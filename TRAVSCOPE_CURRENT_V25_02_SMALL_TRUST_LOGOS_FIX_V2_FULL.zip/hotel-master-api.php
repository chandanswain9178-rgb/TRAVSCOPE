<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
if (is_file(__DIR__ . '/location-master-functions.php')) require_once __DIR__ . '/location-master-functions.php';

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if (empty($_SESSION['admin_id'])) {
    http_response_code(401);
    echo json_encode(['success'=>false,'message'=>'Admin login required.']);
    exit;
}

$destinationId = max(0, (int)($_GET['destination_id'] ?? 0));
$locationId = max(0, (int)($_GET['location_id'] ?? 0));
$q = trim((string)($_GET['q'] ?? ''));
$star = max(0, (int)($_GET['star'] ?? 0));

try {
    if (function_exists('tsLocationEnsureSchema')) tsLocationEnsureSchema($pdo);

    $locations = [];
    if ($destinationId > 0) {
        try {
            $st=$pdo->prepare("SELECT dl.id,dl.location_name,dl.location_type,COUNT(h.id) hotel_count
                               FROM destination_locations dl
                               LEFT JOIN hotels h ON h.location_id=dl.id AND h.destination_id=dl.destination_id AND h.status='active'
                               WHERE dl.destination_id=? AND dl.status='active'
                               GROUP BY dl.id,dl.location_name,dl.location_type,dl.sort_order
                               ORDER BY dl.sort_order,dl.location_name");
            $st->execute([$destinationId]);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
                $locations[] = [
                    'id'=>(int)$row['id'],
                    'name'=>(string)$row['location_name'],
                    'type'=>(string)($row['location_type'] ?? 'city'),
                    'hotel_count'=>(int)($row['hotel_count'] ?? 0),
                ];
            }
        } catch (Throwable $ignored) {
            if (function_exists('tsLocationList')) {
                foreach (tsLocationList($pdo, $destinationId) as $row) {
                    $locations[] = [
                        'id'=>(int)$row['id'],
                        'name'=>(string)$row['location_name'],
                        'type'=>(string)($row['location_type'] ?? 'city'),
                        'hotel_count'=>0,
                    ];
                }
            }
        }
    }

    $hotels = [];
    if ($destinationId > 0) {
        $where = ["h.destination_id=?", "h.status='active'"];
        $params = [$destinationId];
        if ($locationId > 0) {
            $where[] = 'h.location_id=?';
            $params[] = $locationId;
        }
        if (in_array($star, [3,4,5], true)) {
            $where[] = 'h.star_category=?';
            $params[] = $star;
        }
        if ($q !== '') {
            $where[] = '(h.hotel_name LIKE ? OR h.city LIKE ? OR h.area LIKE ? OR h.address LIKE ?)';
            $like = '%' . $q . '%';
            array_push($params, $like, $like, $like, $like);
        }

        $sql = "SELECT h.id,h.destination_id,h.location_id,h.hotel_name,h.city,h.star_category,
                       h.default_room_type,h.default_meal_plan,h.is_preferred,h.priority_order,
                       h.preferred_supplier_id,h.primary_image,h.address,h.area,h.pincode,h.phone,
                       h.website,h.google_maps_url,
                       d.name destination_name,dl.location_name,
                       s.company_name supplier_name,s.priority supplier_priority
                FROM hotels h
                JOIN destinations d ON d.id=h.destination_id
                LEFT JOIN destination_locations dl ON dl.id=h.location_id
                LEFT JOIN suppliers s ON s.id=h.preferred_supplier_id
                WHERE " . implode(' AND ', $where) . "
                ORDER BY COALESCE(dl.location_name,h.city,d.name),h.star_category,h.is_preferred DESC,h.priority_order,h.hotel_name
                LIMIT 500";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
            $hotels[] = [
                'id'=>(int)$row['id'],
                'destination_id'=>(int)$row['destination_id'],
                'destination'=>(string)$row['destination_name'],
                'location_id'=>(int)($row['location_id'] ?? 0),
                'location'=>(string)($row['location_name'] ?: ($row['city'] ?? '')),
                'city'=>(string)($row['city'] ?? ''),
                'name'=>(string)$row['hotel_name'],
                'star'=>(int)$row['star_category'],
                'room_type'=>(string)($row['default_room_type'] ?? ''),
                'meal_plan'=>(string)($row['default_meal_plan'] ?? ''),
                'preferred'=>(int)$row['is_preferred'] === 1,
                'image'=>(string)($row['primary_image'] ?? ''),
                'address'=>(string)($row['address'] ?? ''),
                'area'=>(string)($row['area'] ?? ''),
                'pincode'=>(string)($row['pincode'] ?? ''),
                'phone'=>(string)($row['phone'] ?? ''),
                'website'=>(string)($row['website'] ?? ''),
                'google_maps_url'=>(string)($row['google_maps_url'] ?? ''),
                'supplier_id'=>(int)($row['preferred_supplier_id'] ?? 0),
                'supplier'=>(string)($row['supplier_name'] ?? ''),
            ];
        }
    }

    echo json_encode(['success'=>true,'locations'=>$locations,'hotels'=>$hotels], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    error_log('Hotel Master API: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>'Unable to load Hotel Master data.']);
}
