<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — ADMIN DATA IMPORT + CONTROLLED MIGRATION CENTER
|--------------------------------------------------------------------------
|
| CSV Upload -> Preview -> Duplicate Review -> Explicit Import
|
| Rules:
| - Existing Customer / Supplier masters are NEVER overwritten.
| - Duplicate rows are never imported.
| - Warning rows require explicit "include reviewed warnings".
| - Each imported row runs in its own DB transaction.
| - Batch + row audit remains permanent.
|
*/

$importAclFile = __DIR__ . '/access-control-functions.php';
if (is_file($importAclFile) && !function_exists('tsAclCan')) {
    require_once $importAclFile;
}

$importMasterDataFile = __DIR__ . '/master-data-functions.php';
if (is_file($importMasterDataFile) && !function_exists('tsMasterEmail')) {
    require_once $importMasterDataFile;
}


function tsImportTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];
    $key = strtolower($table);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
              AND table_name = ?
        ");
        $stmt->execute([$table]);

        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}


function tsImportReady(PDO $pdo): bool
{
    return
        tsImportTableExists($pdo, 'data_import_batches')
        && tsImportTableExists($pdo, 'data_import_rows');
}


function tsImportColumnExists(
    PDO $pdo,
    string $table,
    string $column
): bool {
    static $cache = [];

    $key = strtolower($table . '.' . $column);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    if (
        !preg_match('/^[A-Za-z0-9_]+$/', $table)
        || !preg_match('/^[A-Za-z0-9_]+$/', $column)
    ) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = DATABASE()
              AND table_name = ?
              AND column_name = ?
        ");
        $stmt->execute([$table, $column]);

        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}


function tsImportHeader(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/^\xEF\xBB\xBF/', '', $value);
    $value = preg_replace('/[^a-z0-9]+/', '_', $value);

    return trim((string)$value, '_');
}


function tsImportEmail(string $value): string
{
    return function_exists('tsMasterEmail')
        ? tsMasterEmail($value)
        : strtolower(trim($value));
}


function tsImportPhone(string $value): string
{
    if (function_exists('tsMasterPhone')) {
        return tsMasterPhone($value);
    }

    $digits = preg_replace('/[^0-9]/', '', $value);

    return is_string($digits)
        ? (strlen($digits) >= 10 ? substr($digits, -10) : $digits)
        : '';
}


function tsImportText(string $value): string
{
    if (function_exists('tsMasterText')) {
        return tsMasterText($value);
    }

    $value = mb_strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/u', ' ', $value);

    return trim(
        preg_replace('/\s+/u', ' ', (string)$value)
    );
}


function tsImportSchema(string $type): array
{
    return match ($type) {
        'supplier' => [
            'required' => [
                'company_name',
                'primary_contact_name',
            ],
            'allowed' => [
                'company_name',
                'supplier_type',
                'legal_name',
                'gstin',
                'tax_id',
                'website',
                'country',
                'state_region',
                'city',
                'address',
                'default_currency',
                'priority',
                'internal_rating',
                'payment_terms',
                'cancellation_terms',
                'notes',
                'primary_contact_name',
                'primary_contact_mobile',
                'primary_contact_whatsapp',
                'primary_contact_email',
                'status',
            ],
            'label' => 'Suppliers',
            'template' => 'import-template-suppliers.csv',
        ],

        'enquiry' => [
            'required' => [
                'name',
                'email',
                'mobile',
                'destination',
                'travel_date',
                'budget',
                'message',
            ],
            'allowed' => [
                'name',
                'email',
                'mobile',
                'destination',
                'destination_id',
                'travel_date',
                'adults',
                'children',
                'budget',
                'message',
                'status',
                'lead_source',
                'campaign_name',
                'priority',
                'lead_score',
                'estimated_value',
                'owner_admin_email',
                'next_follow_up_at',
                'tags',
                'package_id',
            ],
            'label' => 'Enquiries / Leads',
            'template' => 'import-template-enquiries.csv',
        ],

        default => [
            'required' => [
                'full_name',
                'email',
            ],
            'allowed' => [
                'full_name',
                'email',
                'mobile',
                'country',
                'status',
                'email_verified',
            ],
            'label' => 'Customers',
            'template' => 'import-template-customers.csv',
        ],
    };
}


function tsImportJson(array $value): string
{
    return (string)json_encode(
        $value,
        JSON_UNESCAPED_UNICODE
        | JSON_UNESCAPED_SLASHES
    );
}


function tsImportDecode(?string $json): array
{
    if (!$json) {
        return [];
    }

    $value = json_decode($json, true);

    return is_array($value) ? $value : [];
}


function tsImportCsvRows(array $file, string $type): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Please choose a CSV file to preview.');
    }

    $size = (int)($file['size'] ?? 0);

    if ($size <= 0 || $size > 5 * 1024 * 1024) {
        throw new RuntimeException('CSV file must be between 1 byte and 5 MB.');
    }

    $name = (string)($file['name'] ?? 'import.csv');

    if (strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== 'csv') {
        throw new RuntimeException('Only .csv files are accepted.');
    }

    $tmp = (string)($file['tmp_name'] ?? '');

    if ($tmp === '' || !is_file($tmp)) {
        throw new RuntimeException('Uploaded CSV temporary file is unavailable.');
    }

    $handle = fopen($tmp, 'rb');

    if ($handle === false) {
        throw new RuntimeException('Unable to read uploaded CSV.');
    }

    try {
        $headerRaw = fgetcsv($handle);

        if (!is_array($headerRaw) || !$headerRaw) {
            throw new RuntimeException('CSV header row is missing.');
        }

        $headers = array_map(
            static fn($value) => tsImportHeader((string)$value),
            $headerRaw
        );

        if (count(array_unique($headers)) !== count($headers)) {
            throw new RuntimeException('CSV contains duplicate column headings.');
        }

        $schema = tsImportSchema($type);
        $allowed = array_flip($schema['allowed']);

        foreach ($headers as $header) {
            if ($header === '' || !isset($allowed[$header])) {
                throw new RuntimeException(
                    'Unsupported CSV column: ' . ($header !== '' ? $header : '[blank]') . '.'
                );
            }
        }

        $missing = array_values(
            array_diff($schema['required'], $headers)
        );

        if ($missing) {
            throw new RuntimeException(
                'Missing required CSV column(s): ' . implode(', ', $missing) . '.'
            );
        }

        $rows = [];
        $rowNumber = 1;

        while (($cells = fgetcsv($handle)) !== false) {
            $rowNumber++;

            if ($rowNumber > 2501) {
                throw new RuntimeException(
                    'Maximum import size is 2,500 data rows per batch.'
                );
            }

            if (
                count($cells) === 1
                && trim((string)$cells[0]) === ''
            ) {
                continue;
            }

            if (count($cells) !== count($headers)) {
                $rows[] = [
                    'row_number' => $rowNumber,
                    'raw' => [],
                    'parse_error' =>
                        'Column count does not match CSV header.',
                ];
                continue;
            }

            $row = [];

            foreach ($headers as $index => $header) {
                $row[$header] = trim((string)($cells[$index] ?? ''));
            }

            if (!array_filter(
                $row,
                static fn($value) => trim((string)$value) !== ''
            )) {
                continue;
            }

            $rows[] = [
                'row_number' => $rowNumber,
                'raw' => $row,
                'parse_error' => null,
            ];
        }

        if (!$rows) {
            throw new RuntimeException('CSV contains no data rows.');
        }

        return [
            'filename' => $name,
            'sha256' => hash_file('sha256', $tmp),
            'headers' => $headers,
            'rows' => $rows,
        ];

    } finally {
        fclose($handle);
    }
}


function tsImportExistingCustomerMatches(PDO $pdo, array $row): array
{
    $matches = [];
    $email = tsImportEmail((string)($row['email'] ?? ''));
    $phone = tsImportPhone((string)($row['mobile'] ?? ''));

    if ($email !== '') {
        $stmt = $pdo->prepare("
            SELECT id, full_name, email, mobile
            FROM users
            WHERE LOWER(TRIM(email)) = ?
            ORDER BY id ASC
            LIMIT 3
        ");
        $stmt->execute([$email]);

        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $match) {
            $matches['email:' . (int)$match['id']] = [
                'id' => (int)$match['id'],
                'label' => (string)$match['full_name'],
                'reason' => 'Exact email',
            ];
        }
    }

    if ($phone !== '') {
        $stmt = $pdo->prepare("
            SELECT id, full_name, email, mobile
            FROM users
            WHERE RIGHT(
                REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                    TRIM(COALESCE(mobile,'')),
                    ' ', ''
                ), '-', ''), '(', ''), ')', ''), '+', ''),
                10
            ) = ?
            ORDER BY id ASC
            LIMIT 3
        ");
        $stmt->execute([$phone]);

        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $match) {
            $matches['phone:' . (int)$match['id']] = [
                'id' => (int)$match['id'],
                'label' => (string)$match['full_name'],
                'reason' => 'Normalized mobile',
            ];
        }
    }

    return array_values($matches);
}


function tsImportCustomerNameWarnings(PDO $pdo, array $row): array
{
    $name = tsImportText((string)($row['full_name'] ?? ''));
    $country = tsImportText((string)($row['country'] ?? ''));

    if ($name === '') {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT id, full_name, email, mobile, country
        FROM users
        WHERE LOWER(TRIM(full_name)) = LOWER(TRIM(?))
          AND LOWER(TRIM(COALESCE(country,''))) = LOWER(TRIM(?))
        ORDER BY id ASC
        LIMIT 5
    ");
    $stmt->execute([
        (string)$row['full_name'],
        (string)($row['country'] ?? ''),
    ]);

    return array_map(
        static fn($match) =>
            'Possible existing Customer #'
            . (int)$match['id']
            . ' with same name + country.',
        $stmt->fetchAll(PDO::FETCH_ASSOC) ?: []
    );
}


function tsImportExistingSupplierMatches(PDO $pdo, array $row): array
{
    $matches = [];

    $gst = strtoupper(
        preg_replace(
            '/[^A-Z0-9]/i',
            '',
            (string)($row['gstin'] ?? '')
        )
    );

    $tax = strtoupper(
        preg_replace(
            '/[^A-Z0-9]/i',
            '',
            (string)($row['tax_id'] ?? '')
        )
    );

    if ($gst !== '') {
        $stmt = $pdo->prepare("
            SELECT id, company_name
            FROM suppliers
            WHERE UPPER(
                REPLACE(REPLACE(TRIM(COALESCE(gstin,'')),' ',''),'-','')
            ) = ?
            LIMIT 3
        ");
        $stmt->execute([$gst]);

        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $match) {
            $matches['gst:' . (int)$match['id']] = [
                'id' => (int)$match['id'],
                'label' => (string)$match['company_name'],
                'reason' => 'Exact GSTIN',
            ];
        }
    }

    if ($tax !== '') {
        $stmt = $pdo->prepare("
            SELECT id, company_name
            FROM suppliers
            WHERE UPPER(
                REPLACE(REPLACE(TRIM(COALESCE(tax_id,'')),' ',''),'-','')
            ) = ?
            LIMIT 3
        ");
        $stmt->execute([$tax]);

        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $match) {
            $matches['tax:' . (int)$match['id']] = [
                'id' => (int)$match['id'],
                'label' => (string)$match['company_name'],
                'reason' => 'Exact Tax ID',
            ];
        }
    }

    if (tsImportTableExists($pdo, 'supplier_contacts')) {
        $email = tsImportEmail((string)($row['primary_contact_email'] ?? ''));
        $phone = tsImportPhone((string)($row['primary_contact_mobile'] ?? ''));

        if ($email !== '') {
            $stmt = $pdo->prepare("
                SELECT s.id, s.company_name
                FROM supplier_contacts c
                JOIN suppliers s ON s.id = c.supplier_id
                WHERE LOWER(TRIM(COALESCE(c.email,''))) = ?
                ORDER BY c.is_primary DESC, s.id ASC
                LIMIT 3
            ");
            $stmt->execute([$email]);

            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $match) {
                $matches['email:' . (int)$match['id']] = [
                    'id' => (int)$match['id'],
                    'label' => (string)$match['company_name'],
                    'reason' => 'Exact supplier contact email',
                ];
            }
        }

        if ($phone !== '') {
            $stmt = $pdo->prepare("
                SELECT s.id, s.company_name
                FROM supplier_contacts c
                JOIN suppliers s ON s.id = c.supplier_id
                WHERE RIGHT(
                    REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                        TRIM(COALESCE(c.mobile,'')),
                        ' ', ''
                    ), '-', ''), '(', ''), ')', ''), '+', ''),
                    10
                ) = ?
                ORDER BY c.is_primary DESC, s.id ASC
                LIMIT 3
            ");
            $stmt->execute([$phone]);

            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $match) {
                $matches['phone:' . (int)$match['id']] = [
                    'id' => (int)$match['id'],
                    'label' => (string)$match['company_name'],
                    'reason' => 'Normalized supplier mobile',
                ];
            }
        }
    }

    return array_values($matches);
}


function tsImportSupplierNameWarnings(PDO $pdo, array $row): array
{
    $company = trim((string)($row['company_name'] ?? ''));

    if ($company === '') {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT id, company_name, city, country
        FROM suppliers
        WHERE LOWER(TRIM(company_name)) = LOWER(TRIM(?))
          AND LOWER(TRIM(COALESCE(city,''))) = LOWER(TRIM(?))
          AND LOWER(TRIM(COALESCE(country,''))) = LOWER(TRIM(?))
        ORDER BY id ASC
        LIMIT 5
    ");
    $stmt->execute([
        $company,
        (string)($row['city'] ?? ''),
        (string)($row['country'] ?? ''),
    ]);

    return array_map(
        static fn($match) =>
            'Possible existing Supplier #'
            . (int)$match['id']
            . ' with same company + location.',
        $stmt->fetchAll(PDO::FETCH_ASSOC) ?: []
    );
}


function tsImportResolveDestination(PDO $pdo, array $row): array
{
    $destinationId = max(0, (int)($row['destination_id'] ?? 0));
    $destination = trim((string)($row['destination'] ?? ''));

    if ($destinationId > 0) {
        $stmt = $pdo->prepare("
            SELECT id, name, country
            FROM destinations
            WHERE id = ?
              AND status = 'active'
            LIMIT 1
        ");
        $stmt->execute([$destinationId]);
        $match = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$match) {
            return [
                'ok' => false,
                'message' => 'destination_id does not reference an active Destination.',
            ];
        }

        return [
            'ok' => true,
            'id' => (int)$match['id'],
            'name' => (string)$match['name'],
        ];
    }

    if ($destination === '') {
        return [
            'ok' => false,
            'message' => 'Destination is required.',
        ];
    }

    $stmt = $pdo->prepare("
        SELECT id, name, country
        FROM destinations
        WHERE LOWER(TRIM(name)) = LOWER(TRIM(?))
          AND status = 'active'
        ORDER BY id ASC
        LIMIT 2
    ");
    $stmt->execute([$destination]);

    $matches = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    if (count($matches) === 1) {
        return [
            'ok' => true,
            'id' => (int)$matches[0]['id'],
            'name' => (string)$matches[0]['name'],
        ];
    }

    if (count($matches) > 1) {
        return [
            'ok' => false,
            'message' =>
                'Destination name matches multiple active records; provide destination_id.',
        ];
    }

    return [
        'ok' => false,
        'message' =>
            'Destination was not found in active Destination Master.',
    ];
}


function tsImportEnquiryDuplicate(PDO $pdo, array $row): ?string
{
    $email = tsImportEmail((string)($row['email'] ?? ''));
    $phone = tsImportPhone((string)($row['mobile'] ?? ''));
    $destination = trim((string)($row['destination'] ?? ''));
    $travelDate = trim((string)($row['travel_date'] ?? ''));

    if ($email === '' || $phone === '' || $destination === '' || $travelDate === '') {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT id
        FROM enquiries
        WHERE LOWER(TRIM(email)) = ?
          AND RIGHT(
                REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                    TRIM(COALESCE(mobile,'')),
                    ' ', ''
                ), '-', ''), '(', ''), ')', ''), '+', ''),
                10
              ) = ?
          AND LOWER(TRIM(destination)) = LOWER(TRIM(?))
          AND travel_date = ?
        ORDER BY id DESC
        LIMIT 1
    ");
    $stmt->execute([
        $email,
        $phone,
        $destination,
        $travelDate,
    ]);

    $id = (int)($stmt->fetchColumn() ?: 0);

    return $id > 0
        ? 'Possible duplicate Enquiry #' . $id
            . ' with same email, mobile, destination and travel date.'
        : null;
}


function tsImportOwner(PDO $pdo, string $email): ?array
{
    $email = tsImportEmail($email);

    if ($email === '') {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT id, name, email, status
        FROM admins
        WHERE LOWER(TRIM(email)) = ?
        LIMIT 1
    ");
    $stmt->execute([$email]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

    if (!$row || strtolower((string)$row['status']) !== 'active') {
        return null;
    }

    return $row;
}


function tsImportValidateCustomer(PDO $pdo, array $raw, array &$seen): array
{
    $errors = [];
    $warnings = [];

    $row = [
        'full_name' => trim((string)($raw['full_name'] ?? '')),
        'email' => tsImportEmail((string)($raw['email'] ?? '')),
        'mobile' => trim((string)($raw['mobile'] ?? '')),
        'country' => trim((string)($raw['country'] ?? '')) ?: 'India',
        'status' => strtolower(trim((string)($raw['status'] ?? 'active'))),
        'email_verified' =>
            in_array(
                strtolower(trim((string)($raw['email_verified'] ?? '0'))),
                ['1','yes','true'],
                true
            ) ? 1 : 0,
    ];

    if ($row['full_name'] === '') {
        $errors[] = 'full_name is required.';
    }

    if ($row['email'] === '' || !filter_var($row['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Valid email is required.';
    }

    if (
        $row['mobile'] !== ''
        && !preg_match('/^[0-9+\-\s()]{7,30}$/', $row['mobile'])
    ) {
        $errors[] = 'mobile format is invalid.';
    }

    if (!in_array($row['status'], ['active','inactive','blocked'], true)) {
        $errors[] = 'status must be active, inactive or blocked.';
    }

    $strongMatches = !$errors
        ? tsImportExistingCustomerMatches($pdo, $row)
        : [];

    if ($strongMatches) {
        foreach ($strongMatches as $match) {
            $warnings[] =
                'Existing Customer #'
                . (int)$match['id']
                . ' · '
                . (string)$match['label']
                . ' · '
                . (string)$match['reason'];
        }

        return [
            'status' => 'duplicate',
            'normalized' => $row,
            'errors' => [],
            'warnings' => $warnings,
        ];
    }

    if (!$errors) {
        $emailKey = $row['email'] !== '' ? 'email:' . $row['email'] : '';
        $phone = tsImportPhone($row['mobile']);
        $phoneKey = $phone !== '' ? 'phone:' . $phone : '';

        foreach (array_filter([$emailKey,$phoneKey]) as $key) {
            if (isset($seen[$key])) {
                $warnings[] =
                    'Duplicate inside this CSV; same key already appears on row '
                    . (int)$seen[$key]
                    . '.';

                return [
                    'status' => 'duplicate',
                    'normalized' => $row,
                    'errors' => [],
                    'warnings' => $warnings,
                ];
            }
        }

        foreach (array_filter([$emailKey,$phoneKey]) as $key) {
            $seen[$key] = (int)($raw['__row_number'] ?? 0);
        }

        $warnings = array_merge(
            $warnings,
            tsImportCustomerNameWarnings($pdo, $row)
        );
    }

    return [
        'status' =>
            $errors
                ? 'error'
                : ($warnings ? 'warning' : 'valid'),
        'normalized' => $row,
        'errors' => $errors,
        'warnings' => $warnings,
    ];
}


function tsImportValidateSupplier(PDO $pdo, array $raw, array &$seen): array
{
    $errors = [];
    $warnings = [];

    $row = [
        'company_name' => trim((string)($raw['company_name'] ?? '')),
        'supplier_type' => trim((string)($raw['supplier_type'] ?? '')),
        'legal_name' => trim((string)($raw['legal_name'] ?? '')),
        'gstin' => strtoupper(trim((string)($raw['gstin'] ?? ''))),
        'tax_id' => strtoupper(trim((string)($raw['tax_id'] ?? ''))),
        'website' => trim((string)($raw['website'] ?? '')),
        'country' => trim((string)($raw['country'] ?? '')),
        'state_region' => trim((string)($raw['state_region'] ?? '')),
        'city' => trim((string)($raw['city'] ?? '')),
        'address' => trim((string)($raw['address'] ?? '')),
        'default_currency' =>
            strtoupper(trim((string)($raw['default_currency'] ?? 'INR'))) ?: 'INR',
        'priority' => strtolower(trim((string)($raw['priority'] ?? 'regular'))),
        'internal_rating' => (float)($raw['internal_rating'] ?? 0),
        'payment_terms' => trim((string)($raw['payment_terms'] ?? '')),
        'cancellation_terms' => trim((string)($raw['cancellation_terms'] ?? '')),
        'notes' => trim((string)($raw['notes'] ?? '')),
        'primary_contact_name' =>
            trim((string)($raw['primary_contact_name'] ?? '')),
        'primary_contact_mobile' =>
            trim((string)($raw['primary_contact_mobile'] ?? '')),
        'primary_contact_whatsapp' =>
            trim((string)($raw['primary_contact_whatsapp'] ?? '')),
        'primary_contact_email' =>
            tsImportEmail((string)($raw['primary_contact_email'] ?? '')),
        'status' =>
            strtolower(trim((string)($raw['status'] ?? 'active'))),
    ];

    if ($row['company_name'] === '') {
        $errors[] = 'company_name is required.';
    }

    if ($row['primary_contact_name'] === '') {
        $errors[] = 'primary_contact_name is required.';
    }

    if (
        $row['primary_contact_email'] !== ''
        && !filter_var($row['primary_contact_email'], FILTER_VALIDATE_EMAIL)
    ) {
        $errors[] = 'primary_contact_email is invalid.';
    }

    if (!in_array($row['priority'], ['preferred','regular','backup'], true)) {
        $errors[] = 'priority must be preferred, regular or backup.';
    }

    if ($row['internal_rating'] < 0 || $row['internal_rating'] > 5) {
        $errors[] = 'internal_rating must be between 0 and 5.';
    }

    if (!in_array($row['status'], ['active','inactive'], true)) {
        $errors[] = 'status must be active or inactive.';
    }

    if (
        $row['website'] !== ''
        && !filter_var($row['website'], FILTER_VALIDATE_URL)
    ) {
        $warnings[] = 'website is not a standard absolute URL.';
    }

    $strongMatches = !$errors
        ? tsImportExistingSupplierMatches($pdo, $row)
        : [];

    if ($strongMatches) {
        foreach ($strongMatches as $match) {
            $warnings[] =
                'Existing Supplier #'
                . (int)$match['id']
                . ' · '
                . (string)$match['label']
                . ' · '
                . (string)$match['reason'];
        }

        return [
            'status' => 'duplicate',
            'normalized' => $row,
            'errors' => [],
            'warnings' => $warnings,
        ];
    }

    if (!$errors) {
        $keys = [];

        if ($row['gstin'] !== '') {
            $keys[] = 'gst:' . preg_replace('/[^A-Z0-9]/', '', $row['gstin']);
        }

        if ($row['tax_id'] !== '') {
            $keys[] = 'tax:' . preg_replace('/[^A-Z0-9]/', '', $row['tax_id']);
        }

        if ($row['primary_contact_email'] !== '') {
            $keys[] = 'email:' . $row['primary_contact_email'];
        }

        $phone = tsImportPhone($row['primary_contact_mobile']);

        if ($phone !== '') {
            $keys[] = 'phone:' . $phone;
        }

        foreach ($keys as $key) {
            if ($key !== '' && isset($seen[$key])) {
                return [
                    'status' => 'duplicate',
                    'normalized' => $row,
                    'errors' => [],
                    'warnings' => [
                        'Duplicate inside this CSV; matching key already appears on row '
                        . (int)$seen[$key]
                        . '.',
                    ],
                ];
            }
        }

        foreach ($keys as $key) {
            if ($key !== '') {
                $seen[$key] = (int)($raw['__row_number'] ?? 0);
            }
        }

        $warnings = array_merge(
            $warnings,
            tsImportSupplierNameWarnings($pdo, $row)
        );
    }

    return [
        'status' =>
            $errors
                ? 'error'
                : ($warnings ? 'warning' : 'valid'),
        'normalized' => $row,
        'errors' => $errors,
        'warnings' => $warnings,
    ];
}


function tsImportValidateEnquiry(PDO $pdo, array $raw, array &$seen): array
{
    $errors = [];
    $warnings = [];

    $destinationResult = tsImportResolveDestination($pdo, $raw);

    $row = [
        'name' => trim((string)($raw['name'] ?? '')),
        'email' => tsImportEmail((string)($raw['email'] ?? '')),
        'mobile' => trim((string)($raw['mobile'] ?? '')),
        'destination' =>
            !empty($destinationResult['ok'])
                ? (string)$destinationResult['name']
                : trim((string)($raw['destination'] ?? '')),
        'destination_id' =>
            !empty($destinationResult['ok'])
                ? (int)$destinationResult['id']
                : 0,
        'travel_date' => trim((string)($raw['travel_date'] ?? '')),
        'adults' => max(1, min(30, (int)($raw['adults'] ?? 1))),
        'children' => max(0, min(30, (int)($raw['children'] ?? 0))),
        'budget' => (float)($raw['budget'] ?? 0),
        'message' => trim((string)($raw['message'] ?? '')),
        'status' => strtolower(trim((string)($raw['status'] ?? 'new'))),
        'lead_source' => strtolower(trim((string)($raw['lead_source'] ?? 'other'))),
        'campaign_name' => trim((string)($raw['campaign_name'] ?? 'Imported CSV')),
        'priority' => strtolower(trim((string)($raw['priority'] ?? 'medium'))),
        'lead_score' => max(0, min(100, (int)($raw['lead_score'] ?? 50))),
        'estimated_value' => max(0, (float)($raw['estimated_value'] ?? 0)),
        'owner_admin_email' => tsImportEmail((string)($raw['owner_admin_email'] ?? '')),
        'next_follow_up_at' => trim((string)($raw['next_follow_up_at'] ?? '')),
        'tags' => trim((string)($raw['tags'] ?? 'migration,csv_import')),
        'package_id' => max(0, (int)($raw['package_id'] ?? 0)),
    ];

    if ($row['name'] === '') {
        $errors[] = 'name is required.';
    }

    if ($row['email'] === '' || !filter_var($row['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Valid email is required.';
    }

    if ($row['mobile'] === '') {
        $errors[] = 'mobile is required.';
    }

    if (empty($destinationResult['ok'])) {
        $errors[] = (string)($destinationResult['message'] ?? 'Destination is invalid.');
    }

    if (
        $row['travel_date'] === ''
        || !strtotime($row['travel_date'])
    ) {
        $errors[] = 'Valid travel_date is required.';
    } else {
        $row['travel_date'] = date('Y-m-d', strtotime($row['travel_date']));
    }

    if ($row['budget'] < 0) {
        $errors[] = 'budget cannot be negative.';
    }

    if ($row['message'] === '') {
        $errors[] = 'message is required.';
    }

    if (!in_array($row['status'], ['new','contacted','follow_up','converted','closed'], true)) {
        $errors[] = 'status is invalid.';
    }

    $allowedSources = [
        'website', 'facebook', 'instagram', 'whatsapp', 'google_ads',
        'youtube', 'linkedin', 'twitter', 'telegram', 'phone',
        'walk_in', 'referral', 'manual', 'other'
    ];

    if (!in_array($row['lead_source'], $allowedSources, true)) {
        $warnings[] = 'lead_source was normalized to other.';
        $row['lead_source'] = 'other';
    }

    if (!in_array($row['priority'], ['low','medium','high','urgent'], true)) {
        $warnings[] = 'priority was normalized to medium.';
        $row['priority'] = 'medium';
    }

    if ($row['next_follow_up_at'] !== '') {
        $ts = strtotime($row['next_follow_up_at']);

        if (!$ts) {
            $warnings[] = 'next_follow_up_at is invalid and will be left blank.';
            $row['next_follow_up_at'] = '';
        } else {
            $row['next_follow_up_at'] = date('Y-m-d H:i:s', $ts);
        }
    }

    if ($row['owner_admin_email'] !== '') {
        $owner = tsImportOwner($pdo, $row['owner_admin_email']);

        if (!$owner) {
            $warnings[] =
                'owner_admin_email was not found as an active Admin; lead will import unassigned.';
            $row['owner_admin_id'] = null;
        } else {
            $row['owner_admin_id'] = (int)$owner['id'];
        }
    } else {
        $row['owner_admin_id'] = null;
    }

    $customerMatches =
        tsImportExistingCustomerMatches(
            $pdo,
            [
                'email' => $row['email'],
                'mobile' => $row['mobile'],
            ]
        );

    $customerIds =
        array_values(
            array_unique(
                array_map(
                    static fn($match) => (int)$match['id'],
                    $customerMatches
                )
            )
        );

    if (count($customerIds) === 1) {
        $row['customer_user_id'] = $customerIds[0];
    } elseif (count($customerIds) > 1) {
        $row['customer_user_id'] = null;
        $warnings[] =
            'Lead matches multiple Customer masters by email/mobile; user_id will be left unlinked for Admin review.';
    } else {
        $row['customer_user_id'] = null;
    }

    if ($row['package_id'] > 0) {
        $stmt = $pdo->prepare("
            SELECT id
            FROM packages
            WHERE id = ?
              AND status IN ('active','draft')
            LIMIT 1
        ");
        $stmt->execute([$row['package_id']]);

        if (!$stmt->fetchColumn()) {
            $errors[] = 'package_id does not reference an active/draft Package.';
        }
    }

    if (!$errors) {
        $duplicate = tsImportEnquiryDuplicate($pdo, $row);

        if ($duplicate) {
            return [
                'status' => 'duplicate',
                'normalized' => $row,
                'errors' => [],
                'warnings' => [$duplicate],
            ];
        }

        $fileKey =
            tsImportEmail($row['email'])
            . '|'
            . tsImportPhone($row['mobile'])
            . '|'
            . tsImportText($row['destination'])
            . '|'
            . $row['travel_date'];

        if (isset($seen[$fileKey])) {
            return [
                'status' => 'duplicate',
                'normalized' => $row,
                'errors' => [],
                'warnings' => [
                    'Duplicate inside this CSV; same lead signature appears on row '
                    . (int)$seen[$fileKey]
                    . '.',
                ],
            ];
        }

        $seen[$fileKey] = (int)($raw['__row_number'] ?? 0);
    }

    return [
        'status' =>
            $errors
                ? 'error'
                : ($warnings ? 'warning' : 'valid'),
        'normalized' => $row,
        'errors' => $errors,
        'warnings' => $warnings,
    ];
}


function tsImportValidateRow(
    PDO $pdo,
    string $type,
    array $raw,
    array &$seen
): array {
    return match ($type) {
        'supplier' =>
            tsImportValidateSupplier(
                $pdo,
                $raw,
                $seen
            ),

        'enquiry' =>
            tsImportValidateEnquiry(
                $pdo,
                $raw,
                $seen
            ),

        default =>
            tsImportValidateCustomer(
                $pdo,
                $raw,
                $seen
            ),
    };
}


function tsImportCreateBatch(
    PDO $pdo,
    string $type,
    array $file,
    int $adminId
): int {
    if (!tsImportReady($pdo)) {
        throw new RuntimeException(
            'Import the Data Import SQL before previewing files.'
        );
    }

    if (!in_array($type, ['customer','supplier','enquiry'], true)) {
        throw new RuntimeException('Invalid import type.');
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire(
            $pdo,
            $adminId,
            'manage_access',
            'preview_data_import',
            'data_import_batch',
            null,
            [
                'import_type' => $type,
                'filename' => (string)($file['name'] ?? ''),
            ]
        );
    }

    $csv = tsImportCsvRows($file, $type);

    $previousCompleted = 0;

    $stmt = $pdo->prepare("
        SELECT id
        FROM data_import_batches
        WHERE import_type = ?
          AND file_sha256 = ?
          AND status = 'completed'
        ORDER BY id DESC
        LIMIT 1
    ");
    $stmt->execute([
        $type,
        $csv['sha256']
    ]);

    $previousCompleted =
        (int)($stmt->fetchColumn() ?: 0);

    $pdo->beginTransaction();

    try {
        $stmt = $pdo->prepare("
            INSERT INTO data_import_batches
            (
                import_type,
                original_filename,
                file_sha256,
                status,
                options_json,
                created_by_admin_id
            )
            VALUES (?, ?, ?, 'previewed', ?, ?)
        ");

        $stmt->execute([
            $type,
            mb_substr((string)$csv['filename'], 0, 255),
            (string)$csv['sha256'],
            tsImportJson([
                'headers' => $csv['headers'],
                'previous_completed_batch_id' =>
                    $previousCompleted > 0
                        ? $previousCompleted
                        : null,
            ]),
            $adminId > 0 ? $adminId : null,
        ]);

        $batchId =
            (int)$pdo->lastInsertId();

        $insert = $pdo->prepare("
            INSERT INTO data_import_rows
            (
                batch_id,
                row_number,
                row_hash,
                status,
                raw_json,
                normalized_json,
                errors_json,
                warnings_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $seen = [];
        $counts = [
            'total' => 0,
            'valid' => 0,
            'warning' => 0,
            'duplicate' => 0,
            'error' => 0,
        ];

        foreach ($csv['rows'] as $csvRow) {
            $rowNumber =
                (int)$csvRow['row_number'];

            $raw =
                (array)($csvRow['raw'] ?? []);

            $raw['__row_number'] =
                $rowNumber;

            if (!empty($csvRow['parse_error'])) {
                $result = [
                    'status' => 'error',
                    'normalized' => [],
                    'errors' => [
                        (string)$csvRow['parse_error']
                    ],
                    'warnings' => [],
                ];
            } else {
                $result =
                    tsImportValidateRow(
                        $pdo,
                        $type,
                        $raw,
                        $seen
                    );
            }

            unset($raw['__row_number']);

            $status =
                (string)$result['status'];

            $counts['total']++;

            if (isset($counts[$status])) {
                $counts[$status]++;
            }

            $rowHash =
                hash(
                    'sha256',
                    tsImportJson($raw)
                );

            $insert->execute([
                $batchId,
                $rowNumber,
                $rowHash,
                $status,
                tsImportJson($raw),
                tsImportJson((array)$result['normalized']),
                !empty($result['errors'])
                    ? tsImportJson((array)$result['errors'])
                    : null,
                !empty($result['warnings'])
                    ? tsImportJson((array)$result['warnings'])
                    : null,
            ]);
        }

        $pdo->prepare("
            UPDATE data_import_batches
            SET
                total_rows = ?,
                valid_rows = ?,
                warning_rows = ?,
                duplicate_rows = ?,
                error_rows = ?,
                updated_at = NOW()
            WHERE id = ?
        ")->execute([
            $counts['total'],
            $counts['valid'],
            $counts['warning'],
            $counts['duplicate'],
            $counts['error'],
            $batchId,
        ]);

        $pdo->commit();

        return $batchId;

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $e;
    }
}


function tsImportBatch(
    PDO $pdo,
    int $batchId
): ?array {
    if (
        $batchId <= 0
        || !tsImportReady($pdo)
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT
            b.*,
            a.name AS admin_name,
            a.email AS admin_email
        FROM data_import_batches b
        LEFT JOIN admins a
            ON a.id = b.created_by_admin_id
        WHERE b.id = ?
        LIMIT 1
    ");

    $stmt->execute([$batchId]);

    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}


function tsImportBatchRows(
    PDO $pdo,
    int $batchId,
    string $status = ''
): array {
    if (
        $batchId <= 0
        || !tsImportReady($pdo)
    ) {
        return [];
    }

    $params = [$batchId];
    $where = "batch_id = ?";

    if (
        in_array(
            $status,
            [
                'valid',
                'warning',
                'duplicate',
                'error',
                'imported',
                'skipped',
            ],
            true
        )
    ) {
        $where .= " AND status = ?";
        $params[] = $status;
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM data_import_rows
        WHERE {$where}
        ORDER BY row_number ASC
        LIMIT 2500
    ");

    $stmt->execute($params);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsImportRecentBatches(
    PDO $pdo,
    int $limit = 40
): array {
    if (!tsImportReady($pdo)) {
        return [];
    }

    $limit =
        max(1, min(100, $limit));

    $stmt = $pdo->query("
        SELECT
            b.*,
            a.name AS admin_name
        FROM data_import_batches b
        LEFT JOIN admins a
            ON a.id = b.created_by_admin_id
        ORDER BY b.id DESC
        LIMIT {$limit}
    ");

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsImportSupplierCode(PDO $pdo): string
{
    $year = date('Y');

    $stmt =
        $pdo->query("
            SELECT COALESCE(MAX(id),0)+1
            FROM suppliers
        ");

    $next =
        (int)$stmt->fetchColumn();

    return
        'SUP-'
        . $year
        . '-'
        . str_pad(
            (string)$next,
            5,
            '0',
            STR_PAD_LEFT
        );
}


function tsImportInsertCustomer(
    PDO $pdo,
    array $row
): int {
    $matches =
        tsImportExistingCustomerMatches(
            $pdo,
            $row
        );

    if ($matches) {
        throw new RuntimeException(
            'Duplicate Customer detected again at import time; row was not inserted.'
        );
    }

    $password =
        password_hash(
            bin2hex(random_bytes(32)),
            PASSWORD_DEFAULT
        );

    if ($password === false) {
        throw new RuntimeException(
            'Unable to generate secure Customer password.'
        );
    }

    $stmt = $pdo->prepare("
        INSERT INTO users
        (
            full_name,
            email,
            mobile,
            password,
            profile_image,
            country,
            email_verified,
            status
        )
        VALUES (?, ?, ?, ?, NULL, ?, ?, ?)
    ");

    $stmt->execute([
        (string)$row['full_name'],
        (string)$row['email'],
        trim((string)($row['mobile'] ?? '')) !== ''
            ? (string)$row['mobile']
            : null,
        $password,
        (string)($row['country'] ?: 'India'),
        !empty($row['email_verified']) ? 1 : 0,
        (string)$row['status'],
    ]);

    return (int)$pdo->lastInsertId();
}


function tsImportInsertSupplier(
    PDO $pdo,
    array $row,
    int $adminId
): int {
    $matches =
        tsImportExistingSupplierMatches(
            $pdo,
            $row
        );

    if ($matches) {
        throw new RuntimeException(
            'Duplicate Supplier detected again at import time; row was not inserted.'
        );
    }

    $code =
        tsImportSupplierCode($pdo);

    $stmt = $pdo->prepare("
        INSERT INTO suppliers
        (
            supplier_code,
            company_name,
            supplier_type,
            legal_name,
            gstin,
            tax_id,
            website,
            country,
            state_region,
            city,
            address,
            default_currency,
            priority,
            internal_rating,
            payment_terms,
            cancellation_terms,
            notes,
            status,
            created_by_admin_id,
            updated_by_admin_id
        )
        VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?, ?
        )
    ");

    $stmt->execute([
        $code,
        (string)$row['company_name'],
        (string)$row['supplier_type'] !== ''
            ? (string)$row['supplier_type']
            : null,
        (string)$row['legal_name'] !== ''
            ? (string)$row['legal_name']
            : null,
        (string)$row['gstin'] !== ''
            ? (string)$row['gstin']
            : null,
        (string)$row['tax_id'] !== ''
            ? (string)$row['tax_id']
            : null,
        (string)$row['website'] !== ''
            ? (string)$row['website']
            : null,
        (string)$row['country'] !== ''
            ? (string)$row['country']
            : null,
        (string)$row['state_region'] !== ''
            ? (string)$row['state_region']
            : null,
        (string)$row['city'] !== ''
            ? (string)$row['city']
            : null,
        (string)$row['address'] !== ''
            ? (string)$row['address']
            : null,
        (string)($row['default_currency'] ?: 'INR'),
        (string)$row['priority'],
        (float)$row['internal_rating'],
        (string)$row['payment_terms'] !== ''
            ? (string)$row['payment_terms']
            : null,
        (string)$row['cancellation_terms'] !== ''
            ? (string)$row['cancellation_terms']
            : null,
        (string)$row['notes'] !== ''
            ? (string)$row['notes']
            : null,
        (string)$row['status'],
        $adminId > 0 ? $adminId : null,
        $adminId > 0 ? $adminId : null,
    ]);

    $supplierId =
        (int)$pdo->lastInsertId();

    if (
        $supplierId > 0
        && tsImportTableExists(
            $pdo,
            'supplier_contacts'
        )
    ) {
        $stmt = $pdo->prepare("
            INSERT INTO supplier_contacts
            (
                supplier_id,
                contact_name,
                department,
                mobile,
                whatsapp,
                email,
                is_primary,
                status
            )
            VALUES (?, ?, 'Sales', ?, ?, ?, 1, 'active')
        ");

        $stmt->execute([
            $supplierId,
            (string)$row['primary_contact_name'],
            (string)$row['primary_contact_mobile'] !== ''
                ? (string)$row['primary_contact_mobile']
                : null,
            (string)$row['primary_contact_whatsapp'] !== ''
                ? (string)$row['primary_contact_whatsapp']
                : null,
            (string)$row['primary_contact_email'] !== ''
                ? (string)$row['primary_contact_email']
                : null,
        ]);
    }

    return $supplierId;
}


function tsImportInsertEnquiry(
    PDO $pdo,
    array $row
): int {
    $duplicate =
        tsImportEnquiryDuplicate(
            $pdo,
            $row
        );

    if ($duplicate) {
        throw new RuntimeException(
            'Duplicate Enquiry detected again at import time; row was not inserted.'
        );
    }

    $columns = [
        'package_id',
        'name',
        'email',
        'mobile',
        'destination',
        'travel_date',
        'adults',
        'children',
        'budget',
        'message',
        'status',
        'admin_notes',
    ];

    $values = [
        !empty($row['package_id'])
            ? (int)$row['package_id']
            : null,
        (string)$row['name'],
        (string)$row['email'],
        (string)$row['mobile'],
        (string)$row['destination'],
        (string)$row['travel_date'],
        (int)$row['adults'],
        (int)$row['children'],
        (float)$row['budget'],
        (string)$row['message'],
        (string)$row['status'],
        'Imported by Controlled Migration Center',
    ];

    if (tsImportColumnExists($pdo, 'enquiries', 'destination_id')) {
        $columns[] = 'destination_id';
        $values[] = !empty($row['destination_id'])
            ? (int)$row['destination_id']
            : null;
    }

    if (tsImportColumnExists($pdo, 'enquiries', 'user_id')) {
        $columns[] = 'user_id';
        $values[] = !empty($row['customer_user_id'])
            ? (int)$row['customer_user_id']
            : null;
    }

    $quotedColumns =
        implode(
            ', ',
            array_map(
                static fn($column) => '`' . $column . '`',
                $columns
            )
        );

    $placeholders =
        implode(
            ', ',
            array_fill(0, count($columns), '?')
        );

    $stmt = $pdo->prepare(
        "INSERT INTO enquiries
        ({$quotedColumns}, created_at, updated_at)
        VALUES ({$placeholders}, NOW(), NOW())"
    );

    $stmt->execute($values);

    $enquiryId =
        (int)$pdo->lastInsertId();

    if (
        $enquiryId > 0
        && tsImportTableExists(
            $pdo,
            'crm_lead_meta'
        )
    ) {
        $stmt = $pdo->prepare("
            INSERT INTO crm_lead_meta
            (
                enquiry_id,
                assigned_admin_id,
                priority,
                lead_source,
                campaign_name,
                lead_score,
                estimated_value,
                next_follow_up_at,
                tags,
                created_at,
                updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ON DUPLICATE KEY UPDATE
                assigned_admin_id = VALUES(assigned_admin_id),
                priority = VALUES(priority),
                lead_source = VALUES(lead_source),
                campaign_name = VALUES(campaign_name),
                lead_score = VALUES(lead_score),
                estimated_value = VALUES(estimated_value),
                next_follow_up_at = VALUES(next_follow_up_at),
                tags = VALUES(tags),
                updated_at = NOW()
        ");

        $stmt->execute([
            $enquiryId,
            !empty($row['owner_admin_id'])
                ? (int)$row['owner_admin_id']
                : null,
            (string)$row['priority'],
            (string)($row['lead_source'] ?: 'other'),
            (string)($row['campaign_name'] ?: 'Imported CSV'),
            (int)$row['lead_score'],
            (float)$row['estimated_value'],
            (string)$row['next_follow_up_at'] !== ''
                ? (string)$row['next_follow_up_at']
                : null,
            (string)($row['tags'] ?: 'migration,csv_import'),
        ]);
    }

    return $enquiryId;
}


function tsImportAppendRowWarning(
    PDO $pdo,
    int $rowId,
    string $warning
): void {
    $stmt = $pdo->prepare("
        SELECT warnings_json
        FROM data_import_rows
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$rowId]);

    $warnings =
        tsImportDecode(
            (string)($stmt->fetchColumn() ?: '')
        );

    $warnings[] = $warning;

    $pdo->prepare("
        UPDATE data_import_rows
        SET
            warnings_json = ?,
            updated_at = NOW()
        WHERE id = ?
    ")->execute([
        tsImportJson(array_values(array_unique($warnings))),
        $rowId
    ]);
}


function tsImportMaybeCreateTrip(
    PDO $pdo,
    int $enquiryId,
    int $adminId
): ?int {
    if ($enquiryId <= 0) {
        return null;
    }

    $crmFile =
        __DIR__ . '/crm-functions.php';

    if (
        is_file($crmFile)
        && !function_exists(
            'crmCreateTripForEnquiry'
        )
    ) {
        require_once $crmFile;
    }

    if (!function_exists('crmCreateTripForEnquiry')) {
        return null;
    }

    $trip =
        crmCreateTripForEnquiry(
            $pdo,
            $enquiryId,
            $adminId
        );

    if (is_array($trip)) {
        return
            !empty($trip['id'])
                ? (int)$trip['id']
                : null;
    }

    return
        is_numeric($trip)
            ? (int)$trip
            : null;
}


function tsImportExecuteBatch(
    PDO $pdo,
    int $batchId,
    int $adminId,
    bool $includeWarnings = false,
    bool $createTrips = true
): array {
    if (!tsImportReady($pdo)) {
        throw new RuntimeException(
            'Import SQL is not installed.'
        );
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire(
            $pdo,
            $adminId,
            'manage_access',
            'execute_data_import',
            'data_import_batch',
            $batchId,
            [
                'include_warning_rows' =>
                    $includeWarnings,
                'create_enquiry_trips' =>
                    $createTrips,
            ]
        );
    }

    $pdo->beginTransaction();

    try {
        $stmt = $pdo->prepare("
            SELECT *
            FROM data_import_batches
            WHERE id = ?
            LIMIT 1
            FOR UPDATE
        ");
        $stmt->execute([$batchId]);

        $batch =
            $stmt->fetch(PDO::FETCH_ASSOC)
            ?: null;

        if (!$batch) {
            throw new RuntimeException(
                'Import batch was not found.'
            );
        }

        if (!in_array((string)$batch['status'], ['previewed','importing'], true)) {
            throw new RuntimeException(
                'Only a Previewed or interrupted Importing batch can be processed.'
            );
        }

        $savedOptions =
            tsImportDecode(
                (string)($batch['options_json'] ?? '')
            );

        if ((string)$batch['status'] === 'importing') {
            $includeWarnings =
                !empty($savedOptions['include_warning_rows']);

            $createTrips =
                !empty($savedOptions['create_enquiry_trips']);

            $pdo->prepare("
                UPDATE data_import_batches
                SET updated_at = NOW()
                WHERE id = ?
            ")->execute([$batchId]);

        } else {
            $pdo->prepare("
                UPDATE data_import_batches
                SET
                    status = 'importing',
                    import_started_at = NOW(),
                    options_json = ?,
                    updated_at = NOW()
                WHERE id = ?
            ")->execute([
                tsImportJson(
                    array_merge(
                        $savedOptions,
                        [
                            'include_warning_rows' =>
                                $includeWarnings,
                            'create_enquiry_trips' =>
                                $createTrips,
                        ]
                    )
                ),
                $batchId
            ]);
        }

        $pdo->commit();

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $e;
    }

    $rows =
        tsImportBatchRows(
            $pdo,
            $batchId
        );

    $imported = 0;
    $skipped = 0;
    $failed = 0;
    $tripCreated = 0;

    foreach ($rows as $rowRecord) {
        $rowId =
            (int)$rowRecord['id'];

        $status =
            (string)$rowRecord['status'];

        $eligible =
            $status === 'valid'
            || (
                $includeWarnings
                && $status === 'warning'
            );

        if (!$eligible) {
            if ($status === 'warning') {
                $pdo->prepare("
                    UPDATE data_import_rows
                    SET
                        status = 'skipped',
                        updated_at = NOW()
                    WHERE id = ?
                ")->execute([$rowId]);

                $skipped++;
            } elseif (
                in_array(
                    $status,
                    ['duplicate','error'],
                    true
                )
            ) {
                $skipped++;
            }

            continue;
        }

        $normalized =
            tsImportDecode(
                (string)($rowRecord['normalized_json'] ?? '')
            );

        try {
            $pdo->beginTransaction();

            $type =
                (string)$batch['import_type'];

            if ($type === 'supplier') {
                $targetId =
                    tsImportInsertSupplier(
                        $pdo,
                        $normalized,
                        $adminId
                    );

                $targetTable =
                    'suppliers';

            } elseif ($type === 'enquiry') {
                $targetId =
                    tsImportInsertEnquiry(
                        $pdo,
                        $normalized
                    );

                $targetTable =
                    'enquiries';

            } else {
                $targetId =
                    tsImportInsertCustomer(
                        $pdo,
                        $normalized
                    );

                $targetTable =
                    'users';
            }

            if ($targetId <= 0) {
                throw new RuntimeException(
                    'Insert completed without a new record ID.'
                );
            }

            $pdo->prepare("
                UPDATE data_import_rows
                SET
                    status = 'imported',
                    target_table = ?,
                    target_id = ?,
                    imported_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ")->execute([
                $targetTable,
                $targetId,
                $rowId
            ]);

            $pdo->commit();

            $imported++;

            if (
                $type === 'enquiry'
                && $createTrips
            ) {
                try {
                    $tripId =
                        tsImportMaybeCreateTrip(
                            $pdo,
                            $targetId,
                            $adminId
                        );

                    if ($tripId) {
                        $tripCreated++;
                    } else {
                        tsImportAppendRowWarning(
                            $pdo,
                            $rowId,
                            'Enquiry imported but automatic Trip creation was unavailable; create/open the Trip from CRM.'
                        );
                    }
                } catch (Throwable $tripError) {
                    tsImportAppendRowWarning(
                        $pdo,
                        $rowId,
                        'Enquiry imported but Trip creation failed: '
                        . $tripError->getMessage()
                    );
                }
            }

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $failed++;

            $errors =
                tsImportDecode(
                    (string)($rowRecord['errors_json'] ?? '')
                );

            $errors[] =
                'Import-time error: '
                . $e->getMessage();

            $pdo->prepare("
                UPDATE data_import_rows
                SET
                    status = 'error',
                    errors_json = ?,
                    updated_at = NOW()
                WHERE id = ?
            ")->execute([
                tsImportJson(
                    array_values(
                        array_unique($errors)
                    )
                ),
                $rowId
            ]);
        }
    }

    $stmt =
        $pdo->prepare("
            SELECT
                COUNT(*) AS total_rows,
                SUM(status='valid') AS valid_rows,
                SUM(status='warning') AS warning_rows,
                SUM(status='duplicate') AS duplicate_rows,
                SUM(status='error') AS error_rows,
                SUM(status='imported') AS imported_rows,
                SUM(status='skipped') AS skipped_rows
            FROM data_import_rows
            WHERE batch_id = ?
        ");

    $stmt->execute([$batchId]);

    $counts =
        $stmt->fetch(PDO::FETCH_ASSOC)
        ?: [];

    $result = [
        'preview_valid_rows' =>
            (int)($batch['valid_rows'] ?? 0),
        'preview_warning_rows' =>
            (int)($batch['warning_rows'] ?? 0),
        'preview_duplicate_rows' =>
            (int)($batch['duplicate_rows'] ?? 0),
        'preview_error_rows' =>
            (int)($batch['error_rows'] ?? 0),
        'imported_rows' =>
            (int)($counts['imported_rows'] ?? 0),
        'final_error_rows' =>
            (int)($counts['error_rows'] ?? 0),
        'skipped_rows' =>
            max(
                0,
                (int)($batch['total_rows'] ?? 0)
                - (int)($counts['imported_rows'] ?? 0)
            ),
        'trips_created' =>
            $tripCreated,
        'include_warning_rows' =>
            $includeWarnings,
        'create_enquiry_trips' =>
            $createTrips,
    ];

    $pdo->prepare("
        UPDATE data_import_batches
        SET
            status = 'completed',
            imported_rows = ?,
            skipped_rows = ?,
            result_json = ?,
            completed_at = NOW(),
            updated_at = NOW()
        WHERE id = ?
    ")->execute([
        (int)($counts['imported_rows'] ?? 0),
        (int)$result['skipped_rows'],
        tsImportJson($result),
        $batchId
    ]);

    return $result;
}


function tsImportCancelBatch(
    PDO $pdo,
    int $batchId,
    int $adminId
): void {
    if (!tsImportReady($pdo)) {
        return;
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire(
            $pdo,
            $adminId,
            'manage_access',
            'cancel_data_import',
            'data_import_batch',
            $batchId
        );
    }

    $stmt =
        $pdo->prepare("
            UPDATE data_import_batches
            SET
                status = 'cancelled',
                completed_at = NOW(),
                updated_at = NOW()
            WHERE id = ?
              AND status = 'previewed'
        ");

    $stmt->execute([$batchId]);

    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException(
            'Only a Previewed batch can be cancelled.'
        );
    }
}


function tsImportErrorCsv(
    PDO $pdo,
    int $batchId
): never {
    $batch =
        tsImportBatch(
            $pdo,
            $batchId
        );

    if (!$batch) {
        http_response_code(404);
        exit('Import batch not found.');
    }

    $rows =
        tsImportBatchRows(
            $pdo,
            $batchId
        );

    $filename =
        'TRAVSCOPE-import-batch-'
        . $batchId
        . '-row-report.csv';

    header('Content-Type: text/csv; charset=UTF-8');
    header(
        'Content-Disposition: attachment; filename="'
        . $filename
        . '"'
    );
    header('Cache-Control: no-store');

    $out = fopen('php://output', 'wb');

    if ($out === false) {
        exit;
    }

    fwrite($out, "\xEF\xBB\xBF");

    fputcsv($out, [
        'Row',
        'Status',
        'Errors',
        'Warnings',
        'Target Table',
        'Target ID',
        'Raw Data JSON',
    ]);

    foreach ($rows as $row) {
        fputcsv($out, [
            (int)$row['row_number'],
            (string)$row['status'],
            implode(
                ' | ',
                tsImportDecode(
                    (string)($row['errors_json'] ?? '')
                )
            ),
            implode(
                ' | ',
                tsImportDecode(
                    (string)($row['warnings_json'] ?? '')
                )
            ),
            (string)($row['target_table'] ?? ''),
            (string)($row['target_id'] ?? ''),
            (string)$row['raw_json'],
        ]);
    }

    fclose($out);
    exit;
}
