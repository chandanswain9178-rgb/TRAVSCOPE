<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| ADMIN DASHBOARD
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';

$notificationFunctionsFile = __DIR__ . '/notification-functions.php';
if (is_file($notificationFunctionsFile)) {
    require_once $notificationFunctionsFile;
}


/*
|--------------------------------------------------------------------------
| ADMIN ACCESS ONLY
|--------------------------------------------------------------------------
*/

requireAdmin();


/*
|--------------------------------------------------------------------------
| CURRENT ADMIN
|--------------------------------------------------------------------------
*/

$admin = currentAdmin($pdo);


/*
|--------------------------------------------------------------------------
| VERIFY ADMIN
|--------------------------------------------------------------------------
*/

if (
    !$admin ||
    strtolower((string)($admin['status'] ?? ''))
        !== 'active'
) {

    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_role']
    );

    session_regenerate_id(true);

    redirect(
        BASE_URL . 'login.php'
    );
}
$dashboardNotificationSummary = [
    'unread' => 0,
    'critical' => 0,
    'high' => 0,
    'warning' => 0,
    'due' => 0,
];

$dashboardAccessProfile =
    function_exists('tsAclProfile')
        ? tsAclProfile(
            $pdo,
            (int)$admin['id'],
            (string)($admin['role'] ?? 'admin')
        )
        : (
            strtolower((string)($admin['role'] ?? 'admin')) === 'super_admin'
                ? 'super_admin'
                : 'admin'
        );

if (
    function_exists('tsNotifyReady')
    && tsNotifyReady($pdo)
) {
    try {
        tsNotifyMaybeSync(
            $pdo,
            300
        );

        $dashboardNotificationSummary =
            tsNotifySummary(
                $pdo,
                (int)$admin['id']
            );

    } catch (Throwable $e) {
        error_log(
            'Dashboard notification summary: '
            . $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| SAFE DATABASE HELPERS
|--------------------------------------------------------------------------
|
| During development some travel tables may not exist yet.
| These helpers prevent the whole dashboard from crashing.
|
*/

function dashboardTableExists(
    PDO $pdo,
    string $table
): bool {

    /*
    | Only allow simple table names.
    */

    if (
        !preg_match(
            '/^[a-zA-Z0-9_]+$/',
            $table
        )
    ) {
        return false;
    }

    try {

        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE
                table_schema = DATABASE()
                AND table_name = ?
        ");

        $stmt->execute([
            $table
        ]);

        return
            (int)$stmt->fetchColumn() > 0;

    } catch (Throwable $e) {

        error_log(
            'TRAVSCOPE table check error: '
            . $e->getMessage()
        );

        return false;
    }
}


/*
|--------------------------------------------------------------------------
| SAFE COLUMN CHECK
|--------------------------------------------------------------------------
*/

function dashboardColumnExists(
    PDO $pdo,
    string $table,
    string $column
): bool {

    if (
        !preg_match('/^[a-zA-Z0-9_]+$/', $table)
        || !preg_match('/^[a-zA-Z0-9_]+$/', $column)
    ) {
        return false;
    }

    try {

        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE
                table_schema = DATABASE()
                AND table_name = ?
                AND column_name = ?
        ");

        $stmt->execute([
            $table,
            $column
        ]);

        return
            (int)$stmt->fetchColumn() > 0;

    } catch (Throwable $e) {

        error_log(
            'TRAVSCOPE dashboard column check error ['
            . $table
            . '.'
            . $column
            . ']: '
            . $e->getMessage()
        );

        return false;
    }
}


/*
|--------------------------------------------------------------------------
| SAFE COUNT
|--------------------------------------------------------------------------
*/

function dashboardCount(
    PDO $pdo,
    string $table,
    string $where = ''
): int {

    if (
        !dashboardTableExists(
            $pdo,
            $table
        )
    ) {
        return 0;
    }


    /*
    | Allow only the WHERE clauses used by this dashboard.
    */

    $allowedWhere = [

        '',

        "status = 'active'",

        "status = 'draft'",

        "status = 'new'",

        "status = 'pending'",

        "booking_status = 'pending'",

        "booking_status = 'confirmed'"
    ];


    if (
        !in_array(
            $where,
            $allowedWhere,
            true
        )
    ) {
        return 0;
    }


    try {

        $sql =
            "SELECT COUNT(*) FROM `{$table}`";


        if ($where !== '') {

            $sql .=
                " WHERE {$where}";
        }


        return
            (int)$pdo
                ->query($sql)
                ->fetchColumn();


    } catch (Throwable $e) {

        error_log(
            'TRAVSCOPE dashboard count error ['
            . $table
            . ']: '
            . $e->getMessage()
        );

        return 0;
    }
}


/*
|--------------------------------------------------------------------------
| SITE SETTINGS
|--------------------------------------------------------------------------
*/

try {

    $siteName =
        getSetting(
            $pdo,
            'site_name',
            'TRAVSCOPE.COM'
        );

} catch (Throwable $e) {

    $siteName =
        'TRAVSCOPE.COM';

    error_log(
        'TRAVSCOPE site setting error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| GLOBAL WEBSITE LOGO
|--------------------------------------------------------------------------
*/
$siteLogo = '';
$siteLogoUrl = '';

try {
    $siteLogo = trim((string)getSetting($pdo, 'site_logo', ''));
} catch (Throwable $e) {
    $siteLogo = '';
}

if ($siteLogo !== '') {
    $siteLogoUrl = preg_match('#^https?://#i', $siteLogo)
        ? $siteLogo
        : rtrim((string)BASE_URL, '/') . '/' . ltrim($siteLogo, '/');
}


try {

    $currencySymbol =
        getSetting(
            $pdo,
            'currency_symbol',
            '₹'
        );

} catch (Throwable $e) {

    $currencySymbol =
        '₹';

    error_log(
        'TRAVSCOPE currency setting error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| DASHBOARD STATISTICS
|--------------------------------------------------------------------------
*/

$totalPackages =
    dashboardCount(
        $pdo,
        'packages'
    );


$activePackages =
    dashboardCount(
        $pdo,
        'packages',
        "status = 'active'"
    );


$draftPackages =
    dashboardCount(
        $pdo,
        'packages',
        "status = 'draft'"
    );


$totalDestinations =
    dashboardCount(
        $pdo,
        'destinations'
    );


$activeDestinations =
    dashboardCount(
        $pdo,
        'destinations',
        "status = 'active'"
    );


$totalBookings =
    dashboardCount(
        $pdo,
        'bookings'
    );


$pendingBookings =
    dashboardCount(
        $pdo,
        'bookings',
        "booking_status = 'pending'"
    );


$confirmedBookings =
    dashboardCount(
        $pdo,
        'bookings',
        "booking_status = 'confirmed'"
    );


$newEnquiries =
    dashboardCount(
        $pdo,
        'enquiries',
        "status = 'new'"
    );


$totalEnquiries =
    dashboardCount(
        $pdo,
        'enquiries'
    );


$totalCustomers =
    dashboardCount(
        $pdo,
        'users'
    );


$activeCustomers =
    dashboardCount(
        $pdo,
        'users',
        "status = 'active'"
    );


$pendingReviews =
    dashboardCount(
        $pdo,
        'reviews',
        "status = 'pending'"
    );


$pendingCancellations =
    dashboardCount(
        $pdo,
        'booking_cancellations',
        "status = 'pending'"
    );


$totalBlogStories =
    dashboardCount(
        $pdo,
        'blogs'
    );

$publishedBlogStories =
    dashboardCount(
        $pdo,
        'blogs',
        "status = 'active'"
    );

/*
| blogs uses 'published', which is not in dashboardCount allowed list.
| Read it safely here without changing existing dashboardCount behaviour.
*/
$publishedBlogStories = 0;
if (dashboardTableExists($pdo, 'blogs')) {
    try {
        $publishedBlogStories = (int)$pdo
            ->query("SELECT COUNT(*) FROM blogs WHERE status='published'")
            ->fetchColumn();
    } catch (Throwable $e) {
        $publishedBlogStories = 0;
    }
}


/*
|--------------------------------------------------------------------------
| REVENUE
|--------------------------------------------------------------------------
*/

$totalRevenue = 0.00;

$monthRevenue = 0.00;


if (
    dashboardTableExists(
        $pdo,
        'payments'
    )
) {

    try {

        $totalRevenue =
            (float)$pdo->query("
                SELECT
                    COALESCE(
                        SUM(amount),
                        0
                    )
                FROM payments
                WHERE status = 'success'
            ")->fetchColumn();


        $monthRevenue =
            (float)$pdo->query("
                SELECT
                    COALESCE(
                        SUM(amount),
                        0
                    )
                FROM payments
                WHERE
                    status = 'success'
                    AND YEAR(created_at)
                        = YEAR(CURRENT_DATE())
                    AND MONTH(created_at)
                        = MONTH(CURRENT_DATE())
            ")->fetchColumn();


    } catch (Throwable $e) {

        $totalRevenue = 0.00;

        $monthRevenue = 0.00;

        error_log(
            'TRAVSCOPE revenue error: '
            . $e->getMessage()
        );
    }
}


/* V24.41 — real 7-month revenue chart (successful payments only). */
$executiveRevenue = [];
$chartCurrentMonth = new DateTimeImmutable('first day of this month');
for ($chartIndex = 6; $chartIndex >= 0; $chartIndex--) {
    $chartMonth = $chartCurrentMonth->modify('-' . $chartIndex . ' months');
    $executiveRevenue[$chartMonth->format('Y-m')] = [
        'label' => $chartMonth->format('M'),
        'amount' => 0.0,
    ];
}
if (dashboardTableExists($pdo, 'payments')) {
    try {
        $monthlyPayments = $pdo->query("
            SELECT DATE_FORMAT(created_at, '%Y-%m') AS month_key,
                   COALESCE(SUM(amount), 0) AS total
            FROM payments
            WHERE status = 'success'
              AND created_at >= DATE_FORMAT(DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH), '%Y-%m-01')
            GROUP BY DATE_FORMAT(created_at, '%Y-%m')
        ")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($monthlyPayments as $chartRow) {
            $key = (string)($chartRow['month_key'] ?? '');
            if (isset($executiveRevenue[$key])) {
                $executiveRevenue[$key]['amount'] = max(0.0, (float)$chartRow['total']);
            }
        }
    } catch (Throwable $chartError) {
        error_log('TRAVSCOPE revenue chart: ' . $chartError->getMessage());
    }
}
$executiveRevenueMax = max(1.0, ...array_column(array_values($executiveRevenue), 'amount'));

/*
|--------------------------------------------------------------------------
| RECENT ENQUIRIES
|--------------------------------------------------------------------------
*/

$recentEnquiries = [];


if (
    dashboardTableExists(
        $pdo,
        'enquiries'
    )
) {

    try {

        $recentEnquiries =
            $pdo->query("
                SELECT
                    id,
                    name,
                    email,
                    mobile,
                    destination,
                    travel_date,
                    status,
                    created_at
                FROM enquiries
                ORDER BY id DESC
                LIMIT 6
            ")->fetchAll();


    } catch (Throwable $e) {

        $recentEnquiries = [];

        error_log(
            'TRAVSCOPE enquiries dashboard error: '
            . $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| RECENT BOOKINGS
|--------------------------------------------------------------------------
*/

$recentBookings = [];


if (
    dashboardTableExists(
        $pdo,
        'bookings'
    )
) {

    try {

        /*
        |--------------------------------------------------------------------------
        | WITH PACKAGES TABLE
        |--------------------------------------------------------------------------
        */

        if (
            dashboardTableExists(
                $pdo,
                'packages'
            )
        ) {

            $recentBookings =
                $pdo->query("
                    SELECT
                        b.id,
                        b.booking_number,
                        b.customer_name,
                        b.customer_email,
                        b.customer_mobile,
                        b.total_amount,
                        b.paid_amount,
                        b.booking_status,
                        b.payment_status,
                        b.created_at,

                        p.title AS package_title

                    FROM bookings b

                    LEFT JOIN packages p
                        ON p.id = b.package_id

                    ORDER BY b.id DESC

                    LIMIT 6
                ")->fetchAll();


        /*
        |--------------------------------------------------------------------------
        | WITHOUT PACKAGES TABLE
        |--------------------------------------------------------------------------
        */

        } else {

            $recentBookings =
                $pdo->query("
                    SELECT
                        id,
                        booking_number,
                        customer_name,
                        customer_email,
                        customer_mobile,
                        total_amount,
                        paid_amount,
                        booking_status,
                        payment_status,
                        created_at,

                        NULL AS package_title

                    FROM bookings

                    ORDER BY id DESC

                    LIMIT 6
                ")->fetchAll();
        }


    } catch (Throwable $e) {

        $recentBookings = [];

        error_log(
            'TRAVSCOPE bookings dashboard error: '
            . $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| MANAGEMENT CONTROL TOWER
|--------------------------------------------------------------------------
|
| This dashboard reads the operational and finance tables already created
| by the previous TRAVSCOPE phases. Optional tables are checked first so
| staged installations do not break the existing dashboard.
|
*/

$ctActiveTrips = 0;
$ctOverdueActions = 0;
$ctTripActionRows = [];

$ctPendingSupplierServices = 0;
$ctSupplierProblemServices = 0;
$ctBookingServiceStatusMap = [];

$ctCustomerReceivable = 0.00;
$ctCustomerReceivableCount = 0;
$ctReceivableRows = [];

$ctSupplierPayable = 0.00;
$ctSupplierPayableCount = 0;
$ctPayableRows = [];

$ctUpcomingDepartures = 0;
$ctDeparturesAtRisk = 0;
$ctDepartureRows = [];
$ctFinalVoucherMap = [];

$ctMarginAlertCount = 0;
$ctMarginRiskAmount = 0.00;
$ctMarginRows = [];

$ctClosedProfitabilityCount = 0;
$ctClosedActualMargin = 0.00;


/*
|--------------------------------------------------------------------------
| ACTIVE TRIPS + OVERDUE NEXT ACTIONS
|--------------------------------------------------------------------------
*/

if (
    dashboardTableExists($pdo, 'trips')
    && dashboardColumnExists($pdo, 'trips', 'next_action')
    && dashboardColumnExists($pdo, 'trips', 'next_action_date')
) {

    try {

        $ctActiveTrips =
            (int)$pdo->query("
                SELECT COUNT(*)
                FROM trips
                WHERE
                    status = 'active'
                    AND COALESCE(stage, '') NOT IN ('won','lost')
            ")->fetchColumn();


        $ctOverdueActions =
            (int)$pdo->query("
                SELECT COUNT(*)
                FROM trips
                WHERE
                    status = 'active'
                    AND COALESCE(stage, '') NOT IN ('won','lost')
                    AND next_action_date IS NOT NULL
                    AND next_action_date < CURRENT_DATE()
            ")->fetchColumn();


        if (dashboardTableExists($pdo, 'enquiries')) {

            $ctTripActionRows =
                $pdo->query("
                    SELECT
                        t.id,
                        t.trip_code,
                        t.enquiry_id,
                        t.stage,
                        t.next_action,
                        t.next_action_date,
                        t.travel_start_date,
                        t.expected_value,
                        e.name AS customer_name,
                        e.destination
                    FROM trips t
                    LEFT JOIN enquiries e
                        ON e.id = t.enquiry_id
                    WHERE
                        t.status = 'active'
                        AND COALESCE(t.stage, '') NOT IN ('won','lost')
                    ORDER BY
                        CASE
                            WHEN t.next_action_date IS NOT NULL
                                 AND t.next_action_date < CURRENT_DATE()
                            THEN 0
                            ELSE 1
                        END,
                        CASE
                            WHEN t.next_action_date IS NULL
                            THEN 1
                            ELSE 0
                        END,
                        t.next_action_date ASC,
                        t.id DESC
                    LIMIT 7
                ")->fetchAll(PDO::FETCH_ASSOC);
        }

    } catch (Throwable $e) {

        $ctActiveTrips = 0;
        $ctOverdueActions = 0;
        $ctTripActionRows = [];

        error_log(
            'TRAVSCOPE Control Tower Trip error: '
            . $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| SUPPLIER PROCUREMENT STATUS
|--------------------------------------------------------------------------
*/

if (
    dashboardTableExists($pdo, 'booking_service_snapshots')
) {

    try {

        $ctPendingSupplierServices =
            (int)$pdo->query("
                SELECT COUNT(*)
                FROM booking_service_snapshots
                WHERE
                    (
                        source_supplier_id IS NOT NULL
                        OR internal_supplier_cost > 0
                    )
                    AND procurement_status <> 'confirmed'
            ")->fetchColumn();


        $ctSupplierProblemServices =
            (int)$pdo->query("
                SELECT COUNT(*)
                FROM booking_service_snapshots
                WHERE procurement_status IN (
                    'alternative_required',
                    'rejected'
                )
            ")->fetchColumn();


        $stmt = $pdo->query("
            SELECT
                booking_id,
                SUM(
                    CASE
                        WHEN
                            (
                                source_supplier_id IS NOT NULL
                                OR internal_supplier_cost > 0
                            )
                            AND procurement_status <> 'confirmed'
                        THEN 1
                        ELSE 0
                    END
                ) AS pending_services,
                SUM(
                    CASE
                        WHEN procurement_status IN (
                            'alternative_required',
                            'rejected'
                        )
                        THEN 1
                        ELSE 0
                    END
                ) AS problem_services
            FROM booking_service_snapshots
            GROUP BY booking_id
        ");

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {

            $ctBookingServiceStatusMap[
                (int)$row['booking_id']
            ] = [
                'pending' =>
                    (int)($row['pending_services'] ?? 0),
                'problem' =>
                    (int)($row['problem_services'] ?? 0)
            ];
        }

    } catch (Throwable $e) {

        $ctPendingSupplierServices = 0;
        $ctSupplierProblemServices = 0;
        $ctBookingServiceStatusMap = [];

        error_log(
            'TRAVSCOPE Control Tower supplier confirmation error: '
            . $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| FINAL VOUCHER MAP
|--------------------------------------------------------------------------
*/

if (
    dashboardTableExists($pdo, 'booking_voucher_versions')
) {

    try {

        $stmt = $pdo->query("
            SELECT
                booking_id,
                MAX(version_number) AS final_version
            FROM booking_voucher_versions
            WHERE status = 'final'
            GROUP BY booking_id
        ");

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {

            $ctFinalVoucherMap[
                (int)$row['booking_id']
            ] =
                (int)($row['final_version'] ?? 0);
        }

    } catch (Throwable $e) {

        $ctFinalVoucherMap = [];

        error_log(
            'TRAVSCOPE Control Tower voucher error: '
            . $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| CUSTOMER RECEIVABLES
|--------------------------------------------------------------------------
*/

if (
    dashboardTableExists($pdo, 'bookings')
) {

    try {

        $allReceivables =
            $pdo->query("
                SELECT
                    id,
                    booking_number,
                    customer_name,
                    customer_mobile,
                    travel_date,
                    total_amount,
                    paid_amount,
                    booking_status,
                    payment_status,
                    GREATEST(
                        total_amount - paid_amount,
                        0
                    ) AS outstanding
                FROM bookings
                WHERE
                    booking_status <> 'cancelled'
                    AND total_amount > paid_amount
                ORDER BY
                    outstanding DESC,
                    CASE
                        WHEN travel_date IS NULL
                        THEN 1
                        ELSE 0
                    END,
                    travel_date ASC,
                    id DESC
            ")->fetchAll(PDO::FETCH_ASSOC);


        foreach ($allReceivables as $row) {

            $outstanding =
                max(
                    0,
                    (float)($row['outstanding'] ?? 0)
                );

            if ($outstanding <= 0.009) {
                continue;
            }

            $ctCustomerReceivable +=
                $outstanding;

            $ctCustomerReceivableCount++;

            if (count($ctReceivableRows) < 7) {
                $ctReceivableRows[] = $row;
            }
        }

    } catch (Throwable $e) {

        $ctCustomerReceivable = 0.00;
        $ctCustomerReceivableCount = 0;
        $ctReceivableRows = [];

        error_log(
            'TRAVSCOPE Control Tower receivable error: '
            . $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| SUPPLIER PAYABLES
|--------------------------------------------------------------------------
*/

if (
    dashboardTableExists($pdo, 'supplier_invoices')
    && dashboardTableExists($pdo, 'supplier_payments')
    && dashboardTableExists($pdo, 'suppliers')
) {

    try {

        $rows =
            $pdo->query("
                SELECT
                    i.id,
                    i.booking_id,
                    i.supplier_id,
                    i.invoice_number,
                    i.invoice_date,
                    i.due_date,
                    i.currency,
                    i.total_amount,
                    s.company_name,
                    COALESCE(
                        (
                            SELECT SUM(p.amount)
                            FROM supplier_payments p
                            WHERE
                                p.supplier_invoice_id = i.id
                                AND p.status = 'paid'
                        ),
                        0
                    ) AS paid_amount
                FROM supplier_invoices i
                JOIN suppliers s
                    ON s.id = i.supplier_id
                WHERE i.status = 'approved'
                ORDER BY
                    CASE
                        WHEN i.due_date IS NOT NULL
                             AND i.due_date < CURRENT_DATE()
                        THEN 0
                        ELSE 1
                    END,
                    i.due_date ASC,
                    i.id DESC
            ")->fetchAll(PDO::FETCH_ASSOC);


        foreach ($rows as $row) {

            $outstanding =
                max(
                    0,
                    (float)$row['total_amount']
                    - (float)$row['paid_amount']
                );

            if ($outstanding <= 0.009) {
                continue;
            }

            $row['outstanding'] =
                $outstanding;

            $ctSupplierPayable +=
                $outstanding;

            $ctSupplierPayableCount++;

            if (count($ctPayableRows) < 7) {
                $ctPayableRows[] = $row;
            }
        }

    } catch (Throwable $e) {

        $ctSupplierPayable = 0.00;
        $ctSupplierPayableCount = 0;
        $ctPayableRows = [];

        error_log(
            'TRAVSCOPE Control Tower payable error: '
            . $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| UPCOMING DEPARTURES + DEPARTURE RISK
|--------------------------------------------------------------------------
*/

if (
    dashboardTableExists($pdo, 'bookings')
) {

    try {

        $upcomingRows =
            $pdo->query("
                SELECT
                    id,
                    booking_number,
                    customer_name,
                    customer_mobile,
                    travel_date,
                    total_amount,
                    paid_amount,
                    booking_status,
                    payment_status
                FROM bookings
                WHERE
                    travel_date IS NOT NULL
                    AND travel_date >= CURRENT_DATE()
                    AND travel_date <= DATE_ADD(
                        CURRENT_DATE(),
                        INTERVAL 14 DAY
                    )
                    AND booking_status NOT IN (
                        'cancelled',
                        'completed'
                    )
                ORDER BY
                    travel_date ASC,
                    id ASC
            ")->fetchAll(PDO::FETCH_ASSOC);


        foreach ($upcomingRows as $row) {

            $ctUpcomingDepartures++;

            $bookingId =
                (int)$row['id'];

            $riskReasons = [];

            $customerOutstanding =
                max(
                    0,
                    (float)$row['total_amount']
                    - (float)$row['paid_amount']
                );

            if ($customerOutstanding > 0.009) {
                $riskReasons[] =
                    'Customer due';
            }


            $procurement =
                $ctBookingServiceStatusMap[
                    $bookingId
                ]
                ?? [
                    'pending' => 0,
                    'problem' => 0
                ];

            if ((int)$procurement['problem'] > 0) {

                $riskReasons[] =
                    (int)$procurement['problem']
                    . ' supplier problem';

            } elseif ((int)$procurement['pending'] > 0) {

                $riskReasons[] =
                    (int)$procurement['pending']
                    . ' supplier pending';
            }


            if (
                dashboardTableExists(
                    $pdo,
                    'booking_voucher_versions'
                )
                && empty(
                    $ctFinalVoucherMap[$bookingId]
                )
            ) {

                $riskReasons[] =
                    'Voucher pending';
            }


            if (
                (string)$row['booking_status']
                !== 'confirmed'
            ) {

                $riskReasons[] =
                    'Booking not confirmed';
            }


            if ($riskReasons) {

                $ctDeparturesAtRisk++;

                if (count($ctDepartureRows) < 8) {

                    $row['risk_reasons'] =
                        $riskReasons;

                    $row['outstanding'] =
                        $customerOutstanding;

                    $ctDepartureRows[] =
                        $row;
                }
            }
        }

    } catch (Throwable $e) {

        $ctUpcomingDepartures = 0;
        $ctDeparturesAtRisk = 0;
        $ctDepartureRows = [];

        error_log(
            'TRAVSCOPE Control Tower departure risk error: '
            . $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| LIVE MARGIN VARIANCE ALERTS
|--------------------------------------------------------------------------
*/

if (
    dashboardTableExists($pdo, 'booking_trip_links')
    && dashboardTableExists($pdo, 'bookings')
    && dashboardTableExists($pdo, 'supplier_invoices')
    && dashboardTableExists($pdo, 'booking_actual_direct_costs')
) {

    try {

        $marginCandidates =
            $pdo->query("
                SELECT
                    b.id AS booking_id,
                    b.booking_number,
                    b.customer_name,
                    b.total_amount,
                    b.currency,
                    l.trip_id,
                    l.expected_total_cost,
                    l.expected_margin_amount,
                    COALESCE(
                        (
                            SELECT SUM(i.total_amount)
                            FROM supplier_invoices i
                            WHERE
                                i.booking_id = b.id
                                AND i.status = 'approved'
                        ),
                        0
                    ) AS actual_supplier_cost,
                    COALESCE(
                        (
                            SELECT SUM(dc.amount)
                            FROM booking_actual_direct_costs dc
                            WHERE
                                dc.booking_id = b.id
                                AND dc.status = 'posted'
                        ),
                        0
                    ) AS actual_direct_cost
                FROM booking_trip_links l
                JOIN bookings b
                    ON b.id = l.booking_id
                WHERE b.booking_status <> 'cancelled'
                ORDER BY b.id DESC
            ")->fetchAll(PDO::FETCH_ASSOC);


        foreach ($marginCandidates as $row) {

            $actualSupplier =
                max(
                    0,
                    (float)$row['actual_supplier_cost']
                );

            $actualDirect =
                max(
                    0,
                    (float)$row['actual_direct_cost']
                );

            if (
                $actualSupplier <= 0.009
                && $actualDirect <= 0.009
            ) {
                continue;
            }

            $actualMargin =
                (float)$row['total_amount']
                - $actualSupplier
                - $actualDirect;

            $expectedMargin =
                (float)$row['expected_margin_amount'];

            $variance =
                $actualMargin
                - $expectedMargin;


            if ($variance < -0.009) {

                $ctMarginAlertCount++;

                $ctMarginRiskAmount +=
                    abs($variance);

                if (count($ctMarginRows) < 7) {

                    $row['actual_margin'] =
                        $actualMargin;

                    $row['margin_variance'] =
                        $variance;

                    $ctMarginRows[] =
                        $row;
                }
            }
        }

    } catch (Throwable $e) {

        $ctMarginAlertCount = 0;
        $ctMarginRiskAmount = 0.00;
        $ctMarginRows = [];

        error_log(
            'TRAVSCOPE Control Tower margin alert error: '
            . $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| CLOSED PROFITABILITY
|--------------------------------------------------------------------------
*/

if (
    dashboardTableExists(
        $pdo,
        'booking_profitability_closures'
    )
) {

    try {

        $row =
            $pdo->query("
                SELECT
                    COUNT(*) AS closed_count,
                    COALESCE(
                        SUM(actual_margin),
                        0
                    ) AS actual_margin
                FROM booking_profitability_closures
            ")->fetch(PDO::FETCH_ASSOC)
            ?: [];

        $ctClosedProfitabilityCount =
            (int)($row['closed_count'] ?? 0);

        $ctClosedActualMargin =
            (float)($row['actual_margin'] ?? 0);

    } catch (Throwable $e) {

        $ctClosedProfitabilityCount = 0;
        $ctClosedActualMargin = 0.00;

        error_log(
            'TRAVSCOPE Control Tower closed profitability error: '
            . $e->getMessage()
        );
    }
}




/*
|--------------------------------------------------------------------------
| TODAY ACTION CENTER — ONE-HAND OPERATIONS
|--------------------------------------------------------------------------
| Actionable queues only. Every query is isolated and optional so a staged
| install never takes the main dashboard down.
*/

function dashboardCommandPhoneDigits(string $phone): string
{
    $digits = preg_replace('/\D+/', '', $phone) ?: '';
    if (strlen($digits) === 10) {
        $digits = '91' . $digits;
    }
    return $digits;
}

function dashboardCommandWaUrl(string $phone, string $message = ''): string
{
    $digits = dashboardCommandPhoneDigits($phone);
    if ($digits === '') {
        return '';
    }
    $url = 'https://wa.me/' . rawurlencode($digits);
    if ($message !== '') {
        $url .= '?text=' . rawurlencode($message);
    }
    return $url;
}

$todayNewLeadRows = [];
$todayFollowupRows = [];
$todayQuotationRows = [];
$todaySupplierRows = [];
$todayPaymentApprovalRows = [];
$todayCustomerDueRows = [];
$todaySupplierDueRows = [];
$todayDocumentRows = [];
$todayReadinessRows = [];

$todayNewLeadCount = 0;
$todayFollowupCount = 0;
$todayOverdueFollowupCount = 0;
$todayQuotationCount = 0;
$todayQuotationChangeCount = 0;
$todaySupplierCount = 0;
$todaySupplierProblemCount = 0;
$todayPaymentApprovalCount = 0;
$todayCustomerDueCount = 0;
$todayCustomerDueAmount = 0.0;
$todaySupplierDueCount = 0;
$todaySupplierDueAmount = 0.0;
$todayDocumentCount = 0;
$todayReadinessCount = 0;

// New lead queue.
if (dashboardTableExists($pdo, 'enquiries')) {
    try {
        $todayNewLeadCount = (int)$pdo->query("SELECT COUNT(*) FROM enquiries WHERE status='new'")->fetchColumn();
        $todayNewLeadRows = $pdo->query("\n            SELECT id,name,email,mobile,destination,travel_date,budget,created_at\n            FROM enquiries\n            WHERE status='new'\n            ORDER BY created_at ASC,id ASC\n            LIMIT 6\n        ")->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        error_log('Today Center new leads: '.$e->getMessage());
    }
}

// Sales follow-ups due today or overdue.
if (dashboardTableExists($pdo, 'trips') && dashboardTableExists($pdo, 'enquiries')) {
    try {
        $todayFollowupCount = (int)$pdo->query("\n            SELECT COUNT(*) FROM trips\n            WHERE status='active' AND COALESCE(stage,'') NOT IN ('won','lost')\n              AND next_action_date IS NOT NULL AND next_action_date <= CURRENT_DATE()\n        ")->fetchColumn();
        $todayOverdueFollowupCount = (int)$pdo->query("\n            SELECT COUNT(*) FROM trips\n            WHERE status='active' AND COALESCE(stage,'') NOT IN ('won','lost')\n              AND next_action_date IS NOT NULL AND next_action_date < CURRENT_DATE()\n        ")->fetchColumn();
        $todayFollowupRows = $pdo->query("\n            SELECT t.id AS trip_id,t.enquiry_id,t.trip_code,t.stage,t.next_action,t.next_action_date,\n                   e.name AS customer_name,e.mobile,e.email,e.destination\n            FROM trips t JOIN enquiries e ON e.id=t.enquiry_id\n            WHERE t.status='active' AND COALESCE(t.stage,'') NOT IN ('won','lost')\n              AND t.next_action_date IS NOT NULL AND t.next_action_date <= CURRENT_DATE()\n            ORDER BY t.next_action_date ASC,t.id ASC LIMIT 6\n        ")->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        error_log('Today Center followups: '.$e->getMessage());
    }
}

// Latest customer quotations that need a decision/action.
if (dashboardTableExists($pdo, 'crm_package_versions') && dashboardTableExists($pdo, 'enquiries')) {
    try {
        $hasAcceptance = dashboardTableExists($pdo, 'quotation_acceptances');
        $hasResponses = dashboardTableExists($pdo, 'quotation_customer_responses');
        $acceptJoin = $hasAcceptance ? "LEFT JOIN quotation_acceptances qa ON qa.quotation_version_id=v.id" : "";
        $acceptWhere = $hasAcceptance ? "AND qa.id IS NULL" : "";
        $responseSelect = "NULL AS customer_decision,NULL AS customer_note,NULL AS response_at";
        $responseJoin = "";
        if ($hasResponses) {
            $responseSelect = "qcr.decision AS customer_decision,qcr.customer_note,qcr.created_at AS response_at";
            $responseJoin = "LEFT JOIN quotation_customer_responses qcr ON qcr.id=(SELECT r2.id FROM quotation_customer_responses r2 WHERE r2.quotation_version_id=v.id ORDER BY r2.id DESC LIMIT 1)";
        }
        $sql = "\n            SELECT v.id AS quotation_version_id,v.lead_id,v.version_number,v.package_title,v.final_price,\n                   v.email_sent_at,v.whatsapp_shared_at,e.name AS customer_name,e.mobile,e.email,e.destination,\n                   {$responseSelect}\n            FROM crm_package_versions v\n            JOIN enquiries e ON e.id=v.lead_id\n            JOIN (SELECT lead_id,MAX(version_number) AS max_version FROM crm_package_versions GROUP BY lead_id) latest\n              ON latest.lead_id=v.lead_id AND latest.max_version=v.version_number\n            {$acceptJoin}\n            {$responseJoin}\n            WHERE (v.email_sent_at IS NOT NULL OR v.whatsapp_shared_at IS NOT NULL)\n              AND e.status <> 'converted'\n              {$acceptWhere}\n            ORDER BY CASE WHEN " . ($hasResponses ? "qcr.decision='change_requested'" : "0") . " THEN 0 WHEN " . ($hasResponses ? "qcr.decision='rejected'" : "0") . " THEN 1 ELSE 2 END,\n                     COALESCE(" . ($hasResponses ? "qcr.created_at," : "") . "v.email_sent_at,v.whatsapp_shared_at,v.created_at) ASC\n            LIMIT 8";
        $todayQuotationRows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $countSql = "SELECT COUNT(*) FROM crm_package_versions v
            JOIN enquiries e ON e.id=v.lead_id
            JOIN (SELECT lead_id,MAX(version_number) AS max_version FROM crm_package_versions GROUP BY lead_id) latest
              ON latest.lead_id=v.lead_id AND latest.max_version=v.version_number
            {$acceptJoin}
            WHERE (v.email_sent_at IS NOT NULL OR v.whatsapp_shared_at IS NOT NULL) AND e.status <> 'converted' {$acceptWhere}";
        $todayQuotationCount = (int)$pdo->query($countSql)->fetchColumn();
        if ($hasResponses) {
            $changeSql = "SELECT COUNT(*) FROM crm_package_versions v
                JOIN enquiries e ON e.id=v.lead_id
                JOIN (SELECT lead_id,MAX(version_number) AS max_version FROM crm_package_versions GROUP BY lead_id) latest
                  ON latest.lead_id=v.lead_id AND latest.max_version=v.version_number
                {$acceptJoin}
                JOIN quotation_customer_responses qcr
                  ON qcr.id=(SELECT r2.id FROM quotation_customer_responses r2 WHERE r2.quotation_version_id=v.id ORDER BY r2.id DESC LIMIT 1)
                WHERE (v.email_sent_at IS NOT NULL OR v.whatsapp_shared_at IS NOT NULL) AND e.status <> 'converted' {$acceptWhere}
                  AND qcr.decision='change_requested'";
            $todayQuotationChangeCount = (int)$pdo->query($changeSql)->fetchColumn();
        }
    } catch (Throwable $e) {
        $todayQuotationRows=[];
        error_log('Today Center quotation queue: '.$e->getMessage());
    }
}

// Supplier rate-request reminders + booking confirmation problems/pending.
if (dashboardTableExists($pdo, 'supplier_requests') && dashboardTableExists($pdo, 'suppliers')) {
    try {
        $rateRows = $pdo->query("\n            SELECT 'rate_request' AS action_type,r.id,r.request_code,r.trip_id,r.enquiry_id,NULL AS booking_id,\n                   r.status,r.subject,r.reminder_due_at,r.sent_at,s.company_name,
                   (SELECT COALESCE(NULLIF(sc.whatsapp,''),sc.mobile) FROM supplier_contacts sc WHERE sc.supplier_id=s.id AND sc.status='active' ORDER BY sc.is_primary DESC,sc.id ASC LIMIT 1) AS primary_mobile,
                   (SELECT sc.email FROM supplier_contacts sc WHERE sc.supplier_id=s.id AND sc.status='active' AND sc.email IS NOT NULL AND sc.email<>'' ORDER BY sc.is_primary DESC,sc.id ASC LIMIT 1) AS primary_email,\n                   e.name AS customer_name,e.destination\n            FROM supplier_requests r\n            JOIN suppliers s ON s.id=r.supplier_id\n            LEFT JOIN enquiries e ON e.id=r.enquiry_id\n            WHERE r.status IN ('sent','awaiting_response','reminder_sent','partial_response')\n              AND (r.reminder_due_at IS NULL OR r.reminder_due_at <= NOW())\n            ORDER BY CASE WHEN r.reminder_due_at IS NULL THEN 1 ELSE 0 END,r.reminder_due_at ASC,r.id ASC\n            LIMIT 5\n        ")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $todaySupplierRows = array_merge($todaySupplierRows, $rateRows);
    } catch (Throwable $e) {
        error_log('Today Center supplier rate reminders: '.$e->getMessage());
    }
}
if (dashboardTableExists($pdo, 'supplier_booking_orders') && dashboardTableExists($pdo, 'suppliers') && dashboardTableExists($pdo, 'bookings')) {
    try {
        $orderRows = $pdo->query("\n            SELECT 'booking_order' AS action_type,o.id,o.order_code AS request_code,o.trip_id,NULL AS enquiry_id,o.booking_id,\n                   o.status,o.subject,NULL AS reminder_due_at,o.sent_at,s.company_name,
                   (SELECT COALESCE(NULLIF(sc.whatsapp,''),sc.mobile) FROM supplier_contacts sc WHERE sc.supplier_id=s.id AND sc.status='active' ORDER BY sc.is_primary DESC,sc.id ASC LIMIT 1) AS primary_mobile,
                   (SELECT sc.email FROM supplier_contacts sc WHERE sc.supplier_id=s.id AND sc.status='active' AND sc.email IS NOT NULL AND sc.email<>'' ORDER BY sc.is_primary DESC,sc.id ASC LIMIT 1) AS primary_email,\n                   b.customer_name,b.travel_date AS destination\n            FROM supplier_booking_orders o\n            JOIN suppliers s ON s.id=o.supplier_id\n            JOIN bookings b ON b.id=o.booking_id\n            WHERE o.status IN ('draft','sent','partially_confirmed','alternative_required','rejected')\n              AND b.booking_status <> 'cancelled'\n            ORDER BY CASE WHEN o.status IN ('alternative_required','rejected') THEN 0 WHEN o.status='sent' THEN 1 ELSE 2 END,\n                     COALESCE(b.travel_date,'9999-12-31') ASC,o.id ASC\n            LIMIT 6\n        ")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $todaySupplierRows = array_slice(array_merge($orderRows, $todaySupplierRows), 0, 8);
    } catch (Throwable $e) {
        error_log('Today Center supplier booking orders: '.$e->getMessage());
    }
}
$todaySupplierCount = count($todaySupplierRows);
try {
    $rateCount = 0;
    $orderCount = 0;
    if (dashboardTableExists($pdo, 'supplier_requests')) {
        $rateCount = (int)$pdo->query("SELECT COUNT(*) FROM supplier_requests WHERE status IN ('sent','awaiting_response','reminder_sent','partial_response') AND (reminder_due_at IS NULL OR reminder_due_at <= NOW())")->fetchColumn();
    }
    if (dashboardTableExists($pdo, 'supplier_booking_orders') && dashboardTableExists($pdo, 'bookings')) {
        $orderCount = (int)$pdo->query("SELECT COUNT(*) FROM supplier_booking_orders o JOIN bookings b ON b.id=o.booking_id WHERE o.status IN ('draft','sent','partially_confirmed','alternative_required','rejected') AND b.booking_status <> 'cancelled'")->fetchColumn();
        $todaySupplierProblemCount = (int)$pdo->query("SELECT COUNT(*) FROM supplier_booking_orders o JOIN bookings b ON b.id=o.booking_id WHERE o.status IN ('alternative_required','rejected') AND b.booking_status <> 'cancelled'")->fetchColumn();
    }
    $todaySupplierCount = $rateCount + $orderCount;
} catch (Throwable $e) {
    error_log('Today Center supplier counts: '.$e->getMessage());
}

// Customer-submitted payments waiting for admin approval.
if (dashboardTableExists($pdo, 'payments') && dashboardTableExists($pdo, 'bookings')) {
    try {
        $todayPaymentApprovalCount = (int)$pdo->query("SELECT COUNT(*) FROM payments WHERE status='pending'")->fetchColumn();
        $todayPaymentApprovalRows = $pdo->query("\n            SELECT p.id AS payment_id,p.booking_id,p.amount,p.currency,p.payment_method,p.transaction_id,p.created_at,\n                   b.booking_number,b.customer_name,b.customer_mobile,b.customer_email\n            FROM payments p JOIN bookings b ON b.id=p.booking_id\n            WHERE p.status='pending'\n            ORDER BY p.created_at ASC,p.id ASC LIMIT 6\n        ")->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        error_log('Today Center payment approvals: '.$e->getMessage());
    }
}

// Scheduled customer collections due/overdue (next 3 days included).
if (dashboardTableExists($pdo, 'booking_payment_installments') && dashboardTableExists($pdo, 'booking_payment_schedules') && dashboardTableExists($pdo, 'bookings')) {
    try {
        $todayCustomerDueRows = $pdo->query("\n            SELECT i.id AS installment_id,i.booking_id,i.title,i.due_date,i.amount,i.paid_amount,i.status,\n                   GREATEST(i.amount-i.paid_amount,0) AS outstanding,b.booking_number,b.customer_name,b.customer_mobile,b.customer_email,b.travel_date\n            FROM booking_payment_installments i\n            JOIN booking_payment_schedules ps ON ps.id=i.schedule_id AND ps.status='active'\n            JOIN bookings b ON b.id=i.booking_id\n            WHERE i.status IN ('pending','partially_paid') AND i.due_date IS NOT NULL\n              AND i.due_date <= DATE_ADD(CURRENT_DATE(), INTERVAL 3 DAY)\n              AND b.booking_status <> 'cancelled'\n              AND i.amount > i.paid_amount\n            ORDER BY i.due_date ASC,i.id ASC LIMIT 8\n        ")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($todayCustomerDueRows as $r) {
            $todayCustomerDueCount++;
            $todayCustomerDueAmount += max(0,(float)($r['outstanding'] ?? 0));
        }
    } catch (Throwable $e) {
        error_log('Today Center customer dues: '.$e->getMessage());
    }
}

// Approved supplier invoice balances due/overdue (next 3 days included).
if (dashboardTableExists($pdo, 'supplier_invoices') && dashboardTableExists($pdo, 'supplier_payments') && dashboardTableExists($pdo, 'suppliers') && dashboardTableExists($pdo, 'bookings')) {
    try {
        $todaySupplierDueRows = $pdo->query("\n            SELECT i.id AS invoice_id,i.booking_id,i.supplier_id,i.invoice_number,i.due_date,i.total_amount,\n                   COALESCE((SELECT SUM(p.amount) FROM supplier_payments p WHERE p.supplier_invoice_id=i.id AND p.status='paid'),0) AS paid_amount,\n                   s.company_name,b.booking_number,b.customer_name\n            FROM supplier_invoices i\n            JOIN suppliers s ON s.id=i.supplier_id\n            JOIN bookings b ON b.id=i.booking_id\n            WHERE i.status='approved' AND i.due_date IS NOT NULL\n              AND i.due_date <= DATE_ADD(CURRENT_DATE(), INTERVAL 3 DAY)\n              AND i.total_amount > COALESCE((SELECT SUM(p2.amount) FROM supplier_payments p2 WHERE p2.supplier_invoice_id=i.id AND p2.status='paid'),0)\n            ORDER BY i.due_date ASC,i.id ASC LIMIT 8\n        ")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($todaySupplierDueRows as &$r) {
            $r['outstanding'] = max(0,(float)$r['total_amount']-(float)$r['paid_amount']);
            $todaySupplierDueCount++;
            $todaySupplierDueAmount += $r['outstanding'];
        }
        unset($r);
    } catch (Throwable $e) {
        error_log('Today Center supplier dues: '.$e->getMessage());
    }
}

// Documents needing upload / verification for upcoming live bookings.
if (dashboardTableExists($pdo, 'booking_document_requirements') && dashboardTableExists($pdo, 'bookings')) {
    try {
        $todayDocumentRows = $pdo->query("\n            SELECT d.booking_id,b.booking_number,b.customer_name,b.customer_mobile,b.travel_date,\n                   SUM(CASE WHEN d.is_required=1 AND d.status IN ('required','rejected') THEN 1 ELSE 0 END) AS missing_count,\n                   SUM(CASE WHEN d.is_required=1 AND d.status='uploaded' THEN 1 ELSE 0 END) AS verify_count\n            FROM booking_document_requirements d JOIN bookings b ON b.id=d.booking_id\n            WHERE b.booking_status IN ('pending','confirmed')\n              AND (b.travel_date IS NULL OR b.travel_date >= CURRENT_DATE())\n              AND (b.travel_date IS NULL OR b.travel_date <= DATE_ADD(CURRENT_DATE(), INTERVAL 30 DAY))\n            GROUP BY d.booking_id,b.booking_number,b.customer_name,b.customer_mobile,b.travel_date\n            HAVING missing_count>0 OR verify_count>0\n            ORDER BY CASE WHEN b.travel_date IS NULL THEN 1 ELSE 0 END,b.travel_date ASC,d.booking_id ASC LIMIT 8\n        ")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $todayDocumentCount = count($todayDocumentRows);
    } catch (Throwable $e) {
        error_log('Today Center documents: '.$e->getMessage());
    }
}

// Pre-departure operation checks still incomplete within 14 days.
if (dashboardTableExists($pdo, 'booking_operation_checks') && dashboardTableExists($pdo, 'bookings')) {
    try {
        $todayReadinessRows = $pdo->query("\n            SELECT c.booking_id,b.booking_number,b.customer_name,b.customer_mobile,b.travel_date,\n                   SUM(CASE WHEN c.is_required=1 AND c.is_complete=0 THEN 1 ELSE 0 END) AS incomplete_count\n            FROM booking_operation_checks c JOIN bookings b ON b.id=c.booking_id\n            WHERE b.booking_status IN ('pending','confirmed')\n              AND b.travel_date BETWEEN CURRENT_DATE() AND DATE_ADD(CURRENT_DATE(),INTERVAL 14 DAY)\n            GROUP BY c.booking_id,b.booking_number,b.customer_name,b.customer_mobile,b.travel_date\n            HAVING incomplete_count>0\n            ORDER BY b.travel_date ASC,c.booking_id ASC LIMIT 8\n        ")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $todayReadinessCount = count($todayReadinessRows);
    } catch (Throwable $e) {
        error_log('Today Center readiness: '.$e->getMessage());
    }
}

$todayUrgentTotal = $todayNewLeadCount + $todayFollowupCount + $todayQuotationCount + $todaySupplierCount + $todayPaymentApprovalCount + $todayCustomerDueCount + $todaySupplierDueCount + $todayDocumentCount + $todayReadinessCount;


/*
|--------------------------------------------------------------------------
| ADMIN INITIAL
|--------------------------------------------------------------------------
*/

$adminName =
    trim(
        (string)(
            $admin['name']
            ?? 'Admin'
        )
    );


if ($adminName === '') {

    $adminName =
        'Admin';
}


$adminInitial =
    strtoupper(
        substr(
            $adminName,
            0,
            1
        )
    );

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#07192d"
>

<title>
    Admin Dashboard | <?= e($siteName); ?>
</title>


<!-- GOOGLE FONTS -->

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>


<!-- FONT AWESOME -->

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

/* =========================================================
   VARIABLES
========================================================= */

:root {

    --sidebar:#07192d;
    --sidebar-light:#0d2743;

    --primary:#0b74ff;
    --primary-dark:#075fd2;

    --background:#f5f7fb;
    --white:#ffffff;

    --text:#172033;
    --muted:#778294;

    --border:#e6eaf0;

    --green:#0da66a;
    --orange:#e88b22;
    --red:#e24a5c;
    --purple:#7956d8;

    --shadow:
        0 8px 30px
        rgba(23,32,51,.06);
}


/* =========================================================
   RESET
========================================================= */

* {

    margin:0;
    padding:0;
    box-sizing:border-box;
}


html {

    scroll-behavior:smooth;
}


body {

    font-family:'DM Sans',sans-serif;

    background:var(--background);

    color:var(--text);

    min-height:100vh;
}


a {

    text-decoration:none;
    color:inherit;
}


button {

    font-family:inherit;
}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar {

    position:fixed;

    top:0;
    left:0;
    bottom:0;

    width:265px;

    background:var(--sidebar);

    color:white;

    z-index:1100;

    overflow-y:auto;

    transition:.25s ease;
}


.sidebar-logo {

    height:80px;

    padding:0 23px;

    display:flex;

    align-items:center;

    gap:11px;

    border-bottom:
        1px solid
        rgba(255,255,255,.08);

    font-family:'Manrope',sans-serif;

    font-size:20px;

    font-weight:800;
}


.logo-icon {

    width:42px;
    height:42px;

    border-radius:12px;

    display:grid;

    place-items:center;

    background:
        linear-gradient(
            135deg,
            #0b74ff,
            #00b7ff
        );

    color:white;

    transform:rotate(-5deg);
}


.sidebar-logo span {

    color:#63b4ff;
}


/* =========================================================
   MENU
========================================================= */

.sidebar-menu {

    padding:20px 13px 35px;
}


.menu-title {

    padding:14px 13px 8px;

    color:#647990;

    font-size:12px;

    font-weight:800;

    letter-spacing:1.4px;
}


.menu-link {

    min-height:47px;

    padding:0 14px;

    display:flex;

    align-items:center;

    gap:13px;

    border-radius:10px;

    color:#aebdcc;

    font-size:14px;

    font-weight:600;

    margin-bottom:4px;

    transition:.2s;
}


.menu-link i {

    width:19px;

    text-align:center;

    font-size:15px;
}


.menu-link:hover {

    color:white;

    background:
        rgba(255,255,255,.06);
}


.menu-link.active {

    color:white;

    background:
        rgba(11,116,255,.17);
}


.menu-link.active i {

    color:#61afff;
}


.menu-badge {

    margin-left:auto;

    min-width:22px;
    height:22px;

    padding:0 6px;

    border-radius:50px;

    background:#e54a5b;

    color:white;

    display:grid;

    place-items:center;

    font-size:12px;

    font-weight:800;
}


/* =========================================================
   MAIN
========================================================= */

.main {

    margin-left:265px;

    min-height:100vh;

    transition:.25s;
}


/* =========================================================
   TOPBAR
========================================================= */

.topbar {

    height:80px;

    padding:0 30px;

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:20px;

    background:white;

    border-bottom:
        1px solid
        var(--border);

    position:sticky;

    top:0;

    z-index:900;
}


.mobile-menu {

    display:none;

    width:42px;
    height:42px;

    border:0;

    border-radius:10px;

    background:#edf3fa;

    color:var(--sidebar);

    cursor:pointer;

    font-size:17px;
}


.topbar-left {

    display:flex;

    align-items:center;

    gap:12px;
}


.topbar-title {

    font-weight:700;

    color:var(--sidebar);

    font-size:15px;
}


.top-actions {

    display:flex;

    align-items:center;

    gap:12px;
}


.view-site {

    min-height:41px;

    padding:0 14px;

    border:
        1px solid
        var(--border);

    border-radius:9px;

    display:flex;

    align-items:center;

    gap:8px;

    font-size:14px;

    font-weight:700;

    background:white;

    transition:.2s;
}


.view-site:hover {

    border-color:#bad7fa;

    color:var(--primary);
}


.notification {

    width:41px;
    height:41px;

    display:grid;

    place-items:center;

    border:
        1px solid
        var(--border);

    border-radius:9px;

    position:relative;

    background:white;
}


.notification-dot {

    position:absolute;

    top:7px;
    right:7px;

    width:7px;
    height:7px;

    border-radius:50%;

    background:#e74c5e;
}


/* =========================================================
   ADMIN PROFILE
========================================================= */

.admin-profile {

    display:flex;

    align-items:center;

    gap:10px;

    padding-left:4px;
}


.admin-avatar {

    width:42px;
    height:42px;

    border-radius:50%;

    display:grid;

    place-items:center;

    background:#e8f3ff;

    color:var(--primary);

    font-family:'Manrope',sans-serif;

    font-weight:800;
}


.admin-info strong {

    display:block;

    font-size:14px;

    color:var(--text);
}


.admin-info span {

    display:block;

    color:var(--muted);

    font-size:12px;

    margin-top:2px;
}


/* =========================================================
   CONTENT
========================================================= */

.content {

    padding:30px;
}


.page-heading {

    display:flex;

    align-items:flex-end;

    justify-content:space-between;

    gap:20px;

    margin-bottom:27px;
}


.page-heading h1 {

    font-family:'Manrope',sans-serif;

    color:var(--sidebar);

    font-size:29px;

    letter-spacing:-.7px;
}


.page-heading p {

    margin-top:5px;

    color:var(--muted);

    font-size:14px;
}


.primary-button {

    min-height:45px;

    padding:0 17px;

    display:inline-flex;

    align-items:center;

    justify-content:center;

    gap:8px;

    background:var(--primary);

    color:white;

    border-radius:9px;

    font-size:14px;

    font-weight:700;

    box-shadow:
        0 8px 20px
        rgba(11,116,255,.2);

    transition:.2s;
}


.primary-button:hover {

    background:var(--primary-dark);

    transform:translateY(-1px);
}


/* =========================================================
   STAT CARDS
========================================================= */

.stats-grid {

    display:grid;

    grid-template-columns:
        repeat(4,1fr);

    gap:17px;

    margin-bottom:25px;
}


.stat-card {

    background:white;

    border:
        1px solid
        var(--border);

    border-radius:15px;

    padding:20px;

    min-height:135px;

    display:flex;

    justify-content:space-between;

    gap:15px;

    box-shadow:var(--shadow);
}


.stat-label {

    color:var(--muted);

    font-size:12px;

    font-weight:800;

    letter-spacing:.5px;
}


.stat-number {

    font-family:'Manrope',sans-serif;

    font-size:27px;

    font-weight:800;

    color:var(--sidebar);

    margin-top:11px;
}


.stat-sub {

    margin-top:4px;

    font-size:12px;

    color:#8994a4;
}


.stat-icon {

    flex:0 0 45px;

    height:45px;

    border-radius:12px;

    display:grid;

    place-items:center;

    background:#eaf4ff;

    color:var(--primary);

    font-size:18px;
}


.stat-icon.green {

    background:#eafaf3;

    color:var(--green);
}


.stat-icon.orange {

    background:#fff4e7;

    color:var(--orange);
}


.stat-icon.purple {

    background:#f3edff;

    color:var(--purple);
}


/* =========================================================
   SECONDARY STATS
========================================================= */

.mini-stats {

    display:grid;

    grid-template-columns:
        repeat(5,1fr);

    gap:15px;

    margin-bottom:25px;
}


.mini-stat {

    padding:15px 17px;

    border:
        1px solid
        var(--border);

    border-radius:12px;

    background:white;
}


.mini-stat strong {

    display:block;

    font-family:'Manrope',sans-serif;

    color:var(--sidebar);

    font-size:18px;
}


.mini-stat span {

    color:var(--muted);

    font-size:12px;
}


/* =========================================================
   DASHBOARD GRID
========================================================= */

.dashboard-grid {

    display:grid;

    grid-template-columns:
        minmax(0,1.35fr)
        minmax(300px,.65fr);

    gap:20px;

    margin-bottom:20px;
}


.card {

    background:white;

    border:
        1px solid
        var(--border);

    border-radius:15px;

    overflow:hidden;

    box-shadow:var(--shadow);
}


.card-header {

    min-height:64px;

    padding:0 20px;

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:15px;

    border-bottom:
        1px solid
        var(--border);
}


.card-header h3 {

    font-family:'Manrope',sans-serif;

    font-size:15px;

    color:var(--sidebar);
}


.card-header a {

    color:var(--primary);

    font-size:13px;

    font-weight:700;
}


/* =========================================================
   TABLE
========================================================= */

.table-wrap {

    overflow-x:auto;
}


table {

    width:100%;

    border-collapse:collapse;

    min-width:650px;
}


thead {

    background:#fafbfc;
}


th {

    text-align:left;

    padding:12px 18px;

    color:#8b96a6;

    font-size:12px;

    letter-spacing:.6px;

    text-transform:uppercase;

    font-weight:800;
}


td {

    padding:14px 18px;

    border-top:
        1px solid
        #f0f2f5;

    font-size:13px;

    vertical-align:middle;
}


.customer-name {

    font-weight:700;

    color:#263246;
}


.table-small {

    margin-top:3px;

    color:var(--muted);

    font-size:12px;
}


/* =========================================================
   STATUS
========================================================= */

.status {

    display:inline-flex;

    align-items:center;

    padding:5px 8px;

    border-radius:50px;

    font-size:12px;

    font-weight:800;

    white-space:nowrap;
}


.status-new,
.status-pending,
.status-unpaid {

    background:#fff3e5;

    color:#bd6c10;
}


.status-contacted,
.status-follow_up,
.status-partial {

    background:#eaf4ff;

    color:#086ed9;
}


.status-confirmed,
.status-converted,
.status-paid,
.status-completed {

    background:#e9faf2;

    color:#078652;
}


.status-cancelled,
.status-closed,
.status-refunded {

    background:#fff0f2;

    color:#c83347;
}


/* =========================================================
   QUICK ACTIONS
========================================================= */

.quick-actions {

    padding:18px;

    display:grid;

    grid-template-columns:
        repeat(2,1fr);

    gap:11px;
}


.quick-action {

    min-height:108px;

    padding:15px;

    border:
        1px solid
        var(--border);

    border-radius:12px;

    transition:.2s;
}


.quick-action:hover {

    border-color:#b9d9ff;

    background:#f8fbff;

    transform:translateY(-2px);
}


.quick-action i {

    color:var(--primary);

    font-size:18px;

    margin-bottom:11px;
}


.quick-action strong {

    display:block;

    color:var(--sidebar);

    font-size:13px;
}


.quick-action span {

    display:block;

    color:var(--muted);

    font-size:12px;

    margin-top:3px;

    line-height:1.4;
}


/* =========================================================
   BOOKING SECTION
========================================================= */

.full-card {

    margin-bottom:20px;
}


.amount {

    font-weight:700;

    color:var(--sidebar);
}


/* =========================================================
   SIDEBAR OVERLAY
========================================================= */

.sidebar-overlay {

    display:none;

    position:fixed;

    inset:0;

    background:
        rgba(2,10,18,.5);

    z-index:1050;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:1200px) {

    .stats-grid {

        grid-template-columns:
            repeat(2,1fr);
    }


    .mini-stats {

        grid-template-columns:
            repeat(2,1fr);
    }


    .dashboard-grid {

        grid-template-columns:1fr;
    }
}


@media(max-width:850px) {

    .sidebar {

        transform:
            translateX(-100%);
    }


    .sidebar.open {

        transform:
            translateX(0);
    }


    .sidebar-overlay.show {

        display:block;
    }


    .main {

        margin-left:0;
    }


    .mobile-menu {

        display:grid;

        place-items:center;
    }


    .topbar-title {

        display:none;
    }


    .content {

        padding:20px;
    }


    .page-heading {

        align-items:flex-start;

        flex-direction:column;
    }
}


@media(max-width:600px) {

    .topbar {

        height:70px;

        padding:0 14px;
    }


    .stats-grid,
    .mini-stats {

        grid-template-columns:1fr;
    }


    .content {

        padding:16px;
    }


    .view-site span {

        display:none;
    }


    .notification {

        display:none;
    }


    .admin-info {

        display:none;
    }


    .page-heading h1 {

        font-size:25px;
    }


    .primary-button {

        width:100%;
    }


    .quick-actions {

        grid-template-columns:1fr;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ============================================================
   DASHBOARD — GRAPHICAL COMPACT PROFESSIONAL VIEW
   Visual/layout-only override. Existing PHP logic untouched.
============================================================ */

.content{
    padding:18px 20px 20px !important;
}

.page-heading{
    margin-bottom:14px !important;
    align-items:center !important;
}

.page-heading h1{
    font-size:26px !important;
    line-height:1.15 !important;
}

.page-heading p{
    margin-top:3px !important;
    font-size:12px !important;
}

.primary-button{
    min-height:38px !important;
    padding:0 14px !important;
    font-size:12px !important;
    border-radius:8px !important;
}

/* Main KPI cards */
.stats-grid{
    gap:10px !important;
    margin-bottom:11px !important;
}

.stat-card{
    min-height:96px !important;
    padding:13px 14px !important;
    border-radius:12px !important;
    position:relative;
    overflow:hidden;
    box-shadow:0 5px 16px rgba(20,40,70,.05) !important;
}

.stat-card:before{
    content:"";
    position:absolute;
    inset:0 auto 0 0;
    width:4px;
    background:#2c7ef8;
}

.stat-card:nth-child(1){
    background:linear-gradient(135deg,#ffffff,#f0f7ff) !important;
}
.stat-card:nth-child(1):before{background:#2580f7}

.stat-card:nth-child(2){
    background:linear-gradient(135deg,#ffffff,#eefbf5) !important;
}
.stat-card:nth-child(2):before{background:#13a36f}

.stat-card:nth-child(3){
    background:linear-gradient(135deg,#ffffff,#fff7eb) !important;
}
.stat-card:nth-child(3):before{background:#ef942f}

.stat-card:nth-child(4){
    background:linear-gradient(135deg,#ffffff,#f7f2ff) !important;
}
.stat-card:nth-child(4):before{background:#7d59d9}

.stat-label{
    font-size:10px !important;
    letter-spacing:.55px !important;
}

.stat-number{
    margin-top:6px !important;
    font-size:23px !important;
    line-height:1 !important;
}

.stat-sub{
    margin-top:4px !important;
    font-size:10px !important;
}

.stat-icon{
    flex:0 0 38px !important;
    width:38px !important;
    height:38px !important;
    border-radius:10px !important;
    font-size:15px !important;
}

/* Mini KPI row */
.mini-stats{
    gap:8px !important;
    margin-bottom:11px !important;
}

.mini-stat{
    min-height:64px !important;
    padding:10px 12px !important;
    border-radius:10px !important;
    position:relative;
    overflow:hidden;
}

.mini-stat:nth-child(1){
    background:linear-gradient(135deg,#fff,#eff7ff) !important;
    border-color:#dcecff !important;
}
.mini-stat:nth-child(2){
    background:linear-gradient(135deg,#fff,#f2f8ff) !important;
    border-color:#e0ebf8 !important;
}
.mini-stat:nth-child(3){
    background:linear-gradient(135deg,#fff,#effaf5) !important;
    border-color:#dff1e7 !important;
}
.mini-stat:nth-child(4){
    background:linear-gradient(135deg,#fff,#f6f3ff) !important;
    border-color:#e9e0ff !important;
}
.mini-stat:nth-child(5){
    background:linear-gradient(135deg,#fff,#fff4f4) !important;
    border-color:#f7dede !important;
}

.mini-stat strong{
    font-size:17px !important;
    line-height:1 !important;
}

.mini-stat span{
    margin-top:4px;
    display:block;
    font-size:10px !important;
    line-height:1.25 !important;
}

/* Main dashboard arrangement: enquiries and quick actions balanced */
.dashboard-grid{
    grid-template-columns:minmax(0,1.55fr) minmax(330px,.7fr) !important;
    gap:11px !important;
    margin-bottom:11px !important;
    align-items:stretch !important;
}

.dashboard-grid > .card{
    height:100%;
}

.card{
    border-radius:11px !important;
}

.card-header{
    min-height:48px !important;
    padding:0 13px !important;
}

.card-header h3{
    font-size:14px !important;
}

.card-header a{
    font-size:11px !important;
}

/* Table density */
th{
    padding:8px 11px !important;
    font-size:9px !important;
}

td{
    padding:9px 11px !important;
    font-size:11px !important;
}

.customer-name{
    font-size:11px !important;
}

.table-small{
    margin-top:2px !important;
    font-size:9px !important;
}

.status{
    padding:4px 7px !important;
    font-size:9px !important;
}

/* Quick Actions: compact colorful grid */
.quick-actions{
    padding:10px !important;
    grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    gap:8px !important;
}

.quick-action{
    min-height:76px !important;
    padding:10px !important;
    border-radius:10px !important;
    position:relative;
    overflow:hidden;
    background:#fff !important;
}

.quick-action:nth-child(6n+1){
    background:linear-gradient(135deg,#f3f8ff,#ffffff) !important;
    border-color:#dbeaff !important;
}
.quick-action:nth-child(6n+2){
    background:linear-gradient(135deg,#f0fbf6,#ffffff) !important;
    border-color:#dcefe6 !important;
}
.quick-action:nth-child(6n+3){
    background:linear-gradient(135deg,#fff7ed,#ffffff) !important;
    border-color:#f6e4cf !important;
}
.quick-action:nth-child(6n+4){
    background:linear-gradient(135deg,#f5f1ff,#ffffff) !important;
    border-color:#e6ddfb !important;
}
.quick-action:nth-child(6n+5){
    background:linear-gradient(135deg,#fff1f3,#ffffff) !important;
    border-color:#f4dde1 !important;
}
.quick-action:nth-child(6n+6){
    background:linear-gradient(135deg,#eefbff,#ffffff) !important;
    border-color:#d9edf5 !important;
}

.quick-action i{
    margin-bottom:7px !important;
    font-size:16px !important;
}

.quick-action:nth-child(6n+1) i{color:#2478ed !important}
.quick-action:nth-child(6n+2) i{color:#0f9a68 !important}
.quick-action:nth-child(6n+3) i{color:#df8421 !important}
.quick-action:nth-child(6n+4) i{color:#7653d1 !important}
.quick-action:nth-child(6n+5) i{color:#d34b61 !important}
.quick-action:nth-child(6n+6) i{color:#118dad !important}

.quick-action strong{
    font-size:11px !important;
    line-height:1.2 !important;
}

.quick-action span{
    margin-top:3px !important;
    font-size:9px !important;
    line-height:1.3 !important;
}

/* Recent bookings/full-width cards */
.full-card{
    margin-bottom:11px !important;
}

/* Better use of desktop screen */
@media(min-width:1300px){
    .content{
        padding:16px 18px 18px !important;
    }

    .stats-grid{
        grid-template-columns:repeat(4,minmax(0,1fr)) !important;
    }

    .mini-stats{
        grid-template-columns:repeat(5,minmax(0,1fr)) !important;
    }
}

@media(max-width:1200px){
    .dashboard-grid{
        grid-template-columns:1fr !important;
    }

    .quick-actions{
        grid-template-columns:repeat(3,minmax(0,1fr)) !important;
    }
}

@media(max-width:850px){
    .content{
        padding:14px 12px 18px !important;
    }

    .page-heading{
        margin-bottom:11px !important;
    }

    .stats-grid{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .quick-actions{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }
}

@media(max-width:600px){
    .stats-grid,
    .mini-stats{
        grid-template-columns:1fr !important;
    }

    .quick-actions{
        grid-template-columns:1fr !important;
    }

    .page-heading h1{
        font-size:22px !important;
    }
}



/* ============================================================
   QUICK ACTIONS — SPACE-EFFICIENT PROFESSIONAL POSITION
   Visual-only override
============================================================ */

/* Keep Recent Enquiries wider and Quick Actions compact */
.dashboard-grid{
    grid-template-columns:minmax(0,1fr) 390px !important;
    align-items:start !important;
}

/* Quick Actions card should use only the height its content needs */
.dashboard-grid > .card:last-child{
    height:auto !important;
    align-self:start !important;
}

/* Compact header */
.dashboard-grid > .card:last-child .card-header{
    min-height:44px !important;
    padding:0 12px !important;
}

/* Change large tiles into compact horizontal action buttons */
.quick-actions{
    padding:9px !important;
    grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    gap:6px !important;
}

.quick-action{
    min-height:58px !important;
    padding:8px 9px !important;
    display:grid !important;
    grid-template-columns:25px minmax(0,1fr) !important;
    grid-template-rows:auto auto !important;
    column-gap:7px !important;
    row-gap:1px !important;
    align-items:center !important;
    border-radius:8px !important;
    transform:none !important;
}

.quick-action i{
    grid-column:1 !important;
    grid-row:1 / span 2 !important;
    width:25px !important;
    height:25px !important;
    margin:0 !important;
    border-radius:7px !important;
    display:grid !important;
    place-items:center !important;
    font-size:13px !important;
    background:rgba(255,255,255,.78) !important;
}

.quick-action strong{
    grid-column:2 !important;
    grid-row:1 !important;
    align-self:end !important;
    font-size:10px !important;
    line-height:1.15 !important;
}

.quick-action span{
    grid-column:2 !important;
    grid-row:2 !important;
    align-self:start !important;
    margin:1px 0 0 !important;
    font-size:8px !important;
    line-height:1.2 !important;

    /* Keep descriptions useful without making the card tall */
    display:-webkit-box !important;
    -webkit-line-clamp:2 !important;
    -webkit-box-orient:vertical !important;
    overflow:hidden !important;
}

.quick-action:hover{
    transform:translateY(-1px) !important;
}

/* Medium screens: Quick Actions becomes a compact full-width strip */
@media(max-width:1200px){
    .dashboard-grid{
        grid-template-columns:1fr !important;
    }

    .quick-actions{
        grid-template-columns:repeat(3,minmax(0,1fr)) !important;
    }
}

/* Tablet */
@media(max-width:850px){
    .quick-actions{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }
}

/* Mobile */
@media(max-width:520px){
    .quick-actions{
        grid-template-columns:1fr !important;
    }

    .quick-action{
        min-height:54px !important;
    }
}



/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}

/* ============================================================
   MANAGEMENT CONTROL TOWER
============================================================ */

.control-tower{margin:22px 0 24px}
.control-tower-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:12px}
.control-tower-title h2{margin:0;color:#12233f;font-size:20px}
.control-tower-title p{margin:5px 0 0;color:#70809b;font-size:12px;line-height:1.5}
.control-tower-live{flex:0 0 auto;display:inline-flex;align-items:center;gap:6px;padding:6px 9px;border-radius:999px;background:#ecfdf5;color:#047857;border:1px solid #a7f3d0;font-size:9px;font-weight:900;letter-spacing:.04em}
.ct-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}
.ct-kpi{display:block;min-width:0;padding:13px;border-radius:14px;border:1px solid #dce5ef;background:#fff;color:inherit;text-decoration:none;box-shadow:0 6px 20px rgba(15,23,42,.035);transition:.18s ease}
.ct-kpi:hover{transform:translateY(-1px);border-color:#b7c9de;box-shadow:0 8px 24px rgba(15,23,42,.07)}
.ct-kpi-top{display:flex;align-items:center;justify-content:space-between;gap:8px}
.ct-kpi-label{color:#74839b;font-size:9px;font-weight:900;text-transform:uppercase;letter-spacing:.04em}
.ct-kpi-icon{width:30px;height:30px;display:grid;place-items:center;border-radius:9px;background:#eff6ff;color:#2563eb;font-size:12px}
.ct-kpi.orange .ct-kpi-icon{background:#fff7ed;color:#c2410c}
.ct-kpi.red .ct-kpi-icon{background:#fef2f2;color:#b91c1c}
.ct-kpi.green .ct-kpi-icon{background:#ecfdf5;color:#047857}
.ct-kpi.purple .ct-kpi-icon{background:#f5f3ff;color:#6d28d9}
.ct-kpi-value{display:block;margin-top:8px;color:#10213d;font-size:20px;font-weight:900;line-height:1.1}
.ct-kpi-sub{display:block;margin-top:5px;color:#7a879b;font-size:9px;line-height:1.4}
.ct-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:12px}
.ct-panel{min-width:0;border:1px solid #dce5ef;border-radius:14px;overflow:hidden;background:#fff;box-shadow:0 6px 20px rgba(15,23,42,.03)}
.ct-panel-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff}
.ct-panel-head strong{display:block;color:#172b4d;font-size:12px}
.ct-panel-head small{display:block;margin-top:3px;color:#8793a7;font-size:9px}
.ct-panel-head a{flex:0 0 auto;color:#1766b8;font-size:9px;font-weight:800;text-decoration:none}
.ct-list{display:grid}
.ct-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:center;padding:9px 11px;border-bottom:1px solid #eef2f6;color:inherit;text-decoration:none}
.ct-row:last-child{border-bottom:0}
.ct-row:hover{background:#fbfdff}
.ct-row strong{display:block;color:#263851;font-size:10px}
.ct-row small{display:block;margin-top:3px;color:#7d899b;font-size:8.5px;line-height:1.4}
.ct-row-value{text-align:right;white-space:nowrap;color:#24354d;font-size:10px;font-weight:900}
.ct-tag{display:inline-flex;align-items:center;gap:4px;margin-top:3px;padding:3px 6px;border-radius:999px;background:#eff6ff;color:#1d4ed8;font-size:8px;font-weight:900}
.ct-tag.overdue,.ct-tag.risk{background:#fef2f2;color:#b91c1c}
.ct-tag.warn{background:#fff7ed;color:#c2410c}
.ct-tag.good{background:#ecfdf5;color:#047857}
.ct-empty{padding:18px 12px;text-align:center;color:#93a0b2;font-size:10px}
.ct-risk-reasons{display:flex;gap:4px;flex-wrap:wrap;margin-top:4px}
.ct-risk-reasons span{padding:3px 5px;border-radius:999px;background:#fff7ed;color:#c2410c;font-size:7.5px;font-weight:900}
@media(max-width:1200px){.ct-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:900px){.ct-grid{grid-template-columns:1fr}}
@media(max-width:600px){.control-tower-head{flex-direction:column}.ct-kpis{grid-template-columns:1fr}}




/* ============================================================
   TODAY ACTION CENTER — ONE-HAND OPERATIONS
============================================================ */
.today-center{margin:22px 0 24px;border:1px solid #d9e4f1;border-radius:18px;background:linear-gradient(180deg,#f9fbff 0%,#fff 100%);box-shadow:0 10px 30px rgba(15,23,42,.055);overflow:hidden}
.today-center-head{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;padding:16px 17px;border-bottom:1px solid #e6edf5;background:linear-gradient(120deg,#07192d 0%,#0d3762 100%);color:#fff}
.today-center-head h2{margin:0;font-size:20px;color:#fff}.today-center-head p{margin:5px 0 0;font-size:10px;line-height:1.5;color:#c8d8ea}.today-center-badge{display:inline-flex;gap:6px;align-items:center;white-space:nowrap;padding:7px 10px;border-radius:999px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.18);font-size:9px;font-weight:900;letter-spacing:.04em}.today-center-badge.hot{background:#fff1f2;color:#be123c;border-color:#fecdd3}
.today-kpis{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;padding:12px}
.today-kpi{min-width:0;padding:11px;border:1px solid #e0e8f1;border-radius:12px;background:#fff;text-decoration:none;color:inherit}.today-kpi:hover{border-color:#b7cae1;box-shadow:0 5px 18px rgba(15,23,42,.06)}.today-kpi span{display:block}.today-kpi .tk-label{font-size:8px;font-weight:900;text-transform:uppercase;letter-spacing:.045em;color:#7c899b}.today-kpi .tk-value{margin-top:5px;font-size:18px;font-weight:900;color:#142844}.today-kpi .tk-sub{margin-top:3px;font-size:8px;color:#8a96a8;line-height:1.35}.today-kpi.danger{border-color:#fecdd3;background:#fffafb}.today-kpi.warn{border-color:#fed7aa;background:#fffdf8}.today-kpi.good{border-color:#bbf7d0;background:#fbfffd}
.today-tabs-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;padding:0 12px 12px}.today-panel{min-width:0;border:1px solid #e0e8f1;border-radius:13px;background:#fff;overflow:hidden}.today-panel-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 11px;background:#f8fbff;border-bottom:1px solid #e8eef5}.today-panel-head strong{font-size:11px;color:#203651}.today-panel-head small{display:block;margin-top:2px;font-size:8px;color:#8794a7}.today-count{display:inline-grid;place-items:center;min-width:24px;height:24px;padding:0 6px;border-radius:999px;background:#eaf2ff;color:#175fb0;font-size:9px;font-weight:900}.today-count.red{background:#fff1f2;color:#be123c}.today-list{display:grid}.today-row{padding:9px 10px;border-bottom:1px solid #edf1f6}.today-row:last-child{border-bottom:0}.today-row-top{display:flex;gap:9px;justify-content:space-between;align-items:flex-start}.today-row-main{min-width:0}.today-row-main strong{display:block;font-size:10px;color:#253a55;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.today-row-main small{display:block;margin-top:3px;color:#7f8b9e;font-size:8px;line-height:1.4}.today-row-right{text-align:right;white-space:nowrap;font-size:9px;font-weight:900;color:#24364e}.today-actions{display:flex;gap:5px;flex-wrap:wrap;margin-top:7px}.today-action{display:inline-flex;align-items:center;gap:4px;padding:5px 7px;border-radius:7px;border:1px solid #dce6f0;background:#fff;color:#27527e;text-decoration:none;font-size:8px;font-weight:900}.today-action:hover{background:#f4f8fc}.today-action.primary{background:#0b74ff;color:#fff;border-color:#0b74ff}.today-action.green{background:#ecfdf5;color:#047857;border-color:#a7f3d0}.today-action.orange{background:#fff7ed;color:#c2410c;border-color:#fed7aa}.today-action.red{background:#fff1f2;color:#be123c;border-color:#fecdd3}.today-pill{display:inline-flex;margin-top:4px;padding:3px 6px;border-radius:999px;background:#eff6ff;color:#1d4ed8;font-size:7px;font-weight:900;text-transform:uppercase}.today-pill.red{background:#fff1f2;color:#be123c}.today-pill.orange{background:#fff7ed;color:#c2410c}.today-pill.green{background:#ecfdf5;color:#047857}.today-empty{padding:17px 10px;text-align:center;color:#8b98aa;font-size:9px}.today-foot{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 12px;background:#f8fafc;border-top:1px solid #e6edf5;font-size:8px;color:#8290a3}.today-foot a{font-weight:900;color:#1766b8;text-decoration:none}
@media(max-width:1250px){.today-kpis{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(max-width:900px){.today-tabs-grid{grid-template-columns:1fr}.today-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:600px){.today-center-head{flex-direction:column}.today-kpis{grid-template-columns:1fr}.today-row-top{flex-direction:column}.today-row-right{text-align:left}}


/* V24.41 International executive dashboard — scoped to dashboard content only. */
.main .content{background:#f4f8fd;padding:16px 18px 28px;max-width:none}
.ex-hero{isolation:isolate;position:relative;display:flex;align-items:center;justify-content:space-between;gap:18px;min-height:156px;padding:22px 28px;border:1px solid #d6e6f7;border-radius:16px;overflow:hidden;background:#e7f4ff url('assets/travscope-dashboard-hero.svg') no-repeat center right;background-size:cover;box-shadow:0 6px 22px rgba(21,55,92,.055)}
.ex-hero:before{content:'';position:absolute;z-index:-1;inset:0;background:linear-gradient(90deg,rgba(244,251,255,.98),rgba(239,249,255,.93) 36%,rgba(233,246,255,.33) 67%,rgba(226,246,255,.02))}
.ex-hero-content{max-width:610px}.ex-hero-kicker{font-size:10px;letter-spacing:.11em;font-weight:900;color:#4c6e96}.ex-hero h1{margin:5px 0 7px;font-family:Manrope,Arial,sans-serif;color:#102d56;font-size:clamp(25px,2.6vw,34px);line-height:1.18;letter-spacing:-.04em}.ex-hero h1 span{color:#0975e8}.ex-hero p{margin:0;color:#536d89;font-size:12px;line-height:1.55;max-width:525px}
.ex-hero-right{display:flex;flex-direction:column;align-items:flex-end;gap:17px;min-width:195px}.ex-hero-motto{color:#12396c;font-weight:850;font-size:12px;font-style:italic;line-height:1.15;text-align:center;transform:rotate(-5deg);text-shadow:0 1px 0 #fff}.ex-hero-motto i{color:#027bf7}.ex-primary-action{display:inline-flex;align-items:center;gap:9px;padding:13px 17px;background:linear-gradient(120deg,#0874ee,#1163e2);border-radius:10px;box-shadow:0 8px 17px rgba(11,107,231,.2);color:white!important;font-size:12px;font-weight:900;text-decoration:none}.ex-primary-action:hover{filter:brightness(1.05)}
.ex-kpis{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:9px;margin:0 0 14px}.ex-kpi{min-width:0;display:flex;align-items:flex-start;gap:10px;min-height:86px;background:#fff;border:1px solid #e0e8f2;border-radius:13px;padding:13px 10px;text-decoration:none!important;box-shadow:0 5px 19px rgba(33,63,104,.035);transition:transform .15s,border-color .15s}.ex-kpi:hover{transform:translateY(-2px);border-color:#aacaf0}.ex-kpi-icon{width:38px;height:38px;flex:0 0 38px;border-radius:12px;background:#e7f1ff;color:#1774ed;display:grid;place-items:center;font-size:17px}.ex-kpi-content{min-width:0;display:block}.ex-kpi-content>span{display:block;color:#57708d;font-size:10px;font-weight:850;line-height:1.2}.ex-kpi-content strong{display:block;color:#112e50;margin:5px 0;font-weight:900;letter-spacing:-.025em;font-size:clamp(16px,1.35vw,22px);white-space:nowrap}.ex-kpi-content small{display:block;color:#7388a3;line-height:1.35;font-size:9px}.ex-kpi.k-green .ex-kpi-icon{background:#dff8ef;color:#029968}.ex-kpi.k-amber .ex-kpi-icon{background:#fff3e2;color:#e78e00}.ex-kpi.k-violet .ex-kpi-icon{background:#f1eafa;color:#8140dd}.ex-kpi.k-teal .ex-kpi-icon{background:#def8f6;color:#089893}.ex-kpi.k-cyan .ex-kpi-icon{background:#e4f2ff;color:#1774db}.ex-kpi.k-red .ex-kpi-icon{background:#ffebeb;color:#df373e}
.today-center{margin:0 0 11px!important;border-radius:13px!important;background:#fff!important}.today-center-head{background:linear-gradient(110deg,#0d3258,#0d568c)!important;align-items:center!important;padding:14px 16px!important}.today-center-head h2{font-size:17px!important}.today-center-head p{font-size:10px!important}.ex-command-tools{display:flex;align-items:center;gap:8px}.ex-live-date{padding:7px 11px;border:1px solid rgba(255,255,255,.25);border-radius:9px;color:#ecf5ff;font-size:10px;font-weight:800}.today-kpis{grid-template-columns:repeat(5,minmax(0,1fr))!important;gap:7px!important;padding:10px!important}.today-kpi{position:relative;min-height:63px;padding:10px 10px 9px 44px!important;border-radius:10px!important;background:#fff!important;border-color:#e1e9f3!important}.ex-command-icon{position:absolute;top:12px;left:9px;width:27px;height:27px;display:grid!important;place-items:center;background:#e7f1ff;color:#1674e9;border-radius:8px;font-size:12px}.today-kpi:nth-child(5n+2) .ex-command-icon{background:#fff1e4;color:#e58a16}.today-kpi:nth-child(5n+3) .ex-command-icon{background:#e4f8ef;color:#0c9b67}.today-kpi:nth-child(5n+4) .ex-command-icon{background:#f2eaff;color:#7949d9}.today-kpi:nth-child(5n+5) .ex-command-icon{background:#ffecec;color:#e34848}.today-kpi .tk-label{font-size:9px!important;color:#566d89!important}.today-kpi .tk-value{font-size:16px!important;margin:2px 0!important}.today-kpi .tk-sub{font-size:9px!important;white-space:normal}.ex-deep-queues{margin:0 10px 11px;border:1px solid #e4edf7;border-radius:10px;overflow:hidden}.ex-deep-queues>summary,.ex-deep-reports>summary{list-style:none;display:flex;align-items:center;gap:8px;cursor:pointer;padding:11px 13px;color:#1a5c99;background:#f5faff;font-size:11px;font-weight:850}.ex-deep-queues>summary::-webkit-details-marker,.ex-deep-reports>summary::-webkit-details-marker{display:none}.ex-deep-queues>summary>span,.ex-deep-reports>summary>span{margin-left:auto;font-size:10px;font-weight:500;color:#768ca7}.ex-deep-queues[open]>summary,.ex-deep-reports[open]>summary{border-bottom:1px solid #dce7f4}.ex-deep-queues .today-tabs-grid{padding-top:10px}.ex-deep-queues .today-foot{margin:0}
.ex-ops-row,.ex-finance-row{display:grid;gap:11px;margin-bottom:11px;align-items:stretch}.ex-ops-row{grid-template-columns:minmax(0,1fr) minmax(0,1.55fr) minmax(0,1.08fr)}.ex-finance-row{grid-template-columns:1.2fr 1fr 1fr 1.04fr}.ex-board{min-width:0;border:1px solid #e0e8f2;border-radius:13px;background:#fff;overflow:hidden;box-shadow:0 4px 18px rgba(24,57,98,.03)}.ex-board>header{min-height:43px;padding:12px 13px;display:flex;align-items:center;justify-content:space-between;gap:6px;border-bottom:1px solid #edf1f7}.ex-board>header h2{color:#173252;font-size:12px;font-weight:900;margin:0}.ex-board>header a{color:#096bd3;text-decoration:none;font-size:10px;font-weight:800;white-space:nowrap}.ex-board-list{display:grid}.ex-empty,.ex-empty-small{padding:19px 12px;display:flex;align-items:center;justify-content:center;gap:8px;color:#899bb0;font-size:11px}.ex-empty i{font-size:15px}.ex-empty-small{border:1px dashed #e0e8f2;margin:10px;border-radius:8px;text-align:center}.ex-lead,.ex-trip{min-height:53px;min-width:0;display:flex;align-items:center;gap:9px;padding:9px 12px;text-decoration:none;color:inherit;border-bottom:1px solid #edf2f7}.ex-lead:last-child,.ex-trip:last-child{border-bottom:0}.ex-lead:hover,.ex-trip:hover,.ex-money-row:hover{background:#f5faff}.ex-avatar,.ex-trip-icon{flex:0 0 29px;width:29px;height:29px;border-radius:50%;display:grid;place-items:center;background:#287bde;color:#fff;font-size:10px;font-weight:900}.ex-lead:nth-child(4n+2) .ex-avatar{background:#8b81de}.ex-lead:nth-child(4n+3) .ex-avatar{background:#21aaa2}.ex-lead:nth-child(4n) .ex-avatar{background:#ad76dc}.ex-trip-icon{border-radius:8px;background:#e7f1ff;color:#1873d4}.ex-lead-text,.ex-trip-text{display:block;flex:1;min-width:0}.ex-lead-text strong,.ex-trip-text strong{display:block;font-size:10px;color:#213d5c;font-weight:850;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ex-lead-text small,.ex-trip-text small{display:block;margin-top:3px;color:#8192aa;font-size:9px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ex-state{display:inline-flex;align-items:center;border-radius:7px;padding:4px 7px;background:#eaf3ff;color:#1763c2;font-size:9px;font-weight:850;white-space:nowrap}.ex-state.state-cancelled,.ex-state.state-rejected{background:#fff0f0;color:#cf3643}.ex-state.state-pending,.ex-state.state-follow_up{background:#fff4e4;color:#bd701b}.ex-state.state-converted,.ex-state.state-confirmed,.ex-state.state-contacted,.ex-state.state-paid{background:#e6f8ef;color:#07885e}.ex-row-arrow{color:#9ab0c8;font-size:9px}.ex-due{font-size:9px;color:#ad6d2b;white-space:nowrap;padding:5px;background:#fff4e9;border-radius:7px}.ex-due.overdue{background:#ffebeb;color:#bc3244}
.ex-booking-scroll{overflow-x:auto}.ex-booking-table{width:100%;border-collapse:collapse;table-layout:fixed}.ex-booking-table th{background:#f3f8fe;padding:10px 8px;text-align:left;font-size:8px;letter-spacing:.04em;text-transform:uppercase;color:#7087a4}.ex-booking-table td{padding:11px 8px;font-size:9px;line-height:1.35;border-bottom:1px solid #eef2f7;color:#49607c;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ex-booking-table tr:last-child td{border-bottom:0}.ex-booking-table th:first-child{width:25%}.ex-booking-table th:nth-child(2){width:19%}.ex-booking-table th:nth-child(3){width:26%}.ex-booking-table th:nth-child(4){width:15%}.ex-booking-table th:nth-child(5){width:15%}.ex-booking-table td:first-child a{color:#174875;text-decoration:none;font-weight:900}.ex-booking-table .ex-price{color:#223b58;font-weight:850}.ex-empty-cell{text-align:center;white-space:normal!important;padding:22px!important}
.ex-mini-explainer{margin:7px 13px;font-size:9px;color:#8ca0b7}.ex-chart{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));align-items:end;gap:8px;padding:5px 12px 10px;height:172px}.ex-chart-month{display:flex;align-items:center;flex-direction:column;height:100%;min-width:0}.ex-chart-amount{font-size:8px;color:#7189a7;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}.ex-chart-track{position:relative;flex:1;width:100%;max-width:32px;border-bottom:1px solid #d8e3f0;background:repeating-linear-gradient(to top,#f5f9fd 0,#f5f9fd 1px,transparent 1px,transparent 27px)}.ex-chart-track span{position:absolute;bottom:0;left:0;right:0;background:linear-gradient(0deg,#2781ed,#83c9ff);border-radius:5px 5px 0 0}.ex-chart-month small{padding-top:6px;color:#677f9b;font-size:9px}.ex-finance-total{display:flex;align-items:center;gap:11px;padding:11px 12px}.ex-finance-total strong{display:block;color:#153353;font-size:20px;font-weight:900}.ex-finance-total small{display:block;color:#8595ac;font-size:9px;margin-top:3px}.ex-finance-icon{flex:0 0 39px;width:39px;height:39px;border-radius:12px;background:#ffe9eb;color:#d83848;display:grid;place-items:center;font-size:18px}.ex-payables .ex-finance-icon{background:#e0f8ed;color:#079d6b}.ex-money-row{display:flex;justify-content:space-between;gap:8px;align-items:center;padding:9px 11px;border-top:1px solid #edf2f7;color:inherit;text-decoration:none}.ex-money-row span strong,.ex-money-row span small{display:block}.ex-money-row span strong{font-size:9px;color:#23466a}.ex-money-row span small{font-size:9px;color:#8798a8}.ex-money-row>b{color:#294260;font-size:10px;white-space:nowrap}.ex-money-row em{font-size:8px;color:#ce6820;background:#fff4e6;padding:2px 4px;border-radius:4px;font-style:normal}.ex-quick-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;padding:10px}.ex-quick-grid a{display:grid;justify-items:center;gap:5px;min-height:56px;padding:8px 3px;border:1px solid #e6edf5;border-radius:9px;background:#fcfdff;text-align:center;text-decoration:none;color:#3c5270;font-size:8px;font-weight:850}.ex-quick-grid a:hover{background:#edf6ff;border-color:#c4d8ef}.ex-quick-grid i{display:grid;place-items:center;width:26px;height:26px;border-radius:8px;background:#e5f1ff;color:#1774e5;font-size:12px}.ex-quick-grid a:nth-child(4n+2) i{background:#e1f6ed;color:#0c9969}.ex-quick-grid a:nth-child(4n+3) i{background:#f1eaff;color:#7843cd}.ex-quick-grid a:nth-child(4n+4) i{background:#fff2e8;color:#e27a22}
.ex-deep-reports{border:1px solid #dce7f5;border-radius:12px;overflow:hidden;background:#fff;margin:14px 0}.ex-deep-reports>summary{font-size:12px;padding:14px 15px}.ex-deep-reports .control-tower{margin:14px}.ex-deep-reports .dashboard-grid,.ex-deep-reports>.full-card{margin:14px}
@media(max-width:1500px){.ex-kpis{grid-template-columns:repeat(4,minmax(0,1fr))}.ex-ops-row{grid-template-columns:1fr 1.35fr}.ex-trip-actions{grid-column:1/-1}.ex-finance-row{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:1080px){.today-kpis{grid-template-columns:repeat(3,minmax(0,1fr))!important}.ex-ops-row{grid-template-columns:1fr}.ex-trip-actions{grid-column:auto}}
@media(max-width:740px){.main .content{padding:11px}.ex-hero{padding:17px;min-height:145px}.ex-hero-right{min-width:0}.ex-hero-motto{display:none}.ex-primary-action{font-size:10px;padding:10px}.ex-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.ex-kpi{min-height:75px}.today-kpis{grid-template-columns:repeat(2,minmax(0,1fr))!important}.ex-finance-row{grid-template-columns:1fr}.ex-command-tools{flex-wrap:wrap;justify-content:end}.ex-live-date{display:none}.ex-deep-reports>summary>span,.ex-deep-queues>summary>span{display:none}}
@media(max-width:390px){.ex-kpis{grid-template-columns:1fr}.ex-hero{flex-direction:column;align-items:start}.ex-hero-right{align-items:start}}



/* V24.65: General Settings logo in the marked admin brand area only. */
.sidebar-logo.has-uploaded-logo{
    justify-content:flex-start!important;
    padding-left:16px!important;
    padding-right:16px!important;
}
.sidebar-logo .ts-admin-brand-logo{
    display:block;
    width:auto;
    height:auto;
    max-width:175px;
    max-height:48px;
    object-fit:contain;
    object-position:left center;
}
</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>


<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo<?= $siteLogoUrl !== '' ? ' has-uploaded-logo' : ''; ?>">
        <?php if ($siteLogoUrl !== ''): ?>
            <img
                src="<?= e($siteLogoUrl); ?>"
                alt="<?= e((string)$siteName); ?>"
                class="ts-admin-brand-logo"
            >
        <?php else: ?>
            <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
            <div class="sidebar-brand-text">
                <strong>TRAVSCOPE</strong>
                <small>Travel Business System</small>
            </div>
        <?php endif; ?>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <a href="admin-notifications.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-notifications.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-bell"></i><span>Notifications</span>
            <?php if ((int)$dashboardNotificationSummary['unread'] > 0): ?>
                <span class="menu-badge">
                    <?= min(99, (int)$dashboardNotificationSummary['unread']); ?>
                </span>
            <?php endif; ?>
        </a>

        <a href="admin-business-analytics.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-business-analytics.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-line"></i><span>Business Analytics</span>
        </a>

        <a href="admin-mis-reports.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-mis-reports.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-file-lines"></i><span>Management MIS</span>
        </a>

        <a href="admin-access-control.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-access-control.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-user-shield"></i><span>Access Control</span>
        </a>

        <?php if (in_array($dashboardAccessProfile, ['admin','super_admin'], true)): ?>
            <a href="admin-system-health.php"
               class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-system-health.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-heart-pulse"></i><span>System Health</span>
            </a>

            <a href="admin-master-data.php"
               class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-master-data.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-object-group"></i><span>Master Data</span>
            </a>

            <a href="admin-data-import.php"
               class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-data-import.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-file-import"></i><span>Data Import</span>
            </a>

            <a href="admin-operational-settings.php"
               class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-operational-settings.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-sliders"></i><span>Operational Settings</span>
            </a>

            <a href="admin-deployment-safety.php"
               class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-deployment-safety.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-shield-halved"></i><span>Deployment Safety</span>
            </a>

            <a href="admin-system-jobs.php"
               class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-system-jobs.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-gears"></i><span>System Jobs</span>
            </a>
        <?php endif; ?>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->







<!-- =========================================================
     SIDEBAR OVERLAY
========================================================= -->




<!-- =========================================================
     SIDEBAR
========================================================= -->

<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->




<!-- =========================================================
     MAIN
========================================================= -->

<main class="main">


    <!-- TOPBAR -->

    <header class="topbar">


        <div class="topbar-left">


            


            <div class="topbar-title">

                TRAVSCOPE Administration

            </div>


        </div>


        <div class="top-actions">


            <a
                href="<?= e(BASE_URL); ?>"
                target="_blank"
                class="view-site"
            >

                <i class="fa-solid fa-arrow-up-right-from-square"></i>

                <span>
                    View Website
                </span>

            </a>


            <a
                href="<?= e(BASE_URL . 'admin-notifications.php'); ?>"
                class="notification"
                title="<?= (int)$dashboardNotificationSummary['unread'] > 0
                    ? (int)$dashboardNotificationSummary['unread'] . ' unread system notification(s)'
                    : 'System Notifications'; ?>"
            >

                <i class="fa-regular fa-bell"></i>

                <?php if (
                    (int)$dashboardNotificationSummary['unread'] > 0
                ): ?>

                    <span class="notification-dot"></span>

                <?php endif; ?>

            </a>


            <div class="admin-profile">


                <div class="admin-avatar">

                    <?= e($adminInitial); ?>

                </div>


                <div class="admin-info">

                    <strong>

                        <?= e($admin['name']); ?>

                    </strong>


                    <span>

                        <?= e(
                            ucwords(
                                str_replace(
                                    '_',
                                    ' ',
                                    $admin['role']
                                )
                            )
                        ); ?>

                    </span>

                </div>


            </div>


        </div>


    </header>


    <!-- =====================================================
         CONTENT
    ====================================================== -->

    <div class="content">


        <!-- V24.41: Executive homepage. All figures below come from the existing live queries. -->
        <section class="ex-kpis" aria-label="Live performance overview">
            <a class="ex-kpi k-blue" href="admin-packages.php"><span class="ex-kpi-icon"><i class="fa-solid fa-box-open"></i></span><span class="ex-kpi-content"><span>Total Packages</span><strong><?= number_format($totalPackages); ?></strong><small><?= number_format($activePackages); ?> active package(s)</small></span></a>
            <a class="ex-kpi k-green" href="admin-bookings.php"><span class="ex-kpi-icon"><i class="fa-solid fa-calendar-check"></i></span><span class="ex-kpi-content"><span>Total Bookings</span><strong><?= number_format($totalBookings); ?></strong><small><?= number_format($pendingBookings); ?> awaiting confirmation</small></span></a>
            <a class="ex-kpi k-amber" href="admin-enquiries.php"><span class="ex-kpi-icon"><i class="fa-regular fa-message"></i></span><span class="ex-kpi-content"><span>New Enquiries</span><strong><?= number_format($newEnquiries); ?></strong><small><?= number_format($totalEnquiries); ?> total enquiries</small></span></a>
            <a class="ex-kpi k-violet" href="admin-payments.php"><span class="ex-kpi-icon"><i class="fa-solid fa-wallet"></i></span><span class="ex-kpi-content"><span>Total Revenue</span><strong><?= e($currencySymbol); ?><?= number_format($totalRevenue, 0); ?></strong><small>Verified successful payments</small></span></a>
            <a class="ex-kpi k-teal" href="admin-customers.php"><span class="ex-kpi-icon"><i class="fa-solid fa-users"></i></span><span class="ex-kpi-content"><span>Customers</span><strong><?= number_format($totalCustomers); ?></strong><small><?= number_format($activeCustomers); ?> active customers</small></span></a>
            <a class="ex-kpi k-cyan" href="admin-bookings.php"><span class="ex-kpi-icon"><i class="fa-solid fa-circle-check"></i></span><span class="ex-kpi-content"><span>Confirmed Bookings</span><strong><?= number_format($confirmedBookings); ?></strong><small>All recorded confirmations</small></span></a>
            <a class="ex-kpi k-red" href="admin-cancellations.php"><span class="ex-kpi-icon"><i class="fa-solid fa-circle-xmark"></i></span><span class="ex-kpi-content"><span>Pending Cancellations</span><strong><?= number_format($pendingCancellations); ?></strong><small>Requests for review</small></span></a>
        </section>

        <!-- =================================================
             TODAY ACTION CENTER — ONE-HAND OPERATIONS
        ================================================== -->

        <section class="today-center" id="today-action-center">
            <div class="today-center-head">
                <div>
                    <h2><i class="fa-solid fa-bolt"></i> Today Command Center</h2>
                    <p>One screen for the work that needs your action now. Open the customer, supplier, booking or finance task directly.</p>
                </div>
                <div class="ex-command-tools"><span class="ex-live-date"><i class="fa-regular fa-calendar"></i> <?= e(date('D, d M Y')); ?></span>
                    <span class="today-center-badge <?= $todayUrgentTotal > 0 ? 'hot' : ''; ?>">
                        <i class="fa-solid <?= $todayUrgentTotal > 0 ? 'fa-triangle-exclamation' : 'fa-circle-check'; ?>"></i>
                        <?= $todayUrgentTotal > 0 ? number_format($todayUrgentTotal) . ' ACTIONS' : 'ALL CLEAR'; ?>
                    </span>
                </div>
            </div>

            <div class="today-kpis">
                <a class="today-kpi <?= $todayNewLeadCount > 0 ? 'warn' : 'good'; ?>" href="#today-sales">
                    <span class="ex-command-icon"><i class="fa-solid fa-user-plus"></i></span><span class="tk-label">New Leads</span><span class="tk-value"><?= number_format($todayNewLeadCount); ?></span>
                    <span class="tk-sub">Unworked enquiries</span>
                </a>
                <a class="today-kpi <?= $todayOverdueFollowupCount > 0 ? 'danger' : ($todayFollowupCount > 0 ? 'warn' : 'good'); ?>" href="#today-followups">
                    <span class="ex-command-icon"><i class="fa-solid fa-clock"></i></span><span class="tk-label">Follow-ups Due</span><span class="tk-value"><?= number_format($todayFollowupCount); ?></span>
                    <span class="tk-sub"><?= number_format($todayOverdueFollowupCount); ?> overdue</span>
                </a>
                <a class="today-kpi <?= $todayPaymentApprovalCount > 0 ? 'danger' : 'good'; ?>" href="#today-payment-approvals">
                    <span class="ex-command-icon"><i class="fa-solid fa-credit-card"></i></span><span class="tk-label">Payments to Approve</span><span class="tk-value"><?= number_format($todayPaymentApprovalCount); ?></span>
                    <span class="tk-sub">Customer submissions waiting</span>
                </a>
                <a class="today-kpi <?= $todaySupplierProblemCount > 0 ? 'danger' : ($todaySupplierCount > 0 ? 'warn' : 'good'); ?>" href="#today-suppliers">
                    <span class="ex-command-icon"><i class="fa-solid fa-truck-fast"></i></span><span class="tk-label">Supplier Actions</span><span class="tk-value"><?= number_format($todaySupplierCount); ?></span>
                    <span class="tk-sub"><?= number_format($todaySupplierProblemCount); ?> problem response(s)</span>
                </a>
                <a class="today-kpi <?= ($todayDocumentCount+$todayReadinessCount) > 0 ? 'warn' : 'good'; ?>" href="#today-readiness">
                    <span class="ex-command-icon"><i class="fa-solid fa-plane-departure"></i></span><span class="tk-label">Travel Readiness</span><span class="tk-value"><?= number_format($todayDocumentCount+$todayReadinessCount); ?></span>
                    <span class="tk-sub">Documents + pre-departure checks</span>
                </a>
                <a class="today-kpi <?= $todayCustomerDueCount > 0 ? 'warn' : 'good'; ?>" href="#today-collections">
                    <span class="ex-command-icon"><i class="fa-solid fa-wallet"></i></span><span class="tk-label">Customer Due ≤ 3 Days</span><span class="tk-value"><?= e($currencySymbol); ?><?= number_format($todayCustomerDueAmount,0); ?></span>
                    <span class="tk-sub"><?= number_format($todayCustomerDueCount); ?> installment(s)</span>
                </a>
                <a class="today-kpi <?= $todaySupplierDueCount > 0 ? 'warn' : 'good'; ?>" href="#today-supplier-payments">
                    <span class="ex-command-icon"><i class="fa-solid fa-file-invoice"></i></span><span class="tk-label">Supplier Due ≤ 3 Days</span><span class="tk-value"><?= e($currencySymbol); ?><?= number_format($todaySupplierDueAmount,0); ?></span>
                    <span class="tk-sub"><?= number_format($todaySupplierDueCount); ?> invoice(s)</span>
                </a>
                <a class="today-kpi <?= $todayQuotationChangeCount > 0 ? 'danger' : ($todayQuotationCount > 0 ? 'warn' : 'good'); ?>" href="#today-quotations">
                    <span class="ex-command-icon"><i class="fa-solid fa-file-signature"></i></span><span class="tk-label">Quotation Decisions</span><span class="tk-value"><?= number_format($todayQuotationCount); ?></span>
                    <span class="tk-sub"><?= number_format($todayQuotationChangeCount); ?> change request(s)</span>
                </a>
                <a class="today-kpi <?= $ctDeparturesAtRisk > 0 ? 'danger' : 'good'; ?>" href="#ct-departure-risk">
                    <span class="ex-command-icon"><i class="fa-solid fa-triangle-exclamation"></i></span><span class="tk-label">Departures at Risk</span><span class="tk-value"><?= number_format($ctDeparturesAtRisk); ?></span>
                    <span class="tk-sub">Next 14 days</span>
                </a>
                <a class="today-kpi <?= (int)$dashboardNotificationSummary['critical'] > 0 ? 'danger' : ((int)$dashboardNotificationSummary['unread'] > 0 ? 'warn' : 'good'); ?>" href="<?= e(BASE_URL.'admin-notifications.php'); ?>">
                    <span class="ex-command-icon"><i class="fa-solid fa-bell"></i></span><span class="tk-label">System Alerts</span><span class="tk-value"><?= number_format((int)$dashboardNotificationSummary['unread']); ?></span>
                    <span class="tk-sub"><?= number_format((int)$dashboardNotificationSummary['critical']); ?> critical</span>
                </a>
            </div>

            <details class="ex-deep-queues" id="ex-deep-queues">
                <summary><i class="fa-solid fa-list-check"></i> Open detailed action queues <span>Customer follow-ups, supplier requests, payments and readiness <i class="fa-solid fa-chevron-down"></i></span></summary>
            <div class="today-tabs-grid">
                <section class="today-panel" id="today-sales">
                    <div class="today-panel-head"><div><strong>New Enquiries</strong><small>Contact these customers first</small></div><span class="today-count"><?= number_format($todayNewLeadCount); ?></span></div>
                    <div class="today-list">
                    <?php if (!$todayNewLeadRows): ?><div class="today-empty">No new enquiries waiting.</div><?php else: foreach ($todayNewLeadRows as $r):
                        $wa=dashboardCommandWaUrl((string)$r['mobile'],'Hello '.(string)$r['name'].', this is TRAVSCOPE regarding your travel enquiry'.(!empty($r['destination'])?' for '.$r['destination']:'').'.'); ?>
                        <div class="today-row"><div class="today-row-top"><div class="today-row-main"><strong><?= e((string)$r['name']); ?><?= !empty($r['destination'])?' · '.e((string)$r['destination']):''; ?></strong><small><?= e((string)$r['mobile']); ?><?= !empty($r['travel_date'])?' · Travel '.e(date('d M Y',strtotime($r['travel_date']))):''; ?> · Received <?= e(date('d M, h:i A',strtotime($r['created_at']))); ?></small></div><div class="today-row-right"><?= !empty($r['budget'])?e($currencySymbol).number_format((float)$r['budget'],0):'NEW'; ?></div></div>
                            <div class="today-actions"><a class="today-action primary" href="<?= e(BASE_URL.'admin-crm.php?lead='.(int)$r['id']); ?>"><i class="fa-solid fa-briefcase"></i> CRM</a><a class="today-action" href="tel:<?= e((string)$r['mobile']); ?>"><i class="fa-solid fa-phone"></i> Call</a><?php if($wa!==''): ?><a class="today-action green" target="_blank" rel="noopener" href="<?= e($wa); ?>"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a><?php endif; ?><?php if(!empty($r['email'])): ?><a class="today-action" href="mailto:<?= e((string)$r['email']); ?>"><i class="fa-regular fa-envelope"></i> Email</a><?php endif; ?></div></div>
                    <?php endforeach; endif; ?>
                    </div>
                </section>

                <section class="today-panel" id="today-followups">
                    <div class="today-panel-head"><div><strong>Follow-ups Due</strong><small>Overdue first, then today</small></div><span class="today-count <?= $todayOverdueFollowupCount>0?'red':''; ?>"><?= number_format($todayFollowupCount); ?></span></div>
                    <div class="today-list">
                    <?php if (!$todayFollowupRows): ?><div class="today-empty">No sales follow-up due today.</div><?php else: foreach($todayFollowupRows as $r): $over=((string)$r['next_action_date']<date('Y-m-d')); $wa=dashboardCommandWaUrl((string)$r['mobile'],'Hello '.(string)$r['customer_name'].', following up from TRAVSCOPE regarding your travel plan'.(!empty($r['destination'])?' for '.$r['destination']:'').'.'); ?>
                        <div class="today-row"><div class="today-row-top"><div class="today-row-main"><strong><?= e((string)$r['customer_name']); ?> · <?= e((string)$r['trip_code']); ?></strong><small><?= e((string)($r['next_action']?:'Follow up with customer')); ?><?= !empty($r['destination'])?' · '.e((string)$r['destination']):''; ?></small><span class="today-pill <?= $over?'red':'orange'; ?>"><?= $over?'OVERDUE '.e(date('d M',strtotime($r['next_action_date']))):'DUE TODAY'; ?></span></div><div class="today-row-right"><?= e(ucwords(str_replace('_',' ',(string)$r['stage']))); ?></div></div><div class="today-actions"><a class="today-action primary" href="<?= e(BASE_URL.'admin-crm.php?trip='.(int)$r['trip_id']); ?>"><i class="fa-solid fa-route"></i> Open Trip</a><a class="today-action" href="tel:<?= e((string)$r['mobile']); ?>"><i class="fa-solid fa-phone"></i> Call</a><?php if($wa!==''): ?><a class="today-action green" target="_blank" rel="noopener" href="<?= e($wa); ?>"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a><?php endif; ?></div></div>
                    <?php endforeach; endif; ?>
                    </div>
                </section>

                <section class="today-panel" id="today-quotations">
                    <div class="today-panel-head"><div><strong>Customer Quotation Queue</strong><small>Waiting, change requests and rework</small></div><span class="today-count <?= $todayQuotationChangeCount>0?'red':''; ?>"><?= number_format($todayQuotationCount); ?></span></div>
                    <div class="today-list">
                    <?php if(!$todayQuotationRows): ?><div class="today-empty">No sent quotation needs attention.</div><?php else: foreach($todayQuotationRows as $r): $decision=strtolower((string)($r['customer_decision']??'')); ?>
                        <div class="today-row"><div class="today-row-top"><div class="today-row-main"><strong><?= e((string)$r['customer_name']); ?> · Quote V<?= (int)$r['version_number']; ?></strong><small><?= e((string)$r['package_title']); ?><?= !empty($r['destination'])?' · '.e((string)$r['destination']):''; ?></small><?php if($decision==='change_requested'): ?><span class="today-pill red">CHANGE REQUESTED</span><?php elseif($decision==='rejected'): ?><span class="today-pill red">REJECTED</span><?php else: ?><span class="today-pill orange">AWAITING CUSTOMER</span><?php endif; ?></div><div class="today-row-right"><?= e($currencySymbol); ?><?= number_format((float)$r['final_price'],0); ?></div></div><?php if(!empty($r['customer_note'])): ?><small style="display:block;margin-top:5px;color:#67758a;font-size:8px;">Customer: <?= e((string)$r['customer_note']); ?></small><?php endif; ?><div class="today-actions"><a class="today-action primary" href="<?= e(BASE_URL.'admin-crm.php?lead='.(int)$r['lead_id']); ?>"><i class="fa-solid fa-file-signature"></i> Open Quote</a><?php $wa=dashboardCommandWaUrl((string)$r['mobile'],'Hello '.(string)$r['customer_name'].', following up on your TRAVSCOPE quotation V'.(int)$r['version_number'].'.'); if($wa!==''): ?><a class="today-action green" target="_blank" rel="noopener" href="<?= e($wa); ?>"><i class="fa-brands fa-whatsapp"></i> Follow-up</a><?php endif; ?></div></div>
                    <?php endforeach; endif; ?>
                    </div>
                </section>

                <section class="today-panel" id="today-payment-approvals">
                    <div class="today-panel-head"><div><strong>Payments Waiting Approval</strong><small>Approve to update booking + email receipt</small></div><span class="today-count <?= $todayPaymentApprovalCount>0?'red':''; ?>"><?= number_format($todayPaymentApprovalCount); ?></span></div>
                    <div class="today-list">
                    <?php if(!$todayPaymentApprovalRows): ?><div class="today-empty">No customer payment waiting for approval.</div><?php else: foreach($todayPaymentApprovalRows as $r): ?>
                        <div class="today-row"><div class="today-row-top"><div class="today-row-main"><strong><?= e((string)$r['customer_name']); ?> · <?= e((string)$r['booking_number']); ?></strong><small><?= e(ucwords(str_replace('_',' ',(string)($r['payment_method']?:'payment')))); ?><?= !empty($r['transaction_id'])?' · UTR/Ref '.e((string)$r['transaction_id']):''; ?> · Submitted <?= e(date('d M, h:i A',strtotime($r['created_at']))); ?></small><span class="today-pill red">APPROVAL REQUIRED</span></div><div class="today-row-right"><?= e($currencySymbol); ?><?= number_format((float)$r['amount'],0); ?></div></div><div class="today-actions"><a class="today-action primary" href="<?= e(BASE_URL.'admin-payment-details.php?id='.(int)$r['payment_id']); ?>"><i class="fa-solid fa-check-double"></i> Review & Approve</a><a class="today-action" href="<?= e(BASE_URL.'admin-booking-details.php?id='.(int)$r['booking_id'].'#customer-billing'); ?>"><i class="fa-solid fa-receipt"></i> Booking Billing</a></div></div>
                    <?php endforeach; endif; ?>
                    </div>
                </section>

                <section class="today-panel" id="today-suppliers">
                    <div class="today-panel-head"><div><strong>Supplier Actions</strong><small>Rate follow-ups + booking confirmation issues</small></div><span class="today-count <?= $todaySupplierProblemCount>0?'red':''; ?>"><?= number_format($todaySupplierCount); ?></span></div>
                    <div class="today-list">
                    <?php if(!$todaySupplierRows): ?><div class="today-empty">No supplier action currently due.</div><?php else: foreach($todaySupplierRows as $r): $problem=in_array(strtolower((string)$r['status']),['alternative_required','rejected'],true); $isOrder=(string)$r['action_type']==='booking_order'; $supplierWa=dashboardCommandWaUrl((string)($r['primary_mobile']??''),'Hello, this is TRAVSCOPE following up regarding '.(string)$r['request_code'].'.'); ?>
                        <div class="today-row"><div class="today-row-top"><div class="today-row-main"><strong><?= e((string)$r['company_name']); ?> · <?= e((string)$r['request_code']); ?></strong><small><?= e((string)$r['subject']); ?></small><span class="today-pill <?= $problem?'red':'orange'; ?>"><?= e(strtoupper(str_replace('_',' ',(string)$r['status']))); ?></span></div><div class="today-row-right"><?= $isOrder?'BOOKING':'RATE'; ?></div></div><div class="today-actions"><?php if($isOrder): ?><a class="today-action primary" href="<?= e(BASE_URL.'admin-booking-details.php?id='.(int)$r['booking_id'].'#supplier-procurement'); ?>"><i class="fa-solid fa-handshake"></i> Procurement</a><?php elseif(!empty($r['trip_id'])): ?><a class="today-action primary" href="<?= e(BASE_URL.'admin-crm.php?trip='.(int)$r['trip_id']); ?>"><i class="fa-solid fa-route"></i> CRM Supplier</a><?php else: ?><a class="today-action primary" href="<?= e(BASE_URL.'admin-crm.php?lead='.(int)$r['enquiry_id']); ?>"><i class="fa-solid fa-briefcase"></i> CRM</a><?php endif; ?><?php if($supplierWa!==''): ?><a class="today-action green" target="_blank" rel="noopener" href="<?= e($supplierWa); ?>"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a><?php endif; ?><?php if(!empty($r['primary_mobile'])): ?><a class="today-action" href="tel:<?= e((string)$r['primary_mobile']); ?>"><i class="fa-solid fa-phone"></i> Call</a><?php endif; ?></div></div>
                    <?php endforeach; endif; ?>
                    </div>
                </section>

                <section class="today-panel" id="today-collections">
                    <div class="today-panel-head"><div><strong>Customer Collections</strong><small>Installments overdue / due in next 3 days</small></div><span class="today-count"><?= number_format($todayCustomerDueCount); ?></span></div>
                    <div class="today-list">
                    <?php if(!$todayCustomerDueRows): ?><div class="today-empty">No scheduled customer collection due in 3 days.</div><?php else: foreach($todayCustomerDueRows as $r): $over=(string)$r['due_date']<date('Y-m-d'); $wa=dashboardCommandWaUrl((string)$r['customer_mobile'],'Hello '.(string)$r['customer_name'].', a friendly TRAVSCOPE payment reminder for '.(string)$r['title'].'. Amount due: '.$currencySymbol.number_format((float)$r['outstanding'],0).'.'); ?>
                        <div class="today-row"><div class="today-row-top"><div class="today-row-main"><strong><?= e((string)$r['customer_name']); ?> · <?= e((string)$r['booking_number']); ?></strong><small><?= e((string)$r['title']); ?> · Due <?= e(date('d M Y',strtotime($r['due_date']))); ?></small><span class="today-pill <?= $over?'red':'orange'; ?>"><?= $over?'OVERDUE':'DUE SOON'; ?></span></div><div class="today-row-right"><?= e($currencySymbol); ?><?= number_format((float)$r['outstanding'],0); ?></div></div><div class="today-actions"><a class="today-action primary" href="<?= e(BASE_URL.'admin-booking-details.php?id='.(int)$r['booking_id'].'#customer-billing'); ?>"><i class="fa-solid fa-wallet"></i> Billing</a><?php if($wa!==''): ?><a class="today-action green" target="_blank" rel="noopener" href="<?= e($wa); ?>"><i class="fa-brands fa-whatsapp"></i> Remind</a><?php endif; ?><a class="today-action" href="tel:<?= e((string)$r['customer_mobile']); ?>"><i class="fa-solid fa-phone"></i> Call</a></div></div>
                    <?php endforeach; endif; ?>
                    </div>
                </section>

                <section class="today-panel" id="today-supplier-payments">
                    <div class="today-panel-head"><div><strong>Supplier Payments</strong><small>Approved invoice balances due in 3 days</small></div><span class="today-count"><?= number_format($todaySupplierDueCount); ?></span></div>
                    <div class="today-list">
                    <?php if(!$todaySupplierDueRows): ?><div class="today-empty">No supplier invoice due in the next 3 days.</div><?php else: foreach($todaySupplierDueRows as $r): $over=(string)$r['due_date']<date('Y-m-d'); ?>
                        <div class="today-row"><div class="today-row-top"><div class="today-row-main"><strong><?= e((string)$r['company_name']); ?> · <?= e((string)$r['invoice_number']); ?></strong><small><?= e((string)$r['booking_number']); ?> · Due <?= e(date('d M Y',strtotime($r['due_date']))); ?></small><span class="today-pill <?= $over?'red':'orange'; ?>"><?= $over?'PAYMENT OVERDUE':'DUE SOON'; ?></span></div><div class="today-row-right"><?= e($currencySymbol); ?><?= number_format((float)$r['outstanding'],0); ?></div></div><div class="today-actions"><a class="today-action primary" href="<?= e(BASE_URL.'admin-booking-details.php?id='.(int)$r['booking_id'].'#finance-profitability'); ?>"><i class="fa-solid fa-money-bill-transfer"></i> Supplier Finance</a></div></div>
                    <?php endforeach; endif; ?>
                    </div>
                </section>

                <section class="today-panel" id="today-readiness">
                    <div class="today-panel-head"><div><strong>Documents & Travel Readiness</strong><small>Upcoming bookings that are not ready</small></div><span class="today-count"><?= number_format($todayDocumentCount+$todayReadinessCount); ?></span></div>
                    <div class="today-list">
                    <?php if(!$todayDocumentRows && !$todayReadinessRows): ?><div class="today-empty">Upcoming bookings have no document/readiness action.</div><?php else: foreach($todayDocumentRows as $r): $wa=dashboardCommandWaUrl((string)$r['customer_mobile'],'Hello '.(string)$r['customer_name'].', TRAVSCOPE needs your pending travel document(s) for booking '.(string)$r['booking_number'].'.'); ?>
                        <div class="today-row"><div class="today-row-top"><div class="today-row-main"><strong><?= e((string)$r['customer_name']); ?> · <?= e((string)$r['booking_number']); ?></strong><small><?= (int)$r['missing_count']; ?> missing/rejected · <?= (int)$r['verify_count']; ?> waiting verification<?= !empty($r['travel_date'])?' · Travel '.e(date('d M',strtotime($r['travel_date']))):''; ?></small><span class="today-pill red">DOCUMENTS</span></div></div><div class="today-actions"><a class="today-action primary" href="<?= e(BASE_URL.'admin-booking-details.php?id='.(int)$r['booking_id'].'#traveller-document-center'); ?>"><i class="fa-solid fa-passport"></i> Documents</a><?php if($wa!==''): ?><a class="today-action green" target="_blank" rel="noopener" href="<?= e($wa); ?>"><i class="fa-brands fa-whatsapp"></i> Ask Customer</a><?php endif; ?></div></div>
                    <?php endforeach; foreach($todayReadinessRows as $r): ?>
                        <div class="today-row"><div class="today-row-top"><div class="today-row-main"><strong><?= e((string)$r['customer_name']); ?> · <?= e((string)$r['booking_number']); ?></strong><small><?= (int)$r['incomplete_count']; ?> required operation check(s) incomplete · Departure <?= e(date('d M Y',strtotime($r['travel_date']))); ?></small><span class="today-pill orange">PRE-DEPARTURE</span></div><div class="today-row-right"><?= max(0,(int)floor((strtotime($r['travel_date'])-strtotime(date('Y-m-d')))/86400)); ?>D</div></div><div class="today-actions"><a class="today-action primary" href="<?= e(BASE_URL.'admin-booking-details.php?id='.(int)$r['booking_id'].'#operations-readiness'); ?>"><i class="fa-solid fa-list-check"></i> Readiness</a><a class="today-action" href="<?= e(BASE_URL.'admin-booking-details.php?id='.(int)$r['booking_id'].'#supplier-procurement'); ?>"><i class="fa-solid fa-handshake"></i> Suppliers</a></div></div>
                    <?php endforeach; endif; ?>
                    </div>
                </section>
            </div>

            <div class="today-foot"><span><i class="fa-solid fa-shield-halved"></i> No automatic customer/supplier commitment is made from this dashboard; you stay in control.</span><a href="#management-control-tower">View Management Control Tower ↓</a></div>
            </details>
        </section>


        <!-- The primary executive layout approved for V24.41. -->
        <section class="ex-ops-row" aria-label="Sales and booking snapshots">
            <div class="ex-board ex-leads">
                <header><h2>Recent Enquiries</h2><a href="admin-enquiries.php">View All <i class="fa-solid fa-arrow-right"></i></a></header>
                <div class="ex-board-list">
                <?php if (!$recentEnquiries): ?><div class="ex-empty"><i class="fa-regular fa-message"></i><span>No enquiries recorded yet.</span></div>
                <?php else: foreach(array_slice($recentEnquiries, 0, 5) as $lead):
                    $leadName = trim((string)($lead['name'] ?? 'Customer'));
                    $initials = strtoupper(substr($leadName,0,1)); ?>
                    <a class="ex-lead" href="<?= e(BASE_URL . 'admin-enquiry-details.php?id=' . (int)$lead['id']); ?>">
                        <span class="ex-avatar"><?= e($initials); ?></span><span class="ex-lead-text"><strong><?= e($leadName); ?></strong><small><?= e((string)($lead['destination'] ?: 'Destination not specified')); ?> · <?= e(date('d M Y',strtotime((string)$lead['created_at']))); ?></small></span>
                        <span class="ex-state state-<?= e(preg_replace('/[^a-z_-]/','',strtolower((string)($lead['status']??'new')))); ?>"><?= e(ucwords(str_replace('_',' ',(string)($lead['status']??'New')))); ?></span><i class="fa-solid fa-chevron-right ex-row-arrow"></i>
                    </a>
                <?php endforeach; endif; ?>
                </div>
            </div>
            <div class="ex-board ex-bookings">
                <header><h2>Recent Bookings</h2><a href="admin-bookings.php">View All <i class="fa-solid fa-arrow-right"></i></a></header>
                <div class="ex-booking-scroll"><table class="ex-booking-table"><thead><tr><th>Booking ID</th><th>Customer</th><th>Package</th><th>Amount</th><th>Status</th></tr></thead><tbody>
                    <?php if (!$recentBookings): ?><tr><td colspan="5" class="ex-empty-cell">No recent bookings.</td></tr>
                    <?php else: foreach(array_slice($recentBookings,0,5) as $bk): ?>
                    <tr><td><a href="<?= e(BASE_URL.'admin-booking-details.php?id='.(int)$bk['id']); ?>"><?= e((string)$bk['booking_number']); ?></a></td><td><?= e((string)$bk['customer_name']); ?></td><td title="<?= e((string)($bk['package_title']?:'Custom Trip')); ?>"><?= e((string)($bk['package_title']?:'Custom Trip')); ?></td><td class="ex-price"><?= e($currencySymbol); ?><?= number_format((float)$bk['total_amount'],0); ?></td><td><span class="ex-state state-<?= e(preg_replace('/[^a-z_-]/','',strtolower((string)$bk['booking_status']))); ?>"><?= e(ucfirst((string)$bk['booking_status'])); ?></span></td></tr>
                    <?php endforeach; endif; ?>
                </tbody></table></div>
            </div>
            <div class="ex-board ex-trip-actions">
                <header><h2>Trip Action Queue</h2><a href="admin-crm.php">View All <i class="fa-solid fa-arrow-right"></i></a></header>
                <div class="ex-board-list">
                <?php if (!$ctTripActionRows): ?><div class="ex-empty"><i class="fa-solid fa-route"></i><span>No active trip actions.</span></div>
                <?php else: foreach(array_slice($ctTripActionRows,0,5) as $trip):
                    $tripDue = (string)($trip['next_action_date']??'');
                    $tripOverdue = $tripDue!=='' && $tripDue<date('Y-m-d'); ?>
                    <a class="ex-trip" href="<?= e(BASE_URL.'admin-crm.php?lead='.(int)$trip['enquiry_id'].'&trip='.(int)$trip['id']); ?>"><span class="ex-trip-icon"><i class="fa-solid fa-plane"></i></span><span class="ex-trip-text"><strong><?= e((string)($trip['trip_code'] ?: 'Trip #'.$trip['id'])); ?></strong><small><?= e((string)($trip['customer_name']?:'Customer')); ?> · <?= e((string)($trip['destination']?:'Not specified')); ?></small></span><span class="ex-due <?= $tripOverdue?'overdue':''; ?>"><?= $tripDue === '' ? 'No due date' : ($tripOverdue ? 'Overdue · ' : 'Due · ').e(date('d M',strtotime($tripDue))); ?></span><i class="fa-solid fa-chevron-right ex-row-arrow"></i></a>
                <?php endforeach; endif; ?>
                </div>
            </div>
        </section>
        <section class="ex-finance-row" aria-label="Finance and quick tools">
            <div class="ex-board ex-revenue">
                <header><h2>Revenue Overview</h2><a href="admin-business-analytics.php">Analytics <i class="fa-solid fa-arrow-right"></i></a></header>
                <p class="ex-mini-explainer">Monthly verified successful payments · Last 7 months</p>
                <div class="ex-chart" role="img" aria-label="Seven month revenue trend, with exact amounts shown below each month">
                    <?php foreach($executiveRevenue as $rv): $height = max(3.0, min(100.0, 100*(float)$rv['amount']/$executiveRevenueMax)); ?>
                        <div class="ex-chart-month"><span class="ex-chart-amount" title="<?= e($currencySymbol); ?><?= number_format((float)$rv['amount'],2); ?>"><?= e($currencySymbol); ?><?= number_format((float)$rv['amount'],0); ?></span><div class="ex-chart-track"><span style="height:<?= number_format($height,2,'.',''); ?>%"></span></div><small><?= e($rv['label']); ?></small></div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="ex-board ex-receivables">
                <header><h2>Customer Receivables</h2><a href="admin-bookings.php">View All <i class="fa-solid fa-arrow-right"></i></a></header>
                <div class="ex-finance-total"><span class="ex-finance-icon"><i class="fa-solid fa-wallet"></i></span><span><strong><?= e($currencySymbol); ?><?= number_format($ctCustomerReceivable,0); ?></strong><small><?= number_format($ctCustomerReceivableCount); ?> booking(s) with unpaid balance</small></span></div>
                <?php if (!$ctReceivableRows): ?><div class="ex-empty-small">No open customer balance.</div><?php else: foreach(array_slice($ctReceivableRows,0,3) as $r): ?><a class="ex-money-row" href="<?= e(BASE_URL.'admin-booking-details.php?id='.(int)$r['id']); ?>"><span><strong><?= e((string)$r['booking_number']); ?></strong><small><?= e((string)$r['customer_name']); ?></small></span><b><?= e($currencySymbol); ?><?= number_format((float)$r['outstanding'],0); ?> <em>DUE</em></b></a><?php endforeach; endif; ?>
            </div>
            <div class="ex-board ex-payables">
                <header><h2>Supplier Payables</h2><a href="admin-bookings.php">View All <i class="fa-solid fa-arrow-right"></i></a></header>
                <div class="ex-finance-total"><span class="ex-finance-icon"><i class="fa-solid fa-file-invoice-dollar"></i></span><span><strong><?= e($currencySymbol); ?><?= number_format($ctSupplierPayable,0); ?></strong><small>Approved supplier payable outstanding</small></span></div>
                <?php if (!$ctPayableRows): ?><div class="ex-empty-small">No approved supplier payable balance.</div><?php else: foreach(array_slice($ctPayableRows,0,3) as $r): ?><a class="ex-money-row" href="<?= e(BASE_URL.'admin-booking-details.php?id='.(int)$r['booking_id'].'#finance-profitability'); ?>"><span><strong><?= e((string)($r['invoice_number']?:'Invoice #'.$r['id'])); ?></strong><small><?= e((string)$r['company_name']); ?></small></span><b><?= e($currencySymbol); ?><?= number_format((float)$r['outstanding'],0); ?></b></a><?php endforeach; endif; ?>
            </div>
            <div class="ex-board ex-quick">
                <header><h2>Quick Actions</h2></header>
                <div class="ex-quick-grid">
                    <a href="admin-packages.php?action=add"><i class="fa-solid fa-plus"></i><span>Add Package</span></a>
                    <a href="admin-destinations.php?action=add"><i class="fa-solid fa-location-dot"></i><span>Add Destination</span></a>
                    <a href="admin-bookings.php"><i class="fa-solid fa-calendar-check"></i><span>Bookings</span></a>
                    <a href="admin-web-gallery.php"><i class="fa-regular fa-images"></i><span>Web Gallery</span></a>
                    <a href="admin-coupons.php"><i class="fa-solid fa-ticket"></i><span>Coupons</span></a>
                    <a href="admin-enquiries.php"><i class="fa-solid fa-headset"></i><span>Enquiries</span></a>
                    <a href="admin-blogs.php?action=add"><i class="fa-solid fa-pen-nib"></i><span>Travel Story</span></a>
                    <a href="admin-settings.php"><i class="fa-solid fa-gear"></i><span>Site Settings</span></a>
                </div>
            </div>
        </section>
        <details class="ex-deep-reports" id="ex-deep-reports"><summary><i class="fa-solid fa-layer-group"></i> Detailed Operations & Reports <span>Full Management Control Tower, detailed enquiry lists and bookings <i class="fa-solid fa-chevron-down"></i></span></summary>

        <!-- =================================================
             MANAGEMENT CONTROL TOWER
        ================================================== -->

        <section class="control-tower" id="management-control-tower">

            <div class="control-tower-head">

                <div class="control-tower-title">
                    <h2>Management Control Tower</h2>
                    <p>What needs attention now across Sales, Operations and Finance.</p>
                </div>

                <div style="display:flex;gap:7px;align-items:center;flex-wrap:wrap;">
                    <a
                        href="<?= e(BASE_URL . 'admin-notifications.php'); ?>"
                        class="control-tower-live"
                        style="text-decoration:none;background:<?= (int)$dashboardNotificationSummary['critical'] > 0 ? '#fef2f2' : ((int)$dashboardNotificationSummary['unread'] > 0 ? '#fff7ed' : '#ecfdf5'); ?>;color:<?= (int)$dashboardNotificationSummary['critical'] > 0 ? '#b91c1c' : ((int)$dashboardNotificationSummary['unread'] > 0 ? '#c2410c' : '#047857'); ?>;border-color:<?= (int)$dashboardNotificationSummary['critical'] > 0 ? '#fecaca' : ((int)$dashboardNotificationSummary['unread'] > 0 ? '#fed7aa' : '#a7f3d0'); ?>;"
                    >
                        <i class="fa-regular fa-bell"></i>
                        ALERTS <?= (int)$dashboardNotificationSummary['unread']; ?>
                    </a>

                    <a
                        href="<?= e(BASE_URL . 'admin-business-analytics.php'); ?>"
                        class="control-tower-live"
                        style="text-decoration:none;background:#eff6ff;color:#1d4ed8;border-color:#bfdbfe;"
                    >
                        <i class="fa-solid fa-chart-line"></i>
                        ANALYTICS
                    </a>

                    <a
                        href="<?= e(BASE_URL . 'admin-mis-reports.php'); ?>"
                        class="control-tower-live"
                        style="text-decoration:none;background:#ecfdf5;color:#047857;border-color:#a7f3d0;"
                    >
                        <i class="fa-solid fa-file-lines"></i>
                        MIS
                    </a>

                    <?php if (in_array($dashboardAccessProfile, ['admin','super_admin'], true)): ?>
                        <a
                            href="<?= e(BASE_URL . 'admin-system-health.php'); ?>"
                            class="control-tower-live"
                            style="text-decoration:none;background:#f8fafc;color:#475569;border-color:#cbd5e1;"
                        >
                            <i class="fa-solid fa-heart-pulse"></i>
                            HEALTH
                        </a>

                        <a
                            href="<?= e(BASE_URL . 'admin-master-data.php'); ?>"
                            class="control-tower-live"
                            style="text-decoration:none;background:#f5f3ff;color:#6d28d9;border-color:#ddd6fe;"
                        >
                            <i class="fa-solid fa-object-group"></i>
                            MASTER DATA
                        </a>

                        <a
                            href="<?= e(BASE_URL . 'admin-data-import.php'); ?>"
                            class="control-tower-live"
                            style="text-decoration:none;background:#ecfeff;color:#0f766e;border-color:#a5f3fc;"
                        >
                            <i class="fa-solid fa-file-import"></i>
                            DATA IMPORT
                        </a>

                        <a
                            href="<?= e(BASE_URL . 'admin-operational-settings.php'); ?>"
                            class="control-tower-live"
                            style="text-decoration:none;background:#f0fdf4;color:#166534;border-color:#bbf7d0;"
                        >
                            <i class="fa-solid fa-sliders"></i>
                            OPS SETTINGS
                        </a>

                        <a
                            href="<?= e(BASE_URL . 'admin-deployment-safety.php'); ?>"
                            class="control-tower-live"
                            style="text-decoration:none;background:#fff7ed;color:#9a3412;border-color:#fed7aa;"
                        >
                            <i class="fa-solid fa-shield-halved"></i>
                            DEPLOYMENT
                        </a>

                        <a
                            href="<?= e(BASE_URL . 'admin-system-jobs.php'); ?>"
                            class="control-tower-live"
                            style="text-decoration:none;background:#eef2ff;color:#4338ca;border-color:#c7d2fe;"
                        >
                            <i class="fa-solid fa-gears"></i>
                            JOBS
                        </a>
                    <?php endif; ?>

                    <span class="control-tower-live">
                        <i class="fa-solid fa-signal"></i>
                        LIVE DATABASE
                    </span>
                </div>

            </div>


            <div class="ct-kpis">

                <a class="ct-kpi" href="<?= e(BASE_URL . 'admin-crm.php'); ?>">
                    <div class="ct-kpi-top">
                        <span class="ct-kpi-label">Active Trips</span>
                        <span class="ct-kpi-icon"><i class="fa-solid fa-route"></i></span>
                    </div>
                    <span class="ct-kpi-value"><?= number_format($ctActiveTrips); ?></span>
                    <span class="ct-kpi-sub">
                        <?= number_format($ctOverdueActions); ?>
                        overdue next action<?= $ctOverdueActions === 1 ? '' : 's'; ?>
                    </span>
                </a>


                <a class="ct-kpi <?= $ctPendingSupplierServices > 0 ? 'orange' : 'green'; ?>" href="<?= e(BASE_URL . 'admin-bookings.php'); ?>">
                    <div class="ct-kpi-top">
                        <span class="ct-kpi-label">Supplier Confirmations</span>
                        <span class="ct-kpi-icon"><i class="fa-solid fa-handshake"></i></span>
                    </div>
                    <span class="ct-kpi-value"><?= number_format($ctPendingSupplierServices); ?></span>
                    <span class="ct-kpi-sub">
                        Pending services
                        <?php if ($ctSupplierProblemServices > 0): ?>
                            · <?= number_format($ctSupplierProblemServices); ?> problem<?= $ctSupplierProblemServices === 1 ? '' : 's'; ?>
                        <?php endif; ?>
                    </span>
                </a>


                <a class="ct-kpi <?= $ctDeparturesAtRisk > 0 ? 'red' : 'green'; ?>" href="#ct-departure-risk">
                    <div class="ct-kpi-top">
                        <span class="ct-kpi-label">Departures at Risk</span>
                        <span class="ct-kpi-icon"><i class="fa-solid fa-triangle-exclamation"></i></span>
                    </div>
                    <span class="ct-kpi-value"><?= number_format($ctDeparturesAtRisk); ?></span>
                    <span class="ct-kpi-sub">
                        <?= number_format($ctUpcomingDepartures); ?>
                        departure<?= $ctUpcomingDepartures === 1 ? '' : 's'; ?> in next 14 days
                    </span>
                </a>


                <a class="ct-kpi orange" href="#ct-customer-receivable">
                    <div class="ct-kpi-top">
                        <span class="ct-kpi-label">Customer Receivable</span>
                        <span class="ct-kpi-icon"><i class="fa-solid fa-wallet"></i></span>
                    </div>
                    <span class="ct-kpi-value">
                        <?= e($currencySymbol); ?><?= number_format($ctCustomerReceivable, 0); ?>
                    </span>
                    <span class="ct-kpi-sub">
                        <?= number_format($ctCustomerReceivableCount); ?>
                        booking<?= $ctCustomerReceivableCount === 1 ? '' : 's'; ?> with balance
                    </span>
                </a>


                <a class="ct-kpi purple" href="#ct-supplier-payable">
                    <div class="ct-kpi-top">
                        <span class="ct-kpi-label">Supplier Payable</span>
                        <span class="ct-kpi-icon"><i class="fa-solid fa-money-bill-transfer"></i></span>
                    </div>
                    <span class="ct-kpi-value">
                        <?= e($currencySymbol); ?><?= number_format($ctSupplierPayable, 0); ?>
                    </span>
                    <span class="ct-kpi-sub">
                        <?= number_format($ctSupplierPayableCount); ?>
                        approved invoice<?= $ctSupplierPayableCount === 1 ? '' : 's'; ?> outstanding
                    </span>
                </a>


                <a class="ct-kpi <?= $ctMarginAlertCount > 0 ? 'red' : 'green'; ?>" href="#ct-margin-alerts">
                    <div class="ct-kpi-top">
                        <span class="ct-kpi-label">Margin Alerts</span>
                        <span class="ct-kpi-icon"><i class="fa-solid fa-chart-line"></i></span>
                    </div>
                    <span class="ct-kpi-value"><?= number_format($ctMarginAlertCount); ?></span>
                    <span class="ct-kpi-sub">
                        <?php if ($ctMarginAlertCount > 0): ?>
                            <?= e($currencySymbol); ?><?= number_format($ctMarginRiskAmount, 0); ?> below expected margin
                        <?php else: ?>
                            No negative live variance detected
                        <?php endif; ?>
                    </span>
                </a>


                <div class="ct-kpi green">
                    <div class="ct-kpi-top">
                        <span class="ct-kpi-label">Closed Actual Profit</span>
                        <span class="ct-kpi-icon"><i class="fa-solid fa-circle-check"></i></span>
                    </div>
                    <span class="ct-kpi-value">
                        <?= e($currencySymbol); ?><?= number_format($ctClosedActualMargin, 0); ?>
                    </span>
                    <span class="ct-kpi-sub">
                        <?= number_format($ctClosedProfitabilityCount); ?>
                        financially closed booking<?= $ctClosedProfitabilityCount === 1 ? '' : 's'; ?>
                    </span>
                </div>


                <a class="ct-kpi <?= $ctOverdueActions > 0 ? 'red' : 'green'; ?>" href="#ct-trip-actions">
                    <div class="ct-kpi-top">
                        <span class="ct-kpi-label">Overdue Actions</span>
                        <span class="ct-kpi-icon"><i class="fa-solid fa-clock"></i></span>
                    </div>
                    <span class="ct-kpi-value"><?= number_format($ctOverdueActions); ?></span>
                    <span class="ct-kpi-sub">Active Trip follow-up<?= $ctOverdueActions === 1 ? '' : 's'; ?> past due</span>
                </a>

            </div>


            <div class="ct-grid">

                <section class="ct-panel" id="ct-trip-actions">
                    <div class="ct-panel-head">
                        <div>
                            <strong>Trip Action Queue</strong>
                            <small>Overdue and upcoming next actions first</small>
                        </div>
                        <a href="<?= e(BASE_URL . 'admin-crm.php'); ?>">Open CRM</a>
                    </div>

                    <div class="ct-list">
                        <?php if (!$ctTripActionRows): ?>
                            <div class="ct-empty">No active Trip actions found.</div>
                        <?php else: ?>
                            <?php foreach ($ctTripActionRows as $row): ?>
                                <?php
                                $isOverdue =
                                    !empty($row['next_action_date'])
                                    && $row['next_action_date'] < date('Y-m-d');
                                ?>

                                <a
                                    class="ct-row"
                                    href="<?= e(
                                        BASE_URL
                                        . 'admin-crm.php?lead='
                                        . (int)$row['enquiry_id']
                                        . '&trip='
                                        . (int)$row['id']
                                    ); ?>"
                                >
                                    <div>
                                        <strong>
                                            <?= e((string)($row['trip_code'] ?: ('Trip #' . $row['id']))); ?>
                                            · <?= e((string)($row['customer_name'] ?: 'Customer')); ?>
                                        </strong>

                                        <small>
                                            <?= e((string)($row['next_action'] ?: 'Next action not set')); ?>
                                            <?php if (!empty($row['destination'])): ?>
                                                · <?= e((string)$row['destination']); ?>
                                            <?php endif; ?>
                                        </small>

                                        <?php if (!empty($row['next_action_date'])): ?>
                                            <span class="ct-tag <?= $isOverdue ? 'overdue' : ''; ?>">
                                                <?= $isOverdue ? 'OVERDUE' : 'DUE'; ?>
                                                · <?= e(date('d M Y', strtotime($row['next_action_date']))); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="ct-tag warn">NO DUE DATE</span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="ct-row-value">
                                        <?= e(ucwords(str_replace('_', ' ', (string)($row['stage'] ?: 'active')))); ?>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </section>


                <section class="ct-panel" id="ct-departure-risk">
                    <div class="ct-panel-head">
                        <div>
                            <strong>Departures at Risk</strong>
                            <small>Next 14 days · finance / supplier / voucher readiness</small>
                        </div>
                        <a href="<?= e(BASE_URL . 'admin-bookings.php'); ?>">All Bookings</a>
                    </div>

                    <div class="ct-list">
                        <?php if (!$ctDepartureRows): ?>
                            <div class="ct-empty">No upcoming departure risk detected.</div>
                        <?php else: ?>
                            <?php foreach ($ctDepartureRows as $row): ?>
                                <a
                                    class="ct-row"
                                    href="<?= e(
                                        BASE_URL
                                        . 'admin-booking-details.php?id='
                                        . (int)$row['id']
                                        . '#operations-readiness'
                                    ); ?>"
                                >
                                    <div>
                                        <strong>
                                            <?= e((string)$row['booking_number']); ?>
                                            · <?= e((string)$row['customer_name']); ?>
                                        </strong>

                                        <small>
                                            Departure <?= e(date('d M Y', strtotime($row['travel_date']))); ?>
                                        </small>

                                        <div class="ct-risk-reasons">
                                            <?php foreach ((array)$row['risk_reasons'] as $reason): ?>
                                                <span><?= e((string)$reason); ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>

                                    <div class="ct-row-value">
                                        <?php
                                        $daysAway =
                                            max(
                                                0,
                                                (int)floor(
                                                    (
                                                        strtotime($row['travel_date'])
                                                        - strtotime(date('Y-m-d'))
                                                    )
                                                    / 86400
                                                )
                                            );
                                        ?>
                                        <?= $daysAway; ?> day<?= $daysAway === 1 ? '' : 's'; ?>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </section>


                <section class="ct-panel" id="ct-customer-receivable">
                    <div class="ct-panel-head">
                        <div>
                            <strong>Customer Receivables</strong>
                            <small>Bookings with customer balance outstanding</small>
                        </div>
                        <a href="<?= e(BASE_URL . 'admin-bookings.php'); ?>">Bookings</a>
                    </div>

                    <div class="ct-list">
                        <?php if (!$ctReceivableRows): ?>
                            <div class="ct-empty">No customer receivable balance.</div>
                        <?php else: ?>
                            <?php foreach ($ctReceivableRows as $row): ?>
                                <a
                                    class="ct-row"
                                    href="<?= e(
                                        BASE_URL
                                        . 'admin-booking-details.php?id='
                                        . (int)$row['id']
                                    ); ?>"
                                >
                                    <div>
                                        <strong>
                                            <?= e((string)$row['booking_number']); ?>
                                            · <?= e((string)$row['customer_name']); ?>
                                        </strong>

                                        <small>
                                            Paid <?= e($currencySymbol); ?><?= number_format((float)$row['paid_amount'], 0); ?>
                                            of <?= e($currencySymbol); ?><?= number_format((float)$row['total_amount'], 0); ?>
                                            <?php if (!empty($row['travel_date'])): ?>
                                                · Travel <?= e(date('d M Y', strtotime($row['travel_date']))); ?>
                                            <?php endif; ?>
                                        </small>
                                    </div>

                                    <div class="ct-row-value">
                                        <?= e($currencySymbol); ?><?= number_format((float)$row['outstanding'], 0); ?>
                                        <span class="ct-tag warn">DUE</span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </section>


                <section class="ct-panel" id="ct-supplier-payable">
                    <div class="ct-panel-head">
                        <div>
                            <strong>Supplier Payables</strong>
                            <small>Approved supplier invoice balances</small>
                        </div>
                        <a href="<?= e(BASE_URL . 'admin-bookings.php'); ?>">Booking Finance</a>
                    </div>

                    <div class="ct-list">
                        <?php if (!$ctPayableRows): ?>
                            <div class="ct-empty">No approved supplier payable balance.</div>
                        <?php else: ?>
                            <?php foreach ($ctPayableRows as $row): ?>
                                <?php
                                $payableOverdue =
                                    !empty($row['due_date'])
                                    && $row['due_date'] < date('Y-m-d');
                                ?>

                                <a
                                    class="ct-row"
                                    href="<?= e(
                                        BASE_URL
                                        . 'admin-booking-details.php?id='
                                        . (int)$row['booking_id']
                                        . '#finance-profitability'
                                    ); ?>"
                                >
                                    <div>
                                        <strong>
                                            <?= e((string)$row['company_name']); ?>
                                            · <?= e((string)$row['invoice_number']); ?>
                                        </strong>

                                        <small>
                                            Invoice <?= e(date('d M Y', strtotime($row['invoice_date']))); ?>
                                            <?php if (!empty($row['due_date'])): ?>
                                                · Due <?= e(date('d M Y', strtotime($row['due_date']))); ?>
                                            <?php endif; ?>
                                        </small>

                                        <?php if ($payableOverdue): ?>
                                            <span class="ct-tag overdue">PAYMENT OVERDUE</span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="ct-row-value">
                                        <?= e($currencySymbol); ?><?= number_format((float)$row['outstanding'], 0); ?>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </section>


                <section class="ct-panel" id="ct-margin-alerts">
                    <div class="ct-panel-head">
                        <div>
                            <strong>Margin Variance Alerts</strong>
                            <small>Live actual cost has moved below expected margin</small>
                        </div>
                    </div>

                    <div class="ct-list">
                        <?php if (!$ctMarginRows): ?>
                            <div class="ct-empty">No negative live margin variance detected.</div>
                        <?php else: ?>
                            <?php foreach ($ctMarginRows as $row): ?>
                                <a
                                    class="ct-row"
                                    href="<?= e(
                                        BASE_URL
                                        . 'admin-booking-details.php?id='
                                        . (int)$row['booking_id']
                                        . '#finance-profitability'
                                    ); ?>"
                                >
                                    <div>
                                        <strong>
                                            <?= e((string)$row['booking_number']); ?>
                                            · <?= e((string)$row['customer_name']); ?>
                                        </strong>

                                        <small>
                                            Expected Margin <?= e($currencySymbol); ?><?= number_format((float)$row['expected_margin_amount'], 0); ?>
                                            · Current Actual Margin <?= e($currencySymbol); ?><?= number_format((float)$row['actual_margin'], 0); ?>
                                        </small>
                                    </div>

                                    <div class="ct-row-value" style="color:#b91c1c;">
                                        <?= e($currencySymbol); ?><?= number_format((float)$row['margin_variance'], 0); ?>
                                        <span class="ct-tag risk">VARIANCE</span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </section>


                <section class="ct-panel">
                    <div class="ct-panel-head">
                        <div>
                            <strong>Control Tower Summary</strong>
                            <small>Management snapshot from the connected workflow</small>
                        </div>
                    </div>

                    <div class="ct-list">
                        <div class="ct-row">
                            <div>
                                <strong>Sales Follow-up</strong>
                                <small>Active Trips requiring next action</small>
                            </div>
                            <div class="ct-row-value"><?= number_format($ctActiveTrips); ?></div>
                        </div>

                        <div class="ct-row">
                            <div>
                                <strong>Operations Procurement</strong>
                                <small>Supplier-backed services not yet confirmed</small>
                            </div>
                            <div class="ct-row-value"><?= number_format($ctPendingSupplierServices); ?></div>
                        </div>

                        <div class="ct-row">
                            <div>
                                <strong>Customer Collections</strong>
                                <small>Total open customer balance</small>
                            </div>
                            <div class="ct-row-value">
                                <?= e($currencySymbol); ?><?= number_format($ctCustomerReceivable, 0); ?>
                            </div>
                        </div>

                        <div class="ct-row">
                            <div>
                                <strong>Supplier Payments</strong>
                                <small>Approved supplier payable outstanding</small>
                            </div>
                            <div class="ct-row-value">
                                <?= e($currencySymbol); ?><?= number_format($ctSupplierPayable, 0); ?>
                            </div>
                        </div>

                        <div class="ct-row">
                            <div>
                                <strong>Financially Closed Profit</strong>
                                <small>Actual margin frozen at financial closure</small>
                            </div>
                            <div class="ct-row-value">
                                <?= e($currencySymbol); ?><?= number_format($ctClosedActualMargin, 0); ?>
                            </div>
                        </div>
                    </div>
                </section>

            </div>

        </section>


        <!-- =================================================
             ENQUIRIES + QUICK ACTIONS
        ================================================== -->

        <div class="dashboard-grid">


            <!-- RECENT ENQUIRIES -->

            <section class="card">


                <div class="card-header">

                    <h3>

                        Recent Enquiries

                    </h3>


                    <a href="admin-enquiries.php">

                        View All

                    </a>

                </div>


                <div class="table-wrap">


                    <table>


                        <thead>

                        <tr>

                            <th>Customer</th>

                            <th>Destination</th>

                            <th>Travel Date</th>

                            <th>Status</th>

                            <th>Received</th>

                        </tr>

                        </thead>


                        <tbody>


                        <?php if (!$recentEnquiries): ?>


                            <tr>

                                <td colspan="5">

                                    No travel enquiries received yet.

                                </td>

                            </tr>


                        <?php else: ?>


                            <?php foreach ($recentEnquiries as $item): ?>


                                <tr>


                                    <td>

                                        <div class="customer-name">

                                            <?= e($item['name']); ?>

                                        </div>


                                        <div class="table-small">

                                            <?= e($item['mobile']); ?>

                                        </div>

                                    </td>


                                    <td>

                                        <?= e(
                                            $item['destination']
                                            ?: 'Not specified'
                                        ); ?>

                                    </td>


                                    <td>

                                        <?php if ($item['travel_date']): ?>

                                            <?= date(
                                                'd M Y',
                                                strtotime(
                                                    $item['travel_date']
                                                )
                                            ); ?>

                                        <?php else: ?>

                                            —

                                        <?php endif; ?>

                                    </td>


                                    <td>

                                        <span
                                            class="status status-<?= e($item['status']); ?>"
                                        >

                                            <?= e(
                                                ucwords(
                                                    str_replace(
                                                        '_',
                                                        ' ',
                                                        $item['status']
                                                    )
                                                )
                                            ); ?>

                                        </span>

                                    </td>


                                    <td>

                                        <?= date(
                                            'd M Y',
                                            strtotime(
                                                $item['created_at']
                                            )
                                        ); ?>

                                    </td>


                                </tr>


                            <?php endforeach; ?>


                        <?php endif; ?>


                        </tbody>


                    </table>


                </div>


            </section>


            <!-- QUICK ACTIONS -->

            <section class="card">


                <div class="card-header">

                    <h3>
                        Quick Actions
                    </h3>

                </div>


                <div class="quick-actions">


                    <a
                        href="admin-packages.php?action=add"
                        class="quick-action"
                    >

                        <i class="fa-solid fa-plus"></i>

                        <strong>
                            Add Package
                        </strong>

                        <span>
                            Create and publish a new holiday package.
                        </span>

                    </a>


                    <a
                        href="admin-destinations.php?action=add"
                        class="quick-action"
                    >

                        <i class="fa-solid fa-location-dot"></i>

                        <strong>
                            Add Destination
                        </strong>

                        <span>
                            Add another worldwide travel destination.
                        </span>

                    </a>


                    <a
                        href="admin-web-gallery.php"
                        class="quick-action"
                    >

                        <i class="fa-regular fa-images"></i>

                        <strong>
                            Web Gallery
                        </strong>

                        <span>
                            Upload, search and manage website package photos.
                        </span>

                    </a>


                    <a
                        href="admin-bookings.php"
                        class="quick-action"
                    >

                        <i class="fa-solid fa-calendar-check"></i>

                        <strong>
                            Manage Bookings
                        </strong>

                        <span>
                            Review and manage customer reservations.
                        </span>

                    </a>


                    <a
                        href="<?= e(BASE_URL . 'admin-cancellations.php'); ?>"
                        class="quick-action"
                    >

                        <i class="fa-solid fa-ban"></i>

                        <strong>
                            Cancellations
                        </strong>

                        <span>
                            Review and process customer cancellation requests.
                            <?php if ($pendingCancellations > 0): ?>
                                <?= number_format($pendingCancellations); ?> pending.
                            <?php endif; ?>
                        </span>

                    </a>


                    <a
                        href="admin-coupons.php"
                        class="quick-action"
                    >

                        <i class="fa-solid fa-ticket"></i>

                        <strong>
                            Manage Coupons
                        </strong>

                        <span>
                            Create, edit and manage booking discount coupons.
                        </span>

                    </a>


                    <a
                        href="admin-enquiries.php"
                        class="quick-action"
                    >

                        <i class="fa-solid fa-headset"></i>

                        <strong>
                            Enquiries
                        </strong>

                        <span>
                            Respond to customer travel enquiries.
                        </span>

                    </a>
<a
                        href="admin-customers.php"
                        class="quick-action"
                    >

                        <i class="fa-solid fa-users"></i>

                        <strong>
                            Customers
                        </strong>

                        <span>
                            View registered TRAVSCOPE customers.
                        </span>

                    </a>


                    <a
                        href="admin-blogs.php?action=add"
                        class="quick-action"
                    >
                        <i class="fa-solid fa-pen-nib"></i>

                        <strong>
                            Add Travel Story
                        </strong>

                        <span>
                            Publish destination stories, guides and local experiences.
                        </span>
                    </a>


                    <a
                        href="admin-settings.php"
                        class="quick-action"
                    >

                        <i class="fa-solid fa-sliders"></i>

                        <strong>
                            Site Settings
                        </strong>

                        <span>
                            Manage contact and website information.
                        </span>

                    </a>


                </div>


            </section>


        </div>


        <!-- =================================================
             RECENT BOOKINGS
        ================================================== -->

        <section class="card full-card">


            <div class="card-header">

                <h3>
                    Recent Bookings
                </h3>


                <a href="admin-bookings.php">

                    View All

                </a>

            </div>


            <div class="table-wrap">


                <table>


                    <thead>

                    <tr>

                        <th>Booking</th>

                        <th>Customer</th>

                        <th>Package</th>

                        <th>Amount</th>

                        <th>Booking</th>

                        <th>Payment</th>

                        <th>Date</th>

                    </tr>

                    </thead>


                    <tbody>


                    <?php if (!$recentBookings): ?>


                        <tr>

                            <td colspan="7">

                                No bookings have been received yet.

                            </td>

                        </tr>


                    <?php else: ?>


                        <?php foreach ($recentBookings as $booking): ?>


                            <tr>


                                <td>

                                    <div class="customer-name">

                                        <?= e(
                                            $booking['booking_number']
                                        ); ?>

                                    </div>

                                </td>


                                <td>

                                    <div class="customer-name">

                                        <?= e(
                                            $booking['customer_name']
                                        ); ?>

                                    </div>


                                    <div class="table-small">

                                        <?= e(
                                            $booking['customer_email']
                                        ); ?>

                                    </div>

                                </td>


                                <td>

                                    <?= e(
                                        $booking['package_title']
                                        ?: 'Custom Trip'
                                    ); ?>

                                </td>


                                <td class="amount">

                                    <?= e($currencySymbol); ?>
                                    <?= number_format(
                                        (float)$booking['total_amount'],
                                        0
                                    ); ?>

                                </td>


                                <td>

                                    <span
                                        class="status status-<?= e($booking['booking_status']); ?>"
                                    >

                                        <?= e(
                                            ucfirst(
                                                $booking['booking_status']
                                            )
                                        ); ?>

                                    </span>

                                </td>


                                <td>

                                    <span
                                        class="status status-<?= e($booking['payment_status']); ?>"
                                    >

                                        <?= e(
                                            ucfirst(
                                                $booking['payment_status']
                                            )
                                        ); ?>

                                    </span>

                                </td>


                                <td>

                                    <?= date(
                                        'd M Y',
                                        strtotime(
                                            $booking['created_at']
                                        )
                                    ); ?>

                                </td>


                            </tr>


                        <?php endforeach; ?>


                    <?php endif; ?>


                    </tbody>


                </table>


            </div>


        </section>
        </details><!-- /ex-deep-reports -->


    </div>


</main>


<script>

/*
|--------------------------------------------------------------------------
| MOBILE SIDEBAR
|--------------------------------------------------------------------------
*/

const sidebar =
    document.getElementById('sidebar');

const mobileMenu =
    document.getElementById('mobileMenu');

const sidebarOverlay =
    document.getElementById('sidebarOverlay');


function openSidebar() {

    sidebar.classList.add('open');

    sidebarOverlay.classList.add('show');
}


function closeSidebar() {

    sidebar.classList.remove('open');

    sidebarOverlay.classList.remove('show');
}


mobileMenu.addEventListener(
    'click',
    function () {

        if (
            sidebar.classList.contains('open')
        ) {

            closeSidebar();

        } else {

            openSidebar();
        }
    }
);


sidebarOverlay.addEventListener(
    'click',
    closeSidebar
);


window.addEventListener(
    'resize',
    function () {

        if (window.innerWidth > 850) {

            closeSidebar();
        }
    }
);

</script>








<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<script>
(function(){
    function revealHash(hash) {
        if (!hash || hash.charAt(0) !== '#') return;
        const target = document.getElementById(hash.slice(1));
        if (!target) return;
        let parent = target.closest('details');
        while (parent) { parent.open = true; parent = parent.parentElement.closest('details'); }
        requestAnimationFrame(function(){ target.scrollIntoView({behavior:'smooth',block:'start'}); });
    }
    document.querySelectorAll('a[href^="#"]').forEach(function(link){
        link.addEventListener('click',function(){ revealHash(this.getAttribute('href')); });
    });
    if (location.hash) revealHash(location.hash);
})();
</script>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
