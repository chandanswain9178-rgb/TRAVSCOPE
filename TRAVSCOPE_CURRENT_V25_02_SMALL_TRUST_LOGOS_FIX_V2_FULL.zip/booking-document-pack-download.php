<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/document-functions.php';

$packId =
    max(
        0,
        (int)(
            $_GET['pack']
            ?? 0
        )
    );

if (
    $packId <= 0
    || !tsDocReady($pdo)
) {
    http_response_code(404);
    exit('Trip Document Pack not found.');
}

$pack =
    tsDocPackById(
        $pdo,
        $packId
    );

if (!$pack) {
    http_response_code(404);
    exit('Trip Document Pack not found.');
}

$isAdmin =
    !empty($_SESSION['admin_id']);

if (!$isAdmin) {
    requireLogin();

    $user =
        currentUser($pdo);

    if (
        !$user
        || (int)$pack['user_id']
            !== (int)$user['id']
        || (string)$pack['status']
            !== 'final'
        || !tsDocPackIsCurrent(
            $pdo,
            $pack
        )
    ) {
        http_response_code(403);
        exit('Trip Document Pack download is not available.');
    }
} elseif (
    !in_array(
        (string)$pack['status'],
        ['final','void'],
        true
    )
) {
    http_response_code(400);
    exit('Only issued document packs can be downloaded as ZIP.');
}

if (!class_exists('ZipArchive')) {
    http_response_code(501);
    exit(
        'ZIP download is not available on this server because the PHP ZipArchive extension is not enabled. Open the pack and download documents individually.'
    );
}

$snapshot =
    json_decode(
        (string)$pack['snapshot_json'],
        true
    );

if (!is_array($snapshot)) {
    http_response_code(500);
    exit('Trip Document Pack snapshot is invalid.');
}

$documents =
    is_array(
        $snapshot['documents']
        ?? null
    )
        ? $snapshot['documents']
        : [];

$booking =
    is_array(
        $snapshot['booking']
        ?? null
    )
        ? $snapshot['booking']
        : [];

$travellerNames = [];

foreach (
    (array)(
        $snapshot['travellers']
        ?? []
    )
    as $traveller
) {
    $travellerNames[
        (int)(
            $traveller['id']
            ?? 0
        )
    ] =
        (string)(
            $traveller['full_name']
            ?? 'Traveller'
        );
}

$temp =
    tempnam(
        sys_get_temp_dir(),
        'travscope-pack-'
    );

if (!$temp) {
    http_response_code(500);
    exit('Unable to prepare document ZIP.');
}

$zip =
    new ZipArchive();

if (
    $zip->open(
        $temp,
        (ZipArchive::CREATE | ZipArchive::OVERWRITE)
    ) !== true
) {
    @unlink($temp);
    http_response_code(500);
    exit('Unable to create document ZIP.');
}

$usedNames = [];

function tdpZipSafe(string $name): string
{
    $name =
        preg_replace(
            '/[^A-Za-z0-9._ -]+/',
            '-',
            $name
        );

    $name =
        trim(
            (string)$name,
            " .-_"
        );

    return
        $name !== ''
            ? $name
            : 'document';
}

foreach ($documents as $documentSnapshot) {
    $documentId =
        max(
            0,
            (int)(
                $documentSnapshot['id']
                ?? 0
            )
        );

    if ($documentId <= 0) {
        continue;
    }

    $document =
        tsDocDocument(
            $pdo,
            (int)$pack['booking_id'],
            $documentId
        );

    if (!$document) {
        continue;
    }

    $relative =
        ltrim(
            (string)$document['file_path'],
            '/'
        );

    $full =
        tsDocSafeExistingPath(
            $relative,
            'uploads/booking-documents/booking_'
            . (int)$pack['booking_id']
            . '/'
        );

    if (!$full) {
        continue;
    }

    $travellerId =
        (int)(
            $document['traveller_id']
            ?? 0
        );

    $prefix =
        $travellerId > 0
            ? (
                $travellerNames[$travellerId]
                ?? 'Traveller'
            )
            : 'Booking';

    $extension =
        strtolower(
            pathinfo(
                (string)$document['original_name'],
                PATHINFO_EXTENSION
            )
        );

    if ($extension === '') {
        $extension =
            strtolower(
                pathinfo(
                    $full,
                    PATHINFO_EXTENSION
                )
            );
    }

    $base =
        tdpZipSafe(
            $prefix
            . ' - '
            . (string)$document['document_type']
        );

    $name =
        $base
        . (
            $extension !== ''
                ? '.'
                    . tdpZipSafe($extension)
                : ''
        );

    $counter = 2;

    while (isset($usedNames[strtolower($name)])) {
        $name =
            $base
            . '-'
            . $counter
            . (
                $extension !== ''
                    ? '.'
                        . tdpZipSafe($extension)
                    : ''
            );

        $counter++;
    }

    $usedNames[strtolower($name)] = true;

    $zip->addFile(
        $full,
        $name
    );
}

$manifest =
    "TRAVSCOPE.COM\n"
    . "Trip Document Pack: "
    . (string)$pack['pack_code']
    . "\n"
    . "Booking: "
    . (string)(
        $booking['booking_number']
        ?? ''
    )
    . "\n"
    . "Customer: "
    . (string)(
        $booking['customer_name']
        ?? ''
    )
    . "\n"
    . "Travel Date: "
    . (string)(
        $booking['travel_date']
        ?? ''
    )
    . "\n\n"
    . "This ZIP contains the verified customer-visible files frozen into this Trip Document Pack.\n"
    . "Open the online Trip Document Pack for the TRAVSCOPE Travel Voucher / Final Invoice links.\n";

$zip->addFromString(
    'TRAVSCOPE-Document-Pack-Manifest.txt',
    $manifest
);

$zip->close();

$safeCode =
    preg_replace(
        '/[^A-Za-z0-9._-]+/',
        '-',
        (string)$pack['pack_code']
    );

if (!is_string($safeCode) || $safeCode === '') {
    $safeCode =
        'TRAVSCOPE-Trip-Document-Pack';
}

header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store, max-age=0');
header('Content-Type: application/zip');
header(
    'Content-Disposition: attachment; filename="'
    . $safeCode
    . '.zip"'
);
header(
    'Content-Length: '
    . (string)filesize($temp)
);

readfile($temp);
@unlink($temp);
exit;
