TRAVSCOPE V24.86 — SUPPLIER PAYABLES & ACCOUNTS PAYABLE CONTROL

Install order:
1. Back up current database.
2. Import TRAVSCOPE_V24_86_SUPPLIER_PAYABLES.sql once in the same TRAVSCOPE database.
3. Upload the PATCH files, or use the CLEAN FULL WEBSITE (not both).
4. Open Finance > Supplier Payables.

New controls:
- Supplier invoice entry linked to booking/supplier
- Frozen/committed supplier cost lookup
- 3-way supplier cost / confirmation / invoice review
- Submitted / Under Review / On Hold / Rejected / Disputed / Approved workflow
- Approved payable amount and variance reason
- Partial/full supplier payments
- Transfer amount, TDS/withholding, deduction, bank charge and payment proof
- Automatic A4 supplier payment voucher
- Supplier advances and allocation against approved invoices
- Supplier credit/debit/cancellation/refund adjustments
- Invoices / Payments / Advances / Vouchers / Adjustments / Supplier Ledger tabs
- Booking-level supplier finance and profitability integration
- Finance audit trail
- Void instead of silent deletion for finance records

The SQL is extension-only and does not DROP, DELETE or TRUNCATE existing business tables/data.
