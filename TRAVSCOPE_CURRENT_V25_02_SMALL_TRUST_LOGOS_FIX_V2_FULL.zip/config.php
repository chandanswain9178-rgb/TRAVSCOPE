<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| MAIN CONFIGURATION
|--------------------------------------------------------------------------
|
| File: public_html/config.php
|
| Handles:
| - Application configuration
| - Secure sessions
| - MySQL / PDO
| - Website paths
| - Authentication constants
| - Customer/Admin session keys
| - Gmail SMTP
| - Email OTP
| - Password reset
| - PHPMailer
| - Upload directories
|
*/

declare(strict_types=1);


/*
|--------------------------------------------------------------------------
| APPLICATION DEBUG
|--------------------------------------------------------------------------
|
| false = Production
| true  = Development only
|
*/

define('APP_DEBUG', false);


/*
|--------------------------------------------------------------------------
| ERROR REPORTING
|--------------------------------------------------------------------------
*/

error_reporting(E_ALL);

if (APP_DEBUG) {

    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    ini_set('log_errors', '1');

} else {

    ini_set('display_errors', '0');
    ini_set('display_startup_errors', '0');
    ini_set('log_errors', '1');
}


/*
|--------------------------------------------------------------------------
| TIMEZONE
|--------------------------------------------------------------------------
*/

date_default_timezone_set(
    'Asia/Kolkata'
);


/*
|--------------------------------------------------------------------------
| SECURE SESSION
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {

    $secure =
        (
            !empty($_SERVER['HTTPS'])
            &&
            $_SERVER['HTTPS'] !== 'off'
        )
        ||
        (
            isset($_SERVER['SERVER_PORT'])
            &&
            (int)$_SERVER['SERVER_PORT'] === 443
        );


    session_set_cookie_params([

        'lifetime' => 0,

        'path' => '/',

        'domain' => '',

        'secure' => $secure,

        'httponly' => true,

        'samesite' => 'Lax'

    ]);


    session_start();
}


/*
|--------------------------------------------------------------------------
| DATABASE CONFIGURATION
|--------------------------------------------------------------------------
|
| Enter your real MilesWeb database password below.
|
*/

define(
    'DB_HOST',
    '103.108.220.222'
);


define(
    'DB_PORT',
    3306
);


define(
    'DB_NAME',
    'travscop1_ai'
);


define(
    'DB_USER',
    'travscop1_travscopeai'
);


define(
    'DB_PASSWORD',
    'Travscope@8018'
);


/*
|--------------------------------------------------------------------------
| PDO DATABASE CONNECTION
|--------------------------------------------------------------------------
*/

try {

    $dsn =
        'mysql:host=' . DB_HOST .
        ';port=' . DB_PORT .
        ';dbname=' . DB_NAME .
        ';charset=utf8mb4';


    $pdo =
        new PDO(

            $dsn,

            DB_USER,

            DB_PASSWORD,

            [

                PDO::ATTR_ERRMODE =>
                    PDO::ERRMODE_EXCEPTION,

                PDO::ATTR_DEFAULT_FETCH_MODE =>
                    PDO::FETCH_ASSOC,

                PDO::ATTR_EMULATE_PREPARES =>
                    false,

                PDO::ATTR_STRINGIFY_FETCHES =>
                    false

            ]
        );


    /*
    |--------------------------------------------------------------------------
    | MYSQL TIMEZONE
    |--------------------------------------------------------------------------
    */

    try {

        $pdo->exec(
            "SET time_zone = '+05:30'"
        );

    } catch (PDOException $e) {

        /*
        | Some hosting environments do not allow
        | changing MySQL timezone.
        */

        error_log(
            'TRAVSCOPE MySQL timezone warning: '
            .
            $e->getMessage()
        );
    }


} catch (PDOException $e) {

    error_log(
        'TRAVSCOPE database connection error: '
        .
        $e->getMessage()
    );


    http_response_code(500);


    if (APP_DEBUG) {

        exit(
            'Database Error: '
            .
            htmlspecialchars(
                $e->getMessage(),
                ENT_QUOTES,
                'UTF-8'
            )
        );
    }


    exit(
        'Website database connection is temporarily unavailable. Please try again later.'
    );
}




/*
|--------------------------------------------------------------------------
| PEXELS ROYALTY-FREE IMAGE API
|--------------------------------------------------------------------------
*/

define(
    'PEXELS_API_KEY',
    'fmJ3UxZxTV28SqweE5kTgtfAabuKxxKHi4OyJEEf5Pk3TcyjC511vDQ9'
);

define(
    'PEXELS_API_BASE_URL',
    'https://api.pexels.com/v1'
);

define(
    'PEXELS_API_PER_PAGE',
    24
);

define(
    'PEXELS_API_TIMEOUT',
    25
);


/*
|--------------------------------------------------------------------------
| UNSPLASH ROYALTY-FREE IMAGE API
|--------------------------------------------------------------------------
| Server-side only. Public photo search requires only the Access Key.
| The Unsplash Secret Key is intentionally not stored because this module
| does not use OAuth/user-authorized actions.
|--------------------------------------------------------------------------
*/

define(
    'UNSPLASH_APPLICATION_ID',
    '1013368'
);

define(
    'UNSPLASH_ACCESS_KEY',
    'KL4qjPsAIqmuTLS5B8ttl1N-qEXnJxe9O3SrTFOXr2g'
);

define(
    'UNSPLASH_API_BASE_URL',
    'https://api.unsplash.com'
);

define(
    'UNSPLASH_API_PER_PAGE',
    24
);

define(
    'UNSPLASH_API_TIMEOUT',
    25
);

define(
    'PEXELS_IMAGE_MAX_SIZE_KB',
    100
);

define(
    'PEXELS_SAVE_TO_WEB_GALLERY',
    true
);

define(
    'PEXELS_ENABLE_ATTRIBUTION',
    true
);

/*
|--------------------------------------------------------------------------
| WEBSITE INFORMATION
|--------------------------------------------------------------------------
*/

define(
    'SITE_NAME',
    'TRAVSCOPE.COM'
);


define(
    'SITE_DOMAIN',
    'travscope.com'
);


define(
    'BASE_URL',
    'https://travscope.com/'
);


/*
|--------------------------------------------------------------------------
| GOOGLE OAUTH 2.0 LOGIN / SIGN-UP
|--------------------------------------------------------------------------
| Direct OAuth 2.0 flow. No Composer/google-apiclient required.
|
| Authorized JavaScript origin:
| https://travscope.com
|
| Authorized redirect URI:
| https://travscope.com/google-auth.php
|--------------------------------------------------------------------------
*/

if (!defined('GOOGLE_CLIENT_ID')) {
    define(
        'GOOGLE_CLIENT_ID',
        '573351555286-lf23s4q952ee2nn379cu86njvvc66p8a.apps.googleusercontent.com'
    );
}

if (!defined('GOOGLE_CLIENT_SECRET')) {
    define(
        'GOOGLE_CLIENT_SECRET',
        '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'
    );
}

if (!defined('GOOGLE_REDIRECT_URI')) {
    define(
        'GOOGLE_REDIRECT_URI',
        BASE_URL . 'google-auth.php'
    );
}


/*
|--------------------------------------------------------------------------
| GOOGLE PLACES API (HOTEL MASTER PRO)
|--------------------------------------------------------------------------
| Optional. Enables live hotel search/photo previews in Admin > Hotel Master.
| Recommended: set GOOGLE_PLACES_API_KEY as a hosting environment variable.
| For simple cPanel testing you may paste the restricted server-side key below.
| Restrict the key to Places API (New) and your server/public IP where possible.
|--------------------------------------------------------------------------
*/
if (!defined('GOOGLE_PLACES_API_KEY')) {
    $googlePlacesEnv = getenv('GOOGLE_PLACES_API_KEY');
    define(
        'GOOGLE_PLACES_API_KEY',
        is_string($googlePlacesEnv) && trim($googlePlacesEnv) !== ''
            ? trim($googlePlacesEnv)
            : '' // Example: 'AIza...'; leave blank to use TRAVSCOPE internal hotel search only.
    );
}


/*
|--------------------------------------------------------------------------
| SUPPORT EMAIL
|--------------------------------------------------------------------------
|
| Replace this with your Gmail address.
|
*/

define(
    'SUPPORT_EMAIL',
    'travscope@gmail.com'
);


/*
|--------------------------------------------------------------------------
| ROOT DIRECTORY
|--------------------------------------------------------------------------
*/

define(
    'ROOT_PATH',
    __DIR__
);


/*
|--------------------------------------------------------------------------
| INCLUDE DIRECTORY
|--------------------------------------------------------------------------
*/

define(
    'INCLUDES_PATH',
    ROOT_PATH . '/includes/'
);


/*
|--------------------------------------------------------------------------
| UPLOAD DIRECTORY
|--------------------------------------------------------------------------
*/

define(
    'UPLOAD_PATH',
    ROOT_PATH . '/uploads/'
);


/*
|--------------------------------------------------------------------------
| DESTINATION UPLOAD DIRECTORY
|--------------------------------------------------------------------------
*/

define(
    'DESTINATION_UPLOAD_PATH',
    UPLOAD_PATH . 'destinations/'
);


/*
|--------------------------------------------------------------------------
| PACKAGE UPLOAD DIRECTORY
|--------------------------------------------------------------------------
*/

define(
    'PACKAGE_UPLOAD_PATH',
    UPLOAD_PATH . 'packages/'
);


/*
|--------------------------------------------------------------------------
| PROFILE UPLOAD DIRECTORY
|--------------------------------------------------------------------------
*/

define(
    'PROFILE_UPLOAD_PATH',
    UPLOAD_PATH . 'profiles/'
);


/*
|--------------------------------------------------------------------------
| UPLOAD URL
|--------------------------------------------------------------------------
*/

define(
    'UPLOAD_URL',
    BASE_URL . 'uploads/'
);


/*
|--------------------------------------------------------------------------
| DESTINATION UPLOAD URL
|--------------------------------------------------------------------------
*/

define(
    'DESTINATION_UPLOAD_URL',
    UPLOAD_URL . 'destinations/'
);


/*
|--------------------------------------------------------------------------
| PACKAGE UPLOAD URL
|--------------------------------------------------------------------------
*/

define(
    'PACKAGE_UPLOAD_URL',
    UPLOAD_URL . 'packages/'
);


/*
|--------------------------------------------------------------------------
| PROFILE UPLOAD URL
|--------------------------------------------------------------------------
*/

define(
    'PROFILE_UPLOAD_URL',
    UPLOAD_URL . 'profiles/'
);


/*
|--------------------------------------------------------------------------
| FILE UPLOAD SECURITY
|--------------------------------------------------------------------------
*/

define(
    'MAX_UPLOAD_SIZE',
    5 * 1024 * 1024
);


define(
    'ALLOWED_IMAGE_TYPES',
    [
        'image/jpeg',
        'image/png',
        'image/webp'
    ]
);


/*
|--------------------------------------------------------------------------
| AUTHENTICATION SETTINGS
|--------------------------------------------------------------------------
|
| CUSTOMER REGISTRATION:
|
| Name
| Email
| Mobile
| Password
|     ↓
| Email OTP
|     ↓
| Account Activated
|
|
| CUSTOMER LOGIN:
|
| Email + Password
|
| OR
|
| Mobile + Password
|
|
| ADMIN LOGIN:
|
| Email/Mobile + Password
|
|
| FORGOT PASSWORD:
|
| Email
|     ↓
| Email OTP
|     ↓
| Verify OTP
|     ↓
| Create New Password
|
*/


/*
|--------------------------------------------------------------------------
| EMAIL VERIFICATION
|--------------------------------------------------------------------------
*/

define(
    'EMAIL_VERIFICATION_REQUIRED',
    true
);


/*
|--------------------------------------------------------------------------
| MOBILE VERIFICATION
|--------------------------------------------------------------------------
|
| Mobile number is stored but mobile OTP is not required.
|
*/

define(
    'MOBILE_VERIFICATION_REQUIRED',
    false
);


/*
|--------------------------------------------------------------------------
| PASSWORD SECURITY
|--------------------------------------------------------------------------
*/

define(
    'PASSWORD_MIN_LENGTH',
    8
);


/*
|--------------------------------------------------------------------------
| CUSTOMER / ADMIN SESSION KEYS
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| functions.php uses these constants.
|
| Customer:
| $_SESSION['user_id']
|
| Admin:
| $_SESSION['admin_id']
|
*/

define(
    'USER_SESSION_KEY',
    'user_id'
);


define(
    'ADMIN_SESSION_KEY',
    'admin_id'
);


/*
|--------------------------------------------------------------------------
| LOGIN SECURITY
|--------------------------------------------------------------------------
*/

define(
    'MAX_LOGIN_ATTEMPTS',
    5
);


define(
    'LOGIN_LOCKOUT_MINUTES',
    15
);


/*
|--------------------------------------------------------------------------
| REMEMBER LOGIN
|--------------------------------------------------------------------------
*/

define(
    'REMEMBER_LOGIN_DAYS',
    30
);


/*
|--------------------------------------------------------------------------
| EMAIL OTP LENGTH
|--------------------------------------------------------------------------
*/

define(
    'OTP_LENGTH',
    6
);


/*
|--------------------------------------------------------------------------
| EMAIL OTP EXPIRY
|--------------------------------------------------------------------------
|
| OTP expires after 10 minutes.
|
*/

define(
    'OTP_EXPIRY_MINUTES',
    10
);


/*
|--------------------------------------------------------------------------
| OTP RESEND COOLDOWN
|--------------------------------------------------------------------------
|
| Customer must wait 60 seconds before requesting another OTP.
|
*/

define(
    'OTP_RESEND_SECONDS',
    60
);


/*
|--------------------------------------------------------------------------
| OTP MAX VERIFY ATTEMPTS
|--------------------------------------------------------------------------
*/

define(
    'OTP_MAX_ATTEMPTS',
    5
);


/*
|--------------------------------------------------------------------------
| OTP REQUEST LIMIT
|--------------------------------------------------------------------------
|
| Maximum OTP requests for the same email/purpose per hour.
|
*/

define(
    'OTP_MAX_REQUESTS_PER_HOUR',
    5
);


/*
|--------------------------------------------------------------------------
| SMTP ENABLED
|--------------------------------------------------------------------------
*/

define(
    'SMTP_ENABLED',
    true
);


/*
|--------------------------------------------------------------------------
| GMAIL SMTP HOST
|--------------------------------------------------------------------------
*/

define(
    'SMTP_HOST',
    'smtp.gmail.com'
);


/*
|--------------------------------------------------------------------------
| SMTP AUTHENTICATION
|--------------------------------------------------------------------------
*/

define(
    'SMTP_AUTH',
    true
);


/*
|--------------------------------------------------------------------------
| SMTP PORT
|--------------------------------------------------------------------------
|
| Gmail STARTTLS = 587
|
*/

define(
    'SMTP_PORT',
    587
);


/*
|--------------------------------------------------------------------------
| SMTP ENCRYPTION
|--------------------------------------------------------------------------
*/

define(
    'SMTP_ENCRYPTION',
    'tls'
);


/*
|--------------------------------------------------------------------------
| GMAIL USERNAME
|--------------------------------------------------------------------------
|
| Put the Gmail account used to send OTP emails.
|
*/

define(
    'SMTP_USERNAME',
    'travscope@gmail.com'
);


/*
|--------------------------------------------------------------------------
| GMAIL APP PASSWORD
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| Use a Google App Password.
| Do NOT use your normal Gmail password.
|
*/

define(
    'SMTP_PASSWORD',
    'yyvdgdxdonkmgvdu'
);


/*
|--------------------------------------------------------------------------
| MAIL FROM ADDRESS
|--------------------------------------------------------------------------
|
| Gmail normally requires this to match SMTP_USERNAME.
|
*/

define(
    'MAIL_FROM_ADDRESS',
    SMTP_USERNAME
);


/*
|--------------------------------------------------------------------------
| MAIL FROM NAME
|--------------------------------------------------------------------------
*/

define(
    'MAIL_FROM_NAME',
    'TRAVSCOPE.COM'
);


/*
|--------------------------------------------------------------------------
| REPLY TO
|--------------------------------------------------------------------------
*/

define(
    'MAIL_REPLY_TO',
    SMTP_USERNAME
);


/*
|--------------------------------------------------------------------------
| REGISTRATION OTP EMAIL SUBJECT
|--------------------------------------------------------------------------
*/

define(
    'REGISTER_OTP_SUBJECT',
    'Verify your TRAVSCOPE.COM account'
);


/*
|--------------------------------------------------------------------------
| PASSWORD RESET EMAIL SUBJECT
|--------------------------------------------------------------------------
*/

define(
    'PASSWORD_RESET_OTP_SUBJECT',
    'Reset your TRAVSCOPE.COM password'
);


/*
|--------------------------------------------------------------------------
| PHPMailer FILE PATHS
|--------------------------------------------------------------------------
|
| Required:
|
| public_html/
|
| ├── config.php
|
| ├── PHPMailer/
| │   └── src/
| │       ├── Exception.php
| │       ├── PHPMailer.php
| │       └── SMTP.php
|
| └── includes/
|     └── functions.php
|
*/

$phpMailerException =
    ROOT_PATH .
    '/PHPMailer/src/Exception.php';


$phpMailerMain =
    ROOT_PATH .
    '/PHPMailer/src/PHPMailer.php';


$phpMailerSmtp =
    ROOT_PATH .
    '/PHPMailer/src/SMTP.php';


/*
|--------------------------------------------------------------------------
| VERIFY PHPMailer FILES
|--------------------------------------------------------------------------
*/

if (
    !file_exists(
        $phpMailerException
    )
    ||
    !file_exists(
        $phpMailerMain
    )
    ||
    !file_exists(
        $phpMailerSmtp
    )
) {

    error_log(
        'TRAVSCOPE PHPMailer files are missing.'
    );


    http_response_code(500);


    if (APP_DEBUG) {

        exit(
            'PHPMailer files are missing. Check the PHPMailer/src directory.'
        );
    }


    exit(
        'Website email configuration is incomplete.'
    );
}


/*
|--------------------------------------------------------------------------
| LOAD PHPMailer
|--------------------------------------------------------------------------
*/

require_once
    $phpMailerException;


require_once
    $phpMailerMain;


require_once
    $phpMailerSmtp;


/*
|--------------------------------------------------------------------------
| FUNCTIONS FILE
|--------------------------------------------------------------------------
*/

$functionsFile =
    INCLUDES_PATH .
    'functions.php';


/*
|--------------------------------------------------------------------------
| VERIFY FUNCTIONS FILE
|--------------------------------------------------------------------------
*/

if (
    !file_exists(
        $functionsFile
    )
) {

    error_log(
        'TRAVSCOPE functions.php is missing: '
        .
        $functionsFile
    );


    http_response_code(500);


    if (APP_DEBUG) {

        exit(
            'functions.php not found: '
            .
            htmlspecialchars(
                $functionsFile,
                ENT_QUOTES,
                'UTF-8'
            )
        );
    }


    exit(
        'Website configuration is incomplete.'
    );
}


/*
|--------------------------------------------------------------------------
| LOAD FUNCTIONS
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| USER_SESSION_KEY and ADMIN_SESSION_KEY have already
| been defined above before functions.php is loaded.
|
*/

require_once
    $functionsFile;


/*
|--------------------------------------------------------------------------
| CREATE REQUIRED UPLOAD DIRECTORIES
|--------------------------------------------------------------------------
*/

$requiredDirectories = [

    UPLOAD_PATH,

    DESTINATION_UPLOAD_PATH,

    PACKAGE_UPLOAD_PATH,

    PROFILE_UPLOAD_PATH

];


foreach (
    $requiredDirectories
    as $directory
) {

    if (
        !is_dir(
            $directory
        )
    ) {

        if (
            !@mkdir(
                $directory,
                0755,
                true
            )
            &&
            !is_dir(
                $directory
            )
        ) {

            error_log(
                'TRAVSCOPE could not create directory: '
                .
                $directory
            );
        }
    }
}



/*
|--------------------------------------------------------------------------
| WEBSITE MAINTENANCE MODE
|--------------------------------------------------------------------------
|
| When maintenance_mode = 1:
| - Public/customer pages are blocked.
| - Customer login/registration are blocked.
| - Admin login remains available.
| - Logged-in admin and admin-* pages remain available.
|
*/

try {

    $maintenanceMode = (string)getSetting($pdo, 'maintenance_mode', '0') === '1';

    if ($maintenanceMode) {

        $currentScript = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));

        /*
        | Admin area must always remain accessible so maintenance mode
        | can be switched off again.
        */
        $isAdminPage =
            str_starts_with($currentScript, 'admin-')
            || $currentScript === 'admin-login.php';

        /*
        | Your current project may use login.php for both customer/admin.
        | Keep login.php reachable so the administrator cannot be locked out.
        */
        $isLoginPage =
            $currentScript === 'login.php'
            || $currentScript === 'google-auth.php';

        /*
        | Expose maintenance state to the shared login.php.
        | login.php stays reachable because both customers and admins use it,
        | but customer authentication should be rejected there while maintenance
        | is active. Admin authentication remains allowed.
        */
        if (!defined('MAINTENANCE_MODE_ACTIVE')) {
            define('MAINTENANCE_MODE_ACTIVE', true);
        }

        $isLoggedInAdmin =
            !empty($_SESSION[ADMIN_SESSION_KEY]);

        if (!$isAdminPage && !$isLoginPage && !$isLoggedInAdmin) {

            $maintenanceMessage = trim(
                (string)getSetting(
                    $pdo,
                    'maintenance_message',
                    'We are updating our website. Please check back shortly.'
                )
            );

            if ($maintenanceMessage === '') {
                $maintenanceMessage =
                    'We are updating our website. Please check back shortly.';
            }

            http_response_code(503);
            header('Retry-After: 3600');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

            $safeSiteName = htmlspecialchars(
                (string)getSetting($pdo, 'site_name', SITE_NAME),
                ENT_QUOTES,
                'UTF-8'
            );

            $safeMessage = htmlspecialchars(
                $maintenanceMessage,
                ENT_QUOTES,
                'UTF-8'
            );

            $maintenanceLogoHtml = $safeSiteName;
            try {
                $maintenanceLogo = trim((string)getSetting($pdo, 'site_logo', ''));
                if ($maintenanceLogo !== '') {
                    $maintenanceLogoUrl = preg_match('#^https?://#i', $maintenanceLogo)
                        ? $maintenanceLogo
                        : rtrim((string)BASE_URL, '/') . '/' . ltrim($maintenanceLogo, '/');
                    $maintenanceLogoHtml = '<img src="' . htmlspecialchars($maintenanceLogoUrl, ENT_QUOTES, 'UTF-8') . '" alt="' . $safeSiteName . '" style="display:block;max-width:190px;max-height:48px;width:auto;height:auto;object-fit:contain;margin:0 auto">';
                }
            } catch (Throwable $ignore) {
                $maintenanceLogoHtml = $safeSiteName;
            }

            $adminLoginUrl = htmlspecialchars(
                BASE_URL . 'login.php',
                ENT_QUOTES,
                'UTF-8'
            );

            exit('<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Website Under Maintenance | '.$safeSiteName.'</title>
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#f4f7fb;color:#172033;font-family:Arial,sans-serif}
.box{width:min(620px,100%);background:#fff;border:1px solid #e4e9f0;border-radius:20px;padding:42px 30px;text-align:center;box-shadow:0 18px 55px rgba(7,25,45,.08)}
.icon{width:72px;height:72px;margin:0 auto 20px;border-radius:20px;display:grid;place-items:center;background:#eaf3ff;color:#0b74ff;font-size:34px}
h1{margin:0;font-size:30px;color:#07192d}
p{margin:14px auto 0;max-width:500px;font-size:15px;line-height:1.7;color:#687487}
.brand{margin-top:24px;font-size:12px;font-weight:700;color:#9aa5b3}
.admin{margin-top:25px}
.admin a{display:inline-block;padding:11px 16px;border-radius:9px;background:#07192d;color:#fff;text-decoration:none;font-size:12px;font-weight:700}
</style>
</head>
<body>
<div class="box">
<div class="icon">&#9881;</div>
<h1>Website Under Maintenance</h1>
<p>'.$safeMessage.'</p>
<div class="brand">'.$maintenanceLogoHtml.'</div>
<div class="admin"><a href="'.$adminLoginUrl.'">Administrator Login</a></div>
</div>
</body>
</html>');
        }
    }

} catch (Throwable $e) {

    /*
    | Fail open: a settings-table problem must not accidentally
    | lock the administrator or the whole website.
    */
    error_log('TRAVSCOPE maintenance mode check error: ' . $e->getMessage());
}

/*
|--------------------------------------------------------------------------
| GLOBAL ADMIN DELETE OTP GATE - V24.11
|--------------------------------------------------------------------------
| Every destructive Admin POST (Delete/Remove/Purge/Destroy) is intercepted
| before page-specific code executes and requires verification from the
| currently logged-in Admin email.
*/
$adminDeleteOtpFunctions = __DIR__ . '/admin-delete-otp-functions.php';
if (is_file($adminDeleteOtpFunctions)) {
    require_once $adminDeleteOtpFunctions;
    if (isset($pdo) && $pdo instanceof PDO && function_exists('tsAdminDeleteOtpBoot')) {
        tsAdminDeleteOtpBoot($pdo);
    }
}

/*
|--------------------------------------------------------------------------
| CONFIGURATION COMPLETE
|--------------------------------------------------------------------------
*/