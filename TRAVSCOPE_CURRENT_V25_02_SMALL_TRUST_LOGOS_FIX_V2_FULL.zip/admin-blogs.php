<?php
/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM - ADMIN BLOG / TRAVEL STORIES MANAGER
| VERSION: 2026-08-16-R7 - GALLERY MULTI-SELECT DONE BUTTON
|--------------------------------------------------------------------------
| Add/edit/publish travel stories with destination, specific location,
| related package, main image, gallery images and formatted content.
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';
$pexelsHttpFunctionsFile = __DIR__ . '/pexels-http-functions.php';
if (is_file($pexelsHttpFunctionsFile)) require_once $pexelsHttpFunctionsFile;
$unsplashPhotoFunctionsFile = __DIR__ . '/unsplash-photo-functions.php';
if (is_file($unsplashPhotoFunctionsFile)) require_once $unsplashPhotoFunctionsFile;
requireAdmin();

$admin = currentAdmin($pdo);

if (!$admin || strtolower((string)($admin['status'] ?? 'active')) !== 'active') {
    unset($_SESSION['admin_id'], $_SESSION['admin_name'], $_SESSION['admin_email'], $_SESSION['admin_role']);
    redirect(BASE_URL . 'login.php');
}

$siteName = (string)getSetting($pdo, 'site_name', 'TRAVSCOPE.COM');
$adminInitial = strtoupper(substr((string)($admin['name'] ?? 'A'), 0, 1));

if (empty($_SESSION['admin_blogs_csrf'])) {
    $_SESSION['admin_blogs_csrf'] = bin2hex(random_bytes(32));
}
$csrfToken = (string)$_SESSION['admin_blogs_csrf'];

function blogAdminTableExists(PDO $pdo, string $table): bool
{
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) return false;
    try {
        $s = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
        $s->execute([$table]);
        return (int)$s->fetchColumn() > 0;
    } catch (Throwable $e) {
        return false;
    }
}

function blogAdminSlug(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '-', $value);
    return trim((string)$value, '-');
}

function blogAdminUniqueSlug(PDO $pdo, string $base, int $excludeId = 0): string
{
    $base = blogAdminSlug($base);
    if ($base === '') $base = 'travel-story';

    $slug = $base;
    $i = 2;

    while (true) {
        if ($excludeId > 0) {
            $s = $pdo->prepare("SELECT id FROM blogs WHERE slug=? AND id<>? LIMIT 1");
            $s->execute([$slug, $excludeId]);
        } else {
            $s = $pdo->prepare("SELECT id FROM blogs WHERE slug=? LIMIT 1");
            $s->execute([$slug]);
        }

        if (!$s->fetchColumn()) return $slug;
        $slug = $base . '-' . $i++;
    }
}

function blogAdminImageUrl(?string $image): string
{
    $image = trim((string)$image);
    if ($image === '') return '';
    if (preg_match('#^https?://#i', $image)) return $image;
    return BASE_URL . ltrim($image, '/');
}

function blogAdminUploadImage(array $file, string $prefix = 'blog'): ?string
{
    if (empty($file['name']) || (int)($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    if ((int)$file['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Image upload failed.');

    $maxBytes = 8 * 1024 * 1024;
    if ((int)$file['size'] > $maxBytes) throw new RuntimeException('Image must be 8 MB or smaller.');

    $tmp = (string)$file['tmp_name'];
    $mime = '';

    if (function_exists('finfo_open')) {
        $f = finfo_open(FILEINFO_MIME_TYPE);
        if ($f) {
            $mime = (string)finfo_file($f, $tmp);
            finfo_close($f);
        }
    }

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Only JPG, PNG and WEBP images are supported.');
    }

    $dir = __DIR__ . '/uploads/blogs/';
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
        throw new RuntimeException('Could not create uploads/blogs directory.');
    }

    $name = $prefix . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.' . $allowed[$mime];
    $target = $dir . $name;

    if (!move_uploaded_file($tmp, $target)) {
        throw new RuntimeException('Could not save uploaded image.');
    }

    return 'uploads/blogs/' . $name;
}

function blogAdminDeleteLocalImage(?string $path): void
{
    $path = trim((string)$path);
    if ($path === '' || preg_match('#^https?://#i', $path)) return;
    if (!str_starts_with($path, 'uploads/blogs/')) return;

    $full = __DIR__ . '/' . ltrim($path, '/');
    if (is_file($full)) @unlink($full);
}


/*
|--------------------------------------------------------------------------
| PACKAGE-STYLE WEB GALLERY + PEXELS IMAGE MANAGER
|--------------------------------------------------------------------------
| Uses the same existing website media folders as admin-packages.php.
| Existing package/itinerary images can be reused without copying.
*/

function blogAdminMediaLibrary(): array
{
    $out = [];
    $sources = [
        ['dir' => __DIR__ . '/uploads/packages/',  'prefix' => 'uploads/packages/'],
        ['dir' => __DIR__ . '/uploads/itinerary/', 'prefix' => 'uploads/itinerary/'],
        ['dir' => __DIR__ . '/uploads/blogs/',      'prefix' => 'uploads/blogs/'],
    ];

    foreach ($sources as $source) {
        if (!is_dir($source['dir'])) continue;
        foreach (scandir($source['dir']) ?: [] as $name) {
            $full = $source['dir'] . $name;
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (is_file($full) && in_array($ext, ['jpg','jpeg','png','webp'], true)) {
                $out[] = [
                    'name' => $name,
                    'image' => $source['prefix'] . $name,
                    'mtime' => (int)@filemtime($full),
                ];
            }
        }
    }
    usort($out, static fn($a,$b) => $b['mtime'] <=> $a['mtime']);
    return $out;
}

function blogAdminValidMediaPath(string $path): ?string
{
    $path = trim($path);
    if (function_exists('tsOfficialUnsplashImageUrl') && tsOfficialUnsplashImageUrl($path)) return $path;
    foreach ([
        'uploads/packages/' => __DIR__ . '/uploads/packages/',
        'uploads/itinerary/' => __DIR__ . '/uploads/itinerary/',
        'uploads/blogs/' => __DIR__ . '/uploads/blogs/',
    ] as $prefix => $root) {
        if (strpos($path, $prefix) !== 0) continue;
        $base = realpath($root);
        $file = realpath(__DIR__ . '/' . $path);
        if ($base && $file && is_file($file) && strpos($file, $base . DIRECTORY_SEPARATOR) === 0) {
            return $path;
        }
    }
    return null;
}

function blogPexelsApiKey(): string
{
    return defined('PEXELS_API_KEY') ? trim((string)PEXELS_API_KEY) : '';
}

function blogPexelsSearch(string $query, int $page = 1): array
{
    $key = blogPexelsApiKey();
    if ($key === '' || $key === 'YOUR_PEXELS_API_KEY_HERE') {
        throw new RuntimeException('Pexels API key is not configured in config.php.');
    }
    if (!function_exists('curl_init')) throw new RuntimeException('PHP cURL is required for Pexels search.');

    $query = trim($query);
    if ($query === '') throw new RuntimeException('Please enter a photo search keyword.');
    $page = max(1, $page);
    $perPage = defined('PEXELS_API_PER_PAGE') ? max(1, min(40, (int)PEXELS_API_PER_PAGE)) : 24;
    $base = defined('PEXELS_API_BASE_URL') ? rtrim((string)PEXELS_API_BASE_URL, '/') : 'https://api.pexels.com/v1';
    $url = $base . '/search?query=' . rawurlencode($query) . '&orientation=landscape&size=large&page=' . $page . '&per_page=' . $perPage;

    $request = tsPexelsHttpRequest(
        $url,
        ['Authorization: ' . $key, 'Accept: application/json', 'Connection: close'],
        null,
        45
    );
    $response = $request['body'];
    $code = (int)$request['status'];
    $data = json_decode((string)$response, true);
    if ($code !== 200 || !is_array($data)) throw new RuntimeException('Pexels search could not be completed.');

    $photos = [];
    foreach (($data['photos'] ?? []) as $p) {
        $s = is_array($p['src'] ?? null) ? $p['src'] : [];
        $preview = trim((string)($s['large'] ?? $s['landscape'] ?? $s['medium'] ?? ''));
        $download = trim((string)($s['large2x'] ?? $s['large'] ?? $s['landscape'] ?? ''));
        if (!$preview || !$download || empty($p['id']) || empty($p['url']) || empty($p['photographer'])) continue;
        $photos[] = [
            'provider'=>'pexels','provider_label'=>'Pexels',
            'id'=>(string)$p['id'], 'preview'=>$preview, 'download'=>$download,
            'photo_url'=>(string)$p['url'], 'photographer'=>(string)$p['photographer'],
            'photographer_url'=>(string)($p['photographer_url'] ?? ''),
            'alt'=>trim((string)($p['alt'] ?? $query)),
        ];
    }
    return [
        'photos'=>$photos, 'page'=>(int)($data['page'] ?? $page),
        'total_results'=>(int)($data['total_results'] ?? count($photos)),
        'next_page'=>!empty($data['next_page']), 'prev_page'=>!empty($data['prev_page'])
    ];
}


function blogCombinedPhotoSearch(string $query, int $page = 1): array
{
    $pp=[];$up=[];$status=[];$pm=[];$um=[];
    try{$pm=blogPexelsSearch($query,$page);$pp=array_values((array)($pm['photos']??[]));$status['pexels']=['ok'=>true,'count'=>count($pp),'message'=>count($pp)?'Pexels results loaded.':'Pexels returned no matches.'];}catch(Throwable $e){$status['pexels']=['ok'=>false,'count'=>0,'message'=>'Pexels unavailable: '.$e->getMessage()];}
    try{$um=tsUnsplashSearchPhotos($query,$page);$up=array_values((array)($um['photos']??[]));$status['unsplash']=['ok'=>true,'count'=>count($up),'message'=>count($up)?'Unsplash results loaded.':'Unsplash returned no matches.'];}catch(Throwable $e){$status['unsplash']=['ok'=>false,'count'=>0,'message'=>'Unsplash unavailable: '.$e->getMessage()];}
    $photos=tsInterleavePhotoProviders($pp,$up);
    if(!$photos && empty($status['pexels']['ok']) && empty($status['unsplash']['ok']))throw new RuntimeException('Both photo providers are unavailable. '.$status['pexels']['message'].' '.$status['unsplash']['message']);
    return ['photos'=>$photos,'page'=>max(1,$page),'total_results'=>count($photos),'next_page'=>!empty($pm['next_page'])||!empty($um['next_page']),'prev_page'=>$page>1,'provider_status'=>$status,'counts'=>['all'=>count($photos),'pexels'=>count($pp),'unsplash'=>count($up)]];
}

function blogUseUnsplashPhoto(PDO $pdo, array $photo): array
{
    $id=trim((string)($photo['id']??''));$imageUrl=trim((string)($photo['download']??''));$photoUrl=trim((string)($photo['photo_url']??''));
    $photographer=trim((string)($photo['photographer']??'Unsplash contributor'));$photographerUrl=trim((string)($photo['photographer_url']??''));$alt=trim((string)($photo['alt']??'Unsplash travel photo'));
    if($id===''||!tsOfficialUnsplashImageUrl($imageUrl))throw new RuntimeException('Invalid selected Unsplash photo.');
    tsTrackUnsplashDownload((string)($photo['download_location']??''));
    try{
        $pdo->exec("CREATE TABLE IF NOT EXISTS image_attributions (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,image_path VARCHAR(500) NOT NULL,provider VARCHAR(100) NOT NULL DEFAULT 'Pexels',provider_photo_id VARCHAR(100) DEFAULT NULL,photographer_name VARCHAR(255) DEFAULT NULL,photographer_url VARCHAR(1000) DEFAULT NULL,photo_page_url VARCHAR(1000) DEFAULT NULL,original_image_url LONGTEXT DEFAULT NULL,attribution_text VARCHAR(500) DEFAULT NULL,license_name VARCHAR(150) DEFAULT 'Pexels License',imported_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY unique_image_path(image_path)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $attr='Photo by '.$photographer.' on Unsplash';
        $st=$pdo->prepare("INSERT INTO image_attributions (image_path,provider,provider_photo_id,photographer_name,photographer_url,photo_page_url,original_image_url,attribution_text,license_name) VALUES (?,'Unsplash',?,?,?,?,?,?, 'Unsplash API') ON DUPLICATE KEY UPDATE provider='Unsplash',provider_photo_id=VALUES(provider_photo_id),photographer_name=VALUES(photographer_name),photographer_url=VALUES(photographer_url),photo_page_url=VALUES(photo_page_url),original_image_url=VALUES(original_image_url),attribution_text=VALUES(attribution_text),license_name='Unsplash API'");
        $st->execute([$imageUrl,$id,$photographer,$photographerUrl?:null,$photoUrl?:null,$imageUrl,$attr]);
    }catch(Throwable $e){error_log('Unsplash attribution save error: '.$e->getMessage());}
    return ['image'=>$imageUrl,'url'=>$imageUrl,'name'=>$alt!==''?$alt:('Unsplash '.$id),'alt'=>$alt,'attribution'=>'Photo by '.$photographer.' on Unsplash','photographer'=>$photographer,'photographer_url'=>$photographerUrl,'photo_url'=>$photoUrl,'provider'=>'Unsplash'];
}

function blogOptimizePexelsImage(string $source, string $dest): void
{
    $target = (defined('PEXELS_IMAGE_MAX_SIZE_KB') ? max(60,(int)PEXELS_IMAGE_MAX_SIZE_KB) : 100) * 1024;
    $info = @getimagesize($source);
    if (!$info) throw new RuntimeException('Imported Pexels file is not a valid image.');
    $mime = strtolower((string)($info['mime'] ?? ''));
    $im = $mime === 'image/jpeg' ? @imagecreatefromjpeg($source)
        : ($mime === 'image/png' ? @imagecreatefrompng($source)
        : (($mime === 'image/webp' && function_exists('imagecreatefromwebp')) ? @imagecreatefromwebp($source) : false));

    if (!$im || !function_exists('imagejpeg')) {
        if (!@copy($source, $dest)) throw new RuntimeException('Unable to store imported image.');
        return;
    }
    $w=imagesx($im); $h=imagesy($im);
    if ($w > 1800) {
        $nw=1800; $nh=max(1,(int)round($h*($nw/$w)));
        $r=imagecreatetruecolor($nw,$nh);
        imagecopyresampled($r,$im,0,0,0,0,$nw,$nh,$w,$h);
        imagedestroy($im); $im=$r;
    }
    foreach ([82,74,66,58,50,42,34,28,22] as $q) {
        imagejpeg($im,$dest,$q);
        if (is_file($dest) && filesize($dest) <= $target) break;
    }
    imagedestroy($im);
    if (!is_file($dest) || filesize($dest) < 500) throw new RuntimeException('Unable to optimize imported image.');
}

function blogImportPexelsPhoto(PDO $pdo, array $photo): array
{
    $id=trim((string)($photo['id']??'')); $imageUrl=trim((string)($photo['download']??''));
    $photoUrl=trim((string)($photo['photo_url']??'')); $photographer=trim((string)($photo['photographer']??''));
    $photographerUrl=trim((string)($photo['photographer_url']??'')); $alt=trim((string)($photo['alt']??''));
    if (!$id || !$imageUrl || !$photoUrl || !$photographer) throw new RuntimeException('Incomplete Pexels photo information.');
    if (strtolower((string)parse_url($imageUrl,PHP_URL_HOST)) !== 'images.pexels.com') throw new RuntimeException('Invalid Pexels image URL.');
    if (!function_exists('curl_init')) throw new RuntimeException('PHP cURL is required to import Pexels images.');

    // Same Web Gallery folder used by admin-packages.php.
    $dir=__DIR__.'/uploads/packages/';
    if (!is_dir($dir) && !mkdir($dir,0755,true)) throw new RuntimeException('Unable to create package image directory.');

    $base=preg_replace('/[^A-Za-z0-9 _-]+/','',$alt ?: ('Pexels Travel Photo '.$id));
    $base=trim(preg_replace('/\s+/',' ',(string)$base));
    if ($base==='') $base='Pexels Travel Photo';
    $base=mb_substr($base,0,90);
    $name=$base.' - Pexels '.$id.'.jpg';
    $dest=$dir.$name; $relative='uploads/packages/'.$name;

    if (!is_file($dest)) {
        $tmp=tempnam(sys_get_temp_dir(),'travscope_blog_pexels_');
        if ($tmp === false) throw new RuntimeException('Unable to prepare Pexels image download.');
        $request = tsPexelsHttpRequest($imageUrl, ['Accept: image/*', 'Connection: close'], $tmp, 60);
        $code=(int)$request['status'];
        if ($code<200 || $code>=300 || @getimagesize($tmp)===false) { @unlink($tmp); throw new RuntimeException('Unable to download selected Pexels image.'); }
        try { blogOptimizePexelsImage($tmp,$dest); } finally { @unlink($tmp); }
    }

    // Save attribution when the existing table is available.
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS image_attributions (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            image_path VARCHAR(500) NOT NULL, provider VARCHAR(100) NOT NULL DEFAULT 'Pexels',
            provider_photo_id VARCHAR(100) DEFAULT NULL, photographer_name VARCHAR(255) DEFAULT NULL,
            photographer_url VARCHAR(1000) DEFAULT NULL, photo_page_url VARCHAR(1000) DEFAULT NULL,
            original_image_url LONGTEXT DEFAULT NULL, attribution_text VARCHAR(500) DEFAULT NULL,
            license_name VARCHAR(150) DEFAULT 'Pexels License', imported_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(id), UNIQUE KEY unique_image_path(image_path)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $st=$pdo->prepare("INSERT INTO image_attributions
          (image_path,provider,provider_photo_id,photographer_name,photographer_url,photo_page_url,original_image_url,attribution_text,license_name)
          VALUES (?,'Pexels',?,?,?,?,?,?, 'Pexels License')
          ON DUPLICATE KEY UPDATE photographer_name=VALUES(photographer_name),photo_page_url=VALUES(photo_page_url),original_image_url=VALUES(original_image_url),attribution_text=VALUES(attribution_text)");
        $attr='Photo by '.$photographer.' on Pexels';
        $st->execute([$relative,$id,$photographer,$photographerUrl?:null,$photoUrl,$imageUrl,$attr]);
    } catch (Throwable $e) {}

    return [
        'image' => $relative,
        'url' => blogAdminImageUrl($relative),
        'name' => $name,
        'alt' => $alt,
        'attribution' => 'Photo by ' . $photographer . ' on Pexels',
        'photographer' => $photographer,
        'photographer_url' => $photographerUrl,
        'photo_url' => $photoUrl,
        'provider' => 'Pexels'
    ];
}


function blogAdminExcerpt(string $html, int $length = 160): string
{
    $plain = trim(preg_replace('/\s+/', ' ', strip_tags($html)));
    return mb_strlen($plain) <= $length ? $plain : mb_substr($plain, 0, $length) . '...';
}

$tableReady =
    blogAdminTableExists($pdo, 'blogs')
    && blogAdminTableExists($pdo, 'blog_categories')
    && blogAdminTableExists($pdo, 'blog_images');

$success = (string)($_SESSION['admin_blogs_success'] ?? '');
$error = (string)($_SESSION['admin_blogs_error'] ?? '');
unset($_SESSION['admin_blogs_success'], $_SESSION['admin_blogs_error']);

$action = strtolower(trim((string)($_GET['action'] ?? 'list')));
if (!in_array($action, ['list', 'add', 'edit'], true)) $action = 'list';

$categories = [];
$destinations = [];
$packages = [];

if ($tableReady) {
    try {
        $categories = $pdo->query("SELECT id,name,slug FROM blog_categories WHERE status='active' ORDER BY sort_order ASC,name ASC")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {}

    try {
        $destinations = $pdo->query("SELECT id,name,country FROM destinations WHERE status='active' ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {}

    try {
        $packages = $pdo->query("SELECT id,title FROM packages WHERE status IN ('active','draft') ORDER BY title ASC")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {}
}


$blogMediaLibrary = blogAdminMediaLibrary();

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && (string)($_POST['pexels_ajax'] ?? '') === '1'
) {
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store');
    $token = (string)($_POST['csrf_token'] ?? '');
    if ($token === '' || !hash_equals($csrfToken, $token)) {
        http_response_code(403);
        echo json_encode(['success'=>false,'message'=>'Security verification failed. Refresh and try again.']);
        exit;
    }
    try {
        $a=(string)($_POST['action']??'');
        if ($a==='pexels_search') {
            echo json_encode(['success'=>true,'data'=>blogCombinedPhotoSearch((string)($_POST['query']??''),(int)($_POST['page']??1))],JSON_UNESCAPED_SLASHES);
            exit;
        }
        if ($a==='pexels_import') {
            $photo=[
                'provider'=>(string)($_POST['provider']??'pexels'),'id'=>(string)($_POST['photo_id']??''),'download'=>(string)($_POST['image_url']??''),
                'photo_url'=>(string)($_POST['photo_url']??''),'photographer'=>(string)($_POST['photographer']??''),
                'photographer_url'=>(string)($_POST['photographer_url']??''),'download_location'=>(string)($_POST['download_location']??''),'alt'=>(string)($_POST['alt']??'')
            ];
            $provider=strtolower(trim($photo['provider']));
            $saved=$provider==='unsplash'?blogUseUnsplashPhoto($pdo,$photo):blogImportPexelsPhoto($pdo,$photo);
            echo json_encode(['success'=>true,'message'=>$provider==='unsplash'?'Unsplash photo selected.':'Photo imported to Web Gallery.','data'=>$saved],JSON_UNESCAPED_SLASHES);
            exit;
        }
        throw new RuntimeException('Invalid photo-search action.');
    } catch(Throwable $e) {
        http_response_code(400);
        echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $tableReady) {
    $token = (string)($_POST['csrf_token'] ?? '');

    if (!hash_equals($csrfToken, $token)) {
        $error = 'Security token mismatch. Refresh the page and try again.';
    } else {
        $postAction = (string)($_POST['form_action'] ?? 'save');

        /*
        | Gallery Remove buttons live inside the main edit form.
        | This avoids invalid nested forms and keeps Save Travel Story working.
        */
        if (!empty($_POST['delete_gallery_image_id'])) {
            $postAction = 'delete_gallery';
            $_POST['image_id'] = (int)$_POST['delete_gallery_image_id'];
        }

        try {
            if ($postAction === 'delete') {
                $id = (int)($_POST['id'] ?? 0);

                $s = $pdo->prepare("SELECT main_image FROM blogs WHERE id=? LIMIT 1");
                $s->execute([$id]);
                $oldMain = (string)($s->fetchColumn() ?: '');

                $s = $pdo->prepare("SELECT image FROM blog_images WHERE blog_id=?");
                $s->execute([$id]);
                $galleryFiles = $s->fetchAll(PDO::FETCH_COLUMN);

                $pdo->beginTransaction();
                $pdo->prepare("DELETE FROM blogs WHERE id=?")->execute([$id]);
                $pdo->commit();

                blogAdminDeleteLocalImage($oldMain);
                foreach ($galleryFiles as $g) blogAdminDeleteLocalImage((string)$g);

                $_SESSION['admin_blogs_success'] = 'Travel story deleted successfully.';
                header('Location: admin-blogs.php');
                exit;
            }

            if ($postAction === 'delete_gallery') {
                $imageId = (int)($_POST['image_id'] ?? 0);
                $blogId = (int)($_POST['id'] ?? 0);

                $s = $pdo->prepare("SELECT image FROM blog_images WHERE id=? AND blog_id=? LIMIT 1");
                $s->execute([$imageId, $blogId]);
                $path = (string)($s->fetchColumn() ?: '');

                $pdo->prepare("DELETE FROM blog_images WHERE id=? AND blog_id=?")->execute([$imageId, $blogId]);
                blogAdminDeleteLocalImage($path);

                $_SESSION['admin_blogs_success'] = 'Gallery image removed.';
                header('Location: admin-blogs.php?action=edit&id=' . $blogId);
                exit;
            }

            $id = (int)($_POST['id'] ?? 0);
            $title = trim((string)($_POST['title'] ?? ''));
            $slugInput = trim((string)($_POST['slug'] ?? ''));
            $excerpt = trim((string)($_POST['excerpt'] ?? ''));
            $content = trim((string)($_POST['content'] ?? ''));
            $categoryId = (int)($_POST['category_id'] ?? 0);
            $destinationId = (int)($_POST['destination_id'] ?? 0);
            $packageId = (int)($_POST['package_id'] ?? 0);
            $locationName = trim((string)($_POST['location_name'] ?? ''));
            $city = trim((string)($_POST['city'] ?? ''));
            $stateName = trim((string)($_POST['state_name'] ?? ''));
            $country = trim((string)($_POST['country'] ?? ''));
            $imageAlt = trim((string)($_POST['image_alt'] ?? ''));
            $mainImageUrl = trim((string)($_POST['main_image_url'] ?? ''));
            $authorName = trim((string)($_POST['author_name'] ?? 'TRAVSCOPE Team'));
            $metaTitle = trim((string)($_POST['meta_title'] ?? ''));
            $metaDescription = trim((string)($_POST['meta_description'] ?? ''));
            $featured = !empty($_POST['featured']) ? 1 : 0;
            $status = strtolower(trim((string)($_POST['status'] ?? 'draft')));
            $publishedAt = trim((string)($_POST['published_at'] ?? ''));

            if (!in_array($status, ['draft','published','inactive'], true)) $status = 'draft';
            if ($title === '') throw new RuntimeException('Story title is required.');
            if ($content === '') throw new RuntimeException('Story content is required.');

            $slug = blogAdminUniqueSlug($pdo, $slugInput !== '' ? $slugInput : $title, $id);

            $oldMain = '';
            if ($id > 0) {
                $s = $pdo->prepare("SELECT main_image FROM blogs WHERE id=? LIMIT 1");
                $s->execute([$id]);
                $oldMain = (string)($s->fetchColumn() ?: '');
            }

            $libraryMainImage = blogAdminValidMediaPath((string)($_POST['library_main_image'] ?? '')) ?? '';
            $newUpload = blogAdminUploadImage($_FILES['main_image_file'] ?? [], 'main');
            $mainImage = $newUpload ?: ($libraryMainImage !== '' ? $libraryMainImage : ($mainImageUrl !== '' ? $mainImageUrl : $oldMain));

            if (!empty($_POST['remove_main_image'])) {
                blogAdminDeleteLocalImage($oldMain);
                $mainImage = '';
            } elseif (($newUpload || $libraryMainImage !== '') && $oldMain && $oldMain !== $mainImage) {
                blogAdminDeleteLocalImage($oldMain);
            }

            if ($status === 'published') {
                if ($publishedAt === '') $publishedAt = date('Y-m-d H:i:s');
                else $publishedAt = date('Y-m-d H:i:s', strtotime($publishedAt));
            } else {
                $publishedAt = $publishedAt !== ''
                    ? date('Y-m-d H:i:s', strtotime($publishedAt))
                    : null;
            }

            $pdo->beginTransaction();

            if ($id > 0) {
                $s = $pdo->prepare("
                    UPDATE blogs SET
                        category_id=?,destination_id=?,package_id=?,
                        title=?,slug=?,excerpt=?,content=?,
                        location_name=?,city=?,state_name=?,country=?,
                        main_image=?,image_alt=?,author_name=?,
                        meta_title=?,meta_description=?,
                        featured=?,status=?,published_at=?,updated_at=CURRENT_TIMESTAMP
                    WHERE id=? LIMIT 1
                ");
                $s->execute([
                    $categoryId ?: null, $destinationId ?: null, $packageId ?: null,
                    $title, $slug, $excerpt ?: null, $content,
                    $locationName ?: null, $city ?: null, $stateName ?: null, $country ?: null,
                    $mainImage ?: null, $imageAlt ?: null, $authorName ?: 'TRAVSCOPE Team',
                    $metaTitle ?: null, $metaDescription ?: null,
                    $featured, $status, $publishedAt, $id
                ]);
                $blogId = $id;
            } else {
                $s = $pdo->prepare("
                    INSERT INTO blogs
                    (category_id,destination_id,package_id,title,slug,excerpt,content,
                     location_name,city,state_name,country,main_image,image_alt,author_name,
                     meta_title,meta_description,featured,status,published_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ");
                $s->execute([
                    $categoryId ?: null, $destinationId ?: null, $packageId ?: null,
                    $title, $slug, $excerpt ?: null, $content,
                    $locationName ?: null, $city ?: null, $stateName ?: null, $country ?: null,
                    $mainImage ?: null, $imageAlt ?: null, $authorName ?: 'TRAVSCOPE Team',
                    $metaTitle ?: null, $metaDescription ?: null,
                    $featured, $status, $publishedAt
                ]);
                $blogId = (int)$pdo->lastInsertId();
            }

            if (!empty($_FILES['gallery_files']['name']) && is_array($_FILES['gallery_files']['name'])) {
                $count = count($_FILES['gallery_files']['name']);

                $sortStmt = $pdo->prepare("SELECT COALESCE(MAX(sort_order),0) FROM blog_images WHERE blog_id=?");
                $sortStmt->execute([$blogId]);
                $sort = (int)$sortStmt->fetchColumn();

                $insertGallery = $pdo->prepare("
                    INSERT INTO blog_images (blog_id,image,alt_text,caption,location_name,sort_order)
                    VALUES (?,?,?,?,?,?)
                ");

                for ($i = 0; $i < $count; $i++) {
                    if (empty($_FILES['gallery_files']['name'][$i])) continue;

                    $one = [
                        'name' => $_FILES['gallery_files']['name'][$i],
                        'type' => $_FILES['gallery_files']['type'][$i] ?? '',
                        'tmp_name' => $_FILES['gallery_files']['tmp_name'][$i] ?? '',
                        'error' => $_FILES['gallery_files']['error'][$i] ?? UPLOAD_ERR_NO_FILE,
                        'size' => $_FILES['gallery_files']['size'][$i] ?? 0
                    ];

                    $path = blogAdminUploadImage($one, 'gallery');
                    if ($path) {
                        $sort++;
                        $insertGallery->execute([
                            $blogId,
                            $path,
                            $title,
                            null,
                            $locationName ?: null,
                            $sort
                        ]);
                    }
                }
            }


            $selectedLibraryGallery = $_POST['library_gallery_images'] ?? [];
            if (is_array($selectedLibraryGallery) && $selectedLibraryGallery) {
                $sortStmt = $pdo->prepare("SELECT COALESCE(MAX(sort_order),0) FROM blog_images WHERE blog_id=?");
                $sortStmt->execute([$blogId]);
                $sort = (int)$sortStmt->fetchColumn();

                $existingStmt = $pdo->prepare("SELECT image FROM blog_images WHERE blog_id=?");
                $existingStmt->execute([$blogId]);
                $existingPaths = $existingStmt->fetchAll(PDO::FETCH_COLUMN);

                $insertGallery = $pdo->prepare("
                    INSERT INTO blog_images (blog_id,image,alt_text,caption,location_name,sort_order)
                    VALUES (?,?,?,?,?,?)
                ");
                foreach (array_unique($selectedLibraryGallery) as $rawPath) {
                    $path = blogAdminValidMediaPath((string)$rawPath);
                    if (!$path || in_array($path,$existingPaths,true)) continue;
                    $insertGallery->execute([$blogId,$path,$title,null,$locationName?:null,++$sort]);
                    $existingPaths[]=$path;
                }
            }

            $pdo->commit();

            $_SESSION['admin_blogs_success'] = $id > 0
                ? 'Travel story updated successfully.'
                : 'Travel story created successfully.';

            header('Location: admin-blogs.php?action=edit&id=' . $blogId);
            exit;

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $e instanceof RuntimeException
                ? $e->getMessage()
                : 'The story could not be saved. ' . $e->getMessage();
        }
    }
}

$current = null;
$gallery = [];

if ($tableReady && $action === 'edit') {
    $id = (int)($_GET['id'] ?? 0);
    if ($id > 0) {
        $s = $pdo->prepare("SELECT * FROM blogs WHERE id=? LIMIT 1");
        $s->execute([$id]);
        $current = $s->fetch(PDO::FETCH_ASSOC) ?: null;

        if ($current) {
            $s = $pdo->prepare("SELECT * FROM blog_images WHERE blog_id=? ORDER BY sort_order ASC,id ASC");
            $s->execute([$id]);
            $gallery = $s->fetchAll(PDO::FETCH_ASSOC);
        }
    }
}

$blank = [
    'id'=>0,'category_id'=>'','destination_id'=>'','package_id'=>'',
    'title'=>'','slug'=>'','excerpt'=>'','content'=>'',
    'location_name'=>'','city'=>'','state_name'=>'','country'=>'',
    'main_image'=>'','image_alt'=>'','author_name'=>'TRAVSCOPE Team',
    'meta_title'=>'','meta_description'=>'','featured'=>0,
    'status'=>'draft','published_at'=>''
];
$form = $current ?: $blank;

$q = trim((string)($_GET['q'] ?? ''));
$statusFilter = strtolower(trim((string)($_GET['status'] ?? '')));
$categoryFilter = (int)($_GET['category'] ?? 0);
$rows = [];
$stats = ['total'=>0,'published'=>0,'draft'=>0,'featured'=>0];

if ($tableReady) {
    try {
        $stats['total'] = (int)$pdo->query("SELECT COUNT(*) FROM blogs")->fetchColumn();
        $stats['published'] = (int)$pdo->query("SELECT COUNT(*) FROM blogs WHERE status='published'")->fetchColumn();
        $stats['draft'] = (int)$pdo->query("SELECT COUNT(*) FROM blogs WHERE status='draft'")->fetchColumn();
        $stats['featured'] = (int)$pdo->query("SELECT COUNT(*) FROM blogs WHERE featured=1")->fetchColumn();

        if ($action === 'list') {
            $where = [];
            $params = [];

            if ($q !== '') {
                $where[] = "(b.title LIKE ? OR b.location_name LIKE ? OR b.city LIKE ? OR b.state_name LIKE ? OR b.country LIKE ?)";
                $like = '%' . $q . '%';
                array_push($params, $like,$like,$like,$like,$like);
            }
            if (in_array($statusFilter, ['draft','published','inactive'], true)) {
                $where[] = "b.status=?";
                $params[] = $statusFilter;
            }
            if ($categoryFilter > 0) {
                $where[] = "b.category_id=?";
                $params[] = $categoryFilter;
            }

            $sql = "
                SELECT b.*, c.name AS category_name, d.name AS destination_name, p.title AS package_title
                FROM blogs b
                LEFT JOIN blog_categories c ON c.id=b.category_id
                LEFT JOIN destinations d ON d.id=b.destination_id
                LEFT JOIN packages p ON p.id=b.package_id
            ";
            if ($where) $sql .= " WHERE " . implode(' AND ', $where);
            $sql .= " ORDER BY b.featured DESC, COALESCE(b.published_at,b.created_at) DESC,b.id DESC";

            $s = $pdo->prepare($sql);
            $s->execute($params);
            $rows = $s->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (Throwable $e) {
        $error = 'Blog tables could not be loaded. Please run blogs.sql first.';
    }
}

$pageTitle = $action === 'add' ? 'Add Travel Story' : ($action === 'edit' ? 'Edit Travel Story' : 'Travel Stories');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?= e($pageTitle); ?> | <?= e($siteName); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
:root{--navy:#07192d;--blue:#0b74ff;--bg:#f5f7fb;--white:#fff;--text:#172033;--muted:#778294;--border:#e5e9ef;--green:#0b9b63;--red:#d94457;--orange:#d97706;--shadow:0 10px 30px rgba(23,32,51,.06)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;font-size:15px;line-height:1.55}a{text-decoration:none;color:inherit}button,input,select,textarea{font:inherit}button{cursor:pointer}
.sidebar{position:fixed;inset:0 auto 0 0;width:265px;background:var(--navy);color:#fff;overflow-y:auto;z-index:1000;transition:.25s}.sidebar-logo{height:80px;padding:0 22px;display:flex;align-items:center;gap:10px;border-bottom:1px solid rgba(255,255,255,.08);font:800 20px 'Manrope'}.logo-icon{width:42px;height:42px;display:grid;place-items:center;border-radius:12px;background:var(--blue)}.sidebar-logo span{color:#65b7ff}.sidebar-menu{padding:17px 13px 30px}.menu-title{padding:15px 13px 7px;color:#657b92;font-size:11px;font-weight:800;letter-spacing:1px}.menu-link{min-height:46px;padding:0 14px;margin:3px 0;border-radius:9px;display:flex;align-items:center;gap:11px;color:#aebdcc;font-size:14px;font-weight:600}.menu-link:hover,.menu-link.active{background:rgba(11,116,255,.20);color:#fff}.menu-link i{width:20px;text-align:center}
.main{margin-left:265px;min-height:100vh}.topbar{min-height:76px;padding:0 28px;display:flex;align-items:center;justify-content:space-between;background:#fff;border-bottom:1px solid var(--border);position:sticky;top:0;z-index:800}.mobile-menu{display:none;width:42px;height:42px;border:1px solid var(--border);border-radius:9px;background:#fff}.admin{display:flex;align-items:center;gap:9px}.avatar{width:40px;height:40px;border-radius:10px;display:grid;place-items:center;background:var(--blue);color:#fff;font-weight:800}.admin strong{font-size:13px}.admin small{display:block;color:var(--muted);font-size:11px}.content{width:min(1320px,100%);margin:auto;padding:28px}.page-head{display:flex;align-items:flex-end;justify-content:space-between;gap:15px;margin-bottom:21px}.page-head h1{margin:0;font:800 28px 'Manrope';color:var(--navy)}.page-head p{margin:6px 0 0;color:var(--muted);font-size:14px}.button{min-height:44px;padding:0 16px;border:0;border-radius:9px;display:inline-flex;align-items:center;justify-content:center;gap:7px;font-size:13px;font-weight:800}.primary{background:var(--blue);color:#fff}.secondary{background:#fff;border:1px solid var(--border);color:#566478}.danger{background:#fff0f2;border:1px solid #efc2ca;color:#b52f42}
.alert{margin-bottom:17px;padding:13px 15px;border-radius:9px;font-size:13px}.alert.success{background:#eaf9f2;border:1px solid #bfe8d5;color:#08794f}.alert.error{background:#fff0f2;border:1px solid #f0c3ca;color:#a92d3f}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:19px}.stat{padding:18px;border:1px solid var(--border);border-radius:12px;background:#fff;box-shadow:var(--shadow)}.stat span{display:block;color:var(--muted);font-size:12px}.stat strong{display:block;margin-top:4px;font:800 25px 'Manrope';color:var(--navy)}
.card{background:#fff;border:1px solid var(--border);border-radius:13px;box-shadow:var(--shadow);overflow:hidden}.card-head{padding:17px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:13px}.card-head h2{margin:0;font:800 17px 'Manrope'}.filters{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.control{min-height:43px;padding:0 12px;border:1px solid var(--border);border-radius:8px;background:#fff;font-size:13px}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;min-width:1000px}th{padding:12px 15px;background:#fafbfd;color:#7c8797;text-align:left;font-size:11px;text-transform:uppercase}td{padding:14px 15px;border-top:1px solid var(--border);font-size:13px;vertical-align:middle}.story-cell{display:flex;align-items:center;gap:11px;min-width:300px}.story-thumb{width:70px;height:55px;border-radius:9px;overflow:hidden;background:#edf1f5;flex:0 0 70px}.story-thumb img{width:100%;height:100%;object-fit:cover}.story-cell strong{display:block;color:var(--navy);font-size:14px}.story-cell small{display:block;margin-top:3px;color:var(--muted);font-size:11px}.badge{display:inline-flex;padding:6px 9px;border-radius:20px;font-size:11px;font-weight:800}.published{background:#eaf9f2;color:#08794f}.draft{background:#fff4e6;color:#a7620a}.inactive{background:#fff0f2;color:#b52f42}.featured{background:#edf5ff;color:#0b67d1}.row-actions{display:flex;gap:6px}.row-actions .button{min-height:36px;padding:0 10px;font-size:12px}
.form-wrap{padding:21px}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.full{grid-column:1/-1}.form-group label{display:block;margin-bottom:7px;color:#526174;font-size:13px;font-weight:800}.form-control{width:100%;min-height:45px;padding:10px 12px;border:1px solid var(--border);border-radius:9px;outline:0;background:#fff;font-size:14px}.form-control:focus{border-color:#9ac8ff;box-shadow:0 0 0 3px rgba(11,116,255,.07)}textarea.form-control{min-height:110px;resize:vertical;line-height:1.65}.help{display:block;margin-top:5px;color:var(--muted);font-size:12px}.checks{display:flex;align-items:center;gap:9px}.image-preview{margin-top:10px;width:220px;height:145px;border:1px solid var(--border);border-radius:10px;overflow:hidden;background:#f1f4f7}.image-preview img{width:100%;height:100%;object-fit:cover}.gallery-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-top:12px}.gallery-item{border:1px solid var(--border);border-radius:10px;overflow:hidden;background:#fff}.gallery-item img{width:100%;height:105px;object-fit:cover}.gallery-item form{padding:7px}.gallery-item .button{width:100%;min-height:34px;font-size:11px}
.editor-shell{border:1px solid var(--border);border-radius:10px;overflow:hidden}.editor-toolbar{padding:8px;display:flex;gap:6px;flex-wrap:wrap;background:#f8fafc;border-bottom:1px solid var(--border)}.editor-tool{min-width:38px;min-height:38px;padding:0 10px;border:1px solid #dfe5ec;border-radius:7px;background:#fff;font-size:12px;font-weight:800}.editor{min-height:400px;padding:22px;outline:0;font-size:15px;line-height:1.8}.editor h2,.editor h3{color:var(--navy);font-family:'Manrope'}.source{width:100%;min-height:400px;padding:16px;border:0;display:none;background:#0f172a;color:#e2e8f0;font:13px/1.65 Consolas,monospace}.source.open{display:block}.editor.hidden{display:none}.form-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:19px;padding-top:17px;border-top:1px solid var(--border)}
.overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:900}.overlay.show{display:block}
@media(max-width:1050px){.stats{grid-template-columns:repeat(2,1fr)}.gallery-grid{grid-template-columns:repeat(3,1fr)}}
@media(max-width:900px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:translateX(0)}.main{margin-left:0}.mobile-menu{display:grid;place-items:center}}
@media(max-width:700px){.content{padding:14px}.page-head{align-items:stretch;flex-direction:column}.stats{grid-template-columns:1fr 1fr}.form-grid{grid-template-columns:1fr}.full{grid-column:auto}.gallery-grid{grid-template-columns:repeat(2,1fr)}.card-head{align-items:stretch;flex-direction:column}.filters,.filters .control,.filters .button{width:100%}.form-actions{flex-direction:column-reverse}.form-actions .button{width:100%}.editor{min-height:330px;padding:16px}.topbar{padding:0 14px}}
@media(max-width:430px){.stats{grid-template-columns:1fr}.gallery-grid{grid-template-columns:1fr}}

/* PACKAGE-STYLE BLOG IMAGE MANAGER */
.native-image-input{position:absolute!important;left:-9999px!important;width:1px!important;height:1px!important;opacity:0!important}
.image-action-row{display:flex;gap:10px;flex-wrap:wrap}
.image-choice-button,.pexels-launch{min-height:46px;padding:0 16px;border-radius:10px;border:1px dashed #9fc8fa;background:#f4f9ff;color:#0b74ff;font-weight:800}
.pexels-launch{border-style:solid;border-color:#bde8d9;background:#f1fbf7;color:#087a59}.image-choice-button.secondary,.pexels-launch.secondary{min-height:43px}
.chosen-image-panel{margin-top:10px;padding:12px;border:1px solid #cfe1f7;border-radius:10px;background:#f8fbff}.selected-thumbs,#mainChosenPreviewItems{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.selected-thumb{width:110px}.selected-thumb img{width:110px;height:75px;object-fit:cover;border-radius:8px;border:1px solid var(--border)}.selected-thumb small{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:10px}
.media-modal,.pexels-modal{display:none;position:fixed;inset:0;z-index:3000}.media-modal.open,.pexels-modal.open{display:block}.modal-backdrop{position:absolute;inset:0;background:rgba(7,25,45,.70)}.picker-dialog{position:relative;width:min(1120px,calc(100% - 30px));max-height:calc(100vh - 60px);margin:30px auto;background:#fff;border-radius:18px;overflow:hidden;display:flex;flex-direction:column}.picker-head{padding:18px 20px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;gap:12px;align-items:center}.picker-head h3{margin:0;font:800 19px Manrope}.picker-head p{margin:3px 0 0;color:var(--muted);font-size:12px}.picker-close{width:40px;height:40px;border:1px solid var(--border);border-radius:10px;background:#fff}.picker-tools{padding:12px 16px;border-bottom:1px solid var(--border);display:flex;gap:9px}.picker-tools input{flex:1;min-height:42px;border:1px solid var(--border);border-radius:9px;padding:0 12px}.picker-tools button{border:0;border-radius:9px;padding:0 15px;font-weight:800}.picker-upload{background:#0b74ff;color:#fff}.picker-grid{padding:10px 16px 18px;display:grid;grid-template-columns:repeat(6,1fr);gap:10px;overflow:auto}.picker-card{border:1px solid var(--border);border-radius:10px;padding:7px;background:#fff}.picker-card img{width:100%;height:112px;object-fit:cover;border-radius:7px}.picker-name{font-size:10px;margin:5px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.picker-select{width:100%;min-height:34px;border:1px solid #b9d6ff;border-radius:7px;background:#f4f9ff;color:#0568e8;font-size:11px;font-weight:800}.picker-card.selected{outline:3px solid #0b74ff;background:#edf6ff;box-shadow:0 0 0 3px rgba(11,116,255,.10)}
.picker-card.selected .picker-select{background:#0b74ff;color:#fff;border-color:#0b74ff}
.free-photo-provider-badge{position:absolute;top:8px;left:8px;z-index:4;padding:5px 8px;border-radius:999px;background:rgba(15,23,42,.84);color:#fff;font-size:10px;font-weight:900;letter-spacing:.04em;box-shadow:0 3px 10px rgba(15,23,42,.18)}
.pexels-card.selected{outline:3px solid #0b74ff;background:#edf6ff}
.pexels-grid{padding:10px 16px 18px;display:grid;grid-template-columns:repeat(5,1fr);gap:10px;overflow:auto}.pexels-card{border:1px solid var(--border);border-radius:10px;overflow:hidden;background:#fff;transition:.18s;cursor:pointer;position:relative}.pexels-card:hover{border-color:#8fc4ff;box-shadow:0 8px 22px rgba(11,116,255,.10);transform:translateY(-1px)}.pexels-photo-wrap{position:relative;overflow:hidden}.pexels-card img{width:100%;height:145px;object-fit:cover}.pexels-click-hint{position:absolute;left:0;right:0;bottom:0;padding:7px;background:linear-gradient(180deg,transparent,rgba(0,0,0,.72));color:#fff;font-size:10px;font-weight:800;text-align:center;opacity:0;transition:.18s;pointer-events:none}.pexels-card:hover .pexels-click-hint{opacity:1}.pexels-card-body{padding:8px}.pexels-photo-credit{min-height:34px;color:#657386;font-size:10px;line-height:1.45;overflow:hidden}.pexels-photo-credit a{color:#50647d;font-weight:700;text-decoration:none}.pexels-photo-credit a:hover{color:#0b74ff;text-decoration:underline}.pexels-photo-credit .slash{padding:0 3px;color:#9aa6b5}.pexels-photo-name{min-height:36px;margin-top:5px;color:#25364d;font-size:11px;line-height:1.45;font-weight:700;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.pexels-card button{width:100%;min-height:38px;margin-top:7px;border:0;border-radius:7px;background:#0aa36f;color:#fff;font-weight:800;font-size:11px}.pexels-card.selected{outline:3px solid #0b74ff;background:#edf6ff}.pexels-card.selected button{background:#087a59}.pexels-card.selected:after{content:'✓ Selected';position:absolute;top:8px;right:8px;z-index:3;padding:5px 8px;border-radius:20px;background:#087a59;color:#fff;font-size:10px;font-weight:800}.pexels-status{padding:8px 16px;color:#087a59;font-size:12px}.pexels-pagination{padding:10px 16px;border-top:1px solid var(--border);display:flex;justify-content:center;gap:10px;align-items:center}.pexels-pagination button{min-height:36px;padding:0 14px;border:1px solid var(--border);border-radius:8px;background:#fff}
.pexels-gallery-done-wrap{padding:12px 16px;border-top:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:12px;background:#fff;position:sticky;bottom:0;z-index:5}
.pexels-gallery-selected-count{color:#536174;font-size:12px;font-weight:700}
.pexels-gallery-selected-count i{color:#0b74ff;margin-right:5px}
.pexels-gallery-done{min-height:42px;padding:0 20px;border:0;border-radius:9px;background:#0b74ff;color:#fff;font-size:13px;font-weight:800;box-shadow:0 8px 18px rgba(11,116,255,.20)}
.pexels-gallery-done:hover{background:#075fd2}
@media(max-width:600px){.pexels-gallery-done-wrap{padding:10px 12px}.pexels-gallery-done{min-width:110px}}
@media(max-width:950px){.picker-grid{grid-template-columns:repeat(4,1fr)}.pexels-grid{grid-template-columns:repeat(3,1fr)}}
@media(max-width:600px){.picker-dialog{width:100%;height:100%;max-height:none;margin:0;border-radius:0}.picker-grid,.pexels-grid{grid-template-columns:repeat(2,1fr)}.image-action-row>*{width:100%}}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
}
.main > .content,
.main .content:first-child{
    width:auto!important;
    max-width:none!important;
    margin:0!important;
    padding:16px 18px 20px!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>
<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->





<div class="overlay" id="overlay"></div>
<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->



<main class="main">
<header class="topbar">
<div style="display:flex;align-items:center;gap:10px">

<strong>TRAVSCOPE Administration</strong>
</div>
<div class="admin"><div class="avatar"><?= e($adminInitial); ?></div><div><strong><?= e((string)($admin['name'] ?? 'Administrator')); ?></strong><small><?= e((string)($admin['role'] ?? 'Admin')); ?></small></div></div>
</header>

<div class="content">
<div class="page-head <?= $action === 'list' ? 'ts-content-hero' : ''; ?>">
<div class="ts-content-title">
<?php if ($action === 'list'): ?><span class="ts-eyebrow">CONTENT / EDITORIAL</span><?php endif; ?>
<h1><?= e($pageTitle); ?></h1><p>Manage destination stories, local experiences, travel guides and inspiration from one place.</p>
</div>
<div class="ts-content-head-side">
<?php if ($action === 'list'): ?>
<div class="ts-metric-row" aria-label="Travel story summary">
<div class="ts-metric blue"><span>Total Stories</span><strong><?= number_format($stats['total']); ?></strong></div>
<div class="ts-metric green"><span>Published</span><strong><?= number_format($stats['published']); ?></strong></div>
<div class="ts-metric amber"><span>Draft</span><strong><?= number_format($stats['draft']); ?></strong></div>
<div class="ts-metric violet"><span>Featured</span><strong><?= number_format($stats['featured']); ?></strong></div>
</div>
<?php endif; ?>
<div class="ts-head-actions">
<?php if ($action !== 'list'): ?><a href="admin-blogs.php" class="button secondary"><i class="fa-solid fa-arrow-left"></i> Back</a><?php endif; ?>
<?php if ($action === 'list' && $tableReady): ?><a href="admin-blogs.php?action=add" class="button primary"><i class="fa-solid fa-plus"></i> Add Travel Story</a><?php endif; ?>
</div>
</div>
</div>

<?php if (!$tableReady): ?><div class="alert error"><strong>Blog system is not installed.</strong> Run <b>blogs.sql</b> in your database first.</div><?php endif; ?>
<?php if ($success !== ''): ?><div class="alert success"><i class="fa-solid fa-circle-check"></i> <?= e($success); ?></div><?php endif; ?>
<?php if ($error !== ''): ?><div class="alert error"><i class="fa-solid fa-triangle-exclamation"></i> <?= e($error); ?></div><?php endif; ?>

<?php if ($action === 'list'): ?>
<section class="card ts-directory-card">
<div class="card-head">
<div><span class="ts-section-kicker">STORY DIRECTORY</span><h2>All Travel Stories</h2><p class="ts-section-copy"><?= number_format(count($rows)); ?> record(s) in this view</p></div>
<form method="get" class="filters ts-directory-filters">
<input type="search" class="control" name="q" value="<?= e($q); ?>" placeholder="Search title/location...">
<select name="category" class="control"><option value="0">All Categories</option><?php foreach($categories as $c): ?><option value="<?= (int)$c['id']; ?>" <?= $categoryFilter===(int)$c['id']?'selected':''; ?>><?= e($c['name']); ?></option><?php endforeach; ?></select>
<select name="status" class="control"><option value="">All Status</option><option value="published" <?= $statusFilter==='published'?'selected':''; ?>>Published</option><option value="draft" <?= $statusFilter==='draft'?'selected':''; ?>>Draft</option><option value="inactive" <?= $statusFilter==='inactive'?'selected':''; ?>>Inactive</option></select>
<button class="button primary" type="submit">Filter</button>
</form>
</div>

<?php if($rows): ?>
<div class="table-wrap"><table>
<thead><tr><th>Story</th><th>Category</th><th>Location</th><th>Status</th><th>Views</th><th>Published</th><th>Actions</th></tr></thead>
<tbody>
<?php foreach($rows as $r): ?>
<tr>
<td><div class="story-cell"><div class="story-thumb"><?php if(!empty($r['main_image'])): ?><img src="<?= e(blogAdminImageUrl($r['main_image'])); ?>" alt=""><?php endif; ?></div><div><strong><?= e($r['title']); ?></strong><small><?= e(blogAdminExcerpt((string)($r['excerpt'] ?: $r['content']))); ?></small><?php if((int)$r['featured']===1): ?><span class="badge featured">Featured</span><?php endif; ?></div></div></td>
<td><?= e((string)($r['category_name'] ?: 'Uncategorised')); ?></td>
<td><?= e((string)($r['location_name'] ?: $r['destination_name'] ?: $r['state_name'] ?: $r['country'] ?: '—')); ?></td>
<td><span class="badge <?= e($r['status']); ?>"><?= e(ucfirst($r['status'])); ?></span></td>
<td><?= number_format((int)$r['views']); ?></td>
<td><?= !empty($r['published_at']) ? e(date('d M Y', strtotime($r['published_at']))) : '—'; ?></td>
<td><div class="row-actions"><a href="admin-blogs.php?action=edit&id=<?= (int)$r['id']; ?>" class="button secondary"><i class="fa-solid fa-pen"></i> Edit</a><?php if($r['status']==='published'): ?><a href="blog-details.php?slug=<?= urlencode($r['slug']); ?>" target="_blank" class="button secondary"><i class="fa-regular fa-eye"></i></a><?php endif; ?><form method="post"><input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>"><input type="hidden" name="form_action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id']; ?>"><button class="button danger" type="submit"><i class="fa-solid fa-trash"></i></button></form></div></td>
</tr>
<?php endforeach; ?>
</tbody>
</table></div>
<?php else: ?><div style="padding:45px;text-align:center;color:var(--muted)">No travel stories found.</div><?php endif; ?>
</section>

<?php else: ?>
<section class="card">
<div class="card-head"><div><h2><?= $action==='add'?'Create Travel Story':'Update Travel Story'; ?></h2></div></div>

<form method="post" enctype="multipart/form-data" class="form-wrap" id="storyForm">
<input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
<input type="hidden" name="id" value="<?= (int)$form['id']; ?>">

<div class="form-grid">
<div class="form-group"><label>Story Title *</label><input class="form-control" type="text" name="title" required value="<?= e((string)$form['title']); ?>"></div>
<div class="form-group"><label>Slug</label><input class="form-control" type="text" name="slug" value="<?= e((string)$form['slug']); ?>" placeholder="automatic-from-title"><span class="help">Leave blank to generate automatically.</span></div>

<div class="form-group"><label>Category</label><select class="form-control" name="category_id"><option value="">Select category</option><?php foreach($categories as $c): ?><option value="<?= (int)$c['id']; ?>" <?= (int)$form['category_id']===(int)$c['id']?'selected':''; ?>><?= e($c['name']); ?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Destination</label><select class="form-control" name="destination_id"><option value="">Select destination</option><?php foreach($destinations as $d): ?><option value="<?= (int)$d['id']; ?>" <?= (int)$form['destination_id']===(int)$d['id']?'selected':''; ?>><?= e($d['name'] . (!empty($d['country'])?' — '.$d['country']:'')); ?></option><?php endforeach; ?></select></div>

<div class="form-group"><label>Specific Location / Attraction</label><input class="form-control" type="text" name="location_name" value="<?= e((string)$form['location_name']); ?>" placeholder="e.g. Dashashwamedh Ghat"></div>
<div class="form-group"><label>Related Package</label><select class="form-control" name="package_id"><option value="">No related package</option><?php foreach($packages as $p): ?><option value="<?= (int)$p['id']; ?>" <?= (int)$form['package_id']===(int)$p['id']?'selected':''; ?>><?= e($p['title']); ?></option><?php endforeach; ?></select></div>

<div class="form-group"><label>City</label><input class="form-control" type="text" name="city" value="<?= e((string)$form['city']); ?>"></div>
<div class="form-group"><label>State / Region</label><input class="form-control" type="text" name="state_name" value="<?= e((string)$form['state_name']); ?>"></div>
<div class="form-group"><label>Country</label><input class="form-control" type="text" name="country" value="<?= e((string)$form['country']); ?>"></div>
<div class="form-group"><label>Author</label><input class="form-control" type="text" name="author_name" value="<?= e((string)$form['author_name']); ?>"></div>

<div class="form-group full"><label>Short Description / Excerpt</label><textarea class="form-control" name="excerpt" placeholder="Short introduction shown on blog cards..."><?= e((string)$form['excerpt']); ?></textarea></div>

<div class="form-group full">
<label>Travel Story Content *</label>
<div class="editor-shell">
<div class="editor-toolbar">
<button type="button" class="editor-tool" data-command="formatBlock" data-value="H2">H2</button>
<button type="button" class="editor-tool" data-command="formatBlock" data-value="H3">H3</button>
<button type="button" class="editor-tool" data-command="formatBlock" data-value="P">P</button>
<button type="button" class="editor-tool" data-command="bold"><i class="fa-solid fa-bold"></i></button>
<button type="button" class="editor-tool" data-command="italic"><i class="fa-solid fa-italic"></i></button>
<button type="button" class="editor-tool" data-command="insertUnorderedList"><i class="fa-solid fa-list-ul"></i></button>
<button type="button" class="editor-tool" data-command="insertOrderedList"><i class="fa-solid fa-list-ol"></i></button>
<button type="button" class="editor-tool" id="sourceToggle"><i class="fa-solid fa-code"></i> HTML</button>
</div>
<div id="visualEditor" class="editor" contenteditable="true"></div>
<textarea id="sourceEditor" class="source"></textarea>
</div>
<textarea id="contentField" name="content" required style="position:absolute;left:-9999px;width:1px;height:1px;opacity:0"><?= e((string)$form['content']); ?></textarea>
<span class="help">Paste formatted HTML or write normally. Headings, paragraphs, bold text and lists are preserved.</span>
</div>

<div class="form-group full blog-image-manager">
<label>Main Blog Image</label>
<input type="hidden" name="library_main_image" id="libraryMainImage">
<input type="file" name="main_image_file" id="mainImageFile" class="native-image-input" accept="image/jpeg,image/png,image/webp">
<div class="image-action-row">
<button type="button" class="image-choice-button open-media-picker" data-mode="main"><i class="fa-regular fa-images"></i> Choose Photo</button>
<button type="button" class="pexels-launch open-pexels-picker" data-mode="main"><i class="fa-solid fa-magnifying-glass"></i> Search Pexels + Unsplash</button>
</div>
<div class="chosen-image-panel" id="mainChosenPreview" hidden><strong>Selected Main Image</strong><div id="mainChosenPreviewItems"></div></div>
<span class="help">Computer / PC, existing Web Gallery, or combined Pexels + Unsplash search. Pexels selections are optimized into Web Gallery; Unsplash selections keep the official hotlinked source.</span>
</div>

<div class="form-group"><label>Or Main Image URL</label><input class="form-control" type="url" name="main_image_url" placeholder="https://..." value="<?= preg_match('#^https?://#i',(string)$form['main_image']) ? e((string)$form['main_image']) : ''; ?>"></div>
<div class="form-group"><label>Image Alt Text</label><input class="form-control" type="text" name="image_alt" value="<?= e((string)$form['image_alt']); ?>"></div>

<div class="form-group full blog-image-manager">
<label>Additional Blog Images</label>
<input type="file" name="gallery_files[]" id="galleryFiles" class="native-image-input" accept="image/jpeg,image/png,image/webp" multiple>
<div class="image-action-row">
<button type="button" class="image-choice-button secondary open-media-picker" data-mode="gallery"><i class="fa-regular fa-images"></i> Choose Gallery Photos</button>
<button type="button" class="pexels-launch secondary open-pexels-picker" data-mode="gallery"><i class="fa-solid fa-magnifying-glass"></i> Search Pexels + Unsplash</button>
</div>
<div id="libraryGalleryInputs"></div>
<div class="chosen-image-panel" id="galleryChosenPreview" hidden><strong>Selected Additional Images</strong><div id="galleryChosenPreviewItems" class="selected-thumbs"></div></div>
<span class="help">Select multiple photos from PC, Web Gallery, Pexels or Unsplash.</span>
</div>

<?php if(!empty($form['main_image'])): ?>
<div class="form-group full"><label>Current Main Image</label><div class="image-preview"><img src="<?= e(blogAdminImageUrl($form['main_image'])); ?>" alt=""></div><label class="checks" style="margin-top:8px"><input type="checkbox" name="remove_main_image" value="1"> Remove current main image</label></div>
<?php endif; ?>

<?php if($gallery): ?>
<div class="form-group full">
    <label>Current Gallery</label>

    <div class="gallery-grid">
        <?php foreach($gallery as $g): ?>
            <div class="gallery-item">
                <img
                    src="<?= e(blogAdminImageUrl($g['image'])); ?>"
                    alt="<?= e((string)($g['alt_text'] ?? $form['title'])); ?>"
                >

                <div style="padding:7px;">
                    <button
                        class="button danger"
                        type="submit"
                        name="delete_gallery_image_id"
                        value="<?= (int)$g['id']; ?>"
                        formnovalidate

                    >
                        <i class="fa-solid fa-trash"></i>
                        Remove
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<div class="form-group"><label>Meta Title</label><input class="form-control" type="text" name="meta_title" value="<?= e((string)$form['meta_title']); ?>"></div>
<div class="form-group"><label>Meta Description</label><textarea class="form-control" name="meta_description"><?= e((string)$form['meta_description']); ?></textarea></div>

<div class="form-group"><label>Status</label><select class="form-control" name="status"><option value="draft" <?= $form['status']==='draft'?'selected':''; ?>>Draft</option><option value="published" <?= $form['status']==='published'?'selected':''; ?>>Published</option><option value="inactive" <?= $form['status']==='inactive'?'selected':''; ?>>Inactive</option></select></div>
<div class="form-group"><label>Publish Date / Time</label><input class="form-control" type="datetime-local" name="published_at" value="<?= !empty($form['published_at']) ? e(date('Y-m-d\TH:i',strtotime($form['published_at']))) : ''; ?>"></div>
<div class="form-group full"><label class="checks"><input type="checkbox" name="featured" value="1" <?= (int)$form['featured']===1?'checked':''; ?>> Featured Travel Story</label></div>
</div>

<div class="form-actions">
<a href="admin-blogs.php" class="button secondary">Cancel</a>
<button
    class="button primary"
    type="submit"
    name="form_action"
    value="save"
    id="saveTravelStoryButton"
>
    <i class="fa-solid fa-floppy-disk"></i>
    Save Travel Story
</button>
</div>
</form>
</section>
<?php endif; ?>
</div>
</main>


<!-- Package-style Web Gallery -->
<div class="media-modal" id="mediaModal" aria-hidden="true">
<div class="modal-backdrop" data-close-media></div>
<div class="picker-dialog">
  <div class="picker-head"><div><h3 id="mediaTitle">Choose Main Image</h3><p>Search by image name and click a photo to use it.</p></div><button type="button" class="picker-close" data-close-media><i class="fa-solid fa-xmark"></i></button></div>
  <div class="picker-tools"><input type="search" id="mediaSearch" placeholder="Search photo by image name..."><button type="button" class="picker-upload" id="mediaUploadPc"><i class="fa-solid fa-cloud-arrow-up"></i> Computer / PC</button></div>
  <div class="picker-grid" id="mediaGrid">
  <?php foreach($blogMediaLibrary as $m): ?>
    <div class="picker-card" data-name="<?= e(strtolower($m['name'])); ?>" data-image="<?= e($m['image']); ?>">
      <img src="<?= e(blogAdminImageUrl($m['image'])); ?>" alt="<?= e($m['name']); ?>">
      <div class="picker-name" title="<?= e($m['name']); ?>"><?= e($m['name']); ?></div>
      <button type="button" class="picker-select" data-image="<?= e($m['image']); ?>" data-url="<?= e(blogAdminImageUrl($m['image'])); ?>" data-name="<?= e($m['name']); ?>">Choose Photo</button>
    </div>
  <?php endforeach; ?>
  </div>
</div>
</div>


<style>
/* =====================================================================
   TRAVSCOPE V24.29 — GLOBAL FAIR PHOTO PICKER
   Equal comparison cards + clean pagination across every API photo search.
   ===================================================================== */
#pexelsResults.pexels-results,
#pexelsGrid.pexels-grid,
#crmMediaGrid.crm-media-grid{
    display:grid !important;
    grid-template-columns:repeat(auto-fill,minmax(180px,1fr)) !important;
    grid-auto-flow:row !important;
    grid-auto-rows:1fr !important;
    align-items:stretch !important;
    align-content:start !important;
    gap:14px !important;
    padding:16px !important;
}
#pexelsResults.pexels-results,
#pexelsGrid.pexels-grid{max-height:56vh;overflow-y:auto !important;overflow-x:hidden !important}
.pexels-photo-card,
.pexels-card,
.crm-media-item[data-provider]{
    position:relative !important;
    display:flex !important;
    flex-direction:column !important;
    width:100% !important;
    height:100% !important;
    min-height:310px !important;
    margin:0 !important;
    overflow:hidden !important;
    border:1px solid #dbe4ef !important;
    border-radius:14px !important;
    background:#fff !important;
    box-shadow:0 6px 18px rgba(15,23,42,.07) !important;
    transition:transform .18s ease,border-color .18s ease,box-shadow .18s ease !important;
}
.pexels-photo-card:hover,
.pexels-card:hover,
.crm-media-item[data-provider]:hover{
    transform:translateY(-2px) !important;
    border-color:#93c5fd !important;
    box-shadow:0 12px 28px rgba(37,99,235,.13) !important;
}
.pexels-photo-image,
.pexels-photo-wrap{
    position:relative !important;
    width:100% !important;
    height:158px !important;
    min-height:158px !important;
    aspect-ratio:auto !important;
    overflow:hidden !important;
    background:#eef2f7 !important;
    flex:0 0 158px !important;
}
.pexels-photo-image img,
.pexels-photo-wrap img,
.crm-media-item[data-provider] > img{
    display:block !important;
    width:100% !important;
    height:158px !important;
    min-height:158px !important;
    max-height:158px !important;
    object-fit:cover !important;
    object-position:center !important;
    margin:0 !important;
    padding:0 !important;
    border:0 !important;
}
.pexels-photo-body,
.pexels-card-body,
.crm-media-item[data-provider] .crm-media-item-body{
    display:flex !important;
    flex:1 1 auto !important;
    flex-direction:column !important;
    padding:10px !important;
    background:#fff !important;
}
.pexels-photo-credit,
.crm-media-item[data-provider] .crm-free-credit{
    min-height:30px !important;
    margin:0 0 6px !important;
    padding:0 !important;
    color:#64748b !important;
    font-size:9px !important;
    line-height:1.4 !important;
}
.pexels-photo-name,
.crm-media-item[data-provider] .crm-media-item-name{
    min-height:36px !important;
    margin:0 0 8px !important;
    color:#1e293b !important;
    font-size:11px !important;
    font-weight:800 !important;
    line-height:1.45 !important;
    white-space:normal !important;
    display:-webkit-box !important;
    -webkit-line-clamp:2 !important;
    -webkit-box-orient:vertical !important;
    overflow:hidden !important;
}
.pexels-import-button,
.pexels-card button,
.crm-media-item[data-provider] .crm-media-select{
    width:100% !important;
    min-height:38px !important;
    margin-top:auto !important;
    border:0 !important;
    border-radius:9px !important;
    background:linear-gradient(135deg,#0f766e,#10b981) !important;
    color:#fff !important;
    font-size:10px !important;
    font-weight:900 !important;
    cursor:pointer !important;
}
.free-photo-provider-badge,
.crm-provider-badge{
    border:0 !important;
    color:#fff !important;
    font-weight:900 !important;
    box-shadow:0 4px 12px rgba(15,23,42,.22) !important;
}
.free-photo-provider-badge.pexels,
[data-provider="pexels"] .free-photo-provider-badge,
.crm-provider-badge.pexels{background:#0f766e !important;color:#fff !important}
.free-photo-provider-badge.unsplash,
[data-provider="unsplash"] .free-photo-provider-badge,
.crm-provider-badge.unsplash{background:#111827 !important;color:#fff !important}
.pexels-click-hint{display:none !important}
.pexels-pagination,
.ts-photo-pagination,
.crm-photo-pagination{
    flex:0 0 auto !important;
    display:flex !important;
    align-items:center !important;
    justify-content:center !important;
    gap:14px !important;
    min-height:58px !important;
    padding:10px 16px !important;
    border-top:1px solid #e2e8f0 !important;
    background:#fff !important;
    color:#64748b !important;
    font-size:12px !important;
}
.pexels-pagination[hidden],
.ts-photo-pagination[hidden],
.crm-photo-pagination[hidden]{display:none !important}
.pexels-pagination button,
.ts-photo-pagination button,
.crm-photo-pagination button{
    min-height:38px !important;
    padding:0 15px !important;
    border:1px solid #d7e0eb !important;
    border-radius:9px !important;
    background:#fff !important;
    color:#183153 !important;
    font-size:11px !important;
    font-weight:900 !important;
    cursor:pointer !important;
}
.pexels-pagination button:hover:not(:disabled),
.ts-photo-pagination button:hover:not(:disabled),
.crm-photo-pagination button:hover:not(:disabled){background:#eff6ff !important;border-color:#93c5fd !important;color:#1d4ed8 !important}
.pexels-pagination button:disabled,
.ts-photo-pagination button:disabled,
.crm-photo-pagination button:disabled{opacity:.42 !important;cursor:not-allowed !important}
.pexels-pagination span,
.ts-photo-pagination span,
.crm-photo-pagination span{min-width:125px;text-align:center;font-weight:800;color:#64748b}
@media(max-width:900px){
    #pexelsResults.pexels-results,#pexelsGrid.pexels-grid,#crmMediaGrid.crm-media-grid{grid-template-columns:repeat(3,minmax(0,1fr)) !important}
}
@media(max-width:620px){
    #pexelsResults.pexels-results,#pexelsGrid.pexels-grid,#crmMediaGrid.crm-media-grid{grid-template-columns:repeat(2,minmax(0,1fr)) !important;padding:10px !important;gap:10px !important}
    .pexels-photo-image,.pexels-photo-wrap,.pexels-photo-image img,.pexels-photo-wrap img,.crm-media-item[data-provider] > img{height:135px !important;min-height:135px !important;max-height:135px !important;flex-basis:135px !important}
}

/* TRAVSCOPE V24.76 — International Content Management / Travel Stories */
.ts-content-hero{align-items:center!important;padding:18px 18px 18px 20px!important;margin-bottom:16px!important;background:linear-gradient(120deg,#fff 0%,#f7fbff 100%)!important;border:1px solid #dbe7f4!important;border-left:4px solid #0ea5e9!important;border-radius:14px!important;box-shadow:0 8px 24px rgba(15,23,42,.045)!important}
.ts-content-title{min-width:260px}.ts-eyebrow,.ts-section-kicker{display:block;margin-bottom:3px;color:#1677ff;font-size:10px;font-weight:900;letter-spacing:.8px;text-transform:uppercase}.ts-content-hero h1{font-size:26px!important}.ts-content-hero p{margin-top:3px!important;font-size:12px!important}.ts-content-head-side{margin-left:auto;display:flex;align-items:center;justify-content:flex-end;gap:10px;flex-wrap:wrap}.ts-metric-row{display:flex;gap:7px;flex-wrap:wrap;justify-content:flex-end}.ts-metric{position:relative;min-width:102px;padding:8px 10px 8px 12px;background:#fff;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden}.ts-metric:before{content:"";position:absolute;left:0;top:0;bottom:0;width:3px;background:#2563eb}.ts-metric.green:before{background:#10b981}.ts-metric.amber:before{background:#f59e0b}.ts-metric.violet:before{background:#8b5cf6}.ts-metric span{display:block;color:#64748b;font-size:8px;font-weight:800;text-transform:uppercase;letter-spacing:.45px}.ts-metric strong{display:block;margin-top:2px;color:#0f2744;font:800 18px 'Manrope',sans-serif}.ts-head-actions{display:flex;gap:7px}.ts-directory-card{border-radius:13px!important}.ts-directory-card .card-head{padding:13px 14px!important;background:#fff}.ts-directory-card .card-head h2{font-size:16px!important}.ts-section-copy{margin:2px 0 0;color:#8190a5;font-size:10px}.ts-directory-filters{margin-left:auto;justify-content:flex-end}.ts-directory-filters .control{min-height:38px!important;font-size:11px!important}.ts-directory-filters .button{min-height:38px!important}.ts-directory-card th{padding-top:10px!important;padding-bottom:10px!important}.ts-directory-card td{padding-top:10px!important;padding-bottom:10px!important}.ts-directory-card .story-thumb{width:58px!important;height:46px!important;flex-basis:58px!important}.ts-directory-card .story-cell{min-width:280px!important}.ts-directory-card .row-actions .button{min-height:32px!important}
@media(max-width:1100px){.ts-content-hero{align-items:flex-start!important}.ts-content-head-side{width:100%;justify-content:space-between}.ts-metric-row{justify-content:flex-start}}
@media(max-width:760px){.ts-content-hero{padding:14px!important}.ts-content-head-side{align-items:stretch;flex-direction:column}.ts-metric-row{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));width:100%}.ts-metric{min-width:0}.ts-head-actions .button{width:100%}.ts-directory-filters{width:100%}}
</style>

<!-- Pexels Royalty-Free Search -->
<div class="pexels-modal" id="pexelsModal" aria-hidden="true">
<div class="modal-backdrop" data-close-pexels></div>
<div class="picker-dialog">
  <div class="picker-head"><div><h3>Search Pexels + Unsplash</h3><p>Search Pexels and Unsplash together. Pexels photos are saved to Web Gallery; Unsplash photos keep their official source URL.</p></div><button type="button" class="picker-close" data-close-pexels><i class="fa-solid fa-xmark"></i></button></div>
  <div class="picker-tools"><input type="search" id="pexelsSearch" placeholder="Example: Bali beach, Konark temple, Nepal mountains"><button type="button" class="picker-upload" id="pexelsSearchBtn">Search Photos</button></div>
  <div class="pexels-status" id="pexelsStatus">Official Pexels and Unsplash API results are combined automatically.</div>
  <div class="pexels-grid" id="pexelsGrid"></div>
  <div class="pexels-pagination">
    <button type="button" id="pexelsPrev">Previous</button>
    <span id="pexelsPage">Page 1</span>
    <button type="button" id="pexelsNext">Next</button>
  </div>

  <div class="pexels-gallery-done-wrap" id="pexelsGalleryDoneWrap" hidden>
    <div class="pexels-gallery-selected-count">
      <i class="fa-solid fa-images"></i>
      <span id="pexelsGallerySelectedCount">0</span>
      photo(s) selected
    </div>

    <button type="button" class="pexels-gallery-done" id="pexelsGalleryDone">
      <i class="fa-solid fa-circle-check"></i>
      Done
    </button>
  </div>
</div>
</div>

<script>
const sidebar=document.getElementById('sidebar'),overlay=document.getElementById('overlay'),mobileMenu=document.getElementById('mobileMenu');
mobileMenu?.addEventListener('click',()=>{sidebar.classList.toggle('open');overlay.classList.toggle('show')});
overlay?.addEventListener('click',()=>{sidebar.classList.remove('open');overlay.classList.remove('show')});

(function(){
 const form=document.getElementById('storyForm');
 const hidden=document.getElementById('contentField');
 const visual=document.getElementById('visualEditor');
 const source=document.getElementById('sourceEditor');
 const toggle=document.getElementById('sourceToggle');
 if(!hidden||!visual||!source)return;
 visual.innerHTML=hidden.value||''; source.value=hidden.value||'';
 const syncV=()=>{hidden.value=visual.innerHTML.trim();source.value=hidden.value};
 const syncS=()=>{visual.innerHTML=source.value;hidden.value=source.value.trim()};
 visual.addEventListener('input',syncV);
 visual.addEventListener('paste',e=>{
   const cb=e.clipboardData;if(!cb)return;
   const html=cb.getData('text/html'),plain=cb.getData('text/plain');
   const looks=/<(h[1-6]|p|ul|ol|li|strong|b|em|i|a|br|div|blockquote)\b/i.test(plain||'');
   if(html){e.preventDefault();document.execCommand('insertHTML',false,html);syncV()}
   else if(plain&&looks){e.preventDefault();document.execCommand('insertHTML',false,plain);syncV()}
 });
 source.addEventListener('input',()=>hidden.value=source.value.trim());
 document.querySelectorAll('.editor-tool[data-command]').forEach(btn=>btn.addEventListener('click',()=>{
   if(source.classList.contains('open'))return;
   visual.focus();const cmd=btn.dataset.command,val=btn.dataset.value||null;
   document.execCommand(cmd,false,cmd==='formatBlock'&&val?'<'+val.toLowerCase()+'>':val);syncV();
 }));
 toggle?.addEventListener('click',()=>{
   if(source.classList.contains('open')){syncS();source.classList.remove('open');visual.classList.remove('hidden')}
   else{syncV();source.classList.add('open');visual.classList.add('hidden')}
 });
 form?.addEventListener('submit',e=>{source.classList.contains('open')?syncS():syncV();if(!hidden.value.trim()){e.preventDefault();alert('Travel Story Content is required.')}});
})();

(function(){
    const form = document.getElementById('storyForm');
    if (!form) return;

    const mediaModal = document.getElementById('mediaModal');
    const pexelsModal = document.getElementById('pexelsModal');

    const pexelsGalleryDoneWrap =
        document.getElementById('pexelsGalleryDoneWrap');

    const pexelsGalleryDone =
        document.getElementById('pexelsGalleryDone');

    const pexelsGallerySelectedCount =
        document.getElementById('pexelsGallerySelectedCount');

    const mainInput = document.getElementById('libraryMainImage');
    const mainPanel = document.getElementById('mainChosenPreview');
    const mainItems = document.getElementById('mainChosenPreviewItems');

    const galleryPanel = document.getElementById('galleryChosenPreview');
    const galleryItems = document.getElementById('galleryChosenPreviewItems');

    const mediaTitle = document.getElementById('mediaTitle');
    const mediaSearch = document.getElementById('mediaSearch');
    const mediaGrid = document.getElementById('mediaGrid');

    let mode = 'main';
    let pexelsPage = 1;
    let pexelsQuery = '';
    let hasNext = false;

    /*
    |--------------------------------------------------------------------------
    | SAFE HELPERS
    |--------------------------------------------------------------------------
    | Do not depend on CSS.escape. This keeps selection working across browsers.
    */

    function allGalleryHiddenInputs() {
        return Array.from(
            form.querySelectorAll('input[name="library_gallery_images[]"]')
        );
    }

    function findGalleryInput(imagePath) {
        return allGalleryHiddenInputs().find(function(input){
            return input.value === imagePath;
        }) || null;
    }

    function galleryIsSelected(imagePath) {
        return !!findGalleryInput(imagePath);
    }

    function updatePexelsGalleryDoneState() {
        const count = allGalleryHiddenInputs().length;

        if (pexelsGallerySelectedCount) {
            pexelsGallerySelectedCount.textContent = String(count);
        }

        if (pexelsGalleryDoneWrap) {
            pexelsGalleryDoneWrap.hidden =
                mode !== 'gallery';
        }
    }

    function addGalleryHiddenInput(imagePath) {
        if (!imagePath || galleryIsSelected(imagePath)) {
            return;
        }

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'library_gallery_images[]';
        input.value = imagePath;
        input.className = 'media-gallery-hidden';

        /*
        | Exact package-style behavior:
        | append the selected image directly to the real story form.
        */
        form.appendChild(input);
    }

    function removeGalleryHiddenInput(imagePath) {
        const input = findGalleryInput(imagePath);

        if (input) {
            input.remove();
        }
    }

    function escapeHtml(value) {
        return String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function fileNameFromPath(path) {
        const pieces = String(path || '').split('/');
        return pieces[pieces.length - 1] || 'Selected photo';
    }

    function setMainPreview(imagePath, imageUrl, imageName) {
        if (mainInput) {
            mainInput.value = imagePath;
        }

        if (mainItems) {
            mainItems.innerHTML = `
                <div class="selected-thumb">
                    <img src="${escapeHtml(imageUrl)}" alt="${escapeHtml(imageName)}">
                    <small>${escapeHtml(imageName)}</small>
                </div>
            `;
        }

        if (mainPanel) {
            mainPanel.hidden = false;
        }

        refreshWebGalleryCards();
    }

    function refreshGalleryPreview() {
        if (!galleryItems || !galleryPanel) return;

        galleryItems.innerHTML = '';

        allGalleryHiddenInputs().forEach(function(input){
            const card = Array.from(
                document.querySelectorAll('#mediaGrid .picker-card')
            ).find(function(item){
                return (item.dataset.image || '') === input.value;
            });

            const url =
                card?.querySelector('img')?.src
                || (
                    <?= json_encode(BASE_URL, JSON_UNESCAPED_SLASHES); ?>
                    + String(input.value).replace(/^\/+/, '')
                );

            const name =
                card?.querySelector('.picker-name')?.textContent?.trim()
                || fileNameFromPath(input.value);

            const item = document.createElement('div');
            item.className = 'selected-thumb';
            item.dataset.image = input.value;
            item.innerHTML = `
                <img src="${escapeHtml(url)}" alt="${escapeHtml(name)}">
                <small>${escapeHtml(name)}</small>
            `;

            galleryItems.appendChild(item);
        });

        galleryPanel.hidden = allGalleryHiddenInputs().length === 0;
    }

    function selectGalleryImage(imagePath, imageUrl, imageName) {
        if (!imagePath) return;

        if (galleryIsSelected(imagePath)) {
            removeGalleryHiddenInput(imagePath);
        } else {
            addGalleryHiddenInput(imagePath);
        }

        refreshGalleryPreview();
        refreshWebGalleryCards();
    }

    function refreshWebGalleryCards() {
        document.querySelectorAll('#mediaGrid .picker-card').forEach(function(card){
            const path = card.dataset.image || '';
            const button = card.querySelector('.picker-select');

            if (mode === 'main') {
                const selected =
                    !!mainInput
                    && mainInput.value === path;

                card.classList.toggle('selected', selected);

                if (button) {
                    button.textContent =
                        selected
                            ? 'Selected'
                            : 'Choose Photo';
                }
            } else {
                const selected = galleryIsSelected(path);

                card.classList.toggle('selected', selected);

                if (button) {
                    button.textContent =
                        selected
                            ? 'Remove Photo'
                            : 'Add to Gallery';
                }
            }
        });
    }

    function chooseImage(imagePath, imageUrl, imageName) {
        if (!imagePath) return;

        if (mode === 'main') {
            setMainPreview(
                imagePath,
                imageUrl,
                imageName || fileNameFromPath(imagePath)
            );

            closeMedia();
            closePexels();
            return;
        }

        selectGalleryImage(
            imagePath,
            imageUrl,
            imageName || fileNameFromPath(imagePath)
        );
    }

    /*
    |--------------------------------------------------------------------------
    | WEB GALLERY
    |--------------------------------------------------------------------------
    */

    function openMedia(newMode) {
        mode = newMode === 'gallery' ? 'gallery' : 'main';

        if (mediaTitle) {
            mediaTitle.textContent =
                mode === 'main'
                    ? 'Choose Main Image'
                    : 'Choose Blog Gallery Photos';
        }

        if (mediaSearch) {
            mediaSearch.value = '';
        }

        document.querySelectorAll('#mediaGrid .picker-card').forEach(function(card){
            card.style.display = '';
        });

        refreshWebGalleryCards();

        mediaModal?.classList.add('open');
        mediaModal?.setAttribute('aria-hidden', 'false');

        document.body.classList.add('media-modal-open');

        setTimeout(function(){
            mediaSearch?.focus();
        }, 50);
    }

    function closeMedia() {
        mediaModal?.classList.remove('open');
        mediaModal?.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('media-modal-open');
    }

    document.querySelectorAll('.open-media-picker').forEach(function(button){
        button.addEventListener('click', function(event){
            event.preventDefault();
            openMedia(button.dataset.mode || 'main');
        });
    });

    document.querySelectorAll('[data-close-media]').forEach(function(button){
        button.addEventListener('click', closeMedia);
    });

    mediaSearch?.addEventListener('input', function(){
        const q = mediaSearch.value.trim().toLowerCase();

        document.querySelectorAll('#mediaGrid .picker-card').forEach(function(card){
            const name = (card.dataset.name || '').toLowerCase();

            card.style.display =
                !q || name.includes(q)
                    ? ''
                    : 'none';
        });
    });

    /*
    | Delegated handler means every existing and newly imported Web Gallery
    | photo remains selectable, not only the last rendered card.
    */
    mediaGrid?.addEventListener('click', function(event){
        const button = event.target.closest('.picker-select');

        if (!button) return;

        event.preventDefault();
        event.stopPropagation();

        const card = button.closest('.picker-card');

        const imagePath =
            button.dataset.image
            || card?.dataset.image
            || '';

        const imageUrl =
            button.dataset.url
            || card?.querySelector('img')?.src
            || '';

        const imageName =
            button.dataset.name
            || card?.querySelector('.picker-name')?.textContent?.trim()
            || fileNameFromPath(imagePath);

        chooseImage(
            imagePath,
            imageUrl,
            imageName
        );
    });

    document.getElementById('mediaUploadPc')?.addEventListener(
        'click',
        function(event){
            event.preventDefault();

            closeMedia();

            if (mode === 'main') {
                document.getElementById('mainImageFile')?.click();
            } else {
                document.getElementById('galleryFiles')?.click();
            }
        }
    );

    /*
    |--------------------------------------------------------------------------
    | COMPUTER / PC PREVIEW
    |--------------------------------------------------------------------------
    */

    document.getElementById('mainImageFile')?.addEventListener(
        'change',
        function(){
            const file = this.files?.[0];

            if (!file) return;

            if (mainInput) {
                mainInput.value = '';
            }

            if (mainItems) {
                mainItems.innerHTML = `
                    <div class="selected-thumb">
                        <img src="${escapeHtml(URL.createObjectURL(file))}" alt="${escapeHtml(file.name)}">
                        <small>${escapeHtml(file.name)}</small>
                    </div>
                `;
            }

            if (mainPanel) {
                mainPanel.hidden = false;
            }

            refreshWebGalleryCards();
        }
    );

    document.getElementById('galleryFiles')?.addEventListener(
        'change',
        function(){
            if (!this.files || !this.files.length) return;

            /*
            | PC files are submitted normally. Only their visual preview is added here.
            */
            if (galleryItems) {
                Array.from(this.files).forEach(function(file){
                    const item = document.createElement('div');
                    item.className = 'selected-thumb pc-preview';
                    item.innerHTML = `
                        <img src="${escapeHtml(URL.createObjectURL(file))}" alt="${escapeHtml(file.name)}">
                        <small>${escapeHtml(file.name)}</small>
                    `;
                    galleryItems.appendChild(item);
                });
            }

            if (galleryPanel) {
                galleryPanel.hidden = false;
            }
        }
    );

    /*
    |--------------------------------------------------------------------------
    | PEXELS
    |--------------------------------------------------------------------------
    */

    function openPexels(newMode) {
        mode = newMode === 'gallery' ? 'gallery' : 'main';

        updatePexelsGalleryDoneState();

        pexelsModal?.classList.add('open');
        pexelsModal?.setAttribute('aria-hidden', 'false');

        document.body.classList.add('media-modal-open');

        setTimeout(function(){
            document.getElementById('pexelsSearch')?.focus();
        }, 50);
    }

    function closePexels() {
        pexelsModal?.classList.remove('open');
        pexelsModal?.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('media-modal-open');
    }

    document.querySelectorAll('.open-pexels-picker').forEach(function(button){
        button.addEventListener('click', function(event){
            event.preventDefault();
            openPexels(button.dataset.mode || button.dataset.pexelsMode || 'main');
        });
    });

    document.querySelectorAll('[data-close-pexels]').forEach(function(button){
        button.addEventListener('click', closePexels);
    });

    async function pexelsAjax(data) {
        const fd = new FormData();

        fd.append('pexels_ajax', '1');
        fd.append(
            'csrf_token',
            <?= json_encode($csrfToken, JSON_UNESCAPED_SLASHES); ?>
        );

        Object.entries(data).forEach(function(entry){
            fd.append(entry[0], entry[1]);
        });

        const response = await fetch(
            'admin-blogs.php',
            {
                method: 'POST',
                body: fd,
                credentials: 'same-origin',
                cache: 'no-store'
            }
        );

        let json;

        try {
            json = await response.json();
        } catch (error) {
            throw new Error(
                'The server returned an invalid response while processing the photo.'
            );
        }

        if (!response.ok || !json.success) {
            throw new Error(
                json.message
                || 'The photo request could not be completed.'
            );
        }

        return json;
    }

    /*
    | Immediately add an imported Pexels image to the visible Web Gallery.
    | This matches the package image workflow and avoids needing a page refresh.
    */
    function addImportedPhotoToWebGallery(saved) {
        if (!mediaGrid || !saved?.image || !saved?.url) {
            return;
        }

        const exists = Array.from(
            mediaGrid.querySelectorAll('.picker-card')
        ).some(function(card){
            return (card.dataset.image || '') === saved.image;
        });

        if (exists) return;

        const card = document.createElement('div');
        card.className = 'picker-card';
        card.dataset.name = String(saved.name || '').toLowerCase();
        card.dataset.image = saved.image;

        card.innerHTML = `
            <img
                src="${escapeHtml(saved.url)}"
                alt="${escapeHtml(saved.alt || saved.name || 'Pexels photo')}"
            >
            <div
                class="picker-name"
                title="${escapeHtml(saved.name || fileNameFromPath(saved.image))}"
            >
                ${escapeHtml(saved.name || fileNameFromPath(saved.image))}
            </div>
            <button
                type="button"
                class="picker-select"
                data-image="${escapeHtml(saved.image)}"
                data-url="${escapeHtml(saved.url)}"
                data-name="${escapeHtml(saved.name || fileNameFromPath(saved.image))}"
            >
                Choose Photo
            </button>
        `;

        mediaGrid.prepend(card);

        refreshWebGalleryCards();
    }

    async function searchPexels(page) {
        const searchInput =
            document.getElementById('pexelsSearch');

        const status =
            document.getElementById('pexelsStatus');

        const grid =
            document.getElementById('pexelsGrid');

        pexelsQuery =
            searchInput?.value.trim()
            || '';

        if (!pexelsQuery) {
            status.textContent =
                'Please enter a photo search keyword.';
            return;
        }

        status.textContent =
            'Searching Pexels + Unsplash...';

        grid.innerHTML = '';

        try {
            const result = await pexelsAjax({
                action: 'pexels_search',
                query: pexelsQuery,
                page: String(page)
            });

            pexelsPage =
                result.data?.page
                || page;

            hasNext =
                !!result.data?.next_page;

            const photos =
                result.data?.photos
                || [];

            const prevButton = document.getElementById('pexelsPrev');
            const nextButton = document.getElementById('pexelsNext');
            if (prevButton) prevButton.disabled = pexelsPage <= 1;
            if (nextButton) nextButton.disabled = !hasNext;
            document.getElementById('pexelsPage').textContent =
                'Page ' + pexelsPage + ' • ' + Number(result.data?.total_results || photos.length) + ' result(s)';

            photos.forEach(function(photo){
                const card =
                    document.createElement('div');

                const provider = String(photo.provider || 'pexels').toLowerCase();
                card.className = 'pexels-card';
                card.dataset.provider = provider;

                const photographerHref =
                    photo.photographer_url
                        ? escapeHtml(photo.photographer_url)
                        : '';

                const photoHref =
                    photo.photo_url
                        ? escapeHtml(photo.photo_url)
                        : '';

                card.innerHTML = `
                    <div class="pexels-photo-wrap">
                        <span class="free-photo-provider-badge ${provider}">${escapeHtml(photo.provider_label || (provider === 'unsplash' ? 'Unsplash' : 'Pexels'))}</span>
                        <img
                            src="${escapeHtml(photo.preview)}"
                            alt="${escapeHtml(photo.alt || ((photo.provider || '').toLowerCase() === 'unsplash' ? 'Unsplash travel photo' : 'Pexels travel photo'))}"
                        >
                        <div class="pexels-click-hint">
                            <i class="fa-regular fa-hand-pointer"></i>
                            Click photo to select
                        </div>
                    </div>

                    <div class="pexels-card-body">

                        <div class="pexels-photo-credit">
                            Photo by
                            ${
                                photographerHref
                                    ? `<a href="${photographerHref}" target="_blank" rel="noopener noreferrer">${escapeHtml(photo.photographer)}</a>`
                                    : `<strong>${escapeHtml(photo.photographer)}</strong>`
                            }
                            <span class="slash">/</span>
                            ${
                                photoHref
                                    ? `<a href="${photoHref}" target="_blank" rel="noopener noreferrer">${escapeHtml(photo.provider_label || ((photo.provider || '').toLowerCase() === 'unsplash' ? 'Unsplash' : 'Pexels'))}</a>`
                                    : `<strong>${escapeHtml(photo.provider_label || ((photo.provider || '').toLowerCase() === 'unsplash' ? 'Unsplash' : 'Pexels'))}</strong>`
                            }
                        </div>

                        <div class="pexels-photo-name">
                            ${escapeHtml(photo.alt || 'Royalty-free travel photo')}
                        </div>

                        <button type="button">
                            <i class="fa-solid fa-cloud-arrow-down"></i>
                            Select & Use Photo
                        </button>

                    </div>
                `;

                const button =
                    card.querySelector('button');

                let importing = false;

                async function selectThisPhoto(event) {
                    if (event) {
                        event.preventDefault();
                        event.stopPropagation();
                    }

                    if (importing || card.classList.contains('selected')) {
                        return;
                    }

                    importing = true;

                    const original = button.innerHTML;

                    button.disabled = true;
                    button.innerHTML =
                        '<i class="fa-solid fa-spinner fa-spin"></i> Importing...';

                    try {
                        const savedResult =
                            await pexelsAjax({
                                action: 'pexels_import',
                                provider: photo.provider || 'pexels',
                                photo_id: photo.id,
                                image_url: photo.download,
                                photo_url: photo.photo_url,
                                photographer: photo.photographer,
                                photographer_url: photo.photographer_url || '',
                                download_location: photo.download_location || '',
                                alt: photo.alt || ''
                            });

                        const saved = savedResult.data || {};

                        if (!saved.image || !saved.url) {
                            throw new Error('The imported photo path was not returned by the server.');
                        }

                        addImportedPhotoToWebGallery(saved);

                        if (mode === 'main') {
                            setMainPreview(
                                saved.image,
                                saved.url,
                                saved.name || photo.alt || 'Royalty-free photo'
                            );
                        } else {
                            if (!galleryIsSelected(saved.image)) {
                                addGalleryHiddenInput(saved.image);
                            }

                            refreshGalleryPreview();
                            refreshWebGalleryCards();
                            updatePexelsGalleryDoneState();
                        }

                        card.classList.add('selected');

                        button.disabled = true;
                        button.innerHTML =
                            '<i class="fa-solid fa-circle-check"></i> Selected';

                        status.innerHTML =
                            '<i class="fa-solid fa-circle-check"></i> '
                            + escapeHtml(
                                savedResult.message
                                || 'Photo selected and saved to Web Gallery.'
                            )
                            + (
                                saved.attribution
                                    ? ' &nbsp; ' + escapeHtml(saved.attribution)
                                    : ''
                            );

                        if (mode === 'main') {
                            window.setTimeout(closePexels, 900);
                        }

                    } catch (error) {
                        button.disabled = false;
                        button.innerHTML = original;
                        alert(error.message);

                    } finally {
                        importing = false;
                    }
                }

                /*
                | Exactly as requested:
                | - click the PHOTO itself to select
                | - Select & Use Photo button also works
                | - creator/Pexels links remain normal links
                */
                button.addEventListener('click', selectThisPhoto);

                card.querySelector('.pexels-photo-wrap')?.addEventListener(
                    'click',
                    selectThisPhoto
                );

                grid.appendChild(card);
            });

            status.textContent =
                photos.length
                + ' royalty-free photos found.';

        } catch (error) {
            status.textContent =
                error.message;
        }
    }

    document.getElementById('pexelsSearchBtn')?.addEventListener(
        'click',
        function(event){
            event.preventDefault();
            searchPexels(1);
        }
    );

    document.getElementById('pexelsSearch')?.addEventListener(
        'keydown',
        function(event){
            if (event.key === 'Enter') {
                event.preventDefault();
                searchPexels(1);
            }
        }
    );

    document.getElementById('pexelsPrev')?.addEventListener(
        'click',
        function(event){
            event.preventDefault();

            if (pexelsPage > 1) {
                searchPexels(pexelsPage - 1);
            }
        }
    );

    document.getElementById('pexelsNext')?.addEventListener(
        'click',
        function(event){
            event.preventDefault();

            if (hasNext) {
                searchPexels(pexelsPage + 1);
            }
        }
    );

    pexelsGalleryDone?.addEventListener(
        'click',
        function(event){
            event.preventDefault();

            refreshGalleryPreview();
            updatePexelsGalleryDoneState();
            closePexels();
        }
    );


    /*
    |--------------------------------------------------------------------------
    | INITIAL STATE
    |--------------------------------------------------------------------------
    */

    refreshGalleryPreview();
    refreshWebGalleryCards();
    updatePexelsGalleryDoneState();

    document.addEventListener('keydown', function(event){
        if (event.key !== 'Escape') return;

        if (mediaModal?.classList.contains('open')) {
            closeMedia();
        }

        if (pexelsModal?.classList.contains('open')) {
            closePexels();
        }
    });
})();

</script>






<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
