TRAVSCOPE V24.91 — UNIFIED SUPPLIER PACKAGE + HOTEL IMPORT
===========================================================
Base: V24.90 Bulk Package Master Creation

WHAT CHANGED
1. Admin can upload ONE XLSX workbook from Supplier Packages / Rates import.
2. The workbook can contain:
   - Package_Rates_Import
   - Day_Wise_Itinerary
   - Package_Terms
   - Package_Content
   - Hotel_Options_Import
3. One preview screen now shows both package/rate/itinerary data and supplier hotel options.
4. One final button imports Packages + Hotels together.
5. Hotel rows can be corrected/excluded from the same preview.
6. Missing hotel cities can be created during final import.
7. Existing supplier hotel duplicates are skipped by default; admin may tick Update hotel duplicates.
8. Legacy package-only XLSX/CSV imports continue to work.
9. Supplier Hotel Options page now points its bulk import action to the unified importer.
10. Includes templates/TRAVSCOPE_Unified_Supplier_Package_Hotel_Import_Template.xlsx.

DATABASE
No SQL required.

CHANGED FILES
- admin-supplier-package-import.php
- admin-supplier-packages.php
- admin-supplier-hotels.php
- templates/TRAVSCOPE_Unified_Supplier_Package_Hotel_Import_Template.xlsx
- README_V24_91_UNIFIED_SUPPLIER_IMPORT.txt
