<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE PROFESSIONAL CRM SHARED FUNCTIONS
| VERSION: 2026-08-06-R11 PACKAGE VERSIONING
|--------------------------------------------------------------------------
| File: public_html/crm-functions.php
|--------------------------------------------------------------------------
*/

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| OPTIONAL POST-BOOKING SUPPLIER BRIDGE
|--------------------------------------------------------------------------
| Loading this helper here lets both Admin acceptance and Customer Portal
| acceptance prepare the same supplier procurement records automatically.
*/
$supplierFunctionsFile = __DIR__ . '/supplier-functions.php';
if (
    is_file($supplierFunctionsFile)
    && !function_exists('tsSupplierAutoPrepareBookingOrders')
) {
    require_once $supplierFunctionsFile;
}


/* STEP 10 - PACKAGE SERVICE TEMPLATE -> CRM AUTOMATION */
$packageServicesFunctionsFile = __DIR__ . '/package-services-functions.php';
if (
    is_file($packageServicesFunctionsFile)
    && !function_exists('tsPackageSyncTripServicesFromPackage')
) {
    require_once $packageServicesFunctionsFile;
}

/* STEP 11F - DESTINATION-WISE HOTEL ALLOCATION */
$hotelAllocationFunctionsFile = __DIR__ . '/hotel-allocation-functions.php';
if (
    is_file($hotelAllocationFunctionsFile)
    && !function_exists('tsHABindBooking')
) {
    require_once $hotelAllocationFunctionsFile;
}

/* STEP 11G - SUPPLIER VEHICLE / TRANSPORT ALLOCATION */
$transportAllocationFunctionsFile = __DIR__ . '/transport-allocation-functions.php';
if (
    is_file($transportAllocationFunctionsFile)
    && !function_exists('tsTABindBooking')
) {
    require_once $transportAllocationFunctionsFile;
}

function crmTableExists(PDO $pdo, string $table): bool
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = DATABASE() AND table_name = ?
        ");
        $stmt->execute([$table]);
        return (int)$stmt->fetchColumn() > 0;
    } catch (Throwable $e) {
        error_log('CRM table check: ' . $e->getMessage());
        return false;
    }
}

function crmColumnExists(PDO $pdo, string $table, string $column): bool
{
    if (
        !preg_match('/^[A-Za-z0-9_]+$/', $table)
        || !preg_match('/^[A-Za-z0-9_]+$/', $column)
    ) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = DATABASE()
              AND table_name = ?
              AND column_name = ?
        ");
        $stmt->execute([$table, $column]);
        return (int)$stmt->fetchColumn() > 0;
    } catch (Throwable $e) {
        error_log('CRM column check: ' . $e->getMessage());
        return false;
    }
}

function crmTablesReady(PDO $pdo): bool
{
    foreach (['enquiries', 'crm_lead_meta', 'crm_activities'] as $table) {
        if (!crmTableExists($pdo, $table)) {
            return false;
        }
    }

    $required = [
        'crm_lead_meta' => [
            'enquiry_id', 'priority', 'lead_source', 'campaign_name',
            'social_profile_name', 'social_profile_url', 'platform_lead_id',
            'lead_score', 'estimated_value', 'next_follow_up_at', 'tags'
        ],
        'crm_activities' => [
            'lead_id', 'admin_id', 'activity_type', 'subject',
            'details', 'follow_up_at', 'completed_at', 'created_at'
        ]
    ];

    foreach ($required as $table => $columns) {
        foreach ($columns as $column) {
            if (!crmColumnExists($pdo, $table, $column)) {
                return false;
            }
        }
    }

    return true;
}

function crmAllowedStatuses(): array
{
    return ['new', 'contacted', 'qualified', 'follow_up', 'proposal', 'converted', 'closed'];
}

function crmAllowedPriorities(): array
{
    return ['low', 'medium', 'high', 'urgent'];
}

function crmAllowedActivityTypes(): array
{
    return ['note', 'call', 'email', 'whatsapp', 'meeting', 'quotation', 'follow_up', 'social_message'];
}

function crmAllowedSources(): array
{
    return [
        'website', 'facebook', 'instagram', 'whatsapp', 'google_ads',
        'youtube', 'linkedin', 'twitter', 'telegram', 'phone',
        'walk_in', 'referral', 'manual', 'other'
    ];
}

function crmStatusLabel(?string $status): string
{
    $labels = [
        'new' => 'New',
        'contacted' => 'Contacted',
        'qualified' => 'Qualified',
        'follow_up' => 'Follow Up',
        'proposal' => 'Proposal Sent',
        'converted' => 'Converted',
        'closed' => 'Closed / Lost'
    ];

    $status = trim((string)$status);
    return $labels[$status] ?? ucwords(str_replace('_', ' ', $status ?: 'Not Set'));
}

function crmPriorityLabel(?string $priority): string
{
    $priority = trim((string)$priority);
    return ucwords(str_replace('_', ' ', $priority ?: 'Medium'));
}

function crmSourceLabel(?string $source): string
{
    $labels = [
        'website' => 'Website',
        'facebook' => 'Facebook',
        'instagram' => 'Instagram',
        'whatsapp' => 'WhatsApp',
        'google_ads' => 'Google Ads',
        'youtube' => 'YouTube',
        'linkedin' => 'LinkedIn',
        'twitter' => 'X / Twitter',
        'telegram' => 'Telegram',
        'phone' => 'Phone Call',
        'walk_in' => 'Walk-in',
        'referral' => 'Referral',
        'manual' => 'Manual Entry',
        'other' => 'Other'
    ];

    $source = trim((string)$source);
    return $labels[$source] ?? ucwords(str_replace('_', ' ', $source ?: 'Website'));
}

function crmActivityLabel(?string $type): string
{
    $labels = [
        'note' => 'Note',
        'call' => 'Phone Call',
        'email' => 'Email',
        'whatsapp' => 'WhatsApp',
        'meeting' => 'Meeting',
        'quotation' => 'Quotation',
        'follow_up' => 'Follow Up',
        'social_message' => 'Social Message'
    ];

    $type = trim((string)$type);
    return $labels[$type] ?? ucwords(str_replace('_', ' ', $type ?: 'Activity'));
}

function crmSourceIcon(?string $source): string
{
    $icons = [
        'facebook' => 'fa-brands fa-facebook-f',
        'instagram' => 'fa-brands fa-instagram',
        'whatsapp' => 'fa-brands fa-whatsapp',
        'youtube' => 'fa-brands fa-youtube',
        'linkedin' => 'fa-brands fa-linkedin-in',
        'twitter' => 'fa-brands fa-x-twitter',
        'telegram' => 'fa-brands fa-telegram',
        'google_ads' => 'fa-brands fa-google',
        'phone' => 'fa-solid fa-phone',
        'walk_in' => 'fa-solid fa-person-walking',
        'referral' => 'fa-solid fa-user-group',
        'manual' => 'fa-solid fa-keyboard',
        'website' => 'fa-solid fa-globe'
    ];

    return $icons[trim((string)$source)] ?? 'fa-solid fa-bullhorn';
}

function crmSqlDateTime(?string $value): ?string
{
    $value = trim((string)$value);

    if ($value === '') {
        return null;
    }

    $timestamp = strtotime($value);
    return $timestamp === false ? null : date('Y-m-d H:i:s', $timestamp);
}

function crmDateTimeInput(?string $value): string
{
    $timestamp = strtotime((string)$value);
    return $timestamp === false ? '' : date('Y-m-d\TH:i', $timestamp);
}

function crmDate($value, string $format = 'd M Y'): string
{
    $value = trim((string)$value);

    if (
        $value === ''
        || $value === '0000-00-00'
        || $value === '0000-00-00 00:00:00'
    ) {
        return '-';
    }

    $timestamp = strtotime($value);
    return $timestamp === false ? '-' : date($format, $timestamp);
}

function crmMoney($amount, string $currency = '₹'): string
{
    if ($amount === null || $amount === '' || !is_numeric($amount)) {
        return '-';
    }

    return $currency . number_format((float)$amount, 0);
}

function crmWhatsAppNumber(?string $mobile): string
{
    $digits = preg_replace('/\D+/', '', (string)$mobile);

    if ($digits === '') {
        return '';
    }

    if (strlen($digits) === 10 && preg_match('/^[6-9]/', $digits)) {
        return '91' . $digits;
    }

    return strlen($digits) >= 8 && strlen($digits) <= 15 ? $digits : '';
}

function crmAddActivity(
    PDO $pdo,
    int $leadId,
    int $adminId,
    string $type,
    string $subject,
    ?string $details = null,
    ?string $followUpAt = null
): int {
    if ($leadId <= 0 || $adminId <= 0) {
        throw new InvalidArgumentException('Invalid CRM lead or administrator.');
    }

    if (!in_array($type, crmAllowedActivityTypes(), true)) {
        throw new InvalidArgumentException('Invalid activity type.');
    }

    $subject = trim($subject);

    if ($subject === '') {
        throw new InvalidArgumentException('Activity subject is required.');
    }

    $stmt = $pdo->prepare("
        INSERT INTO crm_activities
        (
            lead_id, admin_id, activity_type, subject, details,
            follow_up_at, completed_at, created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, NULL, NOW())
    ");

    $stmt->execute([
        $leadId,
        $adminId,
        $type,
        $subject,
        trim((string)$details) !== '' ? trim((string)$details) : null,
        $followUpAt
    ]);

    return (int)$pdo->lastInsertId();
}

function crmRedirect(string $url): void
{
    if (!headers_sent()) {
        header('Location: ' . $url);
        exit;
    }

    echo '<script>window.location.href=' . json_encode($url) . ';</script>';
    exit;
}

function crmPageUrl(int $page): string
{
    $query = $_GET;
    unset($query['lead'], $query['page']);
    $query['page'] = max(1, $page);

    return (defined('BASE_URL') ? BASE_URL : '')
        . 'admin-crm.php?'
        . http_build_query($query);
}

function crmLeadScoreLabel(int $score): string
{
    if ($score >= 80) {
        return 'Hot';
    }

    if ($score >= 50) {
        return 'Warm';
    }

    return 'Cold';
}


function crmBuildPackageMessage(array $version, string $siteName = 'TRAVSCOPE.COM'): string
{
    $lines = [];

    $lines[] = $siteName . ' - Package Proposal';
    $lines[] = 'Version: ' . (int)($version['version_number'] ?? 1);
    $lines[] = 'Package: ' . trim((string)($version['package_title'] ?? 'Custom Package'));

    if (!empty($version['travel_date'])) {
        $lines[] = 'Travel Date: ' . crmDate($version['travel_date'], 'd M Y');
    }

    if (!empty($version['hotel_category'])) {
        $lines[] = 'Hotel: ' . trim((string)$version['hotel_category']) . ' Star';
    }

    $lines[] = 'Travellers: '
        . (int)($version['adults'] ?? 1)
        . ' Adult(s), '
        . (int)($version['children'] ?? 0)
        . ' Child(ren)';

    if (isset($version['final_price']) && $version['final_price'] !== '') {
        $lines[] = 'Final Price: ₹' . number_format((float)$version['final_price'], 0);
    }

    foreach ([
        'package_description' => 'Description',
        'itinerary' => 'Itinerary',
        'inclusions' => 'Inclusions',
        'exclusions' => 'Exclusions',
        'custom_notes' => 'Notes'
    ] as $field => $label) {
        $value = trim((string)($version[$field] ?? ''));

        if ($value !== '') {
            $lines[] = '';
            $lines[] = $label . ':';
            $lines[] = $value;
        }
    }

    $lines[] = '';
    $lines[] = 'Prepared by ' . $siteName;

    return implode("\n", $lines);
}

function crmSendPackageEmail(
    string $to,
    string $subject,
    string $html,
    string $plainText
): bool {
    $to = trim($to);

    if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    if (function_exists('sendEmail')) {
        try {
            return (bool)sendEmail($to, $subject, $html);
        } catch (Throwable $e) {
            error_log('CRM sendEmail error: ' . $e->getMessage());
        }
    }

    $headers = [
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . (defined('MAIL_FROM_NAME') ? MAIL_FROM_NAME : 'TRAVSCOPE')
            . ' <' . (defined('MAIL_FROM_EMAIL') ? MAIL_FROM_EMAIL : 'no-reply@localhost') . '>'
    ];

    return @mail(
        $to,
        $subject,
        $html,
        implode("\r\n", $headers)
    );
}

function crmPackageVersionNumber(PDO $pdo, int $leadId): int
{
    $stmt = $pdo->prepare("
        SELECT COALESCE(MAX(version_number), 0) + 1
        FROM crm_package_versions
        WHERE lead_id = ?
    ");

    $stmt->execute([$leadId]);

    return max(1, (int)$stmt->fetchColumn());
}


function crmCsvCell($value): string
{
    $value = str_replace(["\r\n", "\r"], "\n", (string)$value);
    return '"' . str_replace('"', '""', $value) . '"';
}


/* =========================================================
   PHASE 0A — TRIP / OPPORTUNITY FOUNDATION
   Existing enquiry/CRM records remain the source during migration.
========================================================= */
function crmTripsReady(PDO $pdo): bool
{
    return crmTableExists($pdo, 'trips');
}

function crmTripStages(): array
{
    return ['new','contacted','qualified','requirement_pending','planning','supplier_sourcing','ready_for_quotation','quotation_sent','negotiation','won','lost','dormant'];
}

function crmTripStageLabel(string $stage): string
{
    return ucwords(str_replace('_', ' ', $stage));
}

function crmTripByEnquiry(PDO $pdo, int $enquiryId): ?array
{
    if ($enquiryId <= 0 || !crmTripsReady($pdo)) return null;
    $stmt = $pdo->prepare('SELECT * FROM trips WHERE enquiry_id = ? LIMIT 1');
    $stmt->execute([$enquiryId]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

function crmTripById(PDO $pdo, int $tripId): ?array
{
    if ($tripId <= 0 || !crmTripsReady($pdo)) return null;
    $stmt = $pdo->prepare('SELECT * FROM trips WHERE id = ? LIMIT 1');
    $stmt->execute([$tripId]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

function crmTripStageFromEnquiryStatus(string $status): string
{
    return match ($status) {
        'new' => 'new',
        'contacted' => 'contacted',
        'follow_up' => 'qualified',
        'converted' => 'won',
        'closed' => 'dormant',
        default => 'qualified',
    };
}

function crmCreateTripForEnquiry(PDO $pdo, int $enquiryId, int $adminId = 0): array
{
    if (!crmTripsReady($pdo)) {
        throw new RuntimeException('Trip Foundation SQL is not installed yet. Import phase0a_trips.sql first.');
    }
    $existing = crmTripByEnquiry($pdo, $enquiryId);
    if ($existing) {
        if (function_exists('tsPackageSyncTripServicesFromPackage')) {
            try {
                tsPackageSyncTripServicesFromPackage($pdo, (int)$existing['id'], $adminId);
            } catch (Throwable $packageServiceError) {
                error_log('Package service sync (existing Trip): ' . $packageServiceError->getMessage());
            }
        }
        return $existing;
    }

    $stmt = $pdo->prepare("\n        SELECT e.*, m.assigned_admin_id, m.estimated_value, m.lead_score, m.next_follow_up_at, m.lost_reason\n        FROM enquiries e\n        LEFT JOIN crm_lead_meta m ON m.enquiry_id = e.id\n        WHERE e.id = ? LIMIT 1\n    ");
    $stmt->execute([$enquiryId]);
    $e = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$e) throw new RuntimeException('Enquiry not found.');

    $owner = (int)($e['assigned_admin_id'] ?? 0);
    if ($owner <= 0) $owner = $adminId;
    $expected = $e['estimated_value'] ?? $e['budget'] ?? 0;
    $probability = max(0, min(100, (int)($e['lead_score'] ?? 50)));
    $stage = crmTripStageFromEnquiryStatus((string)($e['status'] ?? 'new'));
    $status = $stage === 'won' ? 'won' : ($stage === 'lost' ? 'lost' : 'active');
    $nextDate = !empty($e['next_follow_up_at']) ? date('Y-m-d', strtotime((string)$e['next_follow_up_at'])) : null;

    try {
        $pdo->beginTransaction();
        $tmpCode = 'TMP-' . bin2hex(random_bytes(8));
        $ins = $pdo->prepare("\n            INSERT INTO trips\n            (trip_code,enquiry_id,customer_id,package_id,destination_id,trip_title,travel_start_date,travel_end_date,adults,children,owner_admin_id,stage,status,expected_value,probability,next_action,next_action_date,lost_reason,created_by_admin_id)\n            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)\n        ");
        $ins->execute([
            $tmpCode, $enquiryId,
            !empty($e['user_id']) ? (int)$e['user_id'] : null,
            !empty($e['package_id']) ? (int)$e['package_id'] : null,
            !empty($e['destination_id']) ? (int)$e['destination_id'] : null,
            trim((string)($e['name'] ?? '')) !== '' ? (string)$e['name'] . ' — ' . ((string)($e['destination'] ?? 'Trip')) : 'Trip',
            !empty($e['travel_date']) ? $e['travel_date'] : null,
            null,
            max(1,(int)($e['adults'] ?? 1)), max(0,(int)($e['children'] ?? 0)),
            $owner > 0 ? $owner : null, $stage, $status,
            max(0,(float)$expected), $probability,
            '', $nextDate, !empty($e['lost_reason']) ? $e['lost_reason'] : null,
            $adminId > 0 ? $adminId : null
        ]);
        $tripId = (int)$pdo->lastInsertId();
        $tripCode = 'TS-' . date('Y') . '-' . str_pad((string)$tripId, 6, '0', STR_PAD_LEFT);
        $upd = $pdo->prepare('UPDATE trips SET trip_code = ? WHERE id = ?');
        $upd->execute([$tripCode, $tripId]);
        $pdo->commit();
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        // Unique enquiry protection also makes repeated clicks safe.
        $existing = crmTripByEnquiry($pdo, $enquiryId);
        if ($existing) return $existing;
        throw $ex;
    }
    $createdTrip = crmTripByEnquiry($pdo, $enquiryId) ?: ['id'=>$tripId,'trip_code'=>$tripCode,'enquiry_id'=>$enquiryId];

    /*
    | STEP 10: Package -> Trip Service Requirements -> mapped Supplier drafts.
    | This is idempotent and never emails a supplier automatically.
    */
    if (function_exists('tsPackageSyncTripServicesFromPackage')) {
        try {
            tsPackageSyncTripServicesFromPackage($pdo, (int)$createdTrip['id'], $adminId);
        } catch (Throwable $packageServiceError) {
            error_log('Package service sync (new Trip): ' . $packageServiceError->getMessage());
        }
    }

    return $createdTrip;
}

/* Phase 0B: Trip Service Requirements + Cost Sheet */
function crmServiceRequirementsReady(PDO $pdo): bool { return crmTableExists($pdo,'trip_service_requirements'); }
function crmCostSheetReady(PDO $pdo): bool { return crmTableExists($pdo,'cost_sheets') && crmTableExists($pdo,'cost_sheet_items'); }
function crmServiceRequirementTypes(): array { return ['hotel','transport','transfer','activity','sightseeing','flight','visa','train','cruise','guide','insurance','meal','other']; }
function crmServiceRequirementTypeLabel(string $type): string {
 $map=['hotel'=>'Hotel','transport'=>'Transport / Vehicle','transfer'=>'Transfer','activity'=>'Activity','sightseeing'=>'Sightseeing','flight'=>'Flight','visa'=>'Visa','train'=>'Train','cruise'=>'Cruise','guide'=>'Guide','insurance'=>'Travel Insurance','meal'=>'Meal / Supplement','other'=>'Other Service'];
 $type=strtolower(trim($type)); return $map[$type] ?? ucwords(str_replace('_',' ',$type ?: 'Other'));
}
function crmServiceRequirementStatuses(): array { return ['rate_required','sourcing','quoted','selected','confirmed','cancelled']; }
function crmServiceRequirementStatusLabel(string $status): string {
 $map=['rate_required'=>'Rate Required','sourcing'=>'Supplier Sourcing','quoted'=>'Quote Received','selected'=>'Supplier Selected','confirmed'=>'Confirmed','cancelled'=>'Cancelled'];
 $status=strtolower(trim($status)); return $map[$status] ?? ucwords(str_replace('_',' ',$status ?: 'Rate Required'));
}
function crmTripServiceRequirements(PDO $pdo,int $tripId): array {
 if($tripId<=0 || !crmServiceRequirementsReady($pdo)) return [];
 $st=$pdo->prepare("SELECT r.*,d.name destination_name,d.country destination_country FROM trip_service_requirements r LEFT JOIN destinations d ON d.id=r.destination_id WHERE r.trip_id=? ORDER BY r.sort_order,r.id");
 $st->execute([$tripId]); return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
function crmActiveCostSheet(PDO $pdo,int $tripId): ?array {
 if($tripId<=0 || !crmCostSheetReady($pdo)) return null;
 $st=$pdo->prepare("SELECT * FROM cost_sheets WHERE trip_id=? AND status='active' ORDER BY version_number DESC,id DESC LIMIT 1"); $st->execute([$tripId]); $r=$st->fetch(PDO::FETCH_ASSOC); return $r ?: null;
}
function crmEnsureActiveCostSheet(PDO $pdo,int $tripId,int $enquiryId,int $adminId=0,string $currency='INR'): array {
 $r=crmActiveCostSheet($pdo,$tripId); if($r) return $r;
 if(!crmCostSheetReady($pdo)) throw new RuntimeException('Cost Sheet SQL is not installed yet.');
 $currency=strtoupper(trim($currency)) ?: 'INR';
 $st=$pdo->prepare("INSERT INTO cost_sheets(trip_id,enquiry_id,version_number,status,currency,created_by_admin_id) VALUES(?,?,1,'active',?,?)");
 $st->execute([$tripId,$enquiryId,$currency,$adminId>0?$adminId:null]); $id=(int)$pdo->lastInsertId();
 $st=$pdo->prepare('SELECT * FROM cost_sheets WHERE id=?'); $st->execute([$id]); return $st->fetch(PDO::FETCH_ASSOC) ?: [];
}
function crmCostSheetItems(PDO $pdo,int $sheetId): array {
 if($sheetId<=0 || !crmCostSheetReady($pdo)) return [];
 $st=$pdo->prepare("SELECT i.*,s.company_name supplier_name,r.request_code,q.version_number supplier_quote_version FROM cost_sheet_items i LEFT JOIN suppliers s ON s.id=i.supplier_id LEFT JOIN supplier_requests r ON r.id=i.supplier_request_id LEFT JOIN supplier_quotes q ON q.id=i.supplier_quote_id WHERE i.cost_sheet_id=? ORDER BY CASE i.source_type WHEN 'supplier_quote' THEN 1 WHEN 'contract_rate' THEN 2 ELSE 3 END,i.sort_order,i.id");
 $st->execute([$sheetId]); return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
function crmRecalculateCostSheet(PDO $pdo,int $sheetId): array {
 $st=$pdo->prepare("SELECT COALESCE(SUM(CASE WHEN source_type IN ('supplier_quote','contract_rate') THEN line_cost ELSE 0 END),0) supplier_total, COALESCE(SUM(CASE WHEN source_type NOT IN ('supplier_quote','contract_rate') THEN line_cost ELSE 0 END),0) direct_total FROM cost_sheet_items WHERE cost_sheet_id=?"); $st->execute([$sheetId]); $x=$st->fetch(PDO::FETCH_ASSOC) ?: [];
 $sup=max(0,(float)($x['supplier_total']??0)); $direct=max(0,(float)($x['direct_total']??0)); $total=$sup+$direct;
 $st=$pdo->prepare('UPDATE cost_sheets SET supplier_cost_total=?,direct_cost_total=?,travscope_cost_total=?,updated_at=NOW() WHERE id=?'); $st->execute([$sup,$direct,$total,$sheetId]);
 $st=$pdo->prepare('SELECT * FROM cost_sheets WHERE id=?'); $st->execute([$sheetId]); return $st->fetch(PDO::FETCH_ASSOC) ?: [];
}
function crmCostSheetSupplierNames(PDO $pdo,int $sheetId): array {
 if($sheetId<=0 || !crmCostSheetReady($pdo)) return [];
 $st=$pdo->prepare("SELECT DISTINCT s.company_name FROM cost_sheet_items i JOIN suppliers s ON s.id=i.supplier_id WHERE i.cost_sheet_id=? AND i.supplier_id>0 ORDER BY s.company_name"); $st->execute([$sheetId]); return array_values(array_filter(array_map('strval',$st->fetchAll(PDO::FETCH_COLUMN) ?: [])));
}


/*
|--------------------------------------------------------------------------
| QUOTATION ACCEPTANCE -> BOOKING BRIDGE
|--------------------------------------------------------------------------
|
| The accepted quotation version stays immutable.
| A separate acceptance record creates one Booking and freezes:
| - accepted quotation snapshot
| - Trip service snapshot
| - expected supplier/direct cost and margin baseline
|
*/

function crmBookingBridgeReady(PDO $pdo): bool
{
    return
        crmTableExists($pdo, 'quotation_acceptances')
        && crmTableExists($pdo, 'booking_trip_links')
        && crmTableExists($pdo, 'booking_quotation_snapshots')
        && crmTableExists($pdo, 'booking_service_snapshots')
        && crmTableExists($pdo, 'bookings');
}


function crmBookingNumber(PDO $pdo): string
{
    for ($attempt = 0; $attempt < 30; $attempt++) {
        $number =
            'TS'
            . date('ymd')
            . strtoupper(
                substr(
                    bin2hex(random_bytes(4)),
                    0,
                    6
                )
            );

        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM bookings
            WHERE booking_number = ?
        ");
        $stmt->execute([$number]);

        if ((int)$stmt->fetchColumn() === 0) {
            return $number;
        }
    }

    throw new RuntimeException(
        'Unable to generate a unique booking number.'
    );
}


function crmBookingCustomerUserId(PDO $pdo, array $lead): ?int
{
    $email =
        mb_strtolower(
            trim(
                (string)($lead['email'] ?? '')
            )
        );

    $mobile =
        preg_replace(
            '/[^0-9]/',
            '',
            (string)($lead['mobile'] ?? '')
        );

    $last10 =
        strlen($mobile) >= 10
            ? substr($mobile, -10)
            : $mobile;

    if ($email !== '') {
        $stmt = $pdo->prepare("
            SELECT id
            FROM users
            WHERE LOWER(TRIM(email)) = ?
            ORDER BY id ASC
            LIMIT 1
        ");
        $stmt->execute([$email]);

        $id = (int)($stmt->fetchColumn() ?: 0);

        if ($id > 0) {
            return $id;
        }
    }

    if ($last10 !== '') {
        $stmt = $pdo->prepare("
            SELECT id
            FROM users
            WHERE RIGHT(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    TRIM(COALESCE(mobile, '')),
                                    ' ',
                                    ''
                                ),
                                '-',
                                ''
                            ),
                            '(',
                            ''
                        ),
                        ')',
                        ''
                    ),
                    '+',
                    ''
                ),
                10
            ) = ?
            ORDER BY id ASC
            LIMIT 1
        ");
        $stmt->execute([$last10]);

        $id = (int)($stmt->fetchColumn() ?: 0);

        if ($id > 0) {
            return $id;
        }
    }

    return null;
}


function crmBookingAcceptanceByVersion(
    PDO $pdo,
    int $versionId
): ?array {
    if (
        $versionId <= 0
        || !crmBookingBridgeReady($pdo)
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT
            a.*,
            b.booking_number,
            b.booking_status,
            b.payment_status
        FROM quotation_acceptances a
        JOIN bookings b
            ON b.id = a.booking_id
        WHERE a.quotation_version_id = ?
        LIMIT 1
    ");
    $stmt->execute([$versionId]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function crmBookingQuotationSnapshot(
    PDO $pdo,
    int $bookingId
): ?array {
    if (
        $bookingId <= 0
        || !crmTableExists($pdo, 'booking_quotation_snapshots')
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_quotation_snapshots
        WHERE booking_id = ?
        LIMIT 1
    ");
    $stmt->execute([$bookingId]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function crmBookingServiceSnapshots(
    PDO $pdo,
    int $bookingId
): array {
    if (
        $bookingId <= 0
        || !crmTableExists($pdo, 'booking_service_snapshots')
    ) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_service_snapshots
        WHERE booking_id = ?
        ORDER BY sort_order ASC, id ASC
    ");
    $stmt->execute([$bookingId]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function crmAcceptQuotationAndCreateBooking(
    PDO $pdo,
    int $leadId,
    int $versionId,
    int $tripId,
    int $adminId,
    string $acceptedSource = 'admin',
    string $confirmationNote = ''
): array {
    if (!crmBookingBridgeReady($pdo)) {
        throw new RuntimeException(
            'Booking Bridge SQL is not installed yet.'
        );
    }

    if ($leadId <= 0 || $versionId <= 0 || $tripId <= 0) {
        throw new RuntimeException(
            'A valid Trip and quotation version are required.'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | IDEMPOTENCY / DUPLICATE PROTECTION
    |--------------------------------------------------------------------------
    */

    $existing =
        crmBookingAcceptanceByVersion(
            $pdo,
            $versionId
        );

    if ($existing) {
        return [
            'booking_id' => (int)$existing['booking_id'],
            'booking_number' => (string)$existing['booking_number'],
            'already_created' => true
        ];
    }

    $stmt = $pdo->prepare("
        SELECT
            a.booking_id,
            b.booking_number
        FROM quotation_acceptances a
        JOIN bookings b
            ON b.id = a.booking_id
        WHERE a.trip_id = ?
        LIMIT 1
    ");
    $stmt->execute([$tripId]);
    $existingTrip = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existingTrip) {
        return [
            'booking_id' => (int)$existingTrip['booking_id'],
            'booking_number' => (string)$existingTrip['booking_number'],
            'already_created' => true
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | LOAD AUTHORITATIVE RECORDS
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT *
        FROM trips
        WHERE id = ?
          AND enquiry_id = ?
        LIMIT 1
    ");
    $stmt->execute([
        $tripId,
        $leadId
    ]);
    $trip = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$trip) {
        throw new RuntimeException(
            'The quotation is not linked to a valid Trip.'
        );
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM enquiries
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$leadId]);
    $lead = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$lead) {
        throw new RuntimeException(
            'Customer enquiry was not found.'
        );
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM crm_package_versions
        WHERE id = ?
          AND lead_id = ?
        LIMIT 1
    ");
    $stmt->execute([
        $versionId,
        $leadId
    ]);
    $version = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$version) {
        throw new RuntimeException(
            'Quotation version was not found.'
        );
    }

    $snapshot =
        crmCustomerPackageSnapshot(
            $version['custom_notes']
            ?? ''
        );

    /* STEP 11F: freeze this quotation version's customer-safe hotel plan. */
    if (function_exists('tsHAForQuotation') && function_exists('tsHACustomerSafeRows')) {
        try {
            $snapshot['hotel_allocations'] = tsHACustomerSafeRows(
                tsHAForQuotation($pdo, $versionId)
            );
        } catch (Throwable $hotelSnapshotError) {
            error_log('CRM hotel allocation snapshot: ' . $hotelSnapshotError->getMessage());
        }
    }

    $currency =
        strtoupper(
            trim(
                (string)(
                    $snapshot['currency']
                    ?? 'INR'
                )
            )
        );

    if ($currency === '') {
        $currency = 'INR';
    }

    $sellingPrice =
        max(
            0,
            (float)($version['final_price'] ?? 0)
        );

    $snapshotFinalPrice =
        max(
            0,
            (float)(
                $snapshot['internal_costing']['final_customer_price']
                ?? 0
            )
        );

    if (
        $sellingPrice <= 0
        && $snapshotFinalPrice > 0
    ) {
        $sellingPrice =
            $snapshotFinalPrice;
    }

    if ($sellingPrice <= 0) {
        throw new RuntimeException(
            'The accepted quotation has no valid final selling price.'
        );
    }

    $costSheet =
        crmActiveCostSheet(
            $pdo,
            $tripId
        );

    $supplierCost =
        $costSheet
            ? max(
                0,
                (float)($costSheet['supplier_cost_total'] ?? 0)
            )
            : max(
                0,
                (float)(
                    $snapshot['internal_costing']['supplier_rate']
                    ?? 0
                )
            );

    $directCost =
        $costSheet
            ? max(
                0,
                (float)($costSheet['direct_cost_total'] ?? 0)
            )
            : 0.0;

    $expectedCost =
        $costSheet
            ? max(
                0,
                (float)($costSheet['travscope_cost_total'] ?? 0)
            )
            : ($supplierCost + $directCost);

    $expectedMargin =
        $sellingPrice - $expectedCost;

    $userId =
        crmBookingCustomerUserId(
            $pdo,
            $lead
        );

    $bookingNumber =
        crmBookingNumber(
            $pdo
        );

    $acceptedSource =
        strtolower(
            trim($acceptedSource)
        );

    $allowedSources = [
        'admin',
        'email',
        'whatsapp',
        'phone',
        'in_person',
        'customer_portal',
        'other'
    ];

    if (!in_array($acceptedSource, $allowedSources, true)) {
        $acceptedSource = 'admin';
    }

    $travelDate =
        trim(
            (string)(
                $version['travel_date']
                ?? $trip['travel_start_date']
                ?? $lead['travel_date']
                ?? ''
            )
        );

    $specialRequest =
        trim(
            (string)(
                $snapshot['customer_notes']
                ?? $lead['message']
                ?? ''
            )
        );

    $pdo->beginTransaction();

    try {
        /*
        |--------------------------------------------------------------------------
        | CREATE BOOKING
        |--------------------------------------------------------------------------
        |
        | Keep existing booking workflow compatible:
        | accepted quotation creates a PENDING booking.
        | Supplier service confirmation is a separate post-booking operation.
        |
        */

        $columns = [
            'booking_number',
            'user_id',
            'package_id',
            'customer_name',
            'customer_email',
            'customer_mobile',
            'travel_date',
            'adults',
            'children',
            'total_amount',
            'paid_amount',
            'currency',
            'booking_status',
            'payment_status',
            'special_request'
        ];

        $values = [
            $bookingNumber,
            $userId,
            !empty($version['package_id'])
                ? (int)$version['package_id']
                : null,
            (string)$lead['name'],
            (string)($lead['email'] ?? ''),
            (string)($lead['mobile'] ?? ''),
            $travelDate !== ''
                ? $travelDate
                : null,
            max(
                1,
                (int)($version['adults'] ?? $trip['adults'] ?? 1)
            ),
            max(
                0,
                (int)($version['children'] ?? $trip['children'] ?? 0)
            ),
            $sellingPrice,
            0.00,
            $currency,
            'pending',
            'unpaid',
            $specialRequest !== ''
                ? $specialRequest
                : null
        ];

        if (crmColumnExists($pdo, 'bookings', 'discount_amount')) {
            $columns[] = 'discount_amount';
            $values[] =
                max(
                    0,
                    (float)($version['discount_amount'] ?? 0)
                );
        }

        if (crmColumnExists($pdo, 'bookings', 'hotel_category')) {
            $columns[] = 'hotel_category';
            $values[] =
                trim(
                    (string)($version['hotel_category'] ?? '')
                ) ?: null;
        }

        if (crmColumnExists($pdo, 'bookings', 'hotel_price')) {
            /*
             * Legacy customer Booking Details interprets hotel_price as a
             * PER-ADULT price. Do not place the full Package Master reference
             * total here.
             */
            $columns[] = 'hotel_price';
            $values[] =
                max(
                    0,
                    (float)(
                        $snapshot['pricing']['adult_unit_rate']
                        ?? 0
                    )
                );
        }

        $placeholders =
            implode(
                ',',
                array_fill(
                    0,
                    count($columns),
                    '?'
                )
            );

        $stmt = $pdo->prepare(
            'INSERT INTO bookings ('
            . implode(',', $columns)
            . ') VALUES ('
            . $placeholders
            . ')'
        );
        $stmt->execute($values);

        $bookingId =
            (int)$pdo->lastInsertId();

        if ($bookingId <= 0) {
            throw new RuntimeException(
                'Unable to create the booking.'
            );
        }

        /*
         * Defensive commercial lock:
         * the accepted quotation's FINAL PRICE is the Booking amount.
         * This is intentionally independent from Package Master price.
         */
        $pdo->prepare("
            UPDATE bookings
            SET
                total_amount = ?,
                currency = ?,
                updated_at = NOW()
            WHERE id = ?
        ")->execute([
            $sellingPrice,
            $currency,
            $bookingId
        ]);

        /*
        |--------------------------------------------------------------------------
        | ACCEPTANCE AUDIT
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            INSERT INTO quotation_acceptances
            (
                lead_id,
                trip_id,
                quotation_version_id,
                booking_id,
                accepted_source,
                customer_confirmation_note,
                accepted_by_admin_id,
                accepted_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $leadId,
            $tripId,
            $versionId,
            $bookingId,
            $acceptedSource,
            trim($confirmationNote) !== ''
                ? trim($confirmationNote)
                : null,
            $adminId > 0
                ? $adminId
                : null
        ]);

        /*
        |--------------------------------------------------------------------------
        | BOOKING <-> TRIP COMMERCIAL BASELINE
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            INSERT INTO booking_trip_links
            (
                booking_id,
                trip_id,
                enquiry_id,
                quotation_version_id,
                cost_sheet_id,
                expected_supplier_cost,
                expected_direct_cost,
                expected_total_cost,
                expected_selling_price,
                expected_margin_amount
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $bookingId,
            $tripId,
            $leadId,
            $versionId,
            $costSheet
                ? (int)$costSheet['id']
                : null,
            $supplierCost,
            $directCost,
            $expectedCost,
            $sellingPrice,
            $expectedMargin
        ]);

        /* STEP 11F: attach the exact accepted quotation hotel plan to this Booking. */
        if (function_exists('tsHABindBooking')) {
            tsHABindBooking($pdo, $versionId, $bookingId, $adminId);
        }

        /* STEP 11G: freeze the accepted quotation transport plan to this Booking. */
        if (function_exists('tsTABindBooking')) {
            tsTABindBooking($pdo, $versionId, $bookingId, $adminId);
        }

        /*
        |--------------------------------------------------------------------------
        | FREEZE ACCEPTED QUOTATION
        |--------------------------------------------------------------------------
        */

        $itineraryJson =
            !empty($snapshot['itinerary_days'])
                ? json_encode(
                    $snapshot['itinerary_days'],
                    JSON_UNESCAPED_UNICODE
                    | JSON_UNESCAPED_SLASHES
                )
                : (string)($version['itinerary'] ?? '');

        $stmt = $pdo->prepare("
            INSERT INTO booking_quotation_snapshots
            (
                booking_id,
                lead_id,
                quotation_version_id,
                version_number,
                package_id,
                package_title,
                package_description,
                itinerary_json,
                inclusions,
                exclusions,
                terms,
                customer_notes,
                destination_name,
                travel_date,
                adults,
                children,
                currency,
                base_price,
                discount_amount,
                final_price,
                quotation_snapshot_json
            )
            VALUES
            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $bookingId,
            $leadId,
            $versionId,
            (int)($version['version_number'] ?? 1),
            !empty($version['package_id'])
                ? (int)$version['package_id']
                : null,
            (string)$version['package_title'],
            $version['package_description'] ?? null,
            $itineraryJson !== ''
                ? $itineraryJson
                : null,
            $version['inclusions'] ?? null,
            $version['exclusions'] ?? null,
            $snapshot['terms'] ?? null,
            $snapshot['customer_notes'] ?? null,
            trim(
                (string)($lead['destination'] ?? '')
            ) ?: null,
            $travelDate !== ''
                ? $travelDate
                : null,
            max(
                1,
                (int)($version['adults'] ?? 1)
            ),
            max(
                0,
                (int)($version['children'] ?? 0)
            ),
            $currency,
            max(
                0,
                (float)($version['base_price'] ?? 0)
            ),
            max(
                0,
                (float)($version['discount_amount'] ?? 0)
            ),
            $sellingPrice,
            json_encode(
                $snapshot,
                JSON_UNESCAPED_UNICODE
                | JSON_UNESCAPED_SLASHES
            )
        ]);

        /*
        |--------------------------------------------------------------------------
        | FREEZE TRIP SERVICES
        |--------------------------------------------------------------------------
        |
        | Pre-booking "selected" is not the same as supplier confirmation.
        | Supplier-backed services therefore enter Booking as
        | confirmation_required.
        |
        */

        $serviceStmt = $pdo->prepare("
            SELECT
                r.*,
                d.name AS destination_name
            FROM trip_service_requirements r
            LEFT JOIN destinations d
                ON d.id = r.destination_id
            WHERE r.trip_id = ?
            ORDER BY r.sort_order ASC, r.id ASC
        ");
        $serviceStmt->execute([$tripId]);

        $services =
            $serviceStmt->fetchAll(PDO::FETCH_ASSOC)
            ?: [];

        $costByService = [];

        if (
            $costSheet
            && crmTableExists($pdo, 'cost_sheet_items')
        ) {
            $costStmt = $pdo->prepare("
                SELECT
                    i.service_requirement_id,
                    MAX(i.supplier_id) AS supplier_id,
                    MAX(s.company_name) AS supplier_name,
                    COALESCE(
                        SUM(
                            CASE
                                WHEN i.source_type IN (
                                    'supplier_quote',
                                    'contract_rate'
                                )
                                THEN i.line_cost
                                ELSE 0
                            END
                        ),
                        0
                    ) AS supplier_cost
                FROM cost_sheet_items i
                LEFT JOIN suppliers s
                    ON s.id = i.supplier_id
                WHERE i.cost_sheet_id = ?
                  AND i.service_requirement_id IS NOT NULL
                GROUP BY i.service_requirement_id
            ");
            $costStmt->execute([
                (int)$costSheet['id']
            ]);

            foreach (
                $costStmt->fetchAll(PDO::FETCH_ASSOC)
                ?: []
                as $row
            ) {
                $costByService[
                    (int)$row['service_requirement_id']
                ] = $row;
            }
        }

        $insertService = $pdo->prepare("
            INSERT INTO booking_service_snapshots
            (
                booking_id,
                trip_id,
                source_service_requirement_id,
                sort_order,
                service_type,
                title,
                destination_id,
                destination_name,
                service_date_from,
                service_date_to,
                quantity,
                adults,
                children,
                specifications,
                source_supplier_id,
                source_supplier_name,
                internal_supplier_cost,
                procurement_status
            )
            VALUES
            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        foreach ($services as $service) {
            $sourceServiceId =
                (int)$service['id'];

            $serviceCost =
                $costByService[$sourceServiceId]
                ?? [];

            $serviceSupplierId =
                max(
                    0,
                    (int)($serviceCost['supplier_id'] ?? 0)
                );

            $serviceSupplierCost =
                max(
                    0,
                    (float)($serviceCost['supplier_cost'] ?? 0)
                );

            $procurementStatus =
                (
                    $serviceSupplierId > 0
                    || $serviceSupplierCost > 0
                )
                    ? 'confirmation_required'
                    : 'pending';

            $insertService->execute([
                $bookingId,
                $tripId,
                $sourceServiceId,
                (int)($service['sort_order'] ?? 0),
                (string)($service['service_type'] ?? 'other'),
                trim(
                    (string)($service['title'] ?? '')
                ) !== ''
                    ? trim((string)$service['title'])
                    : crmServiceRequirementTypeLabel(
                        (string)($service['service_type'] ?? 'other')
                    ),
                !empty($service['destination_id'])
                    ? (int)$service['destination_id']
                    : null,
                trim(
                    (string)($service['destination_name'] ?? '')
                ) ?: null,
                $service['service_date_from'] ?? null,
                $service['service_date_to'] ?? null,
                max(
                    0.01,
                    (float)($service['quantity'] ?? 1)
                ),
                max(
                    0,
                    (int)($service['adults'] ?? 0)
                ),
                max(
                    0,
                    (int)($service['children'] ?? 0)
                ),
                $service['specifications'] ?? null,
                $serviceSupplierId > 0
                    ? $serviceSupplierId
                    : null,
                trim(
                    (string)($serviceCost['supplier_name'] ?? '')
                ) ?: null,
                $serviceSupplierCost,
                $procurementStatus
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | AUTO-PREPARE POST-BOOKING SUPPLIER ORDERS
        |--------------------------------------------------------------------------
        |
        | Nothing is emailed automatically here. We only create idempotent DRAFT
        | supplier orders from the frozen accepted Booking services. Admin remains
        | in control of the actual send from Booking Details.
        |
        */

        $supplierProcurementPrepared = null;
        if (function_exists('tsSupplierAutoPrepareBookingOrders')) {
            try {
                $supplierProcurementPrepared =
                    tsSupplierAutoPrepareBookingOrders(
                        $pdo,
                        $bookingId,
                        $adminId
                    );
            } catch (Throwable $supplierBridgeError) {
                error_log(
                    'CRM supplier procurement auto-prepare: '
                    . $supplierBridgeError->getMessage()
                );
            }
        }

        /*
        |--------------------------------------------------------------------------
        | CONVERT SALES RECORDS
        |--------------------------------------------------------------------------
        */

        $conversionNote =
            "\n\nAccepted Quotation V"
            . (int)($version['version_number'] ?? 1)
            . ' converted to booking '
            . $bookingNumber
            . ' on '
            . date('d M Y h:i A')
            . '.';

        $stmt = $pdo->prepare("
            UPDATE enquiries
            SET
                status = 'converted',
                admin_notes = CONCAT(
                    COALESCE(admin_notes, ''),
                    ?
                )
            WHERE id = ?
        ");
        $stmt->execute([
            $conversionNote,
            $leadId
        ]);

        $stmt = $pdo->prepare("
            UPDATE trips
            SET
                stage = 'won',
                status = 'active',
                expected_value = ?,
                probability = 100,
                next_action = 'Booking created - confirm supplier services',
                next_action_date = NULL,
                updated_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([
            $sellingPrice,
            $tripId
        ]);

        $pdo->commit();

        return [
            'booking_id' => $bookingId,
            'booking_number' => $bookingNumber,
            'already_created' => false,
            'supplier_procurement' => $supplierProcurementPrepared,
        ];

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $e;
    }
}

