<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| BOOKING DETAILS
| HOTEL CATEGORY + PER-PERSON PRICE VERSION: 2026-08-04-R1
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';
$crmFunctionsFile = __DIR__ . '/crm-functions.php';
if (is_file($crmFunctionsFile)) {
    require_once $crmFunctionsFile;
}

$operationsFunctionsFile = __DIR__ . '/operations-functions.php';
if (is_file($operationsFunctionsFile)) {
    require_once $operationsFunctionsFile;
}

$amendmentFunctionsFile = __DIR__ . '/amendment-functions.php';
if (is_file($amendmentFunctionsFile)) {
    require_once $amendmentFunctionsFile;
}

$executionFunctionsFile = __DIR__ . '/execution-functions.php';
if (is_file($executionFunctionsFile)) {
    require_once $executionFunctionsFile;
}

$billingFunctionsFile = __DIR__ . '/billing-functions.php';
if (is_file($billingFunctionsFile)) {
    require_once $billingFunctionsFile;
}

$documentFunctionsFile = __DIR__ . '/document-functions.php';
if (is_file($documentFunctionsFile)) {
    require_once $documentFunctionsFile;
}

$communicationFunctionsFile = __DIR__ . '/communication-functions.php';
if (is_file($communicationFunctionsFile)) {
    require_once $communicationFunctionsFile;
}

requireLogin();

$user = currentUser($pdo);

if (!$user) {
    unset($_SESSION['user_id']);
    redirect(BASE_URL . 'login.php');
}

$userId = (int)$user['id'];


/*
|--------------------------------------------------------------------------
| SETTINGS
|--------------------------------------------------------------------------
*/

$siteName = 'TRAVSCOPE.COM';
$currencySymbol = '₹';

try {

    $siteName = getSetting(
        $pdo,
        'site_name',
        'TRAVSCOPE.COM'
    );

    $currencySymbol = getSetting(
        $pdo,
        'currency_symbol',
        '₹'
    );

} catch (Throwable $e) {

    error_log(
        'Booking details settings error: '
        . $e->getMessage()
    );
}



function bookingDetailsHotelCategoryLabel(?string $category): string
{
    $category = strtolower(trim((string)$category));

    return match ($category) {
        '3_star', '3' => '3 Star Hotel',
        '4_star', '4' => '4 Star Hotel',
        '5_star', '5' => '5 Star Hotel',
        default => 'Not specified'
    };
}


/*
|--------------------------------------------------------------------------
| BOOKING ID
|--------------------------------------------------------------------------
|
| Supports:
| booking-details.php?booking=123
| booking-details.php?id=123
|
|--------------------------------------------------------------------------
*/

$bookingId = 0;

if (isset($_GET['booking'])) {

    $bookingId = (int) $_GET['booking'];

} elseif (isset($_GET['id'])) {

    $bookingId = (int) $_GET['id'];
}


/*
|--------------------------------------------------------------------------
| VALIDATE BOOKING ID
|--------------------------------------------------------------------------
*/

if ($bookingId <= 0) {

    redirect(
        BASE_URL . 'my-bookings.php'
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| FETCH BOOKING
|--------------------------------------------------------------------------
|
| IMPORTANT:
| b.user_id = ? prevents users from opening somebody else's booking.
|--------------------------------------------------------------------------
*/

try {

    $stmt = $pdo->prepare("
        SELECT

            b.*,

            p.title AS package_title,
            p.slug AS package_slug,
            p.package_code,
            p.short_description,
            p.description AS package_description,
            p.duration_days,
            p.duration_nights,
            p.regular_price,
            p.sale_price,
            p.currency AS package_currency,
            p.package_type,
            p.main_image,
            p.inclusions,
            p.exclusions,
            p.itinerary,
            p.terms,
            p.featured,
            p.bestseller,

            d.name AS destination_name,
            d.slug AS destination_slug,
            d.country AS destination_country,
            d.continent AS destination_continent,
            d.short_description AS destination_short_description

        FROM bookings b

        LEFT JOIN packages p
            ON p.id = b.package_id

        LEFT JOIN destinations d
            ON d.id = p.destination_id

        WHERE
            b.id = ?
            AND b.user_id = ?

        LIMIT 1
    ");

    $stmt->execute([
        $bookingId,
        $userId
    ]);

    $booking = $stmt->fetch();

} catch (Throwable $e) {

    error_log(
        'Booking details fetch error: '
        . $e->getMessage()
    );

    $booking = false;
}


if (!$booking) {

    http_response_code(404);

    exit(
        'Booking not found or you do not have permission to view it.'
    );
}


/*
|--------------------------------------------------------------------------
| ACCEPTED CRM QUOTATION SNAPSHOT
|--------------------------------------------------------------------------
|
| If this Booking came from an accepted CRM quotation, customer-facing
| Booking Details use the frozen accepted quotation instead of later changes
| to Package Master.
|
*/

$bookingQuotationSnapshot = null;
$bookingServiceSnapshots = [];
$latestFinalVoucher = null;
$hasRevisedCommercial = false;

if (
    function_exists('crmBookingBridgeReady')
    && crmBookingBridgeReady($pdo)
) {
    try {
        $bookingQuotationSnapshot =
            crmBookingQuotationSnapshot(
                $pdo,
                $bookingId
            );

        $bookingServiceSnapshots =
            crmBookingServiceSnapshots(
                $pdo,
                $bookingId
            );

        if ($bookingQuotationSnapshot) {
            $snapshot =
                json_decode(
                    (string)(
                        $bookingQuotationSnapshot['quotation_snapshot_json']
                        ?? ''
                    ),
                    true
                );

            if (!is_array($snapshot)) {
                $snapshot = [];
            }

            /*
             * Customer Booking price must be the exact accepted quotation price.
             * Never fall back to Package Master / enquiry-time package pricing
             * when an immutable accepted quotation snapshot exists.
             */
            $acceptedFinalPrice =
                max(
                    0,
                    (float)(
                        $bookingQuotationSnapshot['final_price']
                        ?? 0
                    )
                );

            if ($acceptedFinalPrice > 0) {
                $hasRevisedCommercial = false;

                if (
                    function_exists('tsAmendTableExists')
                    && tsAmendTableExists($pdo, 'booking_amendments')
                ) {
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*)
                        FROM booking_amendments
                        WHERE booking_id = ?
                          AND status = 'approved'
                    ");
                    $stmt->execute([$bookingId]);
                    $hasRevisedCommercial =
                        (int)$stmt->fetchColumn() > 0;
                }

                if (
                    !$hasRevisedCommercial
                    && function_exists('tsBillReady')
                    && tsBillReady($pdo)
                ) {
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*)
                        FROM booking_billing_adjustments
                        WHERE booking_id = ?
                          AND status = 'posted'
                    ");
                    $stmt->execute([$bookingId]);
                    $hasRevisedCommercial =
                        (int)$stmt->fetchColumn() > 0;
                }

                if (!$hasRevisedCommercial) {
                    $booking['total_amount'] =
                        $acceptedFinalPrice;
                }
            }

            if (
                trim(
                    (string)(
                        $bookingQuotationSnapshot['currency']
                        ?? ''
                    )
                ) !== ''
            ) {
                $booking['currency'] =
                    strtoupper(
                        trim(
                            (string)$bookingQuotationSnapshot['currency']
                        )
                    );
            }

            if (
                array_key_exists(
                    'discount_amount',
                    $bookingQuotationSnapshot
                )
            ) {
                $booking['discount_amount'] =
                    max(
                        0,
                        (float)$bookingQuotationSnapshot['discount_amount']
                    );
            }

            $booking['package_title'] =
                (string)$bookingQuotationSnapshot['package_title'];

            if (
                trim(
                    (string)(
                        $bookingQuotationSnapshot['destination_name']
                        ?? ''
                    )
                ) !== ''
            ) {
                $booking['destination_name'] =
                    (string)$bookingQuotationSnapshot['destination_name'];
            }

            if (!empty($snapshot['package_code'])) {
                $booking['package_code'] =
                    (string)$snapshot['package_code'];
            }

            if (!empty($snapshot['package_type'])) {
                $booking['package_type'] =
                    (string)$snapshot['package_type'];
            }

            if (!empty($snapshot['main_image'])) {
                $booking['main_image'] =
                    (string)$snapshot['main_image'];
            }

            if (
                array_key_exists(
                    'duration_days',
                    $snapshot
                )
            ) {
                $booking['duration_days'] =
                    (int)$snapshot['duration_days'];
            }

            if (
                array_key_exists(
                    'duration_nights',
                    $snapshot
                )
            ) {
                $booking['duration_nights'] =
                    (int)$snapshot['duration_nights'];
            }

            if (
                trim(
                    (string)(
                        $bookingQuotationSnapshot['inclusions']
                        ?? ''
                    )
                ) !== ''
            ) {
                $booking['inclusions'] =
                    (string)$bookingQuotationSnapshot['inclusions'];
            }

            if (
                trim(
                    (string)(
                        $bookingQuotationSnapshot['exclusions']
                        ?? ''
                    )
                ) !== ''
            ) {
                $booking['exclusions'] =
                    (string)$bookingQuotationSnapshot['exclusions'];
            }

            if (
                trim(
                    (string)(
                        $bookingQuotationSnapshot['terms']
                        ?? ''
                    )
                ) !== ''
            ) {
                $booking['terms'] =
                    (string)$bookingQuotationSnapshot['terms'];
            }

            $itineraryRows =
                json_decode(
                    (string)(
                        $bookingQuotationSnapshot['itinerary_json']
                        ?? ''
                    ),
                    true
                );

            if (is_array($itineraryRows)) {
                $itineraryText = [];

                foreach ($itineraryRows as $day) {
                    if (!is_array($day)) {
                        continue;
                    }

                    $title =
                        trim(
                            (string)(
                                $day['title']
                                ?? ''
                            )
                        );

                    $description =
                        trim(
                            (string)(
                                $day['description']
                                ?? ''
                            )
                        );

                    if ($title === '' && $description === '') {
                        continue;
                    }

                    $line =
                        'Day '
                        . max(
                            1,
                            (int)(
                                $day['day_number']
                                ?? (
                                    count($itineraryText)
                                    + 1
                                )
                            )
                        );

                    if ($title !== '') {
                        $line .= ' — ' . $title;
                    }

                    if ($description !== '') {
                        $line .= "\n" . $description;
                    }

                    $itineraryText[] = $line;
                }

                if ($itineraryText) {
                    $booking['itinerary'] =
                        implode(
                            "\n\n",
                            $itineraryText
                        );
                }
            }
        }
    } catch (Throwable $e) {
        error_log(
            'Customer booking quotation snapshot error: '
            . $e->getMessage()
        );
    }
}


if (
    function_exists('tsOpsReady')
    && tsOpsReady($pdo)
) {
    try {
        $latestFinalVoucher =
            tsOpsLatestFinalVoucher(
                $pdo,
                $bookingId
            );
    } catch (Throwable $e) {
        error_log(
            'Customer Booking voucher load: '
            . $e->getMessage()
        );
    }
}


$customerBillingSchedule = null;
$customerBillingInstallments = [];
$customerBillingInvoice = null;
$customerBillingReceipts = [];
$customerBillingRefunds = [];
$customerBillingPendingRefund = 0.0;

if (
    function_exists('tsBillReady')
    && tsBillReady($pdo)
) {
    try {
        tsBillSyncSuccessfulPayments($pdo, $bookingId);
        tsBillSyncRefundObligations($pdo, $bookingId);

        $customerBillingSchedule = tsBillActiveSchedule($pdo, $bookingId);
        $customerBillingInstallments = $customerBillingSchedule
            ? tsBillInstallments($pdo, $bookingId, (int)$customerBillingSchedule['id'])
            : [];
        $customerBillingInvoice = tsBillLatestFinalInvoice($pdo, $bookingId);
        $customerBillingReceipts = tsBillReceipts($pdo, $bookingId);
        $customerBillingRefunds = tsBillRefunds($pdo, $bookingId);
        $customerBillingPendingRefund = tsBillPendingRefundTotal($pdo, $bookingId);
    } catch (Throwable $e) {
        error_log('Customer Billing booking-details load: ' . $e->getMessage());
    }
}


/*
|--------------------------------------------------------------------------
| PAYMENT HISTORY
|--------------------------------------------------------------------------
*/

$payments = [];

try {

    $stmt = $pdo->prepare("
        SELECT
            id,
            transaction_id,
            payment_gateway,
            amount,
            currency,
            payment_method,
            status,
            paid_at,
            created_at

        FROM payments

        WHERE booking_id = ?

        ORDER BY id DESC
    ");

    $stmt->execute([
        $bookingId
    ]);

    $payments = $stmt->fetchAll();

} catch (Throwable $e) {

    error_log(
        'Payment history error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| LATEST PAYMENT
|--------------------------------------------------------------------------
*/

$latestPayment =
    !empty($payments)
        ? $payments[0]
        : null;

$latestPaymentStatus =
    $latestPayment
        ? strtolower(
            (string)$latestPayment['status']
        )
        : '';


/*
|--------------------------------------------------------------------------
| PACKAGE GALLERY
|--------------------------------------------------------------------------
*/

$gallery = [];

try {

    $stmt = $pdo->prepare("
        SELECT
            image,
            alt_text,
            sort_order

        FROM package_images

        WHERE package_id = ?

        ORDER BY
            sort_order ASC,
            id ASC
    ");

    $stmt->execute([
        (int)$booking['package_id']
    ]);

    $gallery = $stmt->fetchAll();

} catch (Throwable $e) {

    error_log(
        'Package gallery error: '
        . $e->getMessage()
    );
}


$customerAmendmentHistory = [];
$customerPendingAmendment = null;

if (function_exists('tsAmendReady') && tsAmendReady($pdo)) {
    try {
        $customerAmendmentHistory = tsAmendHistory($pdo, $bookingId);
        $customerPendingAmendment = tsAmendPending($pdo, $bookingId);
    } catch (Throwable $e) {
        error_log('Customer Booking amendment load: ' . $e->getMessage());
    }
}

$customerExecutionState = null;
$customerExecutionContacts = [];
$customerExecutionUpdates = [];
$customerExecutionIncidents = [];

if (
    function_exists('tsExecReady')
    && tsExecReady($pdo)
) {
    try {
        $customerExecutionState =
            tsExecEnsureState(
                $pdo,
                $bookingId
            );

        $customerExecutionContacts =
            tsExecContacts(
                $pdo,
                $bookingId,
                true
            );

        $customerExecutionUpdates =
            tsExecUpdates(
                $pdo,
                $bookingId,
                true
            );

        $customerExecutionIncidents =
            tsExecIncidents(
                $pdo,
                $bookingId,
                true
            );

    } catch (Throwable $e) {
        error_log(
            'Customer Travel Execution load: '
            . $e->getMessage()
        );
    }
}


$isAcceptedCrmBooking =
    !empty($bookingQuotationSnapshot);


/*
|--------------------------------------------------------------------------
| AMOUNTS
|--------------------------------------------------------------------------
*/

$totalAmount = max(
    0,
    (float)$booking['total_amount']
);

$paidAmount = max(
    0,
    (float)$booking['paid_amount']
);

$remainingAmount = max(
    0,
    $totalAmount - $paidAmount
);

$hotelCategoryLabel =
    bookingDetailsHotelCategoryLabel(
        $booking['hotel_category']
        ?? ''
    );

$hotelPricePerAdult =
    max(
        0,
        (float)(
            $booking['hotel_price']
            ?? 0
        )
    );

$adultCount =
    max(
        1,
        (int)(
            $booking['adults']
            ?? 1
        )
    );

$adultPackageSubtotal =
    round(
        $hotelPricePerAdult
        * $adultCount,
        2
    );

$discountAmount =
    max(
        0,
        (float)(
            $booking['discount_amount']
            ?? 0
        )
    );


/*
|--------------------------------------------------------------------------
| STATUSES
|--------------------------------------------------------------------------
*/

$bookingStatus = strtolower(
    (string)$booking['booking_status']
);

$paymentStatus = strtolower(
    (string)$booking['payment_status']
);


/*
|--------------------------------------------------------------------------
| IMAGE URL
|--------------------------------------------------------------------------
*/

function travscopeImageUrl($image)
{
    $image = trim(
        (string)$image
    );

    if ($image === '') {
        return '';
    }

    if (
        preg_match(
            '#^https?://#i',
            $image
        )
    ) {
        return $image;
    }

    return
        BASE_URL
        . ltrim(
            $image,
            '/'
        );
}


$mainImage = travscopeImageUrl(
    $booking['main_image']
    ?? ''
);


/*
|--------------------------------------------------------------------------
| TEXT LIST PARSER
|--------------------------------------------------------------------------
|
| Works with:
|
| Airport pickup
| Hotel stay
| Breakfast
|
| OR
|
| Airport pickup, Hotel stay, Breakfast
|
|--------------------------------------------------------------------------
*/

function travscopeList($text)
{
    $text = trim(
        (string)$text
    );

    if ($text === '') {
        return [];
    }

    $items = preg_split(
        '/\r\n|\r|\n|,/',
        $text
    );

    $clean = [];

    foreach ($items as $item) {

        $item = trim(
            preg_replace(
                '/^[\-\*\x{2022}\s]+/u',
                '',
                $item
            )
        );

        if ($item !== '') {
            $clean[] = $item;
        }
    }

    return $clean;
}


$inclusions = travscopeList(
    $booking['inclusions']
    ?? ''
);

$exclusions = travscopeList(
    $booking['exclusions']
    ?? ''
);


/*
|--------------------------------------------------------------------------
| STATUS CSS CLASS
|--------------------------------------------------------------------------
*/

function statusClass($status)
{
    switch (
        strtolower(
            (string)$status
        )
    ) {

        case 'confirmed':
        case 'paid':
        case 'success':
        case 'completed':
            return 'success';

        case 'cancelled':
        case 'failed':
        case 'refunded':
            return 'danger';

        default:
            return 'pending';
    }
}


$customerDocumentSummary = null;
$customerFinalDocumentPack = null;
$customerCommunicationSummary = null;

if (
    function_exists('tsDocReady')
    && tsDocReady($pdo)
) {
    try {
        $customerDocumentSummary =
            tsDocSummary(
                $pdo,
                $bookingId
            );

        $customerFinalDocumentPack =
            $customerDocumentSummary[
                'latest_final_pack'
            ]
            ?? null;

    } catch (Throwable $e) {
        error_log(
            'Customer Booking Document Center summary: '
            . $e->getMessage()
        );
    }
}


if (
    function_exists('tsCommReady')
    && tsCommReady($pdo)
) {
    try {
        $customerCommunicationSummary =
            tsCommSummary(
                $pdo,
                $bookingId
            );
    } catch (Throwable $e) {
        error_log(
            'Customer Booking Communication summary: '
            . $e->getMessage()
        );
    }
}

?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#07192d"
>

<title>
<?= e($booking['booking_number']); ?>
| Booking Details
| <?= e($siteName); ?>
</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>

:root {

    --navy:#07192d;
    --navy2:#102d4c;

    --blue:#0b74ff;
    --blue2:#075fd2;

    --green:#07966a;
    --orange:#d98112;
    --red:#d94455;

    --background:#f5f7fa;
    --white:#fff;

    --text:#182337;
    --muted:#788596;

    --border:#e3e8ee;

    --shadow:
        0 12px 40px
        rgba(7,25,45,.07);
}

* {
    box-sizing:border-box;
    margin:0;
    padding:0;
}

body {

    background:var(--background);

    color:var(--text);

    font-family:
        'DM Sans',
        sans-serif;
}

a {
    color:inherit;
    text-decoration:none;
}


/* HEADER */

.header {

    height:72px;

    padding:0 5%;

    display:flex;
    align-items:center;
    justify-content:space-between;

    position:sticky;

    top:0;

    z-index:1000;

    background:
        rgba(255,255,255,.97);

    border-bottom:
        1px solid
        var(--border);

    backdrop-filter:
        blur(10px);
}

.logo {

    display:flex;
    align-items:center;

    gap:9px;

    font-family:
        'Manrope',
        sans-serif;

    color:var(--navy);

    font-size:20px;
    font-weight:800;
}

.logo-icon {

    width:39px;
    height:39px;

    border-radius:11px;

    display:grid;
    place-items:center;

    color:white;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            #00b9ff
        );
}

.logo span {
    color:var(--blue);
}

.nav {

    display:flex;
    align-items:center;

    gap:7px;
}

.nav a {

    padding:9px 11px;

    border-radius:7px;

    color:#687589;

    font-size:10px;
    font-weight:700;
}

.nav a:hover,
.nav a.active {

    background:#edf5ff;

    color:var(--blue);
}


/* HERO */

.hero {

    min-height:270px;

    padding:
        38px 5%
        75px;

    position:relative;

    color:white;

    background:
        radial-gradient(
            circle at 80% 20%,
            rgba(11,116,255,.45),
            transparent 30%
        ),
        linear-gradient(
            135deg,
            #07192d,
            #0b2948
        );

    overflow:hidden;
}

.hero-inner {

    max-width:1180px;

    margin:auto;

    position:relative;

    z-index:2;
}

.breadcrumb {

    display:flex;
    align-items:center;

    gap:7px;

    color:#a9bbce;

    font-size:9px;
}

.hero-main {

    margin-top:24px;

    display:flex;
    justify-content:space-between;

    gap:30px;
}

.hero h1 {

    max-width:720px;

    font-family:
        'Manrope',
        sans-serif;

    font-size:31px;

    line-height:1.3;
}

.location {

    margin-top:8px;

    color:#b7c6d6;

    font-size:10px;
}

.location i {

    margin-right:4px;

    color:#62b3ff;
}

.hero-tags {

    margin-top:14px;

    display:flex;

    gap:7px;

    flex-wrap:wrap;
}

.hero-tag {

    padding:7px 10px;

    border:
        1px solid
        rgba(255,255,255,.15);

    border-radius:7px;

    background:
        rgba(255,255,255,.08);

    font-size:8px;
    font-weight:700;
}

.hero-status {

    min-width:180px;

    text-align:right;
}

.hero-status span {

    padding:8px 12px;

    border-radius:30px;

    display:inline-flex;
    align-items:center;

    gap:6px;

    background:#eaf9f3;

    color:var(--green);

    font-size:9px;
    font-weight:800;

    text-transform:uppercase;
}


/* PAGE */

.container {

    max-width:1180px;

    margin:
        -43px auto
        0;

    padding:
        0 20px
        70px;

    position:relative;

    z-index:3;
}

.layout {

    display:grid;

    grid-template-columns:
        minmax(0,1fr)
        340px;

    gap:22px;
}


/* CARD */

.card {

    margin-bottom:18px;

    border:
        1px solid
        var(--border);

    border-radius:15px;

    overflow:hidden;

    background:white;

    box-shadow:var(--shadow);
}

.card-header {

    min-height:59px;

    padding:0 20px;

    border-bottom:
        1px solid
        var(--border);

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:15px;
}

.card-title {

    display:flex;
    align-items:center;

    gap:8px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:13px;
    font-weight:800;
}

.card-title i {
    color:var(--blue);
}

.card-body {
    padding:21px;
}


/* PACKAGE */

.package-overview {

    display:grid;

    grid-template-columns:
        220px
        minmax(0,1fr);

    gap:20px;
}

.package-image {

    height:160px;

    border-radius:11px;

    overflow:hidden;

    display:grid;
    place-items:center;

    background:
        linear-gradient(
            135deg,
            #0e2d4e,
            var(--blue)
        );

    color:white;

    font-size:35px;
}

.package-image img {

    width:100%;
    height:100%;

    object-fit:cover;
}

.package-content h2 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:20px;
}

.package-content p {

    margin-top:8px;

    color:var(--muted);

    font-size:10px;

    line-height:1.7;
}

.package-stats {

    margin-top:13px;

    display:flex;

    gap:7px;

    flex-wrap:wrap;
}

.package-stat {

    padding:7px 9px;

    border-radius:7px;

    background:#f3f6f9;

    color:#617084;

    font-size:8px;
    font-weight:700;
}


/* DETAILS */

.details-grid {

    display:grid;

    grid-template-columns:
        repeat(2,1fr);

    gap:0 25px;
}

.detail {

    min-height:64px;

    padding:11px 0;

    border-bottom:
        1px solid
        #edf0f3;
}

.detail span {

    display:block;

    color:#8a95a3;

    font-size:8px;

    text-transform:uppercase;

    letter-spacing:.4px;
}

.detail strong {

    display:block;

    margin-top:5px;

    color:#344156;

    font-size:10px;

    line-height:1.5;

    word-break:break-word;
}


/* STATUS */

.status {

    padding:5px 8px;

    border-radius:20px;

    display:inline-flex !important;
    align-items:center;

    gap:4px;

    width:auto;

    font-size:8px !important;
}

.status.success {

    background:#e8f8f1;

    color:#087c55;
}

.status.pending {

    background:#fff3e3;

    color:#a96710;
}

.status.danger {

    background:#ffedef;

    color:#bd3547;
}


/* ITINERARY */

.itinerary {

    color:#566477;

    font-size:10px;

    line-height:1.85;
}

.itinerary h1,
.itinerary h2,
.itinerary h3 {

    margin:
        17px 0
        7px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;
}

.itinerary p {
    margin-bottom:10px;
}

.itinerary ul,
.itinerary ol {

    margin:
        8px 0
        10px 20px;
}


/* INCLUDED */

.two-column {

    display:grid;

    grid-template-columns:
        1fr 1fr;

    gap:20px;
}

.list-title {

    margin-bottom:12px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:12px;
}

.feature-list {

    display:flex;
    flex-direction:column;

    gap:9px;
}

.feature {

    display:flex;
    align-items:flex-start;

    gap:8px;

    color:#5e6c7f;

    font-size:9px;

    line-height:1.5;
}

.feature i {

    width:18px;
    height:18px;

    flex:0 0 18px;

    border-radius:50%;

    display:grid;
    place-items:center;

    font-size:8px;
}

.feature.include i {

    background:#e7f8f0;

    color:var(--green);
}

.feature.exclude i {

    background:#ffedef;

    color:var(--red);
}


/* TERMS */

.terms {

    color:#687588;

    font-size:9px;

    line-height:1.8;

    white-space:pre-line;
}


/* PAYMENT SUMMARY */

.summary-card {

    position:sticky;

    top:92px;
}

.booking-number {

    padding:13px;

    border-radius:9px;

    background:#f4f7fa;
}

.booking-number span {

    display:block;

    color:#8a96a5;

    font-size:8px;

    text-transform:uppercase;
}

.booking-number strong {

    display:block;

    margin-top:4px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:14px;
}

.amounts {

    margin-top:16px;
}

.amount-row {

    padding:10px 0;

    border-bottom:
        1px solid
        #edf0f3;

    display:flex;
    justify-content:space-between;

    gap:15px;

    font-size:9px;
}

.amount-row span {
    color:#7d8998;
}

.amount-row strong {
    color:var(--navy);
}

.amount-row.total {

    border-bottom:0;
}

.amount-row.total strong {

    color:var(--blue);

    font-family:
        'Manrope',
        sans-serif;

    font-size:20px;
}


/* PAYMENT HISTORY */

.payment-history {

    margin-top:17px;
}

.payment-history h3 {

    margin-bottom:10px;

    color:var(--navy);

    font-size:10px;
}

.payment-item {

    margin-bottom:8px;

    padding:11px;

    border:
        1px solid
        #e8ecf0;

    border-radius:8px;

    background:#fafbfd;
}

.payment-item-top {

    display:flex;
    justify-content:space-between;

    gap:10px;
}

.payment-item strong {

    color:#3d4b60;

    font-size:9px;
}

.payment-item small {

    color:#8a96a5;

    font-size:7px;
}

.utr {

    margin-top:6px;

    color:var(--blue);

    font-family:monospace;

    font-size:8px;

    word-break:break-all;
}


/* ACTIONS */

.actions {

    margin-top:17px;

    display:flex;
    flex-direction:column;

    gap:7px;
}

.btn {

    min-height:42px;

    padding:0 13px;

    border-radius:8px;

    display:flex;
    align-items:center;
    justify-content:center;

    gap:6px;

    font-size:9px;
    font-weight:800;

    transition:.2s;
}

.btn:hover {
    transform:translateY(-1px);
}

.btn-primary {

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--blue2)
        );

    color:white;
}

.btn-success {

    background:var(--green);

    color:white;
}

.btn-warning {

    background:#fff1dc;

    color:#a9660e;
}

.btn-secondary {

    border:
        1px solid
        var(--border);

    background:white;

    color:#617084;
}


/* REVIEW ACTIONS */

.btn-review {

    position:relative;

    overflow:hidden;

    border:1px solid #ffd36d;

    background:
        linear-gradient(
            135deg,
            #ffb31a,
            #f28b0c
        );

    color:#fff;

    box-shadow:
        0 8px 22px
        rgba(242,139,12,.22);
}

.btn-review:hover {

    box-shadow:
        0 11px 28px
        rgba(242,139,12,.30);
}

.btn-review i {
    color:#fff;
}


/* PENDING REVIEW */

.btn-review-pending {

    border:1px solid #f0d5a6;

    background:#fff7e8;

    color:#a86a0c;
}


/* APPROVED REVIEW */

.btn-review-approved {

    border:1px solid #bde5d4;

    background:#e9f9f2;

    color:#087952;
}


/* REJECTED REVIEW */

.btn-review-rejected {

    border:1px solid #efc5cb;

    background:#fff0f2;

    color:#b43849;
}

<?php
/*
|--------------------------------------------------------------------------
| REVIEW ACTION
|--------------------------------------------------------------------------
*/

if ($bookingStatus === 'completed'):
?>

    <?php if (!$bookingReview): ?>

        <a
            href="<?= e(
                BASE_URL
                . 'write-review.php?booking_id='
                . $bookingId
            ); ?>"
            class="btn btn-review"
        >

            <i class="fa-solid fa-star"></i>

            Write a Review

        </a>


    <?php elseif (
        $bookingReview['status'] === 'pending'
    ): ?>

        <a
            href="<?= e(
                BASE_URL
                . 'review-success.php?id='
                . (int)$bookingReview['id']
            ); ?>"
            class="btn btn-review-pending"
        >

            <i class="fa-regular fa-clock"></i>

            Review Pending Approval

        </a>


    <?php elseif (
        $bookingReview['status'] === 'approved'
    ): ?>

        <a
            href="<?= e(
                BASE_URL
                . 'review-success.php?id='
                . (int)$bookingReview['id']
            ); ?>"
            class="btn btn-review-approved"
        >

            <i class="fa-solid fa-circle-check"></i>

            View Your Approved Review

        </a>


    <?php elseif (
        $bookingReview['status'] === 'rejected'
    ): ?>

        <a
            href="<?= e(
                BASE_URL
                . 'review-success.php?id='
                . (int)$bookingReview['id']
            ); ?>"
            class="btn btn-review-rejected"
        >

            <i class="fa-solid fa-circle-info"></i>

            View Review Status

        </a>

    <?php endif; ?>

<?php endif; ?>


/* GALLERY */

.gallery {

    display:grid;

    grid-template-columns:
        repeat(3,1fr);

    gap:10px;
}

.gallery-item {

    height:130px;

    border-radius:9px;

    overflow:hidden;

    background:#edf1f5;
}

.gallery-item img {

    width:100%;
    height:100%;

    object-fit:cover;

    transition:.3s;
}

.gallery-item:hover img {
    transform:scale(1.05);
}


/* MOBILE */

@media(max-width:900px) {

    .layout {
        grid-template-columns:1fr;
    }

    .summary-card {
        position:static;
    }
}

@media(max-width:700px) {

    .nav {
        display:none;
    }

    .hero-main {
        flex-direction:column;
    }

    .hero-status {
        text-align:left;
    }

    .package-overview {
        grid-template-columns:1fr;
    }

    .package-image {
        height:210px;
    }

    .details-grid,
    .two-column {
        grid-template-columns:1fr;
    }

    .gallery {
        grid-template-columns:1fr 1fr;
    }
}

@media(max-width:500px) {

    .header {
        padding:0 13px;
    }

    .hero {

        padding:
            28px 15px
            68px;
    }

    .hero h1 {
        font-size:25px;
    }

    .container {
        padding:0 12px 50px;
    }

    .card-body {
        padding:16px;
    }

    .gallery {
        grid-template-columns:1fr;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-public-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="public"></script>
</head>

<body>


<!-- =========================================================
     HEADER
========================================================= -->

<header class="header">

<a
    href="<?= e(BASE_URL); ?>"
    class="logo"
>

    <div class="logo-icon">
        <i class="fa-solid fa-plane"></i>
    </div>

    TRAV<span>SCOPE</span>

</a>


<nav class="nav">

    <a href="<?= e(BASE_URL . 'dashboard.php'); ?>">
        Dashboard
    </a>

    <a href="<?= e(BASE_URL . 'packages.php'); ?>">
        Packages
    </a>

    <a
        href="<?= e(BASE_URL . 'my-bookings.php'); ?>"
        class="active"
    >
        My Bookings
    </a>

</nav>

</header>


<!-- =========================================================
     HERO
========================================================= -->

<section class="hero">

<div class="hero-inner">


<div class="breadcrumb">

    <a href="<?= e(BASE_URL . 'dashboard.php'); ?>">
        Dashboard
    </a>

    <i class="fa-solid fa-chevron-right"></i>

    <a href="<?= e(BASE_URL . 'my-bookings.php'); ?>">
        My Bookings
    </a>

    <i class="fa-solid fa-chevron-right"></i>

    <?= e($booking['booking_number']); ?>

</div>


<div class="hero-main">


<div>

    <h1>
        <?= e(
            $booking['package_title']
            ?: 'Travel Package'
        ); ?>
    </h1>


    <div class="location">

        <i class="fa-solid fa-location-dot"></i>

        <?= e(
            $booking['destination_name']
            ?: 'Destination'
        ); ?>

        <?php if (
            !empty(
                $booking['destination_country']
            )
        ): ?>

            ,
            <?= e(
                $booking['destination_country']
            ); ?>

        <?php endif; ?>

    </div>


    <div class="hero-tags">


        <span class="hero-tag">

            <i class="fa-regular fa-clock"></i>

            <?= (int)$booking['duration_days']; ?>
            Days /

            <?= (int)$booking['duration_nights']; ?>
            Nights

        </span>


        <span class="hero-tag">

            <i class="fa-solid fa-users"></i>

            <?= (int)$booking['adults']; ?>
            Adult<?= (int)$booking['adults'] !== 1 ? 's' : ''; ?>

            <?php if (
                (int)$booking['children'] > 0
            ): ?>

                +
                <?= (int)$booking['children']; ?>
                Child<?= (int)$booking['children'] !== 1 ? 'ren' : ''; ?>

            <?php endif; ?>

        </span>


        <span class="hero-tag">

            <i class="fa-solid fa-hotel"></i>

            <?= e($hotelCategoryLabel); ?>

        </span>


        <?php if (
            !empty(
                $booking['package_code']
            )
        ): ?>

            <span class="hero-tag">

                <i class="fa-solid fa-tag"></i>

                <?= e(
                    $booking['package_code']
                ); ?>

            </span>

        <?php endif; ?>


    </div>

</div>


<div class="hero-status">

    <span>

        <i class="fa-solid fa-circle"></i>

        <?= e(
            ucfirst(
                $bookingStatus
            )
        ); ?>

    </span>

</div>


</div>

</div>

</section>


<!-- =========================================================
     PAGE
========================================================= -->

<main class="container">

<div class="layout">


<!-- =========================================================
     LEFT
========================================================= -->

<div>


<!-- PACKAGE OVERVIEW -->

<section class="card">

<div class="card-header">

    <div class="card-title">

        <i class="fa-solid fa-suitcase-rolling"></i>

        Package Overview

    </div>

</div>


<div class="card-body">

<div class="package-overview">


<div class="package-image">

    <?php if ($mainImage !== ''): ?>

        <img
            src="<?= e($mainImage); ?>"
            alt="<?= e(
                $booking['package_title']
                ?: 'Travel Package'
            ); ?>"
        >

    <?php else: ?>

        <i class="fa-solid fa-mountain-sun"></i>

    <?php endif; ?>

</div>


<div class="package-content">

    <h2>
        <?= e(
            $booking['package_title']
            ?: 'Travel Package'
        ); ?>
    </h2>


    <?php if (
        !empty(
            $booking['short_description']
        )
    ): ?>

        <p>
            <?= e(
                $booking['short_description']
            ); ?>
        </p>

    <?php endif; ?>


    <div class="package-stats">


        <span class="package-stat">

            <i class="fa-regular fa-calendar"></i>

            <?= (int)$booking['duration_days']; ?>
            Days

        </span>


        <span class="package-stat">

            <i class="fa-regular fa-moon"></i>

            <?= (int)$booking['duration_nights']; ?>
            Nights

        </span>


        <span class="package-stat">

            <i class="fa-solid fa-hotel"></i>

            <?= e($hotelCategoryLabel); ?>

        </span>


        <span class="package-stat">

            <i class="fa-solid fa-indian-rupee-sign"></i>

            <?php if ($hotelPricePerAdult > 0): ?>

                <?= e($currencySymbol); ?>
                <?= number_format(
                    $hotelPricePerAdult,
                    2
                ); ?>
                / Adult

            <?php else: ?>

                Price unavailable

            <?php endif; ?>

        </span>


        <?php if (
            !empty(
                $booking['package_type']
            )
        ): ?>

            <span class="package-stat">

                <i class="fa-solid fa-tag"></i>

                <?= e(
                    ucfirst(
                        $booking['package_type']
                    )
                ); ?>

            </span>

        <?php endif; ?>


    </div>

</div>


</div>

</div>

</section>


<!-- =========================================================
     TRAVELLER / BOOKING DETAILS
========================================================= -->

<section class="card">

<div class="card-header">

    <div class="card-title">

        <i class="fa-regular fa-address-card"></i>

        Booking & Traveller Details

    </div>

</div>


<div class="card-body">

<div class="details-grid">


<div class="detail">

    <span>
        Booking Number
    </span>

    <strong>
        <?= e(
            $booking['booking_number']
        ); ?>
    </strong>

</div>


<div class="detail">

    <span>
        Booking Status
    </span>

    <strong
        class="status <?= e(
            statusClass(
                $bookingStatus
            )
        ); ?>"
    >

        <?= e(
            ucfirst(
                $bookingStatus
            )
        ); ?>

    </strong>

</div>


<div class="detail">

    <span>
        Traveller Name
    </span>

    <strong>
        <?= e(
            $booking['customer_name']
        ); ?>
    </strong>

</div>


<div class="detail">

    <span>
        Email
    </span>

    <strong>
        <?= e(
            $booking['customer_email']
        ); ?>
    </strong>

</div>


<div class="detail">

    <span>
        Mobile
    </span>

    <strong>
        <?= e(
            $booking['customer_mobile']
        ); ?>
    </strong>

</div>


<div class="detail">

    <span>
        Travel Date
    </span>

    <strong>

        <?php if (
            !empty(
                $booking['travel_date']
            )
        ): ?>

            <?= e(
                date(
                    'd M Y',
                    strtotime(
                        $booking['travel_date']
                    )
                )
            ); ?>

        <?php else: ?>

            To be confirmed

        <?php endif; ?>

    </strong>

</div>


<div class="detail">

    <span>
        Hotel Category
    </span>

    <strong>
        <?= e($hotelCategoryLabel); ?>
    </strong>

</div>


<div class="detail">

    <span>
        Price Per Adult
    </span>

    <strong>

        <?php if ($hotelPricePerAdult > 0): ?>

            <?= e($currencySymbol); ?>
            <?= number_format(
                $hotelPricePerAdult,
                2
            ); ?>

        <?php else: ?>

            Not available

        <?php endif; ?>

    </strong>

</div>


<div class="detail">

    <span>
        Adult Package Amount
    </span>

    <strong>
        <?= e($currencySymbol); ?>
        <?= number_format(
            $adultPackageSubtotal,
            2
        ); ?>
    </strong>

</div>


<div class="detail">

    <span>
        Adults
    </span>

    <strong>
        <?= (int)$booking['adults']; ?>
    </strong>

</div>


<div class="detail">

    <span>
        Children
    </span>

    <strong>
        <?= (int)$booking['children']; ?>
    </strong>

</div>


<div class="detail">

    <span>
        Payment Status
    </span>

    <strong
        class="status <?= e(
            statusClass(
                $paymentStatus
            )
        ); ?>"
    >

        <?= e(
            ucfirst(
                $paymentStatus
            )
        ); ?>

    </strong>

</div>


<div class="detail">

    <span>
        Booking Created
    </span>

    <strong>

        <?= e(
            date(
                'd M Y, h:i A',
                strtotime(
                    $booking['created_at']
                )
            )
        ); ?>

    </strong>

</div>


<?php if (
    !empty(
        $booking['special_request']
    )
): ?>

<div class="detail">

    <span>
        Special Request
    </span>

    <strong>
        <?= nl2br(
            e(
                $booking['special_request']
            )
        ); ?>
    </strong>

</div>

<?php endif; ?>


</div>

</div>

</section>


<?php if (
    $customerExecutionState
    && (
        (string)$customerExecutionState['execution_status'] !== 'pre_departure'
        || $customerExecutionContacts
        || $customerExecutionUpdates
    )
): ?>

<section class="card">

<div class="card-header">
    <div class="card-title">
        <i class="fa-solid fa-route"></i>
        Trip Support & Live Travel
    </div>
</div>

<div class="card-body">

    <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;padding:12px 14px;border:1px solid <?= $customerExecutionState['execution_status']==='completed' ? '#a7f3d0' : '#fed7aa'; ?>;border-radius:12px;background:<?= $customerExecutionState['execution_status']==='completed' ? '#ecfdf5' : '#fff7ed'; ?>;">
        <div>
            <strong style="display:block;color:<?= $customerExecutionState['execution_status']==='completed' ? '#047857' : '#c2410c'; ?>;">
                <?= $customerExecutionState['execution_status']==='completed' ? 'Trip Completed' : 'Trip In Progress'; ?>
            </strong>
            <small style="display:block;margin-top:4px;color:#64748b;line-height:1.5;">
                <?= $customerExecutionState['execution_status']==='completed'
                    ? 'Your TRAVSCOPE journey has been marked complete.'
                    : 'Your trip is in live operational support. Customer-visible contacts and updates appear below.'; ?>
            </small>
        </div>

        <?php if (
            $customerExecutionState['execution_status'] === 'completed'
            && !empty($booking['package_id'])
        ): ?>
            <a
                href="<?= e(BASE_URL . 'reviews.php'); ?>"
                style="display:inline-flex;align-items:center;gap:7px;padding:10px 13px;border-radius:9px;background:#059669;color:#fff;text-decoration:none;font-weight:800;font-size:11px;"
            >
                <i class="fa-solid fa-star"></i>
                Share Feedback
            </a>
        <?php endif; ?>
    </div>

    <?php if ($customerExecutionContacts): ?>
        <div style="margin-top:12px;">
            <strong style="display:block;color:#0f172a;font-size:12px;margin-bottom:7px;">Operational Contacts</strong>
            <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;">
                <?php foreach ($customerExecutionContacts as $contact): ?>
                    <div style="padding:10px;border:1px solid #e2e8f0;border-radius:10px;background:#fbfdff;">
                        <strong style="display:block;color:#334155;font-size:11px;">
                            <?= e(tsExecContactTypes()[(string)$contact['contact_type']] ?? ucwords(str_replace('_',' ',(string)$contact['contact_type']))); ?>
                            · <?= e((string)$contact['contact_name']); ?>
                        </strong>
                        <?php if (!empty($contact['organization'])): ?><small style="display:block;margin-top:4px;color:#64748b;"><?= e((string)$contact['organization']); ?></small><?php endif; ?>
                        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:7px;">
                            <?php if (!empty($contact['mobile'])): ?><a href="tel:<?= e((string)$contact['mobile']); ?>" style="font-size:10px;font-weight:800;color:#1d4ed8;"><i class="fa-solid fa-phone"></i> <?= e((string)$contact['mobile']); ?></a><?php endif; ?>
                            <?php if (!empty($contact['whatsapp'])): ?><span style="font-size:10px;font-weight:800;color:#047857;"><i class="fa-brands fa-whatsapp"></i> <?= e((string)$contact['whatsapp']); ?></span><?php endif; ?>
                        </div>
                        <?php if (!empty($contact['details'])): ?><small style="display:block;margin-top:6px;color:#64748b;line-height:1.5;"><?= nl2br(e((string)$contact['details'])); ?></small><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($customerExecutionUpdates): ?>
        <div style="margin-top:12px;">
            <strong style="display:block;color:#0f172a;font-size:12px;margin-bottom:7px;">Travel Updates</strong>
            <div style="display:grid;gap:7px;">
                <?php foreach (array_slice($customerExecutionUpdates,0,12) as $update): ?>
                    <div style="padding:9px 10px;border-left:3px solid #2563eb;border-radius:0 9px 9px 0;background:#f8fafc;">
                        <strong style="display:block;color:#334155;font-size:10px;"><?= e((string)$update['title']); ?></strong>
                        <small style="display:block;margin-top:3px;color:#64748b;"><?= e(date('d M Y, h:i A',strtotime((string)$update['created_at']))); ?></small>
                        <?php if (!empty($update['details'])): ?><div style="margin-top:5px;color:#475569;font-size:10px;line-height:1.5;"><?= nl2br(e((string)$update['details'])); ?></div><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($customerExecutionIncidents): ?>
        <div style="margin-top:12px;">
            <strong style="display:block;color:#0f172a;font-size:12px;margin-bottom:7px;">Service Support Updates</strong>
            <div style="display:grid;gap:7px;">
                <?php foreach ($customerExecutionIncidents as $incident): ?>
                    <div style="padding:9px 10px;border:1px solid <?= $incident['status']==='resolved' ? '#a7f3d0' : '#fed7aa'; ?>;border-radius:10px;background:<?= $incident['status']==='resolved' ? '#ecfdf5' : '#fff7ed'; ?>;">
                        <div style="display:flex;justify-content:space-between;gap:8px;">
                            <strong style="font-size:10px;color:#334155;"><?= e((string)$incident['title']); ?></strong>
                            <span style="font-size:8px;font-weight:900;color:<?= $incident['status']==='resolved' ? '#047857' : '#c2410c'; ?>;"><?= e(strtoupper((string)$incident['status'])); ?></span>
                        </div>
                        <?php if (!empty($incident['customer_note'])): ?><div style="margin-top:5px;color:#475569;font-size:10px;line-height:1.5;"><?= nl2br(e((string)$incident['customer_note'])); ?></div><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

</div>
</section>

<?php endif; ?>


<?php if (function_exists('tsAmendReady') && tsAmendReady($pdo)): ?>
<section class="card">
<div class="card-header"><div class="card-title"><i class="fa-solid fa-pen-to-square"></i> Booking Changes</div></div>
<div class="card-body">
    <?php if ($customerPendingAmendment): ?>
        <div style="padding:12px 14px;border:1px solid #fed7aa;border-radius:12px;background:#fff7ed;">
            <strong style="display:block;color:#c2410c;">Amendment V<?= (int)$customerPendingAmendment['version_number']; ?> is under review</strong>
            <div style="margin-top:5px;color:#64748b;font-size:11px;line-height:1.55;"><?= nl2br(e((string)$customerPendingAmendment['request_text'])); ?></div>
        </div>
    <?php elseif (!in_array(strtolower((string)$booking['booking_status']), ['cancelled','completed'], true)): ?>
        <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;padding:12px 14px;border:1px solid #dbeafe;border-radius:12px;background:#eff6ff;">
            <div><strong style="display:block;color:#1d4ed8;">Need to change this Booking?</strong><small style="display:block;margin-top:4px;color:#64748b;line-height:1.45;">Request a hotel, date, transport, activity or other change. TRAVSCOPE checks supplier and price impact before approval.</small></div>
            <a href="<?= e(BASE_URL . 'request-booking-change.php?booking=' . $bookingId); ?>" style="display:inline-flex;align-items:center;gap:7px;padding:10px 13px;border-radius:9px;background:#2563eb;color:#fff;text-decoration:none;font-weight:800;font-size:11px;"><i class="fa-solid fa-pen"></i> Request Change</a>
        </div>
    <?php endif; ?>

    <?php $visibleAmendments=array_values(array_filter($customerAmendmentHistory,static fn($row)=>in_array((string)($row['status']??''),['approved','rejected'],true))); ?>
    <?php if ($visibleAmendments): ?>
        <div style="display:grid;gap:8px;margin-top:10px;">
            <?php foreach (array_slice($visibleAmendments,0,5) as $row): ?>
                <div style="padding:10px 11px;border:1px solid #e2e8f0;border-radius:10px;background:#fbfdff;">
                    <div style="display:flex;justify-content:space-between;gap:10px;"><strong style="font-size:11px;color:#334155;">Amendment V<?= (int)$row['version_number']; ?></strong><span style="font-size:9px;font-weight:900;color:<?= $row['status']==='approved'?'#047857':'#64748b'; ?>;"><?= e(strtoupper((string)$row['status'])); ?></span></div>
                    <div style="margin-top:5px;color:#64748b;font-size:10px;line-height:1.5;"><?= nl2br(e((string)$row['request_text'])); ?></div>
                    <?php if ($row['status']==='approved'): ?><div style="margin-top:6px;color:#1d4ed8;font-size:10px;font-weight:800;">Revised Booking Total: <?= e($currencySymbol); ?><?= number_format((float)$row['revised_customer_price'],2); ?></div><?php endif; ?>
                    <?php if (!empty($row['customer_message'])): ?><div style="margin-top:6px;color:#475569;font-size:10px;"><?= nl2br(e((string)$row['customer_message'])); ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
</section>
<?php endif; ?>


<?php if (
    function_exists('tsCommReady')
    && tsCommReady($pdo)
    && is_array($customerCommunicationSummary)
): ?>

<section class="card" id="customer-communication-center">
<div class="card-header"><div class="card-title"><i class="fa-solid fa-comments"></i> Messages & Communication</div></div>
<div class="card-body">
    <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap;padding:11px;border:1px solid #dbeafe;border-radius:10px;background:#eff6ff;">
        <div>
            <strong style="display:block;color:#1d4ed8;font-size:11px;">Your TRAVSCOPE Communication History</strong>
            <small style="display:block;margin-top:4px;color:#64748b;font-size:9px;line-height:1.5;">
                View your accepted quotation email conversation together with post-booking emails and recorded customer communication. Internal Admin notes are never shown.
            </small>
        </div>

        <a
            href="<?= e(
                BASE_URL
                . 'booking-communications.php?booking='
                . $bookingId
            ); ?>"
            class="btn btn-primary"
        >
            <i class="fa-solid fa-message"></i>
            Open Messages
        </a>
    </div>
</div>
</section>

<?php endif; ?>


<?php if (
    function_exists('tsDocReady')
    && tsDocReady($pdo)
    && is_array($customerDocumentSummary)
): ?>

<section class="card" id="traveller-document-center">

<div class="card-header">

    <div class="card-title">
        <i class="fa-solid fa-passport"></i>
        Travel Documents
    </div>

</div>

<div class="card-body">

    <div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px;margin-bottom:10px;">
        <div style="padding:9px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc;">
            <small style="display:block;color:#64748b;font-size:8px;font-weight:900;text-transform:uppercase;">Travellers</small>
            <strong style="display:block;margin-top:4px;">
                <?= (int)$customerDocumentSummary['active_travellers']; ?>
                /
                <?= (int)$customerDocumentSummary['expected_travellers']; ?>
            </strong>
        </div>

        <div style="padding:9px;border:1px solid #a7f3d0;border-radius:10px;background:#ecfdf5;">
            <small style="display:block;color:#047857;font-size:8px;font-weight:900;text-transform:uppercase;">Verified</small>
            <strong style="display:block;margin-top:4px;color:#047857;">
                <?= (int)$customerDocumentSummary['verified_documents']; ?>
            </strong>
        </div>

        <div style="padding:9px;border:1px solid #fed7aa;border-radius:10px;background:#fff7ed;">
            <small style="display:block;color:#c2410c;font-size:8px;font-weight:900;text-transform:uppercase;">Waiting Review</small>
            <strong style="display:block;margin-top:4px;color:#c2410c;">
                <?= (int)$customerDocumentSummary['pending_documents']; ?>
            </strong>
        </div>

        <div style="padding:9px;border:1px solid #fecaca;border-radius:10px;background:#fef2f2;">
            <small style="display:block;color:#b91c1c;font-size:8px;font-weight:900;text-transform:uppercase;">Required Missing</small>
            <strong style="display:block;margin-top:4px;color:#b91c1c;">
                <?= (int)$customerDocumentSummary['missing_requirements']; ?>
            </strong>
        </div>
    </div>

    <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap;padding:11px;border:1px solid #dbeafe;border-radius:10px;background:#eff6ff;">
        <div>
            <strong style="display:block;color:#1d4ed8;font-size:11px;">
                Traveller & Trip File Center
            </strong>

            <small style="display:block;margin-top:4px;color:#64748b;font-size:9px;line-height:1.5;">
                Add traveller names, upload Passport/Visa/ID/Ticket/Insurance files, reuse Profile Vault documents and follow TRAVSCOPE verification.
            </small>
        </div>

        <a
            href="<?= e(
                BASE_URL
                . 'booking-documents.php?booking='
                . $bookingId
            ); ?>"
            class="btn btn-primary"
        >
            <i class="fa-solid fa-folder-open"></i>
            Open Documents
        </a>
    </div>

    <?php if ($customerFinalDocumentPack): ?>
        <div style="display:flex;gap:7px;flex-wrap:wrap;margin-top:9px;">
            <a
                href="<?= e(
                    BASE_URL
                    . 'booking-document-pack.php?pack='
                    . (int)$customerFinalDocumentPack['id']
                ); ?>"
                target="_blank"
                class="btn btn-secondary"
            >
                <i class="fa-solid fa-box-archive"></i>
                Final Trip Document Pack
            </a>

            <a
                href="<?= e(
                    BASE_URL
                    . 'booking-document-pack-download.php?pack='
                    . (int)$customerFinalDocumentPack['id']
                ); ?>"
                class="btn btn-secondary"
            >
                <i class="fa-solid fa-file-zipper"></i>
                Download Verified Files
            </a>
        </div>
    <?php endif; ?>

</div>

</section>

<?php endif; ?>


<?php if ($latestFinalVoucher): ?>

<section class="card">

<div class="card-header">

    <div class="card-title">

        <i class="fa-solid fa-ticket"></i>

        Travel Voucher

    </div>

</div>

<div class="card-body">

    <div style="display:flex;justify-content:space-between;align-items:center;gap:14px;flex-wrap:wrap;padding:14px;border:1px solid #bbf7d0;border-radius:14px;background:#f0fdf4;">

        <div>

            <strong style="display:block;color:#166534;font-size:15px;">
                <?= e((string)$latestFinalVoucher['voucher_code']); ?>
            </strong>

            <small style="display:block;margin-top:5px;color:#64748b;">
                Final travel voucher · Version <?= (int)$latestFinalVoucher['version_number']; ?>
            </small>

        </div>

        <a
            href="<?= e(BASE_URL . 'booking-voucher.php?voucher=' . (int)$latestFinalVoucher['id']); ?>"
            target="_blank"
            style="display:inline-flex;align-items:center;gap:8px;padding:11px 14px;border-radius:10px;background:#059669;color:#fff;text-decoration:none;font-weight:800;font-size:12px;"
        >
            <i class="fa-solid fa-print"></i>
            Open / Print Voucher
        </a>

    </div>

</div>

</section>

<?php endif; ?>


<?php if ($bookingServiceSnapshots): ?>

<section class="card">

<div class="card-header">

    <div class="card-title">

        <i class="fa-solid fa-list-check"></i>

        Your Booked Services

    </div>

</div>

<div class="card-body">

    <div style="display:grid;gap:10px;">

        <?php foreach ($bookingServiceSnapshots as $service): ?>

        <div style="padding:12px 14px;border:1px solid #e2e8f0;border-radius:12px;background:#fbfdff;">

            <strong style="display:block;color:#0f172a;">
                <?= e((string)$service['title']); ?>
            </strong>

            <small style="display:block;margin-top:4px;color:#64748b;">
                <?= e(ucwords(str_replace('_', ' ', (string)$service['service_type']))); ?>

                <?php if (!empty($service['destination_name'])): ?>
                    · <?= e((string)$service['destination_name']); ?>
                <?php endif; ?>

                <?php if (!empty($service['service_date_from'])): ?>
                    · <?= e(date('d M Y', strtotime((string)$service['service_date_from']))); ?>
                    <?php if (!empty($service['service_date_to']) && $service['service_date_to'] !== $service['service_date_from']): ?>
                        – <?= e(date('d M Y', strtotime((string)$service['service_date_to']))); ?>
                    <?php endif; ?>
                <?php endif; ?>
            </small>

            <?php if (!empty($service['specifications'])): ?>
                <div style="margin-top:7px;color:#475569;font-size:12px;line-height:1.6;">
                    <?= nl2br(e((string)$service['specifications'])); ?>
                </div>
            <?php endif; ?>

        </div>

        <?php endforeach; ?>

    </div>

</div>

</section>

<?php endif; ?>


<!-- =========================================================
     ITINERARY
========================================================= -->

<?php if (
    !empty(
        trim(
            (string)$booking['itinerary']
        )
    )
): ?>

<section class="card">

<div class="card-header">

    <div class="card-title">

        <i class="fa-solid fa-route"></i>

        Complete Itinerary

    </div>

</div>


<div class="card-body">

    <div class="itinerary">

        <?php

        /*
        | Allows basic HTML entered by admin.
        | If your admin stores plain text,
        | line breaks are preserved.
        */

        $itinerary =
            (string)$booking['itinerary'];

        if (
            $itinerary === strip_tags(
                $itinerary
            )
        ) {

            echo nl2br(
                e($itinerary)
            );

        } else {

            /*
            | Basic formatting tags only.
            */

            echo strip_tags(
                $itinerary,
                '<p><br><strong><b><em><i><ul><ol><li><h2><h3><h4>'
            );
        }

        ?>

    </div>

</div>

</section>

<?php endif; ?>


<!-- =========================================================
     INCLUSIONS / EXCLUSIONS
========================================================= -->

<?php if (
    !empty($inclusions)
    ||
    !empty($exclusions)
): ?>

<section class="card">

<div class="card-header">

    <div class="card-title">

        <i class="fa-solid fa-list-check"></i>

        What's Included

    </div>

</div>


<div class="card-body">

<div class="two-column">


<!-- INCLUSIONS -->

<div>

<h3 class="list-title">
    Package Includes
</h3>

<div class="feature-list">

<?php if ($inclusions): ?>

    <?php foreach (
        $inclusions
        as $item
    ): ?>

        <div class="feature include">

            <i class="fa-solid fa-check"></i>

            <span>
                <?= e($item); ?>
            </span>

        </div>

    <?php endforeach; ?>

<?php else: ?>

    <div class="feature">
        Inclusion details not provided.
    </div>

<?php endif; ?>

</div>

</div>


<!-- EXCLUSIONS -->

<div>

<h3 class="list-title">
    Package Excludes
</h3>

<div class="feature-list">

<?php if ($exclusions): ?>

    <?php foreach (
        $exclusions
        as $item
    ): ?>

        <div class="feature exclude">

            <i class="fa-solid fa-xmark"></i>

            <span>
                <?= e($item); ?>
            </span>

        </div>

    <?php endforeach; ?>

<?php else: ?>

    <div class="feature">
        Exclusion details not provided.
    </div>

<?php endif; ?>

</div>

</div>


</div>

</div>

</section>

<?php endif; ?>


<!-- =========================================================
     GALLERY
========================================================= -->

<?php if ($gallery): ?>

<section class="card">

<div class="card-header">

    <div class="card-title">

        <i class="fa-regular fa-images"></i>

        Trip Gallery

    </div>

</div>


<div class="card-body">

<div class="gallery">

<?php foreach ($gallery as $image): ?>

    <?php

    $galleryUrl =
        travscopeImageUrl(
            $image['image']
        );

    ?>

    <?php if (
        $galleryUrl !== ''
    ): ?>

        <div class="gallery-item">

            <img
                src="<?= e($galleryUrl); ?>"
                alt="<?= e(
                    $image['alt_text']
                    ?: $booking['package_title']
                ); ?>"
                loading="lazy"
            >

        </div>

    <?php endif; ?>

<?php endforeach; ?>

</div>

</div>

</section>

<?php endif; ?>


<!-- =========================================================
     TERMS
========================================================= -->

<?php if (
    !empty(
        trim(
            (string)$booking['terms']
        )
    )
): ?>

<section class="card">

<div class="card-header">

    <div class="card-title">

        <i class="fa-solid fa-file-contract"></i>

        Terms & Conditions

    </div>

</div>


<div class="card-body">

    <div class="terms"><?= e(
        $booking['terms']
    ); ?></div>

</div>

</section>

<?php endif; ?>


</div>


<!-- =========================================================
     RIGHT SUMMARY
========================================================= -->

<aside>

<section class="card summary-card">


<div class="card-header">

    <div class="card-title">

        <i class="fa-solid fa-receipt"></i>

        Booking Summary

    </div>

</div>


<div class="card-body">


<div class="booking-number">

    <span>
        Booking Reference
    </span>

    <strong>
        <?= e(
            $booking['booking_number']
        ); ?>
    </strong>

</div>


<div class="amounts">


<div class="amount-row">

    <span>
        Hotel Category
    </span>

    <strong>
        <?= e($hotelCategoryLabel); ?>
    </strong>

</div>


<?php if (!$isAcceptedCrmBooking): ?>

<div class="amount-row">

    <span>
        <?= $adultCount; ?>
        Adult<?= $adultCount === 1 ? '' : 's'; ?>
        ×
        <?= e($currencySymbol); ?>
        <?= number_format(
            $hotelPricePerAdult,
            2
        ); ?>
    </span>

    <strong>
        <?= e($currencySymbol); ?>
        <?= number_format(
            $adultPackageSubtotal,
            2
        ); ?>
    </strong>

</div>

<?php else: ?>

<div class="amount-row">

    <span>
        <?= !empty($hasRevisedCommercial)
            ? 'Current Booking Total (Revised)'
            : 'Accepted Quotation'; ?>
        <?php if (
            empty($hasRevisedCommercial)
            && !empty($bookingQuotationSnapshot['version_number'])
        ): ?>
            · Version <?= (int)$bookingQuotationSnapshot['version_number']; ?>
        <?php endif; ?>
    </span>

    <strong>
        <?= e($currencySymbol); ?>
        <?= number_format(
            $totalAmount,
            2
        ); ?>
    </strong>

</div>

<?php endif; ?>


<?php if ($discountAmount > 0): ?>

<div class="amount-row">

    <span>
        <?= $isAcceptedCrmBooking
            ? 'Quotation Discount'
            : 'Coupon Discount'; ?>

        <?php if (
            !$isAcceptedCrmBooking
            && !empty($booking['coupon_code'])
        ): ?>
            (<?= e($booking['coupon_code']); ?>)
        <?php endif; ?>
    </span>

    <strong style="color:#07966a;">
        -<?= e($currencySymbol); ?>
        <?= number_format(
            $discountAmount,
            2
        ); ?>
    </strong>

</div>

<?php endif; ?>


<div class="amount-row">

    <span>
        Final Booking Total
    </span>

    <strong>

        <?= e($currencySymbol); ?>

        <?= number_format(
            $totalAmount,
            2
        ); ?>

    </strong>

</div>


<div class="amount-row">

    <span>
        Paid Amount
    </span>

    <strong>

        <?= e($currencySymbol); ?>

        <?= number_format(
            $paidAmount,
            2
        ); ?>

    </strong>

</div>


<div class="amount-row">

    <span>
        Amount Remaining
    </span>

    <strong>

        <?= e($currencySymbol); ?>

        <?= number_format(
            $remainingAmount,
            2
        ); ?>

    </strong>

</div>


<div class="amount-row">

    <span>
        Payment Status
    </span>

    <strong>

        <?= e(
            strtoupper(
                $paymentStatus
            )
        ); ?>

    </strong>

</div>


<div class="amount-row total">

    <span>
        Total
    </span>

    <strong>

        <?= e($currencySymbol); ?>

        <?= number_format(
            $totalAmount,
            2
        ); ?>

    </strong>

</div>


</div>


<?php if (function_exists('tsBillReady') && tsBillReady($pdo)): ?>

<div class="payment-history" style="margin-bottom:16px;">

<h3>Billing & Payment Schedule</h3>

<div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-bottom:10px;">
    <div style="padding:10px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc;"><small style="display:block;color:#64748b;font-size:8px;font-weight:900;text-transform:uppercase;">Booking Total</small><strong style="display:block;margin-top:4px;"><?= e($currencySymbol); ?><?= number_format($totalAmount,2); ?></strong></div>
    <div style="padding:10px;border:1px solid #a7f3d0;border-radius:10px;background:#ecfdf5;"><small style="display:block;color:#047857;font-size:8px;font-weight:900;text-transform:uppercase;">Paid</small><strong style="display:block;margin-top:4px;color:#047857;"><?= e($currencySymbol); ?><?= number_format($paidAmount,2); ?></strong></div>
    <div style="padding:10px;border:1px solid #fed7aa;border-radius:10px;background:#fff7ed;"><small style="display:block;color:#c2410c;font-size:8px;font-weight:900;text-transform:uppercase;">Balance</small><strong style="display:block;margin-top:4px;color:#c2410c;"><?= e($currencySymbol); ?><?= number_format($remainingAmount,2); ?></strong></div>
</div>

<?php if ($customerBillingInstallments): ?>
    <div style="display:grid;gap:7px;">
        <?php foreach ($customerBillingInstallments as $installment): ?>
            <?php
            $installmentDue = max(0,(float)$installment['amount']-(float)$installment['paid_amount']);
            $canPayInstallment = $installmentDue > .01
                && !in_array((string)$installment['status'],['paid','cancelled'],true)
                && $bookingStatus !== 'cancelled'
                && $latestPaymentStatus !== 'pending';
            ?>
            <div style="display:grid;grid-template-columns:minmax(0,1fr) auto;gap:9px;align-items:center;padding:10px;border:1px solid #e2e8f0;border-radius:10px;background:#fbfdff;">
                <div>
                    <strong style="font-size:11px;"><?= (int)$installment['installment_number']; ?>. <?= e((string)$installment['title']); ?></strong>
                    <small style="display:block;margin-top:4px;color:#64748b;font-size:9px;">Amount <?= e($currencySymbol); ?><?= number_format((float)$installment['amount'],2); ?> · Paid <?= e($currencySymbol); ?><?= number_format((float)$installment['paid_amount'],2); ?> · Due <?= e($currencySymbol); ?><?= number_format($installmentDue,2); ?><?php if (!empty($installment['due_date'])): ?> · Due <?= e(date('d M Y',strtotime((string)$installment['due_date']))); ?><?php endif; ?></small>
                </div>
                <div style="display:flex;gap:6px;align-items:center;">
                    <span style="display:inline-flex;padding:4px 7px;border-radius:999px;background:<?= $installment['status']==='paid'?'#dcfce7':'#fff7ed'; ?>;color:<?= $installment['status']==='paid'?'#166534':'#c2410c'; ?>;font-size:8px;font-weight:900;"><?= e(strtoupper(str_replace('_',' ',(string)$installment['status']))); ?></span>
                    <?php if ($canPayInstallment): ?>
                        <a href="<?= e(BASE_URL.'payment.php?booking='.$bookingId.'&installment='.(int)$installment['id']); ?>" class="btn btn-primary" style="padding:7px 9px;font-size:9px;">Pay</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php elseif ($remainingAmount > .01): ?>
    <div style="padding:10px;border:1px solid #dbeafe;border-radius:10px;background:#eff6ff;color:#1d4ed8;font-size:10px;">No installment schedule is active. You can still pay the full outstanding Booking balance.</div>
<?php endif; ?>

<div style="display:flex;gap:7px;flex-wrap:wrap;margin-top:10px;">
    <?php if ($customerBillingInvoice): ?>
        <a href="<?= e(BASE_URL.'booking-invoice.php?invoice='.(int)$customerBillingInvoice['id']); ?>" target="_blank" class="btn btn-secondary"><i class="fa-solid fa-file-invoice"></i> Final Invoice</a>
    <?php endif; ?>
    <a href="<?= e(BASE_URL.'booking-statement.php?booking='.$bookingId); ?>" target="_blank" class="btn btn-secondary"><i class="fa-solid fa-file-lines"></i> Statement</a>
    <?php foreach (array_slice($customerBillingReceipts,0,3) as $receipt): ?>
        <a href="<?= e(BASE_URL.'payment-receipt.php?receipt='.(int)$receipt['id']); ?>" target="_blank" class="btn btn-secondary"><i class="fa-solid fa-receipt"></i> <?= e((string)$receipt['receipt_code']); ?></a>
    <?php endforeach; ?>
</div>

<?php if ($customerBillingPendingRefund > .01): ?>
    <div style="margin-top:10px;padding:10px;border:1px solid #bfdbfe;border-radius:10px;background:#eff6ff;color:#1e40af;font-size:10px;"><strong>Refund Pending:</strong> <?= e($currencySymbol); ?><?= number_format($customerBillingPendingRefund,2); ?></div>
<?php endif; ?>

</div>

<?php endif; ?>


<!-- =========================================================
     PAYMENT HISTORY
========================================================= -->

<?php if ($payments): ?>

<div class="payment-history">

<h3>
    Payment History
</h3>


<?php foreach (
    $payments
    as $payment
): ?>


<div class="payment-item">


<div class="payment-item-top">

    <strong>

        <?= e($currencySymbol); ?>

        <?= number_format(
            (float)$payment['amount'],
            2
        ); ?>

    </strong>


    <span
        class="status <?= e(
            statusClass(
                $payment['status']
            )
        ); ?>"
    >

        <?= e(
            ucfirst(
                $payment['status']
            )
        ); ?>

    </span>

</div>


<small>

    <?= e(
        date(
            'd M Y, h:i A',
            strtotime(
                $payment['created_at']
            )
        )
    ); ?>

</small>


<?php if (
    !empty(
        $payment['transaction_id']
    )
): ?>

<div class="utr">

    UTR:
    <?= e(
        $payment['transaction_id']
    ); ?>

</div>

<?php endif; ?>


<?php if (
    !empty(
        $payment['payment_method']
    )
): ?>

<div
    style="
        margin-top:5px;
        color:#7c8999;
        font-size:8px;
    "
>

    <?= e(
        $payment['payment_method']
    ); ?>

</div>

<?php endif; ?>


</div>


<?php endforeach; ?>


</div>

<?php endif; ?>


<!-- =========================================================
     ACTIONS
========================================================= -->

<div class="actions">


<?php if (
    $latestPaymentStatus === 'pending'
): ?>

<a
    href="<?= e(
        BASE_URL
        . 'payment-pending.php?booking='
        . $bookingId
    ); ?>"
    class="btn btn-warning"
>

    <i class="fa-regular fa-clock"></i>

    Check Payment Verification

</a>


<?php elseif (
    $paymentStatus === 'paid'
): ?>


<a
    href="<?= e(
        BASE_URL
        . 'booking-success.php?booking='
        . $bookingId
    ); ?>"
    class="btn btn-success"
>

    <i class="fa-solid fa-circle-check"></i>

    View Confirmation

</a>


<?php elseif (
    $bookingStatus !== 'cancelled'
): ?>


<a
    href="<?= e(
        BASE_URL
        . 'payment.php?booking='
        . $bookingId
    ); ?>"
    class="btn btn-primary"
>

    <i class="fa-solid fa-credit-card"></i>

    Complete Payment

</a>


<?php endif; ?>


<a
    href="<?= e(
        BASE_URL
        . 'my-bookings.php'
    ); ?>"
    class="btn btn-secondary"
>

    <i class="fa-solid fa-arrow-left"></i>

    Back to My Bookings

</a>


<?php if (
    !empty(
        $booking['package_slug']
    )
): ?>

<a
    href="<?= e(
        BASE_URL
        . 'package-details.php?slug='
        . urlencode(
            $booking['package_slug']
        )
    ); ?>"
    class="btn btn-secondary"
>

    <i class="fa-solid fa-suitcase"></i>

    View Package

</a>

<?php endif; ?>


</div>


</div>

</section>

</aside>


</div>

</main>


<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>

</html>