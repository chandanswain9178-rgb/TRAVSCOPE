<?php

require_once __DIR__ . '/config.php';

/*
|--------------------------------------------------------------------------
| ADMIN AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_id'])) {
    redirect(BASE_URL . 'admin-login.php');
}

$adminId = (int) $_SESSION['admin_id'];

$stmt = $pdo->prepare("
    SELECT id, name, email, role, status
    FROM admins
    WHERE id = ?
    LIMIT 1
");

$stmt->execute([$adminId]);

$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin || $admin['status'] !== 'active') {

    unset($_SESSION['admin_id']);

    redirect(BASE_URL . 'admin-login.php');
}

/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_reviews_csrf'])) {

    $_SESSION['admin_reviews_csrf'] =
        bin2hex(random_bytes(32));
}

$csrfToken =
    $_SESSION['admin_reviews_csrf'];

/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function reviewDate(
    $date,
    $format = 'd M Y, h:i A'
) {

    if (empty($date)) {
        return 'Not available';
    }

    $time = strtotime($date);

    if (!$time) {
        return 'Not available';
    }

    return date($format, $time);
}


function reviewStatusClass($status)
{
    switch ($status) {

        case 'approved':
            return 'success';

        case 'rejected':
            return 'danger';

        default:
            return 'warning';
    }
}


function reviewStars($rating)
{
    $rating = max(
        0,
        min(
            5,
            (int) $rating
        )
    );

    $html = '';

    for ($i = 1; $i <= 5; $i++) {

        if ($i <= $rating) {

            $html .=
                '<i class="fa-solid fa-star"></i>';

        } else {

            $html .=
                '<i class="fa-regular fa-star"></i>';
        }
    }

    return $html;
}


function reviewPageUrl($page)
{
    $query = $_GET;

    $query['page'] = $page;

    return BASE_URL .
        'admin-reviews.php?' .
        http_build_query($query);
}

/*
|--------------------------------------------------------------------------
| FLASH
|--------------------------------------------------------------------------
*/

$success = '';
$error = '';

if (!empty($_SESSION['admin_reviews_success'])) {

    $success =
        $_SESSION['admin_reviews_success'];

    unset(
        $_SESSION['admin_reviews_success']
    );
}

if (!empty($_SESSION['admin_reviews_error'])) {

    $error =
        $_SESSION['admin_reviews_error'];

    unset(
        $_SESSION['admin_reviews_error']
    );
}

/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $postedToken =
        (string) ($_POST['csrf_token'] ?? '');

    if (
        $postedToken === '' ||
        !hash_equals(
            $_SESSION['admin_reviews_csrf'] ?? '',
            $postedToken
        )
    ) {

        $error =
            'Security verification failed. Please refresh and try again.';

    } else {

        $action =
            trim(
                (string) ($_POST['action'] ?? '')
            );

        $reviewId =
            (int) ($_POST['review_id'] ?? 0);

        /*
        |--------------------------------------------------------------------------
        | CHANGE REVIEW STATUS
        |--------------------------------------------------------------------------
        */

        if ($action === 'change_status') {

            $newStatus =
                strtolower(
                    trim(
                        (string) (
                            $_POST['new_status']
                            ?? ''
                        )
                    )
                );

            $allowedStatuses = [
                'pending',
                'approved',
                'rejected'
            ];

            if ($reviewId <= 0) {

                $error =
                    'Invalid review.';

            } elseif (
                !in_array(
                    $newStatus,
                    $allowedStatuses,
                    true
                )
            ) {

                $error =
                    'Invalid review status.';

            } else {

                try {

                    $stmt = $pdo->prepare("
                        SELECT id
                        FROM reviews
                        WHERE id = ?
                        LIMIT 1
                    ");

                    $stmt->execute([$reviewId]);

                    if (!$stmt->fetchColumn()) {

                        throw new RuntimeException(
                            'Review not found.'
                        );
                    }

                    $stmt = $pdo->prepare("
                        UPDATE reviews
                        SET status = ?
                        WHERE id = ?
                        LIMIT 1
                    ");

                    $stmt->execute([
                        $newStatus,
                        $reviewId
                    ]);

                    $_SESSION['admin_reviews_success'] =
                        'Review marked as ' .
                        ucfirst($newStatus) .
                        '.';

                    redirect(
                        BASE_URL .
                        'admin-reviews.php'
                    );

                } catch (RuntimeException $e) {

                    $error =
                        $e->getMessage();

                } catch (Throwable $e) {

                    error_log(
                        'Review status error: ' .
                        $e->getMessage()
                    );

                    $error =
                        'Unable to update review.';
                }
            }
        }

        /*
        |--------------------------------------------------------------------------
        | FEATURE / UNFEATURE
        |--------------------------------------------------------------------------
        */

        elseif ($action === 'toggle_featured') {

            if ($reviewId <= 0) {

                $error =
                    'Invalid review.';

            } else {

                try {

                    $stmt = $pdo->prepare("
                        UPDATE reviews

                        SET featured =
                            CASE
                                WHEN featured = 1
                                THEN 0
                                ELSE 1
                            END

                        WHERE id = ?

                        LIMIT 1
                    ");

                    $stmt->execute([$reviewId]);

                    $_SESSION['admin_reviews_success'] =
                        'Featured status updated successfully.';

                    redirect(
                        BASE_URL .
                        'admin-reviews.php'
                    );

                } catch (Throwable $e) {

                    error_log(
                        'Review featured error: ' .
                        $e->getMessage()
                    );

                    $error =
                        'Unable to update featured status.';
                }
            }
        }

        /*
        |--------------------------------------------------------------------------
        | ADMIN REPLY
        |--------------------------------------------------------------------------
        */

        elseif ($action === 'admin_reply') {

            $reply =
                trim(
                    (string) (
                        $_POST['admin_reply']
                        ?? ''
                    )
                );

            if ($reviewId <= 0) {

                $error =
                    'Invalid review.';

            } elseif ($reply === '') {

                $error =
                    'Please enter an admin reply.';

            } elseif (mb_strlen($reply) > 3000) {

                $error =
                    'Admin reply is too long.';

            } else {

                try {

                    $stmt = $pdo->prepare("
                        UPDATE reviews

                        SET
                            admin_reply = ?,
                            admin_reply_at = NOW()

                        WHERE id = ?

                        LIMIT 1
                    ");

                    $stmt->execute([
                        $reply,
                        $reviewId
                    ]);

                    $_SESSION['admin_reviews_success'] =
                        'Reply saved successfully.';

                    redirect(
                        BASE_URL .
                        'admin-reviews.php'
                    );

                } catch (Throwable $e) {

                    error_log(
                        'Review reply error: ' .
                        $e->getMessage()
                    );

                    $error =
                        'Unable to save admin reply.';
                }
            }
        }

        /*
        |--------------------------------------------------------------------------
        | REMOVE ADMIN REPLY
        |--------------------------------------------------------------------------
        */

        elseif ($action === 'remove_reply') {

            if ($reviewId <= 0) {

                $error =
                    'Invalid review.';

            } else {

                try {

                    $stmt = $pdo->prepare("
                        UPDATE reviews

                        SET
                            admin_reply = NULL,
                            admin_reply_at = NULL

                        WHERE id = ?

                        LIMIT 1
                    ");

                    $stmt->execute([$reviewId]);

                    $_SESSION['admin_reviews_success'] =
                        'Admin reply removed.';

                    redirect(
                        BASE_URL .
                        'admin-reviews.php'
                    );

                } catch (Throwable $e) {

                    error_log(
                        'Remove reply error: ' .
                        $e->getMessage()
                    );

                    $error =
                        'Unable to remove reply.';
                }
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

$search =
    trim(
        (string) ($_GET['q'] ?? '')
    );

$status =
    strtolower(
        trim(
            (string) ($_GET['status'] ?? '')
        )
    );

$rating =
    (int) ($_GET['rating'] ?? 0);

$featured =
    trim(
        (string) ($_GET['featured'] ?? '')
    );

$allowedStatuses = [
    'pending',
    'approved',
    'rejected'
];

if (
    $status !== '' &&
    !in_array(
        $status,
        $allowedStatuses,
        true
    )
) {
    $status = '';
}

if ($rating < 1 || $rating > 5) {
    $rating = 0;
}

if (
    !in_array(
        $featured,
        ['', '1', '0'],
        true
    )
) {
    $featured = '';
}

/*
|--------------------------------------------------------------------------
| STATISTICS
|--------------------------------------------------------------------------
*/

$stats = [
    'total' => 0,
    'pending' => 0,
    'approved' => 0,
    'rejected' => 0,
    'featured' => 0,
    'average_rating' => 0
];

try {

    $stmt = $pdo->query("
        SELECT

            COUNT(*) AS total,

            SUM(
                status = 'pending'
            ) AS pending,

            SUM(
                status = 'approved'
            ) AS approved,

            SUM(
                status = 'rejected'
            ) AS rejected,

            SUM(
                featured = 1
            ) AS featured,

            COALESCE(
                AVG(rating),
                0
            ) AS average_rating

        FROM reviews
    ");

    $row =
        $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {

        $stats['total'] =
            (int) ($row['total'] ?? 0);

        $stats['pending'] =
            (int) ($row['pending'] ?? 0);

        $stats['approved'] =
            (int) ($row['approved'] ?? 0);

        $stats['rejected'] =
            (int) ($row['rejected'] ?? 0);

        $stats['featured'] =
            (int) ($row['featured'] ?? 0);

        $stats['average_rating'] =
            round(
                (float) (
                    $row['average_rating']
                    ?? 0
                ),
                1
            );
    }

} catch (Throwable $e) {

    error_log(
        'Review statistics error: ' .
        $e->getMessage()
    );
}

/*
|--------------------------------------------------------------------------
| WHERE
|--------------------------------------------------------------------------
*/

$where = [];
$params = [];

if ($search !== '') {

    $where[] = "
        (
            u.full_name LIKE ?
            OR u.email LIKE ?
            OR p.title LIKE ?
            OR r.title LIKE ?
            OR r.review_text LIKE ?
        )
    ";

    $term =
        '%' . $search . '%';

    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

if ($status !== '') {

    $where[] =
        'r.status = ?';

    $params[] =
        $status;
}

if ($rating > 0) {

    $where[] =
        'r.rating = ?';

    $params[] =
        $rating;
}

if ($featured !== '') {

    $where[] =
        'r.featured = ?';

    $params[] =
        (int) $featured;
}

$whereSql = '';

if ($where) {

    $whereSql =
        ' WHERE ' .
        implode(
            ' AND ',
            $where
        );
}

/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/

$perPage = 10;

$page =
    max(
        1,
        (int) ($_GET['page'] ?? 1)
    );

$totalRows = 0;

try {

    $stmt = $pdo->prepare("
        SELECT COUNT(*)

        FROM reviews r

        LEFT JOIN users u
            ON u.id = r.user_id

        LEFT JOIN packages p
            ON p.id = r.package_id

        {$whereSql}
    ");

    $stmt->execute($params);

    $totalRows =
        (int) $stmt->fetchColumn();

} catch (Throwable $e) {

    error_log(
        'Review count error: ' .
        $e->getMessage()
    );
}

$totalPages =
    max(
        1,
        (int) ceil(
            $totalRows /
            $perPage
        )
    );

if ($page > $totalPages) {
    $page = $totalPages;
}

$offset =
    ($page - 1) *
    $perPage;

/*
|--------------------------------------------------------------------------
| FETCH REVIEWS
|--------------------------------------------------------------------------
*/

$reviews = [];

try {

    $sql = "
        SELECT

            r.id,
            r.user_id,
            r.package_id,
            r.booking_id,
            r.rating,
            r.title,
            r.review_text,
            r.status,
            r.admin_reply,
            r.admin_reply_at,
            r.featured,
            r.created_at,
            r.updated_at,

            u.full_name,
            u.email,
            u.mobile,
            u.profile_image,

            p.title AS package_title,
            p.slug AS package_slug,
            p.main_image,

            b.booking_number,
            b.booking_status,
            b.travel_date

        FROM reviews r

        LEFT JOIN users u
            ON u.id = r.user_id

        LEFT JOIN packages p
            ON p.id = r.package_id

        LEFT JOIN bookings b
            ON b.id = r.booking_id

        {$whereSql}

        ORDER BY

            CASE
                WHEN r.status = 'pending'
                THEN 0
                ELSE 1
            END,

            r.created_at DESC,
            r.id DESC

        LIMIT {$perPage}
        OFFSET {$offset}
    ";

    $stmt =
        $pdo->prepare($sql);

    $stmt->execute($params);

    $reviews =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );

} catch (Throwable $e) {

    error_log(
        'Review fetch error: ' .
        $e->getMessage()
    );

    $error =
        'Unable to load reviews.';
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
Reviews | TRAVSCOPE Admin
</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>

:root{

    --navy:#07192d;
    --navy2:#0c2947;

    --blue:#0b74ff;
    --cyan:#00b8ff;

    --green:#07885f;
    --red:#d94355;
    --orange:#df8617;

    --gold:#f3a712;

    --bg:#f4f7fb;
    --white:#ffffff;

    --text:#172235;
    --muted:#7e8a9b;

    --border:#e1e8ef;

    --shadow:
        0 14px 40px
        rgba(7,25,45,.07);
}

*{
    box-sizing:border-box;
    margin:0;
    padding:0;
}

body{

    background:var(--bg);

    color:var(--text);

    font-family:
        'DM Sans',
        sans-serif;
}

a{
    color:inherit;
    text-decoration:none;
}

button,
input,
select,
textarea{
    font:inherit;
}

/*
|--------------------------------------------------------------------------
| HEADER
|--------------------------------------------------------------------------
*/

.header{

    height:70px;

    padding:0 28px;

    position:sticky;

    top:0;

    z-index:1000;

    display:flex;

    align-items:center;

    justify-content:
        space-between;

    background:white;

    border-bottom:
        1px solid
        var(--border);
}

.logo{

    display:flex;

    align-items:center;

    gap:9px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:18px;

    font-weight:800;
}

.logo-icon{

    width:38px;
    height:38px;

    border-radius:11px;

    display:grid;

    place-items:center;

    color:white;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--cyan)
        );
}

.logo span{
    color:var(--blue);
}

.admin{

    display:flex;

    align-items:center;

    gap:9px;
}

.admin-avatar{

    width:38px;
    height:38px;

    border-radius:10px;

    display:grid;

    place-items:center;

    background:#edf5ff;

    color:var(--blue);

    font-weight:800;
}

.admin strong{

    display:block;

    font-size:10px;
}

.admin small{

    display:block;

    margin-top:2px;

    color:#929dab;

    font-size:8px;
}

/*
|--------------------------------------------------------------------------
| LAYOUT
|--------------------------------------------------------------------------
*/

.layout{

    min-height:
        calc(100vh - 70px);

    display:grid;

    grid-template-columns:
        230px
        minmax(0,1fr);
}

/*
|--------------------------------------------------------------------------
| SIDEBAR
|--------------------------------------------------------------------------
*/

.sidebar{

    padding:
        20px 13px;

    background:
        var(--navy);

    color:white;
}

.menu-title{

    padding:
        0 11px;

    margin:
        13px 0 7px;

    color:#71869c;

    font-size:7px;

    font-weight:800;

    text-transform:
        uppercase;

    letter-spacing:1px;
}

.sidebar a{

    min-height:43px;

    margin-bottom:4px;

    padding:
        0 12px;

    border-radius:9px;

    display:flex;

    align-items:center;

    gap:10px;

    color:#b6c5d4;

    font-size:9px;

    font-weight:700;

    transition:.2s;
}

.sidebar a:hover,
.sidebar a.active{

    color:white;

    background:
        rgba(
            255,
            255,
            255,
            .1
        );
}

.sidebar a.active{

    background:
        linear-gradient(
            135deg,
            var(--blue),
            #0866dd
        );
}

.sidebar i{

    width:18px;

    text-align:center;
}

/*
|--------------------------------------------------------------------------
| MAIN
|--------------------------------------------------------------------------
*/

.main{

    min-width:0;

    padding:27px;
}

.page-head{

    margin-bottom:20px;

    display:flex;

    align-items:flex-end;

    justify-content:
        space-between;

    gap:15px;
}

.page-head h1{

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:25px;
}

.page-head p{

    margin-top:5px;

    color:var(--muted);

    font-size:9px;
}

.refresh{

    min-height:40px;

    padding:
        0 13px;

    border:
        1px solid
        var(--border);

    border-radius:8px;

    display:inline-flex;

    align-items:center;

    gap:6px;

    background:white;

    color:#617084;

    font-size:8px;

    font-weight:800;
}

/*
|--------------------------------------------------------------------------
| ALERT
|--------------------------------------------------------------------------
*/

.alert{

    margin-bottom:17px;

    padding:
        13px 15px;

    border-radius:10px;

    display:flex;

    align-items:center;

    gap:8px;

    font-size:9px;
}

.alert-success{

    border:
        1px solid
        #bce7d5;

    background:#eaf9f3;

    color:#08734f;
}

.alert-error{

    border:
        1px solid
        #f0c5cc;

    background:#fff0f2;

    color:#b43748;
}

/*
|--------------------------------------------------------------------------
| STATS
|--------------------------------------------------------------------------
*/

.stats{

    margin-bottom:20px;

    display:grid;

    grid-template-columns:
        repeat(6,1fr);

    gap:11px;
}

.stat{

    padding:15px;

    border:
        1px solid
        var(--border);

    border-radius:13px;

    background:white;

    box-shadow:
        var(--shadow);
}

.stat-icon{

    width:35px;
    height:35px;

    border-radius:10px;

    display:grid;

    place-items:center;

    background:#edf5ff;

    color:var(--blue);
}

.stat strong{

    display:block;

    margin-top:11px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:19px;
}

.stat span{

    display:block;

    margin-top:2px;

    color:#929daa;

    font-size:7px;
}

.rating-stat .stat-icon{

    background:#fff7e4;

    color:var(--gold);
}

/*
|--------------------------------------------------------------------------
| CARD
|--------------------------------------------------------------------------
*/

.card{

    margin-bottom:18px;

    border:
        1px solid
        var(--border);

    border-radius:15px;

    overflow:hidden;

    background:white;

    box-shadow:
        var(--shadow);
}

.card-head{

    min-height:61px;

    padding:
        0 18px;

    border-bottom:
        1px solid
        var(--border);

    display:flex;

    align-items:center;

    justify-content:
        space-between;

    gap:15px;
}

.card-head h2{

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:13px;
}

.card-head p{

    margin-top:3px;

    color:#929daa;

    font-size:8px;
}

.card-body{

    padding:18px;
}

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

.filters{

    display:grid;

    grid-template-columns:
        2fr 1fr 1fr 1fr auto;

    gap:8px;
}

.control{

    width:100%;

    min-height:41px;

    padding:
        0 11px;

    border:
        1px solid
        #dfe6ed;

    border-radius:8px;

    outline:none;

    background:white;

    color:#39475a;

    font-size:8px;
}

.control:focus{

    border-color:#8abaff;

    box-shadow:
        0 0 0 3px
        rgba(
            11,
            116,
            255,
            .06
        );
}

.filter-btn{

    min-height:41px;

    padding:
        0 16px;

    border:0;

    border-radius:8px;

    cursor:pointer;

    background:var(--navy);

    color:white;

    font-size:8px;

    font-weight:800;
}

.clear{

    margin-top:10px;

    display:inline-flex;

    align-items:center;

    gap:5px;

    color:var(--blue);

    font-size:8px;

    font-weight:700;
}

/*
|--------------------------------------------------------------------------
| REVIEW
|--------------------------------------------------------------------------
*/

.review{

    margin-bottom:14px;

    border:
        1px solid
        #e3e9ef;

    border-radius:14px;

    overflow:hidden;

    background:white;
}

.review:last-child{
    margin-bottom:0;
}

.review-top{

    padding:14px 16px;

    border-bottom:
        1px solid
        #edf0f3;

    display:flex;

    justify-content:
        space-between;

    gap:15px;

    background:#fbfcfe;
}

.customer{

    min-width:0;

    display:flex;

    align-items:center;

    gap:10px;
}

.avatar{

    width:43px;
    height:43px;

    flex:none;

    border-radius:12px;

    display:grid;

    place-items:center;

    background:
        linear-gradient(
            135deg,
            #e8f3ff,
            #f4f9ff
        );

    color:var(--blue);

    font-family:
        'Manrope',
        sans-serif;

    font-size:15px;

    font-weight:800;
}

.customer h3{

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:10px;
}

.customer p{

    margin-top:3px;

    color:#8c98a7;

    font-size:7px;
}

.review-status{

    display:flex;

    align-items:flex-start;

    gap:5px;

    flex-wrap:wrap;

    justify-content:flex-end;
}

/*
|--------------------------------------------------------------------------
| BADGES
|--------------------------------------------------------------------------
*/

.badge{

    padding:
        5px 8px;

    border-radius:20px;

    display:inline-flex;

    align-items:center;

    gap:4px;

    font-size:7px;

    font-weight:800;

    text-transform:capitalize;
}

.badge-success{

    background:#e8f8f1;

    color:var(--green);
}

.badge-warning{

    background:#fff6e7;

    color:#bd7114;
}

.badge-danger{

    background:#fff0f2;

    color:var(--red);
}

.badge-blue{

    background:#edf5ff;

    color:var(--blue);
}

/*
|--------------------------------------------------------------------------
| REVIEW BODY
|--------------------------------------------------------------------------
*/

.review-body{

    padding:16px;
}

.review-meta{

    margin-bottom:11px;

    display:flex;

    align-items:center;

    justify-content:
        space-between;

    gap:10px;

    flex-wrap:wrap;
}

.package-name{

    color:#59687b;

    font-size:8px;
}

.package-name strong{

    color:var(--navy);
}

.stars{

    color:var(--gold);

    font-size:11px;

    letter-spacing:1px;
}

.rating-number{

    margin-left:5px;

    color:#7d8998;

    font-size:7px;

    font-weight:700;
}

.review-title{

    margin-bottom:6px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:11px;
}

.review-text{

    color:#657386;

    font-size:8px;

    line-height:1.75;

    white-space:pre-line;
}

.booking-info{

    margin-top:11px;

    padding:9px 10px;

    border-radius:8px;

    display:flex;

    align-items:center;

    gap:8px;

    flex-wrap:wrap;

    background:#f6f8fb;

    color:#7a8797;

    font-size:7px;
}

.booking-info strong{

    color:#4f5e71;
}

/*
|--------------------------------------------------------------------------
| ADMIN REPLY
|--------------------------------------------------------------------------
*/

.admin-reply{

    margin-top:13px;

    padding:12px;

    border-left:
        3px solid
        var(--blue);

    border-radius:8px;

    background:#f1f7ff;
}

.admin-reply-title{

    display:flex;

    justify-content:
        space-between;

    gap:10px;

    color:var(--blue);

    font-size:7px;

    font-weight:800;
}

.admin-reply p{

    margin-top:6px;

    color:#596b80;

    font-size:8px;

    line-height:1.7;

    white-space:pre-line;
}

/*
|--------------------------------------------------------------------------
| ACTIONS
|--------------------------------------------------------------------------
*/

.actions{

    margin-top:14px;

    padding-top:13px;

    border-top:
        1px solid
        #edf0f3;

    display:flex;

    align-items:center;

    gap:6px;

    flex-wrap:wrap;
}

.btn{

    min-height:34px;

    padding:
        0 10px;

    border:0;

    border-radius:7px;

    cursor:pointer;

    display:inline-flex;

    align-items:center;

    justify-content:center;

    gap:5px;

    font-size:7px;

    font-weight:800;
}

.btn-approve{

    background:#e8f8f1;

    color:var(--green);
}

.btn-reject{

    background:#fff0f2;

    color:var(--red);
}

.btn-pending{

    background:#fff6e7;

    color:#bd7114;
}

.btn-feature{

    background:#fff7e4;

    color:#c77c00;
}

.btn-blue{

    background:#edf5ff;

    color:var(--blue);
}

.btn-light{

    background:#f1f3f6;

    color:#637185;
}

/*
|--------------------------------------------------------------------------
| REPLY FORM
|--------------------------------------------------------------------------
*/

.reply-box{

    margin-top:12px;

    padding:12px;

    border-radius:9px;

    display:none;

    background:#f7f9fc;
}

.reply-box.open{
    display:block;
}

.reply-box textarea{

    width:100%;

    min-height:90px;

    padding:10px;

    resize:vertical;

    border:
        1px solid
        #dce4ec;

    border-radius:8px;

    outline:none;

    color:#435268;

    font-size:8px;

    line-height:1.6;
}

.reply-box textarea:focus{

    border-color:#8abaff;
}

.reply-actions{

    margin-top:8px;

    display:flex;

    gap:6px;

    justify-content:flex-end;
}

/*
|--------------------------------------------------------------------------
| EMPTY
|--------------------------------------------------------------------------
*/

.empty{

    padding:55px 20px;

    text-align:center;
}

.empty-icon{

    width:65px;
    height:65px;

    margin:
        0 auto 13px;

    border-radius:18px;

    display:grid;

    place-items:center;

    background:#fff7e4;

    color:var(--gold);

    font-size:23px;
}

.empty h3{

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:13px;
}

.empty p{

    margin-top:6px;

    color:#8d99a8;

    font-size:8px;
}

/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/

.pagination{

    margin-top:20px;

    display:flex;

    justify-content:center;

    gap:5px;

    flex-wrap:wrap;
}

.page-btn{

    min-width:35px;
    height:35px;

    padding:
        0 9px;

    border:
        1px solid
        var(--border);

    border-radius:7px;

    display:grid;

    place-items:center;

    background:white;

    color:#617084;

    font-size:8px;

    font-weight:800;
}

.page-btn.active{

    border-color:
        var(--blue);

    background:
        var(--blue);

    color:white;
}

/*
|--------------------------------------------------------------------------
| RESPONSIVE
|--------------------------------------------------------------------------
*/

@media(max-width:1200px){

    .stats{

        grid-template-columns:
            repeat(3,1fr);
    }
}

@media(max-width:950px){

    .layout{
        grid-template-columns:1fr;
    }

    .sidebar{
        display:none;
    }

    .main{
        padding:18px;
    }

    .filters{
        grid-template-columns:
            repeat(2,1fr);
    }
}

@media(max-width:650px){

    .header{
        padding:0 13px;
    }

    .admin > div:last-child{
        display:none;
    }

    .main{
        padding:13px;
    }

    .page-head{

        align-items:flex-start;

        flex-direction:column;
    }

    .stats{

        grid-template-columns:
            repeat(2,1fr);
    }

    .filters{
        grid-template-columns:1fr;
    }

    .review-top{

        flex-direction:column;
    }

    .review-status{

        justify-content:flex-start;
    }

    .review-meta{

        align-items:flex-start;

        flex-direction:column;
    }
}

</style>


<style>
/* =========================================================
   ADMIN REVIEWS — READABILITY + RESPONSIVE UPGRADE
   Existing PHP, review actions and functionality unchanged.
========================================================= */
html{font-size:16px}
body{font-size:15px;line-height:1.5}

.logo{font-size:20px}
.admin strong{font-size:13px}
.admin small{font-size:11px}

.menu-title{font-size:11px}
.sidebar a{
    min-height:46px;
    padding:0 14px;
    gap:11px;
    font-size:14px;
    line-height:1.25;
}
.sidebar i{font-size:15px;width:20px}

.page-head h1{font-size:27px}
.page-head p{font-size:13px}
.refresh{
    min-height:42px;
    padding:0 15px;
    font-size:13px;
}

.alert{font-size:13px}

.stat strong{font-size:23px}
.stat span{font-size:11px}
.stat-icon{font-size:16px}

.card-head h2{font-size:17px}
.card-head p{font-size:12px}

.control{
    min-height:43px;
    padding:0 12px;
    font-size:13px;
}
.filter-btn{
    min-height:43px;
    padding:0 17px;
    font-size:13px;
}
.clear{font-size:12px}

.customer h3{font-size:14px}
.customer p{font-size:11px}
.badge{font-size:11px;padding:6px 10px}

.package-name{font-size:12px}
.stars{font-size:14px}
.rating-number{font-size:11px}
.review-title{font-size:15px}
.review-text{font-size:13px;line-height:1.7}
.booking-info{font-size:11px}

.admin-reply-title{font-size:11px}
.admin-reply p{font-size:13px}

.btn{
    min-height:40px;
    padding:0 13px;
    gap:6px;
    font-size:12px;
}
.reply-box textarea{
    min-height:100px;
    padding:11px;
    font-size:13px;
}
.empty h3{font-size:16px}
.empty p{font-size:12px}
.page-btn{
    min-width:40px;
    height:40px;
    font-size:12px;
}

@media(max-width:1200px){
    .stats{grid-template-columns:repeat(3,1fr)}
}

@media(max-width:950px){
    .layout{grid-template-columns:84px minmax(0,1fr)}
    .sidebar{display:block;padding:16px 8px}
    .menu-title{display:none}
    .sidebar a{
        min-height:48px;
        padding:0;
        justify-content:center;
        font-size:0;
    }
    .sidebar a i{
        width:auto;
        font-size:18px;
    }
    .main{padding:18px}
    .filters{grid-template-columns:repeat(2,1fr)}
}

@media(max-width:650px){
    .header{padding:0 13px}
    .admin > div:last-child{display:none}
    .layout{display:block}
    .sidebar{
        display:block;
        padding:10px;
        overflow:visible;
    }
    .sidebar a{
        display:inline-flex;
        width:calc(33.333% - 6px);
        min-height:48px;
        margin:3px 1px;
        padding:5px;
        justify-content:center;
        font-size:11px;
        text-align:center;
    }
    .sidebar a i{font-size:15px}
    .main{padding:13px}
    .page-head{align-items:flex-start;flex-direction:column}
    .page-head h1{font-size:23px}
    .stats{grid-template-columns:repeat(2,1fr)}
    .filters{grid-template-columns:1fr}
    .review-top{flex-direction:column}
    .review-status{justify-content:flex-start}
    .review-meta{align-items:flex-start;flex-direction:column}
    .actions{gap:8px}
    .btn{min-height:42px}
    .reply-actions{flex-direction:column}
    .reply-actions .btn{width:100%}
}

@media(max-width:430px){
    .stats{grid-template-columns:1fr}
    .sidebar a{width:calc(50% - 5px);font-size:12px}
    .card-body{padding:13px}
    .review-body{padding:13px}
    .actions form,.actions .btn{max-width:100%}
}


/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.layout{
    display:block!important;
    grid-template-columns:none!important;
    min-height:100vh!important;
}
.main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
    padding:16px 18px 20px!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<style>
/* TRAVSCOPE V24.75 — International Marketing / Reviews */
.rv-page-head{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:17px 18px;margin-bottom:14px;background:#fff;border:1px solid #dce6f1;border-left:4px solid #f59e0b;border-radius:16px;box-shadow:0 8px 24px rgba(15,23,42,.045)}
.rv-title h1{margin:3px 0 4px;font-size:25px;line-height:1.05;color:#0f172a}.rv-title p{margin:0;color:#64748b;font-size:10px}.rv-eyebrow{font-size:8px;letter-spacing:.12em;font-weight:900;color:#2563eb}.rv-head-right{display:flex;align-items:center;gap:9px}.rv-kpis{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}.rv-kpi{min-width:83px;padding:8px 9px;border:1px solid #e2e8f0;border-left:3px solid #2563eb;border-radius:10px;background:#fbfdff}.rv-kpi span{display:block;color:#64748b;text-transform:uppercase;font-size:6px;font-weight:900;letter-spacing:.06em}.rv-kpi strong{display:block;margin-top:3px;color:#0f172a;font-size:15px}.rv-kpi.c2{border-left-color:#f59e0b}.rv-kpi.c3{border-left-color:#10b981}.rv-kpi.c4{border-left-color:#ef4444}.rv-kpi.c5{border-left-color:#8b5cf6}.rv-kpi.c6{border-left-color:#eab308}.rv-refresh{height:38px;padding:0 12px;border:1px solid #dce6f1;border-radius:9px;display:inline-flex;align-items:center;gap:6px;background:#fff;color:#334155;font-size:9px;font-weight:900;white-space:nowrap}
.stats{display:none!important}.rv-filter-card{margin-bottom:0!important;border-bottom-left-radius:0!important;border-bottom-right-radius:0!important;box-shadow:none!important}.rv-directory-card{margin-top:0!important;border-top:0!important;border-top-left-radius:0!important;border-top-right-radius:0!important}.rv-filter-card .card-head{padding:11px 14px 6px}.rv-filter-card .card-body{padding:8px 14px 10px}.rv-filter-card .filters{gap:8px}.rv-filter-card .control{min-height:36px}.rv-filter-card .filter-btn{min-height:36px}.rv-directory-card .card-head{padding:10px 14px;background:#f8fbff}.rv-directory-card .card-body{padding:0 12px 12px}.review{margin:0!important;border:0!important;border-bottom:1px solid #e6edf5!important;border-radius:0!important;box-shadow:none!important;padding:14px 4px!important}.review:last-child{border-bottom:0!important}.review-top{gap:10px}.review-body{padding-top:8px!important}.review-text{line-height:1.55}.actions{gap:6px!important}.btn{min-height:32px!important}
@media(max-width:1280px){.rv-page-head{align-items:flex-start;flex-direction:column}.rv-head-right{width:100%;justify-content:space-between}}
@media(max-width:760px){.rv-head-right{flex-direction:column;align-items:stretch}.rv-kpis{justify-content:flex-start}.rv-kpi{min-width:105px;flex:1}.rv-filter-card .filters{grid-template-columns:1fr!important}}
</style>

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>

<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->







<header class="header">

<a
    href="<?= e(BASE_URL . 'admin-dashboard.php'); ?>"
    class="logo"
>

<div class="logo-icon">

<i class="fa-solid fa-plane"></i>

</div>

TRAV<span>SCOPE</span> ADMIN

</a>


<div class="admin">

<div class="admin-avatar">

<?= e(
    strtoupper(
        mb_substr(
            $admin['name'],
            0,
            1
        )
    )
); ?>

</div>

<div>

<strong>
<?= e($admin['name']); ?>
</strong>

<small>

<?= e(
    ucfirst(
        str_replace(
            '_',
            ' ',
            $admin['role']
        )
    )
); ?>

</small>

</div>

</div>

</header>


<div class="layout">


<!-- SIDEBAR -->

<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->




<!-- MAIN -->

<main class="main">


<section class="rv-page-head">
<div class="rv-title">
<div class="rv-eyebrow">MARKETING / REPUTATION</div>
<h1>Customer Reviews</h1>
<p>Moderate traveller feedback, ratings, featured testimonials and admin responses.</p>
</div>
<div class="rv-head-right">
<div class="rv-kpis">
<div class="rv-kpi c1"><span>Total</span><strong><?= number_format($stats['total']); ?></strong></div>
<div class="rv-kpi c2"><span>Pending</span><strong><?= number_format($stats['pending']); ?></strong></div>
<div class="rv-kpi c3"><span>Approved</span><strong><?= number_format($stats['approved']); ?></strong></div>
<div class="rv-kpi c4"><span>Rejected</span><strong><?= number_format($stats['rejected']); ?></strong></div>
<div class="rv-kpi c5"><span>Featured</span><strong><?= number_format($stats['featured']); ?></strong></div>
<div class="rv-kpi c6"><span>Avg Rating</span><strong><?= number_format($stats['average_rating'],1); ?></strong></div>
</div>
<a href="<?= e(BASE_URL . 'admin-reviews.php'); ?>" class="rv-refresh"><i class="fa-solid fa-rotate"></i> Refresh</a>
</div>
</section>


<!-- ALERT -->

<?php if ($success !== ''): ?>

<div class="alert alert-success">

<i class="fa-solid fa-circle-check"></i>

<?= e($success); ?>

</div>

<?php endif; ?>


<?php if ($error !== ''): ?>

<div class="alert alert-error">

<i class="fa-solid fa-circle-exclamation"></i>

<?= e($error); ?>

</div>

<?php endif; ?>


<!-- STATISTICS -->

<section class="stats">


<div class="stat">

<div class="stat-icon">
<i class="fa-solid fa-comments"></i>
</div>

<strong>
<?= number_format($stats['total']); ?>
</strong>

<span>
Total Reviews
</span>

</div>


<div class="stat">

<div class="stat-icon">
<i class="fa-regular fa-clock"></i>
</div>

<strong>
<?= number_format($stats['pending']); ?>
</strong>

<span>
Pending Approval
</span>

</div>


<div class="stat">

<div class="stat-icon">
<i class="fa-solid fa-circle-check"></i>
</div>

<strong>
<?= number_format($stats['approved']); ?>
</strong>

<span>
Approved
</span>

</div>


<div class="stat">

<div class="stat-icon">
<i class="fa-solid fa-ban"></i>
</div>

<strong>
<?= number_format($stats['rejected']); ?>
</strong>

<span>
Rejected
</span>

</div>


<div class="stat">

<div class="stat-icon">
<i class="fa-solid fa-award"></i>
</div>

<strong>
<?= number_format($stats['featured']); ?>
</strong>

<span>
Featured
</span>

</div>


<div class="stat rating-stat">

<div class="stat-icon">
<i class="fa-solid fa-star"></i>
</div>

<strong>
<?= number_format(
    $stats['average_rating'],
    1
); ?>
</strong>

<span>
Average Rating
</span>

</div>


</section>


<!-- FILTERS -->

<section class="card rv-filter-card">

<div class="card-head">

<div>

<div class="rv-eyebrow">REVIEW DIRECTORY</div>
<h2>Search & Moderation</h2>

<p>
Search by traveller, package, rating, status or featured state.
</p>

</div>

</div>


<div class="card-body">

<form
    method="get"
    class="filters"
>


<input
    type="text"
    name="q"
    class="control"
    placeholder="Customer, package or review..."
    value="<?= e($search); ?>"
>


<select
    name="status"
    class="control"
>

<option value="">
All Status
</option>

<option
    value="pending"
    <?= $status === 'pending'
        ? 'selected'
        : ''; ?>
>
Pending
</option>

<option
    value="approved"
    <?= $status === 'approved'
        ? 'selected'
        : ''; ?>
>
Approved
</option>

<option
    value="rejected"
    <?= $status === 'rejected'
        ? 'selected'
        : ''; ?>
>
Rejected
</option>

</select>


<select
    name="rating"
    class="control"
>

<option value="0">
All Ratings
</option>

<?php for ($i = 5; $i >= 1; $i--): ?>

<option
    value="<?= $i; ?>"
    <?= $rating === $i
        ? 'selected'
        : ''; ?>
>
<?= $i; ?> Star<?= $i > 1 ? 's' : ''; ?>
</option>

<?php endfor; ?>

</select>


<select
    name="featured"
    class="control"
>

<option value="">
All Reviews
</option>

<option
    value="1"
    <?= $featured === '1'
        ? 'selected'
        : ''; ?>
>
Featured
</option>

<option
    value="0"
    <?= $featured === '0'
        ? 'selected'
        : ''; ?>
>
Not Featured
</option>

</select>


<button
    type="submit"
    class="filter-btn"
>

<i class="fa-solid fa-magnifying-glass"></i>

Search

</button>

</form>


<?php if (
    $search !== '' ||
    $status !== '' ||
    $rating > 0 ||
    $featured !== ''
): ?>

<a
    href="<?= e(BASE_URL . 'admin-reviews.php'); ?>"
    class="clear"
>

<i class="fa-solid fa-xmark"></i>

Clear all filters

</a>

<?php endif; ?>


</div>

</section>


<!-- REVIEWS -->

<section class="card rv-directory-card">

<div class="card-head">

<div>

<h2>
Traveller Reviews
</h2>

<p>

<?= number_format($totalRows); ?>

review<?= $totalRows === 1 ? '' : 's'; ?>

found.

</p>

</div>

</div>


<div class="card-body">


<?php if ($reviews): ?>


<?php foreach ($reviews as $review): ?>


<article class="review">


<div class="review-top">


<div class="customer">


<div class="avatar">

<?= e(
    strtoupper(
        mb_substr(
            $review['full_name']
                ?: 'U',
            0,
            1
        )
    )
); ?>

</div>


<div>

<h3>

<?= e(
    $review['full_name']
        ?: 'Unknown Customer'
); ?>

</h3>

<p>

<?= e(
    $review['email']
        ?: 'Email unavailable'
); ?>

•

<?= e(
    reviewDate(
        $review['created_at'],
        'd M Y'
    )
); ?>

</p>

</div>


</div>


<div class="review-status">


<span
    class="
        badge
        badge-<?=
            e(
                reviewStatusClass(
                    $review['status']
                )
            );
        ?>
    "
>

<?= e(
    ucfirst(
        $review['status']
    )
); ?>

</span>


<?php if ((int) $review['featured'] === 1): ?>

<span class="badge badge-blue">

<i class="fa-solid fa-award"></i>

Featured

</span>

<?php endif; ?>


</div>


</div>


<div class="review-body">


<div class="review-meta">


<div class="package-name">

Package:

<strong>

<?= e(
    $review['package_title']
        ?: 'Package unavailable'
); ?>

</strong>

</div>


<div>

<span class="stars">

<?= reviewStars(
    $review['rating']
); ?>

</span>

<span class="rating-number">

<?= (int) $review['rating']; ?>/5

</span>

</div>


</div>


<?php if (!empty($review['title'])): ?>

<h3 class="review-title">

<?= e($review['title']); ?>

</h3>

<?php endif; ?>


<div class="review-text">

<?= e($review['review_text']); ?>

</div>


<?php if (!empty($review['booking_number'])): ?>

<div class="booking-info">

<i class="fa-solid fa-shield-check"></i>

<strong>
Verified booking
</strong>

<span>
<?= e($review['booking_number']); ?>
</span>


<?php if (!empty($review['travel_date'])): ?>

<span>

Travel:
<?= e(
    reviewDate(
        $review['travel_date'],
        'd M Y'
    )
); ?>

</span>

<?php endif; ?>


<a
    href="<?= e(
        BASE_URL .
        'admin-booking-details.php?id=' .
        (int) $review['booking_id']
    ); ?>"
    style="
        margin-left:auto;
        color:#0b74ff;
        font-weight:800;
    "
>

View Booking

</a>

</div>

<?php endif; ?>


<!-- ADMIN REPLY -->

<?php if (!empty($review['admin_reply'])): ?>

<div class="admin-reply">

<div class="admin-reply-title">

<span>

<i class="fa-solid fa-headset"></i>

TRAVSCOPE Response

</span>

<span>

<?= e(
    reviewDate(
        $review['admin_reply_at'],
        'd M Y'
    )
); ?>

</span>

</div>

<p>

<?= e($review['admin_reply']); ?>

</p>

</div>

<?php endif; ?>


<!-- ACTIONS -->

<div class="actions">


<?php if ($review['status'] !== 'approved'): ?>

<form method="post">

<input
    type="hidden"
    name="csrf_token"
    value="<?= e($csrfToken); ?>"
>

<input
    type="hidden"
    name="action"
    value="change_status"
>

<input
    type="hidden"
    name="review_id"
    value="<?= (int) $review['id']; ?>"
>

<input
    type="hidden"
    name="new_status"
    value="approved"
>

<button
    type="submit"
    class="btn btn-approve"
>

<i class="fa-solid fa-check"></i>

Approve

</button>

</form>

<?php endif; ?>


<?php if ($review['status'] !== 'rejected'): ?>

<form
    method="post"
    onsubmit="
        return confirm(
            'Reject this customer review?'
        );
    "
>

<input
    type="hidden"
    name="csrf_token"
    value="<?= e($csrfToken); ?>"
>

<input
    type="hidden"
    name="action"
    value="change_status"
>

<input
    type="hidden"
    name="review_id"
    value="<?= (int) $review['id']; ?>"
>

<input
    type="hidden"
    name="new_status"
    value="rejected"
>

<button
    type="submit"
    class="btn btn-reject"
>

<i class="fa-solid fa-xmark"></i>

Reject

</button>

</form>

<?php endif; ?>


<?php if ($review['status'] !== 'pending'): ?>

<form method="post">

<input
    type="hidden"
    name="csrf_token"
    value="<?= e($csrfToken); ?>"
>

<input
    type="hidden"
    name="action"
    value="change_status"
>

<input
    type="hidden"
    name="review_id"
    value="<?= (int) $review['id']; ?>"
>

<input
    type="hidden"
    name="new_status"
    value="pending"
>

<button
    type="submit"
    class="btn btn-pending"
>

<i class="fa-regular fa-clock"></i>

Pending

</button>

</form>

<?php endif; ?>


<form method="post">

<input
    type="hidden"
    name="csrf_token"
    value="<?= e($csrfToken); ?>"
>

<input
    type="hidden"
    name="action"
    value="toggle_featured"
>

<input
    type="hidden"
    name="review_id"
    value="<?= (int) $review['id']; ?>"
>

<button
    type="submit"
    class="btn btn-feature"
>

<i class="fa-solid fa-award"></i>

<?= (int) $review['featured'] === 1
    ? 'Unfeature'
    : 'Feature'; ?>

</button>

</form>


<button
    type="button"
    class="btn btn-blue"
    onclick="
        toggleReply(
            <?= (int) $review['id']; ?>
        )
    "
>

<i class="fa-solid fa-reply"></i>

<?= !empty($review['admin_reply'])
    ? 'Edit Reply'
    : 'Reply'; ?>

</button>


<?php if (!empty($review['user_id'])): ?>

<a
    href="<?= e(
        BASE_URL .
        'admin-user-details.php?id=' .
        (int) $review['user_id']
    ); ?>"
    class="btn btn-light"
>

<i class="fa-regular fa-user"></i>

Customer

</a>

<?php endif; ?>


<?php if (!empty($review['package_slug'])): ?>

<a
    href="<?= e(
        BASE_URL .
        'package-details.php?slug=' .
        urlencode(
            $review['package_slug']
        )
    ); ?>"
    target="_blank"
    class="btn btn-light"
>

<i class="fa-solid fa-arrow-up-right-from-square"></i>

Package

</a>

<?php endif; ?>


</div>


<!-- REPLY FORM -->

<div
    class="reply-box"
    id="reply-<?= (int) $review['id']; ?>"
>

<form method="post">

<input
    type="hidden"
    name="csrf_token"
    value="<?= e($csrfToken); ?>"
>

<input
    type="hidden"
    name="action"
    value="admin_reply"
>

<input
    type="hidden"
    name="review_id"
    value="<?= (int) $review['id']; ?>"
>


<textarea
    name="admin_reply"
    maxlength="3000"
    required
    placeholder="Write a professional response to this traveller..."
><?= e(
    $review['admin_reply']
    ?? ''
); ?></textarea>


<div class="reply-actions">

<button
    type="button"
    class="btn btn-light"
    onclick="
        toggleReply(
            <?= (int) $review['id']; ?>
        )
    "
>
Cancel
</button>


<?php if (!empty($review['admin_reply'])): ?>

<button
    type="submit"
    name="action"
    value="remove_reply"
    class="btn btn-reject"
    formnovalidate
    onclick="
        return confirm(
            'Remove this admin reply?'
        );
    "
>

Remove Reply

</button>

<?php endif; ?>


<button
    type="submit"
    class="btn btn-blue"
>

<i class="fa-solid fa-paper-plane"></i>

Save Reply

</button>

</div>

</form>

</div>


</div>

</article>


<?php endforeach; ?>


<!-- PAGINATION -->

<?php if ($totalPages > 1): ?>

<div class="pagination">


<?php if ($page > 1): ?>

<a
    href="<?= e(
        reviewPageUrl(
            $page - 1
        )
    ); ?>"
    class="page-btn"
>

<i class="fa-solid fa-chevron-left"></i>

</a>

<?php endif; ?>


<?php

$startPage =
    max(
        1,
        $page - 2
    );

$endPage =
    min(
        $totalPages,
        $page + 2
    );

?>


<?php for (
    $i = $startPage;
    $i <= $endPage;
    $i++
): ?>

<a
    href="<?= e(
        reviewPageUrl($i)
    ); ?>"
    class="
        page-btn
        <?= $i === $page
            ? 'active'
            : ''; ?>
    "
>

<?= $i; ?>

</a>

<?php endfor; ?>


<?php if ($page < $totalPages): ?>

<a
    href="<?= e(
        reviewPageUrl(
            $page + 1
        )
    ); ?>"
    class="page-btn"
>

<i class="fa-solid fa-chevron-right"></i>

</a>

<?php endif; ?>


</div>

<?php endif; ?>


<?php else: ?>


<div class="empty">

<div class="empty-icon">

<i class="fa-regular fa-star"></i>

</div>

<h3>
No reviews found
</h3>

<p>
Customer reviews will appear here for moderation.
</p>

</div>


<?php endif; ?>


</div>

</section>


</main>

</div>


<script>

function toggleReply(id)
{
    const box =
        document.getElementById(
            'reply-' + id
        );

    if (!box) {
        return;
    }

    box.classList.toggle(
        'open'
    );

    if (
        box.classList.contains(
            'open'
        )
    ) {

        const textarea =
            box.querySelector(
                'textarea'
            );

        if (textarea) {
            textarea.focus();
        }
    }
}


/*
|--------------------------------------------------------------------------
| PREVENT DOUBLE SUBMISSION
|--------------------------------------------------------------------------
*/

document.querySelectorAll(
    'form[method="post"]'
).forEach(function(form){

    form.addEventListener(
        'submit',
        function(){

            const button =
                this.querySelector(
                    'button[type="submit"]:focus'
                );

            if (!button) {
                return;
            }

            setTimeout(
                function(){

                    button.disabled = true;

                    button.style.opacity =
                        '.65';

                },
                20
            );
        }
    );

});

</script>







<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>