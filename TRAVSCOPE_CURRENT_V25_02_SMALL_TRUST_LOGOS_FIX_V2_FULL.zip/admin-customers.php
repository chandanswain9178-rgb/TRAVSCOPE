<?php

require_once __DIR__ . '/config.php';

/*
|--------------------------------------------------------------------------
| ADMIN AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_id'])) {
    redirect(BASE_URL . 'admin-login.php');
}

$adminId = (int)$_SESSION['admin_id'];

$stmt = $pdo->prepare("
    SELECT id, name, email, role, status
    FROM admins
    WHERE id = ?
    LIMIT 1
");

$stmt->execute([$adminId]);

$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin || $admin['status'] !== 'active') {

    unset($_SESSION['admin_id']);

    redirect(BASE_URL . 'admin-login.php');
}


function adminEnsureTravelProfileTables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_family_members (
        id INT AUTO_INCREMENT PRIMARY KEY,
        owner_user_id INT NOT NULL,
        member_code VARCHAR(40) NOT NULL UNIQUE,
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NULL,
        relationship VARCHAR(50) NOT NULL,
        date_of_birth DATE NULL,
        mobile VARCHAR(30) NULL,
        email VARCHAR(190) NULL,
        relationship_notes VARCHAR(500) NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_family_owner_user (owner_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS user_family_links (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        linked_user_id INT NOT NULL,
        relationship VARCHAR(50) NOT NULL,
        relationship_notes VARCHAR(500) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_family_link (user_id, linked_user_id),
        INDEX idx_family_link_user (user_id),
        INDEX idx_family_linked_user (linked_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS user_travel_profiles (
        user_id INT PRIMARY KEY,
        preferred_language VARCHAR(50) NULL,
        city_state VARCHAR(150) NULL,
        lead_source VARCHAR(100) NULL,
        date_of_birth DATE NULL,
        anniversary_date DATE NULL,
        spouse_partner_name VARCHAR(150) NULL,
        occupation VARCHAR(150) NULL,
        preferred_destination_type VARCHAR(255) NULL,
        travel_style VARCHAR(255) NULL,
        preferred_hotel_category VARCHAR(100) NULL,
        relationship_notes TEXT NULL,
        birthday_wishes TINYINT(1) NOT NULL DEFAULT 1,
        anniversary_wishes TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS user_travel_documents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        document_category VARCHAR(30) NOT NULL,
        document_type VARCHAR(80) NOT NULL,
        document_number VARCHAR(150) NULL,
        issuing_country VARCHAR(100) NULL,
        issue_date DATE NULL,
        expiry_date DATE NULL,
        file_path VARCHAR(500) NOT NULL,
        original_name VARCHAR(255) NOT NULL,
        mime_type VARCHAR(100) NULL,
        file_size INT NOT NULL DEFAULT 0,
        notes VARCHAR(1000) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_admin_travel_documents_user (user_id),
        INDEX idx_admin_travel_documents_type (document_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function adminFamilyNormalizeMobile(string $mobile): string {
    $digits = preg_replace('/[^0-9]/', '', $mobile);
    return is_string($digits) ? (strlen($digits) >= 10 ? substr($digits, -10) : $digits) : '';
}

function adminFamilyReverseRelationship(string $relationship): string {
    return match ($relationship) {
        'Child' => 'Parent',
        'Parent' => 'Child',
        'Grandparent' => 'Grandchild',
        'Grandchild' => 'Grandparent',
        default => $relationship
    };
}

function adminFamilyFindCustomer(PDO $pdo, int $ownerUserId, string $email, string $mobile): ?array {
    $email = strtolower(trim($email));
    $mobileLast10 = adminFamilyNormalizeMobile($mobile);
    $parts = [];
    $params = [$ownerUserId];

    if ($email !== '') {
        $parts[] = "LOWER(TRIM(email)) = ?";
        $params[] = $email;
    }
    if ($mobileLast10 !== '') {
        $parts[] = "RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(TRIM(COALESCE(mobile,'')),' ',''),'-',''),'(',''),')',''),'+',''),10) = ?";
        $params[] = $mobileLast10;
    }
    if (!$parts) return null;

    $stmt = $pdo->prepare(
        "SELECT id, full_name, email, mobile, country, status
         FROM users
         WHERE id <> ? AND (" . implode(" OR ", $parts) . ")
         ORDER BY id ASC LIMIT 1"
    );
    $stmt->execute($params);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function adminFamilyLinkExists(PDO $pdo, int $userA, int $userB): bool {
    $stmt = $pdo->prepare(
        "SELECT id FROM user_family_links
         WHERE (user_id=? AND linked_user_id=?)
            OR (user_id=? AND linked_user_id=?)
         LIMIT 1"
    );
    $stmt->execute([$userA,$userB,$userB,$userA]);
    return (bool)$stmt->fetchColumn();
}

function adminFamilyCreateCustomer(PDO $pdo, int $ownerUserId, string $first, string $last, string $email, string $mobile, string $country): int {
    $name = trim($first . ' ' . $last);
    $email = strtolower(trim($email));
    if ($email === '') {
        $email = 'family.' . $ownerUserId . '.' . bin2hex(random_bytes(8)) . '@travscope.local';
    }

    $hash = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);
    if ($hash === false) throw new RuntimeException('Unable to create family customer account.');

    $stmt = $pdo->prepare(
        "INSERT INTO users(full_name,email,mobile,password,profile_image,country,email_verified,status)
         VALUES(?,?,?,?,NULL,?,0,'active')"
    );
    $stmt->execute([
        $name !== '' ? $name : 'Family Traveller',
        $email,
        trim($mobile) !== '' ? trim($mobile) : null,
        $hash,
        trim($country) !== '' ? trim($country) : 'India'
    ]);

    $id = (int)$pdo->lastInsertId();
    if ($id <= 0) throw new RuntimeException('Unable to create family customer account.');
    return $id;
}

function adminTravelDocumentTypes(): array {
    return [
        'identity' => [
            'Aadhaar Card',
            'PAN Card',
            'Voter ID',
            'Driving Licence',
            'National ID',
            'Birth Certificate'
        ],
        'travel' => [
            'Passport',
            'Visa',
            'Travel Insurance',
            'Flight Ticket',
            'Hotel Voucher',
            'Vaccination Certificate',
            'Other Travel Document'
        ]
    ];
}

function adminTravelDocumentCategoryForType(string $type): ?string {
    foreach (adminTravelDocumentTypes() as $category => $types) {
        if (in_array($type, $types, true)) {
            return $category;
        }
    }
    return null;
}

function adminSaveTravellerDocumentUpload(array $file, int $userId): array {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        throw new RuntimeException('Please choose a document file to upload.');
    }
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Document upload failed.');
    }
    if ((int)($file['size'] ?? 0) <= 0 || (int)$file['size'] > 8 * 1024 * 1024) {
        throw new RuntimeException('Document file must be 8 MB or smaller.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string)$finfo->file($file['tmp_name']);
    $allowed = [
        'application/pdf' => 'pdf',
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp'
    ];
    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Only PDF, JPG, PNG and WEBP document files are allowed.');
    }

    $uploadDirectory = __DIR__ . '/uploads/traveller-documents/user_' . $userId . '/';
    if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true)) {
        throw new RuntimeException('Unable to create the traveller document upload folder.');
    }

    $extension = $allowed[$mime];
    $fileName = 'doc_' . $userId . '_' . bin2hex(random_bytes(12)) . '.' . $extension;
    $destination = $uploadDirectory . $fileName;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        throw new RuntimeException('Unable to save the uploaded document.');
    }

    return [
        'path' => 'uploads/traveller-documents/user_' . $userId . '/' . $fileName,
        'original_name' => mb_substr((string)($file['name'] ?? 'document.' . $extension), 0, 255),
        'mime_type' => $mime,
        'file_size' => (int)$file['size']
    ];
}

function adminDeleteTravellerDocumentFile(string $relativePath, int $userId): void {
    $relativePath = ltrim(trim($relativePath), '/');
    if ($relativePath === '') return;

    $allowedPrefix = 'uploads/traveller-documents/user_' . $userId . '/';
    if (!str_starts_with($relativePath, $allowedPrefix)) return;

    $fullPath = __DIR__ . '/' . $relativePath;
    if (is_file($fullPath)) {
        @unlink($fullPath);
    }
}

function adminProfileDateOrNull(string $v): ?string {$v=trim($v);if($v==='')return null;$d=DateTime::createFromFormat('Y-m-d',$v);return($d&&$d->format('Y-m-d')===$v)?$v:null;}
function adminCustomerClip(string $text, int $limit): string {return function_exists('mb_substr') ? mb_substr($text,0,$limit,'UTF-8') : substr($text,0,$limit);}
function adminNewFamilyCode(int $uid): string {return 'TRV-FAM-'.$uid.'-'.strtoupper(substr(bin2hex(random_bytes(5)),0,8));}
try{adminEnsureTravelProfileTables($pdo);}catch(Throwable $e){error_log('Admin travel schema: '.$e->getMessage());}
$customerLocationReady = false;
try {
    $locationColumnStmt = $pdo->query("SHOW COLUMNS FROM user_travel_profiles LIKE 'address_state'");
    $customerLocationReady = (bool)$locationColumnStmt->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) { error_log('Customer location migration check: '.$e->getMessage()); }


/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_customers_csrf'])) {
    $_SESSION['admin_customers_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['admin_customers_csrf'];

// Bundled worldwide country/region directory (no API call required for the first dropdown).
$customerGeoDirectory = json_decode((string)@file_get_contents(__DIR__.'/customer-location-directory.json'),true) ?: [];
$customerGeoCountries = $customerGeoDirectory['countries'] ?? [];


/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function adminUserMoney($amount, $currency = 'INR')
{
    $amount = (float)$amount;

    $currency = strtoupper(
        trim((string)$currency)
    );

    if ($currency === 'INR') {
        return '₹' . number_format($amount, 2);
    }

    return $currency . ' ' . number_format($amount, 2);
}


function adminUserDate(
    $date,
    $format = 'd M Y'
) {

    if (empty($date)) {
        return 'Not available';
    }

    $time = strtotime($date);

    if (!$time) {
        return 'Not available';
    }

    return date($format, $time);
}


function userStatusClass($status)
{
    switch ($status) {

        case 'active':
            return 'success';

        case 'blocked':
            return 'danger';

        default:
            return 'warning';
    }
}


function adminCustomersPageUrl($page)
{
    $query = $_GET;

    $query['page'] = $page;

    return BASE_URL .
        'admin-customers.php?' .
        http_build_query($query);
}

/*
|--------------------------------------------------------------------------
| FLASH MESSAGES
|--------------------------------------------------------------------------
*/

$success = '';
$error = '';

if (!empty($_SESSION['admin_customers_success'])) {

    $success =
        $_SESSION['admin_customers_success'];

    unset(
        $_SESSION['admin_customers_success']
    );
}

if (!empty($_SESSION['admin_customers_error'])) {

    $error =
        $_SESSION['admin_customers_error'];

    unset(
        $_SESSION['admin_customers_error']
    );
}

/*
|--------------------------------------------------------------------------
| USER STATUS UPDATE
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $postedToken =
        (string)($_POST['csrf_token'] ?? '');

    if (
        $postedToken === '' ||
        !hash_equals(
            $_SESSION['admin_customers_csrf'] ?? '',
            $postedToken
        )
    ) {

        $error =
            'Security verification failed. Please refresh and try again.';

    } else {

        $action =
            (string)($_POST['action'] ?? '');

        /*
        |--------------------------------------------------------------------------
        | MANUAL CUSTOMER CREATE
        |--------------------------------------------------------------------------
        */

        if ($action === 'add_customer') {

            try {

                $fullName = trim((string)($_POST['customer_full_name'] ?? ''));
                $email = strtolower(trim((string)($_POST['customer_email'] ?? '')));
                $mobile = trim((string)($_POST['customer_mobile'] ?? ''));
                $country = trim((string)($_POST['customer_country'] ?? 'India'));
                $newStatus = strtolower(trim((string)($_POST['customer_status'] ?? 'active')));
                $emailVerified = !empty($_POST['customer_email_verified']) ? 1 : 0;
                $temporaryPassword = (string)($_POST['customer_password'] ?? '');

                if ($fullName === '') {
                    throw new RuntimeException('Customer name is required.');
                }

                if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    throw new RuntimeException('Please enter a valid customer email address.');
                }

                if (
                    $mobile !== ''
                    && !preg_match('/^[0-9+\-\s()]{7,30}$/', $mobile)
                ) {
                    throw new RuntimeException('Please enter a valid mobile number.');
                }

                $allowedStatuses = ['active', 'inactive', 'blocked'];
                if (!in_array($newStatus, $allowedStatuses, true)) {
                    $newStatus = 'active';
                }

                if ($country === '') {
                    $country = 'India';
                }

                /*
                | Check existing customer by email and, when supplied,
                | normalized mobile number.
                */
                $whereParts = ['LOWER(TRIM(email)) = ?'];
                $checkParams = [$email];

                $mobileLast10 = adminFamilyNormalizeMobile($mobile);
                if ($mobileLast10 !== '') {
                    $whereParts[] =
                        "RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(TRIM(COALESCE(mobile,'')),' ',''),'-',''),'(',''),')',''),'+',''),10) = ?";
                    $checkParams[] = $mobileLast10;
                }

                $stmt = $pdo->prepare(
                    "SELECT id, full_name, email, mobile
                     FROM users
                     WHERE " . implode(' OR ', $whereParts) . "
                     LIMIT 1"
                );
                $stmt->execute($checkParams);
                $existingCustomer = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($existingCustomer) {
                    throw new RuntimeException(
                        'This customer already exists as Customer #' .
                        (int)$existingCustomer['id'] .
                        ' (' . (string)$existingCustomer['full_name'] . ').'
                    );
                }

                /*
                | Password is optional for admin-created customers.
                | A secure random password is stored when admin leaves it blank.
                */
                if ($temporaryPassword !== '') {
                    if (mb_strlen($temporaryPassword) < 6) {
                        throw new RuntimeException(
                            'Temporary password must contain at least 6 characters or leave it blank.'
                        );
                    }
                    $rawPassword = $temporaryPassword;
                } else {
                    $rawPassword = bin2hex(random_bytes(16));
                }

                $passwordHash = password_hash($rawPassword, PASSWORD_DEFAULT);
                if ($passwordHash === false) {
                    throw new RuntimeException('Unable to secure the customer account.');
                }

                $stmt = $pdo->prepare(
                    "INSERT INTO users
                        (full_name, email, mobile, password, profile_image, country, email_verified, status)
                     VALUES (?, ?, ?, ?, NULL, ?, ?, ?)"
                );
                $stmt->execute([
                    $fullName,
                    $email,
                    $mobile !== '' ? $mobile : null,
                    $passwordHash,
                    $country,
                    $emailVerified,
                    $newStatus
                ]);

                $newCustomerId = (int)$pdo->lastInsertId();

                if ($newCustomerId <= 0) {
                    throw new RuntimeException('Unable to create customer.');
                }

                $_SESSION['admin_customers_success'] =
                    $fullName . ' added successfully as Customer #' . $newCustomerId . '.';

                redirect(
                    BASE_URL .
                    'admin-customers.php?profile_id=' .
                    $newCustomerId
                );

            } catch (RuntimeException $e) {

                $error = $e->getMessage();

            } catch (Throwable $e) {

                error_log(
                    'Admin manual customer create error: ' .
                    $e->getMessage()
                );

                $error = 'Unable to add customer.';
            }

        }

        /*
        |--------------------------------------------------------------------------
        | DELETE CUSTOMER
        |--------------------------------------------------------------------------
        */

        elseif ($action === 'delete_customer') {

            $userId = (int)($_POST['user_id'] ?? 0);

            if ($userId <= 0) {

                $error = 'Invalid customer.';

            } else {

                $documentFilesToDelete = [];

                try {

                    $stmt = $pdo->prepare("
                        SELECT id, full_name, email
                        FROM users
                        WHERE id = ?
                        LIMIT 1
                    ");
                    $stmt->execute([$userId]);
                    $customer = $stmt->fetch(PDO::FETCH_ASSOC);

                    if (!$customer) {
                        throw new RuntimeException('Customer was not found.');
                    }

                    /*
                    | Preserve booking records. The project already supports
                    | guest/unlinked bookings with user_id = NULL, so removing
                    | an account will detach its bookings instead of deleting
                    | financial/travel history.
                    */
                    $pdo->beginTransaction();

                    $stmt = $pdo->prepare("
                        SELECT file_path
                        FROM user_travel_documents
                        WHERE user_id = ?
                    ");
                    $stmt->execute([$userId]);
                    $documentFilesToDelete = $stmt->fetchAll(PDO::FETCH_COLUMN);

                    $pdo->prepare("
                        UPDATE bookings
                        SET user_id = NULL
                        WHERE user_id = ?
                    ")->execute([$userId]);

                    $pdo->prepare("
                        DELETE FROM user_family_links
                        WHERE user_id = ?
                           OR linked_user_id = ?
                    ")->execute([$userId, $userId]);

                    $pdo->prepare("
                        DELETE FROM user_family_members
                        WHERE owner_user_id = ?
                    ")->execute([$userId]);

                    $pdo->prepare("
                        DELETE FROM user_travel_documents
                        WHERE user_id = ?
                    ")->execute([$userId]);

                    $pdo->prepare("
                        DELETE FROM user_travel_profiles
                        WHERE user_id = ?
                    ")->execute([$userId]);

                    $stmt = $pdo->prepare("
                        DELETE FROM users
                        WHERE id = ?
                        LIMIT 1
                    ");
                    $stmt->execute([$userId]);

                    if ($stmt->rowCount() !== 1) {
                        throw new RuntimeException('Customer could not be deleted.');
                    }

                    $pdo->commit();

                    /*
                    | Database deletion is complete. Remove uploaded traveller
                    | document files afterwards so a DB rollback can never leave
                    | the record pointing to a file that was already removed.
                    */
                    foreach ($documentFilesToDelete as $relativePath) {
                        adminDeleteTravellerDocumentFile(
                            (string)$relativePath,
                            $userId
                        );
                    }

                    $_SESSION['admin_customers_success'] =
                        (string)$customer['full_name'] .
                        ' (Customer #' . $userId . ') deleted successfully.';

                    redirect(
                        BASE_URL .
                        'admin-customers.php'
                    );

                } catch (RuntimeException $e) {

                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    $error = $e->getMessage();

                } catch (Throwable $e) {

                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    error_log(
                        'Admin customer delete error: ' .
                        $e->getMessage()
                    );

                    $error =
                        'Unable to delete this customer because other records may still be linked to the account.';
                }
            }
        }

        /*
        |--------------------------------------------------------------------------
        | CHANGE USER STATUS
        |--------------------------------------------------------------------------
        */

        elseif ($action === 'change_status') {

            $userId =
                (int)($_POST['user_id'] ?? 0);

            $newStatus =
                strtolower(
                    trim(
                        (string)(
                            $_POST['new_status']
                            ?? ''
                        )
                    )
                );

            $allowedStatuses = [
                'active',
                'inactive',
                'blocked'
            ];

            if ($userId <= 0) {

                $error =
                    'Invalid customer.';

            } elseif (
                !in_array(
                    $newStatus,
                    $allowedStatuses,
                    true
                )
            ) {

                $error =
                    'Invalid account status.';

            } else {

                try {

                    /*
                    |--------------------------------------------------------------------------
                    | GET USER
                    |--------------------------------------------------------------------------
                    */

                    $stmt = $pdo->prepare("
                        SELECT
                            id,
                            full_name,
                            email,
                            status
                        FROM users
                        WHERE id = ?
                        LIMIT 1
                    ");

                    $stmt->execute([$userId]);

                    $customer =
                        $stmt->fetch(
                            PDO::FETCH_ASSOC
                        );

                    if (!$customer) {

                        throw new RuntimeException(
                            'Customer not found.'
                        );
                    }

                    if (
                        $customer['status']
                        === $newStatus
                    ) {

                        throw new RuntimeException(
                            'Customer account is already ' .
                            $newStatus .
                            '.'
                        );
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | UPDATE
                    |--------------------------------------------------------------------------
                    */

                    $stmt = $pdo->prepare("
                        UPDATE users
                        SET status = ?
                        WHERE id = ?
                        LIMIT 1
                    ");

                    $stmt->execute([
                        $newStatus,
                        $userId
                    ]);

                    $_SESSION['admin_customers_success'] =
                        $customer['full_name'] .
                        ' account changed to ' .
                        ucfirst($newStatus) .
                        '.';

                    redirect(
                        BASE_URL .
                        'admin-customers.php'
                    );

                } catch (RuntimeException $e) {

                    $error =
                        $e->getMessage();

                } catch (Throwable $e) {

                    error_log(
                        'Admin user status error: ' .
                        $e->getMessage()
                    );

                    $error =
                        'Unable to update customer status.';
                }
            }

        }


        elseif ($action === 'add_travel_document') {
            $uid = (int)($_POST['user_id'] ?? 0);

            try {
                if ($uid <= 0) {
                    throw new RuntimeException('Invalid customer.');
                }

                $documentType = trim((string)($_POST['document_type'] ?? ''));
                $documentCategory = adminTravelDocumentCategoryForType($documentType);
                if ($documentCategory === null) {
                    throw new RuntimeException('Please select a valid document type.');
                }

                $documentNumber = trim((string)($_POST['document_number'] ?? ''));
                $issuingCountry = trim((string)($_POST['issuing_country'] ?? ''));
                $issueRaw = trim((string)($_POST['document_issue_date'] ?? ''));
                $expiryRaw = trim((string)($_POST['document_expiry_date'] ?? ''));
                $notes = trim((string)($_POST['document_notes'] ?? ''));

                $issueDate = adminProfileDateOrNull($issueRaw);
                $expiryDate = adminProfileDateOrNull($expiryRaw);

                if ($issueRaw !== '' && $issueDate === null) {
                    throw new RuntimeException('Please enter a valid issue date.');
                }
                if ($expiryRaw !== '' && $expiryDate === null) {
                    throw new RuntimeException('Please enter a valid expiry date.');
                }
                if ($issueDate && $expiryDate && $expiryDate < $issueDate) {
                    throw new RuntimeException('Expiry date cannot be before issue date.');
                }

                $upload = adminSaveTravellerDocumentUpload($_FILES['document_file'] ?? [], $uid);

                $stmt = $pdo->prepare("
                    INSERT INTO user_travel_documents
                    (user_id, document_category, document_type, document_number,
                     issuing_country, issue_date, expiry_date, file_path,
                     original_name, mime_type, file_size, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $uid,
                    $documentCategory,
                    $documentType,
                    $documentNumber !== '' ? $documentNumber : null,
                    $issuingCountry !== '' ? $issuingCountry : null,
                    $issueDate,
                    $expiryDate,
                    $upload['path'],
                    $upload['original_name'],
                    $upload['mime_type'],
                    $upload['file_size'],
                    $notes !== '' ? $notes : null
                ]);

                $_SESSION['admin_customers_success'] = $documentType . ' uploaded successfully.';
                redirect(BASE_URL . 'admin-customers.php?profile_id=' . $uid . '#identity-documents');

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Admin traveller document upload error: ' . $e->getMessage());
                $error = 'Unable to upload the customer document.';
            }
        }

        elseif ($action === 'delete_travel_document') {
            $uid = (int)($_POST['user_id'] ?? 0);

            try {
                $documentId = (int)($_POST['document_id'] ?? 0);
                if ($uid <= 0 || $documentId <= 0) {
                    throw new RuntimeException('Invalid document.');
                }

                $stmt = $pdo->prepare("
                    SELECT file_path, document_type
                    FROM user_travel_documents
                    WHERE id = ? AND user_id = ?
                    LIMIT 1
                ");
                $stmt->execute([$documentId, $uid]);
                $document = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$document) {
                    throw new RuntimeException('Document was not found.');
                }

                $pdo->prepare("DELETE FROM user_travel_documents WHERE id = ? AND user_id = ? LIMIT 1")
                    ->execute([$documentId, $uid]);

                adminDeleteTravellerDocumentFile((string)$document['file_path'], $uid);

                $_SESSION['admin_customers_success'] = $document['document_type'] . ' deleted successfully.';
                redirect(BASE_URL . 'admin-customers.php?profile_id=' . $uid . '#identity-documents');

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Admin traveller document delete error: ' . $e->getMessage());
                $error = 'Unable to delete the customer document.';
            }
        }

        elseif ($action === 'update_travel_profile') {
            $uid=(int)($_POST['user_id']??0);
            try{
                if($uid<=0)throw new RuntimeException('Invalid customer.');
                $dobRaw=trim((string)($_POST['date_of_birth']??''));$annRaw=trim((string)($_POST['anniversary_date']??''));
                $dob=adminProfileDateOrNull($dobRaw);$ann=adminProfileDateOrNull($annRaw);
                if($dobRaw!==''&&$dob===null)throw new RuntimeException('Invalid date of birth.');
                if($annRaw!==''&&$ann===null)throw new RuntimeException('Invalid anniversary date.');
                if (!$customerLocationReady) throw new RuntimeException('Please run the V24.31 customer location SQL migration before saving an updated address.');
                $country = adminCustomerClip(trim((string)($_POST['address_country'] ?? '')), 100);
                $state = adminCustomerClip(trim((string)($_POST['address_state'] ?? '')), 100);
                $district = adminCustomerClip(trim((string)($_POST['address_district'] ?? '')), 100);
                $city = adminCustomerClip(trim((string)($_POST['address_city'] ?? '')), 120);
                $pincode = strtoupper(trim((string)($_POST['address_pincode'] ?? '')));
                $addressLine = adminCustomerClip(trim((string)($_POST['address_line'] ?? '')), 255);
                if (strlen($pincode) > 20 || ($pincode !== '' && !preg_match('/^[A-Z0-9 -]{3,20}$/', $pincode)))
                    throw new RuntimeException('Please enter a valid postal/PIN code.');
                if (strcasecmp($country, 'India') === 0 && $pincode !== '' && !preg_match('/^[0-9]{6}$/', $pincode))
                    throw new RuntimeException('Indian PIN code must contain exactly six digits.');
                // Legacy city_state is retained, for existing screens which still use that field.
                $legacyCityState = trim(implode(', ', array_filter([$city, $state], static fn($v) => $v !== '')));
                if ($legacyCityState === '') $legacyCityState = trim((string)($_POST['city_state'] ?? ''));
                $s=$pdo->prepare("INSERT INTO user_travel_profiles(user_id,preferred_language,city_state,lead_source,date_of_birth,anniversary_date,spouse_partner_name,occupation,preferred_destination_type,travel_style,preferred_hotel_category,relationship_notes,birthday_wishes,anniversary_wishes,address_country,address_state,address_district,address_city,address_pincode,address_line)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE preferred_language=VALUES(preferred_language),city_state=VALUES(city_state),lead_source=VALUES(lead_source),date_of_birth=VALUES(date_of_birth),anniversary_date=VALUES(anniversary_date),spouse_partner_name=VALUES(spouse_partner_name),occupation=VALUES(occupation),preferred_destination_type=VALUES(preferred_destination_type),travel_style=VALUES(travel_style),preferred_hotel_category=VALUES(preferred_hotel_category),relationship_notes=VALUES(relationship_notes),birthday_wishes=VALUES(birthday_wishes),anniversary_wishes=VALUES(anniversary_wishes),address_country=VALUES(address_country),address_state=VALUES(address_state),address_district=VALUES(address_district),address_city=VALUES(address_city),address_pincode=VALUES(address_pincode),address_line=VALUES(address_line)");
                $s->execute([$uid,trim((string)($_POST['preferred_language']??''))?:null,$legacyCityState?:null,trim((string)($_POST['lead_source']??''))?:null,$dob,$ann,trim((string)($_POST['spouse_partner_name']??''))?:null,trim((string)($_POST['occupation']??''))?:null,trim((string)($_POST['preferred_destination_type']??''))?:null,trim((string)($_POST['travel_style']??''))?:null,trim((string)($_POST['preferred_hotel_category']??''))?:null,trim((string)($_POST['relationship_notes']??''))?:null,!empty($_POST['birthday_wishes'])?1:0,!empty($_POST['anniversary_wishes'])?1:0,$country?:null,$state?:null,$district?:null,$city?:null,$pincode?:null,$addressLine?:null]);
                $_SESSION['admin_customers_success']='Customer travel profile updated.';redirect(BASE_URL.'admin-customers.php?profile_id='.$uid);
            }catch(RuntimeException $e){$error=$e->getMessage();}catch(Throwable $e){error_log('Admin travel update: '.$e->getMessage());$error='Unable to update customer travel profile.';}
        }

        elseif ($action === 'add_family_member') {
            $uid=(int)($_POST['user_id']??0);
            try{
                $first=trim((string)($_POST['family_first_name']??''));
                $last=trim((string)($_POST['family_last_name']??''));
                $rel=trim((string)($_POST['family_relationship']??''));
                $dobRaw=trim((string)($_POST['family_date_of_birth']??''));
                $dob=adminProfileDateOrNull($dobRaw);
                $mob=trim((string)($_POST['family_mobile']??''));
                $mail=strtolower(trim((string)($_POST['family_email']??'')));
                $notes=trim((string)($_POST['family_notes']??''));
                $allowed=['Spouse','Partner','Child','Parent','Sibling','Grandparent','Grandchild','Relative','Friend','Other'];

                if($uid<=0 || $first==='' || !in_array($rel,$allowed,true))
                    throw new RuntimeException('Customer, first name and relationship are required.');

                if($dobRaw!=='' && $dob===null)
                    throw new RuntimeException('Please enter a valid date of birth.');

                if($mail!=='' && !filter_var($mail,FILTER_VALIDATE_EMAIL))
                    throw new RuntimeException('Please enter a valid email address or leave email blank.');

                if($mob!=='' && !preg_match('/^[0-9+\-\s()]{7,30}$/',$mob))
                    throw new RuntimeException('Please enter a valid mobile number or leave mobile blank.');

                $existing=adminFamilyFindCustomer($pdo,$uid,$mail,$mob);

                if($existing){
                    $linkedId=(int)$existing['id'];
                    if(adminFamilyLinkExists($pdo,$uid,$linkedId))
                        throw new RuntimeException('This user is already linked as a family member.');

                    $stmt=$pdo->prepare("INSERT INTO user_family_links(user_id,linked_user_id,relationship,relationship_notes) VALUES(?,?,?,?)");
                    $stmt->execute([$uid,$linkedId,$rel,$notes!==''?$notes:null]);

                    $_SESSION['admin_customers_success']='Existing customer found and linked to this family.';
                    redirect(BASE_URL.'admin-customers.php?profile_id='.$uid);
                }

                $ownerStmt=$pdo->prepare("SELECT country FROM users WHERE id=? LIMIT 1");
                $ownerStmt->execute([$uid]);
                $ownerCountry=(string)($ownerStmt->fetchColumn()?:'India');

                $newId=adminFamilyCreateCustomer($pdo,$uid,$first,$last,$mail,$mob,$ownerCountry);

                $stmt=$pdo->prepare("INSERT INTO user_family_links(user_id,linked_user_id,relationship,relationship_notes) VALUES(?,?,?,?)");
                $stmt->execute([$uid,$newId,$rel,$notes!==''?$notes:null]);

                $_SESSION['admin_customers_success']='Family member added, customer record created, and family link created.';
                redirect(BASE_URL.'admin-customers.php?profile_id='.$uid);

            }catch(RuntimeException $e){
                $error=$e->getMessage();
            }catch(Throwable $e){
                error_log('Admin family add: '.$e->getMessage());
                $error='Unable to add family member.';
            }
        }

        elseif ($action === 'link_existing_customer') {
            $uid=(int)($_POST['user_id']??0);
            $linked=(int)($_POST['linked_user_id']??0);
            $rel=trim((string)($_POST['link_relationship']??''));
            $notes=trim((string)($_POST['link_notes']??''));
            try{
                $allowed=['Spouse','Partner','Child','Parent','Sibling','Grandparent','Grandchild','Relative','Friend','Other'];

                if($uid<=0 || $linked<=0 || $uid===$linked || !in_array($rel,$allowed,true))
                    throw new RuntimeException('Please select a valid customer and relationship.');

                $activeLinkedCustomer=$pdo->prepare("SELECT id FROM users WHERE id=? AND status='active' LIMIT 1");
                $activeLinkedCustomer->execute([$linked]);
                if (!$activeLinkedCustomer->fetchColumn()) throw new RuntimeException('Please select an active existing customer.');
                if(adminFamilyLinkExists($pdo,$uid,$linked))
                    throw new RuntimeException('This user is already linked as a family member.');

                $stmt=$pdo->prepare("INSERT INTO user_family_links(user_id,linked_user_id,relationship,relationship_notes) VALUES(?,?,?,?)");
                $stmt->execute([$uid,$linked,$rel,$notes!==''?$notes:null]);

                $_SESSION['admin_customers_success']='Customer linked to family.';
                redirect(BASE_URL.'admin-customers.php?profile_id='.$uid);

            }catch(RuntimeException $e){
                $error=$e->getMessage();
            }catch(Throwable $e){
                error_log('Admin family link: '.$e->getMessage());
                $error='Unable to link customer.';
            }
        }

        elseif (in_array($action,['remove_family_member','remove_family_link'],true)) {
            $uid=(int)($_POST['user_id']??0);
            if($action==='remove_family_member')$pdo->prepare("DELETE FROM user_family_members WHERE id=? AND owner_user_id=?")->execute([(int)($_POST['family_id']??0),$uid]);
            else $pdo->prepare("DELETE FROM user_family_links WHERE id=? AND (user_id=? OR linked_user_id=?)")->execute([(int)($_POST['link_id']??0),$uid,$uid]);
            $_SESSION['admin_customers_success']='Family record removed.';redirect(BASE_URL.'admin-customers.php?profile_id='.$uid);
        }
    }
}

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

$search =
    trim(
        (string)($_GET['q'] ?? '')
    );

$status =
    strtolower(
        trim(
            (string)(
                $_GET['status']
                ?? ''
            )
        )
    );

$verified =
    trim(
        (string)(
            $_GET['verified']
            ?? ''
        )
    );

$allowedStatuses = [
    'active',
    'inactive',
    'blocked'
];

if (
    $status !== '' &&
    !in_array(
        $status,
        $allowedStatuses,
        true
    )
) {
    $status = '';
}

if (
    !in_array(
        $verified,
        ['', '1', '0'],
        true
    )
) {
    $verified = '';
}

/*
|--------------------------------------------------------------------------
| CUSTOMER STATISTICS
|--------------------------------------------------------------------------
*/

$stats = [

    'total' => 0,

    'active' => 0,

    'blocked' => 0,

    'verified' => 0,

    'new_this_month' => 0
];

try {

    $stmt = $pdo->query("
        SELECT

            COUNT(*) AS total,

            SUM(
                status = 'active'
            ) AS active,

            SUM(
                status = 'blocked'
            ) AS blocked,

            SUM(
                email_verified = 1
            ) AS verified,

            SUM(
                YEAR(created_at)
                    = YEAR(CURRENT_DATE())
                AND
                MONTH(created_at)
                    = MONTH(CURRENT_DATE())
            ) AS new_this_month

        FROM users
    ");

    $row =
        $stmt->fetch(
            PDO::FETCH_ASSOC
        );

    if ($row) {

        $stats['total'] =
            (int)($row['total'] ?? 0);

        $stats['active'] =
            (int)($row['active'] ?? 0);

        $stats['blocked'] =
            (int)($row['blocked'] ?? 0);

        $stats['verified'] =
            (int)($row['verified'] ?? 0);

        $stats['new_this_month'] =
            (int)(
                $row['new_this_month']
                ?? 0
            );
    }

} catch (Throwable $e) {

    error_log(
        'Admin users stats error: ' .
        $e->getMessage()
    );
}

/*
|--------------------------------------------------------------------------
| FILTER QUERY
|--------------------------------------------------------------------------
*/

$where = [];
$params = [];

if ($search !== '') {

    $where[] = "
        (
            u.full_name LIKE ?
            OR u.email LIKE ?
            OR u.mobile LIKE ?
            OR u.country LIKE ?
        )
    ";

    $term =
        '%' . $search . '%';

    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

if ($status !== '') {

    $where[] =
        "u.status = ?";

    $params[] =
        $status;
}

if ($verified !== '') {

    $where[] =
        "u.email_verified = ?";

    $params[] =
        (int)$verified;
}

$whereSql = '';

if ($where) {

    $whereSql =
        ' WHERE ' .
        implode(
            ' AND ',
            $where
        );
}

/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/

$perPage = 12;

$page =
    max(
        1,
        (int)(
            $_GET['page']
            ?? 1
        )
    );

$totalRows = 0;

try {

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM users u
        {$whereSql}
    ");

    $stmt->execute($params);

    $totalRows =
        (int)$stmt->fetchColumn();

} catch (Throwable $e) {

    error_log(
        'Admin users count error: ' .
        $e->getMessage()
    );
}

$totalPages =
    max(
        1,
        (int)ceil(
            $totalRows /
            $perPage
        )
    );

if ($page > $totalPages) {
    $page = $totalPages;
}

$offset =
    ($page - 1)
    * $perPage;

/*
|--------------------------------------------------------------------------
| FETCH USERS
|--------------------------------------------------------------------------
*/

$users = [];

try {

    $sql = "
        SELECT

            u.id,
            u.full_name,
            u.email,
            u.mobile,
            u.profile_image,
            u.country,
            u.email_verified,
            u.status,
            u.last_login,
            u.created_at,
            u.updated_at,

            COUNT(b.id)
                AS total_bookings,

            COALESCE(
                SUM(b.total_amount),
                0
            ) AS total_booking_value,

            COALESCE(
                SUM(b.paid_amount),
                0
            ) AS total_paid,

            MAX(b.created_at)
                AS last_booking_date,

            MAX(b.travel_date)
                AS latest_travel_date,

            SUM(
                b.booking_status
                    = 'pending'
            ) AS pending_bookings,

            SUM(
                b.booking_status
                    = 'confirmed'
            ) AS confirmed_bookings,

            SUM(
                b.booking_status
                    = 'completed'
            ) AS completed_bookings

        FROM users u

        LEFT JOIN bookings b
            ON b.user_id = u.id

        {$whereSql}

        GROUP BY
            u.id,
            u.full_name,
            u.email,
            u.mobile,
            u.profile_image,
            u.country,
            u.email_verified,
            u.status,
            u.last_login,
            u.created_at,
            u.updated_at

        ORDER BY
            u.created_at DESC,
            u.id DESC

        LIMIT {$perPage}
        OFFSET {$offset}
    ";

    $stmt =
        $pdo->prepare($sql);

    $stmt->execute($params);

    $users =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );

} catch (Throwable $e) {

    error_log(
        'Admin users fetch error: ' .
        $e->getMessage()
    );

    $error =
        'Unable to load customers.';
}


$profileId=max(0,(int)($_GET['profile_id']??0));$profileCustomer=null;
$profileTravel=['address_country'=>'','address_state'=>'','address_district'=>'','address_city'=>'','address_pincode'=>'','address_line'=>'','preferred_language'=>'English','city_state'=>'','lead_source'=>'','date_of_birth'=>'','anniversary_date'=>'','spouse_partner_name'=>'','occupation'=>'','preferred_destination_type'=>'','travel_style'=>'','preferred_hotel_category'=>'','relationship_notes'=>'','birthday_wishes'=>1,'anniversary_wishes'=>1];
$profileFamily=[];$profileLinks=[];$profileAvailable=[];$familySearchTerm='';

if($profileId>0){
try{
    $s=$pdo->prepare("SELECT id,full_name,email,mobile,country,email_verified,status,created_at,last_login FROM users WHERE id=? LIMIT 1");
    $s->execute([$profileId]);
    $profileCustomer=$s->fetch(PDO::FETCH_ASSOC)?:null;

    if($profileCustomer){
        $s=$pdo->prepare("SELECT * FROM user_travel_profiles WHERE user_id=? LIMIT 1");
        $s->execute([$profileId]);
        if($r=$s->fetch(PDO::FETCH_ASSOC)) $profileTravel=array_merge($profileTravel,$r);

        $s=$pdo->prepare("SELECT * FROM user_family_members WHERE owner_user_id=? AND status='active' ORDER BY id DESC");
        $s->execute([$profileId]);
        $profileFamily=$s->fetchAll(PDO::FETCH_ASSOC);

        $s=$pdo->prepare("
            SELECT l.id AS link_id,l.user_id AS link_owner_id,l.linked_user_id,
                   l.relationship,l.relationship_notes,
                   u.id,u.full_name,u.email,u.mobile
            FROM user_family_links l
            JOIN users u ON u.id = CASE WHEN l.user_id=? THEN l.linked_user_id ELSE l.user_id END
            WHERE l.user_id=? OR l.linked_user_id=?
            ORDER BY l.id DESC
        ");
        $s->execute([$profileId,$profileId,$profileId]);
        $profileLinks=$s->fetchAll(PDO::FETCH_ASSOC);

        foreach($profileLinks as &$familyLink){
            if((int)$familyLink['link_owner_id']!==$profileId){
                $familyLink['relationship']=adminFamilyReverseRelationship((string)$familyLink['relationship']);
            }
        }
        unset($familyLink);

        // Search the entire eligible database, not only the first 250 customers.
        $familySearchTerm = trim((string)($_GET['family_search'] ?? ''));
        if ($familySearchTerm !== '') {
            $familySearchTerm = adminCustomerClip($familySearchTerm, 80);
            $searchLike = '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $familySearchTerm) . '%';
            $s=$pdo->prepare("
                SELECT id,full_name,email,mobile
                FROM users
                WHERE id<>?
                  AND status='active'
                  AND id NOT IN(
                      SELECT linked_user_id FROM user_family_links WHERE user_id=?
                      UNION
                      SELECT user_id FROM user_family_links WHERE linked_user_id=?
                  )
                  AND (full_name LIKE ? ESCAPE '!' OR email LIKE ? ESCAPE '!'
                       OR mobile LIKE ? ESCAPE '!' OR CAST(id AS CHAR) = ?)
                ORDER BY full_name, id
                LIMIT 30
            ");
            $s->execute([$profileId,$profileId,$profileId,$searchLike,$searchLike,$searchLike,$familySearchTerm]);
            $profileAvailable=$s->fetchAll(PDO::FETCH_ASSOC);
        }
    }
}catch(Throwable $e){
    error_log('Admin profile load: '.$e->getMessage());
    $error='Unable to load customer family profile.';
}
}

$profileDocuments = [];
if ($profileCustomer) {
    try {
        $stmt = $pdo->prepare("
            SELECT *
            FROM user_travel_documents
            WHERE user_id = ?
            ORDER BY
                CASE WHEN document_category = 'identity' THEN 0 ELSE 1 END,
                document_type ASC,
                created_at DESC
        ");
        $stmt->execute([$profileId]);
        $profileDocuments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log('Admin customer documents load error: ' . $e->getMessage());
    }
}
$customerDocSummary = [];
$customerDocExpiryWarnings = 0;
if ($profileCustomer) {
    // The query above orders newer uploads first within a document type.
    foreach ($profileDocuments as $d) {
        $type = (string)($d['document_type'] ?? 'Document');
        if (isset($customerDocSummary[$type])) continue;
        $expiry = (string)($d['expiry_date'] ?? '');
        $status = 'Expiry not recorded'; $level = 'neutral';
        if ($expiry !== '' && $expiry !== '0000-00-00') {
            $daysLeft = (int)floor((strtotime($expiry . ' 00:00:00') - strtotime(date('Y-m-d') . ' 00:00:00')) / 86400);
            if ($daysLeft < 0) { $status = 'Expired'; $level = 'danger'; $customerDocExpiryWarnings++; }
            elseif ($daysLeft <= 90) { $status = 'Expires in ' . $daysLeft . ' day(s)'; $level = 'warning'; $customerDocExpiryWarnings++; }
            else { $status = 'Expiry recorded'; $level = 'success'; }
        }
        $customerDocSummary[$type] = ['uploaded'=>(string)($d['created_at'] ?? ''), 'issue'=>(string)($d['issue_date'] ?? ''), 'expiry'=>$expiry, 'status'=>$status, 'level'=>$level];
    }
}
$customerLocationStats = ['country'=>[],'state'=>[],'district'=>[],'pincode'=>[]];
if (!$profileCustomer && $customerLocationReady) {
    try {
        $countryStats=$pdo->query("SELECT COALESCE(NULLIF(TRIM(p.address_country),''),NULLIF(TRIM(u.country),'')) AS label, COUNT(*) AS total FROM users u LEFT JOIN user_travel_profiles p ON p.user_id=u.id WHERE COALESCE(NULLIF(TRIM(p.address_country),''),NULLIF(TRIM(u.country),'')) IS NOT NULL GROUP BY label ORDER BY total DESC, label ASC LIMIT 8");
        $customerLocationStats['country']=$countryStats->fetchAll(PDO::FETCH_ASSOC);
        foreach (['state'=>'address_state','district'=>'address_district','pincode'=>'address_pincode'] as $key=>$column) {
            $q=$pdo->query("SELECT TRIM($column) AS label, COUNT(*) AS total FROM user_travel_profiles WHERE $column IS NOT NULL AND TRIM($column)<>'' GROUP BY TRIM($column) ORDER BY total DESC, label ASC LIMIT 8");
            $customerLocationStats[$key]=$q->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (Throwable $e) { error_log('Customer location summary: '.$e->getMessage()); }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
Customer Management | TRAVSCOPE Admin
</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>

:root{

    --navy:#07192d;
    --navy2:#0c2947;

    --blue:#0b74ff;
    --blue2:#075fcf;
    --cyan:#00b8ff;

    --green:#07885f;
    --red:#d94355;
    --orange:#df8617;

    --bg:#f4f7fb;
    --white:#ffffff;

    --text:#172235;
    --muted:#7e8a9b;

    --border:#e1e8ef;

    --shadow:
        0 14px 40px
        rgba(7,25,45,.07);
}

*{
    box-sizing:border-box;
    margin:0;
    padding:0;
}

body{
    background:var(--bg);

    color:var(--text);

    font-family:
        'DM Sans',
        sans-serif;
}

a{
    color:inherit;
    text-decoration:none;
}

button,
input,
select{
    font:inherit;
}

/*
|--------------------------------------------------------------------------
| HEADER
|--------------------------------------------------------------------------
*/

.header{

    height:70px;

    padding:0 28px;

    position:sticky;

    top:0;

    z-index:1000;

    display:flex;

    align-items:center;

    justify-content:
        space-between;

    background:white;

    border-bottom:
        1px solid
        var(--border);
}

.logo{

    display:flex;

    align-items:center;

    gap:9px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:18px;

    font-weight:800;
}

.logo-icon{

    width:38px;
    height:38px;

    border-radius:11px;

    display:grid;

    place-items:center;

    color:white;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--cyan)
        );
}

.logo span{
    color:var(--blue);
}

.admin{

    display:flex;

    align-items:center;

    gap:9px;
}

.admin-avatar{

    width:38px;
    height:38px;

    border-radius:10px;

    display:grid;

    place-items:center;

    background:#edf5ff;

    color:var(--blue);

    font-weight:800;
}

.admin strong{

    display:block;

    font-size:13px;
}

.admin small{

    display:block;

    margin-top:2px;

    color:#929dab;

    font-size:11px;
}

/*
|--------------------------------------------------------------------------
| LAYOUT
|--------------------------------------------------------------------------
*/

.layout{

    min-height:
        calc(
            100vh - 70px
        );

    display:grid;

    grid-template-columns:
        230px
        minmax(0,1fr);
}

/*
|--------------------------------------------------------------------------
| SIDEBAR
|--------------------------------------------------------------------------
*/

.sidebar{

    padding:
        20px 13px;

    background:
        var(--navy);

    color:white;
}

.menu-title{

    padding:
        0 11px;

    margin:
        13px 0 7px;

    color:#71869c;

    font-size:11px;

    font-weight:800;

    text-transform:
        uppercase;

    letter-spacing:1px;
}

.sidebar a{

    min-height:43px;

    margin-bottom:4px;

    padding:
        0 12px;

    border-radius:9px;

    display:flex;

    align-items:center;

    gap:10px;

    color:#b6c5d4;

    font-size:12px;

    font-weight:700;

    transition:.2s;
}

.sidebar a:hover,
.sidebar a.active{

    color:white;

    background:
        rgba(
            255,
            255,
            255,
            .1
        );
}

.sidebar a.active{

    background:
        linear-gradient(
            135deg,
            var(--blue),
            #0866dd
        );
}

.sidebar i{

    width:18px;

    text-align:center;
}

/*
|--------------------------------------------------------------------------
| MAIN
|--------------------------------------------------------------------------
*/

.main{

    min-width:0;

    padding:27px;
}

.page-head{

    margin-bottom:21px;

    display:flex;

    align-items:flex-end;

    justify-content:
        space-between;

    gap:20px;
}

.page-head h1{

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:25px;
}

.page-head p{

    margin-top:5px;

    color:var(--muted);

    font-size:12px;
}

.refresh-btn{

    min-height:40px;

    padding:
        0 13px;

    border:
        1px solid
        var(--border);

    border-radius:8px;

    display:inline-flex;

    align-items:center;

    gap:6px;

    background:white;

    color:#5f6d80;

    font-size:11px;

    font-weight:800;
}

/*
|--------------------------------------------------------------------------
| ALERT
|--------------------------------------------------------------------------
*/

.alert{

    margin-bottom:17px;

    padding:
        13px 15px;

    border-radius:10px;

    display:flex;

    align-items:center;

    gap:8px;

    font-size:12px;
}

.alert-success{

    border:
        1px solid
        #bce7d5;

    background:#eaf9f3;

    color:#08734f;
}

.alert-error{

    border:
        1px solid
        #f0c5cc;

    background:#fff0f2;

    color:#b43748;
}

/*
|--------------------------------------------------------------------------
| STATISTICS
|--------------------------------------------------------------------------
*/

.stats{

    margin-bottom:20px;

    display:grid;

    grid-template-columns:
        repeat(
            5,
            1fr
        );

    gap:12px;
}

.stat{

    padding:16px;

    border:
        1px solid
        var(--border);

    border-radius:13px;

    background:white;

    box-shadow:
        var(--shadow);
}

.stat-icon{

    width:36px;
    height:36px;

    border-radius:10px;

    display:grid;

    place-items:center;

    background:#edf5ff;

    color:var(--blue);
}

.stat strong{

    display:block;

    margin-top:12px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:22px;
}

.stat span{

    display:block;

    margin-top:2px;

    color:#8d98a7;

    font-size:11px;
}

/*
|--------------------------------------------------------------------------
| CARD
|--------------------------------------------------------------------------
*/

.card{

    margin-bottom:20px;

    border:
        1px solid
        var(--border);

    border-radius:15px;

    overflow:hidden;

    background:white;

    box-shadow:
        var(--shadow);
}

.card-head{

    min-height:62px;

    padding:
        0 19px;

    border-bottom:
        1px solid
        var(--border);

    display:flex;

    align-items:center;

    justify-content:
        space-between;

    gap:15px;
}

.card-head h2{

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:13px;
}

.card-head p{

    margin-top:3px;

    color:#929dab;

    font-size:11px;
}

.card-body{
    padding:19px;
}

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

.filters{

    display:grid;

    grid-template-columns:
        2fr
        1fr
        1fr
        auto;

    gap:8px;
}

.control{

    width:100%;

    height:41px;

    padding:
        0 11px;

    border:
        1px solid
        #dfe6ed;

    border-radius:8px;

    outline:none;

    background:white;

    color:#39475a;

    font-size:11px;
}

.control:focus{

    border-color:#8abaff;

    box-shadow:
        0 0 0 3px
        rgba(
            11,
            116,
            255,
            .06
        );
}

.filter-btn{

    height:41px;

    padding:
        0 16px;

    border:0;

    border-radius:8px;

    cursor:pointer;

    background:
        var(--navy);

    color:white;

    font-size:11px;

    font-weight:800;
}

.clear-filter{

    margin-top:10px;

    display:inline-flex;

    align-items:center;

    gap:5px;

    color:var(--blue);

    font-size:11px;

    font-weight:700;
}

/*
|--------------------------------------------------------------------------
| CUSTOMER MANAGEMENT TABLE
|--------------------------------------------------------------------------
*/

.table-wrap{
    width:100%;
    overflow-x:auto;
}

.customer-table{
    width:100%;
    min-width:1200px;
    border-collapse:collapse;
}

.customer-table thead{
    background:#f8fafc;
}

.customer-table th{
    padding:11px 12px;
    border-bottom:1px solid var(--border);
    color:#8793a3;
    font-size:11px;
    font-weight:800;
    text-align:left;
    text-transform:uppercase;
    letter-spacing:.45px;
    white-space:nowrap;
}

.customer-table td{
    padding:12px;
    border-bottom:1px solid #edf1f5;
    color:#465469;
    font-size:11px;
    vertical-align:middle;
}

.customer-table tbody tr:hover{
    background:#fbfdff;
}

.customer-person-row{
    display:flex;
    align-items:center;
    gap:9px;
    min-width:180px;
}

.customer-avatar{
    width:34px;
    height:34px;
    flex:none;
    border-radius:9px;
    display:grid;
    place-items:center;
    background:#edf5ff;
    color:var(--blue);
    font-family:'Manrope',sans-serif;
    font-size:11px;
    font-weight:800;
}

.customer-name{
    max-width:170px;
    overflow:hidden;
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:12px;
    font-weight:800;
    text-overflow:ellipsis;
    white-space:nowrap;
}

.subtext{
    margin-top:3px;
    color:#929dab;
    font-size:11px;
    white-space:nowrap;
}

.badge{
    padding:5px 8px;
    border-radius:20px;
    display:inline-flex;
    align-items:center;
    gap:4px;
    font-size:11px;
    font-weight:800;
    text-transform:capitalize;
    white-space:nowrap;
}

.badge-success{background:#e8f8f1;color:var(--green);}
.badge-warning{background:#fff6e7;color:#bf7415;}
.badge-danger{background:#fff0f2;color:var(--red);}
.badge-blue{background:#edf5ff;color:var(--blue);}
.badge-muted{background:#f1f3f5;color:#758292;}

.money-main{
    color:var(--navy);
    font-size:12px;
    font-weight:800;
    white-space:nowrap;
}

.money-paid{
    margin-top:3px;
    color:var(--green);
    font-size:11px;
    white-space:nowrap;
}

.booking-counts{
    display:flex;
    gap:4px;
    margin-top:4px;
    flex-wrap:wrap;
}

.mini-status{
    padding:4px 6px;
    border-radius:6px;
    background:#f4f6f8;
    color:#69778a;
    font-size:11px;
    font-weight:700;
    white-space:nowrap;
}

.mini-status.pending{background:#fff6e7;color:#b76c11;}
.mini-status.confirmed{background:#eaf9f3;color:#08734f;}
.mini-status.completed{background:#edf5ff;color:#0b74ff;}

.table-actions{
    display:flex;
    align-items:center;
    gap:5px;
    flex-wrap:wrap;
    min-width:285px;
}

.table-actions form{
    margin:0;
}

.btn{
    min-height:31px;
    padding:0 8px;
    border:0;
    border-radius:6px;
    cursor:pointer;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:4px;
    font-size:11px;
    font-weight:800;
    white-space:nowrap;
}

.btn-details{background:#edf5ff;color:var(--blue);}
.btn-bookings{background:#f2f4f7;color:#637185;}
.btn-block{background:#fff0f2;color:var(--red);}
.btn-activate{background:#e8f8f1;color:var(--green);}

/*
|--------------------------------------------------------------------------
| EMPTY
|--------------------------------------------------------------------------
*/

.empty{

    padding:
        60px 20px;

    text-align:center;
}

.empty-icon{

    width:70px;
    height:70px;

    margin:
        0 auto 14px;

    border-radius:20px;

    display:grid;

    place-items:center;

    background:#edf5ff;

    color:var(--blue);

    font-size:25px;
}

.empty h3{

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:14px;
}

.empty p{

    margin-top:6px;

    color:#8b97a6;

    font-size:11px;
}

/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/

.pagination{

    margin-top:20px;

    display:flex;

    align-items:center;

    justify-content:center;

    gap:5px;

    flex-wrap:wrap;
}

.page-btn{

    min-width:35px;
    height:35px;

    padding:
        0 9px;

    border:
        1px solid
        var(--border);

    border-radius:7px;

    display:grid;

    place-items:center;

    background:white;

    color:#617084;

    font-size:11px;

    font-weight:800;
}

.page-btn:hover{

    border-color:#a9cdf9;

    color:var(--blue);
}

.page-btn.active{

    border-color:
        var(--blue);

    background:
        var(--blue);

    color:white;
}

/*
|--------------------------------------------------------------------------
| RESPONSIVE
|--------------------------------------------------------------------------
*/

@media(max-width:1150px){

    .stats{

        grid-template-columns:
            repeat(
                3,
                1fr
            );
    }
}

@media(max-width:950px){

    .layout{
        grid-template-columns:1fr;
    }

    .sidebar{
        display:none;
    }

    .main{
        padding:18px;
    }

}

@media(max-width:700px){

    .filters{
        grid-template-columns:1fr;
    }

    .stats{
        grid-template-columns:
            repeat(
                2,
                1fr
            );
    }
}

@media(max-width:550px){

    .header{
        padding:0 13px;
    }

    .admin > div:last-child{
        display:none;
    }

    .main{
        padding:13px;
    }

    .page-head{

        align-items:
            flex-start;

        flex-direction:
            column;
    }

}


.profile-manager{margin-bottom:20px;border:1px solid #cfe0f5;border-radius:15px;background:#fff;box-shadow:var(--shadow);overflow:hidden}.profile-manager-head{padding:18px 20px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;gap:15px;background:#fbfdff}.profile-manager-head h2{font-size:18px;color:var(--navy)}.profile-manager-head p{margin-top:4px;color:var(--muted);font-size:13px}.profile-manager-body{padding:18px}.overview-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}.overview-item{padding:11px;border:1px solid var(--border);border-radius:9px;background:#fafbfd}.overview-item span{display:block;font-size:11px;color:#929dab;font-weight:800;text-transform:uppercase}.overview-item strong{display:block;margin-top:4px;font-size:11px;color:#354358}.pm-section{margin-top:20px;padding-top:18px;border-top:1px solid var(--border)}.pm-section h3{font-size:15px;color:var(--navy)}.pm-section p{margin-top:4px;color:var(--muted);font-size:12px}.pm-form{margin-top:12px;display:grid;grid-template-columns:repeat(2,1fr);gap:11px}.pm-form .full{grid-column:1/-1}.pm-form label{display:block;margin-bottom:5px;font-size:12px;font-weight:800;color:#526075}.pm-control{width:100%;min-height:40px;padding:0 10px;border:1px solid #dfe6ed;border-radius:8px;font-size:13px}textarea.pm-control{min-height:85px;padding:10px}.pm-save{margin-top:12px;min-height:36px;padding:0 12px;border:0;border-radius:7px;background:var(--blue);color:white;font-size:12px;font-weight:800}.pm-family{margin-top:12px;display:grid;gap:8px}.pm-row{padding:10px;border:1px solid var(--border);border-radius:9px;background:#fbfcfe;display:flex;justify-content:space-between;gap:10px}.pm-row strong{font-size:13px;color:var(--navy)}.pm-row small{display:block;margin-top:3px;font-size:11px;color:#8793a3}.pm-remove{border:1px solid #f0c5cc;background:#fff0f2;color:var(--red);border-radius:6px;padding:6px 8px;font-size:11px;font-weight:800}.btn-profile{background:#e9f7f2;color:#08734f}@media(max-width:700px){.overview-grid,.pm-form{grid-template-columns:1fr}.pm-form .full{grid-column:auto}}


.pm-doc-stats{display:grid;grid-template-columns:repeat(2,1fr);gap:9px;margin-top:12px}
.pm-doc-stat{padding:11px;border:1px solid var(--border);border-radius:9px;background:#fafbfd}
.pm-doc-stat span{display:block;color:#7b8798;font-size:11px;font-weight:700}
.pm-doc-stat strong{display:block;margin-top:4px;color:var(--navy);font-size:17px}
.pm-doc-list{display:grid;gap:9px;margin-top:12px}
.pm-doc-row{padding:12px;border:1px solid var(--border);border-radius:9px;background:#fbfcfe;display:flex;justify-content:space-between;align-items:flex-start;gap:12px}
.pm-doc-row h4{font-size:13px;color:var(--navy)}
.pm-doc-row p{margin-top:5px;color:#667487;font-size:11px;line-height:1.5}
.pm-doc-badge{display:inline-flex;margin-top:5px;padding:4px 7px;border-radius:20px;background:#edf5ff;color:var(--blue);font-size:13px;font-weight:800}
.pm-doc-actions{display:flex;gap:6px;flex-wrap:wrap}
.pm-doc-btn{min-height:32px;padding:0 8px;border-radius:6px;border:1px solid var(--border);display:inline-flex;align-items:center;gap:4px;background:white;color:#536277;font-size:13px;font-weight:800}
.pm-doc-btn.view{background:#edf5ff;color:var(--blue)}
.pm-doc-btn.delete{background:#fff0f2;color:var(--red);border-color:#f0c5cc;cursor:pointer}
.pm-file-box{padding:10px;border:1px solid #dfe6ed;border-radius:8px;background:#fff}
.pm-file-box input{width:100%;font-size:12px}
.pm-file-note{margin-top:5px;color:#7b8798;font-size:13px;line-height:1.45}
@media(max-width:700px){.pm-doc-stats{grid-template-columns:1fr}.pm-doc-row{flex-direction:column}}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ============================================================
   TRAVSCOPE CUSTOMER PROFILE — PROFESSIONAL WORKSPACE UI
   Visual/navigation upgrade only. Existing functionality intact.
============================================================ */
body.profile-open .main{padding-top:18px}
body.profile-open .page-head{margin-bottom:14px}
body.profile-open .profile-manager{
    border:1px solid #dce5ef;
    border-radius:16px;
    box-shadow:0 12px 32px rgba(15,35,60,.08);
    overflow:visible;
}
body.profile-open .profile-manager-head{
    position:sticky;
    top:0;
    z-index:30;
    align-items:center;
    padding:15px 18px;
    background:rgba(255,255,255,.97);
    backdrop-filter:blur(12px);
    border-radius:16px 16px 0 0;
}
body.profile-open .profile-manager-head h2{font-size:19px;line-height:1.25}
body.profile-open .profile-manager-head p{font-size:12px}
body.profile-open .profile-manager-body{padding:14px 16px 18px}

.profile-workspace-nav{
    display:flex;
    align-items:center;
    gap:7px;
    padding:8px;
    margin:0 0 14px;
    border:1px solid #dfe7f0;
    border-radius:12px;
    background:#f7f9fc;
    overflow-x:auto;
    scrollbar-width:thin;
}
.profile-workspace-tab{
    appearance:none;
    border:1px solid transparent;
    background:transparent;
    color:#536176;
    min-height:38px;
    padding:0 13px;
    border-radius:9px;
    font:700 12px/1 'DM Sans',sans-serif;
    white-space:nowrap;
    cursor:pointer;
    transition:.18s ease;
}
.profile-workspace-tab i{margin-right:6px}
.profile-workspace-tab:hover{background:#fff;color:var(--navy)}
.profile-workspace-tab.active{
    background:#fff;
    color:var(--blue);
    border-color:#dce6f2;
    box-shadow:0 3px 10px rgba(18,48,82,.07);
}

body.profile-open .overview-grid{
    grid-template-columns:repeat(4,minmax(0,1fr));
    gap:8px;
}
body.profile-open .overview-item{
    min-height:66px;
    padding:10px 11px;
    border-radius:10px;
    background:#fbfcfe;
}
body.profile-open .overview-item span{font-size:10px;letter-spacing:.04em}
body.profile-open .overview-item strong{
    margin-top:5px;
    font-size:12px;
    line-height:1.35;
    overflow-wrap:anywhere;
}

body.profile-open .pm-section{
    display:none;
    margin-top:0;
    padding-top:2px;
    border-top:0;
    animation:profileFade .16s ease;
}
body.profile-open .pm-section.profile-section-active{display:block}
@keyframes profileFade{from{opacity:.55;transform:translateY(2px)}to{opacity:1;transform:none}}

body.profile-open .pm-section>h3{
    font-size:17px;
    line-height:1.25;
    margin:2px 0 0;
}
body.profile-open .pm-section>p{
    margin-top:4px;
    font-size:12px;
    line-height:1.45;
}
body.profile-open .pm-form{
    margin-top:11px;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:9px 11px;
}
body.profile-open .pm-form label{
    margin-bottom:4px;
    font-size:11px;
}
body.profile-open .pm-control{
    min-height:38px;
    padding:0 10px;
    border-radius:8px;
    font-size:12px;
}
body.profile-open textarea.pm-control{
    min-height:72px;
    padding:9px 10px;
}
body.profile-open .pm-save{
    min-height:36px;
    margin-top:10px;
    padding:0 13px;
    border-radius:8px;
    font-size:11px;
}
body.profile-open .pm-family{margin-top:10px}
body.profile-open .pm-row{padding:9px 11px}
body.profile-open .pm-row strong{font-size:12px}
body.profile-open .pm-row small{font-size:10px}

.profile-section-toolbar{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    padding-bottom:10px;
    margin-bottom:3px;
    border-bottom:1px solid #edf1f5;
}
.profile-section-toolbar .section-copy h3{font-size:17px;color:var(--navy)}
.profile-section-toolbar .section-copy p{margin-top:3px;font-size:12px;color:var(--muted)}
.profile-section-index{
    flex:0 0 auto;
    padding:5px 8px;
    border-radius:7px;
    background:#eef5ff;
    color:#1767c7;
    font-size:10px;
    font-weight:800;
    text-transform:uppercase;
    letter-spacing:.04em;
}

@media(max-width:1100px){
    body.profile-open .overview-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(max-width:760px){
    body.profile-open .profile-manager-body{padding:11px}
    body.profile-open .profile-manager-head{position:relative;padding:13px}
    body.profile-open .profile-manager-head h2{font-size:17px}
    .profile-workspace-nav{position:sticky;top:0;z-index:25;border-radius:10px}
    .profile-workspace-tab{min-height:36px;padding:0 11px;font-size:11px}
    body.profile-open .overview-grid{grid-template-columns:1fr 1fr}
    body.profile-open .pm-form{grid-template-columns:1fr}
    body.profile-open .pm-form .full{grid-column:auto}
}
@media(max-width:470px){
    body.profile-open .overview-grid{grid-template-columns:1fr}
}



/* ============================================================
   CUSTOMER LIST — COMPACT PROFESSIONAL SPACE MANAGEMENT
   Visual spacing only. Profile workspace and all PHP logic intact.
============================================================ */

/* Apply these rules only when a customer profile is NOT open. */
body:not(.profile-open) .main{
    padding:14px 16px 18px !important;
}

body:not(.profile-open) .page-head{
    margin-bottom:10px !important;
    gap:10px !important;
    align-items:center !important;
}

body:not(.profile-open) .page-head h1{
    font-size:24px !important;
    line-height:1.15 !important;
}

body:not(.profile-open) .page-head p{
    margin-top:3px !important;
    font-size:11px !important;
    line-height:1.35 !important;
}

body:not(.profile-open) .refresh-btn{
    min-height:34px !important;
    padding:0 10px !important;
    font-size:11px !important;
}

/* KPI cards: same information, much less vertical space */
body:not(.profile-open) .stats{
    gap:8px !important;
    margin-bottom:10px !important;
}

body:not(.profile-open) .stat{
    min-height:74px !important;
    padding:10px 12px !important;
    border-radius:9px !important;
}

body:not(.profile-open) .stat-icon{
    width:30px !important;
    height:30px !important;
    border-radius:8px !important;
    font-size:12px !important;
}

body:not(.profile-open) .stat strong{
    margin-top:5px !important;
    font-size:19px !important;
    line-height:1 !important;
}

body:not(.profile-open) .stat span{
    margin-top:2px !important;
    font-size:10px !important;
    line-height:1.2 !important;
}

/* General cards on list page */
body:not(.profile-open) .card{
    margin-bottom:10px !important;
    border-radius:10px !important;
}

body:not(.profile-open) .card-head{
    min-height:46px !important;
    padding:9px 13px !important;
}

body:not(.profile-open) .card-head h2{
    font-size:14px !important;
    line-height:1.2 !important;
}

body:not(.profile-open) .card-head p{
    margin-top:2px !important;
    font-size:10px !important;
}

body:not(.profile-open) .card-body{
    padding:10px 12px !important;
}

/* Find Customers: one compact management bar */
body:not(.profile-open) .filters{
    gap:7px !important;
    grid-template-columns:minmax(280px,2.2fr) minmax(150px,.85fr) minmax(150px,.85fr) auto !important;
}

body:not(.profile-open) .control{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    font-size:12px !important;
    border-radius:7px !important;
}

body:not(.profile-open) .filter-btn{
    height:36px !important;
    min-height:36px !important;
    padding:0 13px !important;
    font-size:11px !important;
}

body:not(.profile-open) .clear-filter{
    margin-top:6px !important;
    font-size:10px !important;
}

/* Registered Customers table becomes denser and easier to scan */
body:not(.profile-open) .table-wrap{
    border-radius:8px !important;
}

body:not(.profile-open) table{
    font-size:10px !important;
}

body:not(.profile-open) th{
    padding:7px 8px !important;
    font-size:9px !important;
    line-height:1.2 !important;
    white-space:nowrap !important;
}

body:not(.profile-open) td{
    padding:7px 8px !important;
    font-size:10px !important;
    line-height:1.25 !important;
    vertical-align:middle !important;
}

body:not(.profile-open) .customer-avatar{
    width:32px !important;
    height:32px !important;
    flex:0 0 32px !important;
    border-radius:8px !important;
    font-size:11px !important;
}

body:not(.profile-open) .customer-name{
    font-size:11px !important;
    line-height:1.2 !important;
}

body:not(.profile-open) .customer-email,
body:not(.profile-open) .small,
body:not(.profile-open) td small{
    font-size:9px !important;
    line-height:1.2 !important;
}

body:not(.profile-open) .badge,
body:not(.profile-open) .mini-status{
    min-height:21px !important;
    padding:0 6px !important;
    font-size:8px !important;
}

body:not(.profile-open) .btn{
    min-height:28px !important;
    padding:0 7px !important;
    font-size:9px !important;
    border-radius:6px !important;
}

body:not(.profile-open) .customer-actions{
    gap:4px !important;
    flex-wrap:nowrap !important;
}

body:not(.profile-open) .customer-actions form{
    margin:0 !important;
}

/* Pagination compact */
body:not(.profile-open) .pagination{
    margin-top:9px !important;
}

body:not(.profile-open) .page-btn{
    min-width:30px !important;
    height:30px !important;
    font-size:9px !important;
}

/* Make efficient use of wide laptop/desktop screens */
@media(min-width:1200px){
    body:not(.profile-open) .main{
        padding-left:14px !important;
        padding-right:14px !important;
    }

    body:not(.profile-open) .stats{
        grid-template-columns:repeat(5,minmax(0,1fr)) !important;
    }
}

/* Tablet */
@media(max-width:1050px){
    body:not(.profile-open) .stats{
        grid-template-columns:repeat(3,minmax(0,1fr)) !important;
    }

    body:not(.profile-open) .filters{
        grid-template-columns:1fr 1fr 1fr auto !important;
    }
}

/* Mobile stays readable rather than over-compressed */
@media(max-width:700px){
    body:not(.profile-open) .main{
        padding:10px 8px 16px !important;
    }

    body:not(.profile-open) .page-head{
        align-items:flex-start !important;
    }

    body:not(.profile-open) .page-head h1{
        font-size:21px !important;
    }

    body:not(.profile-open) .stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    body:not(.profile-open) .stat{
        min-height:68px !important;
    }

    body:not(.profile-open) .filters{
        grid-template-columns:1fr !important;
    }

    body:not(.profile-open) .control,
    body:not(.profile-open) .filter-btn{
        min-height:40px !important;
        height:40px !important;
        font-size:12px !important;
    }

    body:not(.profile-open) th,
    body:not(.profile-open) td{
        padding:7px 6px !important;
    }
}



/* ============================================================
   MANUAL CUSTOMER CREATION — PROFESSIONAL COLOR UI
============================================================ */

.customer-head-actions{
    display:flex;
    align-items:center;
    gap:7px;
}

.manual-customer-btn{
    min-height:34px;
    padding:0 12px;
    border:0;
    border-radius:8px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:7px;
    background:linear-gradient(135deg,#0b74ff,#4758f6);
    color:#fff;
    font-size:11px;
    font-weight:800;
    cursor:pointer;
    box-shadow:0 6px 15px rgba(11,116,255,.20);
    transition:.18s ease;
}

.manual-customer-btn:hover{
    transform:translateY(-1px);
    box-shadow:0 8px 20px rgba(11,116,255,.25);
}

.manual-customer-modal{
    position:fixed;
    inset:0;
    z-index:5000;
    display:none;
    align-items:center;
    justify-content:center;
    padding:18px;
}

.manual-customer-modal.open{
    display:flex;
}

.manual-customer-backdrop{
    position:absolute;
    inset:0;
    background:rgba(7,25,45,.55);
    backdrop-filter:blur(5px);
}

.manual-customer-dialog{
    position:relative;
    z-index:1;
    width:min(820px,100%);
    max-height:calc(100vh - 36px);
    overflow:auto;
    border:1px solid rgba(255,255,255,.9);
    border-radius:18px;
    background:#fff;
    box-shadow:0 30px 80px rgba(4,23,44,.24);
}

.manual-customer-head{
    min-height:72px;
    padding:14px 17px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:14px;
    border-bottom:1px solid #e7edf4;
    background:
        radial-gradient(circle at 85% 15%,rgba(11,116,255,.09),transparent 35%),
        linear-gradient(135deg,#fbfdff,#f4f8fd);
}

.manual-customer-title{
    display:flex;
    align-items:center;
    gap:11px;
}

.manual-customer-icon{
    width:43px;
    height:43px;
    flex:0 0 43px;
    display:grid;
    place-items:center;
    border-radius:12px;
    background:linear-gradient(135deg,#0b74ff,#6258ee);
    color:#fff;
    font-size:16px;
    box-shadow:0 8px 18px rgba(11,116,255,.18);
}

.manual-customer-title h2{
    margin:0;
    color:#11223a;
    font:800 18px/1.2 'Manrope',sans-serif;
}

.manual-customer-title p{
    margin:3px 0 0;
    color:#738095;
    font-size:11px;
}

.manual-customer-close{
    width:36px;
    height:36px;
    border:1px solid #dce5ee;
    border-radius:9px;
    display:grid;
    place-items:center;
    background:#fff;
    color:#67758a;
    cursor:pointer;
}

.manual-customer-form{
    padding:15px 17px 17px;
}

.manual-customer-grid{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:10px;
}

.manual-field{
    min-width:0;
    min-height:78px;
    padding:10px;
    border:1px solid transparent;
    border-radius:12px;
    display:grid;
    grid-template-columns:34px minmax(0,1fr);
    gap:9px;
    align-items:start;
}

.manual-field-icon{
    width:34px;
    height:34px;
    display:grid;
    place-items:center;
    border-radius:9px;
    font-size:13px;
}

.manual-field-content{
    min-width:0;
}

.manual-field label{
    display:block;
    margin-bottom:4px;
    color:#344257;
    font-size:10px;
    font-weight:800;
}

.manual-field input,
.manual-field select{
    width:100%;
    height:34px;
    padding:0 9px;
    border:1px solid rgba(114,132,154,.25);
    border-radius:7px;
    background:rgba(255,255,255,.88);
    color:#1d2b3f;
    font-size:11px;
    outline:none;
}

.manual-field input:focus,
.manual-field select:focus{
    border-color:#75aaff;
    box-shadow:0 0 0 3px rgba(11,116,255,.10);
    background:#fff;
}

/* Different professional pastel field groups */
.manual-field-blue{
    background:#f0f6ff;
    border-color:#d8e8ff;
}
.manual-field-blue .manual-field-icon{
    background:#dceaff;
    color:#1268d8;
}

.manual-field-green{
    background:#effbf6;
    border-color:#d6f1e6;
}
.manual-field-green .manual-field-icon{
    background:#d9f4e8;
    color:#087d59;
}

.manual-field-purple{
    background:#f6f2ff;
    border-color:#e7dcff;
}
.manual-field-purple .manual-field-icon{
    background:#e9ddff;
    color:#7350ce;
}

.manual-field-orange{
    background:#fff7ed;
    border-color:#fae5c9;
}
.manual-field-orange .manual-field-icon{
    background:#ffead0;
    color:#c36a08;
}

.manual-field-cyan{
    background:#effbff;
    border-color:#d5f0f9;
}
.manual-field-cyan .manual-field-icon{
    background:#d9f3fb;
    color:#0785a9;
}

.manual-field-rose{
    background:#fff2f5;
    border-color:#f6dce3;
}
.manual-field-rose .manual-field-icon{
    background:#f9dde5;
    color:#bd4863;
}

.manual-verified-card{
    margin-top:10px;
    padding:10px 12px;
    border:1px solid #f2e3b7;
    border-radius:11px;
    display:grid;
    grid-template-columns:36px minmax(0,1fr) auto;
    gap:10px;
    align-items:center;
    background:#fffbef;
    cursor:pointer;
}

.manual-verified-icon{
    width:36px;
    height:36px;
    display:grid;
    place-items:center;
    border-radius:9px;
    background:#fff1be;
    color:#a66b00;
}

.manual-verified-copy strong{
    display:block;
    color:#4c421f;
    font-size:11px;
}

.manual-verified-copy small{
    display:block;
    margin-top:2px;
    color:#85764b;
    font-size:9px;
    line-height:1.35;
}

.manual-switch input{
    position:absolute;
    opacity:0;
    pointer-events:none;
}

.manual-switch span{
    width:39px;
    height:22px;
    padding:3px;
    border-radius:999px;
    display:block;
    background:#ccd5df;
    transition:.18s;
}

.manual-switch span:after{
    content:"";
    width:16px;
    height:16px;
    display:block;
    border-radius:50%;
    background:#fff;
    box-shadow:0 2px 5px rgba(0,0,0,.15);
    transition:.18s;
}

.manual-switch input:checked + span{
    background:#12a675;
}

.manual-switch input:checked + span:after{
    transform:translateX(17px);
}

.manual-customer-footer{
    margin-top:12px;
    padding-top:12px;
    border-top:1px solid #edf1f5;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
}

.manual-customer-note{
    color:#748195;
    font-size:9px;
    line-height:1.4;
}

.manual-customer-note i{
    color:#0b74ff;
    margin-right:4px;
}

.manual-customer-actions{
    display:flex;
    align-items:center;
    gap:7px;
    flex:0 0 auto;
}

.manual-cancel-btn,
.manual-save-btn{
    min-height:36px;
    padding:0 13px;
    border-radius:8px;
    font-size:10px;
    font-weight:800;
    cursor:pointer;
}

.manual-cancel-btn{
    border:1px solid #dbe4ee;
    background:#fff;
    color:#59677b;
}

.manual-save-btn{
    border:0;
    background:linear-gradient(135deg,#087c5a,#10a875);
    color:#fff;
    box-shadow:0 5px 14px rgba(8,124,90,.18);
}

body.manual-customer-open{
    overflow:hidden;
}

@media(max-width:700px){
    .customer-head-actions{
        width:100%;
        justify-content:flex-end;
    }

    .manual-customer-grid{
        grid-template-columns:1fr;
    }

    .manual-customer-dialog{
        max-height:calc(100vh - 16px);
        border-radius:14px;
    }

    .manual-customer-modal{
        padding:8px;
    }

    .manual-customer-head{
        padding:12px;
    }

    .manual-customer-form{
        padding:11px;
    }

    .manual-customer-footer{
        align-items:stretch;
        flex-direction:column;
    }

    .manual-customer-actions{
        justify-content:flex-end;
    }
}



/* Registered Customers — Delete action */
.btn-delete-customer{
    border:1px solid #f1c8cf !important;
    background:#fff1f3 !important;
    color:#c22f47 !important;
}

.btn-delete-customer:hover{
    border-color:#eaa9b5 !important;
    background:#ffe5e9 !important;
    color:#a91f36 !important;
}

.customer-delete-form{
    margin:0 !important;
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.layout{
    display:block!important;
    grid-template-columns:none!important;
    min-height:100vh!important;
}
.main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
    padding:16px 18px 20px!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}

</style>


<style id="travscope-customer-requested-ui-only">
/* Requested: remove duplicate TRAVSCOPE ADMIN top header. */
body > header.header,
body > .header{
    display:none !important;
}

.layout{
    min-height:100vh !important;
}

/* Requested: make customer Profile workspace colourful/professional. */
.profile-workspace-nav{
    display:flex !important;
    flex-wrap:wrap !important;
    gap:8px !important;
    padding:8px !important;
    border:1px solid #e2e8f0 !important;
    border-radius:12px !important;
    background:#f8fafc !important;
}

.profile-workspace-tab{
    min-height:39px !important;
    padding:0 14px !important;
    border-radius:9px !important;
    border:1px solid transparent !important;
    font-size:11px !important;
    font-weight:800 !important;
    cursor:pointer !important;
    transition:.18s ease !important;
}

.profile-workspace-tab[data-profile-tab="overview"]{
    background:#eff6ff !important;
    border-color:#bfdbfe !important;
    color:#2563eb !important;
}

.profile-workspace-tab[data-profile-tab="personal"]{
    background:#f5f3ff !important;
    border-color:#ddd6fe !important;
    color:#7c3aed !important;
}

.profile-workspace-tab[data-profile-tab="documents"]{
    background:#ecfdf5 !important;
    border-color:#a7f3d0 !important;
    color:#059669 !important;
}

.profile-workspace-tab[data-profile-tab="family"]{
    background:#fff7ed !important;
    border-color:#fed7aa !important;
    color:#ea580c !important;
}

.profile-workspace-tab[data-profile-tab="overview"].active{
    background:#2563eb !important;
    border-color:#2563eb !important;
    color:#fff !important;
}

.profile-workspace-tab[data-profile-tab="personal"].active{
    background:#7c3aed !important;
    border-color:#7c3aed !important;
    color:#fff !important;
}

.profile-workspace-tab[data-profile-tab="documents"].active{
    background:#059669 !important;
    border-color:#059669 !important;
    color:#fff !important;
}

.profile-workspace-tab[data-profile-tab="family"].active{
    background:#ea580c !important;
    border-color:#ea580c !important;
    color:#fff !important;
}

.profile-workspace-tab:hover{
    transform:translateY(-1px) !important;
    box-shadow:0 5px 13px rgba(15,23,42,.10) !important;
}

/* Profile forms: colourful section cards without changing form logic. */
.pm-section{
    border:1px solid #e2e8f0 !important;
    border-radius:13px !important;
    background:#fff !important;
    box-shadow:0 8px 22px rgba(15,23,42,.05) !important;
}

.pm-section[data-profile-panel="personal"]{
    border-top:4px solid #7c3aed !important;
}

.pm-section[data-profile-panel="documents"]{
    border-top:4px solid #059669 !important;
}

.pm-section[data-profile-panel="family"]{
    border-top:4px solid #ea580c !important;
}

.pm-control{
    border:1px solid #cbd5e1 !important;
    border-radius:9px !important;
    background:#fff !important;
}

.pm-control:focus{
    border-color:#60a5fa !important;
    box-shadow:0 0 0 3px rgba(37,99,235,.12) !important;
}

/* Existing profile action buttons — colour only. */
.pm-btn,
.manager-subform button[type="submit"],
.profile-manager button[type="submit"]{
    min-height:39px !important;
    padding:0 14px !important;
    border:0 !important;
    border-radius:9px !important;
    background:linear-gradient(135deg,#2563eb,#1d4ed8) !important;
    color:#fff !important;
    font-size:11px !important;
    font-weight:800 !important;
    cursor:pointer !important;
    box-shadow:0 7px 16px rgba(37,99,235,.18) !important;
}

.pm-btn:hover,
.manager-subform button[type="submit"]:hover,
.profile-manager button[type="submit"]:hover{
    transform:translateY(-1px) !important;
}

/* Preserve destructive document/remove actions as red. */
.pm-doc-btn.delete,
.profile-manager button.delete,
.profile-manager .btn-danger{
    background:#dc2626 !important;
    color:#fff !important;
    border-color:#dc2626 !important;
}

/* Document view remains a distinct green action. */
.pm-doc-btn.view{
    background:#059669 !important;
    border-color:#059669 !important;
    color:#fff !important;
}

/* Close customer profile: visible soft red button. */
.profile-manager-head .refresh-btn{
    border:1px solid #fecdd3 !important;
    background:#fff1f2 !important;
    color:#be123c !important;
}

/* Overview boxes receive a light professional colour treatment. */
.overview-item:nth-child(4n+1){
    background:#eff6ff !important;
    border-color:#bfdbfe !important;
}

.overview-item:nth-child(4n+2){
    background:#f5f3ff !important;
    border-color:#ddd6fe !important;
}

.overview-item:nth-child(4n+3){
    background:#ecfdf5 !important;
    border-color:#a7f3d0 !important;
}

.overview-item:nth-child(4n){
    background:#fff7ed !important;
    border-color:#fed7aa !important;
}
</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
<style id="travscope-v2431-customer-update">
.pm-overview-documents{grid-column:1/-1;display:block;padding:15px;border:1px solid #c7d2fe;background:linear-gradient(145deg,#f5f7ff,#ffffff);border-radius:14px}
.pm-overview-documents-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px}.pm-overview-documents-head h3{font-size:15px;color:#172554}.pm-overview-documents-head h3 i{color:#4f46e5}.pm-overview-documents-head p{font-size:11px;color:#64748b;max-width:760px;line-height:1.6;margin-top:5px}
.pm-go-documents,.pm-lookup-btn{min-height:39px;display:inline-flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:9px;padding:0 14px;background:#1d4ed8;color:#fff;font-size:12px;font-weight:800;cursor:pointer}.pm-go-documents:hover,.pm-lookup-btn:hover{background:#1e40af}
.pm-document-mini-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:11px}.pm-document-mini-card{background:white;border:1px solid #e2e8f0;border-radius:12px;padding:12px;display:grid;gap:8px}.pm-document-mini-top{display:flex;justify-content:space-between;align-items:flex-start;gap:8px;flex-wrap:wrap}.pm-document-mini-top strong{font-size:13px;color:#0f172a}.pm-document-mini-card>div:not(:first-child){display:flex;justify-content:space-between;gap:12px}.pm-document-mini-card small{font-size:11px;color:#64748b}.pm-document-mini-card b{font-size:11px;color:#334155;text-align:right}.pm-doc-state{font-size:10px;font-weight:800;padding:4px 7px;border-radius:99px;background:#f1f5f9;color:#475569}.pm-doc-state.success{background:#dcfce7;color:#166534}.pm-doc-state.warning{background:#fef3c7;color:#92400e}.pm-doc-state.danger{background:#fee2e2;color:#991b1b}.pm-doc-warning{margin-top:12px!important;color:#92400e!important;font-weight:800}.pm-doc-empty{padding:13px;font-size:12px;color:#64748b;background:white;border-radius:10px}
.pm-address-heading{padding:12px;border-radius:11px;background:#eff6ff;border:1px solid #bfdbfe}.pm-address-heading h4{font-size:13px;color:#1e40af}.pm-address-heading p{font-size:11px;line-height:1.5;color:#475569}.pm-pin-row{display:flex;gap:7px}.pm-pin-row input{flex:1;min-width:100px}.pm-hint{display:block;margin-top:5px;color:#64748b;font-size:11px;line-height:1.4}.pm-hint.error{color:#b91c1c}.pm-hint.success{color:#047857}.pm-pin-localities{margin-top:7px}
.pm-existing-search{margin-top:18px;padding:16px;border:1px solid #c7d2fe;border-radius:13px;background:#f8faff}.pm-existing-search h4{font-size:14px;color:#312e81}.pm-existing-search p{font-size:12px;line-height:1.5;color:#64748b}.pm-family-search-form{display:flex;gap:9px;flex-wrap:wrap;align-items:center;margin:12px 0}.pm-family-search-form input{flex:1;min-width:200px}.pm-clear-search{font-size:12px;color:#1d4ed8;text-decoration:underline}.pm-search-result-note{margin:10px 0!important;font-size:12px!important;color:#475569!important}
.pm-location-insights{margin:14px 0;padding:16px;border:1px solid #c7d2fe;border-radius:15px;background:linear-gradient(140deg,#eff6ff,#faf5ff);box-shadow:0 8px 18px rgba(15,23,42,.04)}.pm-location-head{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}.pm-location-head h3{font-size:16px;color:#1e3a8a}.pm-location-head p{font-size:11px;color:#475569;margin-top:5px}.pm-location-head>span{font-size:11px;color:#4f46e5;background:#e0e7ff;padding:6px 10px;border-radius:30px;font-weight:800}.pm-location-columns{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-top:13px}.pm-location-card{padding:14px;border:1px solid #e2e8f0;background:#fff;border-radius:12px}.pm-location-card h4{font-size:13px;color:#0f172a;margin-bottom:10px}.pm-location-card p{font-size:11px;color:#94a3b8}.pm-location-item{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 0;border-bottom:1px solid #f1f5f9}.pm-location-item:last-child{border-bottom:0}.pm-location-item strong{font-size:12px;color:#334155;overflow-wrap:anywhere}.pm-location-item span{font-size:11px;font-weight:800;color:#2563eb;white-space:nowrap}

/* V24.32: four distinct location steps; postal code no longer drives address choices. */
.pm-geo-field{min-width:0;padding:13px 14px;border:1px solid #dbeafe;border-radius:12px;background:#f8fbff}
.pm-geo-field label{display:flex;align-items:center;gap:8px!important;margin-bottom:9px!important;font-weight:800!important;font-size:12px!important;color:#183153!important}
.pm-geo-country{background:#eff6ff;border-color:#bfdbfe}.pm-geo-state{background:#f5f3ff;border-color:#ddd6fe}
.pm-geo-district{background:#fff7ed;border-color:#fed7aa}.pm-geo-city{background:#f0fdf4;border-color:#bbf7d0}
.pm-geo-extra{background:#f8fafc;border-color:#e2e8f0}.pm-geo-number{height:24px;width:24px;display:inline-flex;align-items:center;justify-content:center;color:#fff;background:#2563eb;border-radius:8px;font-weight:900}
.pm-geo-state .pm-geo-number{background:#7c3aed}.pm-geo-district .pm-geo-number{background:#ea580c}.pm-geo-city .pm-geo-number{background:#16a34a}
.pm-geo-field>.pm-control{background:#fff;border-color:#cbd5e1!important;min-height:42px}
.pm-geo-field select:disabled{color:#94a3b8;background:#f1f5f9;cursor:not-allowed}
.pm-geo-field small{display:block;color:#64748b;font-size:11px;line-height:1.5;margin-top:7px}
.pm-geo-manual:not([hidden]),.pm-geo-filter:not([hidden]){display:block;margin-top:9px}
.pm-geo-status{grid-column:1/-1;padding:10px 13px;background:#eff6ff;color:#1e40af;border-radius:9px;font-size:12px;font-weight:700}
.pm-geo-status.error{background:#fef2f2;color:#b91c1c}
@media(max-width:1200px){.pm-location-columns{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:900px){.pm-location-columns{grid-template-columns:1fr}}@media(max-width:620px){.pm-pin-row{flex-wrap:wrap}.pm-lookup-btn{width:100%}}
</style>
<style id="travscope-v2454-international-customer-directory">
/* V24.54: Customer listing UI only; no changes to profile, forms, SQL or backend actions. */
.cm-page-head,.cm-page-head *,.cm-geo-panel,.cm-geo-panel *,.cm-directory,.cm-directory *{box-sizing:border-box}
body:not(.profile-open) .main{padding:13px 15px 22px!important}
body:not(.profile-open) .cm-page-head{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:14px!important;flex-wrap:wrap!important;margin:0 0 9px!important;padding:13px 15px!important;background:linear-gradient(105deg,#fff,#f5faff)!important;border:1px solid #dce6f0!important;border-left:4px solid #1475df!important;border-radius:12px!important;box-shadow:0 4px 16px rgba(25,56,92,.045)!important}
.cm-head-primary{display:flex;gap:13px;align-items:center;flex:1 1 870px;min-width:0;flex-wrap:wrap}
.cm-head-title{flex:0 1 330px;min-width:230px}
.cm-eyebrow{display:block;font-size:9px;line-height:1.2;letter-spacing:.72px;font-weight:850;color:#1975d3}
body:not(.profile-open) .cm-page-head h1{margin:3px 0 0!important;font:850 22px/1.17 Manrope,Inter,system-ui,sans-serif!important;letter-spacing:-.6px!important;color:#142b46!important}
body:not(.profile-open) .cm-page-head p{margin:4px 0 0!important;font-size:10px!important;color:#687d96!important;line-height:1.4!important}
.cm-kpis{display:flex;align-items:center;flex-wrap:wrap;gap:5px;flex:1 1 490px;min-width:0}
.cm-kpi{display:inline-flex;align-items:center;gap:5px;min-height:29px;padding:5px 8px;border:1px solid #e1eaf3;border-radius:7px;background:#fff;white-space:nowrap;color:#61758b;font:700 10px/1.25 Inter,system-ui,sans-serif;letter-spacing:0;box-shadow:none}
.cm-kpi i{font-size:10px;color:#2878ca}.cm-kpi strong{margin:0!important;font:850 13px/1.15 Manrope,Inter,system-ui,sans-serif;color:#193957;font-variant-numeric:tabular-nums}
.cm-kpi.cm-active i{color:#079a69}.cm-kpi.cm-verified i{color:#3176dd}.cm-kpi.cm-new i{color:#9b6cda}.cm-kpi.cm-blocked i{color:#c65c65}
.cm-kpi.cm-total{background:#eff6ff;border-color:#cfe4fa}
body:not(.profile-open) .cm-head-actions{display:flex!important;flex:0 0 auto;align-items:center;gap:7px!important;align-self:center}
.cm-head-actions .manual-customer-btn,.cm-head-actions .refresh-btn{height:34px!important;min-height:34px!important;padding:0 11px!important;display:inline-flex;align-items:center;gap:6px;border-radius:7px!important;font-size:10px!important;white-space:nowrap;box-shadow:none!important}
/* Insight panel: an accessible native disclosure instead of four always-visible cards. */
.cm-geo-panel{margin:0 0 9px!important;border:1px solid #dce6f0;border-radius:10px;background:#fff;overflow:hidden;box-shadow:0 3px 12px rgba(24,54,88,.035)}
.cm-geo-summary{padding:10px 12px;display:flex;justify-content:space-between;align-items:center;gap:12px;cursor:pointer;list-style:none;min-height:40px;background:linear-gradient(95deg,#f6faff,#fff)}
.cm-geo-summary::-webkit-details-marker{display:none}.cm-geo-summary:focus-visible{outline:2px solid #1b76df;outline-offset:-3px}
.cm-geo-heading{display:flex;align-items:center;gap:7px;min-width:0;flex-wrap:wrap;font:700 11px/1.25 Inter,system-ui,sans-serif;color:#173958}
.cm-geo-heading i{color:#1776db;font-size:12px}.cm-geo-heading small{font:500 10px/1.3 Inter,system-ui,sans-serif;color:#7a8ca2}
.cm-geo-expand{display:inline-flex;align-items:center;gap:8px;flex:none;white-space:nowrap;font:800 10px/1.2 Inter,system-ui,sans-serif;color:#2a6fb5}
.cm-geo-expand i{font-size:10px;transition:transform .15s}.cm-geo-panel[open] .cm-geo-expand i{transform:rotate(180deg)}
.cm-geo-content{padding:11px 12px 13px;border-top:1px solid #e6edf4;background:#fcfdff}.cm-geo-content>p{margin:0;color:#71879c;font-size:10px;line-height:1.45}
.cm-geo-panel .cm-geo-columns{margin-top:9px!important;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.cm-geo-panel .pm-location-card{padding:10px 11px!important;border-radius:8px!important}.cm-geo-panel .pm-location-card h4{font-size:11px!important;margin-bottom:5px!important}
.cm-geo-panel .pm-location-item{padding:5px 0!important;gap:7px}.cm-geo-panel .pm-location-item strong{font-size:10px!important}.cm-geo-panel .pm-location-item span{font-size:10px!important}
/* Single directory card; filters and table meet without duplicate card headings. */
body:not(.profile-open) .cm-directory{margin:0 0 14px!important;overflow:hidden!important;border:1px solid #dbe5ef!important;border-radius:11px!important;background:#fff!important;box-shadow:0 5px 18px rgba(29,58,91,.04)!important}
.cm-directory-heading{padding:10px 12px!important;display:flex;align-items:center;justify-content:space-between;gap:8px;background:linear-gradient(180deg,#fff,#fbfdff);border-bottom:1px solid #e4ecf4}
.cm-directory-heading h2{margin:0;display:flex;align-items:center;gap:7px;flex-wrap:wrap;font:850 13px/1.3 Manrope,Inter,system-ui,sans-serif;color:#163b60}.cm-directory-heading h2 i{color:#1476da}
.cm-directory-heading p{margin:3px 0 0;color:#71869b;font:500 10px/1.3 Inter,system-ui,sans-serif}.cm-match-count{font:800 10px/1.1 Inter,system-ui,sans-serif;color:#3573a8;background:#edf6ff;border:1px solid #d6e7f6;padding:3px 6px;border-radius:5px}
.cm-directory-tag{font:850 9px/1.2 Inter,system-ui,sans-serif;letter-spacing:.65px;color:#8da0b3;white-space:nowrap}
.cm-filter-bar{display:flex;align-items:center;gap:7px;flex-wrap:wrap;padding:9px 11px!important;margin:0;border-bottom:1px solid #e3ebf4;background:#fff}
body:not(.profile-open) .cm-directory .cm-directory-filters{margin:0!important;padding:0!important;display:grid!important;grid-template-columns:minmax(210px,2.2fr) minmax(130px,1fr) minmax(135px,1fr) auto!important;gap:7px!important;flex:1 1 600px;min-width:0;width:auto!important;border:0!important;background:transparent!important;box-shadow:none!important}
.cm-directory-filters .control,.cm-directory-filters .filter-btn{height:34px!important;min-height:34px!important;border-radius:7px!important;font-size:10px!important;line-height:1.2!important;padding:0 10px!important}
.cm-directory-filters .control{min-width:0!important}.cm-directory-filters .filter-btn{min-width:82px;padding:0 13px!important;background:#156fd9!important;box-shadow:none!important;font-weight:800!important;white-space:nowrap}
.cm-filter-bar .cm-reset-filter{margin:0!important;flex:0 0 auto;display:inline-flex;align-items:center;gap:5px;padding:0 9px;height:34px;border:1px solid #dfe7f0;border-radius:7px;background:#f7f9fc;color:#4d6681;font:750 10px/1 Inter,system-ui,sans-serif;text-decoration:none!important}
.cm-result-strip{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:6px;padding:6px 11px;color:#7a8ca0;background:#fafcff;border-bottom:1px solid #e6edf4;font:600 9px/1.4 Inter,system-ui,sans-serif}
.cm-result-strip i{font-size:9px;margin-right:3px}.cm-list-body{margin:0;padding:0!important}.cm-list-body .cm-table-wrap{margin:0!important;border:0!important;border-radius:0!important;max-width:100%;width:100%;overflow-x:auto!important;-webkit-overflow-scrolling:touch;scrollbar-width:thin;scrollbar-color:#c7d8e8 transparent}
.cm-directory .customer-table{width:100%!important;min-width:1260px!important;border-collapse:collapse!important;table-layout:auto!important}
.cm-directory .customer-table thead{background:#eef4fa!important}.cm-directory .customer-table th{padding:10px 9px!important;background:#eef4fa!important;color:#385873!important;font-size:9px!important;letter-spacing:.32px!important;line-height:1.3!important;font-weight:850!important;border-bottom:1px solid #dce6f1!important}
.cm-directory .customer-table td{padding:10px 9px!important;font-size:10px!important;line-height:1.42!important;vertical-align:middle!important;border-bottom:1px solid #e6edf4!important}
.cm-directory .customer-table tbody tr:nth-child(even){background:#fbfdff}.cm-directory .customer-table tbody tr:hover{background:#f2f8ff}
.cm-directory .customer-name{font-size:11px!important}.cm-directory .customer-avatar{height:29px!important;width:29px!important;border-radius:7px!important;font-size:10px!important}
.cm-directory .customer-person-row{min-width:145px!important;gap:7px!important}.cm-directory .subtext{font-size:9px!important;white-space:normal!important;color:#8090a3!important;line-height:1.4!important}
.cm-directory .badge{padding:4px 6px!important;font-size:9px!important;line-height:1.2!important}.cm-directory .money-main{font-size:11px!important}.cm-directory .money-paid{font-size:9px!important}.cm-directory .mini-status{font-size:9px!important;padding:3px 5px!important}
.cm-directory .table-actions{display:flex!important;align-items:center!important;gap:4px!important;flex-wrap:wrap!important;min-width:225px!important;max-width:290px}.cm-directory .table-actions .btn{height:27px!important;min-height:27px!important;padding:0 7px!important;font-size:9px!important;border-radius:6px!important;box-shadow:none!important}.cm-directory .table-actions .btn i{font-size:9px}
.cm-directory .table-actions form{margin:0!important}.cm-directory .pagination{margin:0!important;padding:10px 12px!important;border-top:1px solid #e6edf4;background:#fafcff}
.cm-directory .empty{padding:35px 14px!important}.cm-directory .empty h3{font-size:14px!important}.cm-directory .empty p{font-size:11px!important}
@media(max-width:1230px){.cm-geo-panel .cm-geo-columns{grid-template-columns:repeat(2,minmax(0,1fr))}.cm-head-title{flex:1 1 100%}.cm-kpis{flex:1 1 550px}}
@media(max-width:850px){body:not(.profile-open) .main{padding:10px 9px 18px!important}.cm-page-head{align-items:flex-start!important}.cm-directory .customer-table{min-width:1220px!important}}
@media(max-width:710px){.cm-directory-tag{display:none}.cm-head-primary{flex-basis:100%;gap:8px}.cm-head-title{min-width:0}.cm-kpis{flex-basis:100%;gap:5px}.cm-head-actions{width:100%;justify-content:flex-end}.cm-geo-summary{align-items:flex-start;flex-wrap:wrap}.cm-geo-heading small{flex-basis:100%;padding-left:20px}.cm-geo-expand{margin-left:auto}.cm-filter-bar{align-items:stretch}.cm-directory .cm-directory-filters{flex-basis:100%!important;grid-template-columns:repeat(2,minmax(0,1fr))!important}.cm-directory-filters input[name="q"]{grid-column:1/-1}.cm-directory-filters .filter-btn{grid-column:1/-1}.cm-filter-bar .cm-reset-filter{width:100%;justify-content:center}.cm-geo-panel .cm-geo-columns{grid-template-columns:1fr}}
@media(max-width:420px){.cm-kpi{font-size:9px;padding:5px 6px}.cm-kpi strong{font-size:12px}.cm-directory .cm-directory-filters{grid-template-columns:1fr!important}.cm-directory-filters input[name="q"],.cm-directory-filters .filter-btn{grid-column:auto}}
</style>

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>

<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->






<!-- HEADER -->

<header class="header">

<a
    href="<?= e(BASE_URL . 'admin-dashboard.php'); ?>"
    class="logo"
>

<div class="logo-icon">
    <i class="fa-solid fa-plane"></i>
</div>

TRAV<span>SCOPE</span> ADMIN

</a>


<div class="admin">

<div class="admin-avatar">

<?= e(
    strtoupper(
        mb_substr(
            $admin['name'],
            0,
            1
        )
    )
); ?>

</div>


<div>

<strong>
    <?= e($admin['name']); ?>
</strong>

<small>

<?= e(
    ucfirst(
        str_replace(
            '_',
            ' ',
            $admin['role']
        )
    )
); ?>

</small>

</div>

</div>

</header>


<div class="layout">


<!-- SIDEBAR -->

<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->




<!-- MAIN -->

<main class="main">


<header class="page-head cm-page-head" aria-label="Customer Management overview">
 <div class="cm-head-primary">
  <div class="cm-head-title"><span class="cm-eyebrow">CUSTOMER RELATIONSHIP</span><h1>Customer Management</h1><p>Manage traveller profiles, account access and customer bookings.</p></div>
  <?php if (!$profileCustomer): ?>
  <div class="cm-kpis" aria-label="Customer summary">
   <span class="cm-kpi cm-total"><i class="fa-solid fa-users" aria-hidden="true"></i><span>Total customers</span><strong><?= number_format((int)$stats['total']); ?></strong></span>
   <span class="cm-kpi cm-active"><i class="fa-solid fa-user-check" aria-hidden="true"></i><span>Active</span><strong><?= number_format((int)$stats['active']); ?></strong></span>
   <span class="cm-kpi cm-verified"><i class="fa-solid fa-envelope-circle-check" aria-hidden="true"></i><span>Email verified</span><strong><?= number_format((int)$stats['verified']); ?></strong></span>
   <span class="cm-kpi cm-new"><i class="fa-solid fa-user-plus" aria-hidden="true"></i><span>New this month</span><strong><?= number_format((int)$stats['new_this_month']); ?></strong></span>
   <span class="cm-kpi cm-blocked"><i class="fa-solid fa-user-lock" aria-hidden="true"></i><span>Blocked</span><strong><?= number_format((int)$stats['blocked']); ?></strong></span>
  </div>
  <?php endif; ?>
 </div>
 <div class="customer-head-actions cm-head-actions">
  <?php if (!$profileCustomer): ?>
   <button type="button" class="manual-customer-btn" id="openManualCustomer"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> Add Customer</button>
  <?php endif; ?>
  <a href="<?= e(BASE_URL . 'admin-customers.php'); ?>" class="refresh-btn"><i class="fa-solid fa-rotate" aria-hidden="true"></i> Refresh</a>
 </div>
</header>

<!-- ALERTS -->

<?php if ($success !== ''): ?>

<div class="alert alert-success">

<i class="fa-solid fa-circle-check"></i>

<?= e($success); ?>

</div>

<?php endif; ?>


<?php if ($error !== ''): ?>

<div class="alert alert-error">

<i class="fa-solid fa-circle-exclamation"></i>

<?= e($error); ?>

</div>

<?php endif; ?>


<?php if($profileCustomer): ?><section class="profile-manager" id="customer-profile-manager"><div class="profile-manager-head"><div><h2><?= e($profileCustomer['full_name']); ?> · Client Profile</h2><p>Customer #<?= (int)$profileCustomer['id']; ?> · <?= e(ucfirst($profileCustomer['status'])); ?></p></div><a href="<?= e(BASE_URL.'admin-customers.php'); ?>" class="refresh-btn"><i class="fa-solid fa-xmark"></i> Close</a></div><div class="profile-manager-body">
<nav class="profile-workspace-nav" aria-label="Customer profile sections">
    <button type="button" class="profile-workspace-tab active" data-profile-tab="overview"><i class="fa-solid fa-address-card"></i> Overview</button>
    <button type="button" class="profile-workspace-tab" data-profile-tab="personal"><i class="fa-solid fa-user-gear"></i> Personal Profile</button>
    <button type="button" class="profile-workspace-tab" data-profile-tab="documents"><i class="fa-solid fa-passport"></i> Documents</button>
    <button type="button" class="profile-workspace-tab" data-profile-tab="family"><i class="fa-solid fa-people-roof"></i> Family & Travellers</button>
</nav>
<div class="overview-grid" data-profile-panel="overview">
<div class="overview-item"><span>Name</span><strong><?= e($profileCustomer['full_name']); ?></strong></div><div class="overview-item"><span>Preferred Language</span><strong><?= e($profileTravel['preferred_language']?:'Not specified'); ?></strong></div><div class="overview-item"><span>Email</span><strong><?= e($profileCustomer['email']); ?></strong></div><div class="overview-item"><span>Phone / WhatsApp</span><strong><?= e($profileCustomer['mobile']?:'Not provided'); ?></strong></div><div class="overview-item"><span>Country</span><strong><?= e($profileTravel['address_country'] ?: ($profileCustomer['country'] ?: 'Not provided')); ?></strong></div><div class="overview-item"><span>State</span><strong><?= e($profileTravel['address_state'] ?: 'Not recorded'); ?></strong></div><div class="overview-item"><span>District</span><strong><?= e($profileTravel['address_district'] ?: 'Not recorded'); ?></strong></div><div class="overview-item"><span>City / Locality</span><strong><?= e($profileTravel['address_city'] ?: ($profileTravel['city_state'] ?: 'Not recorded')); ?></strong></div><div class="overview-item"><span>Postal / PIN</span><strong><?= e($profileTravel['address_pincode'] ?: 'Not recorded'); ?></strong></div><div class="overview-item"><span>Lead Source</span><strong><?= e($profileTravel['lead_source']?:'Not specified'); ?></strong></div><div class="overview-item"><span>Family Members</span><strong><?= count($profileFamily)+count($profileLinks); ?> Linked</strong></div>
<div class="pm-overview-documents">
    <div class="pm-overview-documents-head"><div><h3><i class="fa-solid fa-file-shield"></i> Document status at a glance</h3><p>Latest uploaded record for each document type. Upload dates, issue dates and expiry dates are shown as entered; the uploaded image is not automatically read or verified.</p></div><button type="button" class="pm-go-documents" data-go-profile-tab="documents">Open Documents <i class="fa-solid fa-arrow-right"></i></button></div>
    <?php if ($customerDocSummary): ?><div class="pm-document-mini-grid">
    <?php foreach ($customerDocSummary as $docType=>$docInfo): ?>
      <div class="pm-document-mini-card"><div class="pm-document-mini-top"><strong><?= e($docType); ?></strong><span class="pm-doc-state <?= e($docInfo['level']); ?>"><?= e($docInfo['status']); ?></span></div>
        <div><small>Uploaded</small><b><?= $docInfo['uploaded'] ? e(date('d M Y', strtotime($docInfo['uploaded']))) : 'Not recorded'; ?></b></div>
        <div><small>Issue date</small><b><?= $docInfo['issue'] ? e(date('d M Y', strtotime($docInfo['issue']))) : 'Not entered'; ?></b></div>
        <div><small>Expiry date</small><b><?= $docInfo['expiry'] && $docInfo['expiry'] !== '0000-00-00' ? e(date('d M Y', strtotime($docInfo['expiry']))) : 'Not entered / N.A.'; ?></b></div>
      </div>
    <?php endforeach; ?></div>
    <?php if ($customerDocExpiryWarnings): ?><p class="pm-doc-warning"><?= (int)$customerDocExpiryWarnings; ?> document type(s) need attention (expired or due within 90 days). Check before travel or ticketing.</p><?php endif; ?>
    <?php else: ?><div class="pm-doc-empty">No customer documents uploaded yet. Use the Documents tab to add Aadhaar, PAN, Passport, Visa or other travel documents.</div><?php endif; ?>
</div>
</div>
<div class="pm-section" data-profile-panel="personal"><h3>Personal Profile</h3><p>Manage long-term relationship and travel preferences.</p>
<form method="post"><input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>"><input type="hidden" name="action" value="update_travel_profile"><input type="hidden" name="user_id" value="<?= (int)$profileCustomer['id']; ?>"><div class="pm-form">
<div><label>Date of Birth</label><input class="pm-control" type="date" name="date_of_birth" value="<?= e((string)$profileTravel['date_of_birth']); ?>"></div><div><label>Anniversary Date</label><input class="pm-control" type="date" name="anniversary_date" value="<?= e((string)$profileTravel['anniversary_date']); ?>"></div><div><label>Preferred Language</label><input class="pm-control" name="preferred_language" value="<?= e((string)$profileTravel['preferred_language']); ?>"></div>
<div class="full pm-address-heading"><h4><i class="fa-solid fa-earth-asia"></i> Customer residential / contact address</h4><p>Choose in order: <strong>Country → State / Province → District → City / Locality.</strong> Each step updates the next list. Type a location manually only when it is not in the available directory. Postal/PIN is optional, not used for lookup.</p></div>
<div class="pm-geo-field pm-geo-country"><label><span class="pm-geo-number">1</span> Country / Territory</label>
<select class="pm-control" id="pmAddressCountrySelect" aria-label="Choose country" required><option value="">Choose country</option><?php foreach ($customerGeoCountries as $geoCountry): ?><option value="<?= e((string)$geoCountry['name']); ?>"><?= e((string)$geoCountry['name']); ?></option><?php endforeach; ?><option value="__manual__">Other / type country</option></select>
<input class="pm-control pm-geo-manual" id="pmAddressCountryManual" maxlength="100" placeholder="Enter country" hidden>
<input type="hidden" name="address_country" id="pmAddressCountry" value="<?= e((string)($profileTravel['address_country'] ?: ($profileCustomer['country'] ?? 'India'))); ?>"><small>Worldwide country list is included with TRAVSCOPE.</small></div>
<div class="pm-geo-field pm-geo-state"><label><span class="pm-geo-number">2</span> State / Province / Region</label>
<select class="pm-control" id="pmAddressStateSelect" aria-label="Choose state" disabled><option value="">Choose country first</option></select>
<input class="pm-control pm-geo-manual" id="pmAddressStateManual" maxlength="100" placeholder="Enter state / province" hidden>
<input type="hidden" name="address_state" id="pmAddressState" value="<?= e((string)$profileTravel['address_state']); ?>"><small id="pmStateHint">Available after choosing the country.</small></div>
<div class="pm-geo-field pm-geo-district"><label><span class="pm-geo-number">3</span> District / Administrative Area</label>
<select class="pm-control" id="pmAddressDistrictSelect" aria-label="Choose district" disabled><option value="">Choose state first</option></select>
<input class="pm-control pm-geo-manual" id="pmAddressDistrictManual" maxlength="100" placeholder="Enter district if not listed" hidden>
<input type="hidden" name="address_district" id="pmAddressDistrict" value="<?= e((string)$profileTravel['address_district']); ?>"><small id="pmDistrictHint">District options depend on the selected state.</small></div>
<div class="pm-geo-field pm-geo-city"><label><span class="pm-geo-number">4</span> City / Town / Locality</label>
<input class="pm-control pm-geo-filter" id="pmCityFilter" placeholder="Search available cities..." autocomplete="off" hidden aria-label="Filter city suggestions">
<select class="pm-control" id="pmAddressCitySelect" aria-label="Choose city" disabled><option value="">Choose district first</option></select>
<input class="pm-control pm-geo-manual" id="pmAddressCityManual" maxlength="120" placeholder="Enter city / locality" hidden>
<input type="hidden" name="address_city" id="pmAddressCity" value="<?= e((string)$profileTravel['address_city']); ?>"><small id="pmCityHint">City suggestions will appear after the preceding selections.</small></div>
<div class="pm-geo-field pm-geo-extra"><label>Postal / PIN Code (optional)</label><input class="pm-control" name="address_pincode" id="pmAddressPin" maxlength="20" value="<?= e((string)$profileTravel['address_pincode']); ?>" placeholder="Enter postal / PIN code" inputmode="text"><small>No PIN lookup is used.</small></div>
<div class="pm-geo-field pm-geo-extra"><label>Street / Village / House / Landmark (optional)</label><input class="pm-control" name="address_line" maxlength="255" value="<?= e((string)$profileTravel['address_line']); ?>" placeholder="Full street address or village"></div>
<div class="full pm-geo-status" id="pmGeoFeedback" role="status" aria-live="polite">Choose the country to start.</div>
<input type="hidden" name="city_state" value="<?= e((string)$profileTravel['city_state']); ?>"><div><label>Lead Source</label><input class="pm-control" name="lead_source" value="<?= e((string)$profileTravel['lead_source']); ?>"></div><div><label>Spouse / Partner Name</label><input class="pm-control" name="spouse_partner_name" value="<?= e((string)$profileTravel['spouse_partner_name']); ?>"></div><div><label>Occupation</label><input class="pm-control" name="occupation" value="<?= e((string)$profileTravel['occupation']); ?>"></div><div><label>Preferred Destination Type</label><input class="pm-control" name="preferred_destination_type" value="<?= e((string)$profileTravel['preferred_destination_type']); ?>"></div><div><label>Travel Style</label><input class="pm-control" name="travel_style" value="<?= e((string)$profileTravel['travel_style']); ?>"></div><div><label>Preferred Hotel Category</label><input class="pm-control" name="preferred_hotel_category" value="<?= e((string)$profileTravel['preferred_hotel_category']); ?>"></div><div class="full"><label>Important Relationship Notes</label><textarea class="pm-control" name="relationship_notes"><?= e((string)$profileTravel['relationship_notes']); ?></textarea></div><div class="full"><label><input type="checkbox" name="birthday_wishes" value="1" <?= !empty($profileTravel['birthday_wishes'])?'checked':''; ?>> Birthday wishes</label> &nbsp; <label><input type="checkbox" name="anniversary_wishes" value="1" <?= !empty($profileTravel['anniversary_wishes'])?'checked':''; ?>> Anniversary wishes</label></div>
</div><button class="pm-save"><i class="fa-solid fa-floppy-disk"></i> Save Profile</button></form></div>


<div class="pm-section" id="identity-documents" data-profile-panel="documents">
<h3>Identity & Traveller Documents</h3>
<p>Manage the customer’s identity, passport, visa, insurance, ticket and other travel document files.</p>

<?php
$adminIdentityCount = count(array_filter($profileDocuments, static fn($d) => ($d['document_category'] ?? '') === 'identity'));
$adminTravellerCount = count(array_filter($profileDocuments, static fn($d) => ($d['document_category'] ?? '') === 'travel'));
?>

<div class="pm-doc-stats">
    <div class="pm-doc-stat"><span>Identity Documents</span><strong><?= number_format($adminIdentityCount); ?></strong></div>
    <div class="pm-doc-stat"><span>Traveller Documents</span><strong><?= number_format($adminTravellerCount); ?></strong></div>
</div>

<?php if ($profileDocuments): ?>
<div class="pm-doc-list">
<?php foreach ($profileDocuments as $document): ?>
    <div class="pm-doc-row">
        <div>
            <h4><?= e($document['document_type']); ?></h4>
            <span class="pm-doc-badge"><?= ($document['document_category'] ?? '') === 'identity' ? 'Identity' : 'Traveller'; ?></span>
            <p>
                <strong>Number:</strong> <?= e($document['document_number'] ?: 'Not entered'); ?> ·
                <strong>Country:</strong> <?= e($document['issuing_country'] ?: 'Not entered'); ?><br>
                <strong>Issue:</strong> <?= e(!empty($document['issue_date']) ? date('d M Y', strtotime($document['issue_date'])) : 'Not entered'); ?> ·
                <strong>Expiry:</strong> <?= e(!empty($document['expiry_date']) ? date('d M Y', strtotime($document['expiry_date'])) : 'Not entered'); ?><br>
                <strong>File:</strong> <?= e($document['original_name']); ?>
            </p>
            <?php if (!empty($document['notes'])): ?><p><?= nl2br(e($document['notes'])); ?></p><?php endif; ?>
        </div>

        <div class="pm-doc-actions">
            <a class="pm-doc-btn view" target="_blank" rel="noopener"
               href="<?= e(BASE_URL . ltrim((string)$document['file_path'], '/')); ?>">
                <i class="fa-regular fa-eye"></i> View
            </a>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                <input type="hidden" name="action" value="delete_travel_document">
                <input type="hidden" name="user_id" value="<?= (int)$profileCustomer['id']; ?>">
                <input type="hidden" name="document_id" value="<?= (int)$document['id']; ?>">
                <button class="pm-doc-btn delete" type="submit"><i class="fa-regular fa-trash-can"></i> Delete</button>
            </form>
        </div>
    </div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" class="manager-subform" id="adminTravelDocumentForm">
<input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
<input type="hidden" name="action" value="add_travel_document">
<input type="hidden" name="user_id" value="<?= (int)$profileCustomer['id']; ?>">

<div class="pm-form">

    <div class="full">
        <label>Choose Document Type *</label>
        <select class="pm-control" name="document_type" id="adminDocumentType" required>
            <option value="">Select identity or traveller document</option>
            <optgroup label="Identity Documents">
                <?php foreach (adminTravelDocumentTypes()['identity'] as $docType): ?>
                    <option value="<?= e($docType); ?>"><?= e($docType); ?></option>
                <?php endforeach; ?>
            </optgroup>
            <optgroup label="Traveller Documents">
                <?php foreach (adminTravelDocumentTypes()['travel'] as $docType): ?>
                    <option value="<?= e($docType); ?>"><?= e($docType); ?></option>
                <?php endforeach; ?>
            </optgroup>
        </select>
    </div>

    <div>
        <label id="adminDocumentNumberLabel">Document Number / Reference</label>
        <input class="pm-control" name="document_number" id="adminDocumentNumber" maxlength="150">
    </div>

    <div>
        <label>Issuing Country</label>
        <input class="pm-control" name="issuing_country" maxlength="100" placeholder="e.g. India">
    </div>

    <div>
        <label>Issue Date</label>
        <input class="pm-control" type="date" name="document_issue_date">
    </div>

    <div>
        <label>Expiry / Valid Until</label>
        <input class="pm-control" type="date" name="document_expiry_date">
    </div>

    <div class="full">
        <label id="adminDocumentFileLabel">Upload Document File *</label>
        <div class="pm-file-box">
            <input type="file" name="document_file"
                   accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp"
                   required>
            <div class="pm-file-note" id="adminDocumentFileNote">
                Choose the respective document file after selecting the document type. Maximum 8 MB.
            </div>
        </div>
    </div>

    <div class="full">
        <label>Document Notes</label>
        <textarea class="pm-control" name="document_notes" maxlength="1000"
                  placeholder="Optional passport/visa/policy/ticket or other notes"></textarea>
    </div>

</div>

<button class="pm-save" type="submit">
    <i class="fa-solid fa-cloud-arrow-up"></i> Upload Customer Document
</button>
</form>
</div>


<div class="pm-section" data-profile-panel="family"><h3>Family & Travellers</h3><p>Add a traveller or link an existing registered customer.</p>
<?php if($profileFamily||$profileLinks): ?><div class="pm-family"><?php foreach($profileLinks as $f): ?><div class="pm-row"><div><strong><?= e($f['full_name']); ?></strong><small><?= e($f['relationship']); ?> · Customer #<?= (int)$f['id']; ?><?php if(!empty($f['email']) && !str_ends_with((string)$f['email'],'@travscope.local')): ?> · <?= e($f['email']); ?><?php endif; ?></small></div><form method="post"><input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>"><input type="hidden" name="action" value="remove_family_link"><input type="hidden" name="user_id" value="<?= (int)$profileCustomer['id']; ?>"><input type="hidden" name="link_id" value="<?= (int)$f['link_id']; ?>"><button class="pm-remove">Remove Link</button></form></div><?php endforeach; ?><?php foreach($profileFamily as $f): ?><div class="pm-row"><div><strong><?= e(trim($f['first_name'].' '.($f['last_name']??''))); ?></strong><small><?= e($f['relationship']); ?> · <?= e($f['member_code']); ?></small></div><form method="post"><input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>"><input type="hidden" name="action" value="remove_family_member"><input type="hidden" name="user_id" value="<?= (int)$profileCustomer['id']; ?>"><input type="hidden" name="family_id" value="<?= (int)$f['id']; ?>"><button class="pm-remove">Remove</button></form></div><?php endforeach; ?></div><?php endif; ?>

<form method="post"><input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>"><input type="hidden" name="action" value="add_family_member"><input type="hidden" name="user_id" value="<?= (int)$profileCustomer['id']; ?>"><div class="pm-form"><div><label>First Name *</label><input class="pm-control" name="family_first_name" required></div><div><label>Last Name</label><input class="pm-control" name="family_last_name"></div><div><label>Relationship *</label><select class="pm-control" name="family_relationship" required><option value="">Select Relationship</option><?php foreach(['Spouse','Partner','Child','Parent','Sibling','Grandparent','Grandchild','Relative','Friend','Other'] as $r): ?><option value="<?= e($r); ?>"><?= e($r); ?></option><?php endforeach; ?></select></div><div><label>Date of Birth</label><input class="pm-control" type="date" name="family_date_of_birth"></div><div><label>Phone / WhatsApp</label><input class="pm-control" name="family_mobile"></div><div><label>Email (Optional)</label><input class="pm-control" type="email" name="family_email" placeholder="Optional"></div><div class="full"><label>Relationship Notes</label><input class="pm-control" name="family_notes"></div></div><button class="pm-save"><i class="fa-solid fa-user-plus"></i> Create & Link Family Member</button></form>

<div class="pm-existing-search">
    <h4><i class="fa-solid fa-magnifying-glass"></i> Find and link an existing customer</h4>
    <p>Search all eligible registered customers by name, email, mobile or exact customer ID. Current customer and already-linked profiles are excluded.</p>
    <form method="get" action="<?= e(BASE_URL . 'admin-customers.php'); ?>#profile-family" class="pm-family-search-form">
      <input type="hidden" name="profile_id" value="<?= (int)$profileCustomer['id']; ?>">
      <input class="pm-control" type="search" name="family_search" maxlength="80" value="<?= e($familySearchTerm); ?>" placeholder="Search name, phone, email or customer ID" aria-label="Find existing customer" required>
      <button class="pm-lookup-btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Search Customer</button>
      <?php if($familySearchTerm!==''): ?><a class="pm-clear-search" href="<?= e(BASE_URL . 'admin-customers.php?profile_id=' . (int)$profileCustomer['id'] . '#profile-family'); ?>">Clear</a><?php endif; ?>
    </form>
    <?php if($familySearchTerm!=='' && !$profileAvailable): ?><p class="pm-search-result-note">No eligible customers found. Try another spelling, phone number or customer ID.</p><?php endif; ?>
    <?php if($profileAvailable): ?><p class="pm-search-result-note"><?= count($profileAvailable); ?> matching customer(s) shown (maximum 30). Choose the correct record before linking.</p>
      <form method="post"><input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>"><input type="hidden" name="action" value="link_existing_customer"><input type="hidden" name="user_id" value="<?= (int)$profileCustomer['id']; ?>"><div class="pm-form"><div class="full"><label>Matching Existing Customer *</label><select class="pm-control" name="linked_user_id" required><option value="">Choose customer</option><?php foreach($profileAvailable as $u): ?><option value="<?= (int)$u['id']; ?>"><?= e($u['full_name']); ?> · Customer #<?= (int)$u['id']; ?> · <?= e(($u['mobile'] ?? '') ?: $u['email']); ?></option><?php endforeach; ?></select></div><div><label>Relationship *</label><select class="pm-control" name="link_relationship"><?php foreach(['Spouse','Partner','Child','Parent','Sibling','Grandparent','Grandchild','Relative','Friend','Other'] as $r): ?><option value="<?= e($r); ?>"><?= e($r); ?></option><?php endforeach; ?></select></div><div><label>Relationship Notes</label><input class="pm-control" name="link_notes"></div></div><button class="pm-save"><i class="fa-solid fa-link"></i> Link Selected Customer</button></form>
    <?php endif; ?>
</div>
</div></div></section><?php endif; ?>

<?php if(!$profileCustomer): ?>

<?php if ($customerLocationReady): ?>
<details class="cm-geo-panel" aria-label="Customer location insights">
 <summary class="cm-geo-summary">
  <span class="cm-geo-heading"><i class="fa-solid fa-chart-column" aria-hidden="true"></i><strong>Customer Location Insights</strong><small>Based on saved profile addresses</small></span>
  <span class="cm-geo-expand">View geographic breakdown <i class="fa-solid fa-chevron-down" aria-hidden="true"></i></span>
 </summary>
 <div class="cm-geo-content">
  <p>Counts use saved contact addresses from Personal Profile. Empty or unverified location fields are not guessed.</p>
  <div class="pm-location-columns cm-geo-columns">
   <?php foreach (['country'=>'Top Countries','state'=>'Top States','district'=>'Top Districts','pincode'=>'Top PIN / Postal Codes'] as $key=>$label): ?>
    <div class="pm-location-card"><h4><?= e($label); ?></h4>
     <?php if (!empty($customerLocationStats[$key])): ?>
      <?php foreach ($customerLocationStats[$key] as $row): ?><div class="pm-location-item"><strong><?= e($row['label']); ?></strong><span><?= number_format((int)$row['total']); ?> customer(s)</span></div><?php endforeach; ?>
     <?php else: ?><p>No recorded location data yet.</p><?php endif; ?>
    </div>
   <?php endforeach; ?>
  </div>
 </div>
</details>
<?php endif; ?>

<section class="card cm-directory" aria-labelledby="cm-directory-title">
 <header class="cm-directory-heading">
  <div><h2 id="cm-directory-title"><i class="fa-solid fa-address-book" aria-hidden="true"></i> Customer Directory <span class="cm-match-count"><?= number_format((int)$totalRows); ?> records</span></h2><p>Find registered travellers and manage accounts and bookings from one view.</p></div>
  <span class="cm-directory-tag">CUSTOMER DATABASE</span>
 </header>
 <div class="cm-filter-bar">
<form
    method="get"
    class="filters cm-directory-filters" role="search" aria-label="Search and filter customers"
>


<input
    type="text"
    name="q"
    class="control"
    placeholder="Name, email, mobile or country..."
    value="<?= e($search); ?>"
>


<select
    name="status"
    class="control"
>

<option value="">
    All Account Status
</option>

<option
    value="active"
    <?= $status === 'active'
        ? 'selected'
        : ''; ?>
>
    Active
</option>

<option
    value="inactive"
    <?= $status === 'inactive'
        ? 'selected'
        : ''; ?>
>
    Inactive
</option>

<option
    value="blocked"
    <?= $status === 'blocked'
        ? 'selected'
        : ''; ?>
>
    Blocked
</option>

</select>


<select
    name="verified"
    class="control"
>

<option value="">
    All Verification
</option>

<option
    value="1"
    <?= $verified === '1'
        ? 'selected'
        : ''; ?>
>
    Email Verified
</option>

<option
    value="0"
    <?= $verified === '0'
        ? 'selected'
        : ''; ?>
>
    Not Verified
</option>

</select>


<button
    type="submit"
    class="filter-btn"
>

<i class="fa-solid fa-magnifying-glass"></i>

Search

</button>

</form>
  <?php if ($search !== '' || $status !== '' || $verified !== ''): ?>
  <a href="<?= e(BASE_URL . 'admin-customers.php'); ?>" class="clear-filter cm-reset-filter" title="Clear current filters"><i class="fa-solid fa-xmark" aria-hidden="true"></i> Reset</a>
  <?php endif; ?>
 </div>
 <div class="cm-result-strip"><span>Showing <?= count($users); ?> on this page<?php if ($totalRows > count($users)): ?> · <?= number_format((int)$totalRows); ?> matching in total<?php endif; ?></span><span><i class="fa-solid fa-arrows-left-right" aria-hidden="true"></i> Horizontal scroll on smaller screens</span></div>
 <div class="cm-list-body">
<?php if ($users): ?>

<div class="table-wrap cm-table-wrap" role="region" aria-label="Customer directory table" tabindex="0">

<table class="customer-table">

<thead>
<tr>
    <th>Customer</th>
    <th>Contact</th>
    <th>Country</th>
    <th>Verification</th>
    <th>Status</th>
    <th>Bookings</th>
    <th>Booking Value</th>
    <th>Registered</th>
    <th>Last Login</th>
    <th>Action</th>
</tr>
</thead>

<tbody>

<?php foreach ($users as $user): ?>

<?php
$totalBookings = (int)$user['total_bookings'];
$totalBookingValue = (float)$user['total_booking_value'];
$totalPaid = (float)$user['total_paid'];
$pendingBookings = (int)$user['pending_bookings'];
$confirmedBookings = (int)$user['confirmed_bookings'];
$completedBookings = (int)$user['completed_bookings'];
?>

<tr>

<td>
    <div class="customer-person-row">
        <div class="customer-avatar">
            <?= e(strtoupper(mb_substr($user['full_name'], 0, 1))); ?>
        </div>
        <div style="min-width:0;">
            <div class="customer-name"><?= e($user['full_name']); ?></div>
            <div class="subtext">Customer #<?= (int)$user['id']; ?></div>
        </div>
    </div>
</td>

<td>
    <div><?= e($user['email']); ?></div>
    <div class="subtext">
        <i class="fa-solid fa-phone"></i>
        <?= e($user['mobile'] ?: 'Not provided'); ?>
    </div>
</td>

<td>
    <?= e($user['country'] ?: 'Not provided'); ?>
</td>

<td>
    <?php if ((int)$user['email_verified'] === 1): ?>
        <span class="badge badge-blue">
            <i class="fa-solid fa-envelope-circle-check"></i> Verified
        </span>
    <?php else: ?>
        <span class="badge badge-warning">
            <i class="fa-solid fa-circle-exclamation"></i> Unverified
        </span>
    <?php endif; ?>
</td>

<td>
    <span class="badge badge-<?= e(userStatusClass($user['status'])); ?>">
        <?php if ($user['status'] === 'active'): ?>
            <i class="fa-solid fa-circle-check"></i>
        <?php elseif ($user['status'] === 'blocked'): ?>
            <i class="fa-solid fa-ban"></i>
        <?php else: ?>
            <i class="fa-regular fa-clock"></i>
        <?php endif; ?>
        <?= e(ucfirst($user['status'])); ?>
    </span>
</td>

<td>
    <div class="money-main"><?= number_format($totalBookings); ?></div>

    <?php if ($totalBookings > 0): ?>
        <div class="booking-counts">
            <?php if ($pendingBookings > 0): ?>
                <span class="mini-status pending"><?= $pendingBookings; ?> Pending</span>
            <?php endif; ?>

            <?php if ($confirmedBookings > 0): ?>
                <span class="mini-status confirmed"><?= $confirmedBookings; ?> Confirmed</span>
            <?php endif; ?>

            <?php if ($completedBookings > 0): ?>
                <span class="mini-status completed"><?= $completedBookings; ?> Completed</span>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</td>

<td>
    <div class="money-main">
        <?= e(adminUserMoney($totalBookingValue)); ?>
    </div>
    <div class="money-paid">
        Paid <?= e(adminUserMoney($totalPaid)); ?>
    </div>
</td>

<td>
    <?= e(adminUserDate($user['created_at'])); ?>
    <div class="subtext">
        Last booking: <?= e(adminUserDate($user['last_booking_date'])); ?>
    </div>
</td>

<td>
    <?= e(adminUserDate($user['last_login'], 'd M Y')); ?>
    <div class="subtext">
        <?= !empty($user['last_login'])
            ? e(adminUserDate($user['last_login'], 'h:i A'))
            : 'Never logged in'; ?>
    </div>
</td>

<td>
<div class="table-actions">

<a href="<?= e(BASE_URL . 'admin-customers.php?profile_id=' . (int)$user['id']); ?>" class="btn btn-profile">
    <i class="fa-regular fa-id-card"></i> Profile
</a>

<a
    href="<?= e(BASE_URL . 'admin-bookings.php?q=' . urlencode($user['email'])); ?>"
    class="btn btn-bookings"
>
    <i class="fa-solid fa-suitcase-rolling"></i>
    Bookings<?= $totalBookings > 0 ? ' (' . $totalBookings . ')' : ''; ?>
</a>

<?php if ($user['status'] === 'active'): ?>

<form
    method="post"
    onsubmit="return confirm('Block this customer account? The customer will not be able to use the account until it is activated again.');"
>
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
    <input type="hidden" name="action" value="change_status">
    <input type="hidden" name="user_id" value="<?= (int)$user['id']; ?>">
    <input type="hidden" name="new_status" value="blocked">

    <button type="submit" class="btn btn-block">
        <i class="fa-solid fa-user-lock"></i>
        Block
    </button>
</form>

<?php else: ?>

<form
    method="post"
    onsubmit="return confirm('Activate this customer account?');"
>
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
    <input type="hidden" name="action" value="change_status">
    <input type="hidden" name="user_id" value="<?= (int)$user['id']; ?>">
    <input type="hidden" name="new_status" value="active">

    <button type="submit" class="btn btn-activate">
        <i class="fa-solid fa-user-check"></i>
        Activate
    </button>
</form>

<?php endif; ?>

<form
    method="post"
    class="customer-delete-form"

>
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
    <input type="hidden" name="action" value="delete_customer">
    <input type="hidden" name="user_id" value="<?= (int)$user['id']; ?>">

    <button type="submit" class="btn btn-delete-customer">
        <i class="fa-solid fa-trash-can"></i>
        Delete
    </button>
</form>

</div>
</td>

</tr>

<?php endforeach; ?>

</tbody>
</table>
</div>

<!-- PAGINATION -->

<?php if ($totalPages > 1): ?>

<div class="pagination">


<?php if ($page > 1): ?>

<a
    href="<?= e(
        adminCustomersPageUrl(
            $page - 1
        )
    ); ?>"
    class="page-btn"
>

<i class="fa-solid fa-chevron-left"></i>

</a>

<?php endif; ?>


<?php

$startPage =
    max(
        1,
        $page - 2
    );

$endPage =
    min(
        $totalPages,
        $page + 2
    );

?>


<?php for (
    $i = $startPage;
    $i <= $endPage;
    $i++
): ?>


<a
    href="<?= e(
        adminCustomersPageUrl($i)
    ); ?>"
    class="
        page-btn
        <?= $i === $page
            ? 'active'
            : ''; ?>
    "
>

<?= $i; ?>

</a>


<?php endfor; ?>


<?php if ($page < $totalPages): ?>

<a
    href="<?= e(
        adminCustomersPageUrl(
            $page + 1
        )
    ); ?>"
    class="page-btn"
>

<i class="fa-solid fa-chevron-right"></i>

</a>

<?php endif; ?>


</div>

<?php endif; ?>


<?php else: ?>


<div class="empty">


<div class="empty-icon">

<i class="fa-solid fa-users-slash"></i>

</div>


<h3>
    No customers found
</h3>


<p>
    Registered customers will automatically appear here.
</p>


<?php if (
    $search !== '' ||
    $status !== '' ||
    $verified !== ''
): ?>

<div style="margin-top:14px;">

<a
    href="<?= e(BASE_URL . 'admin-customers.php'); ?>"
    class="btn btn-details"
>

<i class="fa-solid fa-rotate-left"></i>

Clear Filters

</a>

</div>

<?php endif; ?>


</div>


<?php endif; ?>

 </div>
</section>




<?php endif; ?>


<?php if(!$profileCustomer): ?>
<div class="manual-customer-modal" id="manualCustomerModal" aria-hidden="true">

    <div class="manual-customer-backdrop" data-close-manual-customer></div>

    <div
        class="manual-customer-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="manualCustomerTitle"
    >

        <div class="manual-customer-head">

            <div class="manual-customer-title">
                <span class="manual-customer-icon">
                    <i class="fa-solid fa-user-plus"></i>
                </span>
                <div>
                    <h2 id="manualCustomerTitle">Add Customer</h2>
                    <p>Create a customer manually and continue managing the profile.</p>
                </div>
            </div>

            <button
                type="button"
                class="manual-customer-close"
                data-close-manual-customer
                aria-label="Close"
            >
                <i class="fa-solid fa-xmark"></i>
            </button>

        </div>

        <form method="post" class="manual-customer-form">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($csrfToken); ?>"
            >

            <input
                type="hidden"
                name="action"
                value="add_customer"
            >

            <div class="manual-customer-grid">

                <div class="manual-field manual-field-blue">
                    <div class="manual-field-icon">
                        <i class="fa-solid fa-user"></i>
                    </div>
                    <div class="manual-field-content">
                        <label>Customer Name *</label>
                        <input
                            type="text"
                            name="customer_full_name"
                            placeholder="Full customer name"
                            maxlength="190"
                            required
                            autocomplete="name"
                        >
                    </div>
                </div>

                <div class="manual-field manual-field-green">
                    <div class="manual-field-icon">
                        <i class="fa-solid fa-envelope"></i>
                    </div>
                    <div class="manual-field-content">
                        <label>Email Address *</label>
                        <input
                            type="email"
                            name="customer_email"
                            placeholder="customer@example.com"
                            maxlength="190"
                            required
                            autocomplete="email"
                        >
                    </div>
                </div>

                <div class="manual-field manual-field-purple">
                    <div class="manual-field-icon">
                        <i class="fa-solid fa-phone"></i>
                    </div>
                    <div class="manual-field-content">
                        <label>Phone / WhatsApp</label>
                        <input
                            type="text"
                            name="customer_mobile"
                            placeholder="+91 98765 43210"
                            maxlength="30"
                            autocomplete="tel"
                        >
                    </div>
                </div>

                <div class="manual-field manual-field-orange">
                    <div class="manual-field-icon">
                        <i class="fa-solid fa-earth-asia"></i>
                    </div>
                    <div class="manual-field-content">
                        <label>Country</label>
                        <input
                            type="text"
                            name="customer_country"
                            value="India"
                            placeholder="Country"
                            maxlength="100"
                            autocomplete="country-name"
                        >
                    </div>
                </div>

                <div class="manual-field manual-field-cyan">
                    <div class="manual-field-icon">
                        <i class="fa-solid fa-circle-check"></i>
                    </div>
                    <div class="manual-field-content">
                        <label>Account Status</label>
                        <select name="customer_status">
                            <option value="active" selected>Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="blocked">Blocked</option>
                        </select>
                    </div>
                </div>

                <div class="manual-field manual-field-rose">
                    <div class="manual-field-icon">
                        <i class="fa-solid fa-key"></i>
                    </div>
                    <div class="manual-field-content">
                        <label>Temporary Password</label>
                        <input
                            type="text"
                            name="customer_password"
                            placeholder="Optional — auto generated if blank"
                            minlength="6"
                            maxlength="100"
                            autocomplete="new-password"
                        >
                    </div>
                </div>

            </div>

            <label class="manual-verified-card">
                <span class="manual-verified-icon">
                    <i class="fa-solid fa-shield-check"></i>
                </span>
                <span class="manual-verified-copy">
                    <strong>Email already verified</strong>
                    <small>Enable only when the email address has already been verified by your team.</small>
                </span>
                <span class="manual-switch">
                    <input
                        type="checkbox"
                        name="customer_email_verified"
                        value="1"
                    >
                    <span></span>
                </span>
            </label>

            <div class="manual-customer-footer">

                <div class="manual-customer-note">
                    <i class="fa-solid fa-circle-info"></i>
                    Duplicate email or mobile numbers will not create another customer.
                </div>

                <div class="manual-customer-actions">

                    <button
                        type="button"
                        class="manual-cancel-btn"
                        data-close-manual-customer
                    >
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="manual-save-btn"
                    >
                        <i class="fa-solid fa-user-check"></i>
                        Create Customer
                    </button>

                </div>

            </div>

        </form>

    </div>

</div>
<?php endif; ?>

</main>

</div>


<script>

/*
|--------------------------------------------------------------------------
| PREVENT DOUBLE SUBMISSION
|--------------------------------------------------------------------------
*/

document.querySelectorAll(
    'form[method="post"]'
).forEach(function(form){

    form.addEventListener(
        'submit',
        function(){

            const button =
                this.querySelector(
                    'button[type="submit"]'
                );

            if (!button) {
                return;
            }

            setTimeout(
                function(){

                    button.disabled = true;

                    button.style.opacity =
                        '.65';

                    button.style.cursor =
                        'not-allowed';

                },
                20
            );
        }
    );
});

</script>


<script>
(function () {
    const type = document.getElementById('adminDocumentType');
    if (!type) return;

    const numberLabel = document.getElementById('adminDocumentNumberLabel');
    const numberInput = document.getElementById('adminDocumentNumber');
    const fileLabel = document.getElementById('adminDocumentFileLabel');
    const fileNote = document.getElementById('adminDocumentFileNote');

    const labels = {
        'Aadhaar Card': ['Aadhaar Number','Upload Aadhaar Card File'],
        'PAN Card': ['PAN Number','Upload PAN Card File'],
        'Voter ID': ['Voter ID Number','Upload Voter ID File'],
        'Driving Licence': ['Driving Licence Number','Upload Driving Licence File'],
        'National ID': ['National ID Number','Upload National ID File'],
        'Birth Certificate': ['Certificate Number','Upload Birth Certificate File'],
        'Passport': ['Passport Number','Upload Passport File'],
        'Visa': ['Visa Number / Reference','Upload Visa File'],
        'Travel Insurance': ['Policy Number','Upload Travel Insurance File'],
        'Flight Ticket': ['PNR / Ticket Number','Upload Flight Ticket File'],
        'Hotel Voucher': ['Booking / Voucher Number','Upload Hotel Voucher File'],
        'Vaccination Certificate': ['Certificate Number','Upload Vaccination Certificate File'],
        'Other Travel Document': ['Document Number / Reference','Upload Travel Document File']
    };

    function sync() {
        const d = labels[type.value] || ['Document Number / Reference','Upload Document File'];
        if (numberLabel) numberLabel.textContent = d[0];
        if (numberInput) numberInput.placeholder = 'Enter ' + d[0].toLowerCase();
        if (fileLabel) fileLabel.textContent = d[1] + ' *';
        if (fileNote) fileNote.textContent = 'Choose the respective ' + (type.value || 'document') + ' PDF/JPG/PNG/WEBP file. Maximum 8 MB.';
    }

    type.addEventListener('change', sync);
    sync();
})();
</script>



<script>
(function(){
    const manager=document.getElementById('customer-profile-manager');
    if(!manager) return;

    document.body.classList.add('profile-open');

    const tabs=[...manager.querySelectorAll('.profile-workspace-tab')];
    const overview=manager.querySelector('[data-profile-panel="overview"]');
    const sections=[...manager.querySelectorAll('.pm-section[data-profile-panel]')];

    function activate(name, updateHash){
        tabs.forEach(btn=>btn.classList.toggle('active',btn.dataset.profileTab===name));
        if(overview) overview.style.display=(name==='overview'?'grid':'none');
        sections.forEach(section=>{
            section.classList.toggle('profile-section-active',section.dataset.profilePanel===name);
        });

        if(updateHash){
            const hash=name==='documents'?'#identity-documents':'#profile-'+name;
            history.replaceState(null,'',location.pathname+location.search+hash);
        }
    }

    tabs.forEach(btn=>{
        btn.addEventListener('click',()=>activate(btn.dataset.profileTab,true));
    });

    let initial='overview';
    if(location.hash==='#identity-documents') initial='documents';
    else if(location.hash==='#profile-personal') initial='personal';
    else if(location.hash==='#profile-family') initial='family';
    else if (<?= $familySearchTerm !== '' ? 'true' : 'false'; ?>) initial='family';

    activate(initial,false);
})();
</script>



<script>
(function(){
    const modal=document.getElementById('manualCustomerModal');
    const openBtn=document.getElementById('openManualCustomer');

    if(!modal || !openBtn) return;

    const closeButtons=modal.querySelectorAll('[data-close-manual-customer]');
    const firstInput=modal.querySelector('input[name="customer_full_name"]');

    function openModal(){
        modal.classList.add('open');
        modal.setAttribute('aria-hidden','false');
        document.body.classList.add('manual-customer-open');
        setTimeout(()=>firstInput?.focus(),50);
    }

    function closeModal(){
        modal.classList.remove('open');
        modal.setAttribute('aria-hidden','true');
        document.body.classList.remove('manual-customer-open');
        openBtn.focus();
    }

    openBtn.addEventListener('click',openModal);
    closeButtons.forEach(btn=>btn.addEventListener('click',closeModal));

    document.addEventListener('keydown',function(event){
        if(event.key==='Escape' && modal.classList.contains('open')){
            closeModal();
        }
    });
})();
</script>







<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
<script id="travscope-v2431-customer-script">
(function(){
    document.querySelectorAll('[data-go-profile-tab]').forEach(function(b){
        b.addEventListener('click',function(){
            const name=b.dataset.goProfileTab;
            const tab=document.querySelector('.profile-workspace-tab[data-profile-tab="'+name+'"]');
            if(tab) tab.click();
        });
    });
    // Search the complete customer directory and reopen Family tab when results load.
    const familySearch=document.querySelector('.pm-family-search-form');
    if(familySearch){familySearch.addEventListener('submit',function(){
        let target=familySearch.querySelector('input[name="family_search"]');
        if(target) target.value=target.value.trim();
    });}
    /* V24.32 – dependent country → state → district → city dropdowns. */
    const csrfToken=<?= json_encode($csrfToken, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_QUOT | JSON_HEX_APOS); ?>;
    const steps={
        country:{select:document.getElementById('pmAddressCountrySelect'),manual:document.getElementById('pmAddressCountryManual'),value:document.getElementById('pmAddressCountry')},
        state:{select:document.getElementById('pmAddressStateSelect'),manual:document.getElementById('pmAddressStateManual'),value:document.getElementById('pmAddressState')},
        district:{select:document.getElementById('pmAddressDistrictSelect'),manual:document.getElementById('pmAddressDistrictManual'),value:document.getElementById('pmAddressDistrict')},
        city:{select:document.getElementById('pmAddressCitySelect'),manual:document.getElementById('pmAddressCityManual'),value:document.getElementById('pmAddressCity')}
    };
    if(!Object.values(steps).every(x=>x.select&&x.manual&&x.value))return;
    const notes={state:document.getElementById('pmStateHint'),district:document.getElementById('pmDistrictHint'),city:document.getElementById('pmCityHint')};
    const feedback=document.getElementById('pmGeoFeedback');
    const filter=document.getElementById('pmCityFilter');
    const initial=Object.fromEntries(Object.entries(steps).map(([k,x])=>[k,x.value.value.trim()]));
    let cityOptions=[],fullCityOptions=[],geoRequest=0;
    const say=(msg,error=false)=>{if(feedback){feedback.textContent=msg;feedback.classList.toggle('error',error);}};
    function value(k){return steps[k].value.value.trim();}
    function clear(k,help){
        const x=steps[k];x.value.value='';x.manual.hidden=true;x.manual.value='';x.select.disabled=true;
        x.select.replaceChildren(new Option(help,''));if(k==='city'){cityOptions=[];fullCityOptions=[];filter.value='';filter.hidden=true;}
    }
    function showManual(k,seed=''){
        const x=steps[k];x.select.disabled=false;
        if(!Array.from(x.select.options).some(o=>o.value==='__manual__'))x.select.add(new Option('Other / Enter manually','__manual__'));
        x.select.value='__manual__';x.manual.hidden=false;x.manual.value=seed;x.value.value=seed;
    }
    function setChoices(k,items,persisted,help,manualHint=false){
        const x=steps[k],names=[...new Set(items.filter(n=>typeof n==='string'&&n.trim()).map(n=>n.trim()))];
        x.select.replaceChildren(new Option(help,''));
        for(const n of names)x.select.add(new Option(n,n));
        x.select.add(new Option('Other / Not listed – type manually','__manual__'));
        x.select.disabled=false;x.manual.hidden=true;x.manual.value='';x.value.value='';
        if(persisted){
            const hit=names.find(n=>n.toLocaleLowerCase()===persisted.toLocaleLowerCase());
            if(hit){x.select.value=hit;x.value.value=hit;}
            else{ x.select.add(new Option(persisted+' (previously saved)',persisted));x.select.value=persisted;x.value.value=persisted; }
        } else if(manualHint && names.length===0){showManual(k);}
        if(k==='city'){cityOptions=names;fullCityOptions=[...names];filter.hidden=names.length<15;}
    }
    const api=async(action,params={},request)=>{
        const qs=new URLSearchParams({action,...params});
        const res=await fetch('admin-customer-geo.php?'+qs.toString(),{
            headers:{'Accept':'application/json','X-CSRF-Token':csrfToken},credentials:'same-origin'
        });
        const obj=await res.json();
        if(!res.ok)throw new Error(obj.error||'Location service unavailable');
        if(request!==geoRequest)return null;
        return obj;
    };
    async function loadStates(saved='',request=++geoRequest){
        clear('state','Loading states...');clear('district','Choose state first');clear('city','Choose district first');
        if(!value('country')){clear('state','Choose country first');return;}
        say('Loading states / provinces for '+value('country')+'...');
        try{
            const obj=await api('states',{country:value('country')},request);if(!obj)return;
            setChoices('state',obj.items||[],saved,'Choose state / province',!!obj.manual);
            notes.state.textContent=obj.message||'Choose a state / province.';say(obj.message||'Choose your state / province.');
            if(saved) await loadDistricts(initial.district||'',request);
        }catch(err){if(request!==geoRequest)return;setChoices('state',[],saved,'No directory – enter manually',true);say(err.message+'. Type the state manually.',true);if(saved)await loadDistricts(initial.district||'',request);}
    }
    async function loadDistricts(saved='',request=++geoRequest){
        clear('district','Loading districts...');clear('city','Choose district first');
        if(!value('state')){clear('district','Choose state first');return;}
        say('Loading districts for '+value('state')+'...');
        try{
            const obj=await api('districts',{country:value('country'),state:value('state')},request);if(!obj)return;
            setChoices('district',obj.items||[],saved,'Choose district / administrative area',!!obj.manual);
            notes.district.textContent=obj.message||'Choose or type the district.';
            say(obj.message||'Choose or enter your district.');
            // A country may not have a district directory; city suggestions remain accessible.
            if(obj.manual && !(obj.items||[]).length && !saved) {
                steps.district.value.value='';
                await loadCities('',request);
            } else if(saved) await loadCities(initial.city||'',request);
        }catch(err){if(request!==geoRequest)return;setChoices('district',[],saved,'Enter district manually',true);say(err.message+'. Type district if applicable.',true);await loadCities(initial.city||'',request);}
    }
    async function loadCities(saved='',request=++geoRequest){
        clear('city','Loading cities / localities...');
        if(!value('state')){clear('city','Choose state first');return;}
        say('Loading city suggestions for '+value('state')+'...');
        try{
            const obj=await api('cities',{country:value('country'),state:value('state'),district:value('district')},request);if(!obj)return;
            setChoices('city',obj.items||[],saved,'Choose city / locality',!!obj.manual);
            notes.city.textContent=obj.message||'Select a city or locality.';
            say(obj.message||'Select a city, then save the profile.');
        }catch(err){if(request!==geoRequest)return;setChoices('city',[],saved,'Type city manually',true);say(err.message+'. Type the city / locality manually.',true);}
    }
    Object.keys(steps).forEach(k=>{
        const x=steps[k];
        x.manual.addEventListener('input',()=>{
            x.value.value=x.manual.value.trim();
        });
    });
    steps.country.select.addEventListener('change',()=>{
        if(steps.country.select.value==='__manual__')showManual('country');
        else{steps.country.manual.hidden=true;steps.country.value.value=steps.country.select.value;}
        loadStates('');
    });
    steps.country.manual.addEventListener('change',()=>loadStates(''));
    steps.state.select.addEventListener('change',()=>{
        if(steps.state.select.value==='__manual__')showManual('state');
        else{steps.state.manual.hidden=true;steps.state.value.value=steps.state.select.value;}
        loadDistricts('');
    });
    steps.state.manual.addEventListener('change',()=>loadDistricts(''));
    steps.district.select.addEventListener('change',()=>{
        if(steps.district.select.value==='__manual__')showManual('district');
        else{steps.district.manual.hidden=true;steps.district.value.value=steps.district.select.value;}
        loadCities('');
    });
    steps.district.manual.addEventListener('change',()=>loadCities(''));
    steps.city.select.addEventListener('change',()=>{
        if(steps.city.select.value==='__manual__')showManual('city');
        else{steps.city.manual.hidden=true;steps.city.value.value=steps.city.select.value;}
    });
    if(filter)filter.addEventListener('input',()=>{
        const query=filter.value.trim().toLocaleLowerCase();
        const x=steps.city,selected=x.value.value;
        const shown=fullCityOptions.filter(n=>n.toLocaleLowerCase().includes(query)).slice(0,600);
        x.select.replaceChildren(new Option('Choose matching city / locality',''));
        shown.forEach(n=>x.select.add(new Option(n,n)));
        if(selected && !shown.some(n=>n.toLocaleLowerCase()===selected.toLocaleLowerCase())){
            x.select.add(new Option(selected+' (current selection)',selected));
        }
        x.select.add(new Option('Other / Not listed – type manually','__manual__'));
        if(x.manual.hidden && selected)x.select.value=selected;
        else if(!x.manual.hidden)x.select.value='__manual__';
    });
    document.querySelector('.pm-section[data-profile-panel="personal"] form')?.addEventListener('submit',e=>{
        for(const [k,x] of Object.entries(steps)){
            if(x.select.value==='__manual__')x.value.value=x.manual.value.trim();
        }
        if(!value('country')){e.preventDefault();say('Please choose the country before saving the profile.',true);steps.country.select.focus();}
    });
    const countryInitial=initial.country||'India';
    const listed=Array.from(steps.country.select.options).find(o=>o.value.toLocaleLowerCase()===countryInitial.toLocaleLowerCase());
    if(listed){steps.country.select.value=listed.value;steps.country.value.value=listed.value;}
    else showManual('country',countryInitial);
    loadStates(initial.state||'');
})();
</script>
</body>
</html>