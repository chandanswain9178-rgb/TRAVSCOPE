<?php
declare(strict_types=1);

/**
 * TRAVSCOPE Hotel Google Places helper (V18)
 *
 * The API key stays server-side. Configure GOOGLE_PLACES_API_KEY in config.php
 * or as an environment variable. No key is exposed to browser JavaScript.
 */

if (!function_exists('tsHotelGoogleApiKey')) {
    function tsHotelGoogleApiKey(): string
    {
        if (defined('GOOGLE_PLACES_API_KEY')) {
            return trim((string) constant('GOOGLE_PLACES_API_KEY'));
        }
        $env = getenv('GOOGLE_PLACES_API_KEY');
        return is_string($env) ? trim($env) : '';
    }
}

if (!function_exists('tsHotelGoogleConfigured')) {
    function tsHotelGoogleConfigured(): bool
    {
        return tsHotelGoogleApiKey() !== '';
    }
}

if (!function_exists('tsHotelGoogleHttpJson')) {
    function tsHotelGoogleHttpJson(string $method, string $url, array $headers = [], ?array $body = null, int $timeout = 8): array
    {
        $method = strtoupper($method);
        $payload = $body !== null ? json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
        if ($payload === false) {
            throw new RuntimeException('Unable to encode Google Places request.');
        }

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            if ($ch === false) throw new RuntimeException('Unable to start HTTP request.');
            $headerLines = [];
            foreach ($headers as $k => $v) $headerLines[] = $k . ': ' . $v;
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_CUSTOMREQUEST => $method,
                CURLOPT_HTTPHEADER => $headerLines,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_USERAGENT => 'TRAVSCOPE-HotelMaster/18',
            ]);
            if ($payload !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            $raw = curl_exec($ch);
            $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $err = curl_error($ch);
            curl_close($ch);
            if ($raw === false || $status < 200 || $status >= 300) {
                throw new RuntimeException('Google Places request failed' . ($status ? ' (HTTP ' . $status . ')' : '') . ($err ? ': ' . $err : '.'));
            }
        } else {
            $headerLines = [];
            foreach ($headers as $k => $v) $headerLines[] = $k . ': ' . $v;
            $opts = [
                'http' => [
                    'method' => $method,
                    'timeout' => $timeout,
                    'ignore_errors' => true,
                    'header' => implode("\r\n", $headerLines),
                ]
            ];
            if ($payload !== null) $opts['http']['content'] = $payload;
            $raw = @file_get_contents($url, false, stream_context_create($opts));
            if ($raw === false) throw new RuntimeException('Google Places request failed.');
        }

        $decoded = json_decode((string)$raw, true);
        if (!is_array($decoded)) throw new RuntimeException('Invalid Google Places response.');
        if (!empty($decoded['error']['message'])) throw new RuntimeException((string)$decoded['error']['message']);
        return $decoded;
    }
}

if (!function_exists('tsHotelGooglePostalCode')) {
    function tsHotelGooglePostalCode(array $place): string
    {
        foreach (($place['addressComponents'] ?? []) as $component) {
            $types = $component['types'] ?? [];
            if (is_array($types) && in_array('postal_code', $types, true)) {
                return trim((string)($component['longText'] ?? $component['shortText'] ?? ''));
            }
        }
        return '';
    }
}

if (!function_exists('tsHotelGoogleSearch')) {
    function tsHotelGoogleSearch(string $query, string $city = '', string $state = '', string $country = '', int $limit = 8): array
    {
        $key = tsHotelGoogleApiKey();
        if ($key === '') return [];
        $query = trim(preg_replace('/\s+/', ' ', $query) ?? $query);
        if ($query === '') return [];

        $where = array_values(array_filter([$city, $state, $country], static fn($v) => trim((string)$v) !== ''));
        $textQuery = $query . ' hotel';
        if ($where) $textQuery .= ' in ' . implode(', ', $where);

        $limit = max(1, min(10, $limit));
        $fieldMask = implode(',', [
            'places.id',
            'places.displayName',
            'places.formattedAddress',
            'places.addressComponents',
            'places.location',
            'places.googleMapsUri',
            'places.websiteUri',
            'places.internationalPhoneNumber',
            'places.nationalPhoneNumber',
            'places.rating',
            'places.userRatingCount',
            'places.photos',
            'places.types',
        ]);

        $data = tsHotelGoogleHttpJson(
            'POST',
            'https://places.googleapis.com/v1/places:searchText',
            [
                'Content-Type' => 'application/json',
                'X-Goog-Api-Key' => $key,
                'X-Goog-FieldMask' => $fieldMask,
            ],
            [
                'textQuery' => $textQuery,
                'pageSize' => $limit,
                'languageCode' => 'en',
            ]
        );

        $rows = [];
        foreach (($data['places'] ?? []) as $place) {
            if (!is_array($place)) continue;
            $types = array_map('strval', is_array($place['types'] ?? null) ? $place['types'] : []);
            // The text query already asks for hotels. Keep lodging-like results and do not
            // reject a valid hotel just because Google omitted a hotel type in one response.
            $name = trim((string)($place['displayName']['text'] ?? ''));
            if ($name === '') continue;
            $photoName = '';
            $photoAttribution = '';
            if (!empty($place['photos'][0]['name'])) $photoName = (string)$place['photos'][0]['name'];
            if (!empty($place['photos'][0]['authorAttributions']) && is_array($place['photos'][0]['authorAttributions'])) {
                $names=[];
                foreach ($place['photos'][0]['authorAttributions'] as $attr) {
                    $n=trim((string)($attr['displayName']??''));
                    if($n!=='')$names[]=$n;
                }
                if($names)$photoAttribution=implode(', ',array_unique($names));
            }
            $rows[] = [
                'source' => 'google',
                'place_id' => trim((string)($place['id'] ?? '')),
                'name' => $name,
                'address' => trim((string)($place['formattedAddress'] ?? '')),
                'pincode' => tsHotelGooglePostalCode($place),
                'phone' => trim((string)($place['internationalPhoneNumber'] ?? $place['nationalPhoneNumber'] ?? '')),
                'website' => trim((string)($place['websiteUri'] ?? '')),
                'google_maps_url' => trim((string)($place['googleMapsUri'] ?? '')),
                'latitude' => isset($place['location']['latitude']) ? (float)$place['location']['latitude'] : null,
                'longitude' => isset($place['location']['longitude']) ? (float)$place['location']['longitude'] : null,
                'rating' => isset($place['rating']) ? (float)$place['rating'] : null,
                'rating_count' => isset($place['userRatingCount']) ? (int)$place['userRatingCount'] : 0,
                'photo_name' => $photoName,
                'photo_attribution' => $photoAttribution,
                'types' => $types,
            ];
        }
        return $rows;
    }
}

if (!function_exists('tsHotelGooglePhotoUrl')) {
    function tsHotelGooglePhotoUrl(string $photoName, int $maxWidth = 900, int $maxHeight = 700): string
    {
        $photoName = trim($photoName);
        if (!preg_match('~^places/[A-Za-z0-9_-]+/photos/[A-Za-z0-9_-]+$~', $photoName)) return '';
        $maxWidth = max(1, min(4800, $maxWidth));
        $maxHeight = max(1, min(4800, $maxHeight));
        return 'https://places.googleapis.com/v1/' . $photoName . '/media?maxWidthPx=' . $maxWidth . '&maxHeightPx=' . $maxHeight . '&skipHttpRedirect=false&key=' . rawurlencode(tsHotelGoogleApiKey());
    }
}

if (!function_exists('tsHotelGoogleDownloadPhoto')) {
    function tsHotelGoogleDownloadPhoto(string $photoName, string $hotelName = ''): ?string
    {
        if (!tsHotelGoogleConfigured()) return null;
        $url = tsHotelGooglePhotoUrl($photoName, 1400, 1000);
        if ($url === '') return null;
        $bytes = null;
        $mime = '';

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            if ($ch !== false) {
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_CONNECTTIMEOUT => 5,
                    CURLOPT_TIMEOUT => 12,
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_SSL_VERIFYHOST => 2,
                    CURLOPT_USERAGENT => 'TRAVSCOPE-HotelMaster/18',
                ]);
                $raw = curl_exec($ch);
                $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                $mime = trim((string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE));
                curl_close($ch);
                if ($raw !== false && $status >= 200 && $status < 300) $bytes = $raw;
            }
        }
        if ($bytes === null) {
            $ctx = stream_context_create(['http'=>['timeout'=>12,'follow_location'=>1,'user_agent'=>'TRAVSCOPE-HotelMaster/18']]);
            $raw = @file_get_contents($url, false, $ctx);
            if ($raw !== false) $bytes = $raw;
        }
        if (!is_string($bytes) || strlen($bytes) < 1000 || strlen($bytes) > 10*1024*1024) return null;

        $tmp = tempnam(sys_get_temp_dir(), 'ts-hotel-photo-');
        if ($tmp === false) return null;
        file_put_contents($tmp, $bytes);
        try {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $detected = (string)$finfo->file($tmp);
        } finally {
            @unlink($tmp);
        }
        $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
        if (!isset($allowed[$detected])) return null;

        $dir = __DIR__ . '/uploads/hotels/';
        if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) return null;
        $safe = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $hotelName) ?? '', '-'));
        if ($safe === '') $safe = 'hotel';
        $name = $safe . '-google-' . date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.' . $allowed[$detected];
        if (file_put_contents($dir . $name, $bytes) === false) return null;
        return 'uploads/hotels/' . $name;
    }
}
