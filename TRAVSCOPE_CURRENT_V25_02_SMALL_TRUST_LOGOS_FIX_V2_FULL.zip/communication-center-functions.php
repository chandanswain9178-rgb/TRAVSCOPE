<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE STEP 11E - SHARED COMMUNICATION CENTER
|--------------------------------------------------------------------------
| Normalizes inbound/outbound email conversations without replacing the
| existing CRM quotation, supplier request or booking communication tables.
*/

/**
 * Probe an exact table with the SAME PDO account used by this admin page.
 * SELECT ... LIMIT 0 fetches no customer data, but verifies that the table
 * exists in the connected database and the website account can read it.
 * Avoid SHOW TABLES LIKE ? (driver-dependent native-prepared behaviour).
 */
function tsCommTableProbe(PDO $pdo, string $table): array
{
    if (!preg_match('/\A[a-zA-Z0-9_]+\z/D', $table)) {
        return ['ok'=>false, 'reason'=>'Invalid table identifier'];
    }
    try {
        $stmt = $pdo->query('SELECT 1 FROM `'.$table.'` LIMIT 0');
        if ($stmt === false) {
            return ['ok'=>false, 'reason'=>'SQL access check failed'];
        }
        return ['ok'=>true, 'reason'=>'Available'];
    } catch (PDOException $e) {
        $number = isset($e->errorInfo[1]) ? (int)$e->errorInfo[1] : 0;
        $state = (string)$e->getCode();
        if ($number === 1146 || $state === '42S02') {
            $reason = 'Missing from the connected database (MySQL 1146)';
        } elseif (in_array($number, [1044, 1045, 1142, 1227], true) || $state === '42000' || $state === '28000') {
            $reason = 'Database user has insufficient permission (MySQL '.($number ?: $state).')';
        } else {
            $reason = 'SQL check failed (SQLSTATE '.$state.($number ? ', MySQL '.$number : '').')';
        }
        error_log('TRAVSCOPE Communication Center access check: '.$table.'; SQLSTATE '.$state.'; MySQL '.$number);
        return ['ok'=>false, 'reason'=>$reason];
    } catch (Throwable $e) {
        error_log('TRAVSCOPE Communication Center table check: '.$table.'; '.get_class($e));
        return ['ok'=>false, 'reason'=>'Unable to check database access'];
    }
}

function tsCommTableExists(PDO $pdo, string $table): bool
{
    return tsCommTableProbe($pdo, $table)['ok'];
}

function tsCommReady(PDO $pdo): bool
{
    return tsCommTableExists($pdo,'communication_inbox_messages')
        && tsCommTableExists($pdo,'communication_attachments')
        && tsCommTableExists($pdo,'communication_sync_state');
}

function tsCommPrivateRoot(): string
{
    $root=defined('TRAVSCOPE_PRIVATE_STORAGE_DIR')
        ? trim((string)TRAVSCOPE_PRIVATE_STORAGE_DIR)
        : dirname(__DIR__).'/travscope-private';
    if($root==='') throw new RuntimeException('TRAVSCOPE private storage path is not configured.');
    return rtrim($root,'/\\');
}

function tsCommAttachmentDir(): string
{
    $dir=tsCommPrivateRoot().'/communication-attachments/'.date('Y').'/'.date('m');
    if(!is_dir($dir) && !@mkdir($dir,0750,true) && !is_dir($dir)){
        throw new RuntimeException('Unable to create private communication attachment storage.');
    }
    return $dir;
}

function tsCommStoredPath(string $relative): string
{
    $relative=ltrim(str_replace('\\','/',trim($relative)),'/');
    if($relative==='' || str_contains($relative,'..')) throw new RuntimeException('Invalid attachment path.');
    $root=tsCommPrivateRoot(); $full=$root.'/'.$relative;
    $rootReal=realpath($root); $fileReal=realpath($full);
    if(!$rootReal || !$fileReal || !is_file($fileReal)) throw new RuntimeException('Attachment is unavailable.');
    if(!str_starts_with($fileReal,rtrim($rootReal,DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR)){
        throw new RuntimeException('Attachment path is outside private storage.');
    }
    return $fileReal;
}

function tsCommDecodeHeader(string $value): string
{
    $value=trim($value); if($value==='') return '';
    if(!function_exists('imap_mime_header_decode')) return $value;
    $parts=@imap_mime_header_decode($value); if(!is_array($parts)) return $value;
    $out='';
    foreach($parts as $p){
        $chunk=(string)($p->text??''); $charset=strtoupper((string)($p->charset??''));
        if($charset!=='' && $charset!=='DEFAULT' && $charset!=='UTF-8' && function_exists('mb_convert_encoding')){
            $chunk=@mb_convert_encoding($chunk,'UTF-8',$charset) ?: $chunk;
        }
        $out.=$chunk;
    }
    return trim($out);
}

function tsCommDecodePart(string $raw, int $encoding): string
{
    if($encoding===3){ $d=base64_decode($raw,true); return $d!==false?$d:$raw; }
    if($encoding===4) return quoted_printable_decode($raw);
    return $raw;
}

function tsCommStructureFilename($part): string
{
    foreach([($part->dparameters??[]),($part->parameters??[])] as $params){
        if(!is_array($params)) continue;
        foreach($params as $p){
            $attr=strtolower((string)($p->attribute??''));
            if(in_array($attr,['filename','name'],true)) return tsCommDecodeHeader((string)($p->value??''));
        }
    }
    return '';
}

function tsCommMessageText($imap,int $messageNo,$structure,string $partNumber=''): string
{
    if(!$structure) return '';
    $type=(int)($structure->type??0); $sub=strtoupper((string)($structure->subtype??''));
    $filename=tsCommStructureFilename($structure);
    if($filename!=='') return '';
    if($type===0 && in_array($sub,['PLAIN','HTML'],true)){
        $raw=$partNumber!=='' ? (string)@imap_fetchbody($imap,$messageNo,$partNumber,FT_PEEK) : (string)@imap_body($imap,$messageNo,FT_PEEK);
        $body=tsCommDecodePart($raw,(int)($structure->encoding??0));
        if($sub==='HTML'){
            $body=preg_replace('/<(br|br\/|p|div|li)[^>]*>/i',"\n",$body)??$body;
            $body=html_entity_decode(strip_tags($body),ENT_QUOTES|ENT_HTML5,'UTF-8');
        }
        $body=str_replace(["\r\n","\r"],"\n",$body);
        return trim(preg_replace("/\n{3,}/","\n\n",$body)??$body);
    }
    if(!empty($structure->parts) && is_array($structure->parts)){
        $plain='';$other='';
        foreach($structure->parts as $i=>$part){
            $child=$partNumber===''?(string)($i+1):$partNumber.'.'.($i+1);
            $content=tsCommMessageText($imap,$messageNo,$part,$child); if($content==='') continue;
            $s=strtoupper((string)($part->subtype??''));
            if($s==='PLAIN') $plain.=($plain!==''?"\n\n":'').$content;
            else $other.=($other!==''?"\n\n":'').$content;
        }
        return trim($plain!==''?$plain:$other);
    }
    return '';
}

/** Retain the HTML alternative of a MIME message (plain text is stored separately). */
function tsCommMessageHtml($imap,int $messageNo,$structure,string $partNumber=''): string
{
    if (!$structure || tsCommStructureFilename($structure)!=='') return '';
    $type=(int)($structure->type??-1);
    $sub=strtoupper((string)($structure->subtype??''));
    if ($type===0 && $sub==='HTML') {
        $raw=$partNumber!==''?(string)@imap_fetchbody($imap,$messageNo,$partNumber,FT_PEEK):(string)@imap_body($imap,$messageNo,FT_PEEK);
        $html=tsCommDecodePart($raw,(int)($structure->encoding??0));
        $charset='';
        foreach(($structure->parameters??[]) as $param) {
            if(strtolower((string)($param->attribute??''))==='charset') {$charset=(string)($param->value??'');break;}
        }
        if($charset!=='' && strcasecmp($charset,'UTF-8')!==0 && function_exists('mb_convert_encoding')) {
            try{$html=mb_convert_encoding($html,'UTF-8',$charset);}catch(Throwable $ignored){}
        }
        if(function_exists('mb_check_encoding') && !mb_check_encoding($html,'UTF-8')){
            $html=mb_convert_encoding($html,'UTF-8','UTF-8');
        }
        return strlen($html)<=2*1024*1024?trim($html):'';
    }
    foreach(($structure->parts??[]) as $i=>$part) {
        $child=$partNumber===''?(string)($i+1):$partNumber.'.'.($i+1);
        $html=tsCommMessageHtml($imap,$messageNo,$part,$child);
        if($html!=='')return $html;
    }
    return '';
}

/** Resolve small MIME inline images into data: URIs, avoiding live image requests. */
function tsCommEmbedCidImages($imap,int $messageNo,$structure,string $html,string $partNumber='',int &$remaining=1048576): string
{
    if(!$structure || $html==='' || stripos($html,'cid:')===false || $remaining<=0) return $html;
    $cid=trim((string)($structure->id??''),"<> \t\r\n");
    $type=(int)($structure->type??-1);
    $sub=strtoupper((string)($structure->subtype??''));
    $mime=['JPEG'=>'image/jpeg','JPG'=>'image/jpeg','PNG'=>'image/png','GIF'=>'image/gif','WEBP'=>'image/webp'];
    if($cid!=='' && $partNumber!=='' && $type===5 && isset($mime[$sub])) {
        $raw=(string)@imap_fetchbody($imap,$messageNo,$partNumber,FT_PEEK);
        $data=tsCommDecodePart($raw,(int)($structure->encoding??0));
        if($data!=='' && strlen($data)<=min($remaining,262144)) {
            $uri='data:'.$mime[$sub].';base64,'.base64_encode($data);
            $html=str_ireplace('cid:'.$cid,$uri,$html);
            $remaining-=strlen($data);
        }
    }
    foreach(($structure->parts??[]) as $i=>$part) {
        $child=$partNumber===''?(string)($i+1):$partNumber.'.'.($i+1);
        $html=tsCommEmbedCidImages($imap,$messageNo,$part,$html,$child,$remaining);
    }
    return $html;
}

function tsCommAddressFromHeader($addressList): array
{
    if(!is_array($addressList) || !$addressList) return ['name'=>'','email'=>''];
    $a=$addressList[0];
    $mailbox=(string)($a->mailbox??''); $host=(string)($a->host??'');
    $email=($mailbox!==''&&$host!=='')?$mailbox.'@'.$host:'';
    $name=tsCommDecodeHeader((string)($a->personal??''));
    return ['name'=>$name,'email'=>strtolower(trim($email))];
}

function tsCommNormalizeSubject(string $subject): string
{
    $subject=tsCommDecodeHeader($subject);
    $subject=preg_replace('/^\s*((re|fw|fwd)\s*:\s*)+/i','',$subject)??$subject;
    $subject=preg_replace('/\[TRAVSCOPE-[^\]]+\]/i','',$subject)??$subject;
    return trim(preg_replace('/\s+/',' ',$subject)??$subject);
}

function tsCommThreadTag(array $link): string
{
    if(!empty($link['quotation_version_id'])) return '[TRAVSCOPE-QV-'.(int)$link['quotation_version_id'].']';
    if(!empty($link['supplier_request_code'])) return '[TRAVSCOPE-SR-'.trim((string)$link['supplier_request_code']).']';
    if(!empty($link['booking_id'])) return '[TRAVSCOPE-BKG-'.(int)$link['booking_id'].']';
    if(!empty($link['trip_code'])) return '[TRAVSCOPE-TRIP-'.trim((string)$link['trip_code']).']';
    return '';
}

function tsCommAutoMatch(PDO $pdo,string $email,string $subject): array
{
    $email=strtolower(trim($email)); $subject=trim($subject);
    $m=[
        'party_type'=>'unknown','supplier_id'=>null,'supplier_request_id'=>null,'supplier_request_code'=>null,
        'enquiry_id'=>null,'trip_id'=>null,'trip_code'=>null,'quotation_version_id'=>null,'booking_id'=>null,
        'confidence'=>0,'notes'=>'No automatic match found.'
    ];

    if(preg_match('/\[TRAVSCOPE-QV-(\d+)\]/i',$subject,$x)){
        $id=(int)$x[1];
        $s=$pdo->prepare('SELECT v.id,v.lead_id,t.id trip_id,t.trip_code,qa.booking_id FROM crm_package_versions v LEFT JOIN trips t ON t.enquiry_id=v.lead_id LEFT JOIN quotation_acceptances qa ON qa.quotation_version_id=v.id WHERE v.id=? LIMIT 1');
        $s->execute([$id]); if($r=$s->fetch(PDO::FETCH_ASSOC)){
            return array_merge($m,['party_type'=>'customer','enquiry_id'=>(int)$r['lead_id'],'trip_id'=>$r['trip_id']?(int)$r['trip_id']:null,'trip_code'=>$r['trip_code']?:null,'quotation_version_id'=>$id,'booking_id'=>$r['booking_id']?(int)$r['booking_id']:null,'confidence'=>100,'notes'=>'Matched quotation thread tag.']);
        }
    }
    if(preg_match('/\[TRAVSCOPE-BKG-(\d+)\]/i',$subject,$x)){
        $bid=(int)$x[1]; $s=$pdo->prepare('SELECT id,customer_email FROM bookings WHERE id=? LIMIT 1');$s->execute([$bid]);
        if($s->fetch()) return array_merge($m,['party_type'=>'customer','booking_id'=>$bid,'confidence'=>100,'notes'=>'Matched booking thread tag.']);
    }
    if(preg_match('/\[TRAVSCOPE-SR-([^\]]+)\]/i',$subject,$x)){
        $code=trim($x[1]); $s=$pdo->prepare('SELECT id,supplier_id,trip_id,request_code FROM supplier_requests WHERE request_code=? LIMIT 1');$s->execute([$code]);
        if($r=$s->fetch(PDO::FETCH_ASSOC)) return array_merge($m,['party_type'=>'supplier','supplier_id'=>(int)$r['supplier_id'],'supplier_request_id'=>(int)$r['id'],'supplier_request_code'=>(string)$r['request_code'],'trip_id'=>$r['trip_id']?(int)$r['trip_id']:null,'confidence'=>100,'notes'=>'Matched supplier request thread tag.']);
    }
    if(preg_match('/\[TRAVSCOPE-TRIP-([^\]]+)\]/i',$subject,$x)){
        $code=trim($x[1]); $s=$pdo->prepare('SELECT id,enquiry_id,trip_code FROM trips WHERE trip_code=? LIMIT 1');$s->execute([$code]);
        if($r=$s->fetch(PDO::FETCH_ASSOC)) return array_merge($m,['party_type'=>'customer','enquiry_id'=>(int)$r['enquiry_id'],'trip_id'=>(int)$r['id'],'trip_code'=>(string)$r['trip_code'],'confidence'=>95,'notes'=>'Matched trip thread tag.']);
    }

    if($email!==''){
        $s=$pdo->prepare("SELECT s.id,s.company_name FROM supplier_contacts c JOIN suppliers s ON s.id=c.supplier_id WHERE LOWER(c.email)=LOWER(?) AND c.status='active' AND s.status='active' ORDER BY c.is_primary DESC,c.id ASC LIMIT 1");
        $s->execute([$email]);
        if($sup=$s->fetch(PDO::FETCH_ASSOC)){
            $m['party_type']='supplier';$m['supplier_id']=(int)$sup['id'];$m['confidence']=80;$m['notes']='Matched supplier contact email.';
            $r=$pdo->prepare("SELECT id,request_code,trip_id FROM supplier_requests WHERE supplier_id=? AND status NOT IN ('cancelled','closed') AND created_at>=DATE_SUB(NOW(),INTERVAL 120 DAY) ORDER BY updated_at DESC,id DESC LIMIT 2");
            $r->execute([(int)$sup['id']]);$rows=$r->fetchAll(PDO::FETCH_ASSOC)?:[];
            if(count($rows)===1){$m['supplier_request_id']=(int)$rows[0]['id'];$m['supplier_request_code']=(string)$rows[0]['request_code'];$m['trip_id']=$rows[0]['trip_id']?(int)$rows[0]['trip_id']:null;$m['confidence']=88;$m['notes']='Matched supplier email and its only recent open request.';}
            return $m;
        }

        $b=$pdo->prepare("SELECT id FROM bookings WHERE LOWER(customer_email)=LOWER(?) ORDER BY updated_at DESC,id DESC LIMIT 2");$b->execute([$email]);$br=$b->fetchAll(PDO::FETCH_ASSOC)?:[];
        $e=$pdo->prepare("SELECT e.id,t.id trip_id,t.trip_code FROM enquiries e LEFT JOIN trips t ON t.enquiry_id=e.id WHERE LOWER(e.email)=LOWER(?) ORDER BY COALESCE(t.updated_at,e.updated_at) DESC,e.id DESC LIMIT 2");$e->execute([$email]);$er=$e->fetchAll(PDO::FETCH_ASSOC)?:[];
        if($br || $er){
            $m['party_type']='customer';$m['confidence']=72;$m['notes']='Matched customer email.';
            if(count($er)===1){$m['enquiry_id']=(int)$er[0]['id'];$m['trip_id']=$er[0]['trip_id']?(int)$er[0]['trip_id']:null;$m['trip_code']=$er[0]['trip_code']?:null;$m['confidence']=82;}
            if(count($br)===1){$m['booking_id']=(int)$br[0]['id'];$m['confidence']=max($m['confidence'],82);}
            return $m;
        }
    }
    return $m;
}

function tsCommSla(array $match,string $subject,string $body): array
{
    $text=strtolower($subject.' '.$body);$priority='normal';$hours=4;
    if(preg_match('/\b(urgent|asap|immediately|emergency|today)\b/i',$text)){ $priority='urgent';$hours=1; }
    elseif(($match['party_type']??'')==='supplier'){ $priority='high';$hours=3; }
    return ['priority'=>$priority,'sla_due_at'=>date('Y-m-d H:i:s',time()+$hours*3600)];
}

function tsCommThreadKey(array $match,string $email,string $subject): string
{
    if(!empty($match['quotation_version_id'])) return 'QV:'.(int)$match['quotation_version_id'];
    if(!empty($match['supplier_request_id'])) return 'SR:'.(int)$match['supplier_request_id'];
    if(!empty($match['booking_id'])) return 'BKG:'.(int)$match['booking_id'];
    if(!empty($match['trip_id'])) return 'TRIP:'.(int)$match['trip_id'];
    return 'MAIL:'.sha1(strtolower(trim($email)).'|'.strtolower(tsCommNormalizeSubject($subject)));
}

function tsCommStoreMessage(PDO $pdo,array $d): int
{
    $sql="INSERT INTO communication_inbox_messages
      (mailbox_key,external_message_id,thread_key,direction,channel,sender_name,sender_email,sender_mobile,recipient_name,recipient_email,recipient_mobile,subject,body_text,body_html,in_reply_to,references_header,message_date,is_read,status,priority,assigned_admin_id,sla_due_at,party_type,supplier_id,supplier_request_id,enquiry_id,trip_id,quotation_version_id,booking_id,match_confidence,match_notes,meta_json)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
      ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id),updated_at=CURRENT_TIMESTAMP";
    $s=$pdo->prepare($sql);$s->execute([
        $d['mailbox_key']??'primary',$d['external_message_id'],$d['thread_key']??null,$d['direction']??'inbound',$d['channel']??'email',
        $d['sender_name']??null,$d['sender_email']??null,$d['sender_mobile']??null,$d['recipient_name']??null,$d['recipient_email']??null,$d['recipient_mobile']??null,
        $d['subject']??null,$d['body_text']??null,$d['body_html']??null,$d['in_reply_to']??null,$d['references_header']??null,$d['message_date']??date('Y-m-d H:i:s'),
        (int)($d['is_read']??0),$d['status']??'open',$d['priority']??'normal',$d['assigned_admin_id']??null,$d['sla_due_at']??null,$d['party_type']??'unknown',
        $d['supplier_id']??null,$d['supplier_request_id']??null,$d['enquiry_id']??null,$d['trip_id']??null,$d['quotation_version_id']??null,$d['booking_id']??null,
        (int)($d['match_confidence']??0),$d['match_notes']??null,$d['meta_json']??null
    ]);
    return (int)$pdo->lastInsertId();
}

function tsCommMirrorInbound(PDO $pdo,int $messageId,array $match,array $message): void
{
    $external=(string)$message['external_message_id'];$body=(string)($message['body_text']??'');$subject=(string)($message['subject']??'');$date=(string)($message['message_date']??date('Y-m-d H:i:s'));
    try{
        if(!empty($match['quotation_version_id']) && tsCommTableExists($pdo,'crm_quotation_messages')){
            $v=$pdo->prepare('SELECT lead_id FROM crm_package_versions WHERE id=? LIMIT 1');$v->execute([(int)$match['quotation_version_id']]);$lead=(int)$v->fetchColumn();
            if($lead>0){$q=$pdo->prepare("INSERT IGNORE INTO crm_quotation_messages (lead_id,version_id,direction,sender_email,recipient_email,subject,body_text,message_id,in_reply_to,sent_at) VALUES (?,?,'inbound',?,?,?,?,?,?,?)");$q->execute([$lead,(int)$match['quotation_version_id'],$message['sender_email']??null,$message['recipient_email']??null,$subject,$body,$external,$message['in_reply_to']??null,$date]);}
        }
        if(!empty($match['supplier_request_id']) && tsCommTableExists($pdo,'supplier_request_messages')){
            $check=$pdo->prepare("SELECT id FROM supplier_request_messages WHERE supplier_request_id=? AND sender_type='supplier' AND channel='email' AND message=? AND sent_at=? LIMIT 1");$check->execute([(int)$match['supplier_request_id'],$body,$date]);
            if(!$check->fetchColumn()){$q=$pdo->prepare("INSERT INTO supplier_request_messages (supplier_request_id,sender_type,admin_id,channel,message,sent_at) VALUES (?,'supplier',NULL,'email',?,?)");$q->execute([(int)$match['supplier_request_id'],$body,$date]);}
            if(tsCommTableExists($pdo,'supplier_request_events')){$pdo->prepare("INSERT INTO supplier_request_events (supplier_request_id,event_type,channel,description,event_at,admin_id) VALUES (?,'supplier_reply','email',?,?,NULL)")->execute([(int)$match['supplier_request_id'],'Inbound supplier email: '.$subject,$date]);}
        }
        if(!empty($match['booking_id']) && tsCommTableExists($pdo,'booking_communications')){
            $q=$pdo->prepare("INSERT IGNORE INTO booking_communications (booking_id,trip_id,quotation_version_id,direction,channel,sender_name,sender_email,recipient_email,subject,body_text,message_id,in_reply_to,delivery_status,sent_at,meta_json) VALUES (?,?,?,'inbound','email',?,?,?,?,?,?,?,'received',?,?)");
            $q->execute([(int)$match['booking_id'],$match['trip_id']??null,$match['quotation_version_id']??null,$message['sender_name']??null,$message['sender_email']??null,$message['recipient_email']??null,$subject,$body,$external,$message['in_reply_to']??null,$date,json_encode(['communication_inbox_message_id'=>$messageId])]);
        }
    }catch(Throwable $e){error_log('TRAVSCOPE Step11E mirror error: '.$e->getMessage());}
}

function tsCommSaveAttachments(PDO $pdo,$imap,int $messageNo,$structure,int $messageId,string $partNumber=''): int
{
    if(!$structure) return 0; $saved=0;
    $filename=tsCommStructureFilename($structure);
    if($filename!=='' && $partNumber!==''){
        $raw=(string)@imap_fetchbody($imap,$messageNo,$partNumber,FT_PEEK);$data=tsCommDecodePart($raw,(int)($structure->encoding??0));
        if($data!=='' && strlen($data)<=15*1024*1024){
            $safe=preg_replace('/[^A-Za-z0-9._ -]+/u','_',basename($filename))?:'attachment.bin';
            $dir=tsCommAttachmentDir();$disk='MSG'.$messageId.'-'.bin2hex(random_bytes(4)).'-'.$safe;$full=$dir.'/'.$disk;
            if(@file_put_contents($full,$data)!==false){@chmod($full,0640);$rel='communication-attachments/'.date('Y').'/'.date('m').'/'.$disk;$mime='application/octet-stream';
                if(class_exists('finfo')){$fi=new finfo(FILEINFO_MIME_TYPE);$mime=(string)$fi->file($full);}
                $sha=hash_file('sha256',$full);$isPdf=strtolower(pathinfo($safe,PATHINFO_EXTENSION))==='pdf'||$mime==='application/pdf';
                $s=$pdo->prepare('INSERT INTO communication_attachments (message_id,original_filename,stored_path,mime_type,file_size,file_sha256,is_pdf) VALUES (?,?,?,?,?,?,?)');$s->execute([$messageId,$safe,$rel,$mime,filesize($full),$sha,$isPdf?1:0]);$saved++;
            }
        }
    }
    if(!empty($structure->parts)&&is_array($structure->parts)){
        foreach($structure->parts as $i=>$part){$child=$partNumber===''?(string)($i+1):$partNumber.'.'.($i+1);$saved+=tsCommSaveAttachments($pdo,$imap,$messageNo,$part,$messageId,$child);}
    }
    return $saved;
}

function tsCommSyncInbox(PDO $pdo,int $lookbackDays=14,string $mailboxKey='primary'): array
{
    $out=['available'=>false,'scanned'=>0,'inserted'=>0,'attachments'=>0,'html_updated'=>0,'error'=>''];
    if(!tsCommReady($pdo)){ $out['error']='Step 11E SQL is not installed.'; return $out; }
    if(!function_exists('imap_open')){ $out['error']='PHP IMAP extension is not enabled.'; return $out; }
    if(!defined('SMTP_USERNAME')||!defined('SMTP_PASSWORD')||trim((string)SMTP_USERNAME)===''||trim((string)SMTP_PASSWORD)===''){$out['error']='SMTP/IMAP credentials are not configured.';return $out;}
    $mailbox=defined('IMAP_MAILBOX')&&trim((string)IMAP_MAILBOX)!==''?(string)IMAP_MAILBOX:'{imap.gmail.com:993/imap/ssl}INBOX';
    $imap=@imap_open($mailbox,(string)SMTP_USERNAME,(string)SMTP_PASSWORD,0,1);
    if($imap===false){$out['error']='Unable to connect to IMAP inbox.';return $out;}
    $out['available']=true;$latestDate=null;
    try{
        $uids=@imap_search($imap,'SINCE "'.date('d-M-Y',strtotime('-'.max(1,min(90,$lookbackDays)).' days')).'"',SE_UID);
        if(!is_array($uids))$uids=[]; sort($uids,SORT_NUMERIC);
        foreach($uids as $uid){$out['scanned']++;$messageNo=@imap_msgno($imap,(int)$uid);if(!$messageNo)continue;
            $ovl=@imap_fetch_overview($imap,(string)$messageNo,0);$ov=is_array($ovl)&&isset($ovl[0])?$ovl[0]:null;if(!$ov)continue;
            $header=@imap_headerinfo($imap,$messageNo);$from=tsCommAddressFromHeader($header->from??[]);$to=tsCommAddressFromHeader($header->to??[]);
            $messageId=trim((string)($ov->message_id??($header->message_id??'')));if($messageId==='')$messageId='imap-'.$mailboxKey.'-'.$uid;
            $dup=$pdo->prepare('SELECT id,body_html FROM communication_inbox_messages WHERE mailbox_key=? AND external_message_id=? LIMIT 1');$dup->execute([$mailboxKey,$messageId]);$existing=$dup->fetch(PDO::FETCH_ASSOC);
            if($existing){
                // Backfill HTML for messages synced before V24.62, without duplicating records or attachments.
                if(trim((string)($existing['body_html']??''))===''){
                    $existingStructure=@imap_fetchstructure($imap,$messageNo);
                    $existingHtml=tsCommMessageHtml($imap,$messageNo,$existingStructure);
                    if($existingHtml!==''){
                        $cidBudget=1048576;$existingHtml=tsCommEmbedCidImages($imap,$messageNo,$existingStructure,$existingHtml,'',$cidBudget);
                        $htmlUpdate=$pdo->prepare("UPDATE communication_inbox_messages SET body_html=? WHERE id=? AND (body_html IS NULL OR body_html='')");
                        $htmlUpdate->execute([$existingHtml,(int)$existing['id']]);$out['html_updated']+=(int)$htmlUpdate->rowCount();
                    }
                }
                continue;
            }
            $subject=tsCommDecodeHeader((string)($ov->subject??''));$structure=@imap_fetchstructure($imap,$messageNo);
            $body=tsCommMessageText($imap,$messageNo,$structure);if($body==='')$body='(Email body could not be decoded.)';
            $bodyHtml=tsCommMessageHtml($imap,$messageNo,$structure);
            if($bodyHtml!==''){$cidBudget=1048576;$bodyHtml=tsCommEmbedCidImages($imap,$messageNo,$structure,$bodyHtml,'',$cidBudget);}
            $ts=strtotime((string)($ov->date??''));$date=$ts?date('Y-m-d H:i:s',$ts):date('Y-m-d H:i:s');$latestDate=$date;
            $match=tsCommAutoMatch($pdo,$from['email'],$subject);$sla=tsCommSla($match,$subject,$body);$thread=tsCommThreadKey($match,$from['email'],$subject);
            $data=['mailbox_key'=>$mailboxKey,'external_message_id'=>$messageId,'thread_key'=>$thread,'direction'=>'inbound','channel'=>'email','sender_name'=>$from['name'],'sender_email'=>$from['email'],'recipient_name'=>$to['name'],'recipient_email'=>$to['email'],'subject'=>$subject,'body_text'=>$body,'body_html'=>$bodyHtml,'in_reply_to'=>trim((string)($header->in_reply_to??''))?:null,'references_header'=>trim((string)($header->references??''))?:null,'message_date'=>$date,'is_read'=>0,'status'=>'open','priority'=>$sla['priority'],'sla_due_at'=>$sla['sla_due_at'],'party_type'=>$match['party_type'],'supplier_id'=>$match['supplier_id'],'supplier_request_id'=>$match['supplier_request_id'],'enquiry_id'=>$match['enquiry_id'],'trip_id'=>$match['trip_id'],'quotation_version_id'=>$match['quotation_version_id'],'booking_id'=>$match['booking_id'],'match_confidence'=>$match['confidence'],'match_notes'=>$match['notes'],'meta_json'=>json_encode(['imap_uid'=>(int)$uid],JSON_UNESCAPED_SLASHES)];
            $id=tsCommStoreMessage($pdo,$data);$out['inserted']++;tsCommMirrorInbound($pdo,$id,$match,$data);$out['attachments']+=tsCommSaveAttachments($pdo,$imap,$messageNo,$structure,$id);
        }
        $pdo->prepare("INSERT INTO communication_sync_state (mailbox_key,mailbox_address,last_synced_at,last_success_at,last_message_date,last_status,last_error,last_synced_count) VALUES (?,?,NOW(),NOW(),?,'ok',NULL,?) ON DUPLICATE KEY UPDATE mailbox_address=VALUES(mailbox_address),last_synced_at=NOW(),last_success_at=NOW(),last_message_date=COALESCE(VALUES(last_message_date),last_message_date),last_status='ok',last_error=NULL,last_synced_count=VALUES(last_synced_count)")->execute([$mailboxKey,(string)SMTP_USERNAME,$latestDate,$out['inserted']]);
    }catch(Throwable $e){$out['error']=$e->getMessage();$pdo->prepare("INSERT INTO communication_sync_state (mailbox_key,mailbox_address,last_synced_at,last_status,last_error,last_synced_count) VALUES (?,?,NOW(),'error',?,0) ON DUPLICATE KEY UPDATE mailbox_address=VALUES(mailbox_address),last_synced_at=NOW(),last_status='error',last_error=VALUES(last_error),last_synced_count=0")->execute([$mailboxKey,(string)SMTP_USERNAME,mb_substr($e->getMessage(),0,1000)]);}
    finally{@imap_close($imap);}return $out;
}

function tsCommGetMessage(PDO $pdo,int $id): ?array
{
    $s=$pdo->prepare("SELECT m.*,a.name assigned_name,s.company_name,sr.request_code,t.trip_code,b.booking_number,v.version_number,v.package_title FROM communication_inbox_messages m LEFT JOIN admins a ON a.id=m.assigned_admin_id LEFT JOIN suppliers s ON s.id=m.supplier_id LEFT JOIN supplier_requests sr ON sr.id=m.supplier_request_id LEFT JOIN trips t ON t.id=m.trip_id LEFT JOIN bookings b ON b.id=m.booking_id LEFT JOIN crm_package_versions v ON v.id=m.quotation_version_id WHERE m.id=? LIMIT 1");$s->execute([$id]);$r=$s->fetch(PDO::FETCH_ASSOC);return $r?:null;
}

function tsCommReplySubject(array $message): string
{
    $subject=tsCommNormalizeSubject((string)($message['subject']??''));if($subject==='')$subject='TRAVSCOPE Communication';
    $tag='';
    if(!empty($message['quotation_version_id']))$tag='[TRAVSCOPE-QV-'.(int)$message['quotation_version_id'].']';
    elseif(!empty($message['supplier_request_id']) && !empty($message['request_code']))$tag='[TRAVSCOPE-SR-'.(string)$message['request_code'].']';
    elseif(!empty($message['booking_id']))$tag='[TRAVSCOPE-BKG-'.(int)$message['booking_id'].']';
    elseif(!empty($message['trip_code']))$tag='[TRAVSCOPE-TRIP-'.(string)$message['trip_code'].']';
    return 'Re: '.($tag!==''?$tag.' ':'').$subject;
}

/**
 * V24.64: rebuild HTML for Compose AND Reply, retaining email-safe table structure.
 * Never accept arbitrary attributes, scripting, forms, CSS URLs or external resources.
 * Does not depend on ext-dom (optional on shared hosting).
 */
function tsCommReplySafeColor(string $value): string
{
    $value=strtolower(trim(html_entity_decode($value,ENT_QUOTES|ENT_HTML5,'UTF-8')));
    if(preg_match('/^#[0-9a-f]{3}(?:[0-9a-f]{3})?$/D',$value))return $value;
    if(preg_match('/^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/D',$value,$m)){
        if((int)$m[1]<=255&&(int)$m[2]<=255&&(int)$m[3]<=255)return 'rgb('.(int)$m[1].','.(int)$m[2].','.(int)$m[3].')';
    }
    if(in_array($value,['black','white','navy','blue','red','green','gray','grey','yellow','orange','purple','teal','silver','maroon'],true))return $value;
    return '';
}
function tsCommReplyTagStyle(string $tag,string $token): string
{
    $default=[
        'table'=>'border-collapse:collapse;border-spacing:0;max-width:100%;width:100%;border:1px solid #cbd5e1;margin:12px 0;font:13px/1.5 Arial,Helvetica,sans-serif',
        'th'=>'border:1px solid #cbd5e1;padding:7px 9px;background-color:#eff5ff;font-weight:bold;text-align:left;vertical-align:top',
        'td'=>'border:1px solid #cbd5e1;padding:7px 9px;vertical-align:top',
        'p'=>'margin:0 0 12px',
        'blockquote'=>'border-left:3px solid #bdcfe7;padding-left:12px;color:#4c607a;margin:10px 0',
        'h1'=>'font-size:22px;margin:12px 0 7px','h2'=>'font-size:19px;margin:12px 0 7px',
        'h3'=>'font-size:16px;margin:10px 0 6px','h4'=>'font-size:14px;margin:10px 0 5px'
    ];
    $styles=isset($default[$tag])?explode(';',$default[$tag]):[];
    $rawStyle='';
    if(preg_match('~\bstyle\s*=\s*(?:"([^"]*)"|\'([^\']*)\')~i',$token,$sm))$rawStyle=html_entity_decode((string)($sm[1]!==''?$sm[1]:$sm[2]),ENT_QUOTES|ENT_HTML5,'UTF-8');
    // Only safe primitive properties, rebuilt from strict whitelists (never copy raw CSS).
    foreach(explode(';',$rawStyle) as $declaration){
        $parts=explode(':',$declaration,2);if(count($parts)!==2)continue;
        $prop=strtolower(trim($parts[0]));$value=strtolower(trim($parts[1]));
        if(in_array($prop,['color','background-color'],true)){
            $safe=tsCommReplySafeColor($value);if($safe!=='')$styles[]=$prop.':'.$safe;
        }elseif($prop==='text-align'&&in_array($value,['left','right','center','justify'],true))$styles[]='text-align:'.$value;
        elseif($prop==='vertical-align'&&in_array($value,['top','middle','bottom'],true))$styles[]='vertical-align:'.$value;
        elseif($prop==='font-weight'&&in_array($value,['bold','normal','600','700','800','900'],true))$styles[]='font-weight:'.$value;
    }
    if(preg_match('~\bbgcolor\s*=\s*["\']?(#[a-f0-9]{3,6}|[a-z]+)~i',$token,$m)){
        $safe=tsCommReplySafeColor($m[1]);if($safe!=='')$styles[]='background-color:'.$safe;
    }
    if(preg_match('~\balign\s*=\s*["\']?(left|right|center|justify)\b~i',$token,$m))$styles[]='text-align:'.strtolower($m[1]);
    return $styles?' style="'.htmlspecialchars(implode(';',$styles),ENT_QUOTES,'UTF-8').'"':'';
}
function tsCommCleanReplyFragment(string $raw): string
{
    if(strlen($raw)>240000)throw new RuntimeException('Email is too large (maximum 240 KB of HTML markup).');
    // Drop dangerous elements WITH their contents; discard standalone dangerous tags too.
    $raw=preg_replace('~<!--[\s\S]*?-->~','',$raw)??$raw;
    $raw=preg_replace('~<(?:script|style|iframe|object|embed|svg|math|form|template|noscript|video|audio|canvas|link|meta)\b[^>]*>[\s\S]*?</(?:script|style|iframe|object|embed|svg|math|form|template|noscript|video|audio|canvas|link|meta)\s*>~i','',$raw)??$raw;
    $allowed=['p','div','br','strong','b','em','i','u','s','span','ul','ol','li','blockquote','a','h1','h2','h3','h4',
              'table','caption','thead','tbody','tfoot','tr','th','td','colgroup','col'];
    $out='';$stack=[];$skip=0;
    preg_match_all('/<[^>]*>|[^<]+|</s',$raw,$tokens);
    foreach($tokens[0] as $token){
        if(!str_starts_with($token,'<')){
            $out.=htmlspecialchars($token,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8',false);
            continue;
        }
        if(!preg_match('~^<\s*(/?)\s*([a-z][a-z0-9]*)\b[^>]*>$~is',$token,$m))continue;
        $tag=strtolower($m[2]);if(!in_array($tag,$allowed,true))continue;
        $closing=$m[1]==='/';
        if($tag==='br'){if(!$closing)$out.='<br>';continue;}
        if($tag==='col'){
            if(!$closing)$out.='<col'.tsCommReplyTagStyle($tag,$token).'>';
            continue;
        }
        if($closing){
            // Close only tags genuinely opened by us; ensure pasted malformed markup
            // cannot close an outer email wrapper or create a dangling <table>.
            $idx=array_search($tag,array_reverse($stack),true);
            if($idx===false)continue;
            $target=count($stack)-1-$idx;
            while(count($stack)>$target){$out.='</'.array_pop($stack).'>';}
            continue;
        }
        $attr='';
        if($tag==='a'){
            if(!preg_match('~\bhref\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))~i',$token,$link))continue;
            $href=html_entity_decode((string)(($link[1]??'')!==''?$link[1]:(($link[2]??'')!==''?$link[2]:($link[3]??''))),ENT_QUOTES|ENT_HTML5,'UTF-8');
            $href=trim(preg_replace('/[\x00-\x20\x7f]/','',$href)??'');
            $scheme=strtolower((string)parse_url($href,PHP_URL_SCHEME));
            if(!in_array($scheme,['https','http','mailto'],true))continue;
            if($scheme!=='mailto'&&!filter_var($href,FILTER_VALIDATE_URL))continue;
            if($scheme==='mailto'&&!filter_var(substr($href,7),FILTER_VALIDATE_EMAIL))continue;
            $attr=' href="'.htmlspecialchars($href,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'" style="color:#1265d9;text-decoration:underline"';
        }else{
            $attr=tsCommReplyTagStyle($tag,$token);
            if(in_array($tag,['td','th'],true)){
                foreach(['colspan','rowspan'] as $dimension){
                    if(preg_match('~\b'.$dimension.'\s*=\s*["\']?(\d{1,2})~i',$token,$d)){
                        $value=max(1,min(12,(int)$d[1]));$attr.=' '.$dimension.'="'.$value.'"';
                    }
                }
            }
        }
        $out.='<'.$tag.$attr.'>';$stack[]=$tag;
    }
    while($stack){$out.='</'.array_pop($stack).'>';}
    return trim($out);
}

function tsCommReplyPlainText(string $safeFragment): string
{
    // Keep tables readable in non-HTML clients: tab-separated columns, one row per line.
    $plain=preg_replace('~</(?:td|th)>~i',"\t",$safeFragment)??$safeFragment;
    $plain=preg_replace('~<br\s*/?>|</(?:p|div|li|blockquote|ul|ol|tr|table|caption|h[1-4])>~i',"\n",$plain)??$plain;
    $plain=html_entity_decode(strip_tags($plain),ENT_QUOTES|ENT_HTML5,'UTF-8');
    $plain=str_replace(["\r\n","\r",chr(194).chr(160)],["\n","\n",' '],$plain);
    $plain=preg_replace('/[ \t]+\n/',"\n",$plain)??$plain;
    $plain=preg_replace('/\n{3,}/',"\n\n",$plain)??$plain;
    return trim($plain);
}

function tsCommPrepareReply(string $plainInput,string $htmlInput=''): array
{
    if(trim($htmlInput)!==''){
        $fragment=tsCommCleanReplyFragment($htmlInput);
        $plain=tsCommReplyPlainText($fragment);
    }else{
        $plain=trim($plainInput);
        $fragment=nl2br(htmlspecialchars($plain,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'),false);
    }
    if($plain==='')throw new RuntimeException('Enter the reply message before sending.');
    if(mb_strlen($plain)>20000)throw new RuntimeException('Reply is too long (maximum 20,000 characters).');
    $html='<!doctype html><html><head><meta charset="UTF-8"></head>'
        .'<body style="margin:0;padding:20px;background:#ffffff;font:14px/1.65 Arial,Helvetica,sans-serif;color:#202c3b">'
        .'<div style="max-width:760px;margin:0 auto;overflow-wrap:anywhere">'
        .$fragment
        .'<div style="border-top:1px solid #dfe6ef;margin-top:24px;padding-top:12px;color:#66778d;font-size:11px">Sent via TRAVSCOPE Communication Center</div>'
        .'</div></body></html>';
    return ['text'=>$plain,'html'=>$html];
}

function tsCommSendEmail(PDO $pdo,array $message,string $body,int $adminId,string $richHtml=''): array
{
    $reply=tsCommPrepareReply($body,$richHtml);$body=$reply['text'];$bodyHtml=$reply['html'];
    $to=trim((string)(($message['direction']??'inbound')==='outbound'?($message['recipient_email']??''):($message['sender_email']??'')));if(!filter_var($to,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Recipient email is unavailable.');
    if(!class_exists('\\PHPMailer\\PHPMailer\\PHPMailer'))throw new RuntimeException('PHPMailer is unavailable.');
    $subject=tsCommReplySubject($message);$mail=new \PHPMailer\PHPMailer\PHPMailer(true);
    if(defined('SMTP_ENABLED')&&SMTP_ENABLED){$mail->isSMTP();$mail->Host=defined('SMTP_HOST')?SMTP_HOST:'smtp.gmail.com';$mail->SMTPAuth=defined('SMTP_AUTH')?(bool)SMTP_AUTH:true;$mail->Username=defined('SMTP_USERNAME')?SMTP_USERNAME:'';$mail->Password=defined('SMTP_PASSWORD')?SMTP_PASSWORD:'';$mail->Port=defined('SMTP_PORT')?(int)SMTP_PORT:587;if(defined('SMTP_ENCRYPTION')&&trim((string)SMTP_ENCRYPTION)!=='')$mail->SMTPSecure=SMTP_ENCRYPTION;}
    $from=defined('SMTP_FROM_EMAIL')&&trim((string)SMTP_FROM_EMAIL)!==''?(string)SMTP_FROM_EMAIL:(defined('SMTP_USERNAME')?(string)SMTP_USERNAME:'');if($from==='')throw new RuntimeException('Sender email is not configured.');
    $fromName=defined('SMTP_FROM_NAME')&&trim((string)SMTP_FROM_NAME)!==''?(string)SMTP_FROM_NAME:'TRAVSCOPE.COM';$mail->setFrom($from,$fromName);$mail->addAddress($to,(string)((($message['direction']??'inbound')==='outbound')?($message['recipient_name']??''):($message['sender_name']??'')));$mail->Subject=$subject;$mail->CharSet='UTF-8';$mail->isHTML(true);$mail->Body=$bodyHtml;$mail->AltBody=$body;
    if(!empty($message['external_message_id'])){$mail->addCustomHeader('In-Reply-To',(string)$message['external_message_id']);$mail->addCustomHeader('References',(string)$message['external_message_id']);}
    $mail->send();$external=trim((string)$mail->getLastMessageID());if($external==='')$external='local-outbound-'.bin2hex(random_bytes(10));$date=date('Y-m-d H:i:s');
    $data=['mailbox_key'=>(string)($message['mailbox_key']??'primary'),'external_message_id'=>$external,'thread_key'=>(string)$message['thread_key'],'direction'=>'outbound','channel'=>'email','sender_name'=>$fromName,'sender_email'=>$from,'recipient_name'=>(string)((($message['direction']??'inbound')==='outbound')?($message['recipient_name']??''):($message['sender_name']??'')),'recipient_email'=>$to,'subject'=>$subject,'body_text'=>$body,'body_html'=>$bodyHtml,'in_reply_to'=>(string)($message['external_message_id']??''),'message_date'=>$date,'is_read'=>1,'status'=>'resolved','priority'=>'normal','assigned_admin_id'=>$adminId,'party_type'=>(string)$message['party_type'],'supplier_id'=>$message['supplier_id']?:null,'supplier_request_id'=>$message['supplier_request_id']?:null,'enquiry_id'=>$message['enquiry_id']?:null,'trip_id'=>$message['trip_id']?:null,'quotation_version_id'=>$message['quotation_version_id']?:null,'booking_id'=>$message['booking_id']?:null,'match_confidence'=>100,'match_notes'=>'Outbound reply sent from Shared Communication Center.'];$id=tsCommStoreMessage($pdo,$data);
    if(!empty($message['supplier_request_id'])&&tsCommTableExists($pdo,'supplier_request_messages')){$pdo->prepare("INSERT INTO supplier_request_messages (supplier_request_id,sender_type,admin_id,channel,message,sent_at) VALUES (?,'admin',?,'email',?,?)")->execute([(int)$message['supplier_request_id'],$adminId,$body,$date]);}
    if(!empty($message['booking_id'])&&tsCommTableExists($pdo,'booking_communications')){$pdo->prepare("INSERT IGNORE INTO booking_communications (booking_id,trip_id,quotation_version_id,direction,channel,sender_name,sender_email,recipient_name,recipient_email,subject,body_text,message_id,in_reply_to,delivery_status,sent_at,created_by_admin_id,meta_json) VALUES (?,?,?,'outbound','email',?,?,?,?,?,?,?,?,?,'sent',?,?,?)")->execute([(int)$message['booking_id'],$message['trip_id']?:null,$message['quotation_version_id']?:null,$fromName,$from,(string)($message['sender_name']??''),$to,$subject,$body,$external,$message['external_message_id']??null,$date,$adminId,json_encode(['communication_inbox_message_id'=>$id])]);}
    $pdo->prepare("UPDATE communication_inbox_messages SET is_read=1,status='waiting',assigned_admin_id=COALESCE(assigned_admin_id,?),updated_at=NOW() WHERE id=?")->execute([$adminId,(int)$message['id']]);
    return ['ok'=>true,'message_id'=>$external,'stored_id'=>$id];
}

/** Send a new HTML email without requiring an existing communication to reply to. */
function tsCommSendNewEmail(PDO $pdo,string $to,string $subject,string $plainInput,int $adminId,string $richHtml=''): int
{
    $to=trim($to);$subject=trim(str_replace(["\r","\n"],' ',$subject));
    if(!filter_var($to,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Enter one valid recipient email address.');
    if($subject===''||mb_strlen($subject)>190)throw new RuntimeException('Enter a subject (maximum 190 characters).');
    $reply=tsCommPrepareReply($plainInput,$richHtml);
    if(!class_exists('\\PHPMailer\\PHPMailer\\PHPMailer'))throw new RuntimeException('PHPMailer is unavailable.');
    $mail=new \PHPMailer\PHPMailer\PHPMailer(true);
    if(defined('SMTP_ENABLED')&&SMTP_ENABLED){
        $mail->isSMTP();$mail->Host=defined('SMTP_HOST')?SMTP_HOST:'smtp.gmail.com';
        $mail->SMTPAuth=defined('SMTP_AUTH')?(bool)SMTP_AUTH:true;
        $mail->Username=defined('SMTP_USERNAME')?SMTP_USERNAME:'';
        $mail->Password=defined('SMTP_PASSWORD')?SMTP_PASSWORD:'';
        $mail->Port=defined('SMTP_PORT')?(int)SMTP_PORT:587;
        if(defined('SMTP_ENCRYPTION')&&trim((string)SMTP_ENCRYPTION)!=='')$mail->SMTPSecure=SMTP_ENCRYPTION;
    }
    $from=defined('SMTP_FROM_EMAIL')&&trim((string)SMTP_FROM_EMAIL)!==''?(string)SMTP_FROM_EMAIL:(defined('SMTP_USERNAME')?(string)SMTP_USERNAME:'');
    if(!filter_var($from,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Sender email is not configured.');
    $fromName=defined('SMTP_FROM_NAME')&&trim((string)SMTP_FROM_NAME)!==''?(string)SMTP_FROM_NAME:'TRAVSCOPE.COM';
    $mail->setFrom($from,$fromName);$mail->addAddress($to);$mail->Subject=$subject;
    $mail->CharSet='UTF-8';$mail->isHTML(true);$mail->Body=$reply['html'];$mail->AltBody=$reply['text'];
    $mail->send();
    $external=trim((string)$mail->getLastMessageID());if($external==='')$external='local-compose-'.bin2hex(random_bytes(12));
    $thread='MAIL:'.sha1(strtolower($to).'|'.strtolower(tsCommNormalizeSubject($subject)));
    return tsCommStoreMessage($pdo,[
        'mailbox_key'=>'primary','external_message_id'=>$external,'thread_key'=>$thread,
        'direction'=>'outbound','channel'=>'email','sender_name'=>$fromName,'sender_email'=>$from,
        'recipient_name'=>$to,'recipient_email'=>$to,'subject'=>$subject,
        'body_text'=>$reply['text'],'body_html'=>$reply['html'],'message_date'=>date('Y-m-d H:i:s'),
        'is_read'=>1,'status'=>'waiting','priority'=>'normal','assigned_admin_id'=>$adminId,
        'party_type'=>'unknown','match_notes'=>'New formatted HTML email composed by administrator.'
    ]);
}

function tsCommImportPdfAttachment(PDO $pdo,int $attachmentId,int $supplierId,int $adminId): int
{
    if($supplierId<=0)throw new RuntimeException('Link the email to a supplier first.');
    $s=$pdo->prepare('SELECT * FROM communication_attachments WHERE id=? LIMIT 1');$s->execute([$attachmentId]);$a=$s->fetch(PDO::FETCH_ASSOC);if(!$a)throw new RuntimeException('Attachment not found.');if((int)$a['is_pdf']!==1)throw new RuntimeException('Only PDF attachments can be sent to Supplier Documents.');if(!empty($a['supplier_document_id']))return (int)$a['supplier_document_id'];
    $f=__DIR__.'/supplier-document-functions.php';if(!is_file($f))throw new RuntimeException('Step 11A Supplier Document Center is not installed.');require_once $f;if(function_exists('tsSupplierDocumentEnsureSchema')){try{tsSupplierDocumentEnsureSchema($pdo);}catch(Throwable $ignored){}}if(!function_exists('tsSupplierDocumentCenterReady')||!tsSupplierDocumentCenterReady($pdo))throw new RuntimeException('Supplier Document tables are unavailable. Import travscope-step-11a-milesweb-safe.sql.');
    $source=tsCommStoredPath((string)$a['stored_path']);$sup=$pdo->prepare('SELECT * FROM suppliers WHERE id=? LIMIT 1');$sup->execute([$supplierId]);$supplier=$sup->fetch(PDO::FETCH_ASSOC);if(!$supplier)throw new RuntimeException('Supplier not found.');
    $hash=hash_file('sha256',$source);$dup=$pdo->prepare('SELECT id FROM supplier_documents WHERE supplier_id=? AND file_sha256=? LIMIT 1');$dup->execute([$supplierId,$hash]);if($existing=(int)$dup->fetchColumn()){$pdo->prepare('UPDATE communication_attachments SET supplier_document_id=? WHERE id=?')->execute([$existing,$attachmentId]);return $existing;}
    $code=tsSupplierDocumentCode($pdo);$base=tsSupplierDocumentStorageDir().'/'.date('Y').'/'.date('m');if(!is_dir($base)&&!@mkdir($base,0750,true)&&!is_dir($base))throw new RuntimeException('Unable to create Supplier Document folder.');$dest=$base.'/'.$code.'-'.bin2hex(random_bytes(5)).'.pdf';if(!@copy($source,$dest))throw new RuntimeException('Unable to copy PDF into Supplier Document Center.');@chmod($dest,0640);$relative='supplier-documents/'.date('Y').'/'.date('m').'/'.basename($dest);
    try{$ex=tsSupplierDocumentExtractPdfText($dest);$analysis=tsSupplierDocumentAnalyzeText((string)$ex['text'],$supplier);$title=(string)$supplier['company_name'].' · '.ucwords(str_replace('_',' ',(string)$analysis['document_type']));$stmt=$pdo->prepare("INSERT INTO supplier_documents (supplier_id,destination_id,document_code,document_type,title,original_filename,stored_path,file_sha256,mime_type,file_size,source_channel,source_email,received_at,valid_from,valid_to,currency,extraction_status,extraction_method,extraction_confidence,source_coverage,detected_supplier_name,detected_destination_text,detected_itinerary_count,detected_hotel_category_count,detected_rate_group_count,detected_meal_plan,detected_tax_notes,detected_cancellation_terms,detected_transport_terms,analysis_json,status,notes,uploaded_by_admin_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");$coverage=(float)$analysis['source_coverage'];$stmt->execute([$supplierId,null,$code,(string)$analysis['document_type'],$title,(string)$a['original_filename'],$relative,$hash,'application/pdf',(int)$a['file_size'],'supplier_email',null,date('Y-m-d H:i:s'),$analysis['valid_from']?:null,$analysis['valid_to']?:null,strtoupper((string)($supplier['default_currency']??'INR')),$analysis['text_chars']>=80?'analyzed':'failed',(string)$ex['method'],$coverage,$coverage,trim((string)$analysis['supplier_detected'])?:null,null,(int)$analysis['itinerary_count'],(int)$analysis['hotel_category_count'],(int)$analysis['rate_group_count'],trim((string)$analysis['meal_plan'])?:null,$analysis['tax_notes']?implode("\n",$analysis['tax_notes']):null,trim((string)$analysis['cancellation_terms'])?:null,trim((string)$analysis['transport_terms'])?:null,json_encode($analysis,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$analysis['text_chars']>=80?'review':'failed','Imported automatically from Shared Communication Center.',$adminId]);$id=(int)$pdo->lastInsertId();$pdo->prepare('UPDATE communication_attachments SET supplier_document_id=? WHERE id=?')->execute([$id,$attachmentId]);return $id;}catch(Throwable $e){@unlink($dest);throw $e;}
}
