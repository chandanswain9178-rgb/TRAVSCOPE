<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — MANAGEMENT MIS + REPORTING / EXPORT CENTER
|--------------------------------------------------------------------------
|
| Read-only reporting. No SQL migration required.
| CSV/XLS exports are generated directly from the same report rows shown
| on screen. Existing financial/commercial tables remain authoritative.
|
*/

$misAclFile = __DIR__ . '/access-control-functions.php';
if (is_file($misAclFile) && !function_exists('tsAclCan')) {
    require_once $misAclFile;
}

function tsMisTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];
    $key = strtolower($table);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
              AND table_name = ?
        ");
        $stmt->execute([$table]);

        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}

function tsMisColumnExists(PDO $pdo, string $table, string $column): bool
{
    static $cache = [];
    $key = strtolower($table . '.' . $column);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    if (
        !preg_match('/^[A-Za-z0-9_]+$/', $table)
        || !preg_match('/^[A-Za-z0-9_]+$/', $column)
    ) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = DATABASE()
              AND table_name = ?
              AND column_name = ?
        ");
        $stmt->execute([$table, $column]);

        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}

function tsMisCatalog(): array
{
    return [
        'sales' => [
            'label' => 'Lead / Booking / Revenue',
            'description' => 'Bookings created in the selected period with selling, collected and outstanding values.',
        ],
        'profitability' => [
            'label' => 'Expected vs Actual Profitability',
            'description' => 'Financially closed Bookings with expected margin, actual margin and variance.',
        ],
        'collections' => [
            'label' => 'Customer Collections',
            'description' => 'Active customer payment installments due within the selected date range.',
        ],
        'supplier_payables' => [
            'label' => 'Supplier Payables',
            'description' => 'Approved/received supplier invoices with paid and outstanding amounts.',
        ],
        'destination' => [
            'label' => 'Destination Performance',
            'description' => 'Lead volume, converted Bookings and booked value by enquiry destination.',
        ],
        'owner' => [
            'label' => 'Sales Owner Performance',
            'description' => 'Lead ownership, conversion, booked value and overdue CRM follow-ups.',
        ],
        'repeat_sales' => [
            'label' => 'Repeat Sales Pipeline',
            'description' => 'Repeat-customer follow-up opportunities and resulting enquiries/bookings.',
        ],
        'departure_readiness' => [
            'label' => 'Departure Readiness',
            'description' => 'Upcoming travel with payment, supplier, voucher, document and operations readiness status.',
        ],
    ];
}

function tsMisDate(string $value, string $fallback): string
{
    $value = trim($value);

    if ($value === '') {
        return $fallback;
    }

    $ts = strtotime($value);

    if (!$ts) {
        return $fallback;
    }

    return date('Y-m-d', $ts);
}

function tsMisRange(array $input): array
{
    $today = date('Y-m-d');

    $from = tsMisDate(
        (string)($input['from'] ?? ''),
        date('Y-m-01', strtotime('-2 months'))
    );

    $to = tsMisDate(
        (string)($input['to'] ?? ''),
        $today
    );

    if ($from > $to) {
        [$from, $to] = [$to, $from];
    }

    return [$from, $to];
}

function tsMisRows(PDO $pdo, string $sql, array $params = []): array
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function tsMisPct(float $a, float $b): float
{
    return $b > 0
        ? round(($a / $b) * 100, 2)
        : 0.0;
}

function tsMisSales(PDO $pdo, string $from, string $to): array
{
    if (!tsMisTableExists($pdo, 'bookings')) {
        return [
            'columns' => [],
            'rows' => [],
            'totals' => [],
            'note' => 'Bookings table is unavailable.',
        ];
    }

    $tripJoin =
        tsMisTableExists($pdo, 'booking_trip_links')
        && tsMisTableExists($pdo, 'trips')
            ? "
                LEFT JOIN booking_trip_links l
                    ON l.booking_id = b.id
                LEFT JOIN trips t
                    ON t.id = l.trip_id
              "
            : '';

    $tripSelect =
        $tripJoin !== ''
            ? "t.trip_code AS trip_code,"
            : "NULL AS trip_code,";

    $rows = tsMisRows(
        $pdo,
        "
        SELECT
            b.id AS booking_id,
            b.booking_number,
            {$tripSelect}
            b.customer_name,
            b.travel_date,
            b.booking_status,
            b.payment_status,
            b.currency,
            b.total_amount,
            b.paid_amount,
            GREATEST(b.total_amount - b.paid_amount, 0) AS outstanding_amount,
            b.created_at
        FROM bookings b
        {$tripJoin}
        WHERE DATE(b.created_at) BETWEEN ? AND ?
        ORDER BY b.created_at DESC, b.id DESC
        ",
        [$from, $to]
    );

    $totals = [
        'Bookings' => count($rows),
        'Booked Sales' => 0.0,
        'Collected' => 0.0,
        'Outstanding' => 0.0,
    ];

    foreach ($rows as $row) {
        if ((string)$row['booking_status'] === 'cancelled') {
            continue;
        }

        $totals['Booked Sales'] += (float)$row['total_amount'];
        $totals['Collected'] += (float)$row['paid_amount'];
        $totals['Outstanding'] += (float)$row['outstanding_amount'];
    }

    return [
        'columns' => [
            'booking_number' => 'Booking',
            'trip_code' => 'Trip ID',
            'customer_name' => 'Customer',
            'travel_date' => 'Travel Date',
            'booking_status' => 'Booking Status',
            'payment_status' => 'Payment Status',
            'currency' => 'Currency',
            'total_amount' => 'Selling',
            'paid_amount' => 'Collected',
            'outstanding_amount' => 'Outstanding',
            'created_at' => 'Booked At',
        ],
        'rows' => $rows,
        'totals' => $totals,
        'note' => 'Period basis: Booking created_at.',
    ];
}

function tsMisProfitability(PDO $pdo, string $from, string $to): array
{
    if (
        !tsMisTableExists($pdo, 'booking_profitability_closures')
        || !tsMisTableExists($pdo, 'bookings')
    ) {
        return [
            'columns' => [],
            'rows' => [],
            'totals' => [],
            'note' => 'Profitability closure module is unavailable.',
        ];
    }

    $rows = tsMisRows(
        $pdo,
        "
        SELECT
            c.id AS closure_id,
            b.booking_number,
            b.customer_name,
            b.travel_date,
            b.currency,
            c.expected_selling_price,
            c.expected_supplier_cost,
            c.expected_direct_cost,
            c.expected_total_cost,
            c.expected_margin,
            c.actual_customer_revenue,
            c.actual_supplier_cost,
            c.actual_direct_cost,
            c.actual_total_cost,
            c.actual_margin,
            c.margin_variance,
            c.closed_at
        FROM booking_profitability_closures c
        JOIN bookings b
            ON b.id = c.booking_id
        WHERE DATE(c.closed_at) BETWEEN ? AND ?
        ORDER BY c.closed_at DESC, c.id DESC
        ",
        [$from, $to]
    );

    $totals = [
        'Closed Bookings' => count($rows),
        'Expected Margin' => 0.0,
        'Actual Margin' => 0.0,
        'Margin Variance' => 0.0,
    ];

    foreach ($rows as $row) {
        $totals['Expected Margin'] += (float)$row['expected_margin'];
        $totals['Actual Margin'] += (float)$row['actual_margin'];
        $totals['Margin Variance'] += (float)$row['margin_variance'];
    }

    return [
        'columns' => [
            'booking_number' => 'Booking',
            'customer_name' => 'Customer',
            'travel_date' => 'Travel Date',
            'currency' => 'Currency',
            'expected_selling_price' => 'Expected Selling',
            'expected_total_cost' => 'Expected Cost',
            'expected_margin' => 'Expected Margin',
            'actual_customer_revenue' => 'Actual Revenue',
            'actual_total_cost' => 'Actual Cost',
            'actual_margin' => 'Actual Margin',
            'margin_variance' => 'Margin Variance',
            'closed_at' => 'Closed At',
        ],
        'rows' => $rows,
        'totals' => $totals,
        'note' => 'Period basis: financial closure date.',
    ];
}

function tsMisCollections(PDO $pdo, string $from, string $to): array
{
    if (
        !tsMisTableExists($pdo, 'booking_payment_installments')
        || !tsMisTableExists($pdo, 'booking_payment_schedules')
        || !tsMisTableExists($pdo, 'bookings')
    ) {
        return [
            'columns' => [],
            'rows' => [],
            'totals' => [],
            'note' => 'Customer Billing schedule module is unavailable.',
        ];
    }

    $rows = tsMisRows(
        $pdo,
        "
        SELECT
            b.booking_number,
            b.customer_name,
            b.travel_date,
            s.currency,
            i.installment_number,
            i.title,
            i.due_date,
            i.amount,
            i.paid_amount,
            GREATEST(i.amount - i.paid_amount, 0) AS outstanding_amount,
            i.status,
            CASE
                WHEN i.due_date < CURDATE()
                 AND GREATEST(i.amount - i.paid_amount, 0) > 0.01
                THEN DATEDIFF(CURDATE(), i.due_date)
                ELSE 0
            END AS overdue_days
        FROM booking_payment_installments i
        JOIN booking_payment_schedules s
            ON s.id = i.schedule_id
        JOIN bookings b
            ON b.id = i.booking_id
        WHERE s.status = 'active'
          AND i.due_date BETWEEN ? AND ?
          AND b.booking_status <> 'cancelled'
        ORDER BY i.due_date ASC, b.booking_number ASC, i.installment_number ASC
        ",
        [$from, $to]
    );

    $totals = [
        'Installments' => count($rows),
        'Scheduled' => 0.0,
        'Paid' => 0.0,
        'Outstanding' => 0.0,
        'Overdue Outstanding' => 0.0,
    ];

    foreach ($rows as $row) {
        $totals['Scheduled'] += (float)$row['amount'];
        $totals['Paid'] += (float)$row['paid_amount'];
        $totals['Outstanding'] += (float)$row['outstanding_amount'];

        if ((int)$row['overdue_days'] > 0) {
            $totals['Overdue Outstanding'] += (float)$row['outstanding_amount'];
        }
    }

    return [
        'columns' => [
            'booking_number' => 'Booking',
            'customer_name' => 'Customer',
            'travel_date' => 'Travel Date',
            'installment_number' => 'Installment',
            'title' => 'Milestone',
            'due_date' => 'Due Date',
            'currency' => 'Currency',
            'amount' => 'Scheduled',
            'paid_amount' => 'Paid',
            'outstanding_amount' => 'Outstanding',
            'overdue_days' => 'Overdue Days',
            'status' => 'Status',
        ],
        'rows' => $rows,
        'totals' => $totals,
        'note' => 'Period basis: customer installment due_date.',
    ];
}

function tsMisSupplierPayables(PDO $pdo, string $from, string $to): array
{
    if (
        !tsMisTableExists($pdo, 'supplier_invoices')
        || !tsMisTableExists($pdo, 'bookings')
        || !tsMisTableExists($pdo, 'suppliers')
    ) {
        return [
            'columns' => [],
            'rows' => [],
            'totals' => [],
            'note' => 'Supplier Finance module is unavailable.',
        ];
    }

    $paidExpr =
        tsMisTableExists($pdo, 'supplier_payments')
            ? "
                COALESCE(
                    (
                        SELECT SUM(p.amount)
                        FROM supplier_payments p
                        WHERE p.supplier_invoice_id = i.id
                          AND p.status = 'paid'
                    ),
                    0
                )
              "
            : "0";

    $rows = tsMisRows(
        $pdo,
        "
        SELECT
            b.booking_number,
            s.company_name AS supplier_name,
            i.invoice_number,
            i.invoice_date,
            i.due_date,
            i.currency,
            i.total_amount,
            {$paidExpr} AS paid_amount,
            GREATEST(
                i.total_amount - ({$paidExpr}),
                0
            ) AS outstanding_amount,
            i.status,
            CASE
                WHEN i.due_date IS NOT NULL
                 AND i.due_date < CURDATE()
                 AND GREATEST(
                        i.total_amount - ({$paidExpr}),
                        0
                     ) > 0.01
                THEN DATEDIFF(CURDATE(), i.due_date)
                ELSE 0
            END AS overdue_days
        FROM supplier_invoices i
        JOIN bookings b
            ON b.id = i.booking_id
        JOIN suppliers s
            ON s.id = i.supplier_id
        WHERE i.invoice_date BETWEEN ? AND ?
        ORDER BY i.invoice_date DESC, i.id DESC
        ",
        [$from, $to]
    );

    $totals = [
        'Supplier Invoices' => count($rows),
        'Invoice Total' => 0.0,
        'Paid' => 0.0,
        'Outstanding' => 0.0,
        'Overdue Outstanding' => 0.0,
    ];

    foreach ($rows as $row) {
        $totals['Invoice Total'] += (float)$row['total_amount'];
        $totals['Paid'] += (float)$row['paid_amount'];
        $totals['Outstanding'] += (float)$row['outstanding_amount'];

        if ((int)$row['overdue_days'] > 0) {
            $totals['Overdue Outstanding'] += (float)$row['outstanding_amount'];
        }
    }

    return [
        'columns' => [
            'booking_number' => 'Booking',
            'supplier_name' => 'Supplier',
            'invoice_number' => 'Invoice',
            'invoice_date' => 'Invoice Date',
            'due_date' => 'Due Date',
            'currency' => 'Currency',
            'total_amount' => 'Invoice Total',
            'paid_amount' => 'Paid',
            'outstanding_amount' => 'Outstanding',
            'overdue_days' => 'Overdue Days',
            'status' => 'Status',
        ],
        'rows' => $rows,
        'totals' => $totals,
        'note' => 'Period basis: supplier invoice_date. Historical Supplier attribution is preserved.',
    ];
}

function tsMisDestination(PDO $pdo, string $from, string $to): array
{
    if (!tsMisTableExists($pdo, 'enquiries')) {
        return [
            'columns' => [],
            'rows' => [],
            'totals' => [],
            'note' => 'Enquiries table is unavailable.',
        ];
    }

    $hasBookingBridge =
        tsMisTableExists($pdo, 'booking_trip_links')
        && tsMisTableExists($pdo, 'bookings');

    $join =
        $hasBookingBridge
            ? "
                LEFT JOIN booking_trip_links l
                    ON l.enquiry_id = e.id
                LEFT JOIN bookings b
                    ON b.id = l.booking_id
                   AND b.booking_status <> 'cancelled'
              "
            : '';

    $bookedExpr =
        $hasBookingBridge
            ? "COUNT(DISTINCT CASE WHEN b.id IS NOT NULL THEN e.id END)"
            : "SUM(CASE WHEN e.status = 'converted' THEN 1 ELSE 0 END)";

    $valueExpr =
        $hasBookingBridge
            ? "COALESCE(SUM(CASE WHEN b.id IS NOT NULL THEN b.total_amount ELSE 0 END),0)"
            : "0";

    $rows = tsMisRows(
        $pdo,
        "
        SELECT
            COALESCE(NULLIF(TRIM(e.destination),''),'Unspecified') AS destination,
            COUNT(DISTINCT e.id) AS leads,
            {$bookedExpr} AS booked_leads,
            {$valueExpr} AS booked_value
        FROM enquiries e
        {$join}
        WHERE DATE(e.created_at) BETWEEN ? AND ?
        GROUP BY destination
        ORDER BY booked_value DESC, booked_leads DESC, leads DESC
        ",
        [$from, $to]
    );

    foreach ($rows as &$row) {
        $row['conversion_percent'] =
            tsMisPct(
                (float)$row['booked_leads'],
                (float)$row['leads']
            );
    }
    unset($row);

    return [
        'columns' => [
            'destination' => 'Destination',
            'leads' => 'Leads',
            'booked_leads' => 'Booked Leads',
            'conversion_percent' => 'Conversion %',
            'booked_value' => 'Booked Value',
        ],
        'rows' => $rows,
        'totals' => [
            'Destinations' => count($rows),
            'Total Leads' => array_sum(array_map(static fn($r) => (int)$r['leads'], $rows)),
            'Booked Leads' => array_sum(array_map(static fn($r) => (int)$r['booked_leads'], $rows)),
            'Booked Value' => array_sum(array_map(static fn($r) => (float)$r['booked_value'], $rows)),
        ],
        'note' => 'Period basis: Enquiry created_at.',
    ];
}

function tsMisOwner(PDO $pdo, string $from, string $to): array
{
    if (
        !tsMisTableExists($pdo, 'crm_lead_meta')
        || !tsMisTableExists($pdo, 'enquiries')
        || !tsMisTableExists($pdo, 'admins')
    ) {
        return [
            'columns' => [],
            'rows' => [],
            'totals' => [],
            'note' => 'CRM owner metadata is unavailable.',
        ];
    }

    $hasBookingBridge =
        tsMisTableExists($pdo, 'booking_trip_links')
        && tsMisTableExists($pdo, 'bookings');

    $join =
        $hasBookingBridge
            ? "
                LEFT JOIN booking_trip_links l
                    ON l.enquiry_id = e.id
                LEFT JOIN bookings b
                    ON b.id = l.booking_id
                   AND b.booking_status <> 'cancelled'
              "
            : '';

    $bookedExpr =
        $hasBookingBridge
            ? "COUNT(DISTINCT CASE WHEN b.id IS NOT NULL THEN e.id END)"
            : "SUM(CASE WHEN e.status = 'converted' THEN 1 ELSE 0 END)";

    $valueExpr =
        $hasBookingBridge
            ? "COALESCE(SUM(CASE WHEN b.id IS NOT NULL THEN b.total_amount ELSE 0 END),0)"
            : "0";

    $rows = tsMisRows(
        $pdo,
        "
        SELECT
            COALESCE(a.name,'Unassigned') AS owner_name,
            COUNT(DISTINCT e.id) AS leads,
            {$bookedExpr} AS booked_leads,
            {$valueExpr} AS booked_value,
            SUM(
                CASE
                    WHEN m.next_follow_up_at IS NOT NULL
                     AND m.next_follow_up_at < NOW()
                     AND e.status NOT IN ('converted','closed')
                    THEN 1
                    ELSE 0
                END
            ) AS overdue_followups
        FROM crm_lead_meta m
        JOIN enquiries e
            ON e.id = m.enquiry_id
        LEFT JOIN admins a
            ON a.id = m.assigned_admin_id
        {$join}
        WHERE DATE(e.created_at) BETWEEN ? AND ?
        GROUP BY a.id, a.name
        ORDER BY booked_value DESC, booked_leads DESC, leads DESC
        ",
        [$from, $to]
    );

    foreach ($rows as &$row) {
        $row['conversion_percent'] =
            tsMisPct(
                (float)$row['booked_leads'],
                (float)$row['leads']
            );
    }
    unset($row);

    return [
        'columns' => [
            'owner_name' => 'Owner',
            'leads' => 'Leads',
            'booked_leads' => 'Booked Leads',
            'conversion_percent' => 'Conversion %',
            'booked_value' => 'Booked Value',
            'overdue_followups' => 'Overdue Follow-ups',
        ],
        'rows' => $rows,
        'totals' => [
            'Owners' => count($rows),
            'Total Leads' => array_sum(array_map(static fn($r) => (int)$r['leads'], $rows)),
            'Booked Leads' => array_sum(array_map(static fn($r) => (int)$r['booked_leads'], $rows)),
            'Booked Value' => array_sum(array_map(static fn($r) => (float)$r['booked_value'], $rows)),
            'Overdue Follow-ups' => array_sum(array_map(static fn($r) => (int)$r['overdue_followups'], $rows)),
        ],
        'note' => 'Period basis: Enquiry created_at.',
    ];
}

function tsMisRepeatSales(PDO $pdo, string $from, string $to): array
{
    if (!tsMisTableExists($pdo, 'repeat_sales_opportunities')) {
        return [
            'columns' => [],
            'rows' => [],
            'totals' => [],
            'note' => 'Repeat Sales module is unavailable.',
        ];
    }

    $ownerJoin =
        tsMisTableExists($pdo, 'admins')
            ? "LEFT JOIN admins a ON a.id = r.owner_admin_id"
            : '';

    $ownerSelect =
        tsMisTableExists($pdo, 'admins')
            ? "COALESCE(a.name,'Unassigned') AS owner_name,"
            : "'Unassigned' AS owner_name,";

    $rows = tsMisRows(
        $pdo,
        "
        SELECT
            r.id,
            r.customer_name,
            r.source_booking_id,
            {$ownerSelect}
            r.preferred_destination,
            r.preferred_travel_date,
            r.estimated_value,
            r.status,
            r.next_action_date,
            r.linked_enquiry_id,
            r.linked_booking_id,
            r.created_at,
            r.updated_at
        FROM repeat_sales_opportunities r
        {$ownerJoin}
        WHERE DATE(r.created_at) BETWEEN ? AND ?
        ORDER BY r.created_at DESC, r.id DESC
        ",
        [$from, $to]
    );

    $totals = [
        'Opportunities' => count($rows),
        'Interested' => 0,
        'Enquiries Created' => 0,
        'Booked' => 0,
        'Estimated Value' => 0.0,
    ];

    foreach ($rows as $row) {
        $status = (string)$row['status'];

        if ($status === 'interested') {
            $totals['Interested']++;
        }

        if (in_array($status, ['enquiry_created','booked'], true)) {
            $totals['Enquiries Created']++;
        }

        if ($status === 'booked') {
            $totals['Booked']++;
        }

        $totals['Estimated Value'] += (float)$row['estimated_value'];
    }

    return [
        'columns' => [
            'customer_name' => 'Customer',
            'source_booking_id' => 'Source Booking ID',
            'owner_name' => 'Owner',
            'preferred_destination' => 'Preferred Destination',
            'preferred_travel_date' => 'Preferred Travel',
            'estimated_value' => 'Estimated Value',
            'status' => 'Status',
            'next_action_date' => 'Next Action',
            'linked_enquiry_id' => 'New Enquiry ID',
            'linked_booking_id' => 'New Booking ID',
            'created_at' => 'Created At',
        ],
        'rows' => $rows,
        'totals' => $totals,
        'note' => 'Period basis: Repeat Sales opportunity created_at.',
    ];
}

function tsMisDepartureReadiness(PDO $pdo, string $from, string $to): array
{
    if (!tsMisTableExists($pdo, 'bookings')) {
        return [
            'columns' => [],
            'rows' => [],
            'totals' => [],
            'note' => 'Bookings table is unavailable.',
        ];
    }

    $rows = tsMisRows(
        $pdo,
        "
        SELECT
            id,
            booking_number,
            customer_name,
            travel_date,
            booking_status,
            currency,
            total_amount,
            paid_amount
        FROM bookings
        WHERE travel_date BETWEEN ? AND ?
          AND booking_status IN ('pending','confirmed')
        ORDER BY travel_date ASC, id ASC
        ",
        [$from, $to]
    );

    foreach ($rows as &$row) {
        $bookingId = (int)$row['id'];
        $reasons = [];
        $balance = max(
            0,
            (float)$row['total_amount']
            - (float)$row['paid_amount']
        );

        if ($balance > 0.01) {
            $reasons[] = 'Customer balance';
        }

        $supplierPending = 0;

        if (tsMisTableExists($pdo, 'booking_service_snapshots')) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM booking_service_snapshots
                WHERE booking_id = ?
                  AND source_supplier_id IS NOT NULL
                  AND procurement_status NOT IN ('confirmed','cancelled')
            ");
            $stmt->execute([$bookingId]);
            $supplierPending = (int)$stmt->fetchColumn();

            if ($supplierPending > 0) {
                $reasons[] = 'Supplier confirmation';
            }
        }

        $operationsPending = 0;

        if (tsMisTableExists($pdo, 'booking_operation_checks')) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM booking_operation_checks
                WHERE booking_id = ?
                  AND is_required = 1
                  AND is_complete = 0
            ");
            $stmt->execute([$bookingId]);
            $operationsPending = (int)$stmt->fetchColumn();

            if ($operationsPending > 0) {
                $reasons[] = 'Operations checklist';
            }
        }

        $finalVoucher = 0;

        if (tsMisTableExists($pdo, 'booking_voucher_versions')) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM booking_voucher_versions
                WHERE booking_id = ?
                  AND status = 'final'
            ");
            $stmt->execute([$bookingId]);
            $finalVoucher = (int)$stmt->fetchColumn();

            if ($finalVoucher === 0) {
                $reasons[] = 'Final voucher';
            }
        }

        $documentPack = 0;

        if (tsMisTableExists($pdo, 'booking_document_pack_versions')) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM booking_document_pack_versions
                WHERE booking_id = ?
                  AND status = 'final'
            ");
            $stmt->execute([$bookingId]);
            $documentPack = (int)$stmt->fetchColumn();

            if ($documentPack === 0) {
                $reasons[] = 'Document pack';
            }
        }

        $row['customer_balance'] = $balance;
        $row['supplier_pending'] = $supplierPending;
        $row['operations_pending'] = $operationsPending;
        $row['final_voucher'] = $finalVoucher > 0 ? 'Yes' : 'No';
        $row['document_pack'] = $documentPack > 0 ? 'Yes' : 'No';
        $row['risk_count'] = count($reasons);
        $row['risk_reasons'] = implode(' · ', $reasons);
        $row['readiness_status'] = $reasons ? 'Needs Attention' : 'Ready';
    }
    unset($row);

    $attention = array_filter(
        $rows,
        static fn($r) => (int)$r['risk_count'] > 0
    );

    return [
        'columns' => [
            'booking_number' => 'Booking',
            'customer_name' => 'Customer',
            'travel_date' => 'Departure',
            'booking_status' => 'Booking Status',
            'currency' => 'Currency',
            'customer_balance' => 'Customer Balance',
            'supplier_pending' => 'Supplier Pending',
            'operations_pending' => 'Ops Pending',
            'final_voucher' => 'Final Voucher',
            'document_pack' => 'Document Pack',
            'risk_count' => 'Risk Count',
            'risk_reasons' => 'Risk Reasons',
            'readiness_status' => 'Readiness',
        ],
        'rows' => $rows,
        'totals' => [
            'Departures' => count($rows),
            'Ready' => count($rows) - count($attention),
            'Needs Attention' => count($attention),
            'Customer Balance' => array_sum(array_map(static fn($r) => (float)$r['customer_balance'], $rows)),
        ],
        'note' => 'Period basis: Booking travel_date.',
    ];
}

function tsMisReport(
    PDO $pdo,
    string $report,
    string $from,
    string $to
): array {
    return match ($report) {
        'profitability' => tsMisProfitability($pdo, $from, $to),
        'collections' => tsMisCollections($pdo, $from, $to),
        'supplier_payables' => tsMisSupplierPayables($pdo, $from, $to),
        'destination' => tsMisDestination($pdo, $from, $to),
        'owner' => tsMisOwner($pdo, $from, $to),
        'repeat_sales' => tsMisRepeatSales($pdo, $from, $to),
        'departure_readiness' => tsMisDepartureReadiness($pdo, $from, $to),
        default => tsMisSales($pdo, $from, $to),
    };
}

function tsMisExport(
    string $format,
    string $reportLabel,
    string $from,
    string $to,
    array $columns,
    array $rows
): never {
    $safe =
        preg_replace(
            '/[^A-Za-z0-9_-]+/',
            '-',
            strtolower($reportLabel)
        );

    $safe = trim((string)$safe, '-');

    if ($format === 'xls') {
        $filename =
            'TRAVSCOPE-'
            . ($safe ?: 'report')
            . '-'
            . $from
            . '-to-'
            . $to
            . '.xls';

        header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-store, no-cache, must-revalidate');

        echo "\xEF\xBB\xBF";
        echo "<table border=\"1\">";
        echo "<tr><th colspan=\"" . max(1, count($columns)) . "\">"
            . htmlspecialchars($reportLabel, ENT_QUOTES, 'UTF-8')
            . " · "
            . htmlspecialchars($from, ENT_QUOTES, 'UTF-8')
            . " to "
            . htmlspecialchars($to, ENT_QUOTES, 'UTF-8')
            . "</th></tr>";
        echo "<tr>";

        foreach ($columns as $label) {
            echo '<th>'
                . htmlspecialchars((string)$label, ENT_QUOTES, 'UTF-8')
                . '</th>';
        }

        echo "</tr>";

        foreach ($rows as $row) {
            echo "<tr>";

            foreach ($columns as $key => $label) {
                $value = $row[$key] ?? '';

                if (is_array($value) || is_object($value)) {
                    $value = json_encode(
                        $value,
                        JSON_UNESCAPED_UNICODE
                        | JSON_UNESCAPED_SLASHES
                    );
                }

                echo '<td>'
                    . htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8')
                    . '</td>';
            }

            echo "</tr>";
        }

        echo "</table>";
        exit;
    }

    $filename =
        'TRAVSCOPE-'
        . ($safe ?: 'report')
        . '-'
        . $from
        . '-to-'
        . $to
        . '.csv';

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-store, no-cache, must-revalidate');

    $out = fopen('php://output', 'wb');

    if ($out === false) {
        exit;
    }

    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, array_values($columns));

    foreach ($rows as $row) {
        $line = [];

        foreach ($columns as $key => $label) {
            $value = $row[$key] ?? '';

            if (is_array($value) || is_object($value)) {
                $value = json_encode(
                    $value,
                    JSON_UNESCAPED_UNICODE
                    | JSON_UNESCAPED_SLASHES
                );
            }

            $line[] = $value;
        }

        fputcsv($out, $line);
    }

    fclose($out);
    exit;
}
