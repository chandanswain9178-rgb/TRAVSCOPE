<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/document-functions.php';

$documentId =
    max(
        0,
        (int)(
            $_GET['document']
            ?? 0
        )
    );

if (
    $documentId <= 0
    || !tsDocReady($pdo)
) {
    http_response_code(404);
    exit('Document not found.');
}

$stmt = $pdo->prepare("
    SELECT
        d.*,
        b.user_id
    FROM booking_travel_documents d
    JOIN bookings b
        ON b.id = d.booking_id
    WHERE d.id = ?
    LIMIT 1
");
$stmt->execute([$documentId]);

$document =
    $stmt->fetch(PDO::FETCH_ASSOC)
    ?: null;

if (!$document) {
    http_response_code(404);
    exit('Document not found.');
}

$isAdmin =
    !empty($_SESSION['admin_id']);

if (!$isAdmin) {
    requireLogin();

    $user =
        currentUser($pdo);

    if (
        !$user
        || (int)$document['user_id']
            !== (int)$user['id']
        || empty($document['customer_visible'])
        || (string)$document['verification_status']
            === 'archived'
    ) {
        http_response_code(403);
        exit('You do not have permission to view this document.');
    }
}

$bookingId =
    (int)$document['booking_id'];

$relative =
    ltrim(
        trim(
            (string)$document['file_path']
        ),
        '/'
    );

$requiredPrefix =
    'uploads/booking-documents/booking_'
    . $bookingId
    . '/';

$full =
    tsDocSafeExistingPath(
        $relative,
        $requiredPrefix
    );

if (!$full) {
    http_response_code(404);
    exit('Document file is unavailable.');
}

$mime =
    trim(
        (string)(
            $document['mime_type']
            ?? ''
        )
    );

if ($mime === '') {
    $finfo =
        new finfo(
            FILEINFO_MIME_TYPE
        );

    $mime =
        (string)$finfo->file(
            $full
        );
}

$allowedMime = [
    'application/pdf',
    'image/jpeg',
    'image/png',
    'image/webp',
];

if (!in_array($mime, $allowedMime, true)) {
    $mime =
        'application/octet-stream';
}

$original =
    basename(
        (string)(
            $document['original_name']
            ?: 'travel-document'
        )
    );

header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store, max-age=0');
header('Pragma: no-cache');
header('Content-Type: ' . $mime);
header(
    'Content-Disposition: inline; filename="'
    . str_replace(
        ['"', "\r", "\n"],
        '',
        $original
    )
    . '"; filename*=UTF-8\'\''
    . rawurlencode($original)
);
header(
    'Content-Length: '
    . (string)filesize($full)
);

readfile($full);
exit;
