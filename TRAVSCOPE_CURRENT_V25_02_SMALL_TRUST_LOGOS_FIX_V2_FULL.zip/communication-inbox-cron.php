<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(403);exit("CLI only\n");}
require_once __DIR__.'/config.php';
require_once __DIR__.'/communication-center-functions.php';
$days=14;foreach($argv as $arg){if(preg_match('/^--days=(\d+)$/',$arg,$m))$days=max(1,min(90,(int)$m[1]));}
$result=tsCommSyncInbox($pdo,$days);
echo json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES).PHP_EOL;
exit(($result['available']??false)&&empty($result['error'])?0:1);
