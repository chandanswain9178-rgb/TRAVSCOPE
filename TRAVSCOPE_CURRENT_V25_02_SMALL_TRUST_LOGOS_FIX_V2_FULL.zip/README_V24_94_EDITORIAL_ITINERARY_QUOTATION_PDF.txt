TRAVSCOPE V24.94 — Editorial Itinerary + International Quotation PDF
====================================================================

Base: V24.93 — International Itinerary Spacing

PUBLIC PACKAGE DAY-WISE ITINERARY
- Day eyebrow + title now span the full itinerary card.
- Day photo floats at the left of the narrative on desktop/tablet.
- Narrative wraps naturally beside the photo and continues full-width below it.
- This removes the empty right-column gutter that appears when a long 190–200 word narrative is locked inside a fixed two-column grid.
- Narrative remains justified on desktop for a premium brochure/editorial appearance.
- Mobile switches to a clean single-column image-then-text layout.
- Existing route metadata de-duplication and 200-word guard remain active.
- Existing uncropped/full-photo behaviour remains active.

QUOTATION PREVIEW / PDF
- Day-wise itinerary redesigned to the same editorial presentation.
- Compact Day badge + full title header.
- Itinerary photo floats left and narrative wraps beside/under it.
- Narrative is justified in preview/PDF with improved line rhythm.
- Existing trailing [Start / Via / End / Distance / Travel Time] metadata is separated from narrative and shown once below the day copy where present.
- A4 print/PDF spacing tightened: smaller hero, metadata, section, table and card spacing.
- Improved PDF typography, page-break behaviour and table row protection.
- Existing quotation content, rates, hotels, transport, flights, trains, inclusions, exclusions and terms remain unchanged.

FILES CHANGED
- package-details.php
- admin-crm.php

DATABASE
- No SQL required.
