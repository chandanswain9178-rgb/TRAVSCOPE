<?php
declare(strict_types=1);
if (is_file(__DIR__.'/location-master-functions.php')) require_once __DIR__.'/location-master-functions.php';

/* TRAVSCOPE V20.5 - Manual-first Supplier Package helpers.
 * Manual supplier package data is written into the existing seasonal supplier
 * contract/rate-engine tables so Package Master and CRM quotation rate finder
 * continue using one source of truth.
 */

function tsMSTable(PDO $pdo,string $table):bool{
    try{$s=$pdo->query("SHOW TABLES LIKE ".$pdo->quote($table));return (bool)$s->fetchColumn();}catch(Throwable $e){return false;}
}
function tsMSColumn(PDO $pdo,string $table,string $column):bool{
    try{$s=$pdo->query("SHOW COLUMNS FROM `".str_replace('`','',$table)."` LIKE ".$pdo->quote($column));return (bool)$s->fetch(PDO::FETCH_ASSOC);}catch(Throwable $e){return false;}
}
function tsMSReady(PDO $pdo):bool{
    foreach(['supplier_contracts','supplier_contract_versions','supplier_contract_itineraries','supplier_contract_rate_groups','supplier_contract_pax_rates'] as $t){if(!tsMSTable($pdo,$t))return false;}
    return tsMSColumn($pdo,'supplier_contracts','entry_mode') && tsMSColumn($pdo,'supplier_contracts','record_type');
}
function tsMSCode(string $value):string{
    $value=strtoupper(trim($value));$value=preg_replace('/[^A-Z0-9]+/','-',$value)??$value;return trim($value,'-');
}
function tsMSSeasonKey(string $value):string{
    $x=strtolower(trim($value));$x=preg_replace('/[^a-z0-9]+/','-',$x)??$x;return trim($x,'-')?:'regular';
}
function tsMSContractCode(PDO $pdo,int $supplierId,string $supplierCode):string{
    $base='SPKG-'.(tsMSCode($supplierCode)?:str_pad((string)$supplierId,4,'0',STR_PAD_LEFT)).'-'.date('ymd');
    for($i=1;$i<1000;$i++){$code=$base.'-'.str_pad((string)$i,3,'0',STR_PAD_LEFT);$s=$pdo->prepare('SELECT id FROM supplier_contracts WHERE contract_code=? LIMIT 1');$s->execute([$code]);if(!$s->fetchColumn())return $code;}
    return $base.'-'.strtoupper(bin2hex(random_bytes(2)));
}
function tsMSItineraryCode(PDO $pdo,int $contractId,int $versionNo,string $supplierPackageCode):string{
    $base='MAN-'.str_pad((string)$contractId,5,'0',STR_PAD_LEFT).'-V'.$versionNo;
    $pkg=tsMSCode($supplierPackageCode);if($pkg!=='')$base.='-'.$pkg;
    $code=substr($base,0,68);$n=1;
    while(true){$s=$pdo->prepare('SELECT id FROM supplier_contract_itineraries WHERE itinerary_code=? LIMIT 1');$s->execute([$code]);if(!$s->fetchColumn())return $code;$code=substr($base,0,63).'-'.$n++;}
}
function tsMSSupplier(PDO $pdo,int $supplierId):?array{
    $s=$pdo->prepare('SELECT * FROM suppliers WHERE id=? LIMIT 1');$s->execute([$supplierId]);return $s->fetch(PDO::FETCH_ASSOC)?:null;
}
function tsMSPackage(PDO $pdo,int $contractId):?array{
    $s=$pdo->prepare("SELECT c.*,s.company_name,s.supplier_code,s.default_currency FROM supplier_contracts c JOIN suppliers s ON s.id=c.supplier_id WHERE c.id=? AND COALESCE(c.record_type,'service')='package' LIMIT 1");$s->execute([$contractId]);return $s->fetch(PDO::FETCH_ASSOC)?:null;
}
function tsMSVersions(PDO $pdo,int $contractId):array{
    $s=$pdo->prepare("SELECT v.*,(SELECT COUNT(*) FROM supplier_contract_itineraries i WHERE i.contract_version_id=v.id) itinerary_count,(SELECT COUNT(*) FROM supplier_contract_pax_rates p WHERE p.contract_version_id=v.id AND p.status='active') pax_rows FROM supplier_contract_versions v WHERE v.contract_id=? ORDER BY v.rate_priority DESC,v.valid_from DESC,v.version_no DESC");$s->execute([$contractId]);return $s->fetchAll(PDO::FETCH_ASSOC)?:[];
}
function tsMSItineraryForVersion(PDO $pdo,int $versionId):?array{
    $s=$pdo->prepare('SELECT * FROM supplier_contract_itineraries WHERE contract_version_id=? ORDER BY source_order,id LIMIT 1');$s->execute([$versionId]);return $s->fetch(PDO::FETCH_ASSOC)?:null;
}
function tsMSDestinationOptions(PDO $pdo):array{
    try{return $pdo->query("SELECT id,name,country,status FROM destinations WHERE status='active' ORDER BY country,name")->fetchAll(PDO::FETCH_ASSOC)?:[];}catch(Throwable $e){return [];}
}
function tsMSCreatePackage(PDO $pdo,array $in,int $adminId):array{
    if(!tsMSReady($pdo))throw new RuntimeException('Import the V20.1 Manual Supplier Package SQL first.');
    $supplierId=max(0,(int)($in['supplier_id']??0));$supplier=tsMSSupplier($pdo,$supplierId);if(!$supplier)throw new RuntimeException('Supplier not found.');
    $title=trim((string)($in['title']??''));$supplierPackageCode=trim((string)($in['supplier_package_code']??''));
    $destinationId=max(0,(int)($in['destination_id']??0));$nights=max(0,(int)($in['duration_nights']??0));$days=max(1,(int)($in['duration_days']??($nights+1)));
    $validFrom=trim((string)($in['valid_from']??''));$validTo=trim((string)($in['valid_to']??''));
    if($title==='')throw new RuntimeException('Supplier package name is required.');if($supplierPackageCode==='')throw new RuntimeException('Supplier package code is required.');
    if($validFrom===''||$validTo==='')throw new RuntimeException('Season validity dates are required.');if($validTo<$validFrom)throw new RuntimeException('Valid To cannot be before Valid From.');
    $seasonName=trim((string)($in['season_name']??'Regular Season'))?:'Regular Season';$seasonType=trim((string)($in['season_type']??'regular'))?:'regular';$priority=max(0,(int)($in['rate_priority']??10));
    $basis=(string)($in['applicability_basis']??'arrival_date');if(!in_array($basis,['arrival_date','departure_date','majority_nights','per_night','per_service_date','manual_confirmation'],true))$basis='arrival_date';
    $currency=strtoupper(trim((string)($in['currency']??$supplier['default_currency']??'INR')))?:'INR';$status=(string)($in['status']??'active');if(!in_array($status,['review','active'],true))$status='review';$contractStatus=$status==='active'?'active':'draft';
    $code=tsMSContractCode($pdo,$supplierId,(string)($supplier['supplier_code']??''));
    $pdo->beginTransaction();
    try{
        $sourceReference=trim((string)($in['source_reference']??'MANUAL ENTRY'))?:'MANUAL ENTRY';
        $pdo->prepare("INSERT INTO supplier_contracts(supplier_id,contract_code,contract_name,record_type,entry_mode,currency,valid_from,valid_to,status,source_reference,supplier_tax_percent,tax_included,payment_terms,cancellation_terms,notes,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,'package','manual',?,?,?,?,?,?,?,?,?,?,?,?)")
            ->execute([$supplierId,$code,$title,$currency,$validFrom,$validTo,$contractStatus,$sourceReference,max(0,(float)($in['supplier_tax_percent']??0)),!empty($in['tax_included'])?1:0,trim((string)($in['payment_terms']??''))?:null,trim((string)($in['cancellation_terms']??''))?:null,trim((string)($in['notes']??''))?:null,$adminId?:null,$adminId?:null]);
        $contractId=(int)$pdo->lastInsertId();
        $activated=$status==='active'?date('Y-m-d H:i:s'):null;
        $pdo->prepare("INSERT INTO supplier_contract_versions(contract_id,supplier_document_id,version_no,version_label,season_name,season_key,season_type,rate_priority,applicability_basis,valid_from,valid_to,currency,supplier_tax_percent,tax_included,payment_terms,cancellation_terms,transport_terms,meal_plan,source_snapshot_json,status,created_by_admin_id,activated_by_admin_id,activated_at) VALUES(?,NULL,1,'Manual V1',?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL,?,?,?,?)")
            ->execute([$contractId,$seasonName,tsMSSeasonKey($seasonName),$seasonType,$priority,$basis,$validFrom,$validTo,$currency,max(0,(float)($in['supplier_tax_percent']??0)),!empty($in['tax_included'])?1:0,trim((string)($in['payment_terms']??''))?:null,trim((string)($in['cancellation_terms']??''))?:null,trim((string)($in['transport_terms']??''))?:null,trim((string)($in['meal_plan']??''))?:null,$status,$adminId?:null,$status==='active'?($adminId?:null):null,$activated]);
        $versionId=(int)$pdo->lastInsertId();
        $itCode=tsMSItineraryCode($pdo,$contractId,1,$supplierPackageCode);
        $pdo->prepare("INSERT INTO supplier_contract_itineraries(contract_version_id,contract_id,supplier_document_id,supplier_id,destination_id,itinerary_code,supplier_package_code,title,duration_nights,duration_days,itinerary_text,inclusions,exclusions,meal_plan,currency,valid_from,valid_to,source_order,source_heading,status,created_by_admin_id,updated_by_admin_id) VALUES(?,?,NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?,?)")
            ->execute([$versionId,$contractId,$supplierId,$destinationId?:null,$itCode,$supplierPackageCode,$title,$nights,$days,trim((string)($in['itinerary_text']??''))?:null,trim((string)($in['inclusions']??''))?:null,trim((string)($in['exclusions']??''))?:null,trim((string)($in['meal_plan']??''))?:null,$currency,$validFrom,$validTo,$supplierPackageCode,$status==='active'?'active':'review',$adminId?:null,$adminId?:null]);
        $itineraryId=(int)$pdo->lastInsertId();
        $pdo->commit();return ['contract_id'=>$contractId,'version_id'=>$versionId,'itinerary_id'=>$itineraryId];
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function tsMSAddSeason(PDO $pdo,int $contractId,array $in,int $adminId):array{
    $pkg=tsMSPackage($pdo,$contractId);if(!$pkg)throw new RuntimeException('Manual supplier package not found.');
    $versions=tsMSVersions($pdo,$contractId);$latest=$versions[0]??null;if(!$latest)throw new RuntimeException('Existing package season was not found.');
    $baseIt=tsMSItineraryForVersion($pdo,(int)$latest['id']);if(!$baseIt)throw new RuntimeException('Base supplier package itinerary was not found.');
    $validFrom=trim((string)($in['valid_from']??''));$validTo=trim((string)($in['valid_to']??''));if($validFrom===''||$validTo===''||$validTo<$validFrom)throw new RuntimeException('Enter a valid season date range.');
    $seasonName=trim((string)($in['season_name']??''))?:'New Season';$seasonType=trim((string)($in['season_type']??'regular'))?:'regular';$priority=max(0,(int)($in['rate_priority']??10));$basis=(string)($in['applicability_basis']??'arrival_date');if(!in_array($basis,['arrival_date','departure_date','majority_nights','per_night','per_service_date','manual_confirmation'],true))$basis='arrival_date';
    $status=(string)($in['status']??'review');if(!in_array($status,['review','active'],true))$status='review';$versionNo=1+(int)$pdo->query("SELECT COALESCE(MAX(version_no),0) FROM supplier_contract_versions WHERE contract_id=".$contractId)->fetchColumn();
    $pdo->beginTransaction();try{
        $pdo->prepare("INSERT INTO supplier_contract_versions(contract_id,supplier_document_id,version_no,version_label,season_name,season_key,season_type,rate_priority,applicability_basis,valid_from,valid_to,currency,supplier_tax_percent,tax_included,payment_terms,cancellation_terms,transport_terms,meal_plan,source_snapshot_json,status,created_by_admin_id,activated_by_admin_id,activated_at) VALUES(?,NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL,?,?,?,?)")
            ->execute([$contractId,$versionNo,'Manual V'.$versionNo,$seasonName,tsMSSeasonKey($seasonName),$seasonType,$priority,$basis,$validFrom,$validTo,(string)$latest['currency'],(float)$latest['supplier_tax_percent'],(int)$latest['tax_included'],$latest['payment_terms'],$latest['cancellation_terms'],$latest['transport_terms'],$latest['meal_plan'],$status,$adminId?:null,$status==='active'?($adminId?:null):null,$status==='active'?date('Y-m-d H:i:s'):null]);
        $versionId=(int)$pdo->lastInsertId();$itCode=tsMSItineraryCode($pdo,$contractId,$versionNo,(string)$baseIt['supplier_package_code']);
        $pdo->prepare("INSERT INTO supplier_contract_itineraries(contract_version_id,contract_id,supplier_document_id,supplier_id,destination_id,itinerary_code,supplier_package_code,title,duration_nights,duration_days,itinerary_text,inclusions,exclusions,meal_plan,currency,valid_from,valid_to,source_order,source_heading,status,created_by_admin_id,updated_by_admin_id) VALUES(?,?,NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?,?)")
            ->execute([$versionId,$contractId,(int)$baseIt['supplier_id'],$baseIt['destination_id'],$itCode,$baseIt['supplier_package_code'],$baseIt['title'],$baseIt['duration_nights'],$baseIt['duration_days'],$baseIt['itinerary_text'],$baseIt['inclusions'],$baseIt['exclusions'],$baseIt['meal_plan'],$baseIt['currency'],$validFrom,$validTo,$baseIt['source_heading'],$status==='active'?'active':'review',$adminId?:null,$adminId?:null]);
        $newIt=(int)$pdo->lastInsertId();
        if(tsMSTable($pdo,'supplier_contract_day_itineraries')){$s=$pdo->prepare("SELECT * FROM supplier_contract_day_itineraries WHERE itinerary_id=? ORDER BY day_number");$s->execute([(int)$baseIt['id']]);$ins=$pdo->prepare("INSERT INTO supplier_contract_day_itineraries(contract_version_id,itinerary_id,supplier_package_code,day_number,day_title,day_description,overnight_city,source_excerpt,status,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)");foreach($s->fetchAll(PDO::FETCH_ASSOC)?:[] as $d){$ins->execute([$versionId,$newIt,$baseIt['supplier_package_code'],$d['day_number'],$d['day_title'],$d['day_description'],$d['overnight_city'],null,$status==='active'?'active':'review',$adminId?:null,$adminId?:null]);}}
        $pdo->prepare("UPDATE supplier_contracts SET valid_from=LEAST(valid_from,?),valid_to=GREATEST(valid_to,?),status=IF(status='inactive','inactive',?),updated_by_admin_id=?,updated_at=NOW() WHERE id=?")->execute([$validFrom,$validTo,$status==='active'?'active':'draft',$adminId?:null,$contractId]);
        $pdo->commit();return ['version_id'=>$versionId,'itinerary_id'=>$newIt];
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function tsMSSaveOverview(PDO $pdo,int $contractId,int $versionId,array $in,int $adminId):void{
    $pkg=tsMSPackage($pdo,$contractId);if(!$pkg)throw new RuntimeException('Supplier package not found.');$it=tsMSItineraryForVersion($pdo,$versionId);if(!$it)throw new RuntimeException('Season itinerary not found.');
    $title=trim((string)($in['title']??''));$code=trim((string)($in['supplier_package_code']??''));if($title===''||$code==='')throw new RuntimeException('Package name and supplier package code are required.');
    $destinationId=max(0,(int)($in['destination_id']??0));$nights=max(0,(int)($in['duration_nights']??0));$days=max(1,(int)($in['duration_days']??($nights+1)));$meal=trim((string)($in['meal_plan']??''));
    $pdo->beginTransaction();try{
        $pdo->prepare("UPDATE supplier_contracts SET contract_name=?,notes=?,payment_terms=?,cancellation_terms=?,updated_by_admin_id=?,updated_at=NOW() WHERE id=?")->execute([$title,trim((string)($in['notes']??''))?:null,trim((string)($in['payment_terms']??''))?:null,trim((string)($in['cancellation_terms']??''))?:null,$adminId?:null,$contractId]);
        $pdo->prepare("UPDATE supplier_contract_itineraries SET destination_id=?,supplier_package_code=?,title=?,duration_nights=?,duration_days=?,itinerary_text=?,inclusions=?,exclusions=?,meal_plan=?,source_heading=?,updated_by_admin_id=?,updated_at=NOW() WHERE contract_id=?")->execute([$destinationId?:null,$code,$title,$nights,$days,trim((string)($in['itinerary_text']??''))?:null,trim((string)($in['inclusions']??''))?:null,trim((string)($in['exclusions']??''))?:null,$meal?:null,$code,$adminId?:null,$contractId]);
        $pdo->prepare("UPDATE supplier_contract_versions SET meal_plan=?,payment_terms=?,cancellation_terms=?,transport_terms=?,updated_at=NOW() WHERE contract_id=?")->execute([$meal?:null,trim((string)($in['payment_terms']??''))?:null,trim((string)($in['cancellation_terms']??''))?:null,trim((string)($in['transport_terms']??''))?:null,$contractId]);
        $pdo->commit();
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function tsMSSaveSeason(PDO $pdo,int $contractId,int $versionId,array $in,int $adminId):void{
    $validFrom=trim((string)($in['valid_from']??''));$validTo=trim((string)($in['valid_to']??''));if($validFrom===''||$validTo===''||$validTo<$validFrom)throw new RuntimeException('Enter a valid season date range.');
    $name=trim((string)($in['season_name']??''))?:'Regular Season';$type=trim((string)($in['season_type']??'regular'))?:'regular';$priority=max(0,(int)($in['rate_priority']??10));$basis=(string)($in['applicability_basis']??'arrival_date');if(!in_array($basis,['arrival_date','departure_date','majority_nights','per_night','per_service_date','manual_confirmation'],true))$basis='arrival_date';$status=(string)($in['status']??'review');if(!in_array($status,['review','active','superseded','expired','rejected'],true))$status='review';
    if($status==='active'){
        $s=$pdo->prepare("SELECT id,season_name,rate_priority,valid_from,valid_to FROM supplier_contract_versions WHERE contract_id=? AND id<>? AND status='active' AND NOT (valid_to < ? OR valid_from > ?)");$s->execute([$contractId,$versionId,$validFrom,$validTo]);foreach($s->fetchAll(PDO::FETCH_ASSOC)?:[] as $r){if((int)$r['rate_priority']===$priority)throw new RuntimeException('This active season overlaps '.$r['season_name'].' with the same priority. Give Peak/High season a higher priority.');}
    }
    $pdo->beginTransaction();try{
        $pdo->prepare("UPDATE supplier_contract_versions SET season_name=?,season_key=?,season_type=?,rate_priority=?,applicability_basis=?,valid_from=?,valid_to=?,status=?,activated_by_admin_id=?,activated_at=?,updated_at=NOW() WHERE id=? AND contract_id=?")
            ->execute([$name,tsMSSeasonKey($name),$type,$priority,$basis,$validFrom,$validTo,$status,$status==='active'?($adminId?:null):null,$status==='active'?date('Y-m-d H:i:s'):null,$versionId,$contractId]);
        $pdo->prepare("UPDATE supplier_contract_itineraries SET valid_from=?,valid_to=?,status=?,updated_by_admin_id=?,updated_at=NOW() WHERE contract_version_id=?")->execute([$validFrom,$validTo,$status==='active'?'active':'review',$adminId?:null,$versionId]);
        $pdo->prepare("UPDATE supplier_contract_rate_groups SET valid_from=?,valid_to=?,status=? WHERE contract_version_id=?")->execute([$validFrom,$validTo,$status==='active'?'active':'review',$versionId]);
        $pdo->prepare("UPDATE supplier_contract_pax_rates SET status=? WHERE contract_version_id=?")->execute([$status==='active'?'active':'review',$versionId]);
        $pdo->prepare("UPDATE supplier_contracts SET valid_from=(SELECT MIN(valid_from) FROM supplier_contract_versions WHERE contract_id=?),valid_to=(SELECT MAX(valid_to) FROM supplier_contract_versions WHERE contract_id=?),status=IF(EXISTS(SELECT 1 FROM supplier_contract_versions WHERE contract_id=? AND status='active'),'active','draft'),updated_by_admin_id=?,updated_at=NOW() WHERE id=?")->execute([$contractId,$contractId,$contractId,$adminId?:null,$contractId]);
        $pdo->commit();
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function tsMSRateGroups(PDO $pdo,int $versionId):array{
    $s=$pdo->prepare("SELECT g.*,(SELECT COUNT(*) FROM supplier_contract_pax_rates p WHERE p.rate_group_id=g.id) pax_count FROM supplier_contract_rate_groups g WHERE g.contract_version_id=? ORDER BY g.source_order,g.id");$s->execute([$versionId]);$rows=$s->fetchAll(PDO::FETCH_ASSOC)?:[];
    foreach($rows as &$r){$p=$pdo->prepare("SELECT * FROM supplier_contract_pax_rates WHERE rate_group_id=? ORDER BY pax_min,pax_max,id");$p->execute([(int)$r['id']]);$r['pax_rates']=$p->fetchAll(PDO::FETCH_ASSOC)?:[];}unset($r);return $rows;
}
function tsMSSaveRateGroup(PDO $pdo,int $versionId,int $itineraryId,array $in,int $adminId):int{
    $it=tsMSItineraryForVersion($pdo,$versionId);if(!$it||(int)$it['id']!==$itineraryId)throw new RuntimeException('Supplier package season not found.');
    $category=trim((string)($in['supplier_category']??''));if($category==='')throw new RuntimeException('Hotel/category name is required.');$star=max(0,min(5,(int)($in['mapped_star_category']??0)));$meal=trim((string)($in['meal_plan']??$it['meal_plan']??''));$status=(string)($in['status']??'active');if(!in_array($status,['review','active','inactive'],true))$status='active';
    $v=$pdo->prepare('SELECT v.*,c.supplier_id,c.id contract_id FROM supplier_contract_versions v JOIN supplier_contracts c ON c.id=v.contract_id WHERE v.id=? LIMIT 1');$v->execute([$versionId]);$ver=$v->fetch(PDO::FETCH_ASSOC);if(!$ver)throw new RuntimeException('Season not found.');
    $paxes=(array)($in['pax']??[]);$rates=(array)($in['rate']??[]);$pairs=[];foreach($paxes as $k=>$pv){$p=max(0,(int)$pv);$amt=(float)str_replace(',','',(string)($rates[$k]??''));if($p>0&&$amt>0)$pairs[$p]=$amt;}if(!$pairs)throw new RuntimeException('Enter at least one exact PAX rate.');ksort($pairs);
    $pdo->beginTransaction();try{
        $find=$pdo->prepare("SELECT id FROM supplier_contract_rate_groups WHERE itinerary_id=? AND LOWER(TRIM(supplier_category))=LOWER(TRIM(?)) LIMIT 1");$find->execute([$itineraryId,$category]);$groupId=(int)($find->fetchColumn()?:0);
        $vals=[$category,$star?:null,$meal?:null,$ver['currency'],((string)($in['extra_bed_rate']??'')==='')?null:(float)$in['extra_bed_rate'],((string)($in['child_without_bed_rate']??'')==='')?null:(float)$in['child_without_bed_rate'],((string)($in['child_with_bed_rate']??'')==='')?null:(float)$in['child_with_bed_rate'],((string)($in['infant_rate']??'')==='')?null:(float)$in['infant_rate'],trim((string)($in['child_with_bed_basis']??'not_available'))?:'not_available',(int)$ver['tax_included'],(float)$ver['supplier_tax_percent'],$ver['valid_from'],$ver['valid_to'],$status,$adminId?:null];
        if($groupId>0){$pdo->prepare("UPDATE supplier_contract_rate_groups SET supplier_category=?,mapped_star_category=?,meal_plan=?,currency=?,extra_bed_rate=?,child_without_bed_rate=?,child_with_bed_rate=?,infant_rate=?,child_with_bed_basis=?,tax_included=?,tax_percent=?,valid_from=?,valid_to=?,status=?,updated_by_admin_id=?,updated_at=NOW() WHERE id=?")->execute([...$vals,$groupId]);$pdo->prepare('DELETE FROM supplier_contract_pax_rates WHERE rate_group_id=?')->execute([$groupId]);}
        else{$order=10+(int)$pdo->query("SELECT COALESCE(MAX(source_order),0) FROM supplier_contract_rate_groups WHERE itinerary_id=".$itineraryId)->fetchColumn();$pdo->prepare("INSERT INTO supplier_contract_rate_groups(itinerary_id,contract_version_id,contract_id,supplier_id,supplier_category,mapped_star_category,meal_plan,currency,extra_bed_rate,child_without_bed_rate,child_with_bed_rate,infant_rate,child_with_bed_basis,tax_included,tax_percent,valid_from,valid_to,source_order,source_excerpt,status,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL,?,?,?)")
                ->execute([$itineraryId,$versionId,(int)$ver['contract_id'],(int)$ver['supplier_id'],$category,$star?:null,$meal?:null,$ver['currency'],$vals[4],$vals[5],$vals[6],$vals[7],$vals[8],$vals[9],$vals[10],$vals[11],$vals[12],$order,$status,$adminId?:null,$adminId?:null]);$groupId=(int)$pdo->lastInsertId();}
        $ins=$pdo->prepare("INSERT INTO supplier_contract_pax_rates(rate_group_id,itinerary_id,contract_version_id,pax_min,pax_max,source_pax_label,rate_per_person,status,sort_order,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)");$sort=10;foreach($pairs as $p=>$amt){$ins->execute([$groupId,$itineraryId,$versionId,$p,$p,str_pad((string)$p,2,'0',STR_PAD_LEFT).' PAX',$amt,$status,$sort,$adminId?:null,$adminId?:null]);$sort+=10;}
        $pdo->commit();return $groupId;
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function tsMSDeleteRateGroup(PDO $pdo,int $versionId,int $groupId):void{$pdo->beginTransaction();try{$s=$pdo->prepare('SELECT id FROM supplier_contract_rate_groups WHERE id=? AND contract_version_id=?');$s->execute([$groupId,$versionId]);if(!$s->fetchColumn())throw new RuntimeException('Rate category not found.');$pdo->prepare('DELETE FROM supplier_contract_pax_rates WHERE rate_group_id=?')->execute([$groupId]);$pdo->prepare('DELETE FROM supplier_contract_rate_groups WHERE id=?')->execute([$groupId]);$pdo->commit();}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}}
function tsMSDays(PDO $pdo,int $itineraryId):array{if(!tsMSTable($pdo,'supplier_contract_day_itineraries'))return [];$s=$pdo->prepare('SELECT * FROM supplier_contract_day_itineraries WHERE itinerary_id=? ORDER BY day_number,id');$s->execute([$itineraryId]);return $s->fetchAll(PDO::FETCH_ASSOC)?:[];}
function tsMSSaveDays(PDO $pdo,int $versionId,int $itineraryId,array $in,int $adminId):void{
    if(!tsMSTable($pdo,'supplier_contract_day_itineraries'))throw new RuntimeException('V19 day itinerary table is missing.');$it=tsMSItineraryForVersion($pdo,$versionId);if(!$it||(int)$it['id']!==$itineraryId)throw new RuntimeException('Supplier package season not found.');
    $titles=(array)($in['day_title']??[]);$desc=(array)($in['day_description']??[]);$night=(array)($in['overnight_city']??[]);$status=((string)($in['status']??'active'))==='review'?'review':'active';
    $pdo->beginTransaction();try{$pdo->prepare('DELETE FROM supplier_contract_day_itineraries WHERE itinerary_id=?')->execute([$itineraryId]);$ins=$pdo->prepare("INSERT INTO supplier_contract_day_itineraries(contract_version_id,itinerary_id,supplier_package_code,day_number,day_title,day_description,overnight_city,status,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?)");foreach($titles as $k=>$t){$n=(int)$k+1;$t=trim((string)$t);$d=trim((string)($desc[$k]??''));$o=trim((string)($night[$k]??''));if($t===''&&$d===''&&$o==='')continue;$ins->execute([$versionId,$itineraryId,$it['supplier_package_code'],$n,$t!==''?$t:('Day '.$n),$d?:null,$o?:null,$status,$adminId?:null,$adminId?:null]);}$pdo->commit();}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function tsMSHotels(PDO $pdo,int $versionId):array{if(!tsMSTable($pdo,'supplier_contract_hotel_inventory'))return [];$s=$pdo->prepare("SELECT * FROM supplier_contract_hotel_inventory WHERE contract_version_id=? ORDER BY city,supplier_category,source_order,id");$s->execute([$versionId]);return $s->fetchAll(PDO::FETCH_ASSOC)?:[];}
function tsMSSaveHotels(PDO $pdo,int $versionId,array $in,int $adminId):void{
    if(!tsMSTable($pdo,'supplier_contract_hotel_inventory'))throw new RuntimeException('Supplier hotel inventory table is missing.');
    $v=$pdo->prepare('SELECT v.*,c.supplier_id,c.id contract_id FROM supplier_contract_versions v JOIN supplier_contracts c ON c.id=v.contract_id WHERE v.id=?');
    $v->execute([$versionId]);$ver=$v->fetch(PDO::FETCH_ASSOC);if(!$ver)throw new RuntimeException('Season not found.');

    $city=(array)($in['hotel_city']??[]);$cat=(array)($in['hotel_category']??[]);$name=(array)($in['hotel_name']??[]);
    $room=(array)($in['hotel_room']??[]);$meal=(array)($in['hotel_meal']??[]);$dest=(array)($in['hotel_destination_id']??[]);
    $hasLocation=tsMSColumn($pdo,'supplier_contract_hotel_inventory','location_id');
    $hasHotelId=tsMSColumn($pdo,'supplier_contract_hotel_inventory','hotel_id');

    $pdo->beginTransaction();
    try{
        $pdo->prepare('DELETE FROM supplier_contract_hotel_inventory WHERE contract_version_id=?')->execute([$versionId]);
        if($hasLocation && $hasHotelId){
            $ins=$pdo->prepare("INSERT INTO supplier_contract_hotel_inventory(contract_version_id,contract_id,supplier_document_id,supplier_id,destination_id,location_id,city,supplier_category,mapped_star_category,hotel_name,hotel_name_normalized,hotel_id,room_type,meal_plan,valid_from,valid_to,mapping_status,status,source_order,created_by_admin_id,updated_by_admin_id) VALUES(?,?,NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'active',?,?,?)");
        }elseif($hasHotelId){
            $ins=$pdo->prepare("INSERT INTO supplier_contract_hotel_inventory(contract_version_id,contract_id,supplier_document_id,supplier_id,destination_id,city,supplier_category,mapped_star_category,hotel_name,hotel_name_normalized,hotel_id,room_type,meal_plan,valid_from,valid_to,mapping_status,status,source_order,created_by_admin_id,updated_by_admin_id) VALUES(?,?,NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,'active',?,?,?)");
        }else{
            $ins=$pdo->prepare("INSERT INTO supplier_contract_hotel_inventory(contract_version_id,contract_id,supplier_document_id,supplier_id,destination_id,city,supplier_category,mapped_star_category,hotel_name,hotel_name_normalized,room_type,meal_plan,valid_from,valid_to,mapping_status,status,source_order,created_by_admin_id,updated_by_admin_id) VALUES(?,?,NULL,?,?,?,?,?,?,?,?,?,?,?,?,'unmatched','active',?,?,?)");
        }
        $order=10;
        foreach($name as $k=>$hotel){
            $hotel=trim((string)$hotel);if($hotel==='')continue;
            $c=trim((string)($city[$k]??''));$cg=trim((string)($cat[$k]??''))?:'Deluxe';
            $destinationId=max(0,(int)($dest[$k]??0));
            $star=0;if(preg_match('/([345])\s*(?:star|★|\*)?/i',$cg,$m))$star=(int)$m[1];
            $norm=strtolower(trim(preg_replace('/\s+/',' ',$hotel)??$hotel));
            $locationId=0;
            if($destinationId>0 && $c!=='' && function_exists('tsLocationUpsert')){
                try{$locationId=tsLocationUpsert($pdo,$destinationId,$c,'supplier_manual',$adminId?:null);}catch(Throwable $ignored){}
            }
            $hotelId=0;$mapping='unmatched';
            if($hasHotelId && tsMSTable($pdo,'hotels')){
                try{
                    $sql="SELECT h.id FROM hotels h LEFT JOIN destination_locations dl ON dl.id=h.location_id WHERE h.status='active' AND LOWER(TRIM(h.hotel_name))=LOWER(TRIM(?))";
                    $params=[$hotel];
                    if($destinationId>0){$sql.=" AND h.destination_id=?";$params[]=$destinationId;}
                    if($star>0){$sql.=" AND h.star_category=?";$params[]=$star;}
                    if($locationId>0){$sql.=" AND (h.location_id=? OR LOWER(TRIM(COALESCE(dl.location_name,h.city,'')))=LOWER(TRIM(?)))";$params[]=$locationId;$params[]=$c;}
                    elseif($c!==''){$sql.=" AND LOWER(TRIM(COALESCE(dl.location_name,h.city,'')))=LOWER(TRIM(?))";$params[]=$c;}
                    $sql.=" ORDER BY h.is_preferred DESC,h.priority_order,h.id LIMIT 1";
                    $st=$pdo->prepare($sql);$st->execute($params);$hotelId=(int)($st->fetchColumn()?:0);
                    if($hotelId>0)$mapping='matched';
                }catch(Throwable $ignored){}
            }
            $base=[
                $versionId,(int)$ver['contract_id'],(int)$ver['supplier_id'],$destinationId?:null,
            ];
            if($hasLocation && $hasHotelId){
                $ins->execute(array_merge($base,[$locationId?:null,$c,$cg,$star?:null,$hotel,$norm,$hotelId?:null,trim((string)($room[$k]??''))?:null,trim((string)($meal[$k]??''))?:null,$ver['valid_from'],$ver['valid_to'],$mapping,$order,$adminId?:null,$adminId?:null]));
            }elseif($hasHotelId){
                $ins->execute(array_merge($base,[$c,$cg,$star?:null,$hotel,$norm,$hotelId?:null,trim((string)($room[$k]??''))?:null,trim((string)($meal[$k]??''))?:null,$ver['valid_from'],$ver['valid_to'],$mapping,$order,$adminId?:null,$adminId?:null]));
            }else{
                $ins->execute(array_merge($base,[$c,$cg,$star?:null,$hotel,$norm,trim((string)($room[$k]??''))?:null,trim((string)($meal[$k]??''))?:null,$ver['valid_from'],$ver['valid_to'],$order,$adminId?:null,$adminId?:null]));
            }
            $order+=10;
        }
        $pdo->commit();
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}

function tsMSVehicles(PDO $pdo,int $versionId):array{if(!tsMSTable($pdo,'supplier_contract_vehicle_rules'))return [];$s=$pdo->prepare('SELECT * FROM supplier_contract_vehicle_rules WHERE contract_version_id=? ORDER BY source_order,id');$s->execute([$versionId]);return $s->fetchAll(PDO::FETCH_ASSOC)?:[];}
function tsMSSaveVehicles(PDO $pdo,int $versionId,array $in,int $adminId):void{
    if(!tsMSTable($pdo,'supplier_contract_vehicle_rules'))throw new RuntimeException('Supplier vehicle rule table is missing.');$v=$pdo->prepare('SELECT v.*,c.supplier_id,c.id contract_id FROM supplier_contract_versions v JOIN supplier_contracts c ON c.id=v.contract_id WHERE v.id=?');$v->execute([$versionId]);$ver=$v->fetch(PDO::FETCH_ASSOC);if(!$ver)throw new RuntimeException('Season not found.');
    $type=(array)($in['vehicle_type']??[]);$min=(array)($in['vehicle_pax_min']??[]);$max=(array)($in['vehicle_pax_max']??[]);$city=(array)($in['vehicle_city']??[]);$cat=(array)($in['vehicle_category']??[]);$ac=(array)($in['vehicle_ac']??[]);$scope=(array)($in['vehicle_scope']??[]);$dest=(array)($in['vehicle_destination_id']??[]);
    $pdo->beginTransaction();try{$pdo->prepare('DELETE FROM supplier_contract_vehicle_rules WHERE contract_version_id=?')->execute([$versionId]);$ins=$pdo->prepare("INSERT INTO supplier_contract_vehicle_rules(contract_version_id,contract_id,supplier_document_id,supplier_id,destination_id,city,supplier_category,pax_min,pax_max,vehicle_type,ac_basis,route_scope,valid_from,valid_to,status,source_order,created_by_admin_id,updated_by_admin_id) VALUES(?,?,NULL,?,?,?,?,?,?,?,?,?,?,?,'active',?,?,?)");$order=10;foreach($type as $k=>$t){$t=trim((string)$t);if($t==='')continue;$a=(string)($ac[$k]??'unspecified');if(!in_array($a,['ac','non_ac','unspecified'],true))$a='unspecified';$ins->execute([$versionId,(int)$ver['contract_id'],(int)$ver['supplier_id'],max(0,(int)($dest[$k]??0))?:null,trim((string)($city[$k]??''))?:null,trim((string)($cat[$k]??''))?:'Package',max(0,(int)($min[$k]??0))?:null,max(0,(int)($max[$k]??0))?:null,$t,$a,trim((string)($scope[$k]??''))?:null,$ver['valid_from'],$ver['valid_to'],$order,$adminId?:null,$adminId?:null]);$order+=10;}$pdo->commit();}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function tsMSActivities(PDO $pdo,int $versionId):array{if(!tsMSTable($pdo,'supplier_contract_activities'))return [];$s=$pdo->prepare('SELECT * FROM supplier_contract_activities WHERE contract_version_id=? ORDER BY id');$s->execute([$versionId]);return $s->fetchAll(PDO::FETCH_ASSOC)?:[];}
function tsMSSaveActivities(PDO $pdo,int $versionId,array $in,int $adminId):void{
    if(!tsMSTable($pdo,'supplier_contract_activities'))return;$name=(array)($in['activity_name']??[]);$loc=(array)($in['activity_location']??[]);$min=(array)($in['activity_rate_min']??[]);$max=(array)($in['activity_rate_max']??[]);$basis=(array)($in['activity_basis']??[]);$v=$pdo->prepare('SELECT currency FROM supplier_contract_versions WHERE id=?');$v->execute([$versionId]);$currency=(string)($v->fetchColumn()?:'INR');$pdo->beginTransaction();try{$pdo->prepare('DELETE FROM supplier_contract_activities WHERE contract_version_id=?')->execute([$versionId]);$ins=$pdo->prepare("INSERT INTO supplier_contract_activities(contract_version_id,activity_name,location_text,rate_min,rate_max,rate_basis,currency,status,created_by_admin_id) VALUES(?,?,?,?,?,?,?,'active',?)");foreach($name as $k=>$n){$n=trim((string)$n);if($n==='')continue;$b=(string)($basis[$k]??'per_service');if(!in_array($b,['per_person','per_vehicle','per_room','per_package','per_service'],true))$b='per_service';$mi=trim((string)($min[$k]??''));$ma=trim((string)($max[$k]??''));$ins->execute([$versionId,$n,trim((string)($loc[$k]??''))?:null,$mi===''?null:(float)$mi,$ma===''?null:(float)$ma,$b,$currency,$adminId?:null]);}$pdo->commit();}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function tsMSPolicies(PDO $pdo,int $versionId):array{if(!tsMSTable($pdo,'supplier_contract_policy_items'))return [];$s=$pdo->prepare('SELECT * FROM supplier_contract_policy_items WHERE contract_version_id=? ORDER BY id');$s->execute([$versionId]);$out=[];foreach($s->fetchAll(PDO::FETCH_ASSOC)?:[] as $r){$out[(string)$r['policy_type']][]=$r;}return $out;}
function tsMSSavePolicies(PDO $pdo,int $versionId,array $in,int $adminId):void{
    if(!tsMSTable($pdo,'supplier_contract_policy_items'))return;$map=['child_policy'=>'Child Policy','hotel_policy'=>'Hotel / Availability Policy','id_policy'=>'ID / Document Policy','operational_note'=>'Operational Notes','other'=>'Other Terms'];$pdo->beginTransaction();try{$pdo->prepare("DELETE FROM supplier_contract_policy_items WHERE contract_version_id=? AND policy_type IN ('child_policy','hotel_policy','id_policy','operational_note','other')")->execute([$versionId]);$ins=$pdo->prepare("INSERT INTO supplier_contract_policy_items(contract_version_id,policy_type,title,content,visibility,status,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,'active',?,?)");foreach($map as $key=>$title){$content=trim((string)($in[$key]??''));if($content==='')continue;$vis=(string)($in[$key.'_visibility']??'both');if(!in_array($vis,['internal','customer','both'],true))$vis='both';$ins->execute([$versionId,$key,$title,$content,$vis,$adminId?:null,$adminId?:null]);}$pdo->commit();}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
