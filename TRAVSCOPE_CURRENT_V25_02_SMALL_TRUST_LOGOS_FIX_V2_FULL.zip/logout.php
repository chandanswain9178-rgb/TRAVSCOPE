<?php

require_once __DIR__ . '/config.php';


/*
|--------------------------------------------------------------------------
| CLEAR ALL LOGIN SESSIONS
|--------------------------------------------------------------------------
*/

unset(
    $_SESSION['admin_id'],
    $_SESSION['admin_name'],
    $_SESSION['admin_email'],
    $_SESSION['admin_role'],

    $_SESSION['user_id'],
    $_SESSION['user_name'],
    $_SESSION['user_email'],

    $_SESSION['redirect_after_login']
);


/*
|--------------------------------------------------------------------------
| REGENERATE SESSION
|--------------------------------------------------------------------------
*/

session_regenerate_id(true);


/*
|--------------------------------------------------------------------------
| BACK TO LOGIN
|--------------------------------------------------------------------------
*/

redirect(
    BASE_URL . 'login.php'
);