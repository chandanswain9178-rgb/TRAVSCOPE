<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/operations-functions.php';

$voucherId =
    max(
        0,
        (int)(
            $_GET['voucher']
            ?? 0
        )
    );

if ($voucherId <= 0) {
    http_response_code(404);
    exit('Travel voucher not found.');
}

$voucher =
    tsOpsVoucherById(
        $pdo,
        $voucherId
    );

if (!$voucher) {
    http_response_code(404);
    exit('Travel voucher not found.');
}

$isAdmin =
    !empty($_SESSION['admin_id']);

if (!$isAdmin) {
    requireLogin();

    $user =
        currentUser($pdo);

    if (!$user) {
        unset($_SESSION['user_id']);
        redirect(
            BASE_URL . 'login.php'
        );
    }

    if (
        (int)$voucher['user_id']
        !== (int)$user['id']
        || (string)$voucher['status'] !== 'final'
    ) {
        http_response_code(403);
        exit('You do not have permission to view this travel voucher.');
    }
}

$snapshot =
    json_decode(
        (string)$voucher['snapshot_json'],
        true
    );

if (!is_array($snapshot)) {
    http_response_code(500);
    exit('Travel voucher snapshot is invalid.');
}

function tvE(?string $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function tvDate(?string $value): string
{
    if (!$value) {
        return '-';
    }

    $ts = strtotime($value);

    return
        $ts
            ? date('d M Y', $ts)
            : (string)$value;
}

function tvRenderText(?string $value): string
{
    $value =
        trim(
            (string)$value
        );

    if ($value === '') {
        return '';
    }

    return nl2br(
        tvE(
            html_entity_decode(
                strip_tags($value),
                ENT_QUOTES,
                'UTF-8'
            )
        )
    );
}

function tvItinerary(array $snapshot): array
{
    $raw =
        $snapshot['package']['itinerary']
        ?? null;

    if (is_array($raw)) {
        return $raw;
    }

    if (is_string($raw) && trim($raw) !== '') {
        $decoded =
            json_decode(
                $raw,
                true
            );

        if (is_array($decoded)) {
            return $decoded;
        }
    }

    return [];
}

$siteName = 'TRAVSCOPE.COM';
$documentLogo = function_exists('getSetting')
    ? trim((string)getSetting($pdo, 'document_logo', 'assets/travscope-document-logo-wide.png'))
    : 'assets/travscope-document-logo-wide.png';
if ($documentLogo === '') $documentLogo = 'assets/travscope-document-logo-wide.png';
$siteLogo = preg_match('#^https?://#i', $documentLogo)
    ? $documentLogo
    : rtrim((string)BASE_URL, '/') . '/' . ltrim($documentLogo, '/');
$documentHeaderName = 'Memorable Hospitality Pvt. Ltd.';

try {
    if (function_exists('getSetting')) {
        $siteName = getSetting($pdo, 'site_name', 'TRAVSCOPE.COM');
    }
} catch (Throwable $e) {
    // Keep safe fallback.
}

$services =
    is_array($snapshot['services'] ?? null)
        ? $snapshot['services']
        : [];

$itinerary =
    tvItinerary($snapshot);

$hotels =
    is_array($snapshot['hotels'] ?? null)
        ? $snapshot['hotels']
        : [];

$isDraft =
    (string)$voucher['status'] === 'draft';

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= tvE((string)$voucher['voucher_code']); ?> · Travel Voucher</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}
body{margin:0;background:#eef2f7;color:#172033;font-family:Arial,Helvetica,sans-serif}
.toolbar{max-width:920px;margin:14px auto 0;padding:0 12px;display:flex;justify-content:flex-end;gap:8px}
.toolbar button,.toolbar a{border:0;border-radius:9px;padding:10px 13px;background:#0f172a;color:#fff;text-decoration:none;font-weight:800;font-size:11px;cursor:pointer}
.sheet{position:relative;max-width:920px;margin:10px auto 28px;background:#fff;border:1px solid #dbe3ee;border-radius:16px;overflow:hidden;box-shadow:0 15px 40px rgba(15,23,42,.09)}
.draft{position:absolute;inset:0;pointer-events:none;display:flex;align-items:center;justify-content:center;font-size:90px;font-weight:900;color:rgba(185,28,28,.055);transform:rotate(-28deg);z-index:1}
.head{position:relative;z-index:2;padding:24px;background:linear-gradient(135deg,#0f172a,#1e40af);color:#fff}
.head-row{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}
.voucher-brand{display:grid;grid-template-columns:3in minmax(190px,1fr);align-items:center;gap:18px;min-width:0}.voucher-logo{display:block;width:3in;max-width:3in;max-height:1.2in;height:auto;object-fit:contain;object-position:left center;background:#fff;border-radius:10px;padding:3px}.brand{font-size:17px;font-weight:900;line-height:1.25}.muted-light{margin-top:5px;color:#cbd5e1;font-size:11px}
.voucher-code{text-align:right}.voucher-code span{display:block;color:#bfdbfe;font-size:9px;text-transform:uppercase;font-weight:900}.voucher-code strong{display:block;margin-top:4px;font-size:15px}
.body{position:relative;z-index:2;padding:20px}
.summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px}
.summary>div{padding:11px;border:1px solid #e2e8f0;border-radius:11px;background:#f8fafc}
.summary span{display:block;color:#64748b;font-size:8px;font-weight:900;text-transform:uppercase}.summary strong{display:block;margin-top:4px;font-size:11px;color:#0f172a}
.section{margin-top:19px}.section h2{margin:0 0 10px;font-size:14px;color:#0f172a;padding-bottom:7px;border-bottom:2px solid #e2e8f0}
.service{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;padding:10px 11px;border:1px solid #e2e8f0;border-radius:11px;margin-bottom:8px;background:#fbfdff}
.service strong{font-size:11px}.service small{display:block;margin-top:4px;color:#64748b;font-size:9px;line-height:1.5}.ref{white-space:nowrap;font-size:9px;font-weight:900;color:#047857}
.day{padding:10px 11px;border-left:3px solid #2563eb;background:#f8fafc;margin-bottom:8px;border-radius:0 10px 10px 0}.day strong{font-size:11px}.day div{margin-top:5px;font-size:10px;line-height:1.6;color:#475569}
.text{font-size:10px;line-height:1.65;color:#475569}
.footer{margin-top:20px;padding:13px;border-radius:11px;background:#f8fafc;color:#64748b;font-size:9px;line-height:1.55}
@media(max-width:760px){.summary{grid-template-columns:1fr 1fr}.head-row{display:block}.voucher-brand{grid-template-columns:1fr}.voucher-logo{width:min(3in,100%);max-width:100%}.voucher-code{text-align:left;margin-top:12px}.service{grid-template-columns:1fr}.ref{white-space:normal}}
@media print{
    body{background:#fff}
    .toolbar{display:none!important}
    .sheet{margin:0;max-width:none;border:0;border-radius:0;box-shadow:none}
    @page{size:A4;margin:10mm}
}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>
<body>

<div class="toolbar">
    <?php if ($isAdmin): ?>
        <a href="<?= tvE(BASE_URL . 'admin-booking-details.php?id=' . (int)$voucher['booking_id'] . '#operations-readiness'); ?>">
            <i class="fa-solid fa-arrow-left"></i> Booking
        </a>
    <?php else: ?>
        <a href="<?= tvE(BASE_URL . 'booking-details.php?id=' . (int)$voucher['booking_id']); ?>">
            <i class="fa-solid fa-arrow-left"></i> Booking
        </a>
    <?php endif; ?>

    <button type="button" onclick="window.print()">
        <i class="fa-solid fa-print"></i> Print / Save PDF
    </button>
</div>

<main class="sheet">
    <?php if ($isDraft): ?><div class="draft">DRAFT</div><?php endif; ?>

    <header class="head">
        <div class="head-row">
            <div class="voucher-brand">
                <?php if ($siteLogo !== ''): ?>
                    <img class="voucher-logo" src="<?= tvE($siteLogo); ?>" alt="<?= tvE($siteName); ?> logo">
                <?php endif; ?>
                <div>
                    <div class="brand"><?= tvE($documentHeaderName); ?></div>
                    <div class="muted-light">Trade Name: Travscope · Customer Travel Voucher</div>
                </div>
            </div>

            <div class="voucher-code">
                <span>Voucher</span>
                <strong><?= tvE((string)$voucher['voucher_code']); ?></strong>
                <div class="muted-light">
                    Version <?= (int)$voucher['version_number']; ?>
                    · <?= tvE(strtoupper((string)$voucher['status'])); ?>
                </div>
            </div>
        </div>
    </header>

    <div class="body">
        <div class="summary">
            <div>
                <span>Booking</span>
                <strong><?= tvE((string)($snapshot['booking_number'] ?? '')); ?></strong>
            </div>

            <div>
                <span>Trip</span>
                <strong><?= tvE((string)($snapshot['trip_code'] ?? '-')); ?></strong>
            </div>

            <div>
                <span>Customer</span>
                <strong><?= tvE((string)($snapshot['customer']['name'] ?? '')); ?></strong>
            </div>

            <div>
                <span>Travel Date</span>
                <strong><?= tvE(tvDate($snapshot['travel']['travel_date'] ?? null)); ?></strong>
            </div>

            <div>
                <span>Destination</span>
                <strong><?= tvE((string)($snapshot['travel']['destination'] ?? '-')); ?></strong>
            </div>

            <div>
                <span>Travellers</span>
                <strong>
                    <?= (int)($snapshot['travel']['adults'] ?? 0); ?> Adult(s)
                    + <?= (int)($snapshot['travel']['children'] ?? 0); ?> Child(ren)
                </strong>
            </div>

            <div>
                <span>Duration</span>
                <strong>
                    <?= (int)($snapshot['travel']['duration_nights'] ?? 0); ?>N /
                    <?= (int)($snapshot['travel']['duration_days'] ?? 0); ?>D
                </strong>
            </div>

            <div>
                <span>Package</span>
                <strong><?= tvE((string)($snapshot['package']['title'] ?? 'Travel Booking')); ?></strong>
            </div>
        </div>

        <?php if ($hotels): ?>
            <section class="section">
                <h2>Accommodation</h2>
                <?php foreach ($hotels as $hotel): if (!is_array($hotel)) continue;
                    $actual=trim((string)($hotel['hotel_name']??''));
                    $alts=is_array($hotel['alternatives']??null)?$hotel['alternatives']:[];
                    $hotelText=$actual!==''?$actual:($alts?implode(' / ',array_slice($alts,0,4)).' or similar':(($hotel['accommodation_type']??'')==='houseboat'?'Houseboat as per selected category':'To be confirmed'));
                ?>
                    <div class="service">
                        <div>
                            <strong><?= tvE((string)($hotel['destination_name']??'Accommodation')); ?> · <?= max(1,(int)($hotel['nights']??1)); ?> Night<?= max(1,(int)($hotel['nights']??1))===1?'':'s'; ?></strong>
                            <small><?= tvE($hotelText); ?><?php if(!empty($hotel['hotel_category'])): ?> · <?= (int)$hotel['hotel_category']; ?> Star<?php endif; ?></small>
                            <?php if(!empty($hotel['room_type']) || !empty($hotel['meal_plan'])): ?><small><?= tvE(trim((string)($hotel['room_type']??''))); ?><?= (!empty($hotel['room_type'])&&!empty($hotel['meal_plan']))?' · ':''; ?><?= tvE(trim((string)($hotel['meal_plan']??''))); ?></small><?php endif; ?>
                            <?php if(!empty($hotel['check_in_date'])): ?><small><?= tvE(tvDate((string)$hotel['check_in_date'])); ?><?php if(!empty($hotel['check_out_date'])): ?> – <?= tvE(tvDate((string)$hotel['check_out_date'])); ?><?php endif; ?></small><?php endif; ?>
                        </div>
                        <?php if(!empty($hotel['confirmation_reference'])): ?><div class="ref">Ref: <?= tvE((string)$hotel['confirmation_reference']); ?></div><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </section>
        <?php endif; ?>

        <?php if ($transport): ?>
            <section class="section">
                <h2>Transport</h2>
                <?php foreach ($transport as $tr): if(!is_array($tr)) continue;
                    $vehicle=trim((string)($tr['vehicle_type']??''));
                    $alts=is_array($tr['alternatives']??null)?$tr['alternatives']:[];
                    $vehicleText=$vehicle!==''?$vehicle:($alts?implode(' / ',array_slice($alts,0,4)).' or similar':'Vehicle as per confirmed supplier arrangement');
                ?>
                    <div class="service"><div>
                        <strong><?= tvE((string)($tr['route_label']??'Transport as per itinerary')); ?></strong>
                        <small><?= tvE($vehicleText); ?><?php if(!empty($tr['ac_basis'])&&$tr['ac_basis']!=='unspecified'): ?> · <?= tvE(strtoupper(str_replace('_',' ',(string)$tr['ac_basis']))); ?><?php endif; ?></small>
                        <?php if(!empty($tr['pickup_point'])||!empty($tr['pickup_time'])): ?><small>Pickup: <?= tvE(trim((string)($tr['pickup_point']??''))); ?><?= !empty($tr['pickup_time'])?' · '.tvE((string)$tr['pickup_time']):''; ?></small><?php endif; ?>
                        <?php if(!empty($tr['drop_point'])): ?><small>Drop: <?= tvE((string)$tr['drop_point']); ?></small><?php endif; ?>
                        <?php if(!empty($tr['driver_name'])||!empty($tr['driver_mobile'])): ?><small>Driver: <?= tvE((string)($tr['driver_name']??'')); ?><?= !empty($tr['driver_mobile'])?' · '.tvE((string)$tr['driver_mobile']):''; ?></small><?php endif; ?>
                        <?php if(!empty($tr['vehicle_number'])): ?><small>Vehicle No: <?= tvE((string)$tr['vehicle_number']); ?></small><?php endif; ?>
                    </div><?php if(!empty($tr['confirmation_reference'])): ?><div class="ref">Ref: <?= tvE((string)$tr['confirmation_reference']); ?></div><?php endif; ?></div>
                <?php endforeach; ?>
            </section>
        <?php endif; ?>

        <?php if ($services): ?>
            <section class="section">
                <h2>Confirmed Travel Services</h2>

                <?php foreach ($services as $service): ?>
                    <div class="service">
                        <div>
                            <strong><?= tvE((string)($service['title'] ?? 'Service')); ?></strong>
                            <small>
                                <?= tvE(ucwords(str_replace('_', ' ', (string)($service['service_type'] ?? 'service')))); ?>

                                <?php if (!empty($service['destination_name'])): ?>
                                    · <?= tvE((string)$service['destination_name']); ?>
                                <?php endif; ?>

                                <?php if (!empty($service['service_date_from'])): ?>
                                    · <?= tvE(tvDate((string)$service['service_date_from'])); ?>

                                    <?php if (!empty($service['service_date_to']) && $service['service_date_to'] !== $service['service_date_from']): ?>
                                        – <?= tvE(tvDate((string)$service['service_date_to'])); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </small>

                            <?php if (!empty($service['specifications'])): ?>
                                <small><?= nl2br(tvE((string)$service['specifications'])); ?></small>
                            <?php endif; ?>
                        </div>

                        <?php if (!empty($service['confirmation_reference'])): ?>
                            <div class="ref">
                                Ref: <?= tvE((string)$service['confirmation_reference']); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </section>
        <?php endif; ?>

        <?php if ($itinerary): ?>
            <section class="section">
                <h2>Day-wise Itinerary</h2>

                <?php foreach ($itinerary as $index => $day): ?>
                    <?php if (!is_array($day)) continue; ?>

                    <div class="day">
                        <strong>
                            Day <?= (int)($day['day_number'] ?? ($index + 1)); ?>
                            <?php if (!empty($day['title'])): ?>
                                — <?= tvE((string)$day['title']); ?>
                            <?php endif; ?>
                        </strong>

                        <?php if (!empty($day['description'])): ?>
                            <div><?= nl2br(tvE((string)$day['description'])); ?></div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </section>
        <?php endif; ?>

        <?php foreach (
            [
                'inclusions' => 'Inclusions',
                'exclusions' => 'Exclusions',
                'terms' => 'Important Terms',
                'customer_notes' => 'Travel Notes'
            ]
            as $key => $label
        ): ?>
            <?php
            $content =
                trim(
                    (string)(
                        $snapshot['package'][$key]
                        ?? ''
                    )
                );
            ?>

            <?php if ($content !== ''): ?>
                <section class="section">
                    <h2><?= tvE($label); ?></h2>
                    <div class="text"><?= tvRenderText($content); ?></div>
                </section>
            <?php endif; ?>
        <?php endforeach; ?>

<?php require_once __DIR__ . '/credential-display.php'; echo tsCredentialsHtml($pdo, 'document'); ?>
        <div class="footer">
            Please keep this voucher available during travel. Service confirmation references shown above are customer-facing operational references only. Internal supplier rates, commercial margin and supplier sourcing information are not part of this voucher.
        </div>
    </div>
</main>


<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
