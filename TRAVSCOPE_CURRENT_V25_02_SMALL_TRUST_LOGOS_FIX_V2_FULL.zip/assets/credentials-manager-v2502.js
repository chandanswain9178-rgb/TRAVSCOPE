/* TRAVSCOPE V25.02 — expandable credential manager; no third-party libraries. */
(function () {
  'use strict';
  var host = document.getElementById('credentialManager');
  if (!host) return;
  var cards = Array.prototype.slice.call(host.querySelectorAll('[data-credential-card]'));
  var addButton = document.getElementById('addCredentialLogo');
  var count = document.getElementById('credentialCount');
  var message = document.getElementById('credentialLimitMessage');
  function active(card) { return !card.hidden; }
  function refresh() {
    var shown = cards.filter(active).length;
    if (count) count.textContent = shown + ' / ' + cards.length + ' slots';
    if (addButton) addButton.disabled = shown >= cards.length;
    if (message) message.textContent = shown >= cards.length ? 'Maximum of ' + cards.length + ' logos reached.' : 'You can add more logos when needed.';
  }
  function enable(card) {
    card.querySelectorAll('input,select').forEach(function (input) { input.disabled = false; });
  }
  if (addButton) addButton.addEventListener('click', function () {
    var next = cards.find(function (card) { return card.hidden; });
    if (!next) return;
    next.hidden = false; enable(next); refresh();
    var name = next.querySelector('input[name^="quotation_credential_label_"]');
    if (name) name.focus();
    next.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  });
  host.addEventListener('change', function (event) {
    var input = event.target;
    if (!(input instanceof HTMLInputElement) || !input.hasAttribute('data-credential-preview')) return;
    var slot = input.getAttribute('data-credential-preview');
    var image = document.getElementById('credentialLogoPreview' + slot);
    var empty = document.getElementById('credentialLogoEmpty' + slot);
    var file = input.files && input.files[0];
    if (!file || !image) return;
    if (['image/png', 'image/jpeg'].indexOf(file.type) === -1 || file.size > 3 * 1024 * 1024) {
      window.alert('Choose a PNG or JPG logo of 3 MB or less.'); input.value = ''; return;
    }
    var url = URL.createObjectURL(file);
    image.onload = function () { URL.revokeObjectURL(url); };
    image.src = url;
    image.hidden = false;
    if (empty) empty.hidden = true;
  });
  host.addEventListener('click', function (event) {
    var button = event.target.closest('[data-remove-credential]');
    if (!button) return;
    var card = button.closest('[data-credential-card]');
    if (!card) return;
    // Clear only settings. The old uploaded asset stays on disk, and can be restored by re-entering its path.
    card.querySelectorAll('input').forEach(function (input) { input.value = ''; });
    var approval = card.querySelector('select[name^="quotation_credential_verified_"]');
    if (approval) approval.value = '0';
    var image = card.querySelector('.credential-upload-preview img');
    var empty = card.querySelector('.credential-upload-preview span');
    if (image) { image.hidden = true; image.removeAttribute('src'); }
    if (empty) empty.hidden = false;
    // Keep a cleared active card enabled until Save: the server must receive blank values to remove it.
    refresh();
  });
  refresh();
})();
