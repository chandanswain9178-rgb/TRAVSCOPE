/* V25.00 — progressive UI only. No form submission or business-logic interception. */
(function(){
  'use strict';
  if(typeof document==='undefined') return;
  var activeScript=document.currentScript;
  var isAdmin=!!(activeScript && activeScript.getAttribute('data-ts25-area')==='admin');
  var storeKey='travscope:display:v2500:';
  function readSetting(key,defaultValue){try{return localStorage.getItem(storeKey+key)||defaultValue;}catch(_){return defaultValue;}}
  function saveSetting(key,value){try{localStorage.setItem(storeKey+key,value);}catch(_){}}
  function make(tag,cls,text){var n=document.createElement(tag); if(cls)n.className=cls;if(text)n.textContent=text;return n;}
  function mainContent(){return document.querySelector('main:not(.sheet):not(.quotation-print), .odisha-style-main .page, #content, .page-main, .main');}
  function addSkip(target){
    if(!target||document.querySelector('.ts25-skip-link'))return;
    if(!target.id)target.id='ts25-main';
    if(!target.hasAttribute('tabindex'))target.setAttribute('tabindex','-1');
    var link=make('a','ts25-skip-link','Skip to main content');link.href='#'+target.id;
    document.body.insertBefore(link,document.body.firstChild);
  }
  function addTopButton(){
    if(document.querySelector('.ts25-to-top'))return;
    var btn=make('button','ts25-to-top','↑');
    btn.type='button';btn.hidden=true;btn.setAttribute('aria-label','Back to top');btn.title='Back to top';
    btn.addEventListener('click',function(){
      window.scrollTo({top:0,behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
    });
    document.body.appendChild(btn);
    var scheduled=false;
    function check(){scheduled=false;btn.hidden=(window.scrollY||document.documentElement.scrollTop||0)<650;}
    window.addEventListener('scroll',function(){if(scheduled)return;scheduled=true;requestAnimationFrame(check);},{passive:true});
    check();
  }
  function sections(target){
    var candidates=Array.prototype.slice.call(target.querySelectorAll('h1,h2,h3'));
    var seen={};var results=[];
    candidates.forEach(function(h){
      if(results.length>=35||h.closest('.ts25-toolbar,dialog,[role="dialog"],.modal,.sidebar,[hidden]'))return;
      if(h.getClientRects().length===0)return;
      var name=(h.textContent||'').replace(/\s+/g,' ').trim();
      if(!name||name.length<4||name.length>110)return;
      var key=name.toLowerCase();if(seen[key])return;seen[key]=true;
      if(!h.id)h.id='ts25-section-'+results.length;
      results.push({id:h.id,name:name,level:h.tagName});
    });
    return results;
  }
  function addAdminTools(target){
    if(!target||document.querySelector('.ts25-toolbar'))return;
    var toolbar=make('section','ts25-toolbar');
    toolbar.setAttribute('aria-label','Workspace reading and navigation tools');
    var title=make('span','ts25-toolbar-title','✦ Workspace tools');toolbar.appendChild(title);
    var group=make('div','ts25-toolbar-group');
    var label=make('label','ts25-toolbar-label','Jump to');
    var select=make('select');select.setAttribute('aria-label','Jump to a page section');
    var fallback=make('option','', 'Jump to section…');fallback.value='';select.appendChild(fallback);
    sections(target).forEach(function(s){var opt=make('option','',(s.level==='H3'?'· ':'')+s.name);opt.value=s.id;select.appendChild(opt);});
    select.disabled=select.options.length<=1;
    select.addEventListener('change',function(){
      var chosen=document.getElementById(select.value);if(!chosen)return;
      chosen.scrollIntoView({block:'start',behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
      chosen.setAttribute('tabindex','-1');try{chosen.focus({preventScroll:true});}catch(_){chosen.focus();}
      select.value='';
    });
    label.appendChild(select);group.appendChild(label);toolbar.appendChild(group);
    var controls=make('div','ts25-toolbar-group');
    function toggle(labelText,klass,setting,initial){
      var b=make('button','ts25-toolbar-btn',labelText);b.type='button';
      b.setAttribute('aria-pressed',String(initial));
      document.body.classList.toggle(klass,initial);
      b.addEventListener('click',function(){
        var yes=b.getAttribute('aria-pressed')!=='true';
        b.setAttribute('aria-pressed',String(yes));document.body.classList.toggle(klass,yes);
        saveSetting(setting,yes?'on':'off');
      });
      controls.appendChild(b);
    }
    toggle('Comfort text','ts25-readable','readable',readSetting('readable','off')==='on');
    toggle('Compact view','ts25-compact','compact',readSetting('compact','off')==='on');
    toolbar.appendChild(controls);
    target.insertBefore(toolbar,target.firstChild);
    document.addEventListener('keydown',function(ev){
      if(ev.altKey&&ev.shiftKey&&ev.key.toLowerCase()==='j'&&!ev.ctrlKey&&!ev.metaKey){
        if(!select.disabled){ev.preventDefault();select.focus();}
      }
    });
  }
  function syncLongTables(){
    document.querySelectorAll('table').forEach(function(table){
      if(table.closest('.sheet,.quotation-print,.print-sheet,[data-print-document]'))return;
      var region=table.parentElement;
      if(!region||/^(HTML|BODY|FORM)$/.test(region.tagName)||region.clientWidth<80)return;
      var overflow=table.scrollWidth>region.clientWidth+3;
      var hint=region.nextElementSibling;
      var hasHint=!!(hint&&hint.classList.contains('ts25-scroll-hint'));
      if(overflow){
        region.classList.add('ts99-table-scroll','ts25-long-table');
        if(!region.hasAttribute('tabindex'))region.setAttribute('tabindex','0');
        if(!region.hasAttribute('role'))region.setAttribute('role','region');
        if(!region.hasAttribute('aria-label'))region.setAttribute('aria-label','Scrollable data table');
        if(!hasHint){
          var indicator=make('span','ts25-scroll-hint','↔ Scroll this table sideways to see all columns');
          indicator.setAttribute('aria-hidden','true');
          region.insertAdjacentElement('afterend',indicator);
        }
      }else if(region.classList.contains('ts25-long-table')){
        region.classList.remove('ts25-long-table');
        if(hasHint)hint.remove();
      }
    });
    document.querySelectorAll('.ts25-long-table').forEach(function(region){
      if(region.querySelector('table'))return;
      region.classList.remove('ts25-long-table');
      var hint=region.nextElementSibling;
      if(hint&&hint.classList.contains('ts25-scroll-hint'))hint.remove();
    });
  }
  function init(){
    var target=mainContent();
    addSkip(target);
    if(isAdmin)addAdminTools(target);
    addTopButton();
    syncLongTables();
    // Tables loaded after an Ajax action also receive V24.99's overflow handling.
    var timer=null;
    if('MutationObserver' in window){
      var observer=new MutationObserver(function(mutations){
        var relevant=mutations.some(function(m){
          return Array.prototype.some.call(m.addedNodes,function(node){
            return node.nodeType===1&&node.classList&&!node.classList.contains('ts25-scroll-hint')&&
              (node.matches('table,.ts99-table-scroll')||!!node.querySelector('table'));
          });
        });
        if(!relevant||timer!==null)return;
        timer=window.setTimeout(function(){timer=null;syncLongTables();},200);
      });
      observer.observe(document.body,{subtree:true,childList:true});
    }
    window.addEventListener('resize',function(){window.setTimeout(syncLongTables,180);},{passive:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
