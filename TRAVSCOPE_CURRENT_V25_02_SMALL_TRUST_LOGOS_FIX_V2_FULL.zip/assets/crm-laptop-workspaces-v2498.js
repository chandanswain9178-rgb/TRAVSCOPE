/* TRAVSCOPE V24.98 — progressive enhancement only. Existing PHP forms, CSRF,
   allocation status and quotation version save paths are left intact. */
(function () {
  'use strict';
  const doc = document;
  const path = (location.pathname.split('/').pop() || '').toLowerCase();
  const isAllocation = /admin-trip-(hotel|transport)-allocations\.php$/.test(path);
  const isRfq = path === 'admin-supplier-requests.php';
  const isCrm = path === 'admin-crm.php';
  if (!isAllocation && !isRfq && !isCrm) return;
  const body = doc.body;
  if (!body || body.dataset.ts98Enhanced === 'yes') return;
  body.dataset.ts98Enhanced = 'yes';
  body.classList.add('ts98-ui', isAllocation ? 'ts98-alloc' : isRfq ? 'ts98-rfq' : 'ts98-crm');

  const el = (tag, className, text) => {
    const node = doc.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  const btn = (label, callback) => {
    const node = el('button', 'ts98-btn', label);
    node.type = 'button';
    node.addEventListener('click', callback);
    return node;
  };
  const jump = (target) => {
    if (!target) return;
    target.scrollIntoView({behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block:'start'});
  };
  const buildToolbar = (parent, anchor, heading, help) => {
    const bar = el('div', 'ts98-toolbar');
    bar.setAttribute('role', 'region');
    bar.setAttribute('aria-label', heading);
    const title = el('div', 'ts98-toolbar-title');
    title.append(el('strong','',heading), el('small','',help));
    const actions = el('div', 'ts98-toolbar-actions');
    bar.append(title,actions);
    parent.insertBefore(bar,anchor);
    return {bar,actions};
  };
  function initCosting() {
    const section = doc.getElementById('crm-costing');
    if (!section) return;
    const layout = section.querySelector('.ts-cost-layout');
    if (!layout) return;
    const columns = [...layout.querySelectorAll(':scope > .ts-cost-column')];
    if (columns.length < 2) return;
    const head = section.querySelector('.card-head');
    if (!head || !head.parentNode) return;
    const { actions } = buildToolbar(head.parentNode, head.nextSibling,
      'Costing workspace', 'Jump between required services and supplier costing. No customer-facing prices are shown here.');
    actions.append(btn('Services',()=>jump(columns[0])),btn('Cost Sheet',()=>jump(columns[1])));
    const cards = [...columns[0].querySelectorAll('.ts-service-card')];
    cards.forEach((card) => {
      const para = card.querySelector('p');
      if (!para || para.textContent.trim().length < 160) return;
      para.classList.add('ts98-clamped');
      const expand = el('button','ts98-service-expand','Read full requirements');
      expand.type = 'button';
      expand.setAttribute('aria-expanded','false');
      expand.addEventListener('click',()=>{
        const expanded = para.classList.toggle('ts98-clamped') === false;
        expand.textContent = expanded ? 'Show less' : 'Read full requirements';
        expand.setAttribute('aria-expanded',String(expanded));
      });
      para.after(expand);
    });
  }
  function initRfq() {
    const shell = doc.querySelector('.rfq-shell');
    if (!shell) return;
    const hero = shell.querySelector('.rfq-hero');
    const form = shell.querySelector('.rfq-builder');
    const suppliers = shell.querySelector('.rfq-supplier-section');
    const history = shell.querySelector('.rfq-history');
    if (!hero || !form) return;
    const { actions } = buildToolbar(shell, form, 'Supplier RFQ workbench',
      'Quickly move between request details, supplier selection and responses on a laptop.');
    actions.append(btn('Build RFQ',()=>jump(form)));
    if (suppliers) actions.append(btn('Suppliers',()=>jump(suppliers)));
    if (history) actions.append(btn('Responses',()=>jump(history)));
    const focusBtn = btn('Compact overview', () => {
      const active = body.classList.toggle('ts98-compact');
      focusBtn.textContent = active ? 'Show overview' : 'Compact overview';
      focusBtn.setAttribute('aria-pressed',String(active));
    });
    focusBtn.setAttribute('aria-pressed','false');
    actions.append(focusBtn);
  }
  function initAllocation() {
    const wrap = doc.querySelector('.wrap');
    if (!wrap) return;
    const head = wrap.querySelector('.head');
    if (!head) return;
    const cards = [...wrap.children].filter(n => n.matches && n.matches('section.card'));
    const stats = wrap.querySelector('.stats');
    const summary = wrap.querySelector('.context');
    const actionsRow = stats && stats.nextElementSibling;
    const insertAt = cards[0] || actionsRow || stats || head.nextSibling;
    if (!insertAt) return;
    const {bar,actions} = buildToolbar(wrap, insertAt,
      /hotel/.test(path) ? 'Hotel plan · segments' : 'Transport plan · services',
      'Open one segment at a time, confirm the supplier details, then save that segment.');
    const nav = el('div','ts98-nav-strip');
    nav.setAttribute('role','navigation');
    nav.setAttribute('aria-label','Allocation segments');
    bar.after(nav);
    const overviewBtn = btn('Hide trip summary',()=>{
      const hidden=body.classList.toggle('ts98-compact');
      overviewBtn.textContent=hidden?'Show trip summary':'Hide trip summary';
      overviewBtn.setAttribute('aria-pressed',String(hidden));
    });
    overviewBtn.setAttribute('aria-pressed','false');
    actions.append(overviewBtn);
    if (!cards.length) return;

    function openCard(card, scroll) {
      cards.forEach(c => {
        const active = c===card;
        c.classList.toggle('ts98-collapsed',!active);
        c.classList.toggle('ts98-active-allocation',active);
        const toggle=c.querySelector(':scope > .card-head .ts98-fold-btn');
        if(toggle){toggle.textContent=active?'Collapse':'Expand';toggle.setAttribute('aria-expanded',String(active));}
        const marker=nav.querySelector('[data-ts98-card="'+c.id+'"]');
        if(marker){marker.classList.toggle('active',active);marker.setAttribute('aria-current',active?'true':'false');}
      });
      if(scroll) jump(card);
    }
    cards.forEach((card,i) => {
      card.id ||= 'ts98-alloc-'+(i+1);
      card.style.scrollMarginTop='16px';
      const header = card.querySelector(':scope > .card-head');
      const content = card.querySelector(':scope > .body');
      if (!header || !content) return;
      const title=(header.querySelector('h3, strong')?.textContent || 'Segment '+(i+1)).trim().replace(/\s+/g,' ');
      const badge=(header.querySelector('.badge')?.textContent || '').trim().toLowerCase();
      const chip=btn((i+1)+'. '+title,()=>openCard(card,true));
      chip.dataset.ts98Card=card.id;
      chip.title=title;
      if(badge==='confirmed') chip.classList.add('ts98-status-confirmed');
      else if(badge==='proposed'||badge==='requested') chip.classList.add('ts98-status-review');
      nav.append(chip);
      const toggle=el('button','ts98-fold-btn','Expand');
      toggle.type='button';
      toggle.setAttribute('aria-controls',card.id+'-body');
      toggle.setAttribute('aria-expanded','false');
      content.id=card.id+'-body';
      header.append(toggle);
      toggle.addEventListener('click',()=>{
        if(!card.classList.contains('ts98-collapsed')) {
          card.classList.add('ts98-collapsed');
          card.classList.remove('ts98-active-allocation');
          toggle.textContent='Expand';toggle.setAttribute('aria-expanded','false');
          chip.classList.remove('active');chip.setAttribute('aria-current','false');
        } else openCard(card,false);
      });
      // Keep messages explaining missing eligible inventory visible when opening a segment.
      const extra = content.querySelector(':scope > .alternatives');
      if (extra && !/no active hotel exists/i.test(extra.textContent)) {
        const details=el('details','ts98-optional-info');
        const summaryEl=el('summary','', 'Show matching hotel options');
        extra.before(details);
        details.append(summaryEl, extra);
      }
    });
    openCard(cards[0],false);
  }
  if (isAllocation) initAllocation();
  else if (isRfq) initRfq();
  else initCosting();
})();
