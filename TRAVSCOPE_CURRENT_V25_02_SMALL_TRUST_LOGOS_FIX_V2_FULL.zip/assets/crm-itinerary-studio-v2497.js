/* TRAVSCOPE V24.97 — ergonomic, backwards-compatible client-side day editor.
   Server still receives itinerary_title[], itinerary_description[], itinerary_existing_image[], itinerary_image[]. */
(() => {
    'use strict';
    const root = document.getElementById('crmItineraryStudio');
    const list = document.getElementById('crmItineraryRows');
    const form = document.getElementById('customerPackageForm');
    if (!root || !list || !form) return;
    const el = id => document.getElementById(id);
    const duration = el('crmDurationDays');
    const container = root.closest('.package-studio-card');
    const draftKey = `travscope:itinerary:v2497:${root.dataset.lead || 'none'}:${root.dataset.trip || 'none'}`;
    const metadataLabels = { start: 'Start', via: 'Via/Sightseeing', end: 'End', distance: 'Distance', travel: 'Approx travel time' };
    let currentCard = null;
    let draftTimer = null;
    let draftEnabled = true;

    const cards = () => Array.from(list.querySelectorAll('.itinerary-edit-card'));
    const countWords = str => (String(str || '').trim().match(/\S+/g) || []).length;
    const routeFields = card => Array.from(card.querySelectorAll('[data-studio-route-field]'));
    function splitDescription(source) {
        let narrative = String(source || '');
        const route = { start:'', via:'', end:'', distance:'', travel:'', extras:[] };
        narrative = narrative.replace(/\[([^\]\n]{0,900})\]/g, (whole, inside) => {
            let found = false;
            const keep = [];
            for (const fragment of inside.split(/\s*\|\s*/)) {
                const colon = fragment.indexOf(':');
                if (colon < 0) { keep.push(fragment); continue; }
                const key = fragment.slice(0,colon).toLowerCase().replace(/[^a-z]/g,'');
                const value = fragment.slice(colon + 1).trim();
                const field = ({start:'start', via:'via', viasightseeing:'via', end:'end', distance:'distance', approxtraveltime:'travel', approximatetraveltime:'travel', traveltime:'travel'})[key];
                if (field && value) { route[field] = value; found = true; }
                else keep.push(fragment);
            }
            if (!found) return whole;
            if (keep.length) route.extras.push(...keep);
            return '';
        });
        return { narrative:narrative.replace(/[ \t]{2,}/g,' ').replace(/\n\s*\n\s*\n/g,'\n\n').trim(), route };
    }
    function compose(card) {
        const narr = card.querySelector('.itinerary-studio-narrative')?.value.trim() || '';
        const vals = {};
        routeFields(card).forEach(input => { vals[input.dataset.studioRouteField] = input.value.trim(); });
        const parts = Object.entries(metadataLabels).filter(([key]) => vals[key]).map(([key,label]) => label + ': ' + vals[key]);
        const extras = card._studioRouteExtras || [];
        parts.push(...extras);
        return narr + (parts.length ? (narr ? '\n' : '') + '[' + parts.join(' | ') + ']' : '');
    }
    function sync(card) {
        if (!card) return;
        const hidden = card.querySelector('input[type=hidden][name="itinerary_description[]"]');
        if (hidden) hidden.value = compose(card);
    }
    function snapshot(card) {
        const title=card.querySelector('[name="itinerary_title[]"]')?.value || '';
        const description=card.querySelector('.itinerary-studio-narrative')?.value || '';
        const route={};
        routeFields(card).forEach(field=>{route[field.dataset.studioRouteField]=field.value;});
        return JSON.stringify({title,description,route});
    }
    function trackHistory(card) {
        if (!card?._studioHistory) return;
        const history=card._studioHistory;
        const now=snapshot(card);
        if (history.last===now) return;
        history.past.push(history.last);
        if (history.past.length>60) history.past.shift();
        history.last=now;
        history.future=[];
    }
    function applySnapshot(card, value) {
        if (!card || !value) return;
        let parsed;
        try { parsed=JSON.parse(value); } catch(e) {return;}
        const title=card.querySelector('[name="itinerary_title[]"]');
        const text=card.querySelector('.itinerary-studio-narrative');
        if (title) title.value=parsed.title || '';
        if (text) text.value=parsed.description || '';
        routeFields(card).forEach(field=>{field.value=parsed.route?.[field.dataset.studioRouteField] || '';});
        sync(card);
        refresh(); queueDraft();
    }
    function undoRedo(direction) {
        if (!currentCard?._studioHistory) return;
        const history=currentCard._studioHistory;
        const source=direction==='undo' ? history.past : history.future;
        const destination=direction==='undo' ? history.future : history.past;
        if (!source.length) return;
        destination.push(history.last);
        history.last=source.pop();
        applySnapshot(currentCard,history.last);
    }
    function enhance(card) {
        if (card.dataset.studioEnhanced === '1') return;
        const textarea = card.querySelector('textarea[name="itinerary_description[]"]');
        if (!textarea) return;
        const parsed = splitDescription(textarea.value);
        textarea.removeAttribute('name');
        textarea.classList.add('itinerary-studio-narrative');
        textarea.value = parsed.narrative;
        textarea.setAttribute('aria-label', 'Day narrative; 190 to 200 words recommended');
        card._studioRouteExtras = parsed.route.extras;
        const hidden = document.createElement('input');
        hidden.type = 'hidden';
        hidden.name = 'itinerary_description[]';
        textarea.parentNode.appendChild(hidden);
        const details = document.createElement('details');
        details.className = 'crm-studio-route-fields';
        details.innerHTML = '<summary><i class="fa-solid fa-map-location-dot"></i> Route & travel details · separate from narrative</summary><div class="crm-studio-route-grid"></div><p class="crm-studio-route-help">These fields are reassembled into the existing itinerary description on quotation save. They are not counted as narrative words.</p>';
        const grid = details.querySelector('.crm-studio-route-grid');
        Object.entries(metadataLabels).forEach(([key, label]) => {
            const lab = document.createElement('label');
            lab.textContent = label;
            const input = document.createElement('input');
            input.type = 'text';
            input.dataset.studioRouteField = key;
            input.value = parsed.route[key] || '';
            input.placeholder = ({start:'Pickup city / airport',via:'Sightseeing stops',end:'Drop / overnight city',distance:'e.g. 100 km',travel:'e.g. 3 hrs'})[key];
            input.addEventListener('input', () => updateDay(card));
            lab.appendChild(input);
            grid.appendChild(lab);
        });
        const descriptionField = textarea.closest('.field');
        descriptionField.after(details);
        textarea.addEventListener('input', () => updateDay(card));
        card.querySelector('[name="itinerary_title[]"]')?.addEventListener('input', () => updateDay(card));
        card.querySelector('.itinerary-file-input')?.addEventListener('change', () => { updatePreview(); queueDraft(); });
        const imageArea = card.querySelector('.itinerary-preview');
        if (imageArea) new MutationObserver(() => { if (card === currentCard) updatePreview(); }).observe(imageArea,{childList:true,attributes:false});
        card.dataset.studioEnhanced = '1';
        sync(card);
        card._studioHistory = {past:[], future:[], last:snapshot(card)};
    }
    function completeness(card) {
        const words = countWords(card.querySelector('.itinerary-studio-narrative')?.value);
        const title = card.querySelector('[name="itinerary_title[]"]')?.value.trim() || '';
        if (!title && words === 0) return { status:'Empty', css:'', words };
        if (title && words >= 190 && words <= 200) return { status:'Ready', css:'ready', words };
        return { status:'Review · ' + words + ' words', css:'review', words };
    }
    function renderNav() {
        const nav = el('crmStudioDayNav');
        if (!nav) return;
        nav.replaceChildren();
        const all = cards();
        all.forEach((card, index) => {
            const status = completeness(card);
            const title = card.querySelector('[name="itinerary_title[]"]')?.value.trim() || `Day ${index+1} · New itinerary`;
            const button = document.createElement('button');
            button.type='button';
            button.className = 'crm-studio-day-jump' + (card===currentCard?' is-selected':'');
            button.setAttribute('aria-current',card===currentCard?'step':'false');
            const badge = document.createElement('span');
            badge.className = 'crm-studio-day-number';
            badge.textContent = String(index+1).padStart(2,'0');
            const content = document.createElement('span');
            const name = document.createElement('span');
            name.className = 'crm-studio-day-name'; name.textContent = title;
            const state = document.createElement('span');
            state.className = 'crm-studio-day-state ' + status.css; state.textContent = status.status;
            content.append(name,state);
            button.append(badge,content);
            button.addEventListener('click', () => select(card));
            button.draggable=true;
            button.title='Click to edit; drag onto another day to reorder';
            button.addEventListener('dragstart',event=>{event.dataTransfer.setData('text/plain',String(index));event.dataTransfer.effectAllowed='move';});
            button.addEventListener('dragover',event=>{event.preventDefault();event.dataTransfer.dropEffect='move';});
            button.addEventListener('drop',event=>{
                event.preventDefault();
                const from=Number(event.dataTransfer.getData('text/plain'));
                if (!Number.isInteger(from) || from<0 || from>=cards().length) return;
                if(typeof window.crmMoveItineraryCard==='function') window.crmMoveItineraryCard(cards()[from],index);
            });
            nav.appendChild(button);
        });
        if (el('crmStudioDayCount')) el('crmStudioDayCount').textContent = all.length + (all.length===1?' day':' days');
        const ready = all.filter(c => completeness(c).css === 'ready').length;
        if (el('crmStudioDayProgress')) el('crmStudioDayProgress').textContent = all.length ? `${ready} of ${all.length} day narratives meet the 190–200 word target. You can still save drafts while editing.` : 'Add a day or load an itinerary from Package Master.';
    }
    function updatePreview() {
        const card = currentCard;
        const all = cards();
        const index = Math.max(0,all.indexOf(card));
        const title = card?.querySelector('[name="itinerary_title[]"]')?.value.trim() || 'Day title appears here';
        const narrative = card?.querySelector('.itinerary-studio-narrative')?.value.trim() || '';
        const words = countWords(narrative);
        el('crmStudioActiveTitle').textContent = card ? `Day ${index + 1} / ${all.length} · Edit journey` : 'Select a day to begin';
        el('crmStudioLiveDay').textContent = `DAY ${index+1} · YOUR JOURNEY`;
        el('crmStudioLiveTitle').textContent = title;
        el('crmStudioLiveDescription').textContent = narrative || 'The customer-facing narrative will appear here as you type.';
        el('crmStudioWordCounter').textContent = `Narrative: ${words} word${words===1?'':'s'}`;
        const valid = words >= 190 && words <= 200;
        const hint = el('crmStudioWordHint');
        hint.className = valid ? 'is-ready' : (words > 0 ? 'is-review' : '');
        hint.textContent = valid ? '✓ Meets 190–200-word target' : (words > 200 ? `${words-200} words over the 200-word target` : `${Math.max(0,190-words)} more words to reach 190`);
        el('crmStudioEmpty').hidden = !!card;
        for (const id of ['crmStudioPrevious','crmStudioNext','crmStudioDuplicate','crmStudioRemove','crmStudioUndo','crmStudioRedo']) {
            const b=el(id); if (b) b.disabled = !card || (id==='crmStudioPrevious' && index===0) || (id==='crmStudioNext' && index===all.length-1) || (id==='crmStudioUndo' && !card?._studioHistory?.past.length) || (id==='crmStudioRedo' && !card?._studioHistory?.future.length);
        }
        const imageBox = el('crmStudioLiveImage');
        imageBox.replaceChildren();
        const img = card?.querySelector('.itinerary-preview img');
        if (img?.getAttribute('src')) {
            const picture = document.createElement('img');
            picture.src = img.getAttribute('src');
            picture.alt = title;
            picture.loading='lazy';
            imageBox.appendChild(picture);
        } else {
            const icon=document.createElement('i'); icon.className='fa-regular fa-image';
            const text=document.createElement('span'); text.textContent='Choose a photo for this day';
            imageBox.append(icon,text);
        }
        const route = el('crmStudioLiveRoute');
        route.replaceChildren();
        if (card) routeFields(card).forEach(input => {
            if (!input.value.trim()) return;
            const span=document.createElement('span');
            const bold=document.createElement('b'); bold.textContent=metadataLabels[input.dataset.studioRouteField] + ': ';
            span.append(bold,document.createTextNode(input.value.trim()));
            route.appendChild(span);
        });
    }
    function refresh() {
        const all=cards();
        all.forEach(enhance);
        if (!all.includes(currentCard)) currentCard=all[0]||null;
        all.forEach(card => card.classList.toggle('is-active',card===currentCard));
        renderNav(); updatePreview();
    }
    function select(card) { currentCard=card; refresh(); }
    function updateDay(card) { trackHistory(card); sync(card); refresh(); queueDraft(); }
    function allDayData() {
        return cards().map(card => {
            sync(card);
            return {
                title:card.querySelector('[name="itinerary_title[]"]')?.value || '',
                description:card.querySelector('[name="itinerary_description[]"]')?.value || '',
                image:card.querySelector('[name="itinerary_existing_image[]"]')?.value || ''
            };
        });
    }
    function saveDraft() {
        if (!draftEnabled) return;
        try {
            const values=allDayData();
            if (!values.length) return;
            const stamp = new Date().toISOString();
            sessionStorage.setItem(draftKey,JSON.stringify({ saved:stamp,days:values, duration:duration?.value }));
            el('crmStudioDraftStatus').textContent = 'Browser draft saved · ' + new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
            el('crmStudioRestoreDraft').hidden=false;
        } catch (e) { el('crmStudioDraftStatus').textContent='Browser storage unavailable — use Save Customer Quotation'; }
    }
    function queueDraft() {
        if (!draftEnabled) return;
        clearTimeout(draftTimer);
        el('crmStudioDraftStatus').textContent='Unsaved changes · saving browser draft…';
        draftTimer=setTimeout(saveDraft,650);
    }
    function resize(newCount) {
        let target=Math.floor(Number(newCount));
        if (!Number.isFinite(target)) return false;
        target=Math.max(0,Math.min(target,90));
        let all=cards();
        if (target < all.length) {
            const removed=all.slice(target);
            const hasData=removed.some(card => card.querySelector('[name="itinerary_title[]"]')?.value.trim() || card.querySelector('.itinerary-studio-narrative')?.value.trim() || card.querySelector('.itinerary-file-input')?.files.length);
            if (hasData && !confirm(`Reduce to ${target} days? The last ${all.length-target} day(s) will be removed from this unsaved quotation.`)) {
                if (duration) duration.value=all.length;
                return true;
            }
            removed.forEach(card=>card.remove());
        } else while (cards().length < target) {
            if (typeof window.itineraryCard !== 'function') break;
            list.appendChild(window.itineraryCard({},cards().length));
        }
        if (duration) duration.value=cards().length;
        if (typeof window.crmRenumberItineraryCards==='function') window.crmRenumberItineraryCards();
        refresh(); queueDraft();
        return true;
    }
    function addDay() {
        if (cards().length>=90) { alert('A maximum of 90 itinerary days is supported in the studio.'); return; }
        const card=window.itineraryCard({},cards().length);
        list.appendChild(card);
        if (duration) duration.value=cards().length;
        currentCard=card;
        window.crmRenumberItineraryCards?.();
        refresh(); queueDraft();
        card.querySelector('[name="itinerary_title[]"]')?.focus({preventScroll:true});
    }
    function duplicateDay() {
        if (!currentCard || cards().length>=90) return;
        const current = currentCard;
        sync(current);
        const currentTitle=current.querySelector('[name="itinerary_title[]"]')?.value || '';
        const record={title:currentTitle,description:current.querySelector('[name="itinerary_description[]"]')?.value || '',image:current.querySelector('[name="itinerary_existing_image[]"]')?.value || ''};
        const clone=window.itineraryCard(record,cards().length);
        current.after(clone);
        currentCard=clone;
        if (duration) duration.value=cards().length;
        window.crmRenumberItineraryCards?.();
        refresh(); queueDraft();
        if (current.querySelector('.itinerary-file-input')?.files.length) alert('Day duplicated; please choose the locally uploaded PC photo again for the duplicate.');
    }
    function removeDay() {
        if (!currentCard || !confirm('Remove this itinerary day from the draft? You can restore the last browser draft if necessary.')) return;
        const all=cards(); const idx=all.indexOf(currentCard);
        currentCard.remove(); currentCard=cards()[Math.min(idx,cards().length-1)]||null;
        if (duration) duration.value=cards().length;
        window.crmRenumberItineraryCards?.(); refresh(); queueDraft();
    }
    function restoreDraft() {
        let draft;
        try { draft=JSON.parse(sessionStorage.getItem(draftKey)||'null'); } catch (e) { return; }
        if (!draft || !Array.isArray(draft.days)) return;
        if (!confirm('Restore the last browser draft? This replaces the unsaved itinerary days currently shown; it does not change any saved quotation version.')) return;
        draftEnabled=false;
        try {
            if (typeof window.renderItinerary==='function') window.renderItinerary(draft.days,draft.days.length);
            if (duration) duration.value=draft.days.length;
            currentCard=cards()[0]||null;
        } finally { draftEnabled=true; }
        refresh();
        el('crmStudioDraftStatus').textContent='Browser draft restored; save a quotation to keep it permanently';
    }
    // Navigation and ergonomic controls
    el('crmStudioPrevious')?.addEventListener('click', () => { const a=cards(); const i=a.indexOf(currentCard); if (i>0) select(a[i-1]); });
    el('crmStudioNext')?.addEventListener('click', () => { const a=cards(); const i=a.indexOf(currentCard); if (i<a.length-1) select(a[i+1]); });
    el('crmStudioAddDay')?.addEventListener('click',addDay);
    el('crmStudioUndo')?.addEventListener('click',()=>undoRedo('undo'));
    el('crmStudioRedo')?.addEventListener('click',()=>undoRedo('redo'));
    el('crmStudioDuplicate')?.addEventListener('click',duplicateDay);
    el('crmStudioRemove')?.addEventListener('click',removeDay);
    el('crmStudioRestoreDraft')?.addEventListener('click',restoreDraft);
    el('crmStudioFocus')?.addEventListener('click', () => {
        const active=container?.classList.toggle('crm-itinerary-focus');
        const button=el('crmStudioFocus');
        button.innerHTML=active?'<i class="fa-solid fa-compress"></i> Exit focus':'<i class="fa-solid fa-expand"></i> Focus mode';
        if(active) root.closest('details').open=true;
    });
    form.addEventListener('submit', () => { clearTimeout(draftTimer); cards().forEach(sync); });
    window.addEventListener('pagehide', () => { if(draftTimer) { clearTimeout(draftTimer); saveDraft(); } });
    document.addEventListener('keydown', event => {
        if (event.key==='Escape' && container?.classList.contains('crm-itinerary-focus')) el('crmStudioFocus')?.click();
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase()==='s' && root.contains(document.activeElement)) {
            event.preventDefault(); clearTimeout(draftTimer); saveDraft();
        }
    });
    try {
        if (sessionStorage.getItem(draftKey)) {
            el('crmStudioRestoreDraft').hidden=false;
            el('crmStudioDraftStatus').textContent='Previous browser draft available';
        }
    } catch(e) { /* Private mode may block sessionStorage. */ }
    window.crmItineraryStudioV2497 = {refresh,resize,changed:queueDraft};
    refresh();
})();
