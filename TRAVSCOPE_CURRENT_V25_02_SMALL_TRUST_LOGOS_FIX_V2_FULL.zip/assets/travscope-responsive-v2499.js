/* V24.99: Detect genuinely overflowing data tables and add accessible horizontal scroll.
   No DOM reparenting, no business-logic changes, no new event listeners on forms. */
(function(){
  'use strict';
  if (typeof document === 'undefined') return;
  function scanTables(){
    document.querySelectorAll('table').forEach(function(table){
      if (table.closest('.sheet,.quotation-print,.print-sheet,[data-print-document]')) return;
      var parent = table.parentElement;
      if (!parent || !parent.getBoundingClientRect || /^(HTML|BODY|FORM)$/.test(parent.tagName)) return;
      var parentWidth = parent.clientWidth;
      var tableWidth = table.scrollWidth;
      if (parentWidth < 80) return;
      if (tableWidth > parentWidth + 3) {
        parent.classList.add('ts99-table-scroll');
        if (!parent.hasAttribute('tabindex')) parent.setAttribute('tabindex','0');
        if (!parent.hasAttribute('role')) parent.setAttribute('role','region');
        if (!parent.hasAttribute('aria-label')) parent.setAttribute('aria-label','Scrollable data table');
      } else {
        parent.classList.remove('ts99-table-scroll');
      }
    });
  }
  function init(){
    scanTables();
    var scheduled=false;
    window.addEventListener('resize',function(){
      if (scheduled) return;
      scheduled=true;
      window.requestAnimationFrame(function(){scheduled=false;scanTables();});
    },{passive:true});
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',init,{once:true});
  else init();
})();
