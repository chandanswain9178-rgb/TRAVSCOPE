TRAVSCOPE V24.89 — INTELLECTUAL CLIENT CONTENT STANDARD
Release date: 07 October 2026
Base: V24.88 — Hard 200 Word Itinerary Guard

CONTENT STANDARD
1. Package Short Description: 90–100 words.
2. Full Package Description: 190–200 words.
3. Each day-wise itinerary narrative: 190–200 words.
4. Day title, image/photo credit and route metadata are outside the narrative word count.
5. Route metadata includes Start, Via/Sightseeing, End, Distance, Approx. Travel Time, Overnight and Meals.

BEHAVIOUR
- Content above the maximum is safely capped.
- Shorter supplier day narratives are professionally expanded using only confirmed supplier text, route, travel, overnight and meal facts.
- No unverified attraction, service or commercial promise is intentionally added.
- Package Master fallback Short/Full descriptions are generated to the requested word ranges.
- Explicit workbook Short/Full descriptions below the preferred minimum are expanded at Package Master build/sync using confirmed package context.
- Accidental following-day spillover (for example Day 04 text inside Day 3) continues to be removed.
- Public itinerary rendering separates route/travel metadata from the 190–200 word narrative.
- Existing text is still hard-capped at public display to prevent oversized content.

ADMIN IMPORT UI
- Shows the V24.89 word-range standard.
- Shows the final day narrative word count in preview.
- Shows warnings when copy was expanded or capped.

CHANGED FILES
- supplier-package-import-functions.php
- package-supplier-functions.php
- admin-supplier-package-import.php
- package-details.php
- README_V24_89_INTELLECTUAL_CONTENT_STANDARD.txt

DATABASE
No SQL required.
