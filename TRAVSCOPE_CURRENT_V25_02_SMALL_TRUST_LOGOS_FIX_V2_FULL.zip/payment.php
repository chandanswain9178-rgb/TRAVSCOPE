<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| PAYMENT PAGE
| HOTEL CATEGORY + PER-PERSON PRICE VERSION: 2026-08-04-R1
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';

$billingFunctionsFile = __DIR__ . '/billing-functions.php';
if (is_file($billingFunctionsFile)) {
    require_once $billingFunctionsFile;
}


/*
|--------------------------------------------------------------------------
| SIGNED CUSTOMER PAYMENT-LINK ACCESS
|--------------------------------------------------------------------------
| A valid signed link can open this payment target without forcing the
| customer to log in. Normal dashboard visits still require user login.
|--------------------------------------------------------------------------
*/
$paymentAccessBookingId = (int)($_POST['booking_id'] ?? $_GET['booking'] ?? 0);
$paymentAccessInstallmentId = max(0, (int)($_POST['installment_id'] ?? $_GET['installment'] ?? 0));
$paymentAccessExpires = (int)($_POST['payment_link_expires'] ?? $_GET['expires'] ?? 0);
$paymentAccessToken = trim((string)($_POST['payment_link_token'] ?? $_GET['token'] ?? ''));
$paymentLinkAccess = function_exists('tsBillPaymentCollectionTokenValid')
    && tsBillPaymentCollectionTokenValid(
        $paymentAccessBookingId,
        $paymentAccessInstallmentId,
        $paymentAccessExpires,
        $paymentAccessToken
    );


/*
|--------------------------------------------------------------------------
| ACCESS: LOGGED-IN CUSTOMER OR SIGNED PAYMENT LINK
|--------------------------------------------------------------------------
*/
$user = null;
$userId = 0;

if (!$paymentLinkAccess) {
    if (!isLoggedIn()) {
        setFlash('error', 'Please login to continue, or use the secure payment link sent by TRAVSCOPE.');
        redirect(BASE_URL . 'login.php');
    }

    $user = currentUser($pdo);
    if (!$user || strtolower((string)$user['status']) !== 'active') {
        unset($_SESSION['user_id']);
        setFlash('error', 'Please login again.');
        redirect(BASE_URL . 'login.php');
    }
    $userId = (int)$user['id'];
}


/*
|--------------------------------------------------------------------------
| SETTINGS
|--------------------------------------------------------------------------
*/

$siteName = getSetting(
    $pdo,
    'site_name',
    'TRAVSCOPE.COM'
);

$currencySymbol = getSetting(
    $pdo,
    'currency_symbol',
    '₹'
);

/*
|--------------------------------------------------------------------------
| PAYMENT SETTINGS
|--------------------------------------------------------------------------
|
| Add these later in your settings table:
|
| payment_upi_id
| payment_upi_name
| payment_qr
|
*/

$upiId = trim(
    (string)getSetting(
        $pdo,
        'payment_upi_id',
        ''
    )
);

$upiName = trim(
    (string)getSetting(
        $pdo,
        'payment_upi_name',
        'TRAVSCOPE.COM'
    )
);

$paymentQr = trim(
    (string)getSetting(
        $pdo,
        'payment_qr',
        ''
    )
);


/*
|--------------------------------------------------------------------------
| IMAGE HELPER
|--------------------------------------------------------------------------
*/

function paymentImage(?string $image): string
{
    $image = trim((string)$image);

    if ($image === '') {
        return 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1200&q=85';
    }

    if (preg_match('#^https?://#i', $image)) {
        return $image;
    }

    return BASE_URL . ltrim($image, '/');
}



function paymentHotelCategoryLabel(?string $category): string
{
    $category = strtolower(trim((string)$category));

    return match ($category) {
        '3_star', '3' => '3 Star Hotel',
        '4_star', '4' => '4 Star Hotel',
        '5_star', '5' => '5 Star Hotel',
        default => 'Not specified'
    };
}

function paymentMoney(
    float $amount,
    string $symbol
): string {
    return $symbol
        . number_format(
            max(0, $amount),
            2
        );
}


/*
|--------------------------------------------------------------------------
| QR IMAGE
|--------------------------------------------------------------------------
*/

$paymentQrUrl = '';

if ($paymentQr !== '') {

    if (preg_match('#^https?://#i', $paymentQr)) {
        $paymentQrUrl = $paymentQr;
    } else {
        $paymentQrUrl =
            BASE_URL . ltrim($paymentQr, '/');
    }
}


/*
|--------------------------------------------------------------------------
| GET BOOKING
|--------------------------------------------------------------------------
*/

$bookingId = (int)(
    $_POST['booking_id']
    ?? $_GET['booking']
    ?? 0
);

if ($bookingId <= 0) {

    setFlash(
        'error',
        'Invalid booking.'
    );

    redirect(BASE_URL . 'dashboard.php');
}


$installmentId =
    max(
        0,
        (int)(
            $_POST['installment_id']
            ?? $_GET['installment']
            ?? 0
        )
    );

$billingPaymentTarget = null;
$signedPendingUrl = BASE_URL . 'payment-pending.php?booking=' . $bookingId;
if ($paymentLinkAccess) {
    $signedPendingUrl .= '&installment=' . $installmentId
        . '&expires=' . $paymentAccessExpires
        . '&token=' . rawurlencode($paymentAccessToken);
}


/*
|--------------------------------------------------------------------------
| FETCH BOOKING
|--------------------------------------------------------------------------
|
| CRITICAL:
| user_id condition ensures one user cannot pay another user's booking.
|--------------------------------------------------------------------------
*/

$bookingSql = "
    SELECT b.*,p.title AS package_title,p.slug AS package_slug,p.main_image AS package_image,
           p.duration_days,p.duration_nights,p.package_type,
           d.name AS destination_name,d.country AS destination_country
    FROM bookings b
    LEFT JOIN packages p ON p.id=b.package_id
    LEFT JOIN destinations d ON d.id=p.destination_id
    WHERE b.id=?";
$bookingParams = [$bookingId];
if (!$paymentLinkAccess) { $bookingSql .= " AND b.user_id=?"; $bookingParams[] = $userId; }
$bookingSql .= " LIMIT 1";
$stmt = $pdo->prepare($bookingSql);
$stmt->execute($bookingParams);
$booking = $stmt->fetch();

if (!$booking) {

    http_response_code(404);

    exit(
        'Booking not found or you do not have permission to access it.'
    );
}


/*
|--------------------------------------------------------------------------
| BOOKING STATE
|--------------------------------------------------------------------------
*/

$bookingStatus =
    strtolower(
        (string)$booking['booking_status']
    );

$paymentStatus =
    strtolower(
        (string)$booking['payment_status']
    );


/*
|--------------------------------------------------------------------------
| CANCELLED BOOKING
|--------------------------------------------------------------------------
*/

if ($bookingStatus === 'cancelled') {

    setFlash(
        'error',
        'This booking has been cancelled and cannot be paid.'
    );

    redirect(
        BASE_URL . 'dashboard.php'
    );
}


/* Keep customer payable aligned with the latest FINAL GST/TCS invoice. */
if (function_exists('tsBillReady') && tsBillReady($pdo) && function_exists('tsBillSyncBookingPayableFromFinalInvoice')) {
    try {
        $syncedBooking = tsBillSyncBookingPayableFromFinalInvoice($pdo, $bookingId);
        if (is_array($syncedBooking)) {
            $booking['total_amount'] = $syncedBooking['total_amount'] ?? $booking['total_amount'];
            $booking['payment_status'] = $syncedBooking['payment_status'] ?? $booking['payment_status'];
            $paymentStatus = strtolower((string)$booking['payment_status']);
        }
    } catch (Throwable $e) {
        error_log('Payment invoice payable sync: ' . $e->getMessage());
    }
}

/*
|--------------------------------------------------------------------------
| ALREADY PAID
|--------------------------------------------------------------------------
*/

if ($paymentStatus === 'paid') {
    if ($paymentLinkAccess) redirect($signedPendingUrl);
    redirect(BASE_URL . 'booking-success.php?booking=' . $bookingId);
}


/*
|--------------------------------------------------------------------------
| CALCULATE OUTSTANDING BALANCE
|--------------------------------------------------------------------------
*/

$totalAmount =
    (float)$booking['total_amount'];

$paidAmount =
    (float)$booking['paid_amount'];

$amountDue =
    (function_exists('tsBillReady') && tsBillReady($pdo) && function_exists('tsBillCollectibleOutstanding'))
        ? tsBillCollectibleOutstanding($pdo, $booking)
        : max(0, $totalAmount - $paidAmount);

if (
    $installmentId > 0
    && function_exists('tsBillReady')
    && tsBillReady($pdo)
) {
    try {
        $billingPaymentTarget =
            tsBillPaymentTarget(
                $pdo,
                $bookingId,
                $installmentId,
                $amountDue
            );

        $amountDue =
            (float)$billingPaymentTarget['amount'];

    } catch (Throwable $e) {
        setFlash('error', $e->getMessage());
        redirect(
            BASE_URL
            . 'booking-details.php?id='
            . $bookingId
        );
    }
}

$hotelCategoryLabel =
    paymentHotelCategoryLabel(
        $booking['hotel_category']
        ?? ''
    );

$hotelPricePerAdult =
    max(
        0,
        (float)(
            $booking['hotel_price']
            ?? 0
        )
    );

$adultCount =
    max(
        1,
        (int)(
            $booking['adults']
            ?? 1
        )
    );

$adultPackageSubtotal =
    round(
        $hotelPricePerAdult
        * $adultCount,
        2
    );


if ($amountDue <= 0) {

    redirect(
        BASE_URL
        . 'booking-success.php?booking='
        . $bookingId
    );
}


/*
|--------------------------------------------------------------------------
| CHECK EXISTING PENDING PAYMENT
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM payments
    WHERE
        booking_id = ?
        AND status = 'pending'
    ORDER BY id DESC
    LIMIT 1
");

$stmt->execute([$bookingId]);

$pendingPayment =
    $stmt->fetch();


/*
|--------------------------------------------------------------------------
| FORM
|--------------------------------------------------------------------------
*/

$errors = [];

$transactionId = trim(
    (string)(
        $_POST['transaction_id']
        ?? ''
    )
);

$paymentMethod = trim(
    (string)(
        $_POST['payment_method']
        ?? 'UPI'
    )
);


/*
|--------------------------------------------------------------------------
| PAYMENT SUBMISSION
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */

    $csrf =
        $_POST['csrf_token']
        ?? '';

    if (!verifyCsrf($csrf)) {

        $errors[] =
            'Your session expired. Please refresh the page and try again.';
    }


    /*
    |--------------------------------------------------------------------------
    | RE-FETCH BOOKING BEFORE PAYMENT
    |--------------------------------------------------------------------------
    */

    $freshSql = "SELECT id,user_id,booking_status,payment_status,total_amount,paid_amount,currency FROM bookings WHERE id = ?";
    $freshParams = [$bookingId];
    if (!$paymentLinkAccess) { $freshSql .= " AND user_id = ?"; $freshParams[] = $userId; }
    $freshSql .= " LIMIT 1";
    $stmt = $pdo->prepare($freshSql);
    $stmt->execute($freshParams);

    $freshBooking =
        $stmt->fetch();

    if (!$freshBooking) {

        $errors[] =
            'Booking could not be found.';

    } else {

        if (
            strtolower(
                (string)$freshBooking['booking_status']
            ) === 'cancelled'
        ) {

            $errors[] =
                'This booking has been cancelled.';
        }

        if (strtolower((string)$freshBooking['payment_status']) === 'paid') {
            if ($paymentLinkAccess) redirect($signedPendingUrl);
            redirect(BASE_URL . 'booking-success.php?booking=' . $bookingId);
        }

        $amountDue =
            max(
                0,
                (float)$freshBooking['total_amount']
                -
                (float)$freshBooking['paid_amount']
            );

        if (
            $installmentId > 0
            && function_exists('tsBillReady')
            && tsBillReady($pdo)
        ) {
            try {
                $billingPaymentTarget =
                    tsBillPaymentTarget(
                        $pdo,
                        $bookingId,
                        $installmentId,
                        $amountDue
                    );

                $amountDue =
                    (float)$billingPaymentTarget['amount'];

            } catch (Throwable $e) {
                $errors[] = $e->getMessage();
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | PAYMENT METHOD
    |--------------------------------------------------------------------------
    */

    $allowedMethods = [
        'UPI',
        'Bank Transfer'
    ];

    if (
        !in_array(
            $paymentMethod,
            $allowedMethods,
            true
        )
    ) {

        $errors[] =
            'Please select a valid payment method.';
    }


    /*
    |--------------------------------------------------------------------------
    | TRANSACTION ID / UTR
    |--------------------------------------------------------------------------
    */

    $transactionId =
        strtoupper(
            trim($transactionId)
        );

    if ($transactionId === '') {

        $errors[] =
            'Please enter your UPI transaction ID / UTR number.';
    }

    if (
        strlen($transactionId) < 6 ||
        strlen($transactionId) > 150
    ) {

        $errors[] =
            'Please enter a valid transaction ID / UTR.';
    }

    if (
        $transactionId !== ''
        &&
        !preg_match(
            '/^[A-Z0-9._\-\/]+$/',
            $transactionId
        )
    ) {

        $errors[] =
            'Transaction ID contains invalid characters.';
    }


    /*
    |--------------------------------------------------------------------------
    | DUPLICATE TRANSACTION ID
    |--------------------------------------------------------------------------
    */

    if (!$errors) {

        $stmt = $pdo->prepare("
            SELECT id
            FROM payments
            WHERE transaction_id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $transactionId
        ]);

        if ($stmt->fetchColumn()) {

            $errors[] =
                'This transaction ID has already been submitted.';
        }
    }


    /*
    |--------------------------------------------------------------------------
    | ALREADY PENDING
    |--------------------------------------------------------------------------
    */

    if (
        !$errors &&
        $pendingPayment
    ) {

        $errors[] =
            'A payment for this booking is already waiting for verification.';
    }


    /*
    |--------------------------------------------------------------------------
    | CREATE PAYMENT
    |--------------------------------------------------------------------------
    |
    | IMPORTANT:
    | status stays PENDING.
    |
    | Never mark a manual UPI submission SUCCESS just because
    | the customer typed a transaction ID.
    |--------------------------------------------------------------------------
    */

    if (!$errors) {

        try {

            $pdo->beginTransaction();


            /*
            |--------------------------------------------------------------------------
            | LOCK BOOKING
            |--------------------------------------------------------------------------
            */

            $lockSql = "SELECT id,booking_status,payment_status,total_amount,paid_amount,currency FROM bookings WHERE id = ?";
            $lockParams = [$bookingId];
            if (!$paymentLinkAccess) { $lockSql .= " AND user_id = ?"; $lockParams[] = $userId; }
            $lockSql .= " FOR UPDATE";
            $stmt = $pdo->prepare($lockSql);
            $stmt->execute($lockParams);

            $lockedBooking =
                $stmt->fetch();

            if (!$lockedBooking) {

                throw new RuntimeException(
                    'Booking not found.'
                );
            }


            if (
                strtolower(
                    (string)$lockedBooking['booking_status']
                ) === 'cancelled'
            ) {

                throw new RuntimeException(
                    'Cancelled bookings cannot be paid.'
                );
            }


            if (strtolower((string)$lockedBooking['payment_status']) === 'paid') {
                $pdo->rollBack();
                if ($paymentLinkAccess) redirect($signedPendingUrl);
                redirect(BASE_URL . 'booking-success.php?booking=' . $bookingId);
            }


            /*
            |--------------------------------------------------------------------------
            | CALCULATE AMOUNT AGAIN
            |--------------------------------------------------------------------------
            */

            $lockedAmountDue =
                max(
                    0,
                    (float)$lockedBooking['total_amount']
                    -
                    (float)$lockedBooking['paid_amount']
                );

            if (function_exists('tsBillLatestFinalInvoiceAny')) {
                $finalInvoice = tsBillLatestFinalInvoiceAny($pdo, $bookingId);
                if ($finalInvoice) {
                    $invoiceTotal = max(0, (float)($finalInvoice['booking_total'] ?? 0));
                    if ($invoiceTotal > 0) {
                        $lockedAmountDue = max(0, $invoiceTotal - (float)$lockedBooking['paid_amount']);
                    }
                }
            }

            if (
                $installmentId > 0
                && function_exists('tsBillReady')
                && tsBillReady($pdo)
            ) {
                $lockedTarget =
                    tsBillPaymentTarget(
                        $pdo,
                        $bookingId,
                        $installmentId,
                        $lockedAmountDue
                    );

                $lockedAmountDue =
                    (float)$lockedTarget['amount'];
            }

            if ($lockedAmountDue <= 0) {

                throw new RuntimeException(
                    'No outstanding payment exists for this booking.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | RE-CHECK PENDING PAYMENT
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare("
                SELECT id
                FROM payments
                WHERE
                    booking_id = ?
                    AND status = 'pending'
                LIMIT 1
                FOR UPDATE
            ");

            $stmt->execute([
                $bookingId
            ]);

            if ($stmt->fetchColumn()) {

                throw new RuntimeException(
                    'A payment is already waiting for verification.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | RE-CHECK TRANSACTION ID
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare("
                SELECT id
                FROM payments
                WHERE transaction_id = ?
                LIMIT 1
            ");

            $stmt->execute([
                $transactionId
            ]);

            if ($stmt->fetchColumn()) {

                throw new RuntimeException(
                    'This transaction ID has already been submitted.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | STORE PAYMENT
            |--------------------------------------------------------------------------
            */

            $gatewayResponse = json_encode(
                [
                    'source' =>
                        'customer_manual_submission',

                    'submitted_by_user' =>
                        $userId,

                    'submitted_at' =>
                        date('c'),

                    'booking_number' =>
                        $booking['booking_number']
                ],
                JSON_UNESCAPED_SLASHES
            );


            $stmt = $pdo->prepare("
                INSERT INTO payments
                (
                    booking_id,
                    transaction_id,
                    payment_gateway,
                    amount,
                    currency,
                    payment_method,
                    status,
                    gateway_response,
                    paid_at
                )
                VALUES
                (
                    :booking_id,
                    :transaction_id,
                    :payment_gateway,
                    :amount,
                    :currency,
                    :payment_method,
                    'pending',
                    :gateway_response,
                    NULL
                )
            ");

            $stmt->execute([

                ':booking_id' =>
                    $bookingId,

                ':transaction_id' =>
                    $transactionId,

                ':payment_gateway' =>
                    'Manual',

                ':amount' =>
                    $lockedAmountDue,

                ':currency' =>
                    $lockedBooking['currency']
                    ?: 'INR',

                ':payment_method' =>
                    $paymentMethod,

                ':gateway_response' =>
                    $gatewayResponse
            ]);


            $paymentId =
                (int)$pdo->lastInsertId();

            if (
                $installmentId > 0
                && function_exists('tsBillLinkPendingPaymentToInstallment')
            ) {
                tsBillLinkPendingPaymentToInstallment(
                    $pdo,
                    $paymentId,
                    $installmentId,
                    $lockedAmountDue
                );
            }


            /*
            |--------------------------------------------------------------------------
            | DO NOT UPDATE paid_amount
            | DO NOT SET payment_status = paid
            |--------------------------------------------------------------------------
            |
            | Admin must verify the payment first.
            |--------------------------------------------------------------------------
            */


            $pdo->commit();


            $_SESSION['last_payment_id'] =
                $paymentId;


            $pendingUrl = BASE_URL . 'payment-pending.php?booking=' . $bookingId;
            if ($paymentLinkAccess) {
                $pendingUrl .= '&installment=' . $installmentId
                    . '&expires=' . $paymentAccessExpires
                    . '&token=' . rawurlencode($paymentAccessToken);
            }
            redirect($pendingUrl);


        } catch (Throwable $e) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log(
                'Payment submission error: '
                . $e->getMessage()
            );

            $errors[] =
                $e->getMessage();
        }
    }
}


/*
|--------------------------------------------------------------------------
| UPI PAYMENT URI
|--------------------------------------------------------------------------
*/

$upiUri = '';

if ($upiId !== '') {

    $upiParams = http_build_query(
        [
            'pa' => $upiId,
            'pn' => $upiName,
            'am' => number_format(
                $amountDue,
                2,
                '.',
                ''
            ),
            'cu' => 'INR',
            'tn' =>
                'TRAVSCOPE '
                . $booking['booking_number']
        ]
    );

    $upiUri =
        'upi://pay?' . $upiParams;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#07192d"
>

<title>
Payment |
<?= e($booking['booking_number']); ?>
| <?= e($siteName); ?>
</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>

:root{
    --navy:#07192d;
    --navy2:#0d2a48;
    --blue:#0b74ff;
    --blue-dark:#075fd2;
    --green:#078a60;
    --green-bg:#e9faf3;
    --red:#d83d51;
    --orange:#d98a12;
    --orange-bg:#fff7e7;
    --bg:#f5f7fa;
    --white:#fff;
    --text:#172235;
    --muted:#788496;
    --border:#e2e8ef;
    --shadow:0 18px 50px rgba(7,25,45,.09);
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    background:var(--bg);
    color:var(--text);
    font-family:'DM Sans',sans-serif;
}

a{
    color:inherit;
    text-decoration:none;
}

button,
input,
select{
    font:inherit;
}


/* HEADER */

.header{
    height:74px;
    padding:0 5%;
    display:flex;
    align-items:center;
    justify-content:space-between;
    background:white;
    border-bottom:1px solid var(--border);
}

.logo{
    display:flex;
    align-items:center;
    gap:10px;
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:20px;
    font-weight:800;
}

.logo-icon{
    width:40px;
    height:40px;
    border-radius:12px;
    display:grid;
    place-items:center;
    color:white;
    background:linear-gradient(135deg,#0b74ff,#00b8ff);
}

.logo span{
    color:var(--blue);
}

.secure-header{
    display:flex;
    align-items:center;
    gap:7px;
    color:#687587;
    font-size:10px;
    font-weight:700;
}

.secure-header i{
    color:var(--green);
}


/* STEPS */

.progress-wrap{
    background:white;
    border-bottom:1px solid var(--border);
}

.progress{
    min-height:70px;
    display:flex;
    justify-content:center;
    align-items:center;
}

.step{
    display:flex;
    align-items:center;
    gap:7px;
    color:#9ba5b2;
    font-size:9px;
    font-weight:700;
}

.step-circle{
    width:28px;
    height:28px;
    border-radius:50%;
    display:grid;
    place-items:center;
    background:#edf1f5;
}

.step.done{
    color:var(--green);
}

.step.done .step-circle{
    color:white;
    background:var(--green);
}

.step.active{
    color:var(--blue);
}

.step.active .step-circle{
    color:white;
    background:var(--blue);
}

.step-line{
    width:70px;
    height:1px;
    margin:0 10px;
    background:#dce2e8;
}


/* PAGE */

.container{
    max-width:1180px;
    margin:auto;
    padding:35px 20px 70px;
}

.heading{
    margin-bottom:25px;
}

.heading h1{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:30px;
}

.heading p{
    margin-top:5px;
    color:var(--muted);
    font-size:10px;
}

.layout{
    display:grid;
    grid-template-columns:minmax(0,1fr) 360px;
    gap:25px;
}


/* CARDS */

.card{
    margin-bottom:18px;
    padding:24px;
    border:1px solid var(--border);
    border-radius:15px;
    background:white;
    box-shadow:0 8px 30px rgba(7,25,45,.035);
}

.card-heading{
    display:flex;
    align-items:center;
    gap:11px;
    margin-bottom:20px;
}

.card-icon{
    width:39px;
    height:39px;
    flex:0 0 39px;
    border-radius:10px;
    display:grid;
    place-items:center;
    color:var(--blue);
    background:#eaf4ff;
}

.card-heading h2{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:17px;
}

.card-heading p{
    margin-top:2px;
    color:var(--muted);
    font-size:8px;
}


/* ERROR */

.error-box{
    margin-bottom:20px;
    padding:14px;
    border:1px solid #efbec5;
    border-radius:10px;
    background:#fff0f2;
    color:#a92f40;
    font-size:9px;
    line-height:1.7;
}

.error-box ul{
    padding-left:18px;
}


/* AMOUNT */

.amount-box{
    padding:22px;
    border-radius:13px;
    text-align:center;
    background:linear-gradient(135deg,#07192d,#0d3154);
    color:white;
}

.amount-box small{
    display:block;
    color:#9fb1c3;
    font-size:8px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.5px;
}

.amount{
    margin-top:5px;
    font-family:'Manrope',sans-serif;
    font-size:35px;
    font-weight:800;
}

.amount-box p{
    margin-top:5px;
    color:#afbecd;
    font-size:8px;
}


/* METHODS */

.method-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:10px;
}

.method{
    position:relative;
}

.method input{
    position:absolute;
    opacity:0;
}

.method label{
    min-height:80px;
    padding:13px;
    border:1px solid var(--border);
    border-radius:10px;
    display:flex;
    align-items:center;
    gap:11px;
    cursor:pointer;
    transition:.2s;
}

.method-icon{
    width:39px;
    height:39px;
    flex:0 0 39px;
    border-radius:10px;
    display:grid;
    place-items:center;
    background:#f0f5fa;
    color:var(--navy);
    font-size:16px;
}

.method label strong{
    display:block;
    color:var(--navy);
    font-size:10px;
}

.method label small{
    display:block;
    margin-top:3px;
    color:#8a95a3;
    font-size:7px;
}

.method input:checked + label{
    border-color:var(--blue);
    box-shadow:0 0 0 3px rgba(11,116,255,.07);
}

.method input:checked + label .method-icon{
    background:#e8f3ff;
    color:var(--blue);
}


/* PAYMENT INFO */

.payment-details{
    margin-top:18px;
    padding:17px;
    border-radius:11px;
    background:#f7f9fc;
}

.pay-row{
    padding:7px 0;
    display:flex;
    justify-content:space-between;
    gap:20px;
    border-bottom:1px solid #e8edf2;
    font-size:9px;
}

.pay-row:last-child{
    border:0;
}

.pay-row span{
    color:#7d8998;
}

.pay-row strong{
    color:var(--navy);
    text-align:right;
    word-break:break-all;
}


/* QR */

.qr-wrap{
    margin-top:18px;
    text-align:center;
}

.qr{
    width:210px;
    height:210px;
    margin:auto;
    padding:10px;
    border:1px solid var(--border);
    border-radius:14px;
    background:white;
    box-shadow:0 10px 30px rgba(7,25,45,.06);
}

.qr img{
    width:100%;
    height:100%;
    object-fit:contain;
}

.qr-wrap p{
    margin-top:10px;
    color:#7c8898;
    font-size:8px;
}

.upi-button{
    min-height:45px;
    margin-top:13px;
    padding:0 18px;
    border-radius:9px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:7px;
    background:var(--blue);
    color:white;
    font-size:9px;
    font-weight:800;
}


/* NOTICE */

.notice{
    margin-top:17px;
    padding:13px;
    border-radius:9px;
    display:flex;
    align-items:flex-start;
    gap:9px;
    background:var(--orange-bg);
    color:#805c14;
    font-size:8px;
    line-height:1.6;
}

.notice i{
    margin-top:2px;
}


/* FORM */

.form-group{
    margin-top:18px;
}

.form-group label{
    display:block;
    margin-bottom:7px;
    color:#5d6a7b;
    font-size:9px;
    font-weight:800;
}

.required{
    color:var(--red);
}

.form-control{
    width:100%;
    height:49px;
    padding:0 13px;
    border:1px solid var(--border);
    border-radius:9px;
    outline:0;
    color:var(--navy);
    background:white;
    font-size:10px;
    font-weight:600;
    text-transform:uppercase;
}

.form-control:focus{
    border-color:#8ec2ff;
    box-shadow:0 0 0 3px rgba(11,116,255,.07);
}

.help{
    margin-top:6px;
    color:#909aa7;
    font-size:8px;
    line-height:1.5;
}

.submit-btn{
    width:100%;
    min-height:52px;
    margin-top:18px;
    border:0;
    border-radius:10px;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:8px;
    background:linear-gradient(135deg,var(--blue),var(--blue-dark));
    color:white;
    cursor:pointer;
    font-size:10px;
    font-weight:800;
    box-shadow:0 10px 25px rgba(11,116,255,.2);
}

.submit-btn:disabled{
    opacity:.65;
    cursor:not-allowed;
}


/* SUMMARY */

.summary{
    position:sticky;
    top:20px;
    overflow:hidden;
    border:1px solid var(--border);
    border-radius:16px;
    background:white;
    box-shadow:var(--shadow);
}

.package-image{
    height:185px;
}

.package-image img{
    width:100%;
    height:100%;
    object-fit:cover;
}

.summary-body{
    padding:20px;
}

.booking-number{
    color:var(--blue);
    font-size:8px;
    font-weight:800;
}

.summary h2{
    margin-top:5px;
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:17px;
    line-height:1.4;
}

.destination{
    margin-top:7px;
    color:#7b8797;
    font-size:9px;
}

.destination i{
    color:var(--blue);
}

.summary-list{
    margin-top:17px;
}

.summary-row{
    padding:9px 0;
    border-top:1px solid #edf0f3;
    display:flex;
    justify-content:space-between;
    gap:15px;
    font-size:9px;
}

.summary-row span{
    color:#8290a0;
}

.summary-row strong{
    color:var(--navy);
    text-align:right;
}

.summary-total{
    margin-top:10px;
    padding:15px;
    border-radius:9px;
    background:#f5f8fb;
    display:flex;
    align-items:center;
    justify-content:space-between;
}

.summary-total span{
    color:#657386;
    font-size:9px;
    font-weight:700;
}

.summary-total strong{
    color:var(--blue);
    font-family:'Manrope',sans-serif;
    font-size:21px;
}


/* PENDING */

.pending-box{
    padding:22px;
    text-align:center;
}

.pending-icon{
    width:60px;
    height:60px;
    margin:0 auto 13px;
    border-radius:50%;
    display:grid;
    place-items:center;
    background:#fff4d9;
    color:#d0870e;
    font-size:22px;
}

.pending-box h2{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:19px;
}

.pending-box p{
    margin-top:7px;
    color:#7d8998;
    font-size:9px;
    line-height:1.7;
}

.pending-id{
    margin-top:13px;
    padding:10px;
    border-radius:8px;
    background:#f6f8fa;
    color:var(--navy);
    font-size:9px;
    font-weight:700;
}


/* RESPONSIVE */

@media(max-width:900px){

    .layout{
        grid-template-columns:1fr;
    }

    .summary{
        position:static;
    }
}

@media(max-width:600px){

    .header{
        height:65px;
        padding:0 14px;
    }

    .logo{
        font-size:17px;
    }

    .secure-header span{
        display:none;
    }

    .container{
        padding:25px 13px 50px;
    }

    .heading h1{
        font-size:25px;
    }

    .card{
        padding:17px;
    }

    .method-grid{
        grid-template-columns:1fr;
    }

    .step span{
        display:none;
    }

    .step-line{
        width:40px;
    }

    .qr{
        width:190px;
        height:190px;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-public-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="public"></script>
</head>

<body>


<header class="header">

<a
    href="<?= e(BASE_URL); ?>"
    class="logo"
>

    <div class="logo-icon">
        <i class="fa-solid fa-plane"></i>
    </div>

    TRAV<span>SCOPE</span>

</a>


<div class="secure-header">

    <i class="fa-solid fa-shield-halved"></i>

    <span>
        Secure Payment
    </span>

</div>

</header>


<!-- PROGRESS -->

<div class="progress-wrap">

<div class="progress">

    <div class="step done">

        <div class="step-circle">
            <i class="fa-solid fa-check"></i>
        </div>

        <span>
            Traveller Details
        </span>

    </div>


    <div class="step-line"></div>


    <div class="step active">

        <div class="step-circle">
            2
        </div>

        <span>
            Payment
        </span>

    </div>


    <div class="step-line"></div>


    <div class="step">

        <div class="step-circle">
            3
        </div>

        <span>
            Confirmation
        </span>

    </div>

</div>

</div>


<main class="container">


<div class="heading">

    <h1>
        Complete your payment
    </h1>

    <p>
        Pay the exact booking balance below. It already includes the selected hotel category, travel date, adult count and any applied coupon.
    </p>

</div>


<?php if ($errors): ?>

<div class="error-box">

    <strong>
        Please check the following:
    </strong>

    <ul>

        <?php foreach ($errors as $error): ?>

            <li>
                <?= e($error); ?>
            </li>

        <?php endforeach; ?>

    </ul>

</div>

<?php endif; ?>


<div class="layout">


<!-- =========================================================
     LEFT
========================================================= -->

<div>


<?php if (
    $billingPaymentTarget
    && !empty($billingPaymentTarget['installment'])
): ?>

<div style="margin-bottom:14px;padding:11px 12px;border:1px solid #bfdbfe;border-radius:11px;background:#eff6ff;color:#1e40af;font-size:11px;line-height:1.5;">
    <strong>Paying: <?= e((string)$billingPaymentTarget['label']); ?></strong>
    <?php if (!empty($billingPaymentTarget['installment']['due_date'])): ?>
        <br>Due: <?= e(date('d M Y', strtotime((string)$billingPaymentTarget['installment']['due_date']))); ?>
    <?php endif; ?>
</div>

<?php endif; ?>


<?php if ($pendingPayment): ?>


    <section class="card pending-box">

        <div class="pending-icon">

            <i class="fa-regular fa-clock"></i>

        </div>

        <h2>
            Payment submitted
        </h2>

        <p>
            We received your payment reference.
            Your payment is currently waiting for verification.
            Please do not submit another payment for this booking.
        </p>

        <div class="pending-id">

            Transaction ID:
            <?= e(
                $pendingPayment['transaction_id']
                ?: 'Submitted'
            ); ?>

        </div>

        <div class="pending-id">

            Amount:
            <?= e($currencySymbol); ?>
            <?= number_format(
                (float)$pendingPayment['amount'],
                2
            ); ?>

        </div>

        <a
            href="dashboard.php"
            class="upi-button"
        >

            <i class="fa-solid fa-house"></i>

            Go to Dashboard

        </a>

    </section>


<?php else: ?>


<form
    method="post"
    action=""
    id="paymentForm"
>


<input
    type="hidden"
    name="csrf_token"
    value="<?= e(csrfToken()); ?>"
>

<input
    type="hidden"
    name="booking_id"
    value="<?= $bookingId; ?>"
>

<input
    type="hidden"
    name="installment_id"
    value="<?= (int)$installmentId; ?>"
>

<?php if ($paymentLinkAccess): ?>
<input type="hidden" name="payment_link_expires" value="<?= (int)$paymentAccessExpires; ?>">
<input type="hidden" name="payment_link_token" value="<?= e($paymentAccessToken); ?>">
<?php endif; ?>


<section class="card">


    <div class="card-heading">

        <div class="card-icon">
            <i class="fa-solid fa-indian-rupee-sign"></i>
        </div>

        <div>

            <h2>
                Amount to pay
            </h2>

            <p>
                Pay exactly the amount shown below.
            </p>

        </div>

    </div>


    <div class="amount-box">

        <small>
            Total payable now
        </small>

        <div class="amount">

            <?= e($currencySymbol); ?>

            <?= number_format(
                $amountDue,
                2
            ); ?>

        </div>

        <p>
            Booking
            <?= e($booking['booking_number']); ?>
        </p>

    </div>


</section>


<!-- PAYMENT METHOD -->

<section class="card">


    <div class="card-heading">

        <div class="card-icon">
            <i class="fa-regular fa-credit-card"></i>
        </div>

        <div>

            <h2>
                Choose payment method
            </h2>

            <p>
                Select how you made or will make the payment.
            </p>

        </div>

    </div>


    <div class="method-grid">


        <div class="method">

            <input
                type="radio"
                name="payment_method"
                value="UPI"
                id="methodUPI"
                <?= $paymentMethod === 'UPI'
                    ? 'checked'
                    : ''; ?>
            >

            <label for="methodUPI">

                <div class="method-icon">
                    <i class="fa-solid fa-mobile-screen"></i>
                </div>

                <div>

                    <strong>
                        UPI
                    </strong>

                    <small>
                        GPay, PhonePe, Paytm or any UPI app
                    </small>

                </div>

            </label>

        </div>


        <div class="method">

            <input
                type="radio"
                name="payment_method"
                value="Bank Transfer"
                id="methodBank"
                <?= $paymentMethod === 'Bank Transfer'
                    ? 'checked'
                    : ''; ?>
            >

            <label for="methodBank">

                <div class="method-icon">
                    <i class="fa-solid fa-building-columns"></i>
                </div>

                <div>

                    <strong>
                        Bank Transfer
                    </strong>

                    <small>
                        Submit bank UTR after transfer
                    </small>

                </div>

            </label>

        </div>


    </div>


    <?php if ($upiId !== ''): ?>

    <div class="payment-details">

        <div class="pay-row">

            <span>
                Payee
            </span>

            <strong>
                <?= e($upiName); ?>
            </strong>

        </div>

        <div class="pay-row">

            <span>
                UPI ID
            </span>

            <strong>
                <?= e($upiId); ?>
            </strong>

        </div>

        <div class="pay-row">

            <span>
                Amount
            </span>

            <strong>

                <?= e($currencySymbol); ?>

                <?= number_format(
                    $amountDue,
                    2
                ); ?>

            </strong>

        </div>

        <div class="pay-row">

            <span>
                Booking Ref.
            </span>

            <strong>
                <?= e($booking['booking_number']); ?>
            </strong>

        </div>

    </div>

    <?php endif; ?>


    <?php if ($paymentQrUrl !== ''): ?>

    <div class="qr-wrap">

        <div class="qr">

            <img
                src="<?= e($paymentQrUrl); ?>"
                alt="TRAVSCOPE Payment QR"
            >

        </div>

        <p>
            Scan the QR code using your preferred UPI app.
        </p>

    </div>

    <?php endif; ?>


    <?php if ($upiUri !== ''): ?>

    <div class="qr-wrap">

        <a
            href="<?= e($upiUri); ?>"
            class="upi-button"
        >

            <i class="fa-solid fa-mobile-screen-button"></i>

            Pay with UPI App

        </a>

    </div>

    <?php endif; ?>


    <?php if (
        $upiId === '' &&
        $paymentQrUrl === ''
    ): ?>

    <div class="notice">

        <i class="fa-solid fa-triangle-exclamation"></i>

        <div>
            Online payment details have not yet been configured by TRAVSCOPE.
            Please contact support before making a payment.
        </div>

    </div>

    <?php endif; ?>


</section>


<!-- TRANSACTION -->

<section class="card">


    <div class="card-heading">

        <div class="card-icon">
            <i class="fa-solid fa-receipt"></i>
        </div>

        <div>

            <h2>
                Submit payment reference
            </h2>

            <p>
                Enter the transaction reference after completing payment.
            </p>

        </div>

    </div>


    <div class="notice">

        <i class="fa-solid fa-circle-info"></i>

        <div>

            Complete the payment first.
            Then copy the successful transaction ID / UTR from your payment app or bank and enter it below.

        </div>

    </div>


    <div class="form-group">

        <label for="transaction_id">

            TRANSACTION ID / UTR
            <span class="required">*</span>

        </label>

        <input
            type="text"
            name="transaction_id"
            id="transaction_id"
            class="form-control"
            value="<?= e($transactionId); ?>"
            maxlength="150"
            autocomplete="off"
            placeholder="ENTER TRANSACTION ID"
            required
        >

        <div class="help">
            Make sure the transaction ID is correct. Duplicate transaction IDs cannot be submitted.
        </div>

    </div>


<button
    type="submit"
    class="submit-btn"
    id="submitButton"
>
    <i class="fa-solid fa-shield-halved"></i>
    Submit Payment for Verification
</button>


</section>


</form>


<?php endif; ?>


</div>


<!-- =========================================================
     RIGHT BOOKING SUMMARY
========================================================= -->

<aside>


<div class="summary">


    <div class="package-image">

        <img
            src="<?= e(
                paymentImage(
                    $booking['package_image']
                )
            ); ?>"
            alt="<?= e(
                $booking['package_title']
                ?: 'Travel Package'
            ); ?>"
        >

    </div>


    <div class="summary-body">


        <div class="booking-number">

            BOOKING
            <?= e(
                $booking['booking_number']
            ); ?>

        </div>


        <h2>

            <?= e(
                $booking['package_title']
                ?: 'Travel Package'
            ); ?>

        </h2>


        <div class="destination">

            <i class="fa-solid fa-location-dot"></i>

            <?= e(
                $booking['destination_name']
                ?: 'Destination'
            ); ?>

            <?php if (
                !empty(
                    $booking['destination_country']
                )
            ): ?>

                ,
                <?= e(
                    $booking['destination_country']
                ); ?>

            <?php endif; ?>

        </div>


        <div class="summary-list">


            <div class="summary-row">

                <span>
                    Travel Date
                </span>

                <strong>

                    <?= !empty($booking['travel_date'])
                        ? e(
                            date(
                                'd M Y',
                                strtotime(
                                    $booking['travel_date']
                                )
                            )
                        )
                        : '-'; ?>

                </strong>

            </div>


            <div class="summary-row">

                <span>
                    Hotel Category
                </span>

                <strong>
                    <?= e($hotelCategoryLabel); ?>
                </strong>

            </div>


            <div class="summary-row">

                <span>
                    Price Per Adult
                </span>

                <strong>
                    <?= paymentMoney(
                        $hotelPricePerAdult,
                        $currencySymbol
                    ); ?>
                </strong>

            </div>


            <div class="summary-row">

                <span>
                    Adult Package Amount
                </span>

                <strong>
                    <?= paymentMoney(
                        $adultPackageSubtotal,
                        $currencySymbol
                    ); ?>
                </strong>

            </div>


            <div class="summary-row">

                <span>
                    Duration
                </span>

                <strong>

                    <?= (int)$booking['duration_days']; ?>
                    Days /
                    <?= (int)$booking['duration_nights']; ?>
                    Nights

                </strong>

            </div>


            <div class="summary-row">

                <span>
                    Adults
                </span>

                <strong>
                    <?= (int)$booking['adults']; ?>
                </strong>

            </div>


            <?php if (
                (int)$booking['children'] > 0
            ): ?>

            <div class="summary-row">

                <span>
                    Children
                </span>

                <strong>
                    <?= (int)$booking['children']; ?>
                </strong>

            </div>

            <?php endif; ?>


            <div class="summary-row">

                <span>
                    Lead Traveller
                </span>

                <strong>
                    <?= e(
                        $booking['customer_name']
                    ); ?>
                </strong>

            </div>


            <div class="summary-row">

                <span>
                    Booking Status
                </span>

                <strong>
                    <?= e(
                        ucfirst(
                            $bookingStatus
                        )
                    ); ?>
                </strong>

            </div>


            <div class="summary-row">

                <span>
                    Total Amount
                </span>

                <strong>

                    <?= e($currencySymbol); ?>

                    <?= number_format(
                        $totalAmount,
                        2
                    ); ?>

                </strong>

            </div>


            <?php if ($paidAmount > 0): ?>

            <div class="summary-row">

                <span>
                    Already Paid
                </span>

                <strong>

                    <?= e($currencySymbol); ?>

                    <?= number_format(
                        $paidAmount,
                        2
                    ); ?>

                </strong>

            </div>

            <?php endif; ?>


        </div>


        <div
            style="
                margin-top:12px;
                padding:10px 11px;
                border:1px solid #dbe9fa;
                border-radius:8px;
                background:#f3f8ff;
                color:#4d647c;
                font-size:9px;
                line-height:1.55;
            "
        >
            <i
                class="fa-solid fa-circle-info"
                style="color:#0b74ff;margin-right:5px;"
            ></i>

            Price confirmed for
            <strong><?= e($hotelCategoryLabel); ?></strong>
            at
            <strong><?= paymentMoney(
                $hotelPricePerAdult,
                $currencySymbol
            ); ?></strong>
            per adult.
        </div>


        <div class="summary-total">

            <span>
                Payable Now
            </span>

            <strong>

                <?= e($currencySymbol); ?>

                <?= number_format(
                    $amountDue,
                    2
                ); ?>

            </strong>

        </div>


    </div>


</div>


</aside>


</div>


</main>


<script>

const paymentForm =
    document.getElementById(
        'paymentForm'
    );

if (paymentForm) {

    paymentForm.addEventListener(
        'submit',
        function(event) {

            const transaction =
                document.getElementById(
                    'transaction_id'
                );

            const button =
                document.getElementById(
                    'submitButton'
                );

            if (
                !transaction ||
                transaction.value.trim().length < 6
            ) {

                event.preventDefault();

                alert(
                    'Please enter a valid transaction ID / UTR.'
                );

                if (transaction) {
                    transaction.focus();
                }

                return;
            }


            if (button.disabled) {
                event.preventDefault();
                return;
            }


            button.disabled = true;

            button.innerHTML =
                '<i class="fa-solid fa-spinner fa-spin"></i> Submitting Payment...';

        }
    );
}

</script>



<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>