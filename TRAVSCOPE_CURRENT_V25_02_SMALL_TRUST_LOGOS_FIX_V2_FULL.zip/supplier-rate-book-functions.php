<?php
declare(strict_types=1);

if (!function_exists('tsSupplierDocumentExtractFileText') && is_file(__DIR__.'/supplier-document-functions.php')) {
    require_once __DIR__.'/supplier-document-functions.php';
}
if (!function_exists('tsSCRBuildRatesFromDocument') && is_file(__DIR__.'/supplier-contract-rate-functions.php')) {
    require_once __DIR__.'/supplier-contract-rate-functions.php';
}

function tsRBTableExists(PDO $pdo,string $table):bool{
    if(!preg_match('/^[A-Za-z0-9_]+$/',$table))return false;
    try{$pdo->query('SELECT 1 FROM `'.$table.'` LIMIT 0');return true;}catch(Throwable $e){return false;}
}
function tsRBColumnExists(PDO $pdo,string $table,string $column):bool{
    if(!preg_match('/^[A-Za-z0-9_]+$/',$table.$column))return false;
    try{$s=$pdo->query('SHOW COLUMNS FROM `'.$table.'`');foreach($s?:[] as $r){if(strcasecmp((string)$r['Field'],$column)===0)return true;}}catch(Throwable $e){}
    return false;
}
function tsRBReady(PDO $pdo):bool{
    foreach(['supplier_contract_version_documents','supplier_contract_day_itineraries','supplier_contract_activities','supplier_contract_policy_items'] as $t){if(!tsRBTableExists($pdo,$t))return false;}
    return tsRBColumnExists($pdo,'supplier_contract_itineraries','supplier_package_code');
}
function tsRBVersion(PDO $pdo,int $versionId):?array{
    $s=$pdo->prepare("SELECT v.*,c.contract_code,c.contract_name,c.supplier_id,c.status contract_status,s.company_name,s.supplier_code,sd.id primary_document_id,sd.title primary_document_title,sd.original_filename primary_filename FROM supplier_contract_versions v JOIN supplier_contracts c ON c.id=v.contract_id JOIN suppliers s ON s.id=c.supplier_id JOIN supplier_documents sd ON sd.id=v.supplier_document_id WHERE v.id=? LIMIT 1");
    $s->execute([$versionId]);return $s->fetch(PDO::FETCH_ASSOC)?:null;
}
function tsRBLinkedDocuments(PDO $pdo,int $versionId):array{
    $s=$pdo->prepare("SELECT x.*,d.title,d.original_filename,d.document_code,d.document_type,d.valid_from,d.valid_to,d.status document_status FROM supplier_contract_version_documents x JOIN supplier_documents d ON d.id=x.supplier_document_id WHERE x.contract_version_id=? ORDER BY x.is_primary DESC,x.id");
    $s->execute([$versionId]);return $s->fetchAll(PDO::FETCH_ASSOC)?:[];
}
function tsRBAvailableDocuments(PDO $pdo,int $supplierId,int $versionId):array{
    $s=$pdo->prepare("SELECT d.* FROM supplier_documents d WHERE d.supplier_id=? AND d.status<>'archived' AND NOT EXISTS(SELECT 1 FROM supplier_contract_version_documents x WHERE x.contract_version_id=? AND x.supplier_document_id=d.id) ORDER BY d.received_at DESC,d.id DESC");
    $s->execute([$supplierId,$versionId]);return $s->fetchAll(PDO::FETCH_ASSOC)?:[];
}
function tsRBEnsurePrimaryDocumentLink(PDO $pdo,int $versionId,int $adminId):void{
    $v=tsRBVersion($pdo,$versionId);if(!$v||!tsRBReady($pdo))return;
    $s=$pdo->prepare("INSERT IGNORE INTO supplier_contract_version_documents(contract_version_id,supplier_document_id,document_role,is_primary,created_by_admin_id) VALUES(?,?,'rate_sheet',1,?)");
    $s->execute([$versionId,(int)$v['primary_document_id'],$adminId?:null]);
}
function tsRBLinkDocument(PDO $pdo,int $versionId,int $documentId,string $role,int $adminId):void{
    $v=tsRBVersion($pdo,$versionId);if(!$v)throw new RuntimeException('Rate Book not found.');
    $allowed=['rate_sheet','itinerary','hotel_list','terms','activity','other'];if(!in_array($role,$allowed,true))$role='other';
    $s=$pdo->prepare('SELECT id,supplier_id FROM supplier_documents WHERE id=? LIMIT 1');$s->execute([$documentId]);$d=$s->fetch(PDO::FETCH_ASSOC);if(!$d)throw new RuntimeException('Supplier document not found.');
    if((int)$d['supplier_id']!==(int)$v['supplier_id'])throw new RuntimeException('Only documents from the same supplier can be linked to this Rate Book.');
    $s=$pdo->prepare("INSERT INTO supplier_contract_version_documents(contract_version_id,supplier_document_id,document_role,is_primary,created_by_admin_id) VALUES(?,?,?,0,?) ON DUPLICATE KEY UPDATE document_role=VALUES(document_role)");$s->execute([$versionId,$documentId,$role,$adminId?:null]);
}
function tsRBUnlinkDocument(PDO $pdo,int $versionId,int $linkId):void{
    $s=$pdo->prepare('DELETE FROM supplier_contract_version_documents WHERE id=? AND contract_version_id=? AND is_primary=0');$s->execute([$linkId,$versionId]);
}
function tsRBStoredText(array $doc):string{
    if(!function_exists('tsSupplierDocumentStoredPath')||!function_exists('tsSupplierDocumentExtractFileText'))return '';
    $p=tsSupplierDocumentStoredPath((string)$doc['stored_path']);if(!is_file($p))return '';
    $x=tsSupplierDocumentExtractFileText($p);return is_array($x)?(string)($x['text']??''):'';
}
function tsRBPackageCode(string $heading):string{
    if(preg_match('/\b([A-Z]{2,12})\s*[-–—]?\s*(\d{2,5})\b/u',$heading,$m))return strtoupper($m[1]).'-'.$m[2];
    return '';
}
function tsRBIndexPackageCodes(PDO $pdo,int $versionId):int{
    $s=$pdo->prepare('SELECT id,source_heading,title FROM supplier_contract_itineraries WHERE contract_version_id=?');$s->execute([$versionId]);$rows=$s->fetchAll(PDO::FETCH_ASSOC)?:[];$n=0;
    $u=$pdo->prepare('UPDATE supplier_contract_itineraries SET supplier_package_code=? WHERE id=?');
    foreach($rows as $r){$code=tsRBPackageCode((string)$r['source_heading']);if($code==='')$code=tsRBPackageCode((string)$r['title']);if($code!==''){$u->execute([$code,(int)$r['id']]);$n++;}}
    return $n;
}
function tsRBParseDaySections(string $text):array{
    $text=str_replace(["\r\n","\r"],"\n",$text);$packages=[];
    preg_match_all('/(?m)^\s*([A-Z]{2,12})\s*[-–—]?\s*(\d{2,5})\b[^\n]*?(?:Itinerar(?:y|ies))?[^\n]*$/u',$text,$pm,PREG_OFFSET_CAPTURE);
    $heads=$pm[0]??[];
    foreach($heads as $i=>$h){$start=(int)$h[1];$end=isset($heads[$i+1])?(int)$heads[$i+1][1]:strlen($text);$section=substr($text,$start,$end-$start);$code=strtoupper((string)$pm[1][$i][0]).'-'.(string)$pm[2][$i][0];
        preg_match_all('/(?mi)^\s*Day\s*0?(\d{1,2})\s*[:\-–—]?\s*([^\n]*)/u',$section,$dm,PREG_OFFSET_CAPTURE);$days=[];$dh=$dm[0]??[];
        foreach($dh as $j=>$d){$ds=(int)$d[1];$de=isset($dh[$j+1])?(int)$dh[$j+1][1]:strlen($section);$block=trim(substr($section,$ds,$de-$ds));$num=(int)$dm[1][$j][0];$title=trim((string)$dm[2][$j][0]);$body=preg_replace('/^\s*Day\s*0?\d{1,2}\s*[:\-–—]?\s*[^\n]*\n?/iu','',$block,1)??$block;$overnight='';if(preg_match('/Overnight\s+stay\s+(?:at|in)\s+([^\.\n]+)/iu',$body,$om))$overnight=trim($om[1]);$days[]=['day_number'=>$num,'title'=>$title!==''?$title:'Day '.$num,'description'=>trim($body),'overnight_city'=>$overnight,'source_excerpt'=>mb_substr($block,0,1500)];}
        if($days)$packages[$code]=$days;
    }
    return $packages;
}
function tsRBImportDetailedItinerary(PDO $pdo,int $versionId,int $adminId):array{
    tsRBIndexPackageCodes($pdo,$versionId);
    $docs=tsRBLinkedDocuments($pdo,$versionId);$byCode=[];
    foreach($docs as $link){if(!in_array((string)$link['document_role'],['itinerary','rate_sheet'],true))continue;$s=$pdo->prepare('SELECT * FROM supplier_documents WHERE id=?');$s->execute([(int)$link['supplier_document_id']]);$d=$s->fetch(PDO::FETCH_ASSOC);if(!$d)continue;$parsed=tsRBParseDaySections(tsRBStoredText($d));foreach($parsed as $code=>$days){if(!isset($byCode[$code])||count($days)>count($byCode[$code]))$byCode[$code]=$days;}}
    $s=$pdo->prepare('SELECT id,supplier_package_code FROM supplier_contract_itineraries WHERE contract_version_id=?');$s->execute([$versionId]);$its=$s->fetchAll(PDO::FETCH_ASSOC)?:[];$pdo->prepare('DELETE FROM supplier_contract_day_itineraries WHERE contract_version_id=?')->execute([$versionId]);
    $ins=$pdo->prepare('INSERT INTO supplier_contract_day_itineraries(contract_version_id,itinerary_id,supplier_package_code,day_number,day_title,day_description,overnight_city,source_excerpt,status,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,\'review\',?,?)');$count=0;$matched=0;
    foreach($its as $it){$code=trim((string)$it['supplier_package_code']);if($code===''||empty($byCode[$code]))continue;$matched++;foreach($byCode[$code] as $day){$ins->execute([$versionId,(int)$it['id'],$code,(int)$day['day_number'],$day['title'],$day['description'],$day['overnight_city']?:null,$day['source_excerpt'],$adminId?:null,$adminId?:null]);$count++;}}
    return ['packages'=>$matched,'days'=>$count,'detected_packages'=>count($byCode)];
}
function tsRBExtractSection(string $text,string $start,array $ends):string{
    if(!preg_match($start,$text,$m,PREG_OFFSET_CAPTURE))return '';$offset=(int)$m[0][1]+strlen((string)$m[0][0]);$slice=substr($text,$offset);$end=strlen($slice);foreach($ends as $p){if(preg_match($p,$slice,$em,PREG_OFFSET_CAPTURE))$end=min($end,(int)$em[0][1]);}return trim(substr($slice,0,$end));
}
function tsRBImportPoliciesAndActivities(PDO $pdo,int $versionId,int $adminId):array{
    $docs=tsRBLinkedDocuments($pdo,$versionId);$all='';foreach($docs as $l){$s=$pdo->prepare('SELECT * FROM supplier_documents WHERE id=?');$s->execute([(int)$l['supplier_document_id']]);$d=$s->fetch(PDO::FETCH_ASSOC);if($d)$all.="\n".tsRBStoredText($d);} $all=trim($all);
    $pdo->prepare('DELETE FROM supplier_contract_activities WHERE contract_version_id=?')->execute([$versionId]);$pdo->prepare('DELETE FROM supplier_contract_policy_items WHERE contract_version_id=?')->execute([$versionId]);
    $actSection=tsRBExtractSection($all,'/\bACTIVIT(?:Y|IES)\b\s*:?/iu',['/\bPackage\s+Inclusions?\b/iu','/\bPackage\s+Exclusions?\b/iu']);$activityCount=0;
    if($actSection!==''){$ins=$pdo->prepare("INSERT INTO supplier_contract_activities(contract_version_id,activity_name,location_text,rate_min,rate_max,rate_basis,currency,source_text,status,created_by_admin_id) VALUES(?,?,?,?,?,?,'INR',?,'review',?)");foreach(preg_split('/\n/u',$actSection)?:[] as $line){$line=trim(preg_replace('/^\s*\d+[\)\.\-]\s*/u','',$line)??$line);if($line===''||mb_strlen($line)<4)continue;$name=preg_split('/@|Rs\.?|₹/iu',$line)[0]??$line;$basis='per_service';if(preg_match('/per\s+person|\/\-?\s*pp\b/iu',$line))$basis='per_person';elseif(preg_match('/per\s+(?:jeep|jeepsy|vehicle)/iu',$line))$basis='per_vehicle';preg_match_all('/(?:Rs\.?|₹|@)?\s*([0-9][0-9,]*)/iu',$line,$nm);$nums=array_map(fn($v)=>(float)str_replace(',','',$v),$nm[1]??[]);$nums=array_values(array_filter($nums,fn($v)=>$v>=100));$min=$nums?$nums[0]:null;$max=count($nums)>1?$nums[1]:$min;$ins->execute([$versionId,trim($name),null,$min,$max,$basis,mb_substr($line,0,1200),$adminId?:null]);$activityCount++;}}
    $policies=['inclusions'=>['/\bPackage\s+Inclusions?\s*:/iu',['/\bPackage\s+Exclusions?\b/iu','/\bSome\s+Mandatory\s+Notes\b/iu']], 'exclusions'=>['/\bPackage\s+Exclusions?\s*:/iu',['/\bSome\s+Mandatory\s+Notes\b/iu','/\bChild\s+Policy\b/iu']], 'child_policy'=>['/\bChild\s+Policy\s*:/iu',['/\bNotes\s*:/iu','/\bPAYMENTS\b/iu']], 'payment_terms'=>['/\bPAYMENTS\s*:/iu',[]]];
    $insP=$pdo->prepare("INSERT INTO supplier_contract_policy_items(contract_version_id,policy_type,title,content,visibility,status,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,'review',?,?)");$pc=0;
    foreach($policies as $type=>$def){$sec=tsRBExtractSection($all,$def[0],$def[1]);if($sec==='')continue;$vis=$type==='payment_terms'?'internal':'both';$insP->execute([$versionId,$type,ucwords(str_replace('_',' ',$type)),mb_substr($sec,0,12000),$vis,$adminId?:null,$adminId?:null]);$pc++;}
    return ['activities'=>$activityCount,'policies'=>$pc];
}
function tsRBBuildStructuredData(PDO $pdo,int $versionId,int $adminId):array{
    if(!tsRBReady($pdo))throw new RuntimeException('V19 Rate Book SQL is not installed.');tsRBEnsurePrimaryDocumentLink($pdo,$versionId,$adminId);
    $sum=['itineraries'=>0,'rate_groups'=>0,'pax_rows'=>0,'packages'=>0,'days'=>0,'activities'=>0,'policies'=>0];
    if(function_exists('tsSCRSummary')){$before=tsSCRSummary($pdo,$versionId);if((int)$before['active_groups']===0){$r=tsSCRBuildRatesFromDocument($pdo,$versionId,$adminId);$sum['itineraries']=(int)$r['itineraries'];$sum['rate_groups']=(int)$r['rate_groups'];$sum['pax_rows']=(int)$r['pax_rows'];}}
    $d=tsRBImportDetailedItinerary($pdo,$versionId,$adminId);$sum['packages']=$d['packages'];$sum['days']=$d['days'];$p=tsRBImportPoliciesAndActivities($pdo,$versionId,$adminId);$sum['activities']=$p['activities'];$sum['policies']=$p['policies'];return $sum;
}
function tsRBSummary(PDO $pdo,int $versionId):array{
    $out=['documents'=>0,'itineraries'=>0,'rates'=>0,'days'=>0,'hotels'=>0,'vehicles'=>0,'activities'=>0,'policies'=>0];
    $map=['documents'=>['supplier_contract_version_documents','contract_version_id'],'itineraries'=>['supplier_contract_itineraries','contract_version_id'],'rates'=>['supplier_contract_pax_rates','contract_version_id'],'days'=>['supplier_contract_day_itineraries','contract_version_id'],'hotels'=>['supplier_contract_hotel_inventory','contract_version_id'],'vehicles'=>['supplier_contract_vehicle_rules','contract_version_id'],'activities'=>['supplier_contract_activities','contract_version_id'],'policies'=>['supplier_contract_policy_items','contract_version_id']];
    foreach($map as $k=>$v){if(!tsRBTableExists($pdo,$v[0]))continue;$s=$pdo->prepare('SELECT COUNT(*) FROM `'.$v[0].'` WHERE `'.$v[1].'`=?');$s->execute([$versionId]);$out[$k]=(int)$s->fetchColumn();}return $out;
}
