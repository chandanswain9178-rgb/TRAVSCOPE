<?php
declare(strict_types=1);
require_once __DIR__.'/supplier-hotel-option-functions.php';

function tsSHIHeaderKey(string $v): string {
    $v = preg_replace('/^\xEF\xBB\xBF/', '', trim($v)) ?? trim($v);
    $v = strtolower($v);
    $v = preg_replace('/[^a-z0-9]+/', '', $v) ?? $v;
    return $v;
}
function tsSHINormalizeValue(string $v): string {
    $v=trim($v);
    if(function_exists('iconv')){$x=@iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$v);if($x!==false)$v=$x;}
    $v=strtolower($v);
    return trim(preg_replace('/\s+/',' ',preg_replace('/[^a-z0-9]+/',' ',$v)??$v)??$v);
}
function tsSHIColumnMap(array $header): array {
    $aliases = [
        'supplier_code'=>['suppliercode','supplierid','suppliercode*'],
        'supplier_name'=>['suppliername'],
        'country'=>['country','country*'],
        'state'=>['stateregion','state','region','stateregion*'],
        'destination'=>['destinationtourarea','destination','tourarea','destinationtourarea*'],
        'city'=>['citylocation','city','location','citylocation*'],
        'area'=>['arealocality','area','locality'],
        'supplier_category'=>['suppliercategory','suppliercategory*'],
        'travscope_category'=>['travscopecategory','travscopecategory*','standardcategory'],
        'hotel_name'=>['hotelname','hotelname*','propertyname'],
        'hotel_master_id'=>['hotelmasterid','hotelid'],
        'room_type'=>['roomtype'],
        'meal_plan'=>['mealplan'],
        'preferred'=>['preferredoption','preferred'],
        'priority'=>['priority'],
        'status'=>['status','status*'],
        'allow_similar'=>['allowsimilarhotel','allowsimilar','similarhotel'],
        'internal_note'=>['internalnote','notes','note'],
        'source_reference'=>['sourcereference','source','reference'],
    ];
    $norm=[];foreach($header as $i=>$h)$norm[tsSHIHeaderKey((string)$h)]=$i;
    $out=[];foreach($aliases as $field=>$keys){$out[$field]=null;foreach($keys as $k){$kk=tsSHIHeaderKey($k);if(array_key_exists($kk,$norm)){$out[$field]=$norm[$kk];break;}}}
    return $out;
}
function tsSHIRowValue(array $row,array $map,string $field): string {
    $i=$map[$field]??null; return $i===null?'':trim((string)($row[$i]??''));
}
function tsSHIParseCsv(string $path): array {
    $fh=fopen($path,'rb');if(!$fh)throw new RuntimeException('Could not read CSV file.');
    $rows=[];while(($r=fgetcsv($fh,0,','))!==false){if(count($rows)===0&&isset($r[0]))$r[0]=preg_replace('/^\xEF\xBB\xBF/','',(string)$r[0])??(string)$r[0];$rows[]=$r;if(count($rows)>2501)break;}fclose($fh);
    return $rows;
}
function tsSHIXlsxCellColumn(string $ref): int {
    if(!preg_match('/^([A-Z]+)/i',$ref,$m))return 0;
    $letters=strtoupper($m[1]);$n=0;
    for($i=0;$i<strlen($letters);$i++)$n=$n*26+(ord($letters[$i])-64);
    return max(0,$n-1);
}
function tsSHIXmlDecode(string $v): string {
    $v=preg_replace('/^\xEF\xBB\xBF/','',$v)??$v;
    return html_entity_decode($v,ENT_QUOTES|ENT_XML1,'UTF-8');
}
function tsSHIXlsxAttr(string $attrs,string $name): string {
    $q=preg_quote($name,'~');
    if(preg_match('~(?:^|\\s)'.$q.'\\s*=\\s*(["\\\'])(.*?)\\1~is',$attrs,$m))return tsSHIXmlDecode((string)$m[2]);
    return '';
}
function tsSHIXlsxTextNodes(string $xml): string {
    $out='';
    if(preg_match_all('~<(?:[A-Za-z0-9_]+:)?t\\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?t>~is',$xml,$mm)){
        foreach($mm[1] as $t)$out.=tsSHIXmlDecode(strip_tags((string)$t));
    }
    return $out;
}
function tsSHIXlsxSharedStrings(ZipArchive $zip): array {
    $ss=$zip->getFromName('xl/sharedStrings.xml');
    if($ss===false||$ss==='')return [];
    $shared=[];
    if(preg_match_all('~<(?:[A-Za-z0-9_]+:)?si\\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?si>~is',$ss,$items)){
        foreach($items[1] as $si)$shared[]=tsSHIXlsxTextNodes((string)$si);
    }
    return $shared;
}
function tsSHIXlsxParseWorksheetRaw(string $sx,array $shared): array {
    // Strip illegal XML control bytes sometimes introduced by spreadsheet editors.
    $sx=preg_replace('/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]/','',$sx)??$sx;
    $rows=[];
    if(!preg_match_all('~<(?:[A-Za-z0-9_]+:)?row\\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?row>~is',$sx,$rowMatches))return [];
    foreach($rowMatches[1] as $rowXml){
        $arr=[];
        if(preg_match_all('~<(?:[A-Za-z0-9_]+:)?c\\b([^>]*?)(?:\\s*/>|>(.*?)</(?:[A-Za-z0-9_]+:)?c>)~is',(string)$rowXml,$cells,PREG_SET_ORDER)){
            foreach($cells as $cell){
                $attrs=(string)($cell[1]??'');$inner=(string)($cell[2]??'');
                $ref=tsSHIXlsxAttr($attrs,'r');if($ref==='')continue;
                $col=tsSHIXlsxCellColumn($ref);$type=strtolower(tsSHIXlsxAttr($attrs,'t'));$val='';
                if($type==='inlinestr'){
                    $val=tsSHIXlsxTextNodes($inner);
                }else{
                    $raw='';
                    if(preg_match('~<(?:[A-Za-z0-9_]+:)?v\\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?v>~is',$inner,$vm))$raw=tsSHIXmlDecode(strip_tags((string)$vm[1]));
                    if($type==='s'){$idx=(int)$raw;$val=$shared[$idx]??'';}
                    elseif($type==='b')$val=$raw==='1'?'Yes':'No';
                    else $val=$raw;
                }
                $arr[$col]=$val;
            }
        }
        if($arr){
            $max=max(array_keys($arr));$dense=[];
            for($i=0;$i<=$max;$i++)$dense[]=$arr[$i]??'';
            $rows[]=$dense;
        }
        if(count($rows)>2501)break;
    }
    return $rows;
}
function tsSHIXlsxLooksLikeImport(array $rows): bool {
    if(!$rows)return false;
    foreach(array_slice($rows,0,8) as $row){
        $map=tsSHIColumnMap($row);
        if(($map['hotel_name']??null)!==null&&($map['city']??null)!==null&&($map['supplier_category']??null)!==null&&($map['travscope_category']??null)!==null)return true;
    }
    return false;
}
function tsSHIXlsxPromoteHeader(array $rows): array {
    foreach(array_slice($rows,0,8,true) as $i=>$row){
        $map=tsSHIColumnMap($row);
        if(($map['hotel_name']??null)!==null&&($map['city']??null)!==null&&($map['supplier_category']??null)!==null&&($map['travscope_category']??null)!==null){
            return array_values(array_slice($rows,(int)$i));
        }
    }
    return $rows;
}
function tsSHIParseXlsx(string $path): array {
    if(!class_exists('ZipArchive'))throw new RuntimeException('Excel import needs PHP ZipArchive. CSV import is available now; ask hosting to enable php-zip for .xlsx files.');
    $zip=new ZipArchive();
    if($zip->open($path)!==true)throw new RuntimeException('Could not open Excel workbook. Please upload a normal .xlsx file, not an old .xls or password-protected workbook.');
    try{
        $shared=tsSHIXlsxSharedStrings($zip);
        $candidates=[];
        // First try common worksheet names, then scan every worksheet in the workbook.
        foreach(['xl/worksheets/sheet1.xml','xl/worksheets/sheet2.xml','xl/worksheets/sheet3.xml'] as $n){if($zip->locateName($n)!==false)$candidates[$n]=true;}
        for($i=0;$i<$zip->numFiles;$i++){
            $st=$zip->statIndex($i);$n=(string)($st['name']??'');
            if(preg_match('~^xl/worksheets/[^/]+\\.xml$~i',$n))$candidates[$n]=true;
        }
        if(!$candidates)throw new RuntimeException('Could not find any Excel worksheet inside the workbook.');
        $firstRows=[];
        foreach(array_keys($candidates) as $sheetPath){
            $sx=$zip->getFromName($sheetPath);if($sx===false||$sx==='')continue;
            $rows=tsSHIXlsxParseWorksheetRaw($sx,$shared);
            if(!$firstRows&&$rows)$firstRows=$rows;
            if(tsSHIXlsxLooksLikeImport($rows))return tsSHIXlsxPromoteHeader($rows);
        }
        if($firstRows)return tsSHIXlsxPromoteHeader($firstRows);
        throw new RuntimeException('Excel workbook opened, but no readable rows were found. Download the latest TRAVSCOPE template and keep the Hotel_Options_Import header row unchanged, or use CSV.');
    }finally{$zip->close();}
}
function tsSHIParseFile(string $path,string $name): array {
    $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
    if($ext==='csv')return tsSHIParseCsv($path);
    if($ext==='xlsx')return tsSHIParseXlsx($path);
    throw new RuntimeException('Only .xlsx and .csv files are supported.');
}
function tsSHIFindDestination(PDO $pdo,string $destination,string $state,string $country): ?array {
    $names=array_values(array_filter(array_unique([trim($destination),trim($state)]),fn($v)=>$v!==''));if(!$names)return null;
    foreach($names as $name){$sql="SELECT id,name,".(tsSHOColumn($pdo,'destinations','country')?'country':"'' country")." FROM destinations WHERE LOWER(TRIM(name))=LOWER(TRIM(?))";$p=[$name];if($country!==''&&tsSHOColumn($pdo,'destinations','country')){$sql.=" AND (LOWER(TRIM(country))=LOWER(TRIM(?)) OR TRIM(COALESCE(country,''))='')";$p[]=$country;}$sql.=' ORDER BY id LIMIT 1';$s=$pdo->prepare($sql);$s->execute($p);$r=$s->fetch(PDO::FETCH_ASSOC);if($r)return $r;}
    return null;
}
function tsSHIFindLocation(PDO $pdo,int $destinationId,string $city): ?array {
    if($destinationId<=0||$city===''||!tsSHOTable($pdo,'destination_locations'))return null;
    $s=$pdo->prepare("SELECT id,location_name FROM destination_locations WHERE destination_id=? AND LOWER(TRIM(location_name))=LOWER(TRIM(?)) LIMIT 1");$s->execute([$destinationId,$city]);return $s->fetch(PDO::FETCH_ASSOC)?:null;
}
function tsSHIFindHotelMaster(PDO $pdo,int $destinationId,int $locationId,string $city,string $hotelName,int $star,string $hotelMasterId): int {
    $hm=trim($hotelMasterId);if($hm!==''&&tsSHOTable($pdo,'hotels')){$id=ctype_digit($hm)?(int)$hm:0;if($id<=0&&preg_match('/(\d+)$/',$hm,$m))$id=(int)$m[1];if($id>0){$s=$pdo->prepare("SELECT id FROM hotels WHERE id=?".(tsSHOColumn($pdo,'hotels','status')?" AND status='active'":'')." LIMIT 1");$s->execute([$id]);if($s->fetchColumn())return $id;}}
    return tsSHOAutoMatchHotel($pdo,$destinationId,$locationId,$city,$hotelName,$star);
}
function tsSHIExists(PDO $pdo,int $supplierId,string $city,string $supplierCategory,string $hotelName): int {
    if(!tsSHOReady($pdo))return 0;$norm=tsSHONormalize($hotelName);$s=$pdo->prepare("SELECT id FROM supplier_hotel_options WHERE supplier_id=? AND LOWER(TRIM(city))=LOWER(TRIM(?)) AND LOWER(TRIM(supplier_category))=LOWER(TRIM(?)) AND hotel_name_normalized=? LIMIT 1");$s->execute([$supplierId,$city,$supplierCategory,$norm]);return (int)($s->fetchColumn()?:0);
}
function tsSHIValidateRows(PDO $pdo,array $matrix,int $selectedSupplierId): array {
    if(count($matrix)<2)throw new RuntimeException('The import file has no data rows.');
    $header=array_shift($matrix);$map=tsSHIColumnMap($header);$required=['supplier_category','travscope_category','hotel_name','city'];foreach($required as $f)if(($map[$f]??null)===null)throw new RuntimeException('Missing required column: '.str_replace('_',' ',ucwords($f,'_')).'. Use the TRAVSCOPE template.');
    if(($map['destination']??null)===null&&($map['state']??null)===null)throw new RuntimeException('Missing Destination / Tour Area (or State / Region) column.');
    $supplier=tsSHOSupplier($pdo,$selectedSupplierId);if(!$supplier)throw new RuntimeException('Choose the supplier before importing.');$selectedCode=trim((string)($supplier['supplier_code']??''));
    $allowed=['budget','2 star','3 star','4 star','5 star','luxury','boutique','resort'];$out=[];$rowNo=1;
    foreach($matrix as $row){$rowNo++;$allBlank=true;foreach($row as $v)if(trim((string)$v)!==''){$allBlank=false;break;}if($allBlank)continue;if(count($out)>=2000)break;
        $supplierCode=tsSHIRowValue($row,$map,'supplier_code');$country=tsSHIRowValue($row,$map,'country');$state=tsSHIRowValue($row,$map,'state');$destText=tsSHIRowValue($row,$map,'destination');$city=tsSHIRowValue($row,$map,'city');$supplierCat=tsSHIRowValue($row,$map,'supplier_category');$travCat=tsSHIRowValue($row,$map,'travscope_category');$hotelName=tsSHIRowValue($row,$map,'hotel_name');$status=strtolower(tsSHIRowValue($row,$map,'status'));if($status==='')$status='active';$errors=[];$warnings=[];
        if($supplierCode!==''&&$selectedCode!==''&&strcasecmp($supplierCode,$selectedCode)!==0)$errors[]='Supplier Code does not match selected supplier.';
        if($city==='')$errors[]='City / Location is required.';if($supplierCat==='')$errors[]='Supplier Category is required.';if($hotelName==='')$errors[]='Hotel Name is required.';
        if(!in_array(strtolower($travCat),$allowed,true))$errors[]='TRAVSCOPE Category is invalid.';
        if(!in_array($status,['active','inactive'],true))$errors[]='Status must be Active or Inactive.';
        $dest=tsSHIFindDestination($pdo,$destText,$state,$country);if(!$dest)$errors[]='Destination/State not found in Destination Master.';$destId=(int)($dest['id']??0);
        $loc=$destId>0?tsSHIFindLocation($pdo,$destId,$city):null;$locId=(int)($loc['id']??0);if($destId>0&&!$loc)$warnings[]='City/Location not in Location Master; can be created during import.';
        $star=tsSHOCategoryStar($travCat);$hotelId=($destId>0)?tsSHIFindHotelMaster($pdo,$destId,$locId,$city,$hotelName,$star,tsSHIRowValue($row,$map,'hotel_master_id')):0;if($hotelId<=0)$warnings[]='Not linked to Hotel Master; supplier option can still import.';
        $existing=($destId>0&&$city!==''&&$supplierCat!==''&&$hotelName!=='')?tsSHIExists($pdo,$selectedSupplierId,$city,$supplierCat,$hotelName):0;if($existing>0)$warnings[]='Duplicate supplier hotel option already exists.';
        $notes=[];$baseNote=tsSHIRowValue($row,$map,'internal_note');if($baseNote!=='')$notes[]=$baseNote;$pref=tsSHIRowValue($row,$map,'preferred');if($pref!=='')$notes[]='Preferred: '.$pref;$priority=tsSHIRowValue($row,$map,'priority');if($priority!=='')$notes[]='Priority: '.$priority;$similar=tsSHIRowValue($row,$map,'allow_similar');if($similar!=='')$notes[]='Similar allowed: '.$similar;$src=tsSHIRowValue($row,$map,'source_reference');if($src!=='')$notes[]='Source: '.$src;
        $out[]=['row_no'=>$rowNo,'supplier_id'=>$selectedSupplierId,'source_country'=>$country,'source_state'=>$state,'source_destination'=>$destText,'destination_id'=>$destId,'destination_name'=>(string)($dest['name']??($destText?:$state)),'location_id'=>$locId,'city'=>$city,'supplier_category'=>$supplierCat,'travscope_category'=>$travCat,'mapped_star_category'=>$star,'hotel_id'=>$hotelId,'hotel_name'=>$hotelName,'room_type'=>tsSHIRowValue($row,$map,'room_type'),'meal_plan'=>tsSHIRowValue($row,$map,'meal_plan'),'notes'=>implode(' | ',$notes),'status'=>$status,'existing_id'=>$existing,'excluded'=>false,'errors'=>$errors,'warnings'=>$warnings];
    }
    return $out;
}


/*
|--------------------------------------------------------------------------
| V21.5 - Preview correction / revalidation
|--------------------------------------------------------------------------
| Lets staff correct destination, city, category, hotel and room/meal data
| after Excel/CSV preview and before anything is written to the database.
*/
function tsSHIRevalidatePreparedRow(PDO $pdo,array $row,int $supplierId,array $edit=[]):array{
    $allowed=['budget','2 star','3 star','4 star','5 star','luxury','boutique','resort'];
    $row['excluded']=empty($edit)?(bool)($row['excluded']??false):empty($edit['include']);

    foreach(['city','supplier_category','travscope_category','hotel_name','room_type','meal_plan','status'] as $k){
        if(array_key_exists($k,$edit))$row[$k]=trim((string)$edit[$k]);
    }
    $row['status']=strtolower(trim((string)($row['status']??'active')));
    if($row['status']==='')$row['status']='active';

    $destinationId=array_key_exists('destination_id',$edit)?max(0,(int)$edit['destination_id']):max(0,(int)($row['destination_id']??0));
    $dest=null;
    if($destinationId>0&&tsSHOTable($pdo,'destinations')){
        $hasCountry=tsSHOColumn($pdo,'destinations','country');
        $sql='SELECT id,name,'.($hasCountry?'country':"'' country").' FROM destinations WHERE id=? LIMIT 1';
        $q=$pdo->prepare($sql);$q->execute([$destinationId]);$dest=$q->fetch(PDO::FETCH_ASSOC)?:null;
    }
    if(!$dest&&$destinationId<=0){
        $dest=tsSHIFindDestination($pdo,(string)($row['source_destination']??$row['destination_name']??''),(string)($row['source_state']??''),(string)($row['source_country']??''));
        $destinationId=(int)($dest['id']??0);
    }
    $row['destination_id']=$destinationId;
    $row['destination_name']=$dest?(string)$dest['name']:(string)($row['destination_name']??$row['source_destination']??$row['source_state']??'');

    if($row['excluded']){
        $row['errors']=[];$row['warnings']=[];$row['location_id']=0;$row['hotel_id']=0;$row['existing_id']=0;
        return $row;
    }

    $errors=[];$warnings=[];
    $city=trim((string)($row['city']??''));
    $supplierCat=trim((string)($row['supplier_category']??''));
    $travCat=trim((string)($row['travscope_category']??''));
    $hotelName=trim((string)($row['hotel_name']??''));
    if($destinationId<=0||!$dest)$errors[]='Choose a valid Destination / State.';
    if($city==='')$errors[]='City / Location is required.';
    if($supplierCat==='')$errors[]='Supplier Category is required.';
    if($hotelName==='')$errors[]='Hotel Name is required.';
    if(!in_array(strtolower($travCat),$allowed,true))$errors[]='TRAVSCOPE Category is invalid.';
    if(!in_array($row['status'],['active','inactive'],true))$errors[]='Status must be Active or Inactive.';

    $loc=$destinationId>0&&$city!==''?tsSHIFindLocation($pdo,$destinationId,$city):null;
    $locId=(int)($loc['id']??0);$row['location_id']=$locId;
    if($destinationId>0&&$city!==''&&!$loc)$warnings[]='City/Location not in Location Master; can be created during import.';

    $star=tsSHOCategoryStar($travCat);$row['mapped_star_category']=$star;
    $hotelId=($destinationId>0&&$hotelName!=='')?tsSHIFindHotelMaster($pdo,$destinationId,$locId,$city,$hotelName,$star,''):0;
    $row['hotel_id']=$hotelId;
    if($hotelId<=0&&$hotelName!=='')$warnings[]='Not linked to Hotel Master; supplier option can still import.';

    $existing=($destinationId>0&&$city!==''&&$supplierCat!==''&&$hotelName!=='')?tsSHIExists($pdo,$supplierId,$city,$supplierCat,$hotelName):0;
    $row['existing_id']=$existing;
    if($existing>0)$warnings[]='Duplicate supplier hotel option already exists.';

    $row['errors']=$errors;$row['warnings']=$warnings;
    return $row;
}
function tsSHIApplyPreviewCorrections(PDO $pdo,array $rows,int $supplierId,array $postedRows,array $destinationMap=[]):array{
    $mapByLabel=[];
    foreach($destinationMap as $label=>$id){$id=(int)$id;if($id>0)$mapByLabel[trim((string)$label)]=$id;}
    $out=[];
    foreach($rows as $i=>$row){
        $edit=is_array($postedRows[$i]??null)?$postedRows[$i]:[];
        if(!isset($edit['destination_id'])||((int)$edit['destination_id'])<=0){
            $label=trim((string)($row['destination_name']??$row['source_destination']??$row['source_state']??''));
            if($label!==''&&isset($mapByLabel[$label]))$edit['destination_id']=$mapByLabel[$label];
        }
        $out[]=tsSHIRevalidatePreparedRow($pdo,$row,$supplierId,$edit);
    }
    return $out;
}

/*
|--------------------------------------------------------------------------
| V21.6 - Quick master creation from import rectification workbench
|--------------------------------------------------------------------------
| These helpers let staff repair missing geography / Hotel Master links
| without leaving the Excel/CSV preview. No supplier hotel price is created.
*/
if (!function_exists('tsSHISlug')) {
    function tsSHISlug(string $value): string {
        $value=trim($value);
        if(function_exists('iconv')){$x=@iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$value);if($x!==false)$value=$x;}
        $value=strtolower($value);
        $value=preg_replace('/[^a-z0-9]+/','-',$value)??$value;
        $value=trim($value,'-');
        return $value!==''?$value:'destination';
    }
}
if (!function_exists('tsSHIQuickCreateDestination')) {
    function tsSHIQuickCreateDestination(PDO $pdo,string $name,string $country='India'): int {
        $name=trim($name);$country=trim($country);
        if($name==='')throw new RuntimeException('Destination name is required.');
        if(!tsSHOTable($pdo,'destinations'))throw new RuntimeException('Destination Master table is not available.');
        $existing=tsSHIFindDestination($pdo,$name,$name,$country);
        if($existing)return (int)$existing['id'];

        $cols=['name'];$vals=[$name];$marks=['?'];
        if(tsSHOColumn($pdo,'destinations','slug')){
            $base=tsSHISlug($name);$slug=$base;$n=2;
            try{
                $q=$pdo->prepare('SELECT id FROM destinations WHERE slug=? LIMIT 1');
                while(true){$q->execute([$slug]);if(!$q->fetchColumn())break;$slug=$base.'-'.$n++;}
            }catch(Throwable $ignored){}
            $cols[]='slug';$vals[]=$slug;$marks[]='?';
        }
        if(tsSHOColumn($pdo,'destinations','country')){$cols[]='country';$vals[]=$country!==''?$country:'India';$marks[]='?';}
        if(tsSHOColumn($pdo,'destinations','status')){$cols[]='status';$vals[]='active';$marks[]='?';}
        if(tsSHOColumn($pdo,'destinations','sort_order')){$cols[]='sort_order';$vals[]=0;$marks[]='?';}
        $sql='INSERT INTO destinations(`'.implode('`,`',$cols).'`) VALUES('.implode(',',$marks).')';
        $st=$pdo->prepare($sql);$st->execute($vals);
        return (int)$pdo->lastInsertId();
    }
}
if (!function_exists('tsSHIQuickCreateHotelMaster')) {
    function tsSHIQuickCreateHotelMaster(PDO $pdo,array $row,int $supplierId,int $adminId): int {
        if(!tsSHOTable($pdo,'hotels'))throw new RuntimeException('Hotel Master table is not available.');
        $destinationId=max(0,(int)($row['destination_id']??0));
        $city=trim((string)($row['city']??''));
        $hotelName=trim((string)($row['hotel_name']??''));
        $star=tsSHOCategoryStar((string)($row['travscope_category']??''));
        if($destinationId<=0)throw new RuntimeException('Choose or create the Destination first.');
        if($city==='')throw new RuntimeException('City / Location is required before creating Hotel Master.');
        if($hotelName==='')throw new RuntimeException('Hotel Name is required before creating Hotel Master.');
        if(!in_array($star,[3,4,5],true))throw new RuntimeException('Quick Hotel Master creation supports 3 Star, 4 Star and 5 Star categories. Other supplier categories can remain Supplier Only.');
        $locationId=max(0,(int)($row['location_id']??0));
        if($locationId<=0&&function_exists('tsLocationUpsert'))$locationId=tsLocationUpsert($pdo,$destinationId,$city,'supplier_import',$adminId?:null);
        $match=tsSHOAutoMatchHotel($pdo,$destinationId,$locationId,$city,$hotelName,$star);
        if($match>0)return $match;

        $candidate=[
            'destination_id'=>$destinationId,'location_id'=>$locationId?:null,'hotel_name'=>$hotelName,'city'=>$city,
            'star_category'=>$star,'default_room_type'=>trim((string)($row['room_type']??''))?:null,
            'default_meal_plan'=>trim((string)($row['meal_plan']??''))?:null,'preferred_supplier_id'=>null,
            'is_preferred'=>0,'priority_order'=>100,'status'=>'active','source'=>'manual',
            'notes'=>'Created from Supplier Hotel Import preview','created_by_admin_id'=>$adminId?:null,'updated_by_admin_id'=>$adminId?:null
        ];
        $cols=[];$vals=[];$marks=[];
        foreach($candidate as $col=>$val){if(tsSHOColumn($pdo,'hotels',$col)){$cols[]=$col;$vals[]=$val;$marks[]='?';}}
        foreach(['destination_id','hotel_name','star_category'] as $required)if(!in_array($required,$cols,true))throw new RuntimeException('Hotel Master schema is missing required field: '.$required.'.');
        try{
            $sql='INSERT INTO hotels(`'.implode('`,`',$cols).'`) VALUES('.implode(',',$marks).')';
            $st=$pdo->prepare($sql);$st->execute($vals);
            return (int)$pdo->lastInsertId();
        }catch(Throwable $e){
            $match=tsSHOAutoMatchHotel($pdo,$destinationId,$locationId,$city,$hotelName,$star);
            if($match>0)return $match;
            throw $e;
        }
    }
}
