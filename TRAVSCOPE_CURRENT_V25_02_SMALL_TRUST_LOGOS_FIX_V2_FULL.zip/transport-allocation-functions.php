<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE STEP 11G - SUPPLIER-LEVEL VEHICLE / TRANSPORT ALLOCATION
|--------------------------------------------------------------------------
| Supplier Contract owns vehicle inventory/rules. CRM/Quotation/Booking only
| consumes those approved rules. No vehicle inventory is created at Trip level.
*/

function tsTATableExists(PDO $pdo, string $table): bool
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
    try {
        $stmt=$pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');
        $stmt->execute([$table]);
        return (int)$stmt->fetchColumn()>0;
    } catch (Throwable $e) { return false; }
}

function tsTAColumnExists(PDO $pdo, string $table, string $column): bool
{
    try {
        $stmt=$pdo->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?');
        $stmt->execute([$table,$column]);
        return (int)$stmt->fetchColumn()>0;
    } catch (Throwable $e) { return false; }
}

function tsTAReady(PDO $pdo): bool
{
    return tsTATableExists($pdo,'trip_transport_allocations')
        && tsTATableExists($pdo,'trip_transport_allocation_events')
        && tsTATableExists($pdo,'supplier_contract_vehicle_rules');
}

function tsTAStar($value): ?int
{
    $v=strtolower(trim((string)$value));
    if(preg_match('/\b([3-5])\s*(?:star|★)?\b/u',$v,$m)) return (int)$m[1];
    return null;
}

function tsTANorm(string $value): string
{
    $v=mb_strtolower(trim($value));
    $v=preg_replace('/[^\pL\pN]+/u',' ',$v)??$v;
    return trim(preg_replace('/\s+/u',' ',$v)??$v);
}

function tsTASelectedContractContext(PDO $pdo, int $tripId): ?array
{
    if($tripId<=0 || !tsTATableExists($pdo,'cost_sheet_contract_package_sources') || !tsTATableExists($pdo,'supplier_contract_rate_groups')) return null;
    try{
        $stmt=$pdo->prepare("\n            SELECT cs.contract_version_id,cs.itinerary_id,cs.rate_group_id,\n                   g.supplier_id,g.supplier_category,g.mapped_star_category,g.meal_plan,\n                   c.contract_code,c.contract_name,s.company_name supplier_name\n            FROM cost_sheet_contract_package_sources cs\n            JOIN supplier_contract_rate_groups g ON g.id=cs.rate_group_id\n            LEFT JOIN supplier_contracts c ON c.id=g.contract_id\n            LEFT JOIN suppliers s ON s.id=g.supplier_id\n            WHERE cs.trip_id=? ORDER BY cs.id DESC LIMIT 1\n        ");
        $stmt->execute([$tripId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }catch(Throwable $e){return null;}
}

function tsTAQuotationInfo(PDO $pdo, int $versionId): ?array
{
    try{
        $stmt=$pdo->prepare("\n            SELECT v.*,t.id trip_id,t.trip_code,t.enquiry_id,t.travel_start_date,t.travel_end_date,t.destination_id trip_destination_id,\n                   e.destination customer_destination,e.destination_id customer_destination_id\n            FROM crm_package_versions v\n            LEFT JOIN trips t ON t.enquiry_id=v.lead_id\n            LEFT JOIN enquiries e ON e.id=v.lead_id\n            WHERE v.id=? LIMIT 1\n        ");
        $stmt->execute([$versionId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }catch(Throwable $e){return null;}
}

function tsTAVehiclePool(PDO $pdo, int $contractVersionId, string $supplierCategory, int $paxTotal, string $city=''): array
{
    if(!tsTATableExists($pdo,'supplier_contract_vehicle_rules') || $contractVersionId<=0) return [];
    $hasCity=tsTAColumnExists($pdo,'supplier_contract_vehicle_rules','city');
    $select=$hasCity?'r.*':'r.*,NULL AS city';
    try{
        $stmt=$pdo->prepare("SELECT $select FROM supplier_contract_vehicle_rules r WHERE r.contract_version_id=? AND r.status='active' ORDER BY r.source_order,r.id");
        $stmt->execute([$contractVersionId]);
        $rows=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $e){return [];}

    $cat=tsTANorm($supplierCategory);$cityNorm=tsTANorm($city);
    $exact=[];$category=[];$fallback=[];
    foreach($rows as $row){
        $rowCat=tsTANorm((string)($row['supplier_category']??''));
        if($cat!=='' && $rowCat!==$cat && $rowCat!=='all') continue;
        $min=$row['pax_min']!==null?(int)$row['pax_min']:null;
        $max=$row['pax_max']!==null?(int)$row['pax_max']:null;
        if($min!==null && $paxTotal<$min) continue;
        if($max!==null && $paxTotal>$max) continue;
        $rowCity=tsTANorm((string)($row['city']??''));
        $row['pax_rule_specific']=($min!==null||$max!==null)?1:0;
        $row['city_match']=($cityNorm!==''&&$rowCity!==''&&$rowCity===$cityNorm)?1:0;
        $fallback[]=$row;
        if($row['city_match']) $exact[]=$row;
        elseif($rowCity==='') $category[]=$row;
    }
    $use=$exact?:($category?:$fallback);
    $dedupe=[];$out=[];
    foreach($use as $row){
        $key=tsTANorm((string)$row['vehicle_type']).'|'.(string)($row['ac_basis']??'unspecified');
        if(isset($dedupe[$key])) continue;
        $dedupe[$key]=true;$out[]=$row;
    }
    usort($out,static function($a,$b){
        $pa=(int)($a['pax_rule_specific']??0);$pb=(int)($b['pax_rule_specific']??0);
        if($pa!==$pb)return $pb<=>$pa;
        return ((int)($a['source_order']??0))<=>((int)($b['source_order']??0));
    });
    return $out;
}

function tsTAServiceRequirements(PDO $pdo, int $tripId): array
{
    if(!tsTATableExists($pdo,'trip_service_requirements')) return [];
    try{
        $stmt=$pdo->prepare("\n            SELECT r.*,d.name destination_name\n            FROM trip_service_requirements r\n            LEFT JOIN destinations d ON d.id=r.destination_id\n            WHERE r.trip_id=? AND r.service_type IN ('transport','transfer','sightseeing')\n            ORDER BY r.sort_order,r.id\n        ");
        $stmt->execute([$tripId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $e){return [];}
}

function tsTAEvent(PDO $pdo,array $row,string $type,?string $oldStatus,?string $newStatus,string $message,int $adminId):void
{
    if(!tsTATableExists($pdo,'trip_transport_allocation_events')) return;
    try{
        $stmt=$pdo->prepare("INSERT INTO trip_transport_allocation_events(allocation_id,trip_id,quotation_version_id,booking_id,event_type,old_status,new_status,message,admin_id) VALUES(?,?,?,?,?,?,?,?,?)");
        $stmt->execute([
            (int)($row['id']??0),(int)($row['trip_id']??0),(int)($row['quotation_version_id']??0),
            !empty($row['booking_id'])?(int)$row['booking_id']:null,$type,$oldStatus,$newStatus,
            $message!==''?mb_substr($message,0,1000):null,$adminId>0?$adminId:null
        ]);
    }catch(Throwable $e){error_log('Transport allocation event: '.$e->getMessage());}
}

function tsTABuildForQuotation(PDO $pdo,int $tripId,int $versionId,int $adminId=0,bool $force=false):array
{
    if(!tsTAReady($pdo)) return ['created'=>0,'rows'=>[],'warning'=>'Step 11G SQL is not installed.'];
    $version=tsTAQuotationInfo($pdo,$versionId);
    if(!$version || (int)($version['trip_id']??0)!==$tripId) throw new RuntimeException('Quotation/Trip transport context was not found.');
    $existing=tsTAForQuotation($pdo,$versionId);
    if($existing&&!$force)return ['created'=>0,'rows'=>$existing,'warning'=>'Existing transport plan kept.'];
    if($force){
        foreach($existing as $row){
            if(!empty($row['booking_id'])||in_array((string)$row['allocation_status'],['requested','confirmed'],true))
                throw new RuntimeException('This transport plan is already requested/confirmed. Create a new quotation version instead of rebuilding it.');
        }
        $pdo->prepare('DELETE FROM trip_transport_allocations WHERE quotation_version_id=?')->execute([$versionId]);
    }

    $context=tsTASelectedContractContext($pdo,$tripId);
    $pax=max(1,(int)($version['adults']??1)+(int)($version['children']??0));
    $requirements=tsTAServiceRequirements($pdo,$tripId);
    if(!$requirements){
        $requirements=[[
            'id'=>null,'service_type'=>'transport','title'=>'Private transport as per itinerary',
            'destination_id'=>$version['trip_destination_id']??$version['customer_destination_id']??null,
            'destination_name'=>$version['customer_destination']??'',
            'service_date_from'=>$version['travel_date']??$version['travel_start_date']??null,
            'service_date_to'=>$version['travel_end_date']??null,
            'specifications'=>'Whole-tour transport requirement generated from the quotation because no separate transport service requirement exists.'
        ]];
    }

    $insert=$pdo->prepare("\n        INSERT INTO trip_transport_allocations\n        (trip_id,enquiry_id,quotation_version_id,booking_id,service_requirement_id,source_supplier_id,source_contract_version_id,source_vehicle_rule_id,source_supplier_category,destination_id,destination_name,service_type,route_label,service_date_from,service_date_to,pax_total,vehicle_type_snapshot,alternatives_json,ac_basis,allocation_status,sort_order,created_by_admin_id,updated_by_admin_id)\n        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'proposed',?,?,?)\n    ");
    $created=0;
    foreach($requirements as $index=>$req){
        $city=trim((string)($req['destination_name']??''));
        $pool=$context?tsTAVehiclePool($pdo,(int)$context['contract_version_id'],(string)($context['supplier_category']??''),$pax,$city):[];
        $alternatives=[];foreach($pool as $r){$alternatives[]=[
            'rule_id'=>(int)$r['id'],'vehicle_type'=>(string)$r['vehicle_type'],'ac_basis'=>(string)($r['ac_basis']??'unspecified'),
            'pax_min'=>$r['pax_min']!==null?(int)$r['pax_min']:null,'pax_max'=>$r['pax_max']!==null?(int)$r['pax_max']:null,
            'route_scope'=>(string)($r['route_scope']??''),'city'=>(string)($r['city']??'')
        ];}
        $selectedRule=null;$vehicle=null;$ac='unspecified';
        if(count($pool)===1){$selectedRule=(int)$pool[0]['id'];$vehicle=(string)$pool[0]['vehicle_type'];$ac=(string)($pool[0]['ac_basis']??'unspecified');}
        $route=trim((string)($req['title']??''));if($route==='')$route='Transport as per itinerary';
        $insert->execute([
            $tripId,(int)$version['enquiry_id'],$versionId,null,!empty($req['id'])?(int)$req['id']:null,
            !empty($context['supplier_id'])?(int)$context['supplier_id']:null,!empty($context['contract_version_id'])?(int)$context['contract_version_id']:null,
            $selectedRule,$context?trim((string)($context['supplier_category']??''))?:null:null,
            !empty($req['destination_id'])?(int)$req['destination_id']:null,$city!==''?$city:null,
            trim((string)($req['service_type']??'transport'))?:'transport',$route,
            !empty($req['service_date_from'])?(string)$req['service_date_from']:($version['travel_date']??null),
            !empty($req['service_date_to'])?(string)$req['service_date_to']:null,$pax,$vehicle,
            $alternatives?json_encode($alternatives,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):null,$ac,
            $index+1,$adminId>0?$adminId:null,$adminId>0?$adminId:null
        ]);
        $id=(int)$pdo->lastInsertId();$row=['id'=>$id,'trip_id'=>$tripId,'quotation_version_id'=>$versionId,'booking_id'=>null];
        tsTAEvent($pdo,$row,'auto_built',null,'proposed','Transport requirement built from CRM services / quotation context.',$adminId);$created++;
    }
    return ['created'=>$created,'rows'=>tsTAForQuotation($pdo,$versionId),'warning'=>$context?'':'No selected supplier contract rate was found. Choose a supplier contract in Contract Rate Engine first.'];
}

function tsTAForQuotation(PDO $pdo,int $versionId):array
{
    if(!tsTAReady($pdo)||$versionId<=0)return[];
    $stmt=$pdo->prepare("\n        SELECT a.*,s.company_name supplier_name,c.contract_code,c.contract_name\n        FROM trip_transport_allocations a\n        LEFT JOIN suppliers s ON s.id=a.source_supplier_id\n        LEFT JOIN supplier_contract_versions v ON v.id=a.source_contract_version_id\n        LEFT JOIN supplier_contracts c ON c.id=v.contract_id\n        WHERE a.quotation_version_id=? ORDER BY a.sort_order,a.id\n    ");
    $stmt->execute([$versionId]);$rows=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
    foreach($rows as &$row){$d=json_decode((string)($row['alternatives_json']??''),true);$row['alternatives']=is_array($d)?$d:[];}unset($row);
    return $rows;
}

function tsTAForBooking(PDO $pdo,int $bookingId):array
{
    if(!tsTAReady($pdo)||$bookingId<=0||!tsTATableExists($pdo,'booking_trip_links'))return[];
    try{$stmt=$pdo->prepare('SELECT quotation_version_id FROM booking_trip_links WHERE booking_id=? LIMIT 1');$stmt->execute([$bookingId]);$vid=(int)($stmt->fetchColumn()?:0);return $vid>0?tsTAForQuotation($pdo,$vid):[];}catch(Throwable $e){return[];}
}

function tsTACustomerSafeRows(array $rows):array
{
    $out=[];
    foreach($rows as $row){
        $alts=[];$raw=is_array($row['alternatives']??null)?$row['alternatives']:(json_decode((string)($row['alternatives_json']??''),true)?:[]);
        foreach($raw as $alt){if(!is_array($alt))continue;$name=trim((string)($alt['vehicle_type']??''));if($name!==''&&!in_array($name,$alts,true))$alts[]=$name;}
        $out[]=[
            'service_type'=>(string)($row['service_type']??'transport'),'route_label'=>(string)($row['route_label']??'Transport as per itinerary'),
            'destination_name'=>(string)($row['destination_name']??''),'service_date_from'=>$row['service_date_from']??null,'service_date_to'=>$row['service_date_to']??null,
            'pax_total'=>max(1,(int)($row['pax_total']??1)),'vehicle_type'=>trim((string)($row['vehicle_type_snapshot']??'')),
            'alternatives'=>array_slice($alts,0,8),'ac_basis'=>(string)($row['ac_basis']??'unspecified'),'status'=>(string)($row['allocation_status']??'proposed'),
            'pickup_point'=>(string)($row['pickup_point']??''),'pickup_time'=>(string)($row['pickup_time']??''),'drop_point'=>(string)($row['drop_point']??''),
            'driver_name'=>(string)($row['driver_name']??''),'driver_mobile'=>(string)($row['driver_mobile']??''),'vehicle_number'=>(string)($row['vehicle_number']??''),
            'confirmation_reference'=>(string)($row['supplier_confirmation_ref']??'')
        ];
    }
    return $out;
}

function tsTAAllocationById(PDO $pdo,int $id):?array
{
    if(!tsTAReady($pdo)||$id<=0)return null;$stmt=$pdo->prepare('SELECT * FROM trip_transport_allocations WHERE id=? LIMIT 1');$stmt->execute([$id]);$row=$stmt->fetch(PDO::FETCH_ASSOC);if(!$row)return null;$row['alternatives']=json_decode((string)($row['alternatives_json']??''),true)?:[];return$row;
}

function tsTAUpdateAllocation(PDO $pdo,int $id,array $input,int $adminId):array
{
    $row=tsTAAllocationById($pdo,$id);if(!$row)throw new RuntimeException('Transport allocation was not found.');
    $old=(string)$row['allocation_status'];$status=strtolower(trim((string)($input['allocation_status']??$old)));
    $allowed=['proposed','requested','confirmed','unavailable','replaced','cancelled'];if(!in_array($status,$allowed,true))$status=$old;
    $ruleId=max(0,(int)($input['vehicle_rule_id']??0));$vehicle=trim((string)($row['vehicle_type_snapshot']??''));$ac=(string)($row['ac_basis']??'unspecified');
    if($ruleId>0){
        $stmt=$pdo->prepare("SELECT * FROM supplier_contract_vehicle_rules WHERE id=? AND contract_version_id=? AND status='active' LIMIT 1");
        $stmt->execute([$ruleId,(int)$row['source_contract_version_id']]);$rule=$stmt->fetch(PDO::FETCH_ASSOC);
        if(!$rule)throw new RuntimeException('Select a vehicle from this Supplier Contract inventory.');
        $vehicle=trim((string)$rule['vehicle_type']);$ac=(string)($rule['ac_basis']??'unspecified');
    }
    if($status==='confirmed'&&$vehicle==='')throw new RuntimeException('Select the supplier-contract vehicle before marking it Confirmed.');
    $stmt=$pdo->prepare("\n        UPDATE trip_transport_allocations SET source_vehicle_rule_id=?,vehicle_type_snapshot=?,ac_basis=?,allocation_status=?,pickup_point=?,pickup_time=?,drop_point=?,driver_name=?,driver_mobile=?,vehicle_number=?,supplier_confirmation_ref=?,supplier_note=?,updated_by_admin_id=?,updated_at=NOW() WHERE id=?\n    ");
    $stmt->execute([
        $ruleId>0?$ruleId:null,$vehicle!==''?$vehicle:null,$ac,$status,
        trim((string)($input['pickup_point']??''))?:null,trim((string)($input['pickup_time']??''))?:null,trim((string)($input['drop_point']??''))?:null,
        trim((string)($input['driver_name']??''))?:null,trim((string)($input['driver_mobile']??''))?:null,trim((string)($input['vehicle_number']??''))?:null,
        trim((string)($input['supplier_confirmation_ref']??''))?:null,trim((string)($input['supplier_note']??''))?:null,$adminId>0?$adminId:null,$id
    ]);
    $updated=tsTAAllocationById($pdo,$id)?:$row;tsTAEvent($pdo,$updated,'updated',$old,$status,'Transport allocation updated from Supplier Contract vehicle inventory.',$adminId);return$updated;
}

function tsTAMarkRequested(PDO $pdo,int $versionId,int $adminId):int
{
    if(!tsTAReady($pdo))return 0;$rows=tsTAForQuotation($pdo,$versionId);$count=0;
    foreach($rows as $row){if((string)$row['allocation_status']!=='proposed')continue;$pdo->prepare("UPDATE trip_transport_allocations SET allocation_status='requested',updated_by_admin_id=?,updated_at=NOW() WHERE id=?")->execute([$adminId>0?$adminId:null,(int)$row['id']]);$row['allocation_status']='requested';tsTAEvent($pdo,$row,'requested','proposed','requested','Vehicle/transport confirmation requested or queued with supplier.',$adminId);$count++;}
    return$count;
}

function tsTABindBooking(PDO $pdo,int $versionId,int $bookingId,int $adminId=0):void
{
    if(!tsTAReady($pdo)||$versionId<=0||$bookingId<=0)return;$rows=tsTAForQuotation($pdo,$versionId);
    $pdo->prepare('UPDATE trip_transport_allocations SET booking_id=?,updated_by_admin_id=?,updated_at=NOW() WHERE quotation_version_id=? AND (booking_id IS NULL OR booking_id=0)')->execute([$bookingId,$adminId>0?$adminId:null,$versionId]);
    foreach($rows as $row){$row['booking_id']=$bookingId;tsTAEvent($pdo,$row,'booking_bound',(string)$row['allocation_status'],(string)$row['allocation_status'],'Accepted quotation transport plan frozen to booking.',$adminId);}
}

function tsTASummary(array $rows):array
{
    $out=['total'=>count($rows),'confirmed'=>0,'requested'=>0,'review'=>0];
    foreach($rows as $row){$st=(string)($row['allocation_status']??'proposed');if($st==='confirmed')$out['confirmed']++;elseif($st==='requested')$out['requested']++;if(empty($row['alternatives'])&&trim((string)($row['vehicle_type_snapshot']??''))==='')$out['review']++;}
    return$out;
}
