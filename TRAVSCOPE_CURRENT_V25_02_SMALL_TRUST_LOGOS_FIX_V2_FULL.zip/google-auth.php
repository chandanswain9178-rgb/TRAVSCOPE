<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| GOOGLE OAUTH 2.0 LOGIN / REGISTRATION
|--------------------------------------------------------------------------
| PHP 8.0+
| Uses settings from config.php
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';


/*
|--------------------------------------------------------------------------
| GOOGLE AUTH ERROR
|--------------------------------------------------------------------------
*/

function googleAuthFail(string $message): void
{
    $_SESSION['google_auth_error'] = $message;

    header('Location: ' . BASE_URL . 'login.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| HTTP POST TO GOOGLE
|--------------------------------------------------------------------------
*/

function googleHttpPost(string $url, array $fields): array
{
    if (!function_exists('curl_init')) {
        throw new RuntimeException(
            'PHP cURL extension is not enabled on the server.'
        );
    }

    $ch = curl_init($url);

    if ($ch === false) {
        throw new RuntimeException(
            'Unable to initialize cURL.'
        );
    }

    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($fields),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Content-Type: application/x-www-form-urlencoded',
        ],
    ]);

    $body = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = (int)curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if ($body === false) {
        throw new RuntimeException(
            'Google connection failed: ' .
            ($curlError !== ''
                ? $curlError
                : 'Unknown connection error.')
        );
    }

    $data = json_decode(
        (string)$body,
        true
    );

    if (
        $httpCode < 200
        ||
        $httpCode >= 300
    ) {
        $googleError = '';

        if (is_array($data)) {
            $googleError = trim(
                (string)(
                    $data['error_description']
                    ??
                    $data['error']
                    ??
                    ''
                )
            );
        }

        throw new RuntimeException(
            'Google token request failed' .
            (
                $googleError !== ''
                    ? ': ' . $googleError
                    : ' (HTTP ' . $httpCode . ')'
            )
        );
    }

    if (!is_array($data)) {
        throw new RuntimeException(
            'Google returned an invalid token response.'
        );
    }

    return $data;
}


/*
|--------------------------------------------------------------------------
| HTTP GET FROM GOOGLE
|--------------------------------------------------------------------------
*/

function googleHttpGet(
    string $url,
    string $accessToken
): array {

    if (!function_exists('curl_init')) {
        throw new RuntimeException(
            'PHP cURL extension is not enabled on the server.'
        );
    }

    $ch = curl_init($url);

    if ($ch === false) {
        throw new RuntimeException(
            'Unable to initialize cURL.'
        );
    }

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Authorization: Bearer ' . $accessToken,
        ],
    ]);

    $body = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = (int)curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if ($body === false) {
        throw new RuntimeException(
            'Google profile connection failed: ' .
            ($curlError !== ''
                ? $curlError
                : 'Unknown connection error.')
        );
    }

    $data = json_decode(
        (string)$body,
        true
    );

    if (
        $httpCode < 200
        ||
        $httpCode >= 300
        ||
        !is_array($data)
    ) {
        throw new RuntimeException(
            'Google profile request failed (HTTP '
            . $httpCode .
            ').'
        );
    }

    return $data;
}


/*
|--------------------------------------------------------------------------
| VERIFY GOOGLE CONFIGURATION
|--------------------------------------------------------------------------
|
| IMPORTANT:
| Only verify that values exist.
| DO NOT compare them against your real Client ID / Secret / Redirect URI.
|
*/

if (
    !defined('GOOGLE_CLIENT_ID')
    ||
    trim((string)GOOGLE_CLIENT_ID) === ''
    ||
    !defined('GOOGLE_CLIENT_SECRET')
    ||
    trim((string)GOOGLE_CLIENT_SECRET) === ''
    ||
    !defined('GOOGLE_REDIRECT_URI')
    ||
    trim((string)GOOGLE_REDIRECT_URI) === ''
) {
    googleAuthFail(
        'Google login configuration is incomplete.'
    );
}


/*
|--------------------------------------------------------------------------
| GOOGLE RETURNED ERROR
|--------------------------------------------------------------------------
*/

if (!empty($_GET['error'])) {

    $googleError =
        trim((string)$_GET['error']);

    if ($googleError === 'access_denied') {
        googleAuthFail(
            'Google sign-in was cancelled.'
        );
    }

    googleAuthFail(
        'Google sign-in could not be completed.'
    );
}


/*
|--------------------------------------------------------------------------
| STEP 1
| SEND USER TO GOOGLE
|--------------------------------------------------------------------------
*/

if (empty($_GET['code'])) {

    try {

        $state =
            bin2hex(
                random_bytes(32)
            );

    } catch (Throwable $e) {

        error_log(
            'TRAVSCOPE Google state error: '
            . $e->getMessage()
        );

        googleAuthFail(
            'Google sign-in could not be started.'
        );
    }

    $_SESSION['google_oauth_state'] =
        $state;


    /*
    |--------------------------------------------------------------------------
    | GOOGLE AUTHORIZATION PARAMETERS
    |--------------------------------------------------------------------------
    */

    $params = [

        'client_id' =>
            GOOGLE_CLIENT_ID,

        'redirect_uri' =>
            GOOGLE_REDIRECT_URI,

        'response_type' =>
            'code',

        'scope' =>
            'openid email profile',

        'state' =>
            $state,

        'access_type' =>
            'online',

        'include_granted_scopes' =>
            'true',

        'prompt' =>
            'select_account',
    ];


    $googleUrl =
        'https://accounts.google.com/o/oauth2/v2/auth?'
        .
        http_build_query(
            $params,
            '',
            '&',
            PHP_QUERY_RFC3986
        );


    header(
        'Location: ' . $googleUrl
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| STEP 2
| VERIFY SECURITY STATE
|--------------------------------------------------------------------------
*/

$returnedState =
    trim(
        (string)(
            $_GET['state']
            ??
            ''
        )
    );

$savedState =
    trim(
        (string)(
            $_SESSION['google_oauth_state']
            ??
            ''
        )
    );


unset(
    $_SESSION['google_oauth_state']
);


if (
    $returnedState === ''
    ||
    $savedState === ''
    ||
    !hash_equals(
        $savedState,
        $returnedState
    )
) {
    googleAuthFail(
        'Google sign-in security verification failed. Please try again.'
    );
}


/*
|--------------------------------------------------------------------------
| AUTHORIZATION CODE
|--------------------------------------------------------------------------
*/

$authorizationCode =
    trim(
        (string)(
            $_GET['code']
            ??
            ''
        )
    );


if ($authorizationCode === '') {
    googleAuthFail(
        'Google did not return an authorization code.'
    );
}


/*
|--------------------------------------------------------------------------
| STEP 3
| EXCHANGE CODE FOR ACCESS TOKEN
|--------------------------------------------------------------------------
*/

try {

    $tokenData =
        googleHttpPost(
            'https://oauth2.googleapis.com/token',
            [
                'code' =>
                    $authorizationCode,

                'client_id' =>
                    GOOGLE_CLIENT_ID,

                'client_secret' =>
                    GOOGLE_CLIENT_SECRET,

                'redirect_uri' =>
                    GOOGLE_REDIRECT_URI,

                'grant_type' =>
                    'authorization_code',
            ]
        );


    $accessToken =
        trim(
            (string)(
                $tokenData['access_token']
                ??
                ''
            )
        );


    if ($accessToken === '') {
        throw new RuntimeException(
            'Google did not return an access token.'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | GET GOOGLE USER PROFILE
    |--------------------------------------------------------------------------
    */

    $profile =
        googleHttpGet(
            'https://openidconnect.googleapis.com/v1/userinfo',
            $accessToken
        );


    /*
    |--------------------------------------------------------------------------
    | PROFILE VALUES
    |--------------------------------------------------------------------------
    */

    $googleSub =
        trim(
            (string)(
                $profile['sub']
                ??
                ''
            )
        );


    $email =
        strtolower(
            trim(
                (string)(
                    $profile['email']
                    ??
                    ''
                )
            )
        );


    $fullName =
        trim(
            (string)(
                $profile['name']
                ??
                'Google Customer'
            )
        );


    $picture =
        trim(
            (string)(
                $profile['picture']
                ??
                ''
            )
        );


    $emailVerified =
        filter_var(
            $profile['email_verified']
            ??
            false,
            FILTER_VALIDATE_BOOLEAN
        );


    /*
    |--------------------------------------------------------------------------
    | VERIFY GOOGLE PROFILE
    |--------------------------------------------------------------------------
    */

    if (
        $googleSub === ''
        ||
        $email === ''
        ||
        !filter_var(
            $email,
            FILTER_VALIDATE_EMAIL
        )
        ||
        !$emailVerified
    ) {
        throw new RuntimeException(
            'Google account verification failed.'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | CHECK google_sub DATABASE COLUMN
    |--------------------------------------------------------------------------
    */

    $columnCheck =
        $pdo->query(
            "SHOW COLUMNS
             FROM users
             LIKE 'google_sub'"
        );


    if (
        !$columnCheck
        ||
        !$columnCheck->fetch()
    ) {
        throw new RuntimeException(
            'Database column users.google_sub is missing.'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | FIND USER BY GOOGLE ID
    |--------------------------------------------------------------------------
    */

    $stmt =
        $pdo->prepare(
            "
            SELECT
                id,
                full_name,
                email,
                mobile,
                status,
                google_sub
            FROM users
            WHERE google_sub = ?
            LIMIT 1
            "
        );


    $stmt->execute([
        $googleSub
    ]);


    $user =
        $stmt->fetch();


    /*
    |--------------------------------------------------------------------------
    | IF GOOGLE USER NOT FOUND
    | LOOK FOR EXISTING EMAIL ACCOUNT
    |--------------------------------------------------------------------------
    */

    if (!$user) {

        $stmt =
            $pdo->prepare(
                "
                SELECT
                    id,
                    full_name,
                    email,
                    mobile,
                    status,
                    google_sub
                FROM users
                WHERE email = ?
                LIMIT 1
                "
            );

        $stmt->execute([
            $email
        ]);

        $existingUser =
            $stmt->fetch();


        /*
        |--------------------------------------------------------------------------
        | EXISTING EMAIL ACCOUNT
        |--------------------------------------------------------------------------
        */

        if ($existingUser) {

            if (
                !empty(
                    $existingUser['google_sub']
                )
                &&
                !hash_equals(
                    (string)$existingUser['google_sub'],
                    $googleSub
                )
            ) {
                googleAuthFail(
                    'This TRAVSCOPE account is already linked to another Google account.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | EXISTING ACCOUNT WITHOUT MOBILE
            |--------------------------------------------------------------------------
            |
            | Do not complete login yet.
            | Save the verified Google profile and send customer to register.php,
            | where only the mobile-number field will be shown.
            |
            */

            $existingMobile =
                trim(
                    (string)(
                        $existingUser['mobile']
                        ?? ''
                    )
                );

            if ($existingMobile === '') {

                $_SESSION['google_register'] = [
                    'google_sub' => $googleSub,
                    'email'      => $email,
                    'full_name'  => $fullName !== ''
                        ? $fullName
                        : (string)$existingUser['full_name'],
                    'picture'    => $picture,
                    'existing_user_id' => (int)$existingUser['id'],
                ];

                header(
                    'Location: ' . BASE_URL . 'register.php'
                );

                exit;
            }


            /*
            |--------------------------------------------------------------------------
            | EXISTING ACCOUNT ALREADY HAS MOBILE
            | LINK GOOGLE AND CONTINUE LOGIN
            |--------------------------------------------------------------------------
            */

            $stmt =
                $pdo->prepare(
                    "
                    UPDATE users
                    SET
                        google_sub = ?,
                        email_verified = 1,
                        profile_image =
                            CASE
                                WHEN
                                    (
                                        profile_image IS NULL
                                        OR
                                        profile_image = ''
                                    )
                                    AND ? <> ''
                                THEN ?
                                ELSE profile_image
                            END
                    WHERE id = ?
                    "
                );

            $stmt->execute([
                $googleSub,
                $picture,
                $picture,
                (int)$existingUser['id']
            ]);

            $stmt =
                $pdo->prepare(
                    "
                    SELECT
                        id,
                        full_name,
                        email,
                        mobile,
                        status,
                        google_sub
                    FROM users
                    WHERE id = ?
                    LIMIT 1
                    "
                );

            $stmt->execute([
                (int)$existingUser['id']
            ]);

            $user =
                $stmt->fetch();
        }
    }


    /*
    |--------------------------------------------------------------------------
    | NEW GOOGLE CUSTOMER
    |--------------------------------------------------------------------------
    |
    | Do NOT create the database row yet.
    | Google has verified the email, but TRAVSCOPE still requires mobile.
    | Store the Google profile in the session and send the user back to the
    | normal register.php page. That page will ask only for mobile number,
    | save it without OTP, create the account, and log the customer in.
    |
    */

    if (!$user) {

        $_SESSION['google_register'] = [
            'google_sub' => $googleSub,
            'email'      => $email,
            'full_name'  => $fullName !== ''
                ? $fullName
                : 'Google Customer',
            'picture'    => $picture,
        ];

        header(
            'Location: ' . BASE_URL . 'register.php'
        );

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | VERIFY USER
    |--------------------------------------------------------------------------
    */

    if (!$user) {
        throw new RuntimeException(
            'Customer account could not be loaded.'
        );
    }


    if (
        strtolower(
            trim(
                (string)(
                    $user['status']
                    ??
                    ''
                )
            )
        )
        !==
        'active'
    ) {
        googleAuthFail(
            'This customer account is inactive. Please contact support.'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | LOGIN CUSTOMER
    |--------------------------------------------------------------------------
    */

    session_regenerate_id(true);


    /*
    |--------------------------------------------------------------------------
    | REMOVE ADMIN SESSION
    |--------------------------------------------------------------------------
    */

    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_mobile'],
        $_SESSION['admin_role']
    );


    /*
    |--------------------------------------------------------------------------
    | CUSTOMER SESSION
    |--------------------------------------------------------------------------
    */

    $_SESSION['user_id'] =
        (int)$user['id'];

    $_SESSION['user_name'] =
        (string)$user['full_name'];

    $_SESSION['user_email'] =
        (string)$user['email'];

    $_SESSION['user_mobile'] =
        (string)(
            $user['mobile']
            ??
            ''
        );


    /*
    |--------------------------------------------------------------------------
    | REMOVE OLD ERRORS
    |--------------------------------------------------------------------------
    */

    unset(
        $_SESSION['google_auth_error'],
        $_SESSION['pending_verify_user_id'],
        $_SESSION['pending_verify_email'],
        $_SESSION['pending_verify_name']
    );


    /*
    |--------------------------------------------------------------------------
    | REDIRECT AFTER LOGIN
    |--------------------------------------------------------------------------
    */

    $redirectAfterLogin =
        $_SESSION['redirect_after_login']
        ??
        BASE_URL . 'dashboard.php';


    unset(
        $_SESSION['redirect_after_login']
    );


    /*
    |--------------------------------------------------------------------------
    | SAFE REDIRECT CHECK
    |--------------------------------------------------------------------------
    */

    $isSafeRedirect = false;


    if (
        str_starts_with(
            $redirectAfterLogin,
            BASE_URL
        )
    ) {
        $isSafeRedirect = true;

    } elseif (
        str_starts_with(
            $redirectAfterLogin,
            '/'
        )
        &&
        !str_starts_with(
            $redirectAfterLogin,
            '//'
        )
    ) {
        $isSafeRedirect = true;
    }


    if (!$isSafeRedirect) {
        $redirectAfterLogin =
            BASE_URL . 'dashboard.php';
    }


    header(
        'Location: ' . $redirectAfterLogin
    );

    exit;


/*
|--------------------------------------------------------------------------
| GOOGLE LOGIN ERROR
|--------------------------------------------------------------------------
*/

} catch (Throwable $e) {

    error_log(
        'TRAVSCOPE Google OAuth Error: '
        . $e->getMessage()
    );


    if (
        defined('APP_DEBUG')
        &&
        APP_DEBUG
    ) {
        googleAuthFail(
            'Google sign-in error: '
            . $e->getMessage()
        );
    }


    googleAuthFail(
        'Google sign-in failed. Please try again.'
    );
}