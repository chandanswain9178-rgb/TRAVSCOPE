<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — BACKUP / RESTORE + DEPLOYMENT SAFETY CENTER
|--------------------------------------------------------------------------
|
| Safety principles:
| - release workflow is explicit and auditable;
| - pre/post deployment health uses the existing Health Center;
| - maintenance mode reuses the existing settings table;
| - database/settings backups are generated for download only;
| - no automatic database restore exists in this module;
| - rollback is recorded only after an Admin performs the real rollback.
|
*/

$tsDeployAclFile = __DIR__ . '/access-control-functions.php';
if (is_file($tsDeployAclFile) && !function_exists('tsAclCan')) {
    require_once $tsDeployAclFile;
}

$tsDeployHealthFile = __DIR__ . '/health-functions.php';
if (is_file($tsDeployHealthFile) && !function_exists('tsHealthScan')) {
    require_once $tsDeployHealthFile;
}


function tsDeployTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];
    $key = strtolower($table);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
        $stmt->execute([$table]);
        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}


function tsDeployReady(PDO $pdo): bool
{
    return
        tsDeployTableExists($pdo, 'deployment_releases')
        && tsDeployTableExists($pdo, 'deployment_release_events')
        && tsDeployTableExists($pdo, 'deployment_backup_registry');
}


function tsDeploySettingsReady(PDO $pdo): bool
{
    return tsDeployTableExists($pdo, 'settings');
}


function tsDeploySetting(PDO $pdo, string $key, string $default = ''): string
{
    if (!tsDeploySettingsReady($pdo)) {
        return $default;
    }

    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key=? LIMIT 1");
        $stmt->execute([$key]);
        $value = $stmt->fetchColumn();
        return $value !== false ? (string)$value : $default;
    } catch (Throwable $e) {
        return $default;
    }
}


function tsDeploySetSetting(PDO $pdo, string $key, string $value): void
{
    if (!tsDeploySettingsReady($pdo)) {
        throw new RuntimeException('Existing settings table is unavailable.');
    }

    $stmt = $pdo->prepare("SELECT id FROM settings WHERE setting_key=? LIMIT 1 FOR UPDATE");
    $stmt->execute([$key]);
    $id = (int)($stmt->fetchColumn() ?: 0);

    if ($id > 0) {
        $stmt = $pdo->prepare("UPDATE settings SET setting_value=?, updated_at=CURRENT_TIMESTAMP WHERE id=?");
        $stmt->execute([$value, $id]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO settings (setting_key,setting_value) VALUES (?,?)");
        $stmt->execute([$key, $value]);
    }
}


function tsDeployMaintenanceStatus(PDO $pdo): array
{
    return [
        'enabled' => tsDeploySetting($pdo, 'maintenance_mode', '0') === '1',
        'message' => tsDeploySetting(
            $pdo,
            'maintenance_message',
            'We are updating our website. Please check back shortly.'
        ),
    ];
}


function tsDeployHealthSnapshot(PDO $pdo): array
{
    if (!function_exists('tsHealthScan')) {
        throw new RuntimeException('System Health module is not available.');
    }

    $scan = tsHealthScan($pdo);
    $summary = (array)($scan['summary'] ?? []);

    return [
        'scan' => $scan,
        'score' => (int)($summary['health_score'] ?? 0),
        'fail' => (int)($summary['fail'] ?? 0),
        'warning' => (int)($summary['warning'] ?? 0),
        'pass' => (int)($summary['pass'] ?? 0),
        'info' => (int)($summary['info'] ?? 0),
    ];
}


function tsDeployJson(array $value): string
{
    return (string)json_encode(
        $value,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
}


function tsDeployDecode(?string $json): array
{
    if (!$json) {
        return [];
    }

    $value = json_decode($json, true);
    return is_array($value) ? $value : [];
}


function tsDeployEvent(
    PDO $pdo,
    int $releaseId,
    string $eventType,
    string $result,
    int $adminId,
    array $details = [],
    ?array $health = null
): void {
    if (!tsDeployReady($pdo)) {
        return;
    }

    $stmt = $pdo->prepare("INSERT INTO deployment_release_events (release_id,event_type,event_result,health_score,fail_count,warning_count,details_json,admin_id) VALUES (?,?,?,?,?,?,?,?)");
    $stmt->execute([
        $releaseId,
        mb_substr($eventType, 0, 80),
        mb_substr($result, 0, 30),
        $health !== null ? (int)($health['score'] ?? 0) : null,
        $health !== null ? (int)($health['fail'] ?? 0) : null,
        $health !== null ? (int)($health['warning'] ?? 0) : null,
        $details ? tsDeployJson($details) : null,
        $adminId > 0 ? $adminId : null,
    ]);
}


function tsDeployCreateRelease(
    PDO $pdo,
    string $releaseTag,
    string $packageName,
    string $packageSha256,
    string $notes,
    int $adminId
): int {
    if (!tsDeployReady($pdo)) {
        throw new RuntimeException('Import the Deployment Safety SQL first.');
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire($pdo, $adminId, 'manage_access', 'create_deployment_release', 'deployment_release', null);
    }

    $releaseTag = trim($releaseTag);
    $packageName = trim($packageName);
    $packageSha256 = strtolower(trim($packageSha256));
    $notes = trim($notes);

    if ($releaseTag === '' || mb_strlen($releaseTag) > 120) {
        throw new RuntimeException('Release tag is required and must be 120 characters or fewer.');
    }

    if ($packageName !== '' && mb_strlen($packageName) > 255) {
        throw new RuntimeException('Package name is too long.');
    }

    if ($packageSha256 !== '' && !preg_match('/^[a-f0-9]{64}$/', $packageSha256)) {
        throw new RuntimeException('Package SHA-256 must contain exactly 64 hexadecimal characters.');
    }

    $stmt = $pdo->prepare("INSERT INTO deployment_releases (release_tag,package_name,package_sha256,status,notes,created_by_admin_id,updated_by_admin_id) VALUES (?,?,?,'draft',?,?,?)");
    $stmt->execute([
        $releaseTag,
        $packageName !== '' ? $packageName : null,
        $packageSha256 !== '' ? $packageSha256 : null,
        $notes !== '' ? $notes : null,
        $adminId > 0 ? $adminId : null,
        $adminId > 0 ? $adminId : null,
    ]);

    $id = (int)$pdo->lastInsertId();

    tsDeployEvent(
        $pdo,
        $id,
        'release_created',
        'recorded',
        $adminId,
        [
            'release_tag' => $releaseTag,
            'package_name' => $packageName !== '' ? $packageName : null,
            'package_sha256' => $packageSha256 !== '' ? $packageSha256 : null,
        ]
    );

    return $id;
}


function tsDeployRelease(PDO $pdo, int $releaseId): ?array
{
    if ($releaseId <= 0 || !tsDeployReady($pdo)) {
        return null;
    }

    $stmt = $pdo->prepare("SELECT r.*,a.name AS created_by_name FROM deployment_releases r LEFT JOIN admins a ON a.id=r.created_by_admin_id WHERE r.id=? LIMIT 1");
    $stmt->execute([$releaseId]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}


function tsDeployReleases(PDO $pdo, int $limit = 60): array
{
    if (!tsDeployReady($pdo)) {
        return [];
    }

    $limit = max(1, min(200, $limit));
    $stmt = $pdo->query("SELECT r.*,a.name AS created_by_name FROM deployment_releases r LEFT JOIN admins a ON a.id=r.created_by_admin_id ORDER BY r.id DESC LIMIT {$limit}");
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsDeployEvents(PDO $pdo, int $releaseId, int $limit = 80): array
{
    if ($releaseId <= 0 || !tsDeployReady($pdo)) {
        return [];
    }

    $limit = max(1, min(200, $limit));
    $stmt = $pdo->prepare("SELECT e.*,a.name AS admin_name FROM deployment_release_events e LEFT JOIN admins a ON a.id=e.admin_id WHERE e.release_id=? ORDER BY e.id DESC LIMIT {$limit}");
    $stmt->execute([$releaseId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsDeployBackups(PDO $pdo, int $limit = 80): array
{
    if (!tsDeployReady($pdo)) {
        return [];
    }

    $limit = max(1, min(200, $limit));
    $stmt = $pdo->query("SELECT b.*,r.release_tag,a.name AS admin_name FROM deployment_backup_registry b LEFT JOIN deployment_releases r ON r.id=b.release_id LEFT JOIN admins a ON a.id=b.generated_by_admin_id ORDER BY b.id DESC LIMIT {$limit}");
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsDeployRunPrecheck(PDO $pdo, int $releaseId, int $adminId): array
{
    $release = tsDeployRelease($pdo, $releaseId);
    if (!$release) {
        throw new RuntimeException('Deployment release was not found.');
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire($pdo, $adminId, 'manage_access', 'run_pre_deployment_health', 'deployment_release', $releaseId);
    }

    $precheckAllowed =
        in_array((string)$release['status'], ['draft','precheck_ready'], true)
        || (
            (string)$release['status'] === 'failed'
            && empty($release['deployed_at'])
        );

    if (!$precheckAllowed) {
        throw new RuntimeException('Pre-deployment Health Check is not available in the current release state.');
    }

    $health = tsDeployHealthSnapshot($pdo);
    $nextStatus = $health['fail'] > 0 ? 'failed' : 'precheck_ready';

    $stmt = $pdo->prepare("UPDATE deployment_releases SET status=?,pre_health_json=?,prechecked_at=NOW(),updated_by_admin_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?");
    $stmt->execute([
        $nextStatus,
        tsDeployJson($health['scan']),
        $adminId > 0 ? $adminId : null,
        $releaseId,
    ]);

    tsDeployEvent(
        $pdo,
        $releaseId,
        'pre_deployment_health',
        $health['fail'] > 0 ? 'failed' : 'passed',
        $adminId,
        ['status_after' => $nextStatus],
        $health
    );

    return $health;
}


function tsDeployStartMaintenance(
    PDO $pdo,
    int $releaseId,
    string $message,
    int $adminId
): void {
    $release = tsDeployRelease($pdo, $releaseId);
    if (!$release) {
        throw new RuntimeException('Deployment release was not found.');
    }

    if ((string)$release['status'] !== 'precheck_ready') {
        throw new RuntimeException('Run a passing Pre-Deployment Health Check before Maintenance Mode.');
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire($pdo, $adminId, 'manage_access', 'start_deployment_maintenance', 'deployment_release', $releaseId);
    }

    $message = trim($message);
    if ($message === '') {
        $message = 'We are updating our website. Please check back shortly.';
    }

    if (mb_strlen($message) > 1000) {
        throw new RuntimeException('Maintenance message must be 1000 characters or fewer.');
    }

    $pdo->beginTransaction();
    try {
        tsDeploySetSetting($pdo, 'maintenance_message', $message);
        tsDeploySetSetting($pdo, 'maintenance_mode', '1');

        $stmt = $pdo->prepare("UPDATE deployment_releases SET status='maintenance',maintenance_started_at=NOW(),updated_by_admin_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?");
        $stmt->execute([$adminId > 0 ? $adminId : null, $releaseId]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    tsDeployEvent($pdo, $releaseId, 'maintenance_started', 'recorded', $adminId, ['message' => $message]);
}


function tsDeployMarkDeployed(PDO $pdo, int $releaseId, int $adminId): void
{
    $release = tsDeployRelease($pdo, $releaseId);
    if (!$release) {
        throw new RuntimeException('Deployment release was not found.');
    }

    if ((string)$release['status'] !== 'maintenance') {
        throw new RuntimeException('Release must be in Maintenance state before marking code as deployed.');
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire($pdo, $adminId, 'manage_access', 'mark_deployment_code_deployed', 'deployment_release', $releaseId);
    }

    $stmt = $pdo->prepare("UPDATE deployment_releases SET status='deployed',deployed_at=NOW(),updated_by_admin_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?");
    $stmt->execute([$adminId > 0 ? $adminId : null, $releaseId]);

    tsDeployEvent($pdo, $releaseId, 'code_deployed', 'recorded', $adminId);
}


function tsDeployPostcheckAndExit(PDO $pdo, int $releaseId, int $adminId): array
{
    $release = tsDeployRelease($pdo, $releaseId);
    if (!$release) {
        throw new RuntimeException('Deployment release was not found.');
    }

    $postcheckAllowed =
        (string)$release['status'] === 'deployed'
        || (
            (string)$release['status'] === 'failed'
            && !empty($release['deployed_at'])
        );

    if (!$postcheckAllowed) {
        throw new RuntimeException('Post-Deployment Health Check requires a release that was actually marked Deployed.');
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire($pdo, $adminId, 'manage_access', 'run_post_deployment_health', 'deployment_release', $releaseId);
    }

    $health = tsDeployHealthSnapshot($pdo);

    $pdo->beginTransaction();
    try {
        if ($health['fail'] > 0) {
            $stmt = $pdo->prepare("UPDATE deployment_releases SET status='failed',post_health_json=?,updated_by_admin_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?");
            $stmt->execute([
                tsDeployJson($health['scan']),
                $adminId > 0 ? $adminId : null,
                $releaseId,
            ]);
        } else {
            tsDeploySetSetting($pdo, 'maintenance_mode', '0');

            $stmt = $pdo->prepare("UPDATE deployment_releases SET status='verified',post_health_json=?,verified_at=NOW(),updated_by_admin_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?");
            $stmt->execute([
                tsDeployJson($health['scan']),
                $adminId > 0 ? $adminId : null,
                $releaseId,
            ]);
        }

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    tsDeployEvent(
        $pdo,
        $releaseId,
        'post_deployment_health',
        $health['fail'] > 0 ? 'failed' : 'passed',
        $adminId,
        [
            'maintenance_after' => $health['fail'] > 0 ? 'on' : 'off',
            'status_after' => $health['fail'] > 0 ? 'failed' : 'verified',
        ],
        $health
    );

    return $health;
}


function tsDeployExitMaintenance(PDO $pdo, int $releaseId, int $adminId): void
{
    $release = tsDeployRelease($pdo, $releaseId);
    if (!$release) {
        throw new RuntimeException('Deployment release was not found.');
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire($pdo, $adminId, 'manage_access', 'manual_exit_deployment_maintenance', 'deployment_release', $releaseId);
    }

    $pdo->beginTransaction();
    try {
        tsDeploySetSetting($pdo, 'maintenance_mode', '0');
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    tsDeployEvent($pdo, $releaseId, 'maintenance_manually_disabled', 'recorded', $adminId);
}


function tsDeployRegisterRollbackPackage(
    PDO $pdo,
    int $releaseId,
    string $packageName,
    string $packageSha256,
    string $notes,
    int $adminId
): void {
    $release = tsDeployRelease($pdo, $releaseId);
    if (!$release) {
        throw new RuntimeException('Deployment release was not found.');
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire($pdo, $adminId, 'manage_access', 'register_rollback_package', 'deployment_release', $releaseId);
    }

    $packageName = trim($packageName);
    $packageSha256 = strtolower(trim($packageSha256));
    $notes = trim($notes);

    if ($packageName === '') {
        throw new RuntimeException('Rollback package name is required.');
    }

    if (mb_strlen($packageName) > 255) {
        throw new RuntimeException('Rollback package name is too long.');
    }

    if ($packageSha256 !== '' && !preg_match('/^[a-f0-9]{64}$/', $packageSha256)) {
        throw new RuntimeException('Rollback package SHA-256 must contain exactly 64 hexadecimal characters.');
    }

    $stmt = $pdo->prepare("UPDATE deployment_releases SET rollback_package_name=?,rollback_package_sha256=?,rollback_notes=?,updated_by_admin_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?");
    $stmt->execute([
        $packageName,
        $packageSha256 !== '' ? $packageSha256 : null,
        $notes !== '' ? $notes : null,
        $adminId > 0 ? $adminId : null,
        $releaseId,
    ]);

    tsDeployEvent(
        $pdo,
        $releaseId,
        'rollback_package_registered',
        'recorded',
        $adminId,
        [
            'package_name' => $packageName,
            'package_sha256' => $packageSha256 !== '' ? $packageSha256 : null,
            'notes' => $notes !== '' ? $notes : null,
        ]
    );
}


function tsDeployRecordRollback(PDO $pdo, int $releaseId, string $notes, int $adminId): void
{
    $release = tsDeployRelease($pdo, $releaseId);
    if (!$release) {
        throw new RuntimeException('Deployment release was not found.');
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire($pdo, $adminId, 'manage_access', 'record_manual_deployment_rollback', 'deployment_release', $releaseId);
    }

    $notes = trim($notes);
    if ($notes === '') {
        throw new RuntimeException('Enter rollback notes confirming what was manually restored.');
    }

    $stmt = $pdo->prepare("UPDATE deployment_releases SET status='rolled_back',rolled_back_at=NOW(),rollback_notes=?,updated_by_admin_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?");
    $stmt->execute([
        $notes,
        $adminId > 0 ? $adminId : null,
        $releaseId,
    ]);

    tsDeployEvent(
        $pdo,
        $releaseId,
        'manual_rollback_recorded',
        'recorded',
        $adminId,
        ['notes' => $notes]
    );
}


function tsDeployDatabaseStats(PDO $pdo): array
{
    $tableCount = 0;
    $estimatedBytes = 0;

    try {
        $stmt = $pdo->query("SELECT COUNT(*),COALESCE(SUM(data_length+index_length),0) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE'");
        $row = $stmt->fetch(PDO::FETCH_NUM) ?: [0,0];
        $tableCount = (int)$row[0];
        $estimatedBytes = (int)$row[1];
    } catch (Throwable $e) {
    }

    return [
        'table_count' => $tableCount,
        'estimated_bytes' => $estimatedBytes,
        'temp_directory' => sys_get_temp_dir(),
        'temp_writable' => is_writable(sys_get_temp_dir()),
    ];
}


function tsDeploySqlValue(PDO $pdo, mixed $value): string
{
    if ($value === null) {
        return 'NULL';
    }

    if (is_bool($value)) {
        return $value ? '1' : '0';
    }

    $string = (string)$value;

    /* Preserve binary/control-heavy values exactly. */
    if (!mb_check_encoding($string, 'UTF-8') || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $string)) {
        return '0x' . bin2hex($string);
    }

    $quoted = $pdo->quote($string);
    if ($quoted === false) {
        return "'" . str_replace("'", "''", $string) . "'";
    }

    return $quoted;
}


function tsDeployGenerateDatabaseBackup(PDO $pdo): array
{
    $tmp = tempnam(sys_get_temp_dir(), 'travscope-db-');
    if ($tmp === false) {
        throw new RuntimeException('Unable to create temporary backup file.');
    }

    $handle = fopen($tmp, 'wb');
    if ($handle === false) {
        @unlink($tmp);
        throw new RuntimeException('Unable to open temporary backup file.');
    }

    $tableCount = 0;
    $rowCount = 0;

    try {
        fwrite($handle, "-- TRAVSCOPE APPLICATION DATABASE TABLE BACKUP\n");
        fwrite($handle, "-- Generated: " . date('c') . "\n");
        fwrite($handle, "-- IMPORTANT: Review this file before any manual restore.\n");
        fwrite($handle, "-- No automatic restore is provided by TRAVSCOPE Deployment Safety Center.\n\n");
        fwrite($handle, "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n");

        $tables = [];
        $stmt = $pdo->query("SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE' ORDER BY table_name");
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) ?: [] as $table) {
            if (preg_match('/^[A-Za-z0-9_]+$/', (string)$table)) {
                $tables[] = (string)$table;
            }
        }

        foreach ($tables as $table) {
            $tableCount++;
            $quotedTable = '`' . str_replace('`', '``', $table) . '`';

            $createStmt = $pdo->query("SHOW CREATE TABLE {$quotedTable}");
            $createRow = $createStmt->fetch(PDO::FETCH_NUM) ?: [];
            $createSql = (string)($createRow[1] ?? '');

            fwrite($handle, "-- ------------------------------------------------------------\n");
            fwrite($handle, "-- Table: {$table}\n");
            fwrite($handle, "-- ------------------------------------------------------------\n");
            fwrite($handle, "DROP TABLE IF EXISTS {$quotedTable};\n");
            fwrite($handle, $createSql . ";\n\n");

            $dataStmt = $pdo->query("SELECT * FROM {$quotedTable}");
            $columns = [];
            $batch = [];

            while ($row = $dataStmt->fetch(PDO::FETCH_ASSOC)) {
                if (!$columns) {
                    $columns = array_keys($row);
                }

                $values = [];
                foreach ($columns as $column) {
                    $values[] = tsDeploySqlValue($pdo, $row[$column] ?? null);
                }

                $batch[] = '(' . implode(',', $values) . ')';
                $rowCount++;

                if (count($batch) >= 100) {
                    $columnSql = implode(',', array_map(static fn($c) => '`' . str_replace('`','``',(string)$c) . '`', $columns));
                    fwrite($handle, "INSERT INTO {$quotedTable} ({$columnSql}) VALUES\n" . implode(",\n", $batch) . ";\n");
                    $batch = [];
                }
            }

            if ($batch) {
                $columnSql = implode(',', array_map(static fn($c) => '`' . str_replace('`','``',(string)$c) . '`', $columns));
                fwrite($handle, "INSERT INTO {$quotedTable} ({$columnSql}) VALUES\n" . implode(",\n", $batch) . ";\n");
            }

            fwrite($handle, "\n");
        }

        fwrite($handle, "SET FOREIGN_KEY_CHECKS=1;\n");
        fclose($handle);

        return [
            'path' => $tmp,
            'table_count' => $tableCount,
            'row_count' => $rowCount,
            'size' => (int)filesize($tmp),
            'sha256' => hash_file('sha256', $tmp),
        ];

    } catch (Throwable $e) {
        fclose($handle);
        @unlink($tmp);
        throw $e;
    }
}


function tsDeployGenerateSettingsBackup(PDO $pdo): array
{
    $tmp = tempnam(sys_get_temp_dir(), 'travscope-settings-');
    if ($tmp === false) {
        throw new RuntimeException('Unable to create temporary settings backup file.');
    }

    $settings = [];

    if (tsDeploySettingsReady($pdo)) {
        $stmt = $pdo->query("SELECT setting_key,setting_value,updated_at FROM settings ORDER BY setting_key");
        $settings = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    $payload = [
        'schema' => 1,
        'generated_at' => date('c'),
        'scope' => 'TRAVSCOPE settings table only',
        'warning' => 'This file is a configuration reference backup. Review values before any manual restore.',
        'settings' => $settings,
    ];

    $json = json_encode(
        $payload,
        JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );

    if (!is_string($json) || file_put_contents($tmp, $json . "\n") === false) {
        @unlink($tmp);
        throw new RuntimeException('Unable to write settings backup.');
    }

    return [
        'path' => $tmp,
        'table_count' => tsDeploySettingsReady($pdo) ? 1 : 0,
        'row_count' => count($settings),
        'size' => (int)filesize($tmp),
        'sha256' => hash_file('sha256', $tmp),
    ];
}


function tsDeployRegisterBackup(
    PDO $pdo,
    ?int $releaseId,
    string $type,
    string $filename,
    array $meta,
    int $adminId
): int {
    if (!tsDeployReady($pdo)) {
        throw new RuntimeException('Deployment Safety SQL is not installed.');
    }

    $stmt = $pdo->prepare("INSERT INTO deployment_backup_registry (release_id,backup_type,filename,sha256,file_size,table_count,row_count,generated_by_admin_id) VALUES (?,?,?,?,?,?,?,?)");
    $stmt->execute([
        $releaseId && $releaseId > 0 ? $releaseId : null,
        $type,
        mb_substr($filename, 0, 255),
        (string)$meta['sha256'],
        (int)$meta['size'],
        (int)$meta['table_count'],
        (int)$meta['row_count'],
        $adminId > 0 ? $adminId : null,
    ]);

    $backupId = (int)$pdo->lastInsertId();

    if ($releaseId && $releaseId > 0) {
        tsDeployEvent(
            $pdo,
            $releaseId,
            'backup_generated',
            'recorded',
            $adminId,
            [
                'backup_id' => $backupId,
                'backup_type' => $type,
                'filename' => $filename,
                'sha256' => (string)$meta['sha256'],
                'file_size' => (int)$meta['size'],
                'table_count' => (int)$meta['table_count'],
                'row_count' => (int)$meta['row_count'],
            ]
        );
    }

    return $backupId;
}
