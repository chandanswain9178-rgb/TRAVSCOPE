<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
require_once __DIR__.'/supplier-functions.php';
require_once __DIR__.'/supplier-document-functions.php';
require_once __DIR__.'/supplier-contract-rate-functions.php';
if(is_file(__DIR__.'/supplier-rate-book-functions.php'))require_once __DIR__.'/supplier-rate-book-functions.php';
if(is_file(__DIR__.'/package-supplier-functions.php'))require_once __DIR__.'/package-supplier-functions.php';
if(is_file(__DIR__.'/crm-functions.php'))require_once __DIR__.'/crm-functions.php';
if(empty($_SESSION['admin_id'])){header('Location: '.BASE_URL.'login.php');exit;}
$adminId=(int)$_SESSION['admin_id'];$st=$pdo->prepare("SELECT id,name,status FROM admins WHERE id=? LIMIT 1");$st->execute([$adminId]);$admin=$st->fetch(PDO::FETCH_ASSOC);if(!$admin||($admin['status']??'')!=='active'){header('Location: '.BASE_URL.'login.php');exit;}
function tcrE($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
try{if(function_exists('tsSupplierDocumentEnsureSchema'))tsSupplierDocumentEnsureSchema($pdo);}catch(Throwable $ignored){}
$tripId=max(0,(int)($_GET['trip_id']??$_POST['trip_id']??0));$trip=tsSCRTrip($pdo,$tripId);if(!$trip){http_response_code(404);exit('Trip not found.');}
if(empty($_SESSION['trip_rate_csrf']))$_SESSION['trip_rate_csrf']=bin2hex(random_bytes(32));$csrf=(string)$_SESSION['trip_rate_csrf'];$error='';
$tripPackageId=max(0,(int)($trip['package_id']??0));
$requestedPackageId=max(0,(int)($_GET['package_id']??$_POST['package_id']??0));
$packageId=$requestedPackageId>0?$requestedPackageId:$tripPackageId;
$package=null;$packageOptions=[];
if($packageId>0 && function_exists('tsPSOPackage')){
    $package=tsPSOPackage($pdo,$packageId);
    if(!$package)throw new RuntimeException('The selected Package Master was not found. Return to the quotation and choose the package again.');
    if(function_exists('tsPSOReady')&&tsPSOReady($pdo))$packageOptions=tsPSOOptions($pdo,$packageId);
}
$scope=(string)($_GET['scope']??$_POST['scope']??'');
if(!in_array($scope,['package','all'],true))$scope=$packageId>0?'package':'all';
$allGroups=tsSCRActiveGroupsForTrip($pdo,$trip);
$linkedMap=[];$linkedGroups=[];$packageGroups=[];

/*
 * V24.18 — QUOTATION PACKAGE LOCK
 * --------------------------------
 * Supplier costing must never show a tariff belonging to another package.
 * Match the quotation's selected Package Master to supplier rate groups by:
 *   1) exact source itinerary id, or
 *   2) exact supplier package code (SVHC-101, SVHC-116, etc.), or
 *   3) exact package-supplier option itinerary/code.
 * Destination/date alone is NOT enough because many supplier packages share
 * the same destination and season.
 */
$packageItineraryIds=[];$packageCodes=[];
if($package){
    $sourceItineraryId=max(0,(int)($package['source_itinerary_id']??0));
    if($sourceItineraryId>0)$packageItineraryIds[$sourceItineraryId]=true;
    $sourceCode=trim((string)($package['source_supplier_package_code']??''));
    if($sourceCode!=='' && function_exists('tsSCRNormalizePackageCode')){
        $normalized=tsSCRNormalizePackageCode($sourceCode);
        if($normalized!=='')$packageCodes[$normalized]=true;
    }elseif($sourceCode!==''){
        $packageCodes[strtoupper(preg_replace('/\s+/','',$sourceCode))]=true;
    }
}
foreach($packageOptions as $o){
    $iid=max(0,(int)($o['itinerary_id']??0));
    if($iid>0)$packageItineraryIds[$iid]=true;
    $code=trim((string)($o['supplier_package_code']??''));
    if($code!=='' && function_exists('tsSCRNormalizePackageCode')){
        $normalized=tsSCRNormalizePackageCode($code);
        if($normalized!=='')$packageCodes[$normalized]=true;
    }elseif($code!==''){
        $packageCodes[strtoupper(preg_replace('/\s+/','',$code))]=true;
    }
}

if($packageId>0){
    foreach($allGroups as $g){
        $groupItineraryId=max(0,(int)($g['itinerary_id']??0));
        $groupCode=trim((string)($g['supplier_package_code']??''));
        if($groupCode==='' && function_exists('tsRBPackageCode'))$groupCode=tsRBPackageCode((string)($g['itinerary_source_heading']??''));
        if(function_exists('tsSCRNormalizePackageCode'))$groupCodeKey=tsSCRNormalizePackageCode($groupCode!==''?$groupCode:(string)($g['itinerary_source_heading']??''));
        else $groupCodeKey=strtoupper(preg_replace('/\s+/','',$groupCode));
        $exactMatch=($groupItineraryId>0 && isset($packageItineraryIds[$groupItineraryId])) || ($groupCodeKey!=='' && isset($packageCodes[$groupCodeKey]));
        if(!$exactMatch)continue;

        if(function_exists('tsPSOGroupLink')){
            $link=tsPSOGroupLink($pdo,$packageId,$g);
            if($link){$g['_package_link']=$link;$linkedMap[(int)$g['id']]=$link;$linkedGroups[]=$g;}
        }
        $packageGroups[]=$g;
    }
}

/* A selected Package Master is always locked to its exact supplier package.
 * 'all' is retained only for custom quotations where no Package Master exists. */
$groups=$packageId>0?$packageGroups:$allGroups;
$scope=$packageId>0?'package':'all';
if($groups){usort($groups,static function($a,$b){$ap=(int)($a['_package_link']['is_primary']??0);$bp=(int)($b['_package_link']['is_primary']??0);if($ap!==$bp)return $bp<=>$ap;$al=isset($a['_package_link'])?1:0;$bl=isset($b['_package_link'])?1:0;if($al!==$bl)return $bl<=>$al;return strcasecmp((string)($a['supplier_name']??''),(string)($b['supplier_name']??''));});}
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  if(!hash_equals($csrf,(string)($_POST['csrf']??'')))throw new RuntimeException('Security verification failed.');
  $groupId=max(0,(int)($_POST['group_id']??0));$allowed=array_map(static fn($g)=>(int)$g['id'],$groups);if(!in_array($groupId,$allowed,true))throw new RuntimeException('The selected supplier rate is outside the current package/scope. Refresh and select again.');
  $base=(int)($_POST['base_pax']??0);$extra=max(0,(int)($_POST['extra_bed_count']??0));$wob=max(0,(int)($_POST['child_without_bed_count']??0));$cwb=max(0,(int)($_POST['child_with_bed_count']??0));
  if($base<=0)throw new RuntimeException('Select an exact published supplier PAX slab before applying the supplier cost.');
  $selectedGroup=null;foreach($groups as $candidate){if((int)$candidate['id']===$groupId){$selectedGroup=$candidate;break;}}
  $tripAdults=max(0,(int)($trip['adults']??0));
  if($tripAdults>0 && $base!==$tripAdults && empty($_POST['confirm_pax_override']))throw new RuntimeException('The selected supplier PAX slab ('.$base.') differs from the Trip adult count ('.$tripAdults.'). Tick the confirmation only if the supplier has confirmed that this published slab applies to this Trip.');
  if($selectedGroup){
      if($wob>0 && $selectedGroup['child_without_bed_rate']===null)throw new RuntimeException('Child Without Bed cost is not supplied for this supplier category. Obtain/record an approved child rate or leave this count at 0; do not estimate it.');
      if($extra>0 && $selectedGroup['extra_bed_rate']===null)throw new RuntimeException('Extra Bed cost is not supplied for this supplier category. Obtain/record an approved rate or leave this count at 0.');
  }
  if($packageId>0 && $tripPackageId!==$packageId){$pdo->prepare('UPDATE trips SET package_id=?,updated_at=NOW() WHERE id=?')->execute([$packageId,$tripId]);$trip['package_id']=$packageId;$tripPackageId=$packageId;}
  $r=tsSCRApplyToTrip($pdo,$tripId,$groupId,$base,$extra,$wob,$cwb,$adminId);$_SESSION['admin_crm_success']='Supplier Contract Rate applied for '.(string)($package['title']??'selected package').': '.number_format((float)$r['calculation']['supplier_total_amount'],2).' '.(string)$r['rate']['currency'].' supplier cost. Customer quotation can now use the Trip Cost Sheet.';header('Location: admin-crm.php?lead='.(int)$trip['enquiry_id'].'&trip='.$tripId.'#crm-package');exit;
 }catch(Throwable $e){$error=$e->getMessage();}
}
$paxByGroup=[];$paxOptionsByGroup=[];foreach($groups as $g){$st=$pdo->prepare("SELECT pax_min,pax_max,source_pax_label,rate_per_person FROM supplier_contract_pax_rates WHERE rate_group_id=? AND status='active' ORDER BY pax_min,pax_max");$st->execute([(int)$g['id']]);$rows=$st->fetchAll(PDO::FETCH_ASSOC)?:[];$paxByGroup[(int)$g['id']]=$rows;$opts=[];foreach($rows as $pr){$mn=max(1,(int)($pr['pax_min']??0));$mx=max($mn,(int)($pr['pax_max']??$mn));if($mx-$mn>20)$mx=$mn;for($n=$mn;$n<=$mx;$n++){$opts[$n]=['value'=>$n,'label'=>(string)($pr['source_pax_label']?:($mn===$mx?str_pad((string)$n,2,'0',STR_PAD_LEFT).' PAX':$mn.'-'.$mx.' PAX')),'rate'=>(float)$pr['rate_per_person']];}}ksort($opts);$paxOptionsByGroup[(int)$g['id']]=array_values($opts);} 
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Supplier Rate Selection | TRAVSCOPE</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260921-v20"><style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Inter,Arial,sans-serif}.top{padding:18px 24px;background:#07192d;color:#fff;display:flex;justify-content:space-between;align-items:center}.page{max-width:1320px;margin:auto;padding:24px}.head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.btn{display:inline-flex;gap:7px;align-items:center;text-decoration:none;border:0;border-radius:9px;padding:9px 12px;font-weight:800;cursor:pointer}.blue{background:#0b74ff;color:#fff}.soft{background:#eaf2ff;color:#155daf}.good{background:#087f5b;color:#fff}.panel,.card{background:#fff;border:1px solid #e1e7ef;border-radius:14px;padding:16px;margin-top:15px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.card.linked{border-color:#9bc7ff;box-shadow:0 0 0 2px #e3f0ff}.card.primary{border-color:#62c89e;box-shadow:0 0 0 2px #e7f9f1}.card h3{margin:0 0 5px}.muted{color:#718096;font-size:12px}.pills{display:flex;gap:6px;flex-wrap:wrap;margin:10px 0}.pill{background:#edf4ff;border-radius:999px;padding:5px 8px;font-size:10px;font-weight:800}.pill.linked{background:#e8f2ff;color:#0b5fc7}.pill.primary{background:#e9fbf3;color:#087f5b}.pill.warn{background:#fff4df;color:#9a5a00}.form{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;align-items:end}.field label{font-size:9px;font-weight:900;text-transform:uppercase;color:#718096;display:block;margin-bottom:4px}.input{width:100%;border:1px solid #d7e0ea;border-radius:8px;padding:8px}.err{background:#fff0f0;color:#a23030;padding:12px;border-radius:10px;margin-top:14px}.warn{background:#fff7ed;color:#92400e;padding:12px;border-radius:10px}.flow{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.step{padding:12px;border-radius:12px;border:1px solid #dce8f5}.step:nth-child(1){background:#eef7ff}.step:nth-child(2){background:#f7f0ff}.step:nth-child(3){background:#fff7e9}.step:nth-child(4){background:#edfbf4}.step b{display:block;margin-bottom:4px}.scope{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.pkg-options{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.pkg-option{padding:5px 8px;border-radius:999px;background:#f2f6fb;font-size:10px}.pkg-option.primary{background:#e9fbf3;color:#087f5b}.statline{display:flex;gap:16px;flex-wrap:wrap;margin-top:9px}.statline span{font-size:11px;color:#65768b}.trip-pax{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.trip-pax span{padding:6px 9px;border-radius:999px;background:#eef4fb;font-size:11px;font-weight:800;color:#34465a}.mismatch{margin-top:9px;padding:9px 10px;border-radius:9px;background:#fff3f3;color:#a23030;font-size:11px;font-weight:700}.okmatch{margin-top:9px;padding:9px 10px;border-radius:9px;background:#edf9f3;color:#087f5b;font-size:11px;font-weight:700}.confirmline{display:flex;align-items:flex-start;gap:6px;margin-top:7px;font-size:10px;color:#7a4b00}@media(max-width:900px){.grid,.form,.flow{grid-template-columns:1fr}.page{padding:14px}.head{display:block}}
</style>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head><body><div class="top"><strong>TRAVSCOPE · Supplier Rate Selection</strong><span><?=tcrE($admin['name'])?></span></div><div class="page">
<div class="head"><div><h1 style="margin:0">Choose Supplier Cost For Quotation</h1><div class="muted"><?=tcrE($trip['trip_code'])?> · <?=tcrE($trip['customer_name'])?> · <?=tcrE($trip['trip_title'])?> · <?=tcrE($trip['travel_start_date']?:$trip['enquiry_travel_date']?:'Travel date not set')?></div></div><div style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn soft" href="admin-crm.php?lead=<?=(int)$trip['enquiry_id']?>&trip=<?=$tripId?>#crm-package"><i class="fa-solid fa-arrow-left"></i> Back to Quotation</a><?php if($packageId>0):?><a class="btn soft" href="admin-package-suppliers.php?package_id=<?=$packageId?>"><i class="fa-solid fa-diagram-project"></i> Package Supplier Map</a><?php endif;?><a class="btn soft" href="admin-trip-commercial-hub.php?trip_id=<?=$tripId?>"><i class="fa-solid fa-comments-dollar"></i> Commercial Hub</a></div></div>
<?php if($error):?><div class="err"><?=tcrE($error)?></div><?php endif;?><div class="trip-pax"><span>Trip Adults: <?=max(0,(int)($trip['adults']??0))?></span><span>Trip Children: <?=max(0,(int)($trip['children']??0))?></span><span>Total Travellers: <?=max(0,(int)($trip['adults']??0))+max(0,(int)($trip['children']??0))?></span></div>
<div class="panel"><div class="flow"><div class="step"><b>1 · Selected Package</b><span class="muted"><?=tcrE($package['title']??'No Package Master selected')?></span><?php if($package && !empty($package['source_supplier_package_code'])):?><div class="pill primary" style="display:inline-block;margin-top:6px"><?=tcrE($package['source_supplier_package_code'])?></div><?php endif;?></div><div class="step"><b>2 · Exact Supplier Package</b><span class="muted">Only rates belonging to this Package Master are allowed.</span></div><div class="step"><b>3 · Seasonal Rate</b><span class="muted">Travel date + exact PAX + hotel category.</span></div><div class="step"><b>4 · Apply Cost</b><span class="muted">Locked into Trip Cost Sheet; markup stays separate.</span></div></div>
<?php if($packageId>0):?><div class="okmatch" style="margin-top:12px"><i class="fa-solid fa-lock"></i> <strong>Package Lock Active:</strong> Unrelated supplier packages are hidden. Only tariffs matching <strong><?=tcrE($package['title']??'the selected Package Master')?></strong><?php if(!empty($package['source_supplier_package_code'])):?> (<?=tcrE($package['source_supplier_package_code'])?>)<?php endif;?> can be applied to this quotation.</div><?php if($packageOptions):?><div class="pkg-options"><?php foreach($packageOptions as $o):?><span class="pkg-option <?=!empty($o['is_primary'])?'primary':''?>"><?=!empty($o['is_primary'])?'PRIMARY · ':''?><?=tcrE($o['company_name'])?> · <?=tcrE($o['supplier_package_code']?:$o['supplier_package_title'])?></span><?php endforeach;?></div><?php endif;?><?php else:?><div class="warn" style="margin-top:10px"><strong>No Package Master is selected.</strong> This is a custom quotation, so destination/date-valid supplier rates may be shown. Return to the quotation and select a Package Master to lock rates to one exact package.</div><?php endif;?></div>
<div class="panel"><strong>Selection rule</strong><div class="muted" style="margin-top:6px"><?php if($packageId>0):?>Only ACTIVE tariffs for the exact selected supplier package and travel season appear. Rates from other package codes are blocked to prevent calculation mismatch.<?php else:?>Only ACTIVE supplier seasonal tariffs valid for this Trip appear. Regular/High/Peak overlap is resolved by rate priority. Missing PAX values are never estimated.<?php endif;?></div><div class="statline"><span><strong><?=count($groups)?></strong> exact rate categories shown</span><span><strong><?=count($packageOptions)?></strong> package supplier links</span><span>Scope: <strong><?=strtoupper(tcrE($scope))?></strong></span></div></div>
<?php if(!$groups):?><div class="panel warn"><strong>No exact supplier tariff was found for this selected Package Master.</strong><br><?php if($packageId>0):?>TRAVSCOPE intentionally did not show rates from other supplier packages because that could create a quotation cost mismatch. Check the supplier package code/link, travel-date validity, season, status and exact PAX slab. <?php if($packageId>0):?><a href="admin-package-suppliers.php?package_id=<?=$packageId?>">Open Package Supplier Map</a><?php endif;?> or use Supplier/RFQ to obtain the correct rate.<?php else:?>Check travel dates, destination, season validity/priority and exact PAX slab.<?php endif;?></div><?php else:?><div class="grid"><?php foreach($groups as $g):$link=$g['_package_link']??null;$isPrimary=!empty($link['is_primary']);?><div class="card <?=$isPrimary?'primary':($link?'linked':'')?>"><h3><?=tcrE($g['supplier_name'])?> · <?=tcrE($g['supplier_category'])?></h3><div class="muted"><?php $pkgCode=(string)($g['supplier_package_code']??'');if($pkgCode===''&&function_exists('tsRBPackageCode'))$pkgCode=tsRBPackageCode((string)($g['itinerary_source_heading']??''));?><?= $pkgCode!==''?'<strong>'.tcrE($pkgCode).'</strong> · ':'' ?><?=tcrE($g['itinerary_title'])?> · <?=tcrE($g['meal_plan'])?> · <?=tcrE($g['contract_code'])?> · <a href="admin-supplier-package-manual.php?id=<?=(int)$g['contract_id']?>&version_id=<?=(int)$g['contract_version_id']?>" target="_blank">Supplier Package</a></div><div class="pills"><?php if($link):?><span class="pill <?=$isPrimary?'primary':'linked'?>"><?=$isPrimary?'PRIMARY PACKAGE SUPPLIER':'PACKAGE-LINKED'?></span><?php endif;?><span class="pill"><?=tcrE((string)($g['season_name']??'Regular Season'))?></span><span class="pill"><?=tcrE((string)($g['version_valid_from']??''))?> → <?=tcrE((string)($g['version_valid_to']??''))?></span><span class="pill">Priority <?=(int)($g['rate_priority']??10)?></span><?php foreach($paxByGroup[(int)$g['id']]??[] as $p):?><span class="pill"><?=tcrE($p['source_pax_label'])?>: <?=tcrE($g['currency'])?> <?=number_format((float)$p['rate_per_person'],2)?></span><?php endforeach;?></div><div class="muted">Extra Bed: <?=($g['extra_bed_rate']!==null?number_format((float)$g['extra_bed_rate'],2):'Not supplied')?> · Child W/O Bed: <?=($g['child_without_bed_rate']!==null?number_format((float)$g['child_without_bed_rate'],2):'Not supplied')?> · Child With Bed: <?=tcrE(str_replace('_',' ',(string)$g['child_with_bed_basis']))?></div><?php $tripAdults=max(0,(int)($trip['adults']??0));$tripChildren=max(0,(int)($trip['children']??0));$paxOpts=$paxOptionsByGroup[(int)$g['id']]??[];$exactAdultMatch=false;foreach($paxOpts as $po){if((int)$po['value']===$tripAdults){$exactAdultMatch=true;break;}} ?>
<?php if(!$exactAdultMatch):?><div class="mismatch"><i class="fa-solid fa-triangle-exclamation"></i> Trip has <?=$tripAdults?> adult<?=($tripAdults===1?'':'s')?>, but this supplier has no exact <?=$tripAdults?>-PAX slab. Available published slabs: <?=tcrE(implode(', ',array_map(static fn($x)=>(string)$x['value'],$paxOpts)))?>. Do not estimate a missing slab.</div><?php else:?><div class="okmatch"><i class="fa-solid fa-circle-check"></i> Exact <?=$tripAdults?>-PAX supplier slab is available for the Trip adult count.</div><?php endif;?>
<?php if($tripChildren>0 && $g['child_without_bed_rate']===null):?><div class="mismatch"><i class="fa-solid fa-child-reaching"></i> Trip includes <?=$tripChildren?> child<?=($tripChildren===1?'':'ren')?>, but Child W/O Bed rate is not supplied for this category. It is not auto-added.</div><?php endif;?>
<form method="post" class="form" style="margin-top:10px"><input type="hidden" name="csrf" value="<?=tcrE($csrf)?>"><input type="hidden" name="trip_id" value="<?=$tripId?>"><input type="hidden" name="package_id" value="<?=$packageId?>"><input type="hidden" name="scope" value="<?=tcrE($scope)?>"><input type="hidden" name="group_id" value="<?=(int)$g['id']?>"><div class="field"><label>Exact Supplier PAX Slab</label><select class="input" name="base_pax" required><option value="">Select exact slab</option><?php foreach($paxOpts as $po):?><option value="<?=(int)$po['value']?>" <?=((int)$po['value']===$tripAdults?'selected':'')?>><?=tcrE($po['label'])?> · <?=tcrE((string)$g['currency'])?> <?=number_format((float)$po['rate'],2)?>/PP</option><?php endforeach;?></select><?php if(!$exactAdultMatch):?><label class="confirmline"><input type="checkbox" name="confirm_pax_override" value="1"> I confirm the supplier has approved the selected published slab for this Trip even though it differs from the adult count.</label><?php endif;?></div><div class="field"><label>Extra Bed</label><input class="input" type="number" min="0" name="extra_bed_count" value="0" <?=($g['extra_bed_rate']===null?'disabled title="Supplier rate not supplied"':'')?>></div><div class="field"><label>Child W/O Bed</label><input class="input" type="number" min="0" name="child_without_bed_count" value="0" <?=($g['child_without_bed_rate']===null?'disabled title="Supplier rate not supplied"':'')?>></div><div class="field"><label>Child With Bed</label><input class="input" type="number" min="0" name="child_with_bed_count" value="0" <?=((string)$g['child_with_bed_basis']==='not_available'?'disabled title="Supplier rate not supplied"':'')?>></div><div><button class="btn good" onclick="return confirm('Apply this exact published supplier tariff to the Trip Cost Sheet?');"><i class="fa-solid fa-check"></i> Apply Supplier Cost</button></div></form></div><?php endforeach;?></div><?php endif;?></div>
<script src="assets/travscope-pro-admin.js?v=20260921-v20" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script></body></html>
