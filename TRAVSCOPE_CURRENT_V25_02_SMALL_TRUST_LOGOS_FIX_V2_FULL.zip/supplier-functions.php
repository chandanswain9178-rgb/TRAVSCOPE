<?php
declare(strict_types=1);
if (is_file(__DIR__ . '/location-master-functions.php')) { require_once __DIR__ . '/location-master-functions.php'; }

/**
 * TRAVSCOPE Supplier Phase 2 shared helpers.
 * Requires config.php to be loaded before this file.
 */

function tsSupE(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function tsSupplierRequestCode(PDO $pdo): string {
    $year = date('Y');
    $next = (int)$pdo->query("SELECT COALESCE(MAX(id),0)+1 FROM supplier_requests")->fetchColumn();
    return 'SR-' . $year . '-' . str_pad((string)$next, 6, '0', STR_PAD_LEFT);
}

function tsSupplierRequestGroupCode(PDO $pdo): string {
    $year = date('Y');
    $next = (int)$pdo->query("SELECT COALESCE(MAX(id),0)+1 FROM supplier_requests")->fetchColumn();
    return 'SRG-' . $year . '-' . str_pad((string)$next, 6, '0', STR_PAD_LEFT);
}

function tsSupplierEvent(PDO $pdo, int $requestId, string $type, ?int $adminId, string $description = '', string $channel = ''): void {
    $stmt = $pdo->prepare("
        INSERT INTO supplier_request_events
        (supplier_request_id,event_type,channel,description,admin_id)
        VALUES (?,?,?,?,?)
    ");
    $stmt->execute([$requestId,$type,$channel ?: null,$description ?: null,$adminId ?: null]);
}



function tsSupplierPortalToken(PDO $pdo, int $requestId): string {
    $raw = bin2hex(random_bytes(32));
    $hash = hash('sha256', $raw);
    $stmt = $pdo->prepare("INSERT INTO supplier_request_portal_tokens (supplier_request_id,token_hash,expires_at) VALUES (?,?,DATE_ADD(NOW(),INTERVAL 30 DAY))");
    $stmt->execute([$requestId,$hash]);
    return $raw;
}

function tsSupplierPortalUrl(PDO $pdo, int $requestId): string {
    $raw = tsSupplierPortalToken($pdo,$requestId);
    return BASE_URL.'supplier-response.php?token='.rawurlencode($raw);
}

function tsSupplierMessage(PDO $pdo, int $requestId, string $senderType, ?int $adminId, string $message, string $channel='portal', ?string $attachmentPath=null, ?string $originalFilename=null): void {
    $stmt=$pdo->prepare("INSERT INTO supplier_request_messages (supplier_request_id,sender_type,admin_id,channel,message,attachment_path,original_filename) VALUES (?,?,?,?,?,?,?)");
    $stmt->execute([$requestId,$senderType,$adminId?:null,$channel,$message,$attachmentPath,$originalFilename]);
}


function tsSupplierQuoteModeColumnExists(PDO $pdo): bool {
    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = DATABASE()
              AND table_name = 'supplier_quotes'
              AND column_name = 'costing_mode'
        ");
        $stmt->execute();
        return (int)$stmt->fetchColumn() > 0;
    } catch (Throwable $e) {
        return false;
    }
}

function tsSupplierQuoteMode(string $value): string {
    $value = strtolower(trim($value));
    return in_array($value, ['complete_package','service_wise','hybrid'], true)
        ? $value
        : 'complete_package';
}

function tsSupplierQuoteModeLabel(string $mode): string {
    return match (tsSupplierQuoteMode($mode)) {
        'service_wise' => 'Service-wise Costing',
        'hybrid' => 'Hybrid Costing',
        default => 'Complete Package Rate',
    };
}

function tsSupplierQuoteModeFromRow(array $quote, string $requestType = ''): string {
    $stored = trim((string)($quote['costing_mode'] ?? ''));
    if (in_array($stored, ['complete_package','service_wise','hybrid'], true)) {
        return $stored;
    }

    return $requestType === 'service_quote'
        ? 'service_wise'
        : 'complete_package';
}

function tsSupplierQuoteBuildCosting(
    string $mode,
    float $packageBaseAmount,
    float $supplierTaxAmount,
    float $otherCharges,
    array $itemTypes,
    array $itemDescriptions,
    array $itemCosts
): array {
    $mode = tsSupplierQuoteMode($mode);
    $packageBaseAmount = max(0, $packageBaseAmount);
    $supplierTaxAmount = max(0, $supplierTaxAmount);
    $otherCharges = max(0, $otherCharges);

    $allowedTypes = [
        'hotel','transport','sightseeing','visa','insurance',
        'flight','transfer','activity','upgrade','other'
    ];

    $items = [];
    $serviceTotal = 0.0;
    $rowCount = max(count($itemTypes), count($itemDescriptions), count($itemCosts));

    for ($i = 0; $i < $rowCount; $i++) {
        $rawCost = trim((string)($itemCosts[$i] ?? ''));
        $description = trim((string)($itemDescriptions[$i] ?? ''));
        $type = strtolower(trim((string)($itemTypes[$i] ?? 'other')));

        if ($rawCost === '' && $description === '') {
            continue;
        }

        $cost = $rawCost === '' ? 0.0 : max(0, (float)$rawCost);

        if ($cost <= 0) {
            if ($description !== '') {
                throw new RuntimeException(
                    'Enter a positive cost for service item "' . $description . '".'
                );
            }
            continue;
        }

        if ($description === '') {
            throw new RuntimeException('Enter a description for every service cost item.');
        }

        if (!in_array($type, $allowedTypes, true)) {
            $type = 'other';
        }

        $items[] = [
            'item_type' => $type,
            'description' => $description,
            'cost' => $cost,
            'is_upgrade' => $type === 'upgrade' ? 1 : 0,
        ];

        $serviceTotal += $cost;
    }

    if ($mode === 'complete_package') {
        if ($packageBaseAmount <= 0) {
            throw new RuntimeException('Enter the supplier complete package NET amount.');
        }

        $items = [[
            'item_type' => 'package',
            'description' => 'Complete supplier package rate',
            'cost' => $packageBaseAmount,
            'is_upgrade' => 0,
        ]];

        $netAmount = $packageBaseAmount;
    } elseif ($mode === 'service_wise') {
        if ($serviceTotal <= 0) {
            throw new RuntimeException(
                'Add at least one service cost item for service-wise costing.'
            );
        }

        $netAmount = $serviceTotal;
    } else {
        if ($packageBaseAmount <= 0) {
            throw new RuntimeException(
                'Enter the base package NET amount for hybrid costing.'
            );
        }

        if ($serviceTotal <= 0) {
            throw new RuntimeException(
                'Add at least one additional service cost item for hybrid costing.'
            );
        }

        array_unshift($items, [
            'item_type' => 'package',
            'description' => 'Base supplier package rate',
            'cost' => $packageBaseAmount,
            'is_upgrade' => 0,
        ]);

        $netAmount = $packageBaseAmount + $serviceTotal;
    }

    $total = $netAmount + $otherCharges + $supplierTaxAmount;

    return [
        'mode' => $mode,
        'net_amount' => $netAmount,
        'tax_amount' => $supplierTaxAmount,
        'upgrade_amount' => $otherCharges,
        'total_supplier_cost' => $total,
        'items' => $items,
    ];
}

function tsSupplierPrimaryContact(PDO $pdo, int $supplierId): ?array {
    $stmt = $pdo->prepare("
        SELECT *
        FROM supplier_contacts
        WHERE supplier_id=? AND status='active'
        ORDER BY is_primary DESC,
                 CASE department WHEN 'Sales' THEN 1 WHEN 'Operations' THEN 2 ELSE 3 END,
                 id ASC
        LIMIT 1
    ");
    $stmt->execute([$supplierId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsSupplierEmail(PDO $pdo, array $request, array $supplier, ?array $contact): array {
    $email = trim((string)($contact['email'] ?? ''));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['ok'=>false,'message'=>'Supplier email is not available.'];
    }
    if (!class_exists('\\PHPMailer\\PHPMailer\\PHPMailer')) {
        return ['ok'=>false,'message'=>'PHPMailer is unavailable.'];
    }

    try {
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        if (defined('SMTP_ENABLED') && SMTP_ENABLED) {
            $mail->isSMTP();
            $mail->Host = defined('SMTP_HOST') ? SMTP_HOST : 'smtp.gmail.com';
            $mail->SMTPAuth = defined('SMTP_AUTH') ? SMTP_AUTH : true;
            $mail->Username = defined('SMTP_USERNAME') ? SMTP_USERNAME : '';
            $mail->Password = defined('SMTP_PASSWORD') ? SMTP_PASSWORD : '';
            $mail->SMTPSecure = defined('SMTP_ENCRYPTION') ? SMTP_ENCRYPTION : 'tls';
            $mail->Port = defined('SMTP_PORT') ? SMTP_PORT : 587;
        }
        $from = defined('MAIL_FROM_ADDRESS') ? MAIL_FROM_ADDRESS : (defined('SMTP_USERNAME') ? SMTP_USERNAME : '');
        $fromName = defined('MAIL_FROM_NAME') ? MAIL_FROM_NAME : 'TRAVSCOPE.COM';
        $mail->setFrom($from, $fromName);
        $mail->addAddress($email, (string)($contact['contact_name'] ?? $supplier['company_name']));
        if (defined('MAIL_REPLY_TO') && filter_var(MAIL_REPLY_TO, FILTER_VALIDATE_EMAIL)) {
            $mail->addReplyTo(MAIL_REPLY_TO, $fromName);
        }
        $mail->isHTML(true);
        $threadTag = '[TRAVSCOPE-SR-' . (string)$request['request_code'] . ']';
        $rawSubject = (string)$request['subject'];
        $mail->Subject = stripos($rawSubject, $threadTag) !== false ? $rawSubject : ($threadTag . ' ' . $rawSubject);

        $body = nl2br(tsSupE((string)$request['requirement_text']));
        if (!empty($request['special_requirements'])) {
            $body .= '<br><br><strong>Special Requirements / Upgrades</strong><br>' .
                     nl2br(tsSupE((string)$request['special_requirements']));
        }
        $body .= '<br><br><strong>Supplier Request Reference:</strong> ' . tsSupE((string)$request['request_code']);
        $body .= '<br><br>Please quote your best current NET rate, availability, payment terms, cancellation terms and validity.';
        $portalUrl = tsSupplierPortalUrl($pdo,(int)$request['id']);
        $body .= '<br><br><a href="'.tsSupE($portalUrl).'" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;padding:12px 18px;border-radius:8px;font-weight:bold">View Request & Reply</a>';
        $body .= '<br><br>You can use the secure link above to chat with TRAVSCOPE, attach documents and submit/revise your quotation.';
        $body .= '<br><br>Regards,<br>TRAVSCOPE.COM';

        $mail->Body = '<div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.65;color:#172033">' . $body . '</div>';
        $mail->AltBody = (string)$request['requirement_text'] . "\n\nSpecial Requirements:\n" .
                         (string)($request['special_requirements'] ?? '') .
                         "\n\nSupplier Request Reference: " . (string)$request['request_code'];
        $mail->send();
        return ['ok'=>true,'message'=>'Supplier request email sent.'];
    } catch (Throwable $e) {
        error_log('TRAVSCOPE supplier request email error: ' . $e->getMessage());
        return ['ok'=>false,'message'=>'Unable to send supplier email. Check SMTP configuration.'];
    }
}


function tsSupplierCustomEmail(array $supplier, ?array $contact, string $subject, string $message): array {
    $email = trim((string)($contact['email'] ?? ''));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return ['ok'=>false,'message'=>'Supplier email is not available.'];
    if (!class_exists('\PHPMailer\PHPMailer\PHPMailer')) return ['ok'=>false,'message'=>'PHPMailer is unavailable.'];
    try {
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        if (defined('SMTP_ENABLED') && SMTP_ENABLED) {
            $mail->isSMTP();
            $mail->Host = defined('SMTP_HOST') ? SMTP_HOST : 'smtp.gmail.com';
            $mail->SMTPAuth = defined('SMTP_AUTH') ? SMTP_AUTH : true;
            $mail->Username = defined('SMTP_USERNAME') ? SMTP_USERNAME : '';
            $mail->Password = defined('SMTP_PASSWORD') ? SMTP_PASSWORD : '';
            $mail->SMTPSecure = defined('SMTP_ENCRYPTION') ? SMTP_ENCRYPTION : 'tls';
            $mail->Port = defined('SMTP_PORT') ? SMTP_PORT : 587;
        }
        $from = defined('MAIL_FROM_ADDRESS') ? MAIL_FROM_ADDRESS : (defined('SMTP_USERNAME') ? SMTP_USERNAME : '');
        $fromName = defined('MAIL_FROM_NAME') ? MAIL_FROM_NAME : 'TRAVSCOPE.COM';
        $mail->setFrom($from, $fromName);
        $mail->addAddress($email, (string)($contact['contact_name'] ?? $supplier['company_name'] ?? 'Supplier'));
        if (defined('MAIL_REPLY_TO') && filter_var(MAIL_REPLY_TO, FILTER_VALIDATE_EMAIL)) $mail->addReplyTo(MAIL_REPLY_TO, $fromName);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = '<div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.65;color:#172033">'.nl2br(tsSupE($message)).'</div>';
        $mail->AltBody = $message;
        $mail->send();
        return ['ok'=>true,'message'=>'Supplier email sent.'];
    } catch (Throwable $e) {
        error_log('TRAVSCOPE supplier message email error: '.$e->getMessage());
        return ['ok'=>false,'message'=>'Unable to send supplier email. Check SMTP configuration.'];
    }
}

function tsSupplierWhatsappNumber(?string $number): string {
    $digits = preg_replace('/\D+/', '', (string)$number);
    if (!$digits) return '';
    if (strlen($digits) === 10) $digits = '91' . $digits;
    return $digits;
}

function tsSupplierUploadQuote(array $file): array {
    if (empty($file) || !isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['path'=>null,'name'=>null];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Supplier quote upload failed.');
    if ((int)$file['size'] > 10 * 1024 * 1024) throw new RuntimeException('Supplier attachment must be smaller than 10 MB.');
    if (!is_uploaded_file((string)$file['tmp_name'])) throw new RuntimeException('Invalid uploaded file.');

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string)$finfo->file((string)$file['tmp_name']);
    $allowed = [
        'application/pdf'=>'pdf',
        'application/vnd.ms-excel'=>'xls',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'=>'xlsx',
        'application/msword'=>'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'=>'docx',
        'image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'
    ];
    if (!isset($allowed[$mime])) throw new RuntimeException('Allowed: PDF, Excel, Word, JPG, PNG or WEBP.');

    $dir = __DIR__ . '/uploads/supplier-quotes/';
    if (!is_dir($dir) && !mkdir($dir,0755,true) && !is_dir($dir)) {
        throw new RuntimeException('Unable to create supplier quote upload directory.');
    }
    $original = basename((string)($file['name'] ?? 'supplier-quote'));
    $safe = preg_replace('/[^A-Za-z0-9._-]+/', '-', pathinfo($original, PATHINFO_FILENAME));
    $safe = trim((string)$safe, '-_.') ?: 'supplier-quote';
    $name = substr($safe,0,80) . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(4)) . '.' . $allowed[$mime];
    $dest = $dir . $name;
    if (!move_uploaded_file((string)$file['tmp_name'],$dest)) throw new RuntimeException('Unable to save supplier quote.');
    return ['path'=>'uploads/supplier-quotes/'.$name,'name'=>$original];
}


/*
|--------------------------------------------------------------------------
| SUPPLIER CONTRACT + PREDEFINED RATE ENGINE
|--------------------------------------------------------------------------
|
| Contract rates are suggestions until an Admin explicitly clicks
| "Use in Cost Sheet". This preserves human commercial verification.
|
*/

function tsSupplierTableExists(PDO $pdo, string $table): bool {
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
        $stmt->execute([$table]);
        if ((int)$stmt->fetchColumn() > 0) return true;
    } catch (Throwable $e) {}
    try { $pdo->query('SELECT 1 FROM `'.$table.'` LIMIT 0'); return true; } catch (Throwable $e) {}
    try { $q=$pdo->quote($table); if ($q!==false) { $stmt=$pdo->query('SHOW TABLES LIKE '.$q); return $stmt?(bool)$stmt->fetchColumn():false; } } catch (Throwable $e) {}
    return false;
}

function tsSupplierColumnExists(PDO $pdo, string $table, string $column): bool {
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) return false;
    try {
        $stmt=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?");
        $stmt->execute([$table,$column]);
        if((int)$stmt->fetchColumn()>0)return true;
    } catch (Throwable $e) {}
    try {
        $pdo->query('SELECT `'.$column.'` FROM `'.$table.'` LIMIT 0');
        return true;
    } catch (Throwable $e) {}
    return false;
}

/**
 * Self-healing Supplier Contract / Predefined Rate schema.
 * Additive only: existing tables and rows are never dropped, truncated or replaced.
 * No hard foreign keys are created so this remains compatible with MilesWeb/MariaDB.
 */
function tsSupplierEnsureRateEngineSchema(PDO $pdo): array {
    $result = [
        'supplier_contracts' => false,
        'supplier_rate_cards' => false,
        'supplier_rate_items' => false,
        'changed' => false,
    ];

    if (!tsSupplierTableExists($pdo, 'suppliers')) {
        throw new RuntimeException('Supplier Master table is missing. The Supplier module must exist before contracts can be created.');
    }

    if (!tsSupplierTableExists($pdo, 'supplier_contracts')) {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS supplier_contracts (
              id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
              supplier_id BIGINT UNSIGNED NOT NULL,
              contract_code VARCHAR(60) NOT NULL,
              contract_name VARCHAR(190) NOT NULL,
              currency VARCHAR(10) NOT NULL DEFAULT 'INR',
              valid_from DATE NOT NULL,
              valid_to DATE NOT NULL,
              status ENUM('draft','active','inactive','expired') NOT NULL DEFAULT 'draft',
              source_reference VARCHAR(190) DEFAULT NULL,
              supplier_tax_percent DECIMAL(7,4) NOT NULL DEFAULT 0.0000,
              tax_included TINYINT(1) NOT NULL DEFAULT 0,
              payment_terms TEXT DEFAULT NULL,
              cancellation_terms TEXT DEFAULT NULL,
              notes TEXT DEFAULT NULL,
              created_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
              updated_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
              created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
              updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              PRIMARY KEY (id),
              UNIQUE KEY uq_supplier_contract_code (contract_code),
              KEY idx_supplier_contract_supplier (supplier_id,status,valid_from,valid_to)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $result['changed'] = true;
    }

    if (!tsSupplierTableExists($pdo, 'supplier_rate_cards')) {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS supplier_rate_cards (
              id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
              contract_id BIGINT UNSIGNED NOT NULL,
              supplier_id BIGINT UNSIGNED NOT NULL,
              destination_id BIGINT UNSIGNED DEFAULT NULL,
              location_city VARCHAR(120) DEFAULT NULL,
              service_type VARCHAR(40) NOT NULL,
              rate_title VARCHAR(190) NOT NULL,
              valid_from DATE DEFAULT NULL,
              valid_to DATE DEFAULT NULL,
              pax_min INT UNSIGNED DEFAULT NULL,
              pax_max INT UNSIGNED DEFAULT NULL,
              hotel_category VARCHAR(40) DEFAULT NULL,
              property_name VARCHAR(190) DEFAULT NULL,
              room_type VARCHAR(120) DEFAULT NULL,
              meal_plan VARCHAR(120) DEFAULT NULL,
              vehicle_type VARCHAR(120) DEFAULT NULL,
              nationality_rule VARCHAR(120) DEFAULT NULL,
              blackout_dates TEXT DEFAULT NULL,
              availability_status ENUM('available','on_request','closed') NOT NULL DEFAULT 'available',
              confirmation_required TINYINT(1) NOT NULL DEFAULT 0,
              notes TEXT DEFAULT NULL,
              status ENUM('active','inactive') NOT NULL DEFAULT 'active',
              created_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
              updated_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
              created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
              updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              PRIMARY KEY (id),
              KEY idx_rate_card_contract (contract_id,status),
              KEY idx_rate_card_supplier_service (supplier_id,service_type,destination_id,status),
              KEY idx_rate_card_location (supplier_id,destination_id,location_city,service_type,status),
              KEY idx_rate_card_validity (valid_from,valid_to)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $result['changed'] = true;
    }

    if (!tsSupplierTableExists($pdo, 'supplier_rate_items')) {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS supplier_rate_items (
              id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
              rate_card_id BIGINT UNSIGNED NOT NULL,
              rate_name VARCHAR(190) NOT NULL,
              unit_basis VARCHAR(40) NOT NULL DEFAULT 'flat',
              amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
              tax_percent DECIMAL(7,4) DEFAULT NULL,
              tax_included TINYINT(1) NOT NULL DEFAULT 0,
              supplement_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
              child_age_from INT UNSIGNED DEFAULT NULL,
              child_age_to INT UNSIGNED DEFAULT NULL,
              min_quantity DECIMAL(10,2) DEFAULT NULL,
              max_quantity DECIMAL(10,2) DEFAULT NULL,
              status ENUM('active','inactive') NOT NULL DEFAULT 'active',
              sort_order INT NOT NULL DEFAULT 0,
              created_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
              updated_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
              created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
              updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              PRIMARY KEY (id),
              KEY idx_rate_item_card (rate_card_id,status,sort_order)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $result['changed'] = true;
    }

    // V8: destination/location-aware supplier hotel and vehicle rates.
    // Existing sites receive the new location_city column automatically.
    if (tsSupplierTableExists($pdo,'supplier_rate_cards') && !tsSupplierColumnExists($pdo,'supplier_rate_cards','location_city')) {
        try {
            $pdo->exec("ALTER TABLE supplier_rate_cards ADD COLUMN location_city VARCHAR(120) DEFAULT NULL AFTER destination_id");
            $result['changed']=true;
        } catch (Throwable $ignored) {}
    }
    if (tsSupplierTableExists($pdo,'supplier_rate_cards')) {
        try {
            $stmt=$pdo->prepare("SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='supplier_rate_cards' AND index_name='idx_rate_card_location'");
            $stmt->execute();
            if((int)$stmt->fetchColumn()===0){
                $pdo->exec("ALTER TABLE supplier_rate_cards ADD KEY idx_rate_card_location (supplier_id,destination_id,location_city,service_type,status)");
                $result['changed']=true;
            }
        } catch (Throwable $ignored) {}
    }

    // V9 child-city/location master. This is additive and keeps the parent destination
    // (for example Tamil Nadu) separate from the operational city (for example Chennai).
    if (function_exists('tsLocationEnsureSchema')) {
        try {
            $locSchema=tsLocationEnsureSchema($pdo);
            if (!empty($locSchema['changed'])) $result['changed']=true;
        } catch (Throwable $ignored) {}
    }

    $result['supplier_contracts'] = tsSupplierTableExists($pdo, 'supplier_contracts');
    $result['supplier_rate_cards'] = tsSupplierTableExists($pdo, 'supplier_rate_cards');
    $result['supplier_rate_items'] = tsSupplierTableExists($pdo, 'supplier_rate_items');
    return $result;
}

function tsSupplierRateEngineReady(PDO $pdo): bool {
    try {
        tsSupplierEnsureRateEngineSchema($pdo);
    } catch (Throwable $ignored) {
        // Readiness below still reports the true state.
    }

    return
        tsSupplierTableExists($pdo, 'supplier_contracts')
        && tsSupplierTableExists($pdo, 'supplier_rate_cards')
        && tsSupplierTableExists($pdo, 'supplier_rate_items');
}

function tsSupplierContractCode(PDO $pdo, int $supplierId): string {
    $year = date('Y');
    $stmt = $pdo->prepare("
        SELECT COALESCE(MAX(id),0)+1
        FROM supplier_contracts
        WHERE supplier_id = ?
    ");
    $stmt->execute([$supplierId]);
    $next = max(1, (int)$stmt->fetchColumn());

    return
        'SC-'
        . $year
        . '-'
        . str_pad((string)$supplierId, 4, '0', STR_PAD_LEFT)
        . '-'
        . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
}

function tsSupplierRateServiceTypes(): array {
    return [
        'hotel',
        'transport',
        'transfer',
        'activity',
        'sightseeing',
        'flight',
        'visa',
        'train',
        'cruise',
        'guide',
        'insurance',
        'meal',
        'other'
    ];
}

function tsSupplierRateServiceLabel(string $type): string {
    $labels = [
        'hotel' => 'Hotel',
        'transport' => 'Transport / Vehicle',
        'transfer' => 'Transfer',
        'activity' => 'Activity',
        'sightseeing' => 'Sightseeing',
        'flight' => 'Flight',
        'visa' => 'Visa',
        'train' => 'Train',
        'cruise' => 'Cruise',
        'guide' => 'Guide',
        'insurance' => 'Travel Insurance',
        'meal' => 'Meal / Supplement',
        'other' => 'Other Service',
    ];

    $type = strtolower(trim($type));
    return $labels[$type] ?? ucwords(str_replace('_', ' ', $type ?: 'Other'));
}

function tsSupplierRateUnitBases(): array {
    return [
        'flat' => 'Flat / Package Amount',
        'per_service' => 'Per Service / Unit',
        'per_person' => 'Per Person',
        'per_adult' => 'Per Adult',
        'per_child' => 'Per Child',
        'per_room_night' => 'Per Room / Night',
        'per_vehicle_day' => 'Per Vehicle / Day',
        'per_transfer' => 'Per Transfer',
        'per_night' => 'Per Night',
    ];
}

function tsSupplierFindContractRates(PDO $pdo, array $service): array {
    if (!tsSupplierRateEngineReady($pdo)) {
        return [];
    }

    $serviceType = strtolower(trim((string)($service['service_type'] ?? '')));
    if ($serviceType === '') {
        return [];
    }

    $destinationId = max(0, (int)($service['destination_id'] ?? 0));
    $serviceDate =
        trim(
            (string)(
                $service['service_date_from']
                ?? ''
            )
        );
    $pax =
        max(
            0,
            (int)($service['adults'] ?? 0)
            + (int)($service['children'] ?? 0)
        );

    $where = [
        "s.status = 'active'",
        "c.status = 'active'",
        "rc.status = 'active'",
        "ri.status = 'active'",
        "rc.availability_status <> 'closed'",
        "rc.service_type = ?"
    ];
    $params = [$serviceType];

    if ($destinationId > 0) {
        $where[] = "(rc.destination_id IS NULL OR rc.destination_id = ?)";
        $params[] = $destinationId;
    } else {
        $where[] = "rc.destination_id IS NULL";
    }

    if ($serviceDate !== '') {
        $where[] = "c.valid_from <= ?";
        $params[] = $serviceDate;
        $where[] = "c.valid_to >= ?";
        $params[] = $serviceDate;

        $where[] = "(rc.valid_from IS NULL OR rc.valid_from <= ?)";
        $params[] = $serviceDate;
        $where[] = "(rc.valid_to IS NULL OR rc.valid_to >= ?)";
        $params[] = $serviceDate;
    } else {
        $where[] = "c.valid_from <= CURDATE()";
        $where[] = "c.valid_to >= CURDATE()";
    }

    if ($pax > 0) {
        $where[] = "(rc.pax_min IS NULL OR rc.pax_min <= ?)";
        $params[] = $pax;
        $where[] = "(rc.pax_max IS NULL OR rc.pax_max >= ?)";
        $params[] = $pax;
    }

    $serviceQuantity = max(0.01, (float)($service['quantity'] ?? 1));

    $where[] = "(ri.min_quantity IS NULL OR ri.min_quantity <= ?)";
    $params[] = $serviceQuantity;
    $where[] = "(ri.max_quantity IS NULL OR ri.max_quantity >= ?)";
    $params[] = $serviceQuantity;

    $stmt = $pdo->prepare("
        SELECT
            ri.id AS rate_item_id,
            ri.rate_card_id,
            ri.rate_name,
            ri.unit_basis,
            ri.amount,
            ri.tax_percent AS item_tax_percent,
            ri.tax_included AS item_tax_included,
            ri.supplement_amount,
            ri.child_age_from,
            ri.child_age_to,
            ri.min_quantity,
            ri.max_quantity,

            rc.id AS rate_card_id_real,
            rc.service_type,
            rc.rate_title,
            rc.destination_id,
            rc.valid_from AS rate_valid_from,
            rc.valid_to AS rate_valid_to,
            rc.pax_min,
            rc.pax_max,
            rc.hotel_category,
            rc.property_name,
            rc.room_type,
            rc.meal_plan,
            rc.vehicle_type,
            rc.nationality_rule,
            rc.blackout_dates,
            rc.availability_status,
            rc.confirmation_required,
            rc.notes AS rate_notes,

            c.id AS contract_id,
            c.contract_code,
            c.contract_name,
            c.currency,
            c.valid_from AS contract_valid_from,
            c.valid_to AS contract_valid_to,
            c.source_reference,
            c.supplier_tax_percent,
            c.tax_included AS contract_tax_included,
            c.payment_terms,
            c.cancellation_terms,

            s.id AS supplier_id,
            s.company_name,
            s.priority,

            d.name AS destination_name,
            d.country AS destination_country

        FROM supplier_rate_items ri
        JOIN supplier_rate_cards rc
            ON rc.id = ri.rate_card_id
        JOIN supplier_contracts c
            ON c.id = rc.contract_id
        JOIN suppliers s
            ON s.id = c.supplier_id
        LEFT JOIN destinations d
            ON d.id = rc.destination_id
        WHERE
            " . implode("\n            AND ", $where) . "
        ORDER BY
            CASE s.priority
                WHEN 'preferred' THEN 1
                WHEN 'regular' THEN 2
                ELSE 3
            END,
            rc.confirmation_required ASC,
            ri.amount ASC,
            s.company_name ASC,
            c.contract_code ASC,
            rc.id ASC,
            ri.sort_order ASC,
            ri.id ASC
    ");
    $stmt->execute($params);

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    foreach ($rows as &$row) {
        $row['calculation'] =
            tsSupplierCalculateContractRate(
                $row,
                $service
            );
    }
    unset($row);

    return $rows;
}

function tsSupplierContractRateForService(
    PDO $pdo,
    int $rateItemId,
    array $service
): ?array {
    if ($rateItemId <= 0) {
        return null;
    }

    foreach (tsSupplierFindContractRates($pdo, $service) as $row) {
        if ((int)($row['rate_item_id'] ?? 0) === $rateItemId) {
            return $row;
        }
    }

    return null;
}

function tsSupplierCalculateContractRate(array $rate, array $service): array {
    $amount = max(0, (float)($rate['amount'] ?? 0));
    $basis = strtolower(trim((string)($rate['unit_basis'] ?? 'flat')));
    $quantity = max(0.01, (float)($service['quantity'] ?? 1));
    $adults = max(0, (int)($service['adults'] ?? 0));
    $children = max(0, (int)($service['children'] ?? 0));
    $pax = $adults + $children;

    $from = trim((string)($service['service_date_from'] ?? ''));
    $to = trim((string)($service['service_date_to'] ?? ''));

    $days = 1;
    $nights = 1;

    if ($from !== '' && $to !== '') {
        try {
            $start = new DateTimeImmutable($from);
            $end = new DateTimeImmutable($to);

            if ($end >= $start) {
                $diff = (int)$start->diff($end)->days;
                $days = max(1, $diff + 1);
                $nights = max(1, $diff);
            }
        } catch (Throwable $e) {
            $days = 1;
            $nights = 1;
        }
    }

    $units = 1.0;
    $formula = 'Flat amount';

    switch ($basis) {
        case 'per_service':
            $units = $quantity;
            $formula = 'Rate × service quantity';
            break;

        case 'per_person':
            $units = max(1, $pax);
            $formula = 'Rate × total travellers';
            break;

        case 'per_adult':
            $units = max(1, $adults);
            $formula = 'Rate × adults';
            break;

        case 'per_child':
            $units = max(1, $children);
            $formula = 'Rate × children';
            break;

        case 'per_room_night':
            $units = $quantity * $nights;
            $formula = 'Rate × rooms × nights';
            break;

        case 'per_vehicle_day':
            $units = $quantity * $days;
            $formula = 'Rate × vehicles × days';
            break;

        case 'per_transfer':
            $units = $quantity;
            $formula = 'Rate × transfers';
            break;

        case 'per_night':
            $units = $nights;
            $formula = 'Rate × nights';
            break;

        default:
            $units = 1.0;
            $formula = 'Flat amount';
            break;
    }

    $base = round($amount * $units, 2);

    $taxPercent =
        $rate['item_tax_percent'] !== null
            && $rate['item_tax_percent'] !== ''
                ? max(0, (float)$rate['item_tax_percent'])
                : max(0, (float)($rate['supplier_tax_percent'] ?? 0));

    $taxIncluded =
        !empty($rate['item_tax_included'])
        || (
            empty($rate['item_tax_percent'])
            && !empty($rate['contract_tax_included'])
        );

    $taxAmount =
        $taxIncluded
            ? 0.0
            : round($base * $taxPercent / 100, 2);

    $supplement =
        max(
            0,
            (float)($rate['supplement_amount'] ?? 0)
        );

    return [
        'units' => $units,
        'formula' => $formula,
        'base_cost' => $base,
        'tax_percent' => $taxPercent,
        'tax_included' => $taxIncluded ? 1 : 0,
        'tax_amount' => $taxAmount,
        'supplement_amount' => $supplement,
        'supplier_total' => round($base + $taxAmount + $supplement, 2),
        'days' => $days,
        'nights' => $nights,
    ];
}

function tsSupplierEnsureTripCostSheet(
    PDO $pdo,
    int $tripId,
    int $enquiryId,
    int $adminId,
    string $currency
): array {
    if (
        !tsSupplierTableExists($pdo, 'cost_sheets')
        || !tsSupplierTableExists($pdo, 'cost_sheet_items')
    ) {
        throw new RuntimeException(
            'Trip Cost Sheet is not installed yet.'
        );
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM cost_sheets
        WHERE trip_id = ?
          AND status = 'active'
        ORDER BY version_number DESC, id DESC
        LIMIT 1
    ");
    $stmt->execute([$tripId]);
    $sheet = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

    $currency = strtoupper(trim($currency));
    if ($currency === '') {
        $currency = 'INR';
    }

    if (!$sheet) {
        $stmt = $pdo->prepare("
            INSERT INTO cost_sheets
            (
                trip_id,
                enquiry_id,
                version_number,
                status,
                currency,
                created_by_admin_id
            )
            VALUES (?, ?, 1, 'active', ?, ?)
        ");
        $stmt->execute([
            $tripId,
            $enquiryId,
            $currency,
            $adminId > 0 ? $adminId : null
        ]);

        $stmt = $pdo->prepare("
            SELECT *
            FROM cost_sheets
            WHERE id = ?
            LIMIT 1
        ");
        $stmt->execute([(int)$pdo->lastInsertId()]);
        $sheet = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    if (!$sheet) {
        throw new RuntimeException(
            'Unable to prepare the Trip Cost Sheet.'
        );
    }

    $existingTotal =
        max(
            0,
            (float)($sheet['travscope_cost_total'] ?? 0)
        );
    $sheetCurrency =
        strtoupper(
            trim(
                (string)($sheet['currency'] ?? 'INR')
            )
        );

    if (
        $existingTotal > 0
        && $sheetCurrency !== ''
        && $sheetCurrency !== $currency
    ) {
        throw new RuntimeException(
            'This Cost Sheet is already in '
            . $sheetCurrency
            . '. Contract rate '
            . $currency
            . ' cannot be mixed until FX conversion is configured.'
        );
    }

    if (
        $existingTotal <= 0
        && $sheetCurrency !== $currency
    ) {
        $pdo->prepare("
            UPDATE cost_sheets
            SET currency = ?
            WHERE id = ?
        ")->execute([
            $currency,
            (int)$sheet['id']
        ]);

        $sheet['currency'] = $currency;
    }

    return $sheet;
}

function tsSupplierRecalculateTripCostSheet(PDO $pdo, int $sheetId): void {
    $stmt = $pdo->prepare("
        SELECT
            COALESCE(
                SUM(
                    CASE
                        WHEN source_type IN ('supplier_quote','contract_rate')
                        THEN line_cost
                        ELSE 0
                    END
                ),
                0
            ) AS supplier_total,
            COALESCE(
                SUM(
                    CASE
                        WHEN source_type NOT IN ('supplier_quote','contract_rate')
                        THEN line_cost
                        ELSE 0
                    END
                ),
                0
            ) AS direct_total
        FROM cost_sheet_items
        WHERE cost_sheet_id = ?
    ");
    $stmt->execute([$sheetId]);
    $totals = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

    $supplier =
        max(
            0,
            (float)($totals['supplier_total'] ?? 0)
        );
    $direct =
        max(
            0,
            (float)($totals['direct_total'] ?? 0)
        );

    $pdo->prepare("
        UPDATE cost_sheets
        SET
            supplier_cost_total = ?,
            direct_cost_total = ?,
            travscope_cost_total = ?,
            updated_at = NOW()
        WHERE id = ?
    ")->execute([
        $supplier,
        $direct,
        $supplier + $direct,
        $sheetId
    ]);
}

function tsSupplierApplyContractRate(
    PDO $pdo,
    int $rateItemId,
    array $service,
    int $adminId
): array {
    $tripId = max(0, (int)($service['trip_id'] ?? 0));
    $enquiryId = max(0, (int)($service['enquiry_id'] ?? 0));
    $serviceId = max(0, (int)($service['id'] ?? 0));

    if ($tripId <= 0 || $enquiryId <= 0 || $serviceId <= 0) {
        throw new RuntimeException(
            'This service is not linked to a valid Trip.'
        );
    }

    $rate =
        tsSupplierContractRateForService(
            $pdo,
            $rateItemId,
            $service
        );

    if (!$rate) {
        throw new RuntimeException(
            'This contract rate is no longer applicable to the selected Trip service.'
        );
    }

    $calc = (array)($rate['calculation'] ?? []);
    $supplierTotal =
        max(
            0,
            (float)($calc['supplier_total'] ?? 0)
        );

    if ($supplierTotal <= 0) {
        throw new RuntimeException(
            'The selected contract rate calculates to zero.'
        );
    }

    $sheet =
        tsSupplierEnsureTripCostSheet(
            $pdo,
            $tripId,
            $enquiryId,
            $adminId,
            (string)($rate['currency'] ?? 'INR')
        );

    $sheetId = (int)$sheet['id'];

    $pdo->beginTransaction();

    try {
        /*
         * One authoritative source per exact service:
         * Applying a contract rate replaces any previously imported Supplier Quote
         * or Contract Rate for the same service requirement.
         */
        if (tsSupplierTableExists($pdo, 'cost_sheet_rate_sources')) {
            $stmt = $pdo->prepare("
                DELETE FROM cost_sheet_rate_sources
                WHERE cost_sheet_item_id IN (
                    SELECT id
                    FROM cost_sheet_items
                    WHERE cost_sheet_id = ?
                      AND service_requirement_id = ?
                      AND source_type IN ('supplier_quote','contract_rate')
                )
            ");
            $stmt->execute([
                $sheetId,
                $serviceId
            ]);
        }

        $stmt = $pdo->prepare("
            DELETE FROM cost_sheet_items
            WHERE cost_sheet_id = ?
              AND service_requirement_id = ?
              AND source_type IN ('supplier_quote','contract_rate')
        ");
        $stmt->execute([
            $sheetId,
            $serviceId
        ]);

        $sortStmt = $pdo->prepare("
            SELECT COALESCE(MAX(sort_order),0) + 10
            FROM cost_sheet_items
            WHERE cost_sheet_id = ?
        ");
        $sortStmt->execute([$sheetId]);
        $sort = (int)$sortStmt->fetchColumn();

        $insert = $pdo->prepare("
            INSERT INTO cost_sheet_items
            (
                cost_sheet_id,
                service_requirement_id,
                supplier_id,
                source_type,
                item_type,
                description,
                quantity,
                unit_cost,
                line_cost,
                sort_order,
                created_by_admin_id
            )
            VALUES (?, ?, ?, 'contract_rate', ?, ?, ?, ?, ?, ?, ?)
        ");

        $description =
            (string)$rate['company_name']
            . ' · '
            . (string)$rate['contract_code']
            . ' · '
            . (string)$rate['rate_title']
            . ' — '
            . (string)$rate['rate_name'];

        $insert->execute([
            $sheetId,
            $serviceId,
            (int)$rate['supplier_id'],
            (string)$service['service_type'],
            $description,
            max(0.01, (float)($calc['units'] ?? 1)),
            max(0, (float)$rate['amount']),
            max(0, (float)($calc['base_cost'] ?? 0)),
            $sort,
            $adminId > 0 ? $adminId : null
        ]);

        $baseItemId = (int)$pdo->lastInsertId();

        if (
            $baseItemId > 0
            && tsSupplierTableExists($pdo, 'cost_sheet_rate_sources')
        ) {
            $pdo->prepare("
                INSERT INTO cost_sheet_rate_sources
                (
                    cost_sheet_item_id,
                    supplier_contract_id,
                    supplier_rate_card_id,
                    supplier_rate_item_id
                )
                VALUES (?, ?, ?, ?)
            ")->execute([
                $baseItemId,
                (int)$rate['contract_id'],
                (int)$rate['rate_card_id_real'],
                (int)$rate['rate_item_id']
            ]);
        }

        $sort += 10;

        $taxAmount =
            max(
                0,
                (float)($calc['tax_amount'] ?? 0)
            );

        if ($taxAmount > 0) {
            $insert->execute([
                $sheetId,
                $serviceId,
                (int)$rate['supplier_id'],
                'supplier_tax',
                (string)$rate['company_name']
                    . ' · '
                    . (string)$rate['contract_code']
                    . ' — Supplier GST / Tax',
                1,
                $taxAmount,
                $taxAmount,
                $sort,
                $adminId > 0 ? $adminId : null
            ]);

            $taxItemId = (int)$pdo->lastInsertId();

            if (
                $taxItemId > 0
                && tsSupplierTableExists($pdo, 'cost_sheet_rate_sources')
            ) {
                $pdo->prepare("
                    INSERT INTO cost_sheet_rate_sources
                    (
                        cost_sheet_item_id,
                        supplier_contract_id,
                        supplier_rate_card_id,
                        supplier_rate_item_id
                    )
                    VALUES (?, ?, ?, ?)
                ")->execute([
                    $taxItemId,
                    (int)$rate['contract_id'],
                    (int)$rate['rate_card_id_real'],
                    (int)$rate['rate_item_id']
                ]);
            }

            $sort += 10;
        }

        $supplement =
            max(
                0,
                (float)($calc['supplement_amount'] ?? 0)
            );

        if ($supplement > 0) {
            $insert->execute([
                $sheetId,
                $serviceId,
                (int)$rate['supplier_id'],
                'other',
                (string)$rate['company_name']
                    . ' · '
                    . (string)$rate['contract_code']
                    . ' — Contract Supplement',
                1,
                $supplement,
                $supplement,
                $sort,
                $adminId > 0 ? $adminId : null
            ]);

            $otherItemId = (int)$pdo->lastInsertId();

            if (
                $otherItemId > 0
                && tsSupplierTableExists($pdo, 'cost_sheet_rate_sources')
            ) {
                $pdo->prepare("
                    INSERT INTO cost_sheet_rate_sources
                    (
                        cost_sheet_item_id,
                        supplier_contract_id,
                        supplier_rate_card_id,
                        supplier_rate_item_id
                    )
                    VALUES (?, ?, ?, ?)
                ")->execute([
                    $otherItemId,
                    (int)$rate['contract_id'],
                    (int)$rate['rate_card_id_real'],
                    (int)$rate['rate_item_id']
                ]);
            }
        }

        $pdo->prepare("
            UPDATE trip_service_requirements
            SET status = 'selected',
                updated_at = NOW()
            WHERE id = ?
        ")->execute([$serviceId]);

        tsSupplierRecalculateTripCostSheet(
            $pdo,
            $sheetId
        );

        $pdo->commit();

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    return [
        'sheet_id' => $sheetId,
        'rate' => $rate,
        'calculation' => $calc
    ];
}


/*
|--------------------------------------------------------------------------
| POST-BOOKING SUPPLIER PROCUREMENT
|--------------------------------------------------------------------------
|
| PRE-BOOKING:
| supplier_requests / supplier_quotes
|
| POST-BOOKING:
| supplier_booking_orders / supplier_booking_order_items
|
| These states are intentionally separate.
|
*/

function tsSupplierBookingProcurementReady(PDO $pdo): bool {
    return
        tsSupplierTableExists($pdo, 'supplier_booking_orders')
        && tsSupplierTableExists($pdo, 'supplier_booking_order_items')
        && tsSupplierTableExists($pdo, 'supplier_booking_order_messages')
        && tsSupplierTableExists($pdo, 'supplier_booking_order_tokens')
        && tsSupplierTableExists($pdo, 'booking_service_snapshots');
}

function tsSupplierBookingOrderCode(PDO $pdo): string {
    $year = date('Y');
    $next =
        (int)$pdo->query("
            SELECT COALESCE(MAX(id),0)+1
            FROM supplier_booking_orders
        ")->fetchColumn();

    return
        'SPO-'
        . $year
        . '-'
        . str_pad(
            (string)$next,
            6,
            '0',
            STR_PAD_LEFT
        );
}

function tsSupplierBookingPortalToken(PDO $pdo, int $orderId): string {
    if ($orderId <= 0) {
        throw new RuntimeException('Invalid supplier booking order.');
    }

    $raw = bin2hex(random_bytes(32));
    $hash = hash('sha256', $raw);

    $stmt = $pdo->prepare("
        INSERT INTO supplier_booking_order_tokens
        (
            supplier_booking_order_id,
            token_hash,
            expires_at
        )
        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 45 DAY))
    ");
    $stmt->execute([
        $orderId,
        $hash
    ]);

    return $raw;
}

function tsSupplierBookingPortalUrl(PDO $pdo, int $orderId): string {
    $raw =
        tsSupplierBookingPortalToken(
            $pdo,
            $orderId
        );

    return
        BASE_URL
        . 'supplier-booking-response.php?token='
        . rawurlencode($raw);
}

function tsSupplierBookingMessage(
    PDO $pdo,
    int $orderId,
    string $senderType,
    ?int $adminId,
    string $message,
    string $channel = 'portal',
    ?string $attachmentPath = null,
    ?string $originalFilename = null
): void {
    $message = trim($message);

    if ($message === '') {
        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO supplier_booking_order_messages
        (
            supplier_booking_order_id,
            sender_type,
            admin_id,
            channel,
            message,
            attachment_path,
            original_filename
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $orderId,
        $senderType,
        $adminId ?: null,
        $channel,
        $message,
        $attachmentPath,
        $originalFilename
    ]);
}

function tsSupplierBookingUpload(array $file): array {
    if (
        empty($file)
        || !isset($file['error'])
        || $file['error'] === UPLOAD_ERR_NO_FILE
    ) {
        return [
            'path' => null,
            'name' => null
        ];
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException(
            'Supplier confirmation attachment upload failed.'
        );
    }

    if ((int)$file['size'] > 12 * 1024 * 1024) {
        throw new RuntimeException(
            'Supplier confirmation attachment must be smaller than 12 MB.'
        );
    }

    if (!is_uploaded_file((string)$file['tmp_name'])) {
        throw new RuntimeException(
            'Invalid supplier confirmation attachment.'
        );
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime =
        (string)$finfo->file(
            (string)$file['tmp_name']
        );

    $allowed = [
        'application/pdf' => 'pdf',
        'application/vnd.ms-excel' => 'xls',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
        'application/msword' => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($allowed[$mime])) {
        throw new RuntimeException(
            'Allowed confirmation attachments: PDF, Excel, Word, JPG, PNG or WEBP.'
        );
    }

    $dir =
        __DIR__
        . '/uploads/supplier-confirmations/';

    if (
        !is_dir($dir)
        && !mkdir($dir, 0755, true)
        && !is_dir($dir)
    ) {
        throw new RuntimeException(
            'Unable to create supplier confirmation upload directory.'
        );
    }

    $original =
        basename(
            (string)(
                $file['name']
                ?? 'supplier-confirmation'
            )
        );

    $safe =
        preg_replace(
            '/[^A-Za-z0-9._-]+/',
            '-',
            pathinfo(
                $original,
                PATHINFO_FILENAME
            )
        );

    $safe =
        trim(
            (string)$safe,
            '-_.'
        ) ?: 'supplier-confirmation';

    $name =
        substr($safe, 0, 80)
        . '-'
        . date('YmdHis')
        . '-'
        . bin2hex(random_bytes(4))
        . '.'
        . $allowed[$mime];

    $dest = $dir . $name;

    if (
        !move_uploaded_file(
            (string)$file['tmp_name'],
            $dest
        )
    ) {
        throw new RuntimeException(
            'Unable to save supplier confirmation attachment.'
        );
    }

    return [
        'path' =>
            'uploads/supplier-confirmations/'
            . $name,
        'name' => $original
    ];
}

/**
 * Store an invoice submitted through the supplier booking portal.
 *
 * Invoice files are deliberately kept separate from confirmation attachments
 * so finance documents can be backed up and access-controlled independently.
 */
function tsSupplierBookingInvoiceUpload(array $file): array {
    if (
        empty($file)
        || !isset($file['error'])
        || (int)$file['error'] === UPLOAD_ERR_NO_FILE
    ) {
        return ['path' => null, 'name' => null];
    }

    if ((int)$file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Supplier invoice attachment upload failed.');
    }

    if ((int)($file['size'] ?? 0) <= 0 || (int)$file['size'] > 12 * 1024 * 1024) {
        throw new RuntimeException('Supplier invoice attachment must be smaller than 12 MB.');
    }

    $temporaryPath = (string)($file['tmp_name'] ?? '');
    if ($temporaryPath === '' || !is_uploaded_file($temporaryPath)) {
        throw new RuntimeException('Invalid supplier invoice attachment.');
    }

    $mime = (string)(new finfo(FILEINFO_MIME_TYPE))->file($temporaryPath);
    $allowed = [
        'application/pdf' => 'pdf',
        'application/vnd.ms-excel' => 'xls',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
        'application/msword' => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];

    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Allowed invoice attachments: PDF, Excel, Word, JPG, PNG or WEBP.');
    }

    $directory = __DIR__ . '/uploads/supplier-invoices/';
    if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
        throw new RuntimeException('Unable to create supplier invoice upload directory.');
    }

    $original = basename((string)($file['name'] ?? 'supplier-invoice'));
    $base = preg_replace('/[^A-Za-z0-9._-]+/', '-', pathinfo($original, PATHINFO_FILENAME));
    $base = trim((string)$base, '-_.') ?: 'supplier-invoice';
    $storedName = substr($base, 0, 80)
        . '-' . date('YmdHis')
        . '-' . bin2hex(random_bytes(4))
        . '.' . $allowed[$mime];

    if (!move_uploaded_file($temporaryPath, $directory . $storedName)) {
        throw new RuntimeException('Unable to save supplier invoice attachment.');
    }

    return [
        'path' => 'uploads/supplier-invoices/' . $storedName,
        'name' => $original,
    ];
}

/**
 * Prepare draft post-booking supplier orders from frozen booking services.
 * Nothing is emailed here; an administrator still reviews and sends each order.
 */
function tsSupplierAutoPrepareBookingOrders(PDO $pdo, int $bookingId, int $adminId = 0): array {
    $result = ['orders_created' => 0, 'orders_updated' => 0, 'items_prepared' => 0];

    if ($bookingId <= 0 || !tsSupplierBookingProcurementReady($pdo)) {
        return $result;
    }

    $stmt = $pdo->prepare("SELECT * FROM booking_service_snapshots
        WHERE booking_id = ? AND source_supplier_id IS NOT NULL AND source_supplier_id > 0
        ORDER BY source_supplier_id, sort_order, id");
    $stmt->execute([$bookingId]);
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    if (!$services) {
        return $result;
    }

    $grouped = [];
    foreach ($services as $service) {
        $grouped[(int)$service['source_supplier_id']][] = $service;
    }

    $tripStmt = $pdo->prepare("SELECT trip_id FROM booking_trip_links WHERE booking_id = ? LIMIT 1");
    $tripStmt->execute([$bookingId]);
    $tripId = (int)($tripStmt->fetchColumn() ?: ($services[0]['trip_id'] ?? 0));

    $bookingStmt = $pdo->prepare("SELECT booking_number FROM bookings WHERE id = ? LIMIT 1");
    $bookingStmt->execute([$bookingId]);
    $bookingNumber = (string)($bookingStmt->fetchColumn() ?: $bookingId);

    $ownsTransaction = !$pdo->inTransaction();
    if ($ownsTransaction) {
        $pdo->beginTransaction();
    }

    try {
        foreach ($grouped as $supplierId => $supplierServices) {
            $supplierStmt = $pdo->prepare("SELECT id FROM suppliers WHERE id = ? AND status = 'active' LIMIT 1");
            $supplierStmt->execute([$supplierId]);
            if (!(int)$supplierStmt->fetchColumn()) {
                continue;
            }

            $contact = tsSupplierPrimaryContact($pdo, $supplierId);
            $orderStmt = $pdo->prepare("SELECT * FROM supplier_booking_orders
                WHERE booking_id = ? AND supplier_id = ? LIMIT 1");
            $orderStmt->execute([$bookingId, $supplierId]);
            $order = $orderStmt->fetch(PDO::FETCH_ASSOC) ?: null;

            if (!$order) {
                $orderCode = tsSupplierBookingOrderCode($pdo);
                $insertOrder = $pdo->prepare("INSERT INTO supplier_booking_orders
                    (order_code, booking_id, trip_id, supplier_id, supplier_contact_id,
                     subject, request_text, status, created_by_admin_id, updated_by_admin_id)
                    VALUES (?, ?, ?, ?, ?, ?, NULL, 'draft', ?, ?)");
                $insertOrder->execute([
                    $orderCode, $bookingId, $tripId, $supplierId,
                    $contact ? (int)$contact['id'] : null,
                    'Booking Confirmation ' . $orderCode . ' · ' . $bookingNumber,
                    $adminId ?: null, $adminId ?: null,
                ]);
                $orderId = (int)$pdo->lastInsertId();
                $result['orders_created']++;
            } else {
                $orderId = (int)$order['id'];
                $pdo->prepare("UPDATE supplier_booking_orders
                    SET supplier_contact_id = COALESCE(?, supplier_contact_id),
                        updated_by_admin_id = ?, updated_at = NOW()
                    WHERE id = ?")->execute([
                        $contact ? (int)$contact['id'] : null,
                        $adminId ?: null,
                        $orderId,
                    ]);
                $result['orders_updated']++;
            }

            $insertItem = $pdo->prepare("INSERT INTO supplier_booking_order_items
                (supplier_booking_order_id, booking_service_snapshot_id, service_type, title,
                 service_date_from, service_date_to, quantity, specifications,
                 agreed_supplier_cost, status, sort_order)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'confirmation_required', ?)
                ON DUPLICATE KEY UPDATE
                    service_type = VALUES(service_type), title = VALUES(title),
                    service_date_from = VALUES(service_date_from), service_date_to = VALUES(service_date_to),
                    quantity = VALUES(quantity), specifications = VALUES(specifications),
                    agreed_supplier_cost = VALUES(agreed_supplier_cost), sort_order = VALUES(sort_order),
                    updated_at = NOW()");

            foreach ($supplierServices as $service) {
                $insertItem->execute([
                    $orderId, (int)$service['id'], (string)$service['service_type'],
                    (string)$service['title'], $service['service_date_from'] ?: null,
                    $service['service_date_to'] ?: null, max(0.01, (float)$service['quantity']),
                    $service['specifications'] ?: null,
                    max(0, (float)$service['internal_supplier_cost']),
                    (int)$service['sort_order'],
                ]);
                $result['items_prepared']++;
            }
        }

        if ($ownsTransaction) {
            $pdo->commit();
        }
    } catch (Throwable $error) {
        if ($ownsTransaction && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $error;
    }

    return $result;
}

function tsSupplierBookingRefreshOrderStatus(
    PDO $pdo,
    int $orderId
): string {
    $stmt = $pdo->prepare("
        SELECT status, COUNT(*) AS total
        FROM supplier_booking_order_items
        WHERE supplier_booking_order_id = ?
        GROUP BY status
    ");
    $stmt->execute([$orderId]);

    $counts = [];
    $total = 0;

    foreach (
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        ?: []
        as $row
    ) {
        $counts[
            (string)$row['status']
        ] = (int)$row['total'];
        $total += (int)$row['total'];
    }

    $status = 'sent';

    if ($total <= 0) {
        $status = 'draft';
    } elseif (($counts['confirmed'] ?? 0) === $total) {
        $status = 'supplier_confirmed';
    } elseif (($counts['rejected'] ?? 0) === $total) {
        $status = 'rejected';
    } elseif (($counts['alternative_required'] ?? 0) > 0) {
        $status = 'alternative_required';
    } elseif (
        ($counts['confirmed'] ?? 0) > 0
        || ($counts['rejected'] ?? 0) > 0
    ) {
        $status = 'partially_confirmed';
    } elseif (
        ($counts['confirmation_requested'] ?? 0) > 0
        || ($counts['confirmation_required'] ?? 0) > 0
    ) {
        $status = 'sent';
    }

    $pdo->prepare("
        UPDATE supplier_booking_orders
        SET status = ?, updated_at = NOW()
        WHERE id = ?
    ")->execute([
        $status,
        $orderId
    ]);

    return $status;
}

function tsSupplierBookingSyncServiceStatuses(
    PDO $pdo,
    int $orderId
): void {
    $stmt = $pdo->prepare("
        SELECT
            booking_service_snapshot_id,
            status,
            supplier_confirmation_ref
        FROM supplier_booking_order_items
        WHERE supplier_booking_order_id = ?
    ");
    $stmt->execute([$orderId]);

    $update = $pdo->prepare("
        UPDATE booking_service_snapshots
        SET
            procurement_status = ?,
            supplier_confirmation_ref = ?,
            updated_at = NOW()
        WHERE id = ?
    ");

    foreach (
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        ?: []
        as $row
    ) {
        $update->execute([
            (string)$row['status'],
            trim(
                (string)(
                    $row['supplier_confirmation_ref']
                    ?? ''
                )
            ) ?: null,
            (int)$row['booking_service_snapshot_id']
        ]);
    }
}

function tsSupplierBookingEmail(
    PDO $pdo,
    array $order,
    array $supplier,
    ?array $contact,
    array $items
): array {
    $email =
        trim(
            (string)(
                $contact['email']
                ?? ''
            )
        );

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return [
            'ok' => false,
            'message' =>
                'Supplier email is not available.'
        ];
    }

    if (!class_exists('\\PHPMailer\\PHPMailer\\PHPMailer')) {
        return [
            'ok' => false,
            'message' => 'PHPMailer is unavailable.'
        ];
    }

    try {
        $mail =
            new \PHPMailer\PHPMailer\PHPMailer(true);

        if (
            defined('SMTP_ENABLED')
            && SMTP_ENABLED
        ) {
            $mail->isSMTP();
            $mail->Host =
                defined('SMTP_HOST')
                    ? SMTP_HOST
                    : 'smtp.gmail.com';
            $mail->SMTPAuth =
                defined('SMTP_AUTH')
                    ? SMTP_AUTH
                    : true;
            $mail->Username =
                defined('SMTP_USERNAME')
                    ? SMTP_USERNAME
                    : '';
            $mail->Password =
                defined('SMTP_PASSWORD')
                    ? SMTP_PASSWORD
                    : '';
            $mail->SMTPSecure =
                defined('SMTP_ENCRYPTION')
                    ? SMTP_ENCRYPTION
                    : 'tls';
            $mail->Port =
                defined('SMTP_PORT')
                    ? SMTP_PORT
                    : 587;
        }

        $from =
            defined('MAIL_FROM_ADDRESS')
                ? MAIL_FROM_ADDRESS
                : (
                    defined('SMTP_USERNAME')
                        ? SMTP_USERNAME
                        : ''
                );

        $fromName =
            defined('MAIL_FROM_NAME')
                ? MAIL_FROM_NAME
                : 'TRAVSCOPE.COM';

        $mail->setFrom(
            $from,
            $fromName
        );

        $mail->addAddress(
            $email,
            (string)(
                $contact['contact_name']
                ?? $supplier['company_name']
            )
        );

        if (
            defined('MAIL_REPLY_TO')
            && filter_var(
                MAIL_REPLY_TO,
                FILTER_VALIDATE_EMAIL
            )
        ) {
            $mail->addReplyTo(
                MAIL_REPLY_TO,
                $fromName
            );
        }

        $mail->isHTML(true);
        $mail->Subject =
            (string)$order['subject'];

        $portalUrl =
            tsSupplierBookingPortalUrl(
                $pdo,
                (int)$order['id']
            );

        $html =
            '<div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.6;color:#172033">'
            . '<p>Dear '
            . tsSupE(
                (string)(
                    $contact['contact_name']
                    ?? $supplier['company_name']
                )
            )
            . ',</p>'
            . '<p>This is a <strong>post-booking service confirmation request</strong> from TRAVSCOPE. '
            . 'Please confirm the booked services below at the agreed supplier rates.</p>'
            . '<p><strong>Supplier Order:</strong> '
            . tsSupE((string)$order['order_code'])
            . '<br><strong>Booking:</strong> '
            . tsSupE((string)($order['booking_number'] ?? ''))
            . '<br><strong>Trip:</strong> '
            . tsSupE((string)($order['trip_code'] ?? ''))
            . '</p>';

        if (
            trim(
                (string)(
                    $order['request_text']
                    ?? ''
                )
            ) !== ''
        ) {
            $html .=
                '<p>'
                . nl2br(
                    tsSupE(
                        (string)$order['request_text']
                    )
                )
                . '</p>';
        }

        $html .=
            '<table style="width:100%;border-collapse:collapse;margin:16px 0">'
            . '<thead><tr>'
            . '<th style="text-align:left;border:1px solid #dbe3ee;padding:8px;background:#f8fafc">Service</th>'
            . '<th style="text-align:left;border:1px solid #dbe3ee;padding:8px;background:#f8fafc">Date</th>'
            . '<th style="text-align:right;border:1px solid #dbe3ee;padding:8px;background:#f8fafc">Agreed Cost</th>'
            . '</tr></thead><tbody>';

        foreach ($items as $item) {
            $date =
                trim(
                    (string)(
                        $item['service_date_from']
                        ?? ''
                    )
                );

            if (
                !empty($item['service_date_to'])
                && $item['service_date_to']
                    !== $item['service_date_from']
            ) {
                $date .=
                    ' to '
                    . (string)$item['service_date_to'];
            }

            $html .=
                '<tr>'
                . '<td style="border:1px solid #dbe3ee;padding:8px">'
                . '<strong>'
                . tsSupE((string)$item['title'])
                . '</strong>';

            if (
                trim(
                    (string)(
                        $item['specifications']
                        ?? ''
                    )
                ) !== ''
            ) {
                $html .=
                    '<br><small>'
                    . nl2br(
                        tsSupE(
                            (string)$item['specifications']
                        )
                    )
                    . '</small>';
            }

            $html .=
                '</td>'
                . '<td style="border:1px solid #dbe3ee;padding:8px">'
                . tsSupE($date !== '' ? $date : '-')
                . '</td>'
                . '<td style="text-align:right;border:1px solid #dbe3ee;padding:8px">'
                . tsSupE(
                    (string)(
                        $order['currency']
                        ?? 'INR'
                    )
                )
                . ' '
                . number_format(
                    (float)(
                        $item['agreed_supplier_cost']
                        ?? 0
                    ),
                    2
                )
                . '</td>'
                . '</tr>';
        }

        $html .=
            '</tbody></table>'
            . '<p>Please use the secure link below to confirm, reject, or request an alternative for each service.</p>'
            . '<p><a href="'
            . tsSupE($portalUrl)
            . '" style="display:inline-block;background:#059669;color:#fff;text-decoration:none;padding:12px 18px;border-radius:8px;font-weight:bold">'
            . 'Confirm Booked Services'
            . '</a></p>'
            . '<p><small>This is a booking confirmation request, not a new quotation/RFQ.</small></p>'
            . '</div>';

        $mail->Body = $html;

        $plain = [
            'TRAVSCOPE POST-BOOKING SUPPLIER CONFIRMATION',
            'Supplier Order: ' . (string)$order['order_code'],
            'Booking: ' . (string)($order['booking_number'] ?? ''),
            'Trip: ' . (string)($order['trip_code'] ?? ''),
            ''
        ];

        foreach ($items as $item) {
            $plain[] =
                '- '
                . (string)$item['title']
                . ' | '
                . (string)(
                    $item['service_date_from']
                    ?? ''
                )
                . ' | '
                . (string)(
                    $order['currency']
                    ?? 'INR'
                )
                . ' '
                . number_format(
                    (float)(
                        $item['agreed_supplier_cost']
                        ?? 0
                    ),
                    2
                );
        }

        $plain[] = '';
        $plain[] = 'Secure confirmation link: ' . $portalUrl;

        $mail->AltBody =
            implode(
                "\n",
                $plain
            );

        $mail->send();

        return [
            'ok' => true,
            'message' =>
                'Supplier confirmation email sent.'
        ];

    } catch (Throwable $e) {
        error_log(
            'TRAVSCOPE supplier booking confirmation email error: '
            . $e->getMessage()
        );

        return [
            'ok' => false,
            'message' =>
                'Unable to send supplier confirmation email. Check SMTP configuration.'
        ];
    }
}

