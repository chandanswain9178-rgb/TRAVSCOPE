<?php
declare(strict_types=1);
/**
 * HTML email is untrusted, even when it appears to come from an internal address.
 * Isolate it in a unique-origin sandboxed iframe with a restrictive CSP.
 * External image loads are opt-in; never enable scripts, forms or same-origin.
 */
function tsCommEmailFrameDocument(string $raw, bool $allowRemoteImages=false): string
{
    if(trim($raw)==='')return '';
    // Keep email presentation markup/tables/CSS but remove interactive and active content.
    $raw=preg_replace('/<!--[\s\S]*?-->/', '', $raw)??$raw;
    $raw=preg_replace('/<!doctype[^>]*>/i','',$raw)??$raw;
    $danger='script|iframe|frame|frameset|object|embed|applet|form|input|button|textarea|select|option|video|audio|source|track|canvas|svg|math|meta|base|link|template';
    $raw=preg_replace('~<(?:'.$danger.')\b[^>]*>[\s\S]*?</(?:'.$danger.')\s*>~i','',$raw)??$raw;
    $raw=preg_replace('~</?(?:'.$danger.')\b[^>]*>~i','',$raw)??$raw;
    $raw=preg_replace('/\s+on[a-z]+\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)/i','',$raw)??$raw;
    $raw=preg_replace('/\s+(?:srcdoc|formaction|autofocus)\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)/i','',$raw)??$raw;
    $raw=preg_replace('~(href\s*=\s*["\']?)\s*(?:javascript|vbscript|data|file):~i','$1#blocked-',$raw)??$raw;
    $raw=preg_replace('~(src\s*=\s*["\']?)\s*(?:javascript|vbscript|file):~i','$1#blocked-',$raw)??$raw;
    // HTML emails often include their own <html>/<head>. The trusted head must be first.
    $raw=preg_replace('~</?(?:html|head|body)\b[^>]*>~i','',$raw)??$raw;
    // External links must be an explicit click and must not replace the admin dashboard.
    $raw=preg_replace('~<a\b~i','<a target="_blank" rel="noopener noreferrer" ',$raw)??$raw;
    $images=$allowRemoteImages?'data: https: http:':'data:';
    $csp="default-src 'none'; script-src 'none'; img-src $images; style-src 'unsafe-inline'; font-src data:; connect-src 'none'; form-action 'none'; base-uri 'none'; object-src 'none'; frame-src 'none'; media-src 'none'";
    return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        .'<meta http-equiv="Content-Security-Policy" content="'.htmlspecialchars($csp,ENT_QUOTES,'UTF-8').'">'
        .'<style>html,body{margin:0;padding:0;overflow-wrap:anywhere;background:#fff;color:#202124}body{font:14px/1.55 Arial,sans-serif;padding:18px;max-width:100%;}table{max-width:100%}img{max-width:100%;height:auto}pre{white-space:pre-wrap;word-break:break-word}a{color:#1769cf}</style>'
        .'</head><body>'.$raw.'</body></html>';
}
