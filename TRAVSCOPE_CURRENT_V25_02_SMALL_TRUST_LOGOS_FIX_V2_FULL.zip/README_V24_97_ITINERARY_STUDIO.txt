TRAVSCOPE V24.97 — PROFESSIONAL ITINERARY STUDIO
Base: V24.96 — INTERNATIONAL QUOTATION PRINT + GALLERY

PURPOSE
Replace the long, nested Day 1 / Day 2 / Day 3 editing stack in the CRM Quotation Builder
with an ergonomic itinerary day navigator, selected-day editor and live customer-view preview.

CHANGED FILES
- admin-crm.php
- assets/crm-itinerary-studio-v2497.css (new)
- assets/crm-itinerary-studio-v2497.js (new)
- README_V24_97_ITINERARY_STUDIO.txt (release notes)

FEATURES
1) Day navigator with completion status and drag-to-reorder (existing earlier/later/move controls remain).
2) Only the selected day's full editor is shown at a time; all hidden days remain part of the quotation form.
3) Previous, Next, Add Day, Duplicate Day, Remove Day, per-day Undo and Redo.
4) Structured Start, Via/Sightseeing, End, Distance and Approx Travel Time fields.
   Existing [Start: ... | Via/Sightseeing: ... | End: ...] information is read into those fields.
   It is reassembled into the existing itinerary_description[] field on form submission.
   No database schema change is required.
5) Day photo picker remains integrated with existing PC, website gallery, and Pexels/Unsplash flow.
6) Client-facing selected-day preview plus live 190–200-word narrative indicator.
7) Focus mode widens the quotation editor and hides the saved-version sidebar temporarily.
8) Browser draft auto-save (sessionStorage only, per lead/trip/tab) with deliberate Restore Draft action.
   This does not create a permanent CRM quotation version. Locally selected image files are NOT
   persisted in browser drafts. The existing Save Customer Quotation action is still authoritative.
9) Duration Days changes append/remove only required cards instead of rebuilding every card,
   helping preserve selected PC image input files on unaffected days.
10) Accessible button labels, responsive layout, and minimized extra scrollable containers.

EXISTING CONTRACT PRESERVED
- Existing save_package_version PHP route, DB tables, CSRF and ACL flows are unchanged.
- Existing field names preserved: itinerary_title[], itinerary_description[],
  itinerary_existing_image[], itinerary_image[].
- Original master package import, exact-PAX costing, hotel selection, supplier quotes,
  quotation version list, quotation PDFs and media picker flows are untouched.
- Existing 190–200-word customer itinerary presentation policy remains unchanged.

DEPLOYMENT
- BACK UP your current files and database before deployment.
- Upload the PATCH contents maintaining relative directory structure, or deploy the FULL ZIP.
- Refresh admin-crm.php with a hard reload (Ctrl+F5); assets use ?v=2497 for cache busting.
- Open CRM / Trips > Quotation Builder > Step 3B Professional Itinerary Studio.
- Try day switching, day ordering, route metadata, images, and then a saved quotation preview/PDF.
- Browser draft will be shown as saved in a normal HTTPS browser context; when browser storage
  is blocked, it reports the limitation and existing permanent quotation save still works.

TESTING
- PHP lint: admin-crm.php
- JavaScript syntax: assets/crm-itinerary-studio-v2497.js
- Automated browser fixture: add/edit/route/duplicate/undo/redo/focus/prev+next/browser draft
- This standalone environment does not contain production DB credentials or live server data;
  production booking/quotation write-through must be acceptance tested on a staging copy.

No SQL required.
