TRAVSCOPE V24.10 - INSTANT DELETE UX
Date: 2026-09-26

Changes:
1. Supplier Package single Delete now submits immediately (no browser confirm popup).
2. Supplier Package Delete Selected now submits immediately after rows are selected (no second confirmation popup).
3. Supplier Directory Delete now submits immediately (no browser confirm popup).
4. Package Master Delete now submits immediately (no browser confirm popup).

Safety:
- Existing server-side dependency/history checks remain active.
- If a supplier/package is protected by costing, booking, quotation, or other historical links, the server may block deletion and show an error instead of corrupting historical data.
- No database/schema change is required.
