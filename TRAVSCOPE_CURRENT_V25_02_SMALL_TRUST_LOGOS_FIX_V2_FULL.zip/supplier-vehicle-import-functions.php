<?php
declare(strict_types=1);
require_once __DIR__.'/supplier-vehicle-option-functions.php';

function tsSVIHeaderKey(string $v):string{
    $v=preg_replace('/^\xEF\xBB\xBF/','',trim($v))??trim($v);
    $v=strtolower($v);return preg_replace('/[^a-z0-9]+/','',$v)??$v;
}
function tsSVIColumnMap(array $header):array{
    $aliases=[
        'supplier_code'=>['suppliercode','suppliercode*','supplierid'],
        'supplier_name'=>['suppliername'],
        'country'=>['country','country*'],
        'state'=>['stateregion','state','region','stateregion*'],
        'destination'=>['destinationtourarea','destination','tourarea','destinationtourarea*'],
        'city'=>['citylocation','city','location'],
        'supplier_category'=>['suppliercategory','packagecategory','supplierpackagecategory'],
        'pax_min'=>['paxmin','minpax','paxfrom','paxmin*'],
        'pax_max'=>['paxmax','maxpax','paxto','paxmax*'],
        'vehicle_type'=>['vehicletype','vehicle','vehiclename','vehicletype*'],
        'ac_basis'=>['acbasis','acnonac','ac'],
        'route_scope'=>['routescope','route','scope'],
        'status'=>['status','status*'],
        'internal_note'=>['internalnote','notes','note'],
        'source_reference'=>['sourcereference','source','reference'],
    ];
    $norm=[];foreach($header as $i=>$h)$norm[tsSVIHeaderKey((string)$h)]=$i;
    $out=[];foreach($aliases as $field=>$keys){$out[$field]=null;foreach($keys as $k){$kk=tsSVIHeaderKey($k);if(array_key_exists($kk,$norm)){$out[$field]=$norm[$kk];break;}}}
    return $out;
}
function tsSVIRowValue(array $row,array $map,string $field):string{$i=$map[$field]??null;return $i===null?'':trim((string)($row[$i]??''));}
function tsSVIParseCsv(string $path):array{$fh=fopen($path,'rb');if(!$fh)throw new RuntimeException('Could not read CSV file.');$rows=[];while(($r=fgetcsv($fh,0,','))!==false){if(!$rows&&isset($r[0]))$r[0]=preg_replace('/^\xEF\xBB\xBF/','',(string)$r[0])??(string)$r[0];$rows[]=$r;if(count($rows)>2501)break;}fclose($fh);return $rows;}
function tsSVIXlsxCellColumn(string $ref):int{if(!preg_match('/^([A-Z]+)/i',$ref,$m))return 0;$letters=strtoupper($m[1]);$n=0;for($i=0;$i<strlen($letters);$i++)$n=$n*26+(ord($letters[$i])-64);return max(0,$n-1);}
function tsSVIXmlDecode(string $v):string{return html_entity_decode(preg_replace('/^\xEF\xBB\xBF/','',$v)??$v,ENT_QUOTES|ENT_XML1,'UTF-8');}
function tsSVIXlsxAttr(string $attrs,string $name):string{$q=preg_quote($name,'~');if(preg_match('~(?:^|\\s)'.$q.'\\s*=\\s*(["\\\'])(.*?)\\1~is',$attrs,$m))return tsSVIXmlDecode((string)$m[2]);return '';}
function tsSVIXlsxTextNodes(string $xml):string{$out='';if(preg_match_all('~<(?:[A-Za-z0-9_]+:)?t\\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?t>~is',$xml,$mm))foreach($mm[1] as $t)$out.=tsSVIXmlDecode(strip_tags((string)$t));return $out;}
function tsSVIXlsxSharedStrings(ZipArchive $zip):array{$ss=$zip->getFromName('xl/sharedStrings.xml');if($ss===false||$ss==='')return [];$shared=[];if(preg_match_all('~<(?:[A-Za-z0-9_]+:)?si\\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?si>~is',$ss,$items))foreach($items[1] as $si)$shared[]=tsSVIXlsxTextNodes((string)$si);return $shared;}
function tsSVIXlsxParseWorksheetRaw(string $sx,array $shared):array{$sx=preg_replace('/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]/','',$sx)??$sx;$rows=[];if(!preg_match_all('~<(?:[A-Za-z0-9_]+:)?row\\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?row>~is',$sx,$rm))return [];
    foreach($rm[1] as $rx){$arr=[];if(preg_match_all('~<(?:[A-Za-z0-9_]+:)?c\\b([^>]*?)(?:\\s*/>|>(.*?)</(?:[A-Za-z0-9_]+:)?c>)~is',(string)$rx,$cells,PREG_SET_ORDER))foreach($cells as $c){$attrs=(string)($c[1]??'');$inner=(string)($c[2]??'');$ref=tsSVIXlsxAttr($attrs,'r');if($ref==='')continue;$col=tsSVIXlsxCellColumn($ref);$type=strtolower(tsSVIXlsxAttr($attrs,'t'));$val='';if($type==='inlinestr')$val=tsSVIXlsxTextNodes($inner);else{$raw='';if(preg_match('~<(?:[A-Za-z0-9_]+:)?v\\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?v>~is',$inner,$vm))$raw=tsSVIXmlDecode(strip_tags((string)$vm[1]));if($type==='s')$val=$shared[(int)$raw]??'';elseif($type==='b')$val=$raw==='1'?'Yes':'No';else$val=$raw;}$arr[$col]=$val;}
        if($arr){$max=max(array_keys($arr));$dense=[];for($i=0;$i<=$max;$i++)$dense[]=$arr[$i]??'';$rows[]=$dense;}if(count($rows)>2501)break;}
    return $rows;}
function tsSVIXlsxLooksLikeImport(array $rows):bool{foreach(array_slice($rows,0,8) as $row){$m=tsSVIColumnMap($row);if(($m['vehicle_type']??null)!==null&&($m['pax_min']??null)!==null&&(($m['destination']??null)!==null||($m['state']??null)!==null))return true;}return false;}
function tsSVIXlsxPromoteHeader(array $rows):array{foreach(array_slice($rows,0,8,true) as $i=>$row){$m=tsSVIColumnMap($row);if(($m['vehicle_type']??null)!==null&&($m['pax_min']??null)!==null&&(($m['destination']??null)!==null||($m['state']??null)!==null))return array_values(array_slice($rows,(int)$i));}return $rows;}
function tsSVIParseXlsx(string $path):array{if(!class_exists('ZipArchive'))throw new RuntimeException('Excel import needs PHP ZipArchive. CSV import is available now; ask hosting to enable php-zip for .xlsx files.');$zip=new ZipArchive();if($zip->open($path)!==true)throw new RuntimeException('Could not open Excel workbook. Upload a normal .xlsx file.');try{$shared=tsSVIXlsxSharedStrings($zip);$candidates=[];for($i=0;$i<$zip->numFiles;$i++){$st=$zip->statIndex($i);$n=(string)($st['name']??'');if(preg_match('~^xl/worksheets/[^/]+\\.xml$~i',$n))$candidates[$n]=true;}if(!$candidates)throw new RuntimeException('Could not find any Excel worksheet.');$first=[];foreach(array_keys($candidates) as $p){$sx=$zip->getFromName($p);if($sx===false||$sx==='')continue;$rows=tsSVIXlsxParseWorksheetRaw($sx,$shared);if(!$first&&$rows)$first=$rows;if(tsSVIXlsxLooksLikeImport($rows))return tsSVIXlsxPromoteHeader($rows);}if($first)return tsSVIXlsxPromoteHeader($first);throw new RuntimeException('No readable rows were found in the Excel workbook.');}finally{$zip->close();}}
function tsSVIParseFile(string $path,string $name):array{$ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));if($ext==='csv')return tsSVIParseCsv($path);if($ext==='xlsx')return tsSVIParseXlsx($path);throw new RuntimeException('Only .xlsx and .csv files are supported.');}
function tsSVIFindDestination(PDO $pdo,string $destination,string $state,string $country):?array{$names=array_values(array_filter(array_unique([trim($destination),trim($state)]),fn($v)=>$v!==''));if(!$names)return null;foreach($names as $name){$sql='SELECT id,name,'.(tsSVOColumn($pdo,'destinations','country')?'country':"'' country").' FROM destinations WHERE LOWER(TRIM(name))=LOWER(TRIM(?))';$p=[$name];if($country!==''&&tsSVOColumn($pdo,'destinations','country')){$sql.=" AND (LOWER(TRIM(country))=LOWER(TRIM(?)) OR TRIM(COALESCE(country,''))='')";$p[]=$country;}$sql.=' ORDER BY id LIMIT 1';$s=$pdo->prepare($sql);$s->execute($p);$r=$s->fetch(PDO::FETCH_ASSOC);if($r)return $r;}return null;}
function tsSVIFindLocation(PDO $pdo,int $destinationId,string $city):?array{if($destinationId<=0||$city===''||!tsSVOTable($pdo,'destination_locations'))return null;$s=$pdo->prepare('SELECT id,location_name FROM destination_locations WHERE destination_id=? AND LOWER(TRIM(location_name))=LOWER(TRIM(?)) LIMIT 1');$s->execute([$destinationId,$city]);return $s->fetch(PDO::FETCH_ASSOC)?:null;}
function tsSVIExisting(PDO $pdo,int $supplierId,int $destinationId,string $city,string $cat,int $pmin,int $pmax,string $vehicle):int{if(!tsSVOReady($pdo))return 0;$norm=tsSVONormalize($vehicle);$s=$pdo->prepare("SELECT id FROM supplier_vehicle_options WHERE supplier_id=? AND destination_id=? AND LOWER(TRIM(city))=LOWER(TRIM(?)) AND LOWER(TRIM(supplier_category))=LOWER(TRIM(?)) AND pax_min=? AND pax_max=? AND vehicle_type_normalized=? LIMIT 1");$s->execute([$supplierId,$destinationId,$city,$cat,$pmin,$pmax,$norm]);return (int)($s->fetchColumn()?:0);}
function tsSVINormalizeAc(string $v):string{$n=tsSVONormalize($v);if(in_array($n,['ac','a c','air conditioned','air conditioning'],true))return 'ac';if(in_array($n,['non ac','non a c','without ac','nonac'],true))return 'non_ac';return 'unspecified';}
function tsSVIValidateRows(PDO $pdo,array $matrix,int $supplierId):array{
    if(count($matrix)<2)throw new RuntimeException('The import file has no data rows.');$header=array_shift($matrix);$map=tsSVIColumnMap($header);
    foreach(['pax_min','pax_max','vehicle_type'] as $f)if(($map[$f]??null)===null)throw new RuntimeException('Missing required column: '.str_replace('_',' ',ucwords($f,'_')).'. Use the TRAVSCOPE Vehicle template.');
    if(($map['destination']??null)===null&&($map['state']??null)===null)throw new RuntimeException('Missing Destination / Tour Area (or State / Region) column.');
    $sup=tsSVOSupplier($pdo,$supplierId);if(!$sup)throw new RuntimeException('Choose supplier before importing.');$code=trim((string)($sup['supplier_code']??''));$out=[];$rowNo=1;
    foreach($matrix as $row){$rowNo++;$allBlank=true;foreach($row as $v)if(trim((string)$v)!==''){$allBlank=false;break;}if($allBlank)continue;if(count($out)>=2000)break;
        $supplierCode=tsSVIRowValue($row,$map,'supplier_code');$country=tsSVIRowValue($row,$map,'country');$state=tsSVIRowValue($row,$map,'state');$destText=tsSVIRowValue($row,$map,'destination');$city=tsSVIRowValue($row,$map,'city');$cat=tsSVIRowValue($row,$map,'supplier_category');if($cat==='')$cat='All';$pmin=(int)tsSVIRowValue($row,$map,'pax_min');$pmax=(int)tsSVIRowValue($row,$map,'pax_max');$vehicle=tsSVIRowValue($row,$map,'vehicle_type');$status=strtolower(tsSVIRowValue($row,$map,'status'));if($status==='')$status='active';$errors=[];$warnings=[];
        if($supplierCode!==''&&$code!==''&&strcasecmp($supplierCode,$code)!==0)$errors[]='Supplier Code does not match selected supplier.';if($pmin<=0)$errors[]='PAX Min must be greater than 0.';if($pmax<=0)$errors[]='PAX Max must be greater than 0.';if($pmin>0&&$pmax>0&&$pmax<$pmin)$errors[]='PAX Max cannot be smaller than PAX Min.';if($vehicle==='')$errors[]='Vehicle Type is required.';if(!in_array($status,['active','inactive'],true))$errors[]='Status must be Active or Inactive.';
        $dest=tsSVIFindDestination($pdo,$destText,$state,$country);if(!$dest)$errors[]='Destination/State not found in Destination Master.';$did=(int)($dest['id']??0);$loc=$did>0&&$city!==''?tsSVIFindLocation($pdo,$did,$city):null;$lid=(int)($loc['id']??0);if($did>0&&$city!==''&&!$loc)$warnings[]='City/Location not in Location Master; can be created during import.';
        $existing=($did>0&&$pmin>0&&$pmax>0&&$vehicle!=='')?tsSVIExisting($pdo,$supplierId,$did,$city,$cat,$pmin,$pmax,$vehicle):0;if($existing>0)$warnings[]='Duplicate supplier vehicle option already exists.';
        $notes=[];$base=tsSVIRowValue($row,$map,'internal_note');if($base!=='')$notes[]=$base;$src=tsSVIRowValue($row,$map,'source_reference');if($src!=='')$notes[]='Source: '.$src;
        $out[]=['row_no'=>$rowNo,'supplier_id'=>$supplierId,'source_country'=>$country,'source_state'=>$state,'source_destination'=>$destText,'destination_id'=>$did,'destination_name'=>(string)($dest['name']??($destText?:$state)),'location_id'=>$lid,'city'=>$city,'supplier_category'=>$cat,'pax_min'=>$pmin,'pax_max'=>$pmax,'vehicle_type'=>$vehicle,'ac_basis'=>tsSVINormalizeAc(tsSVIRowValue($row,$map,'ac_basis')),'route_scope'=>tsSVIRowValue($row,$map,'route_scope'),'notes'=>implode(' | ',$notes),'status'=>$status,'existing_id'=>$existing,'excluded'=>false,'errors'=>$errors,'warnings'=>$warnings];
    }
    return $out;
}
function tsSVIRevalidateRow(PDO $pdo,array $row,int $supplierId,array $edit=[]):array{
    $row['excluded']=empty($edit)?(bool)($row['excluded']??false):empty($edit['include']);foreach(['city','supplier_category','vehicle_type','ac_basis','route_scope','status'] as $k)if(array_key_exists($k,$edit))$row[$k]=trim((string)$edit[$k]);foreach(['pax_min','pax_max','destination_id'] as $k)if(array_key_exists($k,$edit))$row[$k]=max(0,(int)$edit[$k]);if($row['excluded']){$row['errors']=[];$row['warnings']=[];return $row;}
    $did=(int)($row['destination_id']??0);$dest=null;if($did>0&&tsSVOTable($pdo,'destinations')){$q=$pdo->prepare('SELECT id,name FROM destinations WHERE id=? LIMIT 1');$q->execute([$did]);$dest=$q->fetch(PDO::FETCH_ASSOC)?:null;}if(!$dest){$dest=tsSVIFindDestination($pdo,(string)($row['source_destination']??$row['destination_name']??''),(string)($row['source_state']??''),(string)($row['source_country']??''));$did=(int)($dest['id']??0);}$row['destination_id']=$did;$row['destination_name']=$dest?(string)$dest['name']:(string)($row['destination_name']??'');
    $city=trim((string)($row['city']??''));$cat=trim((string)($row['supplier_category']??'All'));if($cat==='')$cat='All';$row['supplier_category']=$cat;$pmin=(int)($row['pax_min']??0);$pmax=(int)($row['pax_max']??0);$vehicle=trim((string)($row['vehicle_type']??''));$status=strtolower(trim((string)($row['status']??'active')));$row['status']=$status;$errors=[];$warnings=[];
    if($did<=0)$errors[]='Choose a valid Destination / State.';if($pmin<=0)$errors[]='PAX Min must be greater than 0.';if($pmax<=0)$errors[]='PAX Max must be greater than 0.';if($pmin>0&&$pmax>0&&$pmax<$pmin)$errors[]='PAX Max cannot be smaller than PAX Min.';if($vehicle==='')$errors[]='Vehicle Type is required.';if(!in_array($status,['active','inactive'],true))$errors[]='Status must be Active or Inactive.';
    $loc=$did>0&&$city!==''?tsSVIFindLocation($pdo,$did,$city):null;$row['location_id']=(int)($loc['id']??0);if($did>0&&$city!==''&&!$loc)$warnings[]='City/Location not in Location Master; can be created during import.';$existing=($did>0&&$pmin>0&&$pmax>0&&$vehicle!=='')?tsSVIExisting($pdo,$supplierId,$did,$city,$cat,$pmin,$pmax,$vehicle):0;$row['existing_id']=$existing;if($existing>0)$warnings[]='Duplicate supplier vehicle option already exists.';$row['errors']=$errors;$row['warnings']=$warnings;return $row;
}
function tsSVIApplyCorrections(PDO $pdo,array $rows,int $supplierId,array $posted):array{$out=[];foreach($rows as $i=>$r)$out[]=tsSVIRevalidateRow($pdo,$r,$supplierId,is_array($posted[$i]??null)?$posted[$i]:[]);return $out;}
