<?php
/**
 * V24.38 - customer cancellation notifications.
 * Uses the existing booking_communications/PHPMailer channel. No extra SQL.
 * Cancellation/refund mutations must commit before this helper is called.
 */
declare(strict_types=1);

function tsCancelMailDraft(PDO $pdo, int $caseId, string $event = 'update'): array
{
    if ($caseId < 1) throw new RuntimeException('Invalid cancellation case.');
    if (!in_array($event, ['approved','rejected','assessment','refund_paid','update'], true)) {
        throw new RuntimeException('Unknown cancellation email type.');
    }
    $stmt = $pdo->prepare('SELECT bc.id,bc.booking_id,bc.status,bc.processed_at,b.booking_number,b.customer_name,b.customer_email,b.total_amount,b.paid_amount,b.travel_date,b.booking_status,b.currency,p.title AS package_title FROM booking_cancellations bc JOIN bookings b ON b.id=bc.booking_id LEFT JOIN packages p ON p.id=b.package_id WHERE bc.id=? LIMIT 1');
    $stmt->execute([$caseId]);
    $r = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$r) throw new RuntimeException('Cancellation case not found.');
    if ($event === 'update' && !in_array($r['status'],['approved','rejected'],true)) throw new RuntimeException('A pending cancellation cannot be emailed as an approved cancellation.');
    if ($event === 'approved' && $r['status'] !== 'approved') throw new RuntimeException('Cancellation has not been approved.');
    if ($event === 'rejected' && $r['status'] !== 'rejected') throw new RuntimeException('Cancellation has not been rejected.');
    if (in_array($event,['assessment','refund_paid'],true) && $r['status'] !== 'approved') throw new RuntimeException('Cancellation is not approved.');

    $finance = null;
    try {
        $f=$pdo->prepare('SELECT customer_paid_at_cancellation,customer_cancellation_charge,customer_refund_amount,customer_refund_status FROM booking_cancellation_financials WHERE booking_cancellation_id=? LIMIT 1');
        $f->execute([$caseId]); $finance=$f->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) { /* The finance extension can be unavailable on older installations. */ }

    $refund = null;
    try {
        $f=$pdo->prepare("SELECT amount,status,payment_method,reference_number,paid_at FROM booking_customer_refunds WHERE source_type='cancellation' AND source_id=? AND booking_id=? ORDER BY id DESC LIMIT 1");
        $f->execute([$caseId,(int)$r['booking_id']]); $refund=$f->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) { /* Keep status mail usable without optional billing tables. */ }

    if ($event==='assessment' && !$finance) throw new RuntimeException('Financial assessment must be saved before sending its notice.');
    if ($event==='refund_paid' && (!$refund || $refund['status']!=='paid')) {
        throw new RuntimeException('There is no verified paid cancellation refund to email.');
    }

    $currency=strtoupper(trim((string)$r['currency'])) ?: 'INR';
    $money=static fn(float $n): string => $currency.' '.number_format(max(0,$n),2);
    $booking=(string)$r['booking_number'];
    $name=trim((string)$r['customer_name']) ?: 'Traveller';
    $lines=['Dear '.$name.',',''];

    if ($event==='rejected' || ($event==='update' && $r['status']==='rejected')) {
        $subject='Cancellation request update - '.$booking;
        $lines[]='Your cancellation request for booking '.$booking.' was not approved.';
        $lines[]='The reservation status remains: '.ucfirst((string)$r['booking_status']).'.';
        $lines[]='Please contact the TRAVSCOPE team if you need any clarification.';
    } elseif ($event==='refund_paid' || ($event==='update' && $refund && $refund['status']==='paid')) {
        $subject='Cancellation refund paid - '.$booking;
        $lines[]='We confirm that your booking '.$booking.' was cancelled and the customer refund transfer has been recorded as PAID.';
        $lines[]='Refund transferred: '.$money((float)$refund['amount']);
        $lines[]='Refund method: '.str_replace('_',' ',ucwords((string)$refund['payment_method'],'_'));
        $lines[]='Transfer reference / UTR: '.(string)($refund['reference_number'] ?: 'Contact support');
        $lines[]='Recorded on: '.(!empty($refund['paid_at']) ? date('d M Y, h:i A',strtotime((string)$refund['paid_at'])) : 'Not specified');
        $lines[]='Bank/UPI settlement timing may vary. Please contact us with your booking number if you need assistance.';
    } else {
        $subject=($event==='assessment' ? 'Cancellation financial assessment - ' : 'Booking cancellation notice - ').$booking;
        $lines[]='Your booking '.$booking.' ('.trim((string)($r['package_title'] ?: 'Travel Package')).') has been cancelled.';
        if (!empty($r['travel_date'])) $lines[]='Original travel date: '.date('d M Y',strtotime((string)$r['travel_date']));
        if ($finance) {
            $lines[]='';
            $lines[]='Cancellation financial assessment:';
            $lines[]='Customer amount received at cancellation: '.$money((float)$finance['customer_paid_at_cancellation']);
            $lines[]='Cancellation charge retained: '.$money((float)$finance['customer_cancellation_charge']);
            $lines[]='Refund assessed: '.$money((float)$finance['customer_refund_amount']);
            $lines[]='Refund status: '.($refund && $refund['status']==='paid' ? 'Paid' : ((float)$finance['customer_refund_amount'] > .009 ? 'Awaiting refund transfer confirmation' : 'No refund due under this assessment'));
            if (!$refund || $refund['status']!=='paid') {
                $lines[]='This notification is not a payment confirmation. Any refund will be confirmed separately after the transfer is completed.';
            }
        } else {
            $lines[]='';
            $lines[]='Any applicable cancellation charges and refund are still under financial review. We will communicate the assessment separately. This cancellation notice does not confirm a refund or a transfer.';
        }
    }
    $lines[]='';
    $lines[]='Cancellation reference: #'.$caseId;
    $lines[]='Booking number: '.$booking;
    $lines[]='';
    $lines[]='Regards,';
    $lines[]='TRAVSCOPE Customer Support';
    return ['subject'=>$subject,'body'=>implode("\n",$lines),'booking_id'=>(int)$r['booking_id'],'email'=>trim((string)$r['customer_email']),'case_id'=>$caseId];
}

/** Return a non-throwing result, so delivery problems never roll back finance data. */
function tsCancelSendMail(PDO $pdo, int $caseId, string $event, int $adminId=0, bool $resend=false): array
{
    try {
        $draft=tsCancelMailDraft($pdo,$caseId,$event);
        if (!filter_var($draft['email'],FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Customer has no valid email address.');
        require_once __DIR__ . '/communication-functions.php';
        if (!tsCommReady($pdo)) throw new RuntimeException('Communication Center is not available.');
        $templateKey='ts_cancellation_'.$event.'_'.$caseId;
        if (!$resend) {
            $s=$pdo->prepare("SELECT id FROM booking_communications WHERE booking_id=? AND template_key=? AND channel='email' AND delivery_status='sent' LIMIT 1");
            $s->execute([$draft['booking_id'],$templateKey]);
            if ($s->fetchColumn()) return ['ok'=>true,'skipped'=>true,'message'=>'This cancellation email was already sent.'];
        }
        tsCommSendEmail($pdo,$draft['booking_id'],$draft['subject'],$draft['body'],$adminId,$templateKey,['cancellation_case_id'=>$caseId,'notice_event'=>$event]);
        return ['ok'=>true,'skipped'=>false,'message'=>'Customer cancellation email sent to '.$draft['email'].'.'];
    } catch (Throwable $e) {
        error_log('TRAVSCOPE Cancellation Email: '.$e->getMessage());
        return ['ok'=>false,'skipped'=>false,'message'=>'Cancellation was saved, but email was NOT sent: '.$e->getMessage()];
    }
}
