<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/deployment-functions.php';

requireAdmin();

$admin = currentAdmin($pdo);
if (!$admin || strtolower((string)($admin['status'] ?? '')) !== 'active') {
    unset($_SESSION['admin_id'], $_SESSION['admin_name'], $_SESSION['admin_email'], $_SESSION['admin_role']);
    redirect(BASE_URL . 'login.php');
}

$adminId = (int)$admin['id'];
$canManage = function_exists('tsAclCan') ? tsAclCan($pdo, $adminId, 'manage_access') : true;

if (!$canManage) {
    http_response_code(403);
    exit('Deployment Safety Center requires Manage Permissions authority.');
}

if (empty($_SESSION['admin_deployment_csrf'])) {
    $_SESSION['admin_deployment_csrf'] = bin2hex(random_bytes(32));
}
$csrf = (string)$_SESSION['admin_deployment_csrf'];

$releaseId = max(0, (int)($_GET['release_id'] ?? $_POST['release_id'] ?? 0));
$error = '';
$success = '';

if (!empty($_SESSION['admin_deployment_success'])) {
    $success = (string)$_SESSION['admin_deployment_success'];
    unset($_SESSION['admin_deployment_success']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (string)($_POST['action'] ?? '') !== '') {
    $postedToken = (string)($_POST['csrf_token'] ?? '');

    if ($postedToken === '' || !hash_equals($csrf, $postedToken)) {
        $error = 'Security verification failed. Refresh and try again.';
    } else {
        try {
            if (!tsDeployReady($pdo)) {
                throw new RuntimeException('Import TRAVSCOPE_Backup_Restore_Deployment_Safety.sql first.');
            }

            $action = (string)$_POST['action'];

            if ($action === 'create_release') {
                $releaseId = tsDeployCreateRelease(
                    $pdo,
                    (string)($_POST['release_tag'] ?? ''),
                    (string)($_POST['package_name'] ?? ''),
                    (string)($_POST['package_sha256'] ?? ''),
                    (string)($_POST['notes'] ?? ''),
                    $adminId
                );
                $_SESSION['admin_deployment_success'] = 'Deployment release created. Run Pre-Deployment Health Check before Maintenance Mode.';

            } elseif ($action === 'precheck') {
                $health = tsDeployRunPrecheck($pdo, $releaseId, $adminId);
                $_SESSION['admin_deployment_success'] =
                    $health['fail'] > 0
                        ? 'Pre-Deployment Health Check found FAIL conditions. Deployment remains blocked.'
                        : 'Pre-Deployment Health Check passed with ' . (int)$health['warning'] . ' warning(s). Release is ready for Maintenance Mode.';

            } elseif ($action === 'start_maintenance') {
                if (strtoupper(trim((string)($_POST['confirm_text'] ?? ''))) !== 'MAINTENANCE') {
                    throw new RuntimeException('Type MAINTENANCE to enable Maintenance Mode.');
                }
                tsDeployStartMaintenance(
                    $pdo,
                    $releaseId,
                    (string)($_POST['maintenance_message'] ?? ''),
                    $adminId
                );
                $_SESSION['admin_deployment_success'] = 'Maintenance Mode enabled. Admin access remains available.';

            } elseif ($action === 'mark_deployed') {
                if (strtoupper(trim((string)($_POST['confirm_text'] ?? ''))) !== 'DEPLOYED') {
                    throw new RuntimeException('Type DEPLOYED after the code/package has actually been uploaded.');
                }
                tsDeployMarkDeployed($pdo, $releaseId, $adminId);
                $_SESSION['admin_deployment_success'] = 'Release marked Deployed. Maintenance remains ON until Post-Deployment Health verification passes.';

            } elseif ($action === 'postcheck') {
                $health = tsDeployPostcheckAndExit($pdo, $releaseId, $adminId);
                $_SESSION['admin_deployment_success'] =
                    $health['fail'] > 0
                        ? 'Post-Deployment Health Check failed. Maintenance Mode remains ON.'
                        : 'Post-Deployment Health Check passed. Release is Verified and Maintenance Mode is OFF.';

            } elseif ($action === 'exit_maintenance') {
                if (strtoupper(trim((string)($_POST['confirm_text'] ?? ''))) !== 'EXIT') {
                    throw new RuntimeException('Type EXIT to manually disable Maintenance Mode.');
                }
                tsDeployExitMaintenance($pdo, $releaseId, $adminId);
                $_SESSION['admin_deployment_success'] = 'Maintenance Mode manually disabled. Release status was not changed.';

            } elseif ($action === 'register_rollback') {
                tsDeployRegisterRollbackPackage(
                    $pdo,
                    $releaseId,
                    (string)($_POST['rollback_package_name'] ?? ''),
                    (string)($_POST['rollback_package_sha256'] ?? ''),
                    (string)($_POST['rollback_notes'] ?? ''),
                    $adminId
                );
                $_SESSION['admin_deployment_success'] = 'Rollback package metadata registered. No restore was performed.';

            } elseif ($action === 'record_rollback') {
                if (strtoupper(trim((string)($_POST['confirm_text'] ?? ''))) !== 'ROLLED BACK') {
                    throw new RuntimeException('Type ROLLED BACK only after the rollback was manually completed outside this page.');
                }
                tsDeployRecordRollback(
                    $pdo,
                    $releaseId,
                    (string)($_POST['rollback_notes'] ?? ''),
                    $adminId
                );
                $_SESSION['admin_deployment_success'] = 'Manual rollback recorded. TRAVSCOPE did not perform the restore.';

            } else {
                throw new RuntimeException('Invalid Deployment Safety action.');
            }

            redirect(BASE_URL . 'admin-deployment-safety.php?release_id=' . $releaseId);

        } catch (RuntimeException $e) {
            $error = $e->getMessage();
        } catch (Throwable $e) {
            error_log('TRAVSCOPE Deployment Safety: ' . $e->getMessage());
            $error = 'Unable to complete Deployment Safety action: ' . $e->getMessage();
        }
    }
}

$maintenance = tsDeployMaintenanceStatus($pdo);
$dbStats = tsDeployDatabaseStats($pdo);
$release = $releaseId > 0 ? tsDeployRelease($pdo, $releaseId) : null;
$releases = tsDeployReleases($pdo, 60);
$events = $release ? tsDeployEvents($pdo, (int)$release['id'], 80) : [];
$backups = tsDeployBackups($pdo, 80);

function dsE(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dsDate(?string $value): string
{
    if (!$value) return '-';
    $ts = strtotime($value);
    return $ts ? date('d M Y · h:i A', $ts) : (string)$value;
}

function dsBytes(int $bytes): string
{
    if ($bytes < 1024) return $bytes . ' B';
    if ($bytes < 1024 * 1024) return number_format($bytes / 1024, 1) . ' KB';
    if ($bytes < 1024 * 1024 * 1024) return number_format($bytes / (1024 * 1024), 1) . ' MB';
    return number_format($bytes / (1024 * 1024 * 1024), 2) . ' GB';
}

function dsStatus(string $status): string
{
    return match ($status) {
        'verified' => 'good',
        'precheck_ready','deployed' => 'info',
        'maintenance' => 'warn',
        'failed' => 'bad',
        'rolled_back' => 'neutral',
        default => 'neutral',
    };
}

function dsHealthSummary(?string $json): array
{
    $scan = tsDeployDecode($json);
    $summary = (array)($scan['summary'] ?? []);
    return [
        'score' => (int)($summary['health_score'] ?? 0),
        'fail' => (int)($summary['fail'] ?? 0),
        'warning' => (int)($summary['warning'] ?? 0),
        'pass' => (int)($summary['pass'] ?? 0),
    ];
}

$preHealth = $release ? dsHealthSummary((string)($release['pre_health_json'] ?? '')) : [];
$postHealth = $release ? dsHealthSummary((string)($release['post_health_json'] ?? '')) : [];

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Deployment Safety | TRAVSCOPE Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:68px;padding:10px 4%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;border-bottom:1px solid #dfe7f0;position:sticky;top:0;z-index:20}.brand{font-weight:900}.brand span{color:#2563eb}.actions{display:flex;gap:7px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 10px;border:1px solid #cbd5e1;border-radius:9px;background:#fff;color:#334155;text-decoration:none;font-size:9px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.btn.good{background:#059669;border-color:#059669;color:#fff}.btn.warn{background:#fff7ed;border-color:#fed7aa;color:#c2410c}.btn.bad{background:#fff1f2;border-color:#fecdd3;color:#be123c}.btn:disabled{opacity:.5;cursor:not-allowed}.wrap{max-width:1450px;margin:20px auto;padding:0 13px}.hero{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;padding:17px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:20px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px;line-height:1.55}.pill{display:inline-flex;align-items:center;gap:4px;padding:4px 7px;border-radius:999px;font-size:7.5px;font-weight:900;background:#f1f5f9;color:#64748b}.pill.good{background:#dcfce7;color:#166534}.pill.info{background:#dbeafe;color:#1d4ed8}.pill.warn{background:#fef3c7;color:#92400e}.pill.bad{background:#fee2e2;color:#b91c1c}.pill.neutral{background:#e2e8f0;color:#475569}.notice{margin-top:10px;padding:10px 12px;border-radius:10px;font-size:10px;line-height:1.5}.notice.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#047857}.notice.err{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c}.notice.warn{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412}.stats{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin-top:11px}.stat{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.stat span{display:block;color:#64748b;font-size:7px;font-weight:900;text-transform:uppercase}.stat strong{display:block;margin-top:4px;font-size:12px}.layout{display:grid;grid-template-columns:.38fr 1fr;gap:11px;margin-top:11px}.card{background:#fff;border:1px solid #dfe7f0;border-radius:13px;overflow:hidden}.head{padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff;display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.head h2{margin:0;font-size:12px}.head p{margin:4px 0 0;color:#64748b;font-size:8.5px;line-height:1.45}.body{padding:11px}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.field.full{grid-column:1/-1}.field label{display:block;margin-bottom:4px;font-size:8px;font-weight:900;color:#475569}.control{width:100%;min-height:35px;padding:7px 8px;border:1px solid #cbd5e1;border-radius:8px;font-size:8.5px}.release{padding:9px;border:1px solid #e2e8f0;border-radius:9px;margin-bottom:7px}.release a{text-decoration:none;color:#1d4ed8;font-size:9px;font-weight:900}.release small{display:block;margin-top:4px;color:#64748b;font-size:7.5px;line-height:1.45}.workflow{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px}.step{padding:9px;border:1px solid #e2e8f0;border-radius:10px;background:#fff}.step strong{display:block;font-size:8.5px}.step small{display:block;margin-top:4px;color:#64748b;font-size:7.5px;line-height:1.45}.step form{margin-top:8px}.event{padding:8px;border-bottom:1px solid #eef2f7}.event:last-child{border-bottom:0}.event strong{font-size:8.5px}.event small{display:block;margin-top:3px;color:#64748b;font-size:7.5px;line-height:1.45}.backup-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.backup{padding:10px;border:1px solid #dbeafe;border-radius:10px;background:#eff6ff}.backup h3{margin:0;font-size:10px}.backup p{font-size:8px;color:#475569;line-height:1.5}.table-wrap{overflow:auto;border:1px solid #e2e8f0;border-radius:9px}.table{width:100%;border-collapse:collapse;min-width:850px}.table th,.table td{padding:7px 8px;border-bottom:1px solid #eef2f7;text-align:left;font-size:7.8px}.table th{background:#f8fafc;color:#64748b;font-size:7px;text-transform:uppercase}.empty{padding:22px;text-align:center;color:#94a3b8;border:1px dashed #cbd5e1;border-radius:10px;font-size:9px}.danger-note{padding:10px;border:1px solid #fecaca;border-radius:10px;background:#fff1f2;color:#9f1239;font-size:8.5px;line-height:1.55}
@media(max-width:1100px){.layout{grid-template-columns:1fr}.workflow{grid-template-columns:1fr 1fr}}@media(max-width:700px){.top,.hero{flex-direction:column;align-items:flex-start}.stats,.workflow,.backup-grid,.form-grid{grid-template-columns:1fr}.field.full{grid-column:auto}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>
<body>
<header class="top">
    <div class="brand">TRAV<span>SCOPE</span> · DEPLOYMENT SAFETY</div>
    <div class="actions">
        <a class="btn" href="<?= dsE(BASE_URL . 'admin-dashboard.php'); ?>"><i class="fa-solid fa-gauge-high"></i>Dashboard</a>
        <a class="btn" href="<?= dsE(BASE_URL . 'admin-system-health.php'); ?>"><i class="fa-solid fa-heart-pulse"></i>System Health</a>
        <a class="btn" href="<?= dsE(BASE_URL . 'admin-operational-settings.php'); ?>"><i class="fa-solid fa-sliders"></i>Ops Settings</a>
    </div>
</header>

<main class="wrap">
<section class="hero">
    <div>
        <h1>Backup / Restore + Deployment Safety Center</h1>
        <p>
            Register releases, capture pre-deployment Health, generate controlled backups,
            enable the existing Maintenance Mode, record when code is deployed, verify the
            live system, and keep a rollback registry. <strong>No automatic destructive restore exists.</strong>
        </p>
    </div>
    <span class="pill <?= !empty($maintenance['enabled']) ? 'warn' : 'good'; ?>">
        MAINTENANCE <?= !empty($maintenance['enabled']) ? 'ON' : 'OFF'; ?>
    </span>
</section>

<?php if ($success): ?><div class="notice ok"><?= dsE($success); ?></div><?php endif; ?>
<?php if ($error): ?><div class="notice err"><?= dsE($error); ?></div><?php endif; ?>
<?php if (!tsDeployReady($pdo)): ?>
<div class="notice err">Import <strong>TRAVSCOPE_Backup_Restore_Deployment_Safety.sql</strong> before using release, backup or deployment actions.</div>
<?php endif; ?>

<div class="stats">
    <div class="stat"><span>Database Tables</span><strong><?= (int)$dbStats['table_count']; ?></strong></div>
    <div class="stat"><span>Estimated DB Size</span><strong><?= dsE(dsBytes((int)$dbStats['estimated_bytes'])); ?></strong></div>
    <div class="stat"><span>Temp Storage</span><strong><?= !empty($dbStats['temp_writable']) ? 'WRITABLE' : 'NOT WRITABLE'; ?></strong></div>
    <div class="stat"><span>Registered Releases</span><strong><?= count($releases); ?></strong></div>
    <div class="stat"><span>Backup Records</span><strong><?= count($backups); ?></strong></div>
</div>

<div class="layout">
<aside>
<section class="card">
    <div class="head"><div><h2>Register New Release</h2><p>Record exact package identity before deployment.</p></div></div>
    <div class="body">
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= dsE($csrf); ?>">
            <input type="hidden" name="action" value="create_release">
            <div class="form-grid">
                <div class="field full"><label>Release Tag *</label><input class="control" name="release_tag" required placeholder="2026-09-09-r1"></div>
                <div class="field full"><label>Package Filename</label><input class="control" name="package_name" placeholder="TRAVSCOPE_release.zip"></div>
                <div class="field full"><label>Package SHA-256</label><input class="control" name="package_sha256" maxlength="64" placeholder="64 hex characters"></div>
                <div class="field full"><label>Release Notes</label><textarea class="control" name="notes" rows="4" placeholder="Files/features included"></textarea></div>
            </div>
            <button class="btn primary" type="submit" style="margin-top:8px;" <?= !tsDeployReady($pdo) ? 'disabled' : ''; ?>>Create Release</button>
        </form>
    </div>
</section>

<section class="card" style="margin-top:11px;">
    <div class="head"><div><h2>Release Registry</h2><p>Newest first.</p></div></div>
    <div class="body">
        <?php if (!$releases): ?><div class="empty">No deployment releases yet.</div><?php endif; ?>
        <?php foreach ($releases as $item): ?>
            <div class="release">
                <div style="display:flex;justify-content:space-between;gap:6px;">
                    <a href="<?= dsE(BASE_URL . 'admin-deployment-safety.php?release_id=' . (int)$item['id']); ?>">#<?= (int)$item['id']; ?> · <?= dsE((string)$item['release_tag']); ?></a>
                    <span class="pill <?= dsE(dsStatus((string)$item['status'])); ?>"><?= dsE(strtoupper((string)$item['status'])); ?></span>
                </div>
                <small><?= dsE((string)($item['package_name'] ?? 'No package filename')); ?><br><?= dsE(dsDate((string)$item['created_at'])); ?> · <?= dsE((string)($item['created_by_name'] ?? 'Admin')); ?></small>
            </div>
        <?php endforeach; ?>
    </div>
</section>
</aside>

<section>
<?php if (!$release): ?>
<div class="card"><div class="body"><div class="empty">Select or create a Deployment Release to open the safety workflow.</div></div></div>
<?php else: ?>
<section class="card">
    <div class="head">
        <div>
            <h2>Release #<?= (int)$release['id']; ?> · <?= dsE((string)$release['release_tag']); ?></h2>
            <p><?= dsE((string)($release['package_name'] ?? 'Package filename not registered')); ?> · Created <?= dsE(dsDate((string)$release['created_at'])); ?></p>
        </div>
        <span class="pill <?= dsE(dsStatus((string)$release['status'])); ?>"><?= dsE(strtoupper((string)$release['status'])); ?></span>
    </div>
    <div class="body">
        <div class="workflow">
            <div class="step">
                <strong>1 · Pre-Deployment Health</strong>
                <small>FAIL blocks Maintenance Mode. Warnings are recorded for Admin review.</small>
                <?php if (!empty($release['pre_health_json'])): ?><span class="pill <?= ($preHealth['fail'] ?? 0) > 0 ? 'bad' : 'good'; ?>" style="margin-top:6px;">Score <?= (int)($preHealth['score'] ?? 0); ?>% · Fail <?= (int)($preHealth['fail'] ?? 0); ?> · Warn <?= (int)($preHealth['warning'] ?? 0); ?></span><?php endif; ?>
                <?php $precheckAllowed = in_array((string)$release['status'], ['draft','precheck_ready'], true) || ((string)$release['status'] === 'failed' && empty($release['deployed_at'])); ?>
                <form method="post"><input type="hidden" name="csrf_token" value="<?= dsE($csrf); ?>"><input type="hidden" name="release_id" value="<?= (int)$release['id']; ?>"><input type="hidden" name="action" value="precheck"><button class="btn primary" type="submit" <?= !$precheckAllowed ? 'disabled' : ''; ?>>Run Precheck</button></form>
            </div>

            <div class="step">
                <strong>2 · Maintenance Mode</strong>
                <small>Reuses the existing Website Settings maintenance switch.</small>
                <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= dsE($csrf); ?>"><input type="hidden" name="release_id" value="<?= (int)$release['id']; ?>"><input type="hidden" name="action" value="start_maintenance">
                    <textarea class="control" name="maintenance_message" rows="2"><?= dsE((string)$maintenance['message']); ?></textarea>
                    <input class="control" name="confirm_text" placeholder="Type MAINTENANCE">
                    <button class="btn warn" type="submit" <?= (string)$release['status'] !== 'precheck_ready' ? 'disabled' : ''; ?>>Enable Maintenance</button>
                </form>
            </div>

            <div class="step">
                <strong>3 · Mark Code Deployed</strong>
                <small>This button does not upload code. Use it only after your hosting/File Manager deployment is complete.</small>
                <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= dsE($csrf); ?>"><input type="hidden" name="release_id" value="<?= (int)$release['id']; ?>"><input type="hidden" name="action" value="mark_deployed">
                    <input class="control" name="confirm_text" placeholder="Type DEPLOYED">
                    <button class="btn primary" type="submit" <?= (string)$release['status'] !== 'maintenance' ? 'disabled' : ''; ?>>Mark Deployed</button>
                </form>
            </div>

            <div class="step">
                <strong>4 · Post-Deployment Health</strong>
                <small>Passing scan marks Verified and turns Maintenance OFF. FAIL keeps Maintenance ON.</small>
                <?php if (!empty($release['post_health_json'])): ?><span class="pill <?= ($postHealth['fail'] ?? 0) > 0 ? 'bad' : 'good'; ?>" style="margin-top:6px;">Score <?= (int)($postHealth['score'] ?? 0); ?>% · Fail <?= (int)($postHealth['fail'] ?? 0); ?> · Warn <?= (int)($postHealth['warning'] ?? 0); ?></span><?php endif; ?>
                <?php $postcheckAllowed = (string)$release['status'] === 'deployed' || ((string)$release['status'] === 'failed' && !empty($release['deployed_at'])); ?>
                <form method="post"><input type="hidden" name="csrf_token" value="<?= dsE($csrf); ?>"><input type="hidden" name="release_id" value="<?= (int)$release['id']; ?>"><input type="hidden" name="action" value="postcheck"><button class="btn good" type="submit" <?= !$postcheckAllowed ? 'disabled' : ''; ?>>Verify Deployment</button></form>
            </div>
        </div>
    </div>
</section>

<section class="card" style="margin-top:11px;">
    <div class="head"><div><h2>Controlled Backup Downloads</h2><p>Generated on demand, registered by SHA-256, streamed to Admin, then deleted from server temp storage.</p></div></div>
    <div class="body">
        <div class="danger-note"><strong>Sensitive data:</strong> Database SQL backup can contain customer personal information, password hashes, tokens, financial data and internal supplier data. Store the downloaded file securely. TRAVSCOPE does not provide a one-click restore.</div>
        <div class="backup-grid" style="margin-top:8px;">
            <div class="backup">
                <h3>Application Database Table Backup</h3>
                <p>Exports current base-table CREATE statements + rows with foreign-key checks disabled during manual restore script execution. DB routines/triggers/events are not exported.</p>
                <form method="post" action="<?= dsE(BASE_URL . 'deployment-backup-download.php'); ?>">
                    <input type="hidden" name="csrf_token" value="<?= dsE($csrf); ?>"><input type="hidden" name="release_id" value="<?= (int)$release['id']; ?>"><input type="hidden" name="backup_type" value="database_sql">
                    <input class="control" name="confirm_text" placeholder="Type BACKUP" required>
                    <button class="btn primary" type="submit">Download SQL Backup</button>
                </form>
            </div>
            <div class="backup">
                <h3>Configuration Settings Backup</h3>
                <p>Exports the existing settings table as readable JSON. It does not export config.php, database passwords, SMTP passwords or server secrets.</p>
                <form method="post" action="<?= dsE(BASE_URL . 'deployment-backup-download.php'); ?>">
                    <input type="hidden" name="csrf_token" value="<?= dsE($csrf); ?>"><input type="hidden" name="release_id" value="<?= (int)$release['id']; ?>"><input type="hidden" name="backup_type" value="settings_json">
                    <input class="control" name="confirm_text" placeholder="Type BACKUP" required>
                    <button class="btn primary" type="submit">Download Settings JSON</button>
                </form>
            </div>
        </div>
    </div>
</section>

<section class="card" style="margin-top:11px;">
    <div class="head"><div><h2>Rollback Registry</h2><p>Metadata and audit only. No ZIP/SQL restore is executed by this page.</p></div></div>
    <div class="body">
        <div class="form-grid">
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= dsE($csrf); ?>"><input type="hidden" name="release_id" value="<?= (int)$release['id']; ?>"><input type="hidden" name="action" value="register_rollback">
                <div class="field"><label>Rollback Package Filename *</label><input class="control" name="rollback_package_name" value="<?= dsE((string)($release['rollback_package_name'] ?? '')); ?>" required></div>
                <div class="field"><label>Rollback Package SHA-256</label><input class="control" name="rollback_package_sha256" maxlength="64" value="<?= dsE((string)($release['rollback_package_sha256'] ?? '')); ?>"></div>
                <div class="field"><label>Registry Notes</label><textarea class="control" name="rollback_notes" rows="3"><?= dsE((string)($release['rollback_notes'] ?? '')); ?></textarea></div>
                <button class="btn" type="submit">Register Rollback Package</button>
            </form>

            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= dsE($csrf); ?>"><input type="hidden" name="release_id" value="<?= (int)$release['id']; ?>"><input type="hidden" name="action" value="record_rollback">
                <div class="field"><label>Manual Rollback Notes *</label><textarea class="control" name="rollback_notes" rows="3" required placeholder="What code/database/configuration was manually restored?"></textarea></div>
                <div class="field"><label>Confirmation</label><input class="control" name="confirm_text" placeholder="Type ROLLED BACK" required></div>
                <button class="btn bad" type="submit">Record Completed Manual Rollback</button>
            </form>
        </div>

        <?php if (!empty($maintenance['enabled'])): ?>
        <form method="post" style="margin-top:10px;padding-top:10px;border-top:1px solid #eef2f7;">
            <input type="hidden" name="csrf_token" value="<?= dsE($csrf); ?>"><input type="hidden" name="release_id" value="<?= (int)$release['id']; ?>"><input type="hidden" name="action" value="exit_maintenance">
            <div class="field"><label>Emergency Manual Maintenance Exit</label><input class="control" name="confirm_text" placeholder="Type EXIT" required></div>
            <button class="btn warn" type="submit">Manually Turn Maintenance OFF</button>
        </form>
        <?php endif; ?>
    </div>
</section>

<section class="card" style="margin-top:11px;">
    <div class="head"><div><h2>Release Event Timeline</h2><p>Immutable operational history for this release.</p></div></div>
    <div class="body" style="padding:0;">
        <?php if (!$events): ?><div class="empty" style="margin:11px;">No release events yet.</div><?php endif; ?>
        <?php foreach ($events as $event): ?>
            <div class="event">
                <strong><?= dsE((string)$event['event_type']); ?> · <?= dsE(strtoupper((string)$event['event_result'])); ?></strong>
                <small><?= dsE(dsDate((string)$event['created_at'])); ?> · <?= dsE((string)($event['admin_name'] ?? 'Admin')); ?><?php if ($event['health_score'] !== null): ?> · Health <?= (int)$event['health_score']; ?>% · Fail <?= (int)$event['fail_count']; ?> · Warn <?= (int)$event['warning_count']; ?><?php endif; ?></small>
            </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>
</section>
</div>

<section class="card" style="margin-top:11px;">
    <div class="head"><div><h2>Backup Registry</h2><p>Download metadata only. Backup file bytes are not retained by this module after streaming.</p></div></div>
    <div class="body">
        <?php if (!$backups): ?><div class="empty">No backup downloads registered yet.</div><?php else: ?>
        <div class="table-wrap"><table class="table"><thead><tr><th>ID</th><th>Release</th><th>Type</th><th>Filename</th><th>SHA-256</th><th>Size</th><th>Tables</th><th>Rows</th><th>Generated</th></tr></thead><tbody>
        <?php foreach ($backups as $b): ?><tr>
            <td>#<?= (int)$b['id']; ?></td><td><?= dsE((string)($b['release_tag'] ?? '-')); ?></td><td><?= dsE((string)$b['backup_type']); ?></td><td><?= dsE((string)$b['filename']); ?></td><td><code><?= dsE(substr((string)$b['sha256'],0,20)); ?>…</code></td><td><?= dsE(dsBytes((int)$b['file_size'])); ?></td><td><?= (int)$b['table_count']; ?></td><td><?= number_format((int)$b['row_count']); ?></td><td><?= dsE(dsDate((string)$b['generated_at'])); ?></td>
        </tr><?php endforeach; ?>
        </tbody></table></div>
        <?php endif; ?>
    </div>
</section>

<div class="notice warn">
    <strong>Restore policy:</strong> TRAVSCOPE intentionally does not expose a browser-based destructive restore button. Restore SQL/code only through your controlled hosting/database process after reviewing the exact release, hashes and backup contents.
</div>

</main>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
