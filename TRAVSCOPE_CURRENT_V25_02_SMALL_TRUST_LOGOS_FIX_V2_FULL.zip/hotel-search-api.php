<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/location-master-functions.php';
require_once __DIR__ . '/hotel-google-places-functions.php';

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
if (empty($_SESSION['admin_id'])) {
    http_response_code(401);
    echo json_encode(['success'=>false,'message'=>'Admin login required.']); exit;
}

$destinationId = max(0,(int)($_GET['destination_id']??0));
$q = trim((string)($_GET['q']??''));
$city = trim((string)($_GET['city']??''));
$state = trim((string)($_GET['state']??''));
$country = trim((string)($_GET['country']??''));
$includeGoogle = (string)($_GET['google']??'1') !== '0';
if (mb_strlen($q) < 2) {
    echo json_encode(['success'=>true,'internal'=>[],'google'=>[],'google_configured'=>tsHotelGoogleConfigured(),'message'=>'Type at least 2 characters.']); exit;
}
if (mb_strlen($q) > 120) $q = mb_substr($q,0,120);

try {
    if (function_exists('tsLocationEnsureSchema')) tsLocationEnsureSchema($pdo);
    $internal=[];
    if ($destinationId>0) {
        $params=[$destinationId,'%'.$q.'%','%'.$q.'%','%'.$q.'%','%'.$q.'%'];
        $where="h.destination_id=? AND h.status='active' AND (h.hotel_name LIKE ? OR h.city LIKE ? OR h.area LIKE ? OR h.address LIKE ?)";
        if ($city!=='') { $where.=" AND (LOWER(TRIM(COALESCE(h.geo_city,'')))=LOWER(TRIM(?)) OR LOWER(TRIM(COALESCE(h.city,'')))=LOWER(TRIM(?)) OR h.geo_city IS NULL OR h.geo_city='')"; $params[]=$city; $params[]=$city; }
        $sql="SELECT h.id,h.hotel_name,h.city,h.star_category,h.primary_image,h.address,h.area,h.pincode,h.phone,h.email,h.website,h.google_maps_url,h.latitude,h.longitude,h.google_place_id,h.google_rating,h.google_user_ratings_total,d.name destination_name
              FROM hotels h JOIN destinations d ON d.id=h.destination_id WHERE {$where}
              ORDER BY (LOWER(h.hotel_name)=LOWER(?)) DESC,h.is_preferred DESC,h.priority_order,h.hotel_name LIMIT 12";
        $params[]=$q;
        $st=$pdo->prepare($sql); $st->execute($params);
        foreach($st->fetchAll(PDO::FETCH_ASSOC)?:[] as $r){
            $internal[]=[
                'source'=>'internal','existing_id'=>(int)$r['id'],'place_id'=>(string)($r['google_place_id']??''),'name'=>(string)$r['hotel_name'],'address'=>(string)($r['address']??''),'area'=>(string)($r['area']??''),'city'=>(string)($r['city']??''),'pincode'=>(string)($r['pincode']??''),'phone'=>(string)($r['phone']??''),'email'=>(string)($r['email']??''),'website'=>(string)($r['website']??''),'google_maps_url'=>(string)($r['google_maps_url']??''),'latitude'=>$r['latitude']!==null?(float)$r['latitude']:null,'longitude'=>$r['longitude']!==null?(float)$r['longitude']:null,'rating'=>$r['google_rating']!==null?(float)$r['google_rating']:null,'rating_count'=>(int)($r['google_user_ratings_total']??0),'star'=>(int)$r['star_category'],'image'=>(function($p){$p=trim((string)$p);if($p==='')return '';return preg_match('~^https?://~i',$p)?$p:rtrim(BASE_URL,'/').'/'.ltrim($p,'/');})($r['primary_image']??''),'destination'=>(string)$r['destination_name']
            ];
        }
    }

    $google=[]; $googleError='';
    if ($includeGoogle && tsHotelGoogleConfigured()) {
        try {
            $google=tsHotelGoogleSearch($q,$city,$state,$country,8);
            if ($google) {
                $checkPlace=$pdo->prepare("SELECT id FROM hotels WHERE google_place_id=? AND google_place_id<>'' LIMIT 1");
                $checkName=$pdo->prepare("SELECT id FROM hotels WHERE destination_id=? AND LOWER(TRIM(hotel_name))=LOWER(TRIM(?)) AND (LOWER(TRIM(COALESCE(city,'')))=LOWER(TRIM(?)) OR ?='') LIMIT 1");
                foreach($google as &$g){
                    $existing=0;
                    if(!empty($g['place_id'])){$checkPlace->execute([$g['place_id']]);$existing=(int)($checkPlace->fetchColumn()?:0);}
                    if(!$existing && $destinationId>0){$checkName->execute([$destinationId,$g['name'],$city,$city]);$existing=(int)($checkName->fetchColumn()?:0);}
                    $g['existing_id']=$existing;
                    $g['photo_url']=!empty($g['photo_name'])?BASE_URL.'hotel-place-photo.php?name='.rawurlencode((string)$g['photo_name']):'';
                }
                unset($g);
            }
        } catch(Throwable $ge) { $googleError=$ge->getMessage(); }
    }

    echo json_encode(['success'=>true,'internal'=>$internal,'google'=>$google,'google_configured'=>tsHotelGoogleConfigured(),'google_error'=>$googleError],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
} catch(Throwable $e){
    error_log('Hotel Search API: '.$e->getMessage());
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>'Unable to search hotels right now.']);
}
