<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — CUSTOMER + SUPPLIER MASTER DATA CONSOLIDATION
|--------------------------------------------------------------------------
|
| Duplicate detection is advisory.
| Merge execution is explicit, transactional and audited.
| Source master rows are deactivated, never deleted.
| Historical commercial supplier references are intentionally preserved.
|
*/

$masterAclFile = __DIR__ . '/access-control-functions.php';
if (
    is_file($masterAclFile)
    && !function_exists('tsAclCan')
) {
    require_once $masterAclFile;
}


function tsMasterTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];

    $key = strtolower($table);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
              AND table_name = ?
        ");
        $stmt->execute([$table]);

        return $cache[$key] =
            ((int)$stmt->fetchColumn() > 0);

    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}


function tsMasterColumnExists(
    PDO $pdo,
    string $table,
    string $column
): bool {
    static $cache = [];

    $key = strtolower($table . '.' . $column);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    if (
        !preg_match('/^[A-Za-z0-9_]+$/', $table)
        || !preg_match('/^[A-Za-z0-9_]+$/', $column)
    ) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = DATABASE()
              AND table_name = ?
              AND column_name = ?
        ");
        $stmt->execute([
            $table,
            $column
        ]);

        return $cache[$key] =
            ((int)$stmt->fetchColumn() > 0);

    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}


function tsMasterReady(PDO $pdo): bool
{
    return
        tsMasterTableExists($pdo, 'master_data_merge_cases')
        && tsMasterTableExists($pdo, 'master_data_aliases')
        && tsMasterTableExists($pdo, 'master_data_merge_audit');
}


function tsMasterEmail(string $value): string
{
    return
        strtolower(
            trim($value)
        );
}


function tsMasterPhone(string $value): string
{
    $digits =
        preg_replace(
            '/[^0-9]/',
            '',
            $value
        );

    if (!is_string($digits)) {
        return '';
    }

    return
        strlen($digits) >= 10
            ? substr($digits, -10)
            : $digits;
}


function tsMasterText(string $value): string
{
    $value =
        mb_strtolower(
            trim($value)
        );

    $value =
        preg_replace(
            '/[^a-z0-9]+/u',
            ' ',
            $value
        );

    return
        trim(
            preg_replace(
                '/\s+/u',
                ' ',
                (string)$value
            )
        );
}


function tsMasterAliasMap(
    PDO $pdo,
    string $entityType
): array {
    if (!tsMasterReady($pdo)) {
        return [];
    }

    try {
        $stmt = $pdo->prepare("
            SELECT alias_id, canonical_id
            FROM master_data_aliases
            WHERE entity_type = ?
              AND is_active = 1
        ");
        $stmt->execute([$entityType]);

        $map = [];

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $map[(int)$row['alias_id']] =
                (int)$row['canonical_id'];
        }

        return $map;

    } catch (Throwable $e) {
        return [];
    }
}



function tsMasterClosedPairMap(
    PDO $pdo,
    string $entityType
): array {
    if (!tsMasterReady($pdo)) {
        return [];
    }

    try {
        $stmt =
            $pdo->prepare("
                SELECT
                    source_id,
                    canonical_id,
                    status
                FROM master_data_merge_cases
                WHERE entity_type = ?
                  AND status IN (
                        'merged',
                        'rejected'
                      )
            ");

        $stmt->execute([$entityType]);

        $map = [];

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $a =
                (int)$row['source_id'];

            $b =
                (int)$row['canonical_id'];

            $key =
                min($a, $b)
                . ':'
                . max($a, $b);

            $map[$key] =
                (string)$row['status'];
        }

        return $map;

    } catch (Throwable $e) {
        return [];
    }
}


function tsMasterCustomerCandidates(PDO $pdo): array
{
    if (!tsMasterTableExists($pdo, 'users')) {
        return [];
    }

    try {
        $stmt = $pdo->query("
            SELECT
                id,
                full_name,
                email,
                mobile,
                country,
                status,
                email_verified,
                created_at,
                last_login
            FROM users
            ORDER BY id ASC
            LIMIT 10000
        ");

        $rows =
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: [];

    } catch (Throwable $e) {
        return [];
    }

    $aliases =
        tsMasterAliasMap(
            $pdo,
            'customer'
        );

    $pairs = [];
    $emailMap = [];
    $phoneMap = [];
    $nameMap = [];

    foreach ($rows as $row) {
        $id = (int)$row['id'];

        if (isset($aliases[$id])) {
            continue;
        }

        $email =
            tsMasterEmail(
                (string)($row['email'] ?? '')
            );

        $phone =
            tsMasterPhone(
                (string)($row['mobile'] ?? '')
            );

        $nameKey =
            tsMasterText(
                (string)($row['full_name'] ?? '')
            )
            . '|'
            . tsMasterText(
                (string)($row['country'] ?? '')
            );

        if (
            $email !== ''
            && !str_ends_with(
                $email,
                '@travscope.local'
            )
        ) {
            $emailMap[$email][] =
                $row;
        }

        if (strlen($phone) >= 7) {
            $phoneMap[$phone][] =
                $row;
        }

        if (
            trim($nameKey, '|') !== ''
            && tsMasterText(
                (string)($row['full_name'] ?? '')
            ) !== ''
        ) {
            $nameMap[$nameKey][] =
                $row;
        }
    }

    $addPair =
        static function (
            array &$pairs,
            array $a,
            array $b,
            string $reason,
            int $score
        ): void {
            $id1 = (int)$a['id'];
            $id2 = (int)$b['id'];

            if ($id1 === $id2) {
                return;
            }

            $left =
                min($id1, $id2);

            $right =
                max($id1, $id2);

            $key =
                $left . ':' . $right;

            if (!isset($pairs[$key])) {
                $pairs[$key] = [
                    'left' =>
                        $id1 === $left
                            ? $a
                            : $b,
                    'right' =>
                        $id1 === $left
                            ? $b
                            : $a,
                    'score' => 0,
                    'reasons' => [],
                ];
            }

            $pairs[$key]['score'] =
                min(
                    100,
                    max(
                        (int)$pairs[$key]['score'],
                        $score
                    )
                    + (
                        in_array(
                            $reason,
                            $pairs[$key]['reasons'],
                            true
                        )
                            ? 0
                            : 3
                    )
                );

            if (
                !in_array(
                    $reason,
                    $pairs[$key]['reasons'],
                    true
                )
            ) {
                $pairs[$key]['reasons'][] =
                    $reason;
            }
        };

    foreach ($emailMap as $group) {
        if (count($group) < 2) {
            continue;
        }

        for ($i = 0; $i < count($group); $i++) {
            for ($j = $i + 1; $j < count($group); $j++) {
                $addPair(
                    $pairs,
                    $group[$i],
                    $group[$j],
                    'Exact email',
                    96
                );
            }
        }
    }

    foreach ($phoneMap as $group) {
        if (count($group) < 2) {
            continue;
        }

        for ($i = 0; $i < count($group); $i++) {
            for ($j = $i + 1; $j < count($group); $j++) {
                $addPair(
                    $pairs,
                    $group[$i],
                    $group[$j],
                    'Normalized mobile',
                    92
                );
            }
        }
    }

    foreach ($nameMap as $group) {
        if (count($group) < 2) {
            continue;
        }

        for ($i = 0; $i < count($group); $i++) {
            for ($j = $i + 1; $j < count($group); $j++) {
                $addPair(
                    $pairs,
                    $group[$i],
                    $group[$j],
                    'Same name + country',
                    66
                );
            }
        }
    }

    $closedPairs =
        tsMasterClosedPairMap(
            $pdo,
            'customer'
        );

    foreach (
        array_keys($pairs)
        as $pairKey
    ) {
        if (isset($closedPairs[$pairKey])) {
            unset($pairs[$pairKey]);
        }
    }

    $closedPairs =
        tsMasterClosedPairMap(
            $pdo,
            'supplier'
        );

    foreach (
        array_keys($pairs)
        as $pairKey
    ) {
        if (isset($closedPairs[$pairKey])) {
            unset($pairs[$pairKey]);
        }
    }

    $result =
        array_values($pairs);

    usort(
        $result,
        static fn($a, $b) =>
            ((int)$b['score'])
            <=>
            ((int)$a['score'])
    );

    return
        array_slice(
            $result,
            0,
            250
        );
}


function tsMasterSupplierCandidates(PDO $pdo): array
{
    if (!tsMasterTableExists($pdo, 'suppliers')) {
        return [];
    }

    $contactJoin =
        tsMasterTableExists(
            $pdo,
            'supplier_contacts'
        )
            ? "
                LEFT JOIN supplier_contacts c
                    ON c.supplier_id = s.id
                   AND c.status = 'active'
              "
            : '';

    $contactSelect =
        tsMasterTableExists(
            $pdo,
            'supplier_contacts'
        )
            ? "
                MAX(
                    CASE
                        WHEN c.is_primary = 1
                        THEN c.email
                    END
                ) AS primary_email,
                MAX(
                    CASE
                        WHEN c.is_primary = 1
                        THEN c.mobile
                    END
                ) AS primary_mobile
              "
            : "
                NULL AS primary_email,
                NULL AS primary_mobile
              ";

    try {
        $stmt = $pdo->query("
            SELECT
                s.id,
                s.supplier_code,
                s.company_name,
                s.legal_name,
                s.gstin,
                s.tax_id,
                s.country,
                s.state_region,
                s.city,
                s.status,
                s.priority,
                s.internal_rating,
                {$contactSelect}
            FROM suppliers s
            {$contactJoin}
            GROUP BY
                s.id,
                s.supplier_code,
                s.company_name,
                s.legal_name,
                s.gstin,
                s.tax_id,
                s.country,
                s.state_region,
                s.city,
                s.status,
                s.priority,
                s.internal_rating
            ORDER BY s.id ASC
            LIMIT 10000
        ");

        $rows =
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: [];

    } catch (Throwable $e) {
        return [];
    }

    $aliases =
        tsMasterAliasMap(
            $pdo,
            'supplier'
        );

    $pairs = [];
    $maps = [
        'gstin' => [],
        'tax' => [],
        'email' => [],
        'phone' => [],
        'name_location' => [],
    ];

    foreach ($rows as $row) {
        $id = (int)$row['id'];

        if (isset($aliases[$id])) {
            continue;
        }

        $gst =
            strtoupper(
                preg_replace(
                    '/[^A-Z0-9]/i',
                    '',
                    (string)($row['gstin'] ?? '')
                )
            );

        $tax =
            strtoupper(
                preg_replace(
                    '/[^A-Z0-9]/i',
                    '',
                    (string)($row['tax_id'] ?? '')
                )
            );

        $email =
            tsMasterEmail(
                (string)($row['primary_email'] ?? '')
            );

        $phone =
            tsMasterPhone(
                (string)($row['primary_mobile'] ?? '')
            );

        $nameLocation =
            tsMasterText(
                (string)$row['company_name']
            )
            . '|'
            . tsMasterText(
                (string)($row['city'] ?? '')
            )
            . '|'
            . tsMasterText(
                (string)($row['country'] ?? '')
            );

        if ($gst !== '') {
            $maps['gstin'][$gst][] =
                $row;
        }

        if ($tax !== '') {
            $maps['tax'][$tax][] =
                $row;
        }

        if ($email !== '') {
            $maps['email'][$email][] =
                $row;
        }

        if (strlen($phone) >= 7) {
            $maps['phone'][$phone][] =
                $row;
        }

        if (
            tsMasterText(
                (string)$row['company_name']
            ) !== ''
        ) {
            $maps['name_location'][$nameLocation][] =
                $row;
        }
    }

    $rules = [
        'gstin' => ['Exact GSTIN', 100],
        'tax' => ['Exact Tax ID', 98],
        'email' => ['Exact primary email', 94],
        'phone' => ['Normalized primary mobile', 90],
        'name_location' => ['Same company + location', 72],
    ];

    foreach ($maps as $type => $groups) {
        foreach ($groups as $group) {
            if (count($group) < 2) {
                continue;
            }

            for ($i = 0; $i < count($group); $i++) {
                for ($j = $i + 1; $j < count($group); $j++) {
                    $a = $group[$i];
                    $b = $group[$j];

                    $left =
                        min(
                            (int)$a['id'],
                            (int)$b['id']
                        );

                    $right =
                        max(
                            (int)$a['id'],
                            (int)$b['id']
                        );

                    $key =
                        $left . ':' . $right;

                    if (!isset($pairs[$key])) {
                        $pairs[$key] = [
                            'left' =>
                                (int)$a['id'] === $left
                                    ? $a
                                    : $b,
                            'right' =>
                                (int)$a['id'] === $left
                                    ? $b
                                    : $a,
                            'score' => 0,
                            'reasons' => [],
                        ];
                    }

                    [$reason, $score] =
                        $rules[$type];

                    $pairs[$key]['score'] =
                        min(
                            100,
                            max(
                                (int)$pairs[$key]['score'],
                                $score
                            )
                            + (
                                in_array(
                                    $reason,
                                    $pairs[$key]['reasons'],
                                    true
                                )
                                    ? 0
                                    : 2
                            )
                        );

                    if (
                        !in_array(
                            $reason,
                            $pairs[$key]['reasons'],
                            true
                        )
                    ) {
                        $pairs[$key]['reasons'][] =
                            $reason;
                    }
                }
            }
        }
    }

    $result =
        array_values($pairs);

    usort(
        $result,
        static fn($a, $b) =>
            ((int)$b['score'])
            <=>
            ((int)$a['score'])
    );

    return
        array_slice(
            $result,
            0,
            250
        );
}


function tsMasterEntity(
    PDO $pdo,
    string $entityType,
    int $id
): ?array {
    if ($id <= 0) {
        return null;
    }

    if ($entityType === 'customer') {
        $stmt = $pdo->prepare("
            SELECT
                id,
                full_name,
                email,
                mobile,
                country,
                profile_image,
                email_verified,
                status,
                created_at,
                last_login
            FROM users
            WHERE id = ?
            LIMIT 1
        ");

    } elseif ($entityType === 'supplier') {
        $stmt = $pdo->prepare("
            SELECT *
            FROM suppliers
            WHERE id = ?
            LIMIT 1
        ");

    } else {
        return null;
    }

    $stmt->execute([$id]);

    return
        $stmt->fetch(PDO::FETCH_ASSOC)
        ?: null;
}


function tsMasterAudit(
    PDO $pdo,
    int $caseId,
    string $entityType,
    string $actionKey,
    ?string $tableName,
    int $affectedRows,
    array $details,
    int $adminId
): void {
    $stmt = $pdo->prepare("
        INSERT INTO master_data_merge_audit
        (
            merge_case_id,
            entity_type,
            action_key,
            table_name,
            affected_rows,
            details_json,
            admin_id
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $caseId,
        $entityType,
        mb_substr($actionKey, 0, 100),
        $tableName !== null
            ? mb_substr($tableName, 0, 100)
            : null,
        max(0, $affectedRows),
        $details
            ? json_encode(
                $details,
                JSON_UNESCAPED_UNICODE
                | JSON_UNESCAPED_SLASHES
            )
            : null,
        $adminId > 0
            ? $adminId
            : null,
    ]);
}


function tsMasterEnsureCase(
    PDO $pdo,
    string $entityType,
    int $sourceId,
    int $canonicalId,
    int $score,
    string $reason,
    string $reviewNote,
    int $adminId
): int {
    if (!tsMasterReady($pdo)) {
        throw new RuntimeException(
            'Import the Master Data Consolidation SQL first.'
        );
    }

    $stmt = $pdo->prepare("
        SELECT id
        FROM master_data_merge_cases
        WHERE entity_type = ?
          AND source_id = ?
          AND canonical_id = ?
        LIMIT 1
    ");
    $stmt->execute([
        $entityType,
        $sourceId,
        $canonicalId
    ]);

    $existing =
        (int)(
            $stmt->fetchColumn()
            ?: 0
        );

    if ($existing > 0) {
        $pdo->prepare("
            UPDATE master_data_merge_cases
            SET
                confidence_score = ?,
                match_reason = ?,
                review_note = ?,
                updated_at = NOW()
            WHERE id = ?
        ")->execute([
            max(0, min(100, $score)),
            $reason !== ''
                ? mb_substr($reason, 0, 1000)
                : null,
            $reviewNote !== ''
                ? $reviewNote
                : null,
            $existing
        ]);

        return $existing;
    }

    $stmt = $pdo->prepare("
        INSERT INTO master_data_merge_cases
        (
            entity_type,
            source_id,
            canonical_id,
            confidence_score,
            match_reason,
            status,
            review_note,
            created_by_admin_id
        )
        VALUES (?, ?, ?, ?, ?, 'open', ?, ?)
    ");

    $stmt->execute([
        $entityType,
        $sourceId,
        $canonicalId,
        max(0, min(100, $score)),
        $reason !== ''
            ? mb_substr($reason, 0, 1000)
            : null,
        $reviewNote !== ''
            ? $reviewNote
            : null,
        $adminId > 0
            ? $adminId
            : null
    ]);

    return
        (int)$pdo->lastInsertId();
}


function tsMasterUpdateReference(
    PDO $pdo,
    int $caseId,
    string $entityType,
    string $table,
    string $column,
    int $sourceId,
    int $canonicalId,
    int $adminId
): int {
    if (
        !tsMasterTableExists($pdo, $table)
        || !tsMasterColumnExists(
            $pdo,
            $table,
            $column
        )
    ) {
        return 0;
    }

    $sql =
        "UPDATE `{$table}`
         SET `{$column}` = ?
         WHERE `{$column}` = ?";

    $stmt =
        $pdo->prepare($sql);

    $stmt->execute([
        $canonicalId,
        $sourceId
    ]);

    $rows =
        $stmt->rowCount();

    tsMasterAudit(
        $pdo,
        $caseId,
        $entityType,
        'reassign_reference',
        $table,
        $rows,
        [
            'column' => $column,
            'from_id' => $sourceId,
            'to_id' => $canonicalId,
        ],
        $adminId
    );

    return $rows;
}


function tsMasterFillBlankFields(
    PDO $pdo,
    string $table,
    int $sourceId,
    int $canonicalId,
    array $fields,
    string $idColumn = 'id'
): array {
    if (
        !tsMasterTableExists($pdo, $table)
        || !tsMasterColumnExists(
            $pdo,
            $table,
            $idColumn
        )
    ) {
        return [];
    }

    $usable =
        array_values(
            array_filter(
                $fields,
                static fn($field) =>
                    is_string($field)
                    && preg_match(
                        '/^[A-Za-z0-9_]+$/',
                        $field
                    )
            )
        );

    $usable =
        array_values(
            array_filter(
                $usable,
                static fn($field) =>
                    tsMasterColumnExists(
                        $pdo,
                        $table,
                        $field
                    )
            )
        );

    if (!$usable) {
        return [];
    }

    $columnSql =
        implode(
            ', ',
            array_map(
                static fn($field) =>
                    "`{$field}`",
                $usable
            )
        );

    $stmt =
        $pdo->prepare("
            SELECT
                `{$idColumn}`,
                {$columnSql}
            FROM `{$table}`
            WHERE `{$idColumn}` IN (?, ?)
        ");

    $stmt->execute([
        $sourceId,
        $canonicalId
    ]);

    $rows = [];

    foreach (
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        ?: []
        as $row
    ) {
        $rows[(int)$row[$idColumn]] =
            $row;
    }

    $source =
        $rows[$sourceId]
        ?? null;

    $target =
        $rows[$canonicalId]
        ?? null;

    if (
        !$source
        || !$target
    ) {
        return [];
    }

    $updates = [];
    $params = [];
    $filled = [];

    foreach ($usable as $field) {
        $targetValue =
            trim(
                (string)(
                    $target[$field]
                    ?? ''
                )
            );

        $sourceValue =
            trim(
                (string)(
                    $source[$field]
                    ?? ''
                )
            );

        if (
            $targetValue === ''
            && $sourceValue !== ''
        ) {
            $updates[] =
                "`{$field}` = ?";

            $params[] =
                $source[$field];

            $filled[] =
                $field;
        }
    }

    if (!$updates) {
        return [];
    }

    $params[] =
        $canonicalId;

    $stmt =
        $pdo->prepare(
            "UPDATE `{$table}`
             SET "
             . implode(', ', $updates)
             . "
             WHERE `{$idColumn}` = ?"
        );

    $stmt->execute($params);

    return $filled;
}


function tsMasterCreateAlias(
    PDO $pdo,
    string $entityType,
    int $sourceId,
    int $canonicalId,
    int $caseId,
    int $adminId
): void {
    $stmt = $pdo->prepare("
        SELECT canonical_id
        FROM master_data_aliases
        WHERE entity_type = ?
          AND alias_id = ?
        LIMIT 1
        FOR UPDATE
    ");
    $stmt->execute([
        $entityType,
        $sourceId
    ]);

    $existing =
        (int)(
            $stmt->fetchColumn()
            ?: 0
        );

    if (
        $existing > 0
        && $existing !== $canonicalId
    ) {
        throw new RuntimeException(
            'This source record is already mapped to another canonical master.'
        );
    }

    $stmt = $pdo->prepare("
        INSERT INTO master_data_aliases
        (
            entity_type,
            alias_id,
            canonical_id,
            merge_case_id,
            is_active,
            created_by_admin_id
        )
        VALUES (?, ?, ?, ?, 1, ?)
        ON DUPLICATE KEY UPDATE
            canonical_id = VALUES(canonical_id),
            merge_case_id = VALUES(merge_case_id),
            is_active = 1,
            updated_at = NOW()
    ");

    $stmt->execute([
        $entityType,
        $sourceId,
        $canonicalId,
        $caseId,
        $adminId > 0
            ? $adminId
            : null
    ]);
}



function tsMasterAliasCanonical(
    PDO $pdo,
    string $entityType,
    int $aliasId
): ?int {
    if (
        !tsMasterReady($pdo)
        || $aliasId <= 0
    ) {
        return null;
    }

    $stmt =
        $pdo->prepare("
            SELECT canonical_id
            FROM master_data_aliases
            WHERE entity_type = ?
              AND alias_id = ?
              AND is_active = 1
            LIMIT 1
        ");

    $stmt->execute([
        $entityType,
        $aliasId
    ]);

    $value =
        (int)(
            $stmt->fetchColumn()
            ?: 0
        );

    return
        $value > 0
            ? $value
            : null;
}


function tsMasterMergeCustomer(
    PDO $pdo,
    int $sourceId,
    int $canonicalId,
    int $score,
    string $reason,
    string $reviewNote,
    int $adminId
): array {
    if (
        $sourceId <= 0
        || $canonicalId <= 0
        || $sourceId === $canonicalId
    ) {
        throw new RuntimeException(
            'Select two different Customer records.'
        );
    }

    if (!tsMasterReady($pdo)) {
        throw new RuntimeException(
            'Import the Master Data Consolidation SQL first.'
        );
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire(
            $pdo,
            $adminId,
            'manage_access',
            'merge_customer_master',
            'customer',
            $canonicalId,
            [
                'source_customer_id' =>
                    $sourceId,
                'canonical_customer_id' =>
                    $canonicalId,
            ]
        );
    }

    $pdo->beginTransaction();

    try {
        $sourceStmt =
            $pdo->prepare("
                SELECT *
                FROM users
                WHERE id = ?
                LIMIT 1
                FOR UPDATE
            ");

        $sourceStmt->execute([$sourceId]);

        $source =
            $sourceStmt->fetch(PDO::FETCH_ASSOC)
            ?: null;

        $sourceStmt->execute([$canonicalId]);

        $canonical =
            $sourceStmt->fetch(PDO::FETCH_ASSOC)
            ?: null;

        if (!$source || !$canonical) {
            throw new RuntimeException(
                'Customer source/canonical record was not found.'
            );
        }

        $existingSourceCanonical =
            tsMasterAliasCanonical(
                $pdo,
                'customer',
                $sourceId
            );

        if ($existingSourceCanonical) {
            throw new RuntimeException(
                'Source Customer is already consolidated into canonical Customer #'
                . $existingSourceCanonical
                . '.'
            );
        }

        $canonicalAlias =
            tsMasterAliasCanonical(
                $pdo,
                'customer',
                $canonicalId
            );

        if ($canonicalAlias) {
            throw new RuntimeException(
                'Selected canonical Customer is itself an alias. Use final canonical Customer #'
                . $canonicalAlias
                . '.'
            );
        }

        if (
            strtolower(
                (string)(
                    $canonical['status']
                    ?? ''
                )
            ) !== 'active'
        ) {
            throw new RuntimeException(
                'Canonical Customer must be Active before merge.'
            );
        }

        $caseId =
            tsMasterEnsureCase(
                $pdo,
                'customer',
                $sourceId,
                $canonicalId,
                $score,
                $reason,
                $reviewNote,
                $adminId
            );

        tsMasterAudit(
            $pdo,
            $caseId,
            'customer',
            'before_snapshot',
            'users',
            0,
            [
                'source' => $source,
                'canonical' => $canonical,
            ],
            $adminId
        );

        $filled =
            tsMasterFillBlankFields(
                $pdo,
                'users',
                $sourceId,
                $canonicalId,
                [
                    'full_name',
                    'mobile',
                    'country',
                    'profile_image',
                ]
            );

        if ($filled) {
            tsMasterAudit(
                $pdo,
                $caseId,
                'customer',
                'fill_blank_canonical_fields',
                'users',
                count($filled),
                [
                    'fields' => $filled,
                ],
                $adminId
            );
        }

        /*
        | Core ownership/history references that should follow the canonical
        | Customer account.
        |
        | Actor/audit columns such as created_by_user_id are intentionally NOT
        | rewritten.
        */
        $references = [
            ['bookings', 'user_id'],
            ['booking_cancellations', 'user_id'],
            ['reviews', 'user_id'],
            ['repeat_sales_opportunities', 'customer_user_id'],
            ['booking_travellers', 'source_user_id'],
            ['user_travel_documents', 'user_id'],
            ['user_family_members', 'owner_user_id'],
        ];

        $moved = [];

        foreach ($references as [$table, $column]) {
            $moved[$table . '.' . $column] =
                tsMasterUpdateReference(
                    $pdo,
                    $caseId,
                    'customer',
                    $table,
                    $column,
                    $sourceId,
                    $canonicalId,
                    $adminId
                );
        }

        /*
        | Travel profile:
        | move the whole profile only when canonical has none.
        | If both have profiles, preserve source row for human review.
        */
        $profileConflict = false;

        if (
            tsMasterTableExists(
                $pdo,
                'user_travel_profiles'
            )
            && tsMasterColumnExists(
                $pdo,
                'user_travel_profiles',
                'user_id'
            )
        ) {
            $stmt =
                $pdo->prepare("
                    SELECT user_id
                    FROM user_travel_profiles
                    WHERE user_id IN (?, ?)
                ");

            $stmt->execute([
                $sourceId,
                $canonicalId
            ]);

            $ids =
                array_map(
                    'intval',
                    $stmt->fetchAll(
                        PDO::FETCH_COLUMN
                    )
                    ?: []
                );

            $sourceHas =
                in_array(
                    $sourceId,
                    $ids,
                    true
                );

            $targetHas =
                in_array(
                    $canonicalId,
                    $ids,
                    true
                );

            if (
                $sourceHas
                && !$targetHas
            ) {
                $moved['user_travel_profiles.user_id'] =
                    tsMasterUpdateReference(
                        $pdo,
                        $caseId,
                        'customer',
                        'user_travel_profiles',
                        'user_id',
                        $sourceId,
                        $canonicalId,
                        $adminId
                    );

            } elseif (
                $sourceHas
                && $targetHas
            ) {
                $profileConflict = true;

                tsMasterAudit(
                    $pdo,
                    $caseId,
                    'customer',
                    'profile_conflict_preserved',
                    'user_travel_profiles',
                    0,
                    [
                        'message' =>
                            'Both source and canonical Customer have Travel Profile rows. Source profile was preserved for manual comparison.',
                    ],
                    $adminId
                );
            }
        }

        /*
        | Family links:
        | copy relationships to canonical with INSERT IGNORE.
        | Original source rows remain as historical master-data evidence.
        */
        $familyCopied = 0;

        if (
            tsMasterTableExists(
                $pdo,
                'user_family_links'
            )
        ) {
            $stmt =
                $pdo->prepare("
                    SELECT
                        user_id,
                        linked_user_id,
                        relationship,
                        relationship_notes
                    FROM user_family_links
                    WHERE user_id = ?
                       OR linked_user_id = ?
                ");

            $stmt->execute([
                $sourceId,
                $sourceId
            ]);

            $insert =
                $pdo->prepare("
                    INSERT IGNORE INTO user_family_links
                    (
                        user_id,
                        linked_user_id,
                        relationship,
                        relationship_notes
                    )
                    VALUES (?, ?, ?, ?)
                ");

            foreach (
                $stmt->fetchAll(PDO::FETCH_ASSOC)
                ?: []
                as $row
            ) {
                $userId =
                    (int)$row['user_id'];

                $linkedUserId =
                    (int)$row['linked_user_id'];

                if ($userId === $sourceId) {
                    $userId = $canonicalId;
                }

                if ($linkedUserId === $sourceId) {
                    $linkedUserId = $canonicalId;
                }

                if (
                    $userId <= 0
                    || $linkedUserId <= 0
                    || $userId === $linkedUserId
                ) {
                    continue;
                }

                $insert->execute([
                    $userId,
                    $linkedUserId,
                    (string)$row['relationship'],
                    $row['relationship_notes']
                        ?: null,
                ]);

                $familyCopied +=
                    $insert->rowCount();
            }

            tsMasterAudit(
                $pdo,
                $caseId,
                'customer',
                'copy_family_links',
                'user_family_links',
                $familyCopied,
                [
                    'source_rows_preserved' => true,
                ],
                $adminId
            );
        }

        /*
        | Email/login identity:
        | never overwrite canonical email/password during automatic merge.
        */
        $differentEmail =
            tsMasterEmail(
                (string)($source['email'] ?? '')
            ) !== ''
            && tsMasterEmail(
                (string)($canonical['email'] ?? '')
            ) !== ''
            && tsMasterEmail(
                (string)$source['email']
            ) !== tsMasterEmail(
                (string)$canonical['email']
            );

        if ($differentEmail) {
            tsMasterAudit(
                $pdo,
                $caseId,
                'customer',
                'alternate_login_email_preserved',
                'users',
                0,
                [
                    'source_email' =>
                        (string)$source['email'],
                    'canonical_email' =>
                        (string)$canonical['email'],
                    'message' =>
                        'Source email was not copied over canonical login email.',
                ],
                $adminId
            );
        }

        tsMasterCreateAlias(
            $pdo,
            'customer',
            $sourceId,
            $canonicalId,
            $caseId,
            $adminId
        );

        $stmt =
            $pdo->prepare("
                UPDATE users
                SET status = 'inactive'
                WHERE id = ?
            ");

        $stmt->execute([$sourceId]);

        tsMasterAudit(
            $pdo,
            $caseId,
            'customer',
            'deactivate_duplicate_master',
            'users',
            $stmt->rowCount(),
            [
                'source_id' => $sourceId,
                'canonical_id' => $canonicalId,
            ],
            $adminId
        );

        $summary = [
            'source_customer_id' =>
                $sourceId,
            'canonical_customer_id' =>
                $canonicalId,
            'moved_references' =>
                $moved,
            'family_links_copied' =>
                $familyCopied,
            'travel_profile_conflict' =>
                $profileConflict,
            'alternate_login_email' =>
                $differentEmail,
            'source_deactivated' =>
                true,
        ];

        $pdo->prepare("
            UPDATE master_data_merge_cases
            SET
                status = 'merged',
                merged_by_admin_id = ?,
                merged_at = NOW(),
                merge_summary_json = ?,
                updated_at = NOW()
            WHERE id = ?
        ")->execute([
            $adminId,
            json_encode(
                $summary,
                JSON_UNESCAPED_UNICODE
                | JSON_UNESCAPED_SLASHES
            ),
            $caseId
        ]);

        $pdo->commit();

        return [
            'case_id' => $caseId,
            'summary' => $summary,
        ];

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $e;
    }
}


function tsMasterMergeSupplier(
    PDO $pdo,
    int $sourceId,
    int $canonicalId,
    int $score,
    string $reason,
    string $reviewNote,
    int $adminId
): array {
    if (
        $sourceId <= 0
        || $canonicalId <= 0
        || $sourceId === $canonicalId
    ) {
        throw new RuntimeException(
            'Select two different Supplier records.'
        );
    }

    if (!tsMasterReady($pdo)) {
        throw new RuntimeException(
            'Import the Master Data Consolidation SQL first.'
        );
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire(
            $pdo,
            $adminId,
            'manage_access',
            'merge_supplier_master',
            'supplier',
            $canonicalId,
            [
                'source_supplier_id' =>
                    $sourceId,
                'canonical_supplier_id' =>
                    $canonicalId,
            ]
        );
    }

    $pdo->beginTransaction();

    try {
        $stmt =
            $pdo->prepare("
                SELECT *
                FROM suppliers
                WHERE id = ?
                LIMIT 1
                FOR UPDATE
            ");

        $stmt->execute([$sourceId]);

        $source =
            $stmt->fetch(PDO::FETCH_ASSOC)
            ?: null;

        $stmt->execute([$canonicalId]);

        $canonical =
            $stmt->fetch(PDO::FETCH_ASSOC)
            ?: null;

        if (!$source || !$canonical) {
            throw new RuntimeException(
                'Supplier source/canonical record was not found.'
            );
        }

        $existingSourceCanonical =
            tsMasterAliasCanonical(
                $pdo,
                'supplier',
                $sourceId
            );

        if ($existingSourceCanonical) {
            throw new RuntimeException(
                'Source Supplier is already consolidated into canonical Supplier #'
                . $existingSourceCanonical
                . '.'
            );
        }

        $canonicalAlias =
            tsMasterAliasCanonical(
                $pdo,
                'supplier',
                $canonicalId
            );

        if ($canonicalAlias) {
            throw new RuntimeException(
                'Selected canonical Supplier is itself an alias. Use final canonical Supplier #'
                . $canonicalAlias
                . '.'
            );
        }

        if (
            strtolower(
                (string)(
                    $canonical['status']
                    ?? ''
                )
            ) !== 'active'
        ) {
            throw new RuntimeException(
                'Canonical Supplier must be Active before merge.'
            );
        }

        $caseId =
            tsMasterEnsureCase(
                $pdo,
                'supplier',
                $sourceId,
                $canonicalId,
                $score,
                $reason,
                $reviewNote,
                $adminId
            );

        tsMasterAudit(
            $pdo,
            $caseId,
            'supplier',
            'before_snapshot',
            'suppliers',
            0,
            [
                'source' => $source,
                'canonical' => $canonical,
            ],
            $adminId
        );

        $filled =
            tsMasterFillBlankFields(
                $pdo,
                'suppliers',
                $sourceId,
                $canonicalId,
                [
                    'company_name',
                    'supplier_type',
                    'legal_name',
                    'gstin',
                    'tax_id',
                    'website',
                    'country',
                    'state_region',
                    'city',
                    'address',
                    'default_currency',
                    'payment_terms',
                    'cancellation_terms',
                    'notes',
                ]
            );

        if ($filled) {
            tsMasterAudit(
                $pdo,
                $caseId,
                'supplier',
                'fill_blank_canonical_fields',
                'suppliers',
                count($filled),
                [
                    'fields' => $filled,
                ],
                $adminId
            );
        }

        /*
        | Supplier master-data children move to the canonical master.
        */
        $moved = [];

        foreach ([
            ['supplier_contracts', 'supplier_id'],
            ['supplier_rate_cards', 'supplier_id'],
        ] as [$table, $column]) {
            $moved[$table . '.' . $column] =
                tsMasterUpdateReference(
                    $pdo,
                    $caseId,
                    'supplier',
                    $table,
                    $column,
                    $sourceId,
                    $canonicalId,
                    $adminId
                );
        }

        /*
        | Contacts are COPIED, not moved.
        | Historical Supplier Requests may retain supplier_contact_id pointing
        | at the original source Supplier contact.
        */
        $copiedContacts = 0;

        if (
            tsMasterTableExists(
                $pdo,
                'supplier_contacts'
            )
        ) {
            $contactColumns = [
                'contact_name',
                'department',
                'designation',
                'mobile',
                'whatsapp',
                'email',
                'status',
                'notes',
            ];

            $contactColumns =
                array_values(
                    array_filter(
                        $contactColumns,
                        static fn($column) =>
                            tsMasterColumnExists(
                                $pdo,
                                'supplier_contacts',
                                $column
                            )
                    )
                );

            if ($contactColumns) {
                $columnSql =
                    implode(
                        ', ',
                        array_map(
                            static fn($column) =>
                                "`{$column}`",
                            $contactColumns
                        )
                    );

                $stmt =
                    $pdo->prepare(
                        "INSERT INTO supplier_contacts
                         (
                            supplier_id,
                            {$columnSql},
                            is_primary
                         )
                         SELECT
                            ?,
                            {$columnSql},
                            0
                         FROM supplier_contacts
                         WHERE supplier_id = ?"
                    );

                $stmt->execute([
                    $canonicalId,
                    $sourceId
                ]);

                $copiedContacts =
                    $stmt->rowCount();

                tsMasterAudit(
                    $pdo,
                    $caseId,
                    'supplier',
                    'copy_supplier_contacts',
                    'supplier_contacts',
                    $copiedContacts,
                    [
                        'source_contacts_preserved' => true,
                        'copied_contacts_are_primary' => false,
                    ],
                    $adminId
                );
            }
        }

        /*
        | Destination / Service mappings can have unique composite indexes.
        | Copy missing mappings to canonical with INSERT IGNORE and preserve
        | source mappings on the inactive duplicate.
        */
        $copiedMappings = [];

        if (
            tsMasterTableExists(
                $pdo,
                'supplier_destinations'
            )
            && tsMasterColumnExists(
                $pdo,
                'supplier_destinations',
                'destination_id'
            )
        ) {
            $stmt =
                $pdo->prepare("
                    INSERT IGNORE INTO supplier_destinations
                    (
                        supplier_id,
                        destination_id
                    )
                    SELECT
                        ?,
                        destination_id
                    FROM supplier_destinations
                    WHERE supplier_id = ?
                ");

            $stmt->execute([
                $canonicalId,
                $sourceId
            ]);

            $copiedMappings['supplier_destinations'] =
                $stmt->rowCount();

            tsMasterAudit(
                $pdo,
                $caseId,
                'supplier',
                'copy_master_mapping',
                'supplier_destinations',
                $stmt->rowCount(),
                [
                    'source_rows_preserved' => true,
                ],
                $adminId
            );
        }

        if (
            tsMasterTableExists(
                $pdo,
                'supplier_services'
            )
            && tsMasterColumnExists(
                $pdo,
                'supplier_services',
                'service_type_id'
            )
        ) {
            $stmt =
                $pdo->prepare("
                    INSERT IGNORE INTO supplier_services
                    (
                        supplier_id,
                        service_type_id
                    )
                    SELECT
                        ?,
                        service_type_id
                    FROM supplier_services
                    WHERE supplier_id = ?
                ");

            $stmt->execute([
                $canonicalId,
                $sourceId
            ]);

            $copiedMappings['supplier_services'] =
                $stmt->rowCount();

            tsMasterAudit(
                $pdo,
                $caseId,
                'supplier',
                'copy_master_mapping',
                'supplier_services',
                $stmt->rowCount(),
                [
                    'source_rows_preserved' => true,
                ],
                $adminId
            );
        }

        /*
        | Historical commercial references intentionally stay on the source
        | supplier ID so old RFQs, supplier quotes, procurement, invoices,
        | payments, cost sheets and frozen Booking snapshots remain historically
        | exact.
        */
        $historicalTables = [
            'supplier_requests',
            'cost_sheet_items',
            'supplier_booking_orders',
            'supplier_invoices',
            'supplier_payments',
            'booking_service_snapshots',
        ];

        tsMasterAudit(
            $pdo,
            $caseId,
            'supplier',
            'preserve_historical_supplier_references',
            null,
            0,
            [
                'tables' =>
                    array_values(
                        array_filter(
                            $historicalTables,
                            static fn($table) =>
                                tsMasterTableExists(
                                    $pdo,
                                    $table
                                )
                        )
                    ),
            ],
            $adminId
        );

        tsMasterCreateAlias(
            $pdo,
            'supplier',
            $sourceId,
            $canonicalId,
            $caseId,
            $adminId
        );

        $stmt =
            $pdo->prepare("
                UPDATE suppliers
                SET
                    status = 'inactive',
                    updated_by_admin_id = ?
                WHERE id = ?
            ");

        $stmt->execute([
            $adminId,
            $sourceId
        ]);

        tsMasterAudit(
            $pdo,
            $caseId,
            'supplier',
            'deactivate_duplicate_master',
            'suppliers',
            $stmt->rowCount(),
            [
                'source_id' => $sourceId,
                'canonical_id' => $canonicalId,
            ],
            $adminId
        );

        $summary = [
            'source_supplier_id' =>
                $sourceId,
            'canonical_supplier_id' =>
                $canonicalId,
            'moved_master_rows' =>
                $moved,
            'copied_mappings' =>
                $copiedMappings,
            'supplier_contacts_copied' =>
                $copiedContacts,
            'historical_commercial_references_preserved' =>
                true,
            'source_deactivated' =>
                true,
        ];

        $pdo->prepare("
            UPDATE master_data_merge_cases
            SET
                status = 'merged',
                merged_by_admin_id = ?,
                merged_at = NOW(),
                merge_summary_json = ?,
                updated_at = NOW()
            WHERE id = ?
        ")->execute([
            $adminId,
            json_encode(
                $summary,
                JSON_UNESCAPED_UNICODE
                | JSON_UNESCAPED_SLASHES
            ),
            $caseId
        ]);

        $pdo->commit();

        return [
            'case_id' => $caseId,
            'summary' => $summary,
        ];

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $e;
    }
}



function tsMasterRejectCandidate(
    PDO $pdo,
    string $entityType,
    int $leftId,
    int $rightId,
    int $score,
    string $reason,
    string $note,
    int $adminId
): int {
    if (
        !in_array(
            $entityType,
            ['customer','supplier'],
            true
        )
        || $leftId <= 0
        || $rightId <= 0
        || $leftId === $rightId
    ) {
        throw new RuntimeException(
            'Invalid duplicate candidate.'
        );
    }

    if (trim($note) === '') {
        throw new RuntimeException(
            'Enter a review note explaining why these are separate masters.'
        );
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire(
            $pdo,
            $adminId,
            'manage_access',
            'reject_master_duplicate_candidate',
            $entityType,
            $leftId,
            [
                'other_id' => $rightId,
            ]
        );
    }

    $caseId =
        tsMasterEnsureCase(
            $pdo,
            $entityType,
            $rightId,
            $leftId,
            $score,
            $reason,
            $note,
            $adminId
        );

    tsMasterRejectCase(
        $pdo,
        $caseId,
        $note,
        $adminId
    );

    return $caseId;
}


function tsMasterRejectCase(
    PDO $pdo,
    int $caseId,
    string $note,
    int $adminId
): void {
    if (!tsMasterReady($pdo)) {
        throw new RuntimeException(
            'Master Data Consolidation SQL is not installed.'
        );
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire(
            $pdo,
            $adminId,
            'manage_access',
            'reject_master_merge_case',
            'master_merge_case',
            $caseId
        );
    }

    $stmt =
        $pdo->prepare("
            UPDATE master_data_merge_cases
            SET
                status = 'rejected',
                review_note = ?,
                rejected_by_admin_id = ?,
                rejected_at = NOW(),
                updated_at = NOW()
            WHERE id = ?
              AND status = 'open'
        ");

    $stmt->execute([
        trim($note) !== ''
            ? trim($note)
            : 'Reviewed and confirmed as separate master records.',
        $adminId,
        $caseId
    ]);

    if ($stmt->rowCount() < 1) {
        throw new RuntimeException(
            'Open merge case was not found.'
        );
    }
}


function tsMasterCases(
    PDO $pdo,
    string $entityType = '',
    string $status = ''
): array {
    if (!tsMasterReady($pdo)) {
        return [];
    }

    $where = [];
    $params = [];

    if (
        in_array(
            $entityType,
            ['customer','supplier'],
            true
        )
    ) {
        $where[] =
            'entity_type = ?';

        $params[] =
            $entityType;
    }

    if (
        in_array(
            $status,
            ['open','merged','rejected'],
            true
        )
    ) {
        $where[] =
            'status = ?';

        $params[] =
            $status;
    }

    $sql =
        "SELECT *
         FROM master_data_merge_cases"
        . (
            $where
                ? ' WHERE ' . implode(' AND ', $where)
                : ''
        )
        . "
         ORDER BY updated_at DESC
         LIMIT 150";

    $stmt =
        $pdo->prepare($sql);

    $stmt->execute($params);

    return
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        ?: [];
}
