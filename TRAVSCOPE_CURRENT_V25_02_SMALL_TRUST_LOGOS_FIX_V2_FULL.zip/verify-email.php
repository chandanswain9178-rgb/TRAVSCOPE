<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| EMAIL VERIFICATION
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';


/*
|--------------------------------------------------------------------------
| ALREADY LOGGED IN
|--------------------------------------------------------------------------
*/

if (isAdminLoggedIn()) {
    redirect(BASE_URL . 'admin-dashboard.php');
}

if (isLoggedIn()) {
    redirect(BASE_URL . 'dashboard.php');
}


/*
|--------------------------------------------------------------------------
| PENDING VERIFICATION SESSION
|--------------------------------------------------------------------------
*/

$userId = (int)(
    $_SESSION['pending_verify_user_id']
    ?? 0
);

$email = normalizeEmail(
    (string)(
        $_SESSION['pending_verify_email']
        ?? ''
    )
);

$name = trim(
    (string)(
        $_SESSION['pending_verify_name']
        ?? ''
    )
);


/*
|--------------------------------------------------------------------------
| INVALID SESSION
|--------------------------------------------------------------------------
*/

if (
    $userId <= 0
    ||
    !validEmail($email)
) {

    setFlash(
        'error',
        'Your verification session has expired. Please register or sign in again.'
    );

    redirect(BASE_URL . 'login.php');
}


/*
|--------------------------------------------------------------------------
| LOAD USER
|--------------------------------------------------------------------------
*/

try {

    $stmt = $pdo->prepare("
        SELECT
            id,
            full_name,
            email,
            email_verified,
            status
        FROM users
        WHERE
            id = ?
            AND email = ?
        LIMIT 1
    ");

    $stmt->execute([
        $userId,
        $email
    ]);

    $user = $stmt->fetch();

} catch (Throwable $e) {

    error_log(
        'Verify email user lookup error: '
        . $e->getMessage()
    );

    $user = false;
}


/*
|--------------------------------------------------------------------------
| USER NOT FOUND
|--------------------------------------------------------------------------
*/

if (!$user) {

    unset(
        $_SESSION['pending_verify_user_id'],
        $_SESSION['pending_verify_email'],
        $_SESSION['pending_verify_name']
    );

    setFlash(
        'error',
        'Account could not be found. Please register again.'
    );

    redirect(BASE_URL . 'register.php');
}


/*
|--------------------------------------------------------------------------
| REFRESH USER DATA
|--------------------------------------------------------------------------
*/

$name = trim(
    (string)$user['full_name']
);

$email = normalizeEmail(
    (string)$user['email']
);

$_SESSION['pending_verify_name'] = $name;
$_SESSION['pending_verify_email'] = $email;


/*
|--------------------------------------------------------------------------
| BLOCKED ACCOUNT
|--------------------------------------------------------------------------
*/

if (
    strtolower(
        (string)$user['status']
    ) === 'blocked'
) {

    unset(
        $_SESSION['pending_verify_user_id'],
        $_SESSION['pending_verify_email'],
        $_SESSION['pending_verify_name']
    );

    setFlash(
        'error',
        'This account has been blocked.'
    );

    redirect(BASE_URL . 'login.php');
}


/*
|--------------------------------------------------------------------------
| ALREADY VERIFIED
|--------------------------------------------------------------------------
*/

if (
    (int)$user['email_verified']
    === 1
) {

    unset(
        $_SESSION['pending_verify_user_id'],
        $_SESSION['pending_verify_email'],
        $_SESSION['pending_verify_name']
    );

    setFlash(
        'success',
        'Your email is already verified. Please sign in.'
    );

    redirect(BASE_URL . 'login.php');
}


/*
|--------------------------------------------------------------------------
| PAGE VARIABLES
|--------------------------------------------------------------------------
*/

$error = '';
$success = '';
$otpValue = '';


/*
|--------------------------------------------------------------------------
| ERROR PASSED FROM REGISTER
|--------------------------------------------------------------------------
*/

if (
    !empty(
        $_SESSION['otp_send_error']
    )
) {

    $error =
        (string)
        $_SESSION['otp_send_error'];

    unset(
        $_SESSION['otp_send_error']
    );
}


/*
|--------------------------------------------------------------------------
| HANDLE POST REQUEST
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */

    if (
        !verifyCsrf(
            $_POST['csrf_token']
            ?? null
        )
    ) {

        $error =
            'Security verification failed. Please refresh the page and try again.';
    }


    /*
    |--------------------------------------------------------------------------
    | VERIFY OTP
    |--------------------------------------------------------------------------
    */

    elseif (
        isset($_POST['verify_otp'])
    ) {

        $otpValue =
            preg_replace(
                '/[^0-9]/',
                '',
                (string)(
                    $_POST['otp']
                    ?? ''
                )
            );


        /*
        |--------------------------------------------------------------------------
        | OTP FORMAT
        |--------------------------------------------------------------------------
        */

        if (
            strlen($otpValue)
            !== OTP_LENGTH
        ) {

            $error =
                'Please enter the complete '
                . OTP_LENGTH
                . '-digit verification code.';

        } else {

            try {

                /*
                |--------------------------------------------------------------------------
                | VERIFY OTP
                |--------------------------------------------------------------------------
                */

                $result =
                    verifyEmailOtp(
                        $pdo,
                        $email,
                        $otpValue,
                        'register'
                    );


                /*
                |--------------------------------------------------------------------------
                | OTP SUCCESS
                |--------------------------------------------------------------------------
                */

                if (
                    is_array($result)
                    &&
                    !empty($result['success'])
                ) {

                    /*
                    |--------------------------------------------------------------------------
                    | MARK EMAIL VERIFIED
                    |--------------------------------------------------------------------------
                    */

                    $update =
                        $pdo->prepare("
                            UPDATE users
                            SET
                                email_verified = 1,
                                updated_at = NOW()
                            WHERE
                                id = ?
                                AND email = ?
                        ");

                    $update->execute([
                        $userId,
                        $email
                    ]);


                    /*
                    |--------------------------------------------------------------------------
                    | CONFIRM DATABASE UPDATE
                    |--------------------------------------------------------------------------
                    */

                    $check =
                        $pdo->prepare("
                            SELECT email_verified
                            FROM users
                            WHERE
                                id = ?
                                AND email = ?
                            LIMIT 1
                        ");

                    $check->execute([
                        $userId,
                        $email
                    ]);

                    $verified =
                        (int)
                        $check->fetchColumn();


                    if ($verified !== 1) {

                        throw new RuntimeException(
                            'Email verification status could not be updated.'
                        );
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | INVALIDATE OTHER OTPs
                    |--------------------------------------------------------------------------
                    */

                    invalidateEmailOtps(
                        $pdo,
                        $email,
                        'register'
                    );


                    /*
                    |--------------------------------------------------------------------------
                    | CLEAR VERIFICATION SESSION
                    |--------------------------------------------------------------------------
                    */

                    unset(
                        $_SESSION['pending_verify_user_id'],
                        $_SESSION['pending_verify_email'],
                        $_SESSION['pending_verify_name'],
                        $_SESSION['otp_send_error']
                    );


                    /*
                    |--------------------------------------------------------------------------
                    | SUCCESS
                    |--------------------------------------------------------------------------
                    */

                    setFlash(
                        'success',
                        'Email verified successfully. Please sign in.'
                    );

                    redirect(
                        BASE_URL . 'login.php'
                    );

                } else {

                    $error =
                        (
                            is_array($result)
                            &&
                            !empty($result['message'])
                        )
                            ?
                            (string)$result['message']
                            :
                            'The verification code is incorrect or has expired.';
                }

            } catch (Throwable $e) {

                error_log(
                    'Verify OTP error: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to verify your code right now. Please try again.';
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | RESEND OTP
    |--------------------------------------------------------------------------
    */

    elseif (
        isset($_POST['resend_otp'])
    ) {

        try {

            /*
            |--------------------------------------------------------------------------
            | CHECK COOLDOWN
            |--------------------------------------------------------------------------
            */

            $remaining =
                otpResendRemaining(
                    $pdo,
                    $email,
                    'register'
                );


            if ($remaining > 0) {

                $error =
                    'Please wait '
                    . $remaining
                    . ' second'
                    . ($remaining === 1 ? '' : 's')
                    . ' before requesting another verification code.';

            } else {

                /*
                |--------------------------------------------------------------------------
                | CREATE + SEND NEW OTP
                |--------------------------------------------------------------------------
                */

                $result =
                    createEmailOtp(
                        $pdo,
                        $email,
                        $name,
                        'register'
                    );


                if (
                    is_array($result)
                    &&
                    !empty($result['success'])
                ) {

                    $success =
                        !empty($result['message'])
                            ?
                            (string)$result['message']
                            :
                            'A new verification code has been sent to your email.';

                    $otpValue = '';

                } else {

                    $error =
                        (
                            is_array($result)
                            &&
                            !empty($result['message'])
                        )
                            ?
                            (string)$result['message']
                            :
                            'Unable to send a new verification code.';
                }
            }

        } catch (Throwable $e) {

            error_log(
                'Resend OTP error: '
                . $e->getMessage()
            );

            $error =
                'Unable to resend the verification code right now. Please try again.';
        }
    }


    /*
    |--------------------------------------------------------------------------
    | UNKNOWN POST
    |--------------------------------------------------------------------------
    */

    else {

        $error =
            'Invalid request. Please try again.';
    }
}


/*
|--------------------------------------------------------------------------
| RESEND TIMER
|--------------------------------------------------------------------------
*/

try {

    $resendRemaining =
        otpResendRemaining(
            $pdo,
            $email,
            'register'
        );

} catch (Throwable $e) {

    error_log(
        'OTP timer error: '
        . $e->getMessage()
    );

    $resendRemaining = 0;
}


/*
|--------------------------------------------------------------------------
| DISPLAY DATA
|--------------------------------------------------------------------------
*/

$maskedEmail = maskEmail($email);

$csrfToken = csrfToken();

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#071a2f"
>

<meta
    name="robots"
    content="noindex,nofollow"
>

<title>Verify Email | TRAVSCOPE.COM</title>


<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

:root {
    --primary:#0b74ff;
    --primary-dark:#075ed1;
    --navy:#071a2f;
    --text:#172033;
    --muted:#6d7889;
    --border:#e3e8ef;
    --background:#f4f8fc;
    --danger:#c92a42;
    --success:#0b8d58;
}

* {
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body {
    min-height:100vh;
    font-family:'DM Sans',sans-serif;
    background:var(--background);
    color:var(--text);
}

a {
    text-decoration:none;
    color:inherit;
}

button,
input {
    font-family:inherit;
}


/* PAGE */

.verify-page {
    min-height:100vh;
    display:grid;
    grid-template-columns:minmax(400px,.9fr) minmax(500px,1.1fr);
}


/* LEFT */

.travel-side {
    min-height:100vh;
    padding:52px 58px;

    display:flex;
    flex-direction:column;
    justify-content:space-between;

    color:white;

    background:
        linear-gradient(
            125deg,
            rgba(3,18,34,.95),
            rgba(5,40,73,.67)
        ),
        url(
            'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=1600&q=88'
        )
        center/cover no-repeat;
}


/* LOGO */

.logo {
    display:inline-flex;
    align-items:center;
    gap:11px;
    width:max-content;

    font-family:'Manrope',sans-serif;
    font-size:23px;
    font-weight:800;
}

.logo-icon {
    width:45px;
    height:45px;

    border-radius:13px;

    display:grid;
    place-items:center;

    background:
        linear-gradient(
            135deg,
            #0b74ff,
            #00b6ff
        );

    transform:rotate(-5deg);
}

.logo span {
    color:#62b5ff;
}


/* LEFT CONTENT */

.travel-content {
    max-width:560px;
}

.travel-content h1 {
    font-family:'Manrope',sans-serif;

    font-size:
        clamp(
            40px,
            4.7vw,
            62px
        );

    line-height:1.08;
    letter-spacing:-2px;
}

.travel-content h1 span {
    display:block;
    color:#62b5ff;
}

.travel-content p {
    max-width:510px;
    margin-top:20px;

    color:rgba(255,255,255,.78);

    font-size:15px;
    line-height:1.75;
}

.travel-footer {
    color:rgba(255,255,255,.55);
    font-size:11px;
}


/* RIGHT */

.form-side {
    min-height:100vh;
    padding:40px;

    display:grid;
    place-items:center;

    background:white;
}

.verify-container {
    width:100%;
    max-width:470px;
}

.mobile-logo {
    display:none;
    margin-bottom:40px;
    color:var(--navy);
}

.mobile-logo span {
    color:var(--primary);
}


/* ICON */

.verify-icon {
    width:72px;
    height:72px;

    margin-bottom:24px;

    border-radius:20px;

    display:grid;
    place-items:center;

    background:#eaf4ff;
    color:var(--primary);

    font-size:28px;
}


/* HEADER */

.verify-header h2 {
    font-family:'Manrope',sans-serif;
    font-size:34px;
    color:var(--navy);
    letter-spacing:-1px;
}

.verify-header p {
    margin-top:10px;
    color:var(--muted);
    font-size:13px;
    line-height:1.7;
}


/* EMAIL */

.email-box {
    margin-top:17px;
    padding:12px 14px;

    display:flex;
    align-items:center;
    gap:10px;

    border:1px solid #dcecff;
    border-radius:11px;

    background:#f6faff;

    color:#51647b;

    font-size:12px;
    font-weight:600;
}

.email-box i {
    color:var(--primary);
}


/* ALERTS */

.alert {
    margin-top:20px;
    padding:13px 14px;

    display:flex;
    align-items:flex-start;
    gap:10px;

    border-radius:11px;

    font-size:12px;
    line-height:1.55;
}

.alert-error {
    border:1px solid #ffd8de;
    background:#fff1f3;
    color:var(--danger);
}

.alert-success {
    border:1px solid #cceedd;
    background:#effbf5;
    color:var(--success);
}


/* OTP */

.otp-form {
    margin-top:25px;
}

.otp-label {
    display:block;
    margin-bottom:9px;

    color:#344054;

    font-size:12px;
    font-weight:700;
}

.otp-input {
    width:100%;
    height:66px;

    padding:0 20px;

    border:1px solid var(--border);
    border-radius:13px;

    outline:none;

    background:white;

    color:var(--navy);

    text-align:center;

    font-family:'Manrope',sans-serif;

    font-size:28px;
    font-weight:800;

    letter-spacing:13px;
}

.otp-input:focus {
    border-color:var(--primary);

    box-shadow:
        0 0 0 3px
        rgba(11,116,255,.09);
}

.otp-help {
    margin-top:8px;

    color:#8a95a5;

    text-align:center;

    font-size:10px;
}


/* VERIFY BUTTON */

.verify-button {
    width:100%;
    min-height:55px;

    margin-top:20px;

    border:0;
    border-radius:12px;

    display:flex;
    align-items:center;
    justify-content:center;
    gap:9px;

    background:var(--primary);

    color:white;

    font-size:14px;
    font-weight:700;

    cursor:pointer;

    box-shadow:
        0 12px 28px
        rgba(11,116,255,.2);
}

.verify-button:hover {
    background:var(--primary-dark);
}


/* RESEND */

.resend-area {
    margin-top:22px;
    padding-top:21px;

    border-top:1px solid var(--border);

    text-align:center;
}

.resend-area p {
    margin-bottom:10px;

    color:var(--muted);

    font-size:11px;
}

.resend-button {
    border:0;

    background:transparent;

    color:var(--primary);

    font-size:12px;
    font-weight:700;

    cursor:pointer;
}

.resend-button:hover {
    color:var(--primary-dark);
}

.countdown {
    min-height:18px;

    margin-top:8px;

    color:#8a95a5;

    font-size:11px;
}


/* LINKS */

.actions {
    margin-top:25px;

    display:flex;
    justify-content:center;

    gap:20px;

    font-size:11px;
    font-weight:700;
}

.actions a {
    color:#647184;
}

.actions a:hover {
    color:var(--primary);
}

.security {
    margin-top:25px;

    display:flex;
    justify-content:center;
    align-items:center;

    gap:7px;

    color:#98a2b3;

    font-size:10px;
}

.security i {
    color:var(--success);
}


/* RESPONSIVE */

@media(max-width:950px) {

    .verify-page {
        grid-template-columns:1fr;
    }

    .travel-side {
        display:none;
    }

    .form-side {
        padding:35px 24px;
    }

    .mobile-logo {
        display:flex;
    }
}


@media(max-width:500px) {

    .form-side {
        display:block;
        padding:26px 18px 40px;
    }

    .verify-header h2 {
        font-size:29px;
    }

    .otp-input {
        font-size:25px;
        letter-spacing:9px;
    }

    .actions {
        flex-direction:column;
        align-items:center;
        gap:12px;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-public-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="public"></script>
</head>


<body>


<div class="verify-page">


    <!-- LEFT -->

    <section class="travel-side">


        <a
            href="<?= e(BASE_URL); ?>"
            class="logo"
        >

            <div class="logo-icon">
                <i class="fa-solid fa-plane"></i>
            </div>

            TRAV<span>SCOPE</span>

        </a>


        <div class="travel-content">

            <h1>

                One quick step.

                <span>
                    Then explore the world.
                </span>

            </h1>

            <p>

                Verify your email address to secure
                your TRAVSCOPE account and start
                managing your worldwide travel
                experiences.

            </p>

        </div>


        <div class="travel-footer">

            © <?= date('Y'); ?>
            TRAVSCOPE.COM —
            Worldwide Travel Experiences

        </div>


    </section>


    <!-- RIGHT -->

    <section class="form-side">


        <div class="verify-container">


            <!-- MOBILE LOGO -->

            <a
                href="<?= e(BASE_URL); ?>"
                class="logo mobile-logo"
            >

                <div class="logo-icon">
                    <i class="fa-solid fa-plane"></i>
                </div>

                TRAV<span>SCOPE</span>

            </a>


            <!-- ICON -->

            <div class="verify-icon">

                <i class="fa-solid fa-envelope-circle-check"></i>

            </div>


            <!-- HEADER -->

            <div class="verify-header">

                <h2>
                    Verify your email
                </h2>

                <p>

                    Hi <?= e($name); ?>,

                    enter the
                    <?= (int)OTP_LENGTH; ?>-digit
                    verification code sent to your
                    registered email address.

                </p>

            </div>


            <!-- EMAIL -->

            <div class="email-box">

                <i class="fa-regular fa-envelope"></i>

                <?= e($maskedEmail); ?>

            </div>


            <!-- ERROR -->

            <?php if ($error !== ''): ?>

                <div
                    class="alert alert-error"
                    role="alert"
                >

                    <i class="fa-solid fa-circle-exclamation"></i>

                    <span>
                        <?= e($error); ?>
                    </span>

                </div>

            <?php endif; ?>


            <!-- SUCCESS -->

            <?php if ($success !== ''): ?>

                <div
                    class="alert alert-success"
                    role="status"
                >

                    <i class="fa-solid fa-circle-check"></i>

                    <span>
                        <?= e($success); ?>
                    </span>

                </div>

            <?php endif; ?>


            <!-- =================================================
                 VERIFY FORM
            ================================================== -->

            <form
                method="POST"
                action=""
                class="otp-form"
                id="otpForm"
                autocomplete="off"
            >


                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e($csrfToken); ?>"
                >


                <!--
                IMPORTANT:
                This hidden field guarantees PHP
                receives verify_otp even if JS changes
                the visible button later.
                -->

                <input
                    type="hidden"
                    name="verify_otp"
                    value="1"
                >


                <label
                    for="otp"
                    class="otp-label"
                >

                    Verification Code

                </label>


                <input
                    type="text"
                    id="otp"
                    name="otp"
                    class="otp-input"
                    value="<?= e($otpValue); ?>"
                    maxlength="<?= (int)OTP_LENGTH; ?>"
                    inputmode="numeric"
                    pattern="[0-9]*"
                    autocomplete="one-time-code"
                    placeholder="000000"
                    required
                    autofocus
                >


                <div class="otp-help">

                    Enter the latest code sent
                    to your email.

                </div>


                <button
                    type="submit"
                    class="verify-button"
                    id="verifyButton"
                >

                    <i class="fa-solid fa-shield-halved"></i>

                    <span id="verifyButtonText">
                        Verify Email
                    </span>

                </button>


            </form>


            <!-- =================================================
                 RESEND FORM
            ================================================== -->

            <div class="resend-area">


                <p>
                    Didn't receive the code?
                </p>


                <form
                    method="POST"
                    action=""
                    id="resendForm"
                >


                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e($csrfToken); ?>"
                    >


                    <!--
                    Same approach:
                    PHP will always receive resend_otp.
                    -->

                    <input
                        type="hidden"
                        name="resend_otp"
                        value="1"
                    >


                    <button
                        type="submit"
                        class="resend-button"
                        id="resendButton"
                    >

                        <i class="fa-solid fa-rotate-right"></i>

                        <span id="resendText">
                            Resend verification code
                        </span>

                    </button>


                </form>


                <div
                    class="countdown"
                    id="countdown"
                    data-seconds="<?= (int)$resendRemaining; ?>"
                ></div>


            </div>


            <!-- LINKS -->

            <div class="actions">


                <a
                    href="<?= e(BASE_URL); ?>login.php"
                >

                    <i class="fa-solid fa-arrow-left"></i>

                    Back to Login

                </a>


                <a
                    href="<?= e(BASE_URL); ?>register.php"
                >

                    <i class="fa-regular fa-user"></i>

                    Register Again

                </a>


            </div>


            <div class="security">

                <i class="fa-solid fa-shield-halved"></i>

                Secure email verification by
                TRAVSCOPE.COM

            </div>


        </div>


    </section>


</div>


<script>

/*
|--------------------------------------------------------------------------
| OTP - NUMBERS ONLY
|--------------------------------------------------------------------------
*/

const otpInput =
    document.getElementById('otp');


if (otpInput) {

    otpInput.addEventListener(
        'input',
        function () {

            this.value =
                this.value
                    .replace(/[^0-9]/g, '')
                    .slice(
                        0,
                        <?= (int)OTP_LENGTH; ?>
                    );
        }
    );
}


/*
|--------------------------------------------------------------------------
| VERIFY FORM
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| Do NOT disable the submit button here.
|
| The hidden:
|
|     verify_otp = 1
|
| guarantees PHP knows this is a verification request.
|
|--------------------------------------------------------------------------
*/

const otpForm =
    document.getElementById('otpForm');

const verifyButtonText =
    document.getElementById('verifyButtonText');


if (
    otpForm
    &&
    verifyButtonText
) {

    otpForm.addEventListener(
        'submit',
        function () {

            verifyButtonText.innerHTML =
                '<i class="fa-solid fa-circle-notch fa-spin"></i> Verifying...';
        }
    );
}


/*
|--------------------------------------------------------------------------
| RESEND COUNTDOWN
|--------------------------------------------------------------------------
*/

const countdown =
    document.getElementById('countdown');

const resendText =
    document.getElementById('resendText');


let seconds =
    countdown
        ?
        parseInt(
            countdown.dataset.seconds || '0',
            10
        )
        :
        0;


function updateCountdown() {

    if (!countdown) {
        return;
    }


    if (seconds <= 0) {

        countdown.textContent = '';

        return;
    }


    countdown.textContent =
        'You can request another code in '
        + seconds
        + ' second'
        + (seconds === 1 ? '' : 's')
        + '.';


    seconds--;


    window.setTimeout(
        updateCountdown,
        1000
    );
}


updateCountdown();


/*
|--------------------------------------------------------------------------
| RESEND FORM
|--------------------------------------------------------------------------
|
| Again:
| DO NOT disable the submit button before POST.
|--------------------------------------------------------------------------
*/

const resendForm =
    document.getElementById('resendForm');


if (
    resendForm
    &&
    resendText
) {

    resendForm.addEventListener(
        'submit',
        function () {

            resendText.innerHTML =
                '<i class="fa-solid fa-circle-notch fa-spin"></i> Sending...';
        }
    );
}

</script>



<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>