<?php

require_once __DIR__ . '/config.php';

$crmFunctionsFile = __DIR__ . '/crm-functions.php';
if (is_file($crmFunctionsFile)) { require_once $crmFunctionsFile; }

/*
|--------------------------------------------------------------------------
| ADMIN AUTH
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_id'])) {

    header(
        'Location: '
        . BASE_URL
        . 'admin-login.php'
    );

    exit;
}

$adminId = (int)$_SESSION['admin_id'];


/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function enquiryStatusLabel(string $status): string
{
    switch ($status) {
        case 'new':
            return 'New';
        case 'contacted':
            return 'Contacted';
        case 'follow_up':
            return 'Follow Up';
        case 'converted':
            return 'Converted';
        case 'closed':
            return 'Closed';
        default:
            return ucfirst(str_replace('_', ' ', $status));
    }
}


function enquiryStatusClass(string $status): string
{
    switch ($status) {
        case 'new':
            return 'status-new';
        case 'contacted':
            return 'status-contacted';
        case 'follow_up':
            return 'status-follow';
        case 'converted':
            return 'status-converted';
        case 'closed':
            return 'status-closed';
        default:
            return 'status-closed';
    }
}


function enquiryDate($date, bool $withTime = true): string
{
    if (empty($date)) {
        return '—';
    }

    $time = strtotime((string)$date);

    if (!$time) {
        return '—';
    }

    return $withTime
        ? date('d M Y, h:i A', $time)
        : date('d M Y', $time);
}


function enquiryMoney($amount): string
{
    if (
        $amount === null ||
        $amount === ''
    ) {
        return 'Not specified';
    }

    return '₹'
        . number_format(
            (float)$amount,
            2
        );
}


function enquiryBookingNumber(): string
{
    return 'TRV'
        . date('ymd')
        . strtoupper(
            substr(
                bin2hex(random_bytes(5)),
                0,
                8
            )
        );
}


/*
|--------------------------------------------------------------------------
| ALLOWED STATUSES
|--------------------------------------------------------------------------
*/

$allowedStatuses = [
    'new',
    'contacted',
    'follow_up',
    'converted',
    'closed'
];


/*
|--------------------------------------------------------------------------
| ENQUIRY ID
|--------------------------------------------------------------------------
*/

$enquiryId =
    (int)(
        $_GET['id']
        ??
        $_POST['enquiry_id']
        ??
        0
    );

if ($enquiryId <= 0) {

    header(
        'Location: '
        . BASE_URL
        . 'admin-enquiries.php'
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_enquiry_details_csrf'])) {

    $_SESSION['admin_enquiry_details_csrf'] =
        bin2hex(
            random_bytes(32)
        );
}

$csrfToken =
    $_SESSION['admin_enquiry_details_csrf'];


/*
|--------------------------------------------------------------------------
| FLASH
|--------------------------------------------------------------------------
*/

$success = '';
$error = '';

if (!empty($_SESSION['admin_enquiry_details_success'])) {

    $success =
        (string)
        $_SESSION['admin_enquiry_details_success'];

    unset(
        $_SESSION['admin_enquiry_details_success']
    );
}


/*
|--------------------------------------------------------------------------
| FETCH ENQUIRY FUNCTION
|--------------------------------------------------------------------------
*/

function getAdminEnquiry(
    PDO $pdo,
    int $enquiryId
): ?array {

    $stmt = $pdo->prepare("
        SELECT

            e.id,
            e.package_id,
            e.name,
            e.email,
            e.mobile,
            e.destination,
            e.travel_date,
            e.adults,
            e.children,
            e.budget,
            e.message,
            e.status,
            e.admin_notes,
            e.created_at,
            e.updated_at,

            p.title AS package_title,
            p.package_code,
            p.slug,
            p.sale_price AS package_sale_price,
            p.regular_price AS package_regular_price,
            p.currency AS package_currency,
            p.duration_days,
            p.duration_nights,

            d.name AS package_destination,
            d.country AS package_country

        FROM enquiries e

        LEFT JOIN packages p
            ON p.id = e.package_id

        LEFT JOIN destinations d
            ON d.id = p.destination_id

        WHERE e.id = ?

        LIMIT 1
    ");

    $stmt->execute([
        $enquiryId
    ]);

    $row =
        $stmt->fetch(
            PDO::FETCH_ASSOC
        );

    return $row ?: null;
}


/*
|--------------------------------------------------------------------------
| FETCH ENQUIRY
|--------------------------------------------------------------------------
*/

try {

    $enquiry =
        getAdminEnquiry(
            $pdo,
            $enquiryId
        );

} catch (Throwable $e) {

    error_log(
        'Admin enquiry details fetch: '
        . $e->getMessage()
    );

    $enquiry = null;
}


if (!$enquiry) {

    http_response_code(404);

    die(
        'Enquiry not found.'
    );
}


/* Phase 0A Trip Foundation */
$trip = null;
try {
    if (function_exists('crmTripByEnquiry')) { $trip = crmTripByEnquiry($pdo, $enquiryId); }
} catch (Throwable $e) { error_log('Enquiry trip lookup: ' . $e->getMessage()); }

/*
|--------------------------------------------------------------------------
| FIND POSSIBLE EXISTING BOOKING
|--------------------------------------------------------------------------
|
| Because enquiries table does not contain booking_id, we perform a
| conservative lookup for a likely booking created from this enquiry.
|
*/

$existingBooking = null;

try {

    if (!empty($enquiry['package_id'])) {

        $stmt = $pdo->prepare("
            SELECT
                id,
                booking_number,
                customer_name,
                customer_email,
                customer_mobile,
                total_amount,
                paid_amount,
                currency,
                booking_status,
                payment_status,
                created_at

            FROM bookings

            WHERE
                package_id = ?
                AND customer_mobile = ?
                AND created_at >= ?

            ORDER BY id DESC

            LIMIT 1
        ");

        $stmt->execute([
            (int)$enquiry['package_id'],
            $enquiry['mobile'],
            $enquiry['created_at']
        ]);

        $existingBooking =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );

        if (!$existingBooking) {
            $existingBooking = null;
        }
    }

} catch (Throwable $e) {

    error_log(
        'Existing enquiry booking lookup: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $postedToken =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );


    /*
    |--------------------------------------------------------------------------
    | CSRF CHECK
    |--------------------------------------------------------------------------
    */

    if (
        $postedToken === ''
        ||
        !hash_equals(
            $_SESSION[
                'admin_enquiry_details_csrf'
            ]
            ?? '',
            $postedToken
        )
    ) {

        $error =
            'Security verification failed. Please refresh and try again.';
    }


    /* Phase 0A — Create Trip */
    elseif (isset($_POST['create_trip'])) {
        try {
            if (!function_exists('crmCreateTripForEnquiry')) throw new RuntimeException('Trip helper is unavailable.');
            $trip = crmCreateTripForEnquiry($pdo, $enquiryId, $adminId);
            $_SESSION['admin_enquiry_details_success'] = 'Trip ' . (string)$trip['trip_code'] . ' is ready.';
            header('Location: ' . BASE_URL . 'admin-enquiry-details.php?id=' . $enquiryId);
            exit;
        } catch (Throwable $e) {
            error_log('Create trip from enquiry details: ' . $e->getMessage());
            $error = $e->getMessage();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | UPDATE ENQUIRY
    |--------------------------------------------------------------------------
    */

    elseif (
        isset(
            $_POST['save_enquiry']
        )
    ) {

        $status =
            trim(
                (string)(
                    $_POST['status']
                    ?? ''
                )
            );

        $adminNotes =
            trim(
                (string)(
                    $_POST['admin_notes']
                    ?? ''
                )
            );


        if (
            !in_array(
                $status,
                $allowedStatuses,
                true
            )
        ) {

            $error =
                'Please select a valid enquiry status.';
        }

        elseif (
            mb_strlen($adminNotes)
            > 10000
        ) {

            $error =
                'Admin notes are too long.';
        }

        else {

            try {

                $stmt =
                    $pdo->prepare("
                        UPDATE enquiries

                        SET
                            status = ?,
                            admin_notes = ?

                        WHERE id = ?

                        LIMIT 1
                    ");

                $stmt->execute([
                    $status,
                    $adminNotes !== ''
                        ? $adminNotes
                        : null,
                    $enquiryId
                ]);


                $_SESSION[
                    'admin_enquiry_details_success'
                ] =
                    'Enquiry updated successfully.';


                header(
                    'Location: '
                    . BASE_URL
                    . 'admin-enquiry-details.php?id='
                    . $enquiryId
                );

                exit;

            } catch (Throwable $e) {

                error_log(
                    'Admin enquiry save: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to update the enquiry.';
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | LEGACY DIRECT BOOKING CONVERSION DISABLED (V24.1)
    |--------------------------------------------------------------------------
    | Booking creation must follow the quotation workflow:
    | Enquiry -> Quotation -> Customer Decision -> Admin Review -> Booking.
    | Keep this guard so an old bookmarked/form POST cannot bypass quotation review.
    */

    elseif (isset($_POST['convert_booking'])) {
        $error = 'Direct enquiry-to-booking conversion is disabled. Create or review the customer quotation first, then convert an accepted quotation from the Quotation Desk.';
    }


    /*
    |--------------------------------------------------------------------------
    | REFRESH ENQUIRY AFTER NON-REDIRECT ERROR
    |--------------------------------------------------------------------------
    */

    try {

        $enquiry =
            getAdminEnquiry(
                $pdo,
                $enquiryId
            );

    } catch (Throwable $e) {
        // Keep previous data.
    }
}


/*
|--------------------------------------------------------------------------
| QUOTATION WORKFLOW SUMMARY (V24.1)
|--------------------------------------------------------------------------
| Read only. No schema changes. All queries are guarded so older installations
| still open the enquiry page even when one of the quotation tables is absent.
*/

$latestQuotation = null;
$quotationWorkflowState = 'not_created';
$quotationWorkflowLabel = 'Quotation Not Created';
$quotationWorkflowHint = 'Prepare the customer quotation from this enquiry.';
$quotationBooking = null;

try {
    $stmt = $pdo->prepare("\n        SELECT id, lead_id, version_number, package_title, hotel_category,\n               travel_date, adults, children, final_price, created_at\n        FROM crm_package_versions\n        WHERE lead_id = ?\n        ORDER BY id DESC\n        LIMIT 1\n    ");
    $stmt->execute([$enquiryId]);
    $latestQuotation = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
} catch (Throwable $e) {
    $latestQuotation = null;
}

if ($latestQuotation) {
    $quotationWorkflowState = 'draft';
    $quotationWorkflowLabel = 'Quotation Prepared';
    $quotationWorkflowHint = 'Review the latest quotation, then preview/send it to the customer.';

    try {
        $stmt = $pdo->prepare("\n            SELECT id, decision, booking_id, customer_note, created_at\n            FROM quotation_customer_responses\n            WHERE quotation_version_id = ?\n            ORDER BY id DESC\n            LIMIT 1\n        ");
        $stmt->execute([(int)$latestQuotation['id']]);
        $response = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

        if ($response) {
            if (($response['decision'] ?? '') === 'accepted') {
                if (!empty($response['booking_id'])) {
                    $quotationWorkflowState = 'converted';
                    $quotationWorkflowLabel = 'Booking Created';
                    $quotationWorkflowHint = 'This accepted quotation has already been converted to a booking.';
                } else {
                    $quotationWorkflowState = 'accepted';
                    $quotationWorkflowLabel = 'Accepted — Admin Review';
                    $quotationWorkflowHint = 'Customer accepted this quotation. Complete admin/supplier review before booking conversion.';
                }
            } elseif (($response['decision'] ?? '') === 'change_requested') {
                $quotationWorkflowState = 'change_requested';
                $quotationWorkflowLabel = 'Customer Requested Changes';
                $quotationWorkflowHint = 'Revise the quotation and send a new version for customer approval.';
            } elseif (($response['decision'] ?? '') === 'rejected') {
                $quotationWorkflowState = 'rejected';
                $quotationWorkflowLabel = 'Quotation Rejected';
                $quotationWorkflowHint = 'Review the customer note and decide whether to create a revised version.';
            }
        }
    } catch (Throwable $e) {
        // Response table may not exist on older installs. Keep prepared state.
    }

    try {
        $stmt = $pdo->prepare("\n            SELECT b.id, b.booking_number, b.booking_status, b.payment_status\n            FROM quotation_acceptances a\n            INNER JOIN bookings b ON b.id = a.booking_id\n            WHERE a.quotation_version_id = ?\n            ORDER BY a.id DESC\n            LIMIT 1\n        ");
        $stmt->execute([(int)$latestQuotation['id']]);
        $quotationBooking = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        if ($quotationBooking) {
            $quotationWorkflowState = 'converted';
            $quotationWorkflowLabel = 'Booking Created';
            $quotationWorkflowHint = 'This quotation has completed admin conversion.';
        }
    } catch (Throwable $e) {
        // Guarded for older schemas.
    }
}


/*
|--------------------------------------------------------------------------
| DEFAULT CONVERSION PRICE
|--------------------------------------------------------------------------
|
| Package price is a useful starting point for the admin.
| The customer enquiry budget is NOT automatically used.
|
*/

$defaultBookingAmount = '';

if (
    isset(
        $enquiry['package_sale_price']
    )
    &&
    (float)$enquiry[
        'package_sale_price'
    ] > 0
) {

    $defaultBookingAmount =
        number_format(
            (float)$enquiry[
                'package_sale_price'
            ],
            2,
            '.',
            ''
        );
}

elseif (
    isset(
        $enquiry['package_regular_price']
    )
    &&
    (float)$enquiry[
        'package_regular_price'
    ] > 0
) {

    $defaultBookingAmount =
        number_format(
            (float)$enquiry[
                'package_regular_price'
            ],
            2,
            '.',
            ''
        );
}


/*
|--------------------------------------------------------------------------
| PHONE / EMAIL LINKS
|--------------------------------------------------------------------------
*/

$phoneLink =
    preg_replace(
        '/[^0-9+]/',
        '',
        (string)$enquiry['mobile']
    );

$emailLink =
    trim(
        (string)$enquiry['email']
    );

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
Enquiry #<?= (int)$enquiryId; ?> | TRAVSCOPE Admin
</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

:root {

    --navy:#07192d;
    --navy2:#0c3156;

    --blue:#0b74ff;

    --bg:#f4f7fb;

    --white:#fff;

    --text:#172235;

    --muted:#8290a0;

    --border:#e1e8ef;

    --green:#087952;
    --green-bg:#eaf9f3;

    --orange:#a96500;
    --orange-bg:#fff4dc;

    --purple:#684bd2;
    --purple-bg:#eeebff;

    --red:#bd4453;
    --red-bg:#fff0f2;

    --gray:#687586;
    --gray-bg:#eef1f5;

    --shadow:
        0 12px 35px
        rgba(7,25,45,.07);
}


* {
    box-sizing:border-box;
    margin:0;
    padding:0;
}


body {

    min-height:100vh;

    background:var(--bg);

    color:var(--text);

    font-family:
        'DM Sans',
        sans-serif;
}


a {
    color:inherit;
    text-decoration:none;
}


button,
input,
select,
textarea {
    font:inherit;
}


/* =========================================================
   TOP BAR
========================================================= */

.topbar {

    min-height:68px;

    padding:0 4%;

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:20px;

    background:var(--navy);

    color:white;
}


.brand {

    display:flex;

    align-items:center;

    gap:9px;

    font-family:
        'Manrope',
        sans-serif;

    font-size:20px;

    font-weight:800;
}


.brand-icon {

    width:37px;
    height:37px;

    border-radius:10px;

    display:grid;

    place-items:center;

    background:
        linear-gradient(
            135deg,
            #0b74ff,
            #00b8ff
        );
}


.brand span {
    color:#5fc9ff;
}


.top-actions {

    display:flex;

    align-items:center;

    gap:7px;
}


.top-link {

    min-height:37px;

    padding:0 11px;

    border-radius:8px;

    display:flex;

    align-items:center;

    gap:6px;

    color:#c4d4e2;

    font-size:13px;

    font-weight:700;
}


.top-link:hover {

    background:
        rgba(255,255,255,.08);

    color:white;
}


/* =========================================================
   PAGE
========================================================= */

.page {

    width:min(1250px,94%);

    margin:27px auto 60px;
}


.back {

    margin-bottom:14px;

    display:inline-flex;

    align-items:center;

    gap:6px;

    color:#718092;

    font-size:13px;

    font-weight:700;
}


.back:hover {
    color:var(--blue);
}


.head {

    margin-bottom:20px;

    display:flex;

    align-items:flex-start;

    justify-content:space-between;

    gap:20px;
}


.eyebrow {

    color:var(--blue);

    font-size:12px;

    font-weight:800;

    text-transform:uppercase;

    letter-spacing:.8px;
}


.head h1 {

    margin-top:5px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:30px;
}


.head-meta {

    margin-top:6px;

    display:flex;

    align-items:center;

    gap:8px;

    flex-wrap:wrap;

    color:#8b97a5;

    font-size:13px;
}


/* =========================================================
   STATUS
========================================================= */

.status {

    display:inline-flex;

    align-items:center;

    gap:6px;

    padding:7px 11px;

    border-radius:30px;

    font-size:12px;

    font-weight:800;
}


.status::before {

    content:"";

    width:6px;
    height:6px;

    border-radius:50%;

    background:currentColor;
}


.status-new {

    background:#e9f3ff;

    color:#0b74ff;
}


.status-contacted {

    background:var(--green-bg);

    color:var(--green);
}


.status-follow {

    background:var(--orange-bg);

    color:var(--orange);
}


.status-converted {

    background:var(--purple-bg);

    color:var(--purple);
}


.status-closed {

    background:var(--gray-bg);

    color:var(--gray);
}


/* =========================================================
   ALERT
========================================================= */

.alert {

    margin-bottom:15px;

    padding:13px 14px;

    border-radius:10px;

    display:flex;

    align-items:flex-start;

    gap:8px;

    font-size:14px;

    line-height:1.6;
}


.alert-success {

    border:1px solid #bce5d4;

    background:var(--green-bg);

    color:var(--green);
}


.alert-error {

    border:1px solid #efcbd0;

    background:var(--red-bg);

    color:var(--red);
}


/* =========================================================
   GRID / CARD
========================================================= */

.layout {

    display:grid;

    grid-template-columns:
        minmax(0,1fr)
        355px;

    gap:17px;

    align-items:start;
}


.stack {

    display:flex;

    flex-direction:column;

    gap:15px;
}


.card {

    border:1px solid var(--border);

    border-radius:14px;

    background:white;

    box-shadow:var(--shadow);

    overflow:hidden;
}


.card-head {

    padding:16px 18px;

    border-bottom:1px solid var(--border);

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:10px;
}


.card-head h2 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:17px;
}


.card-head span {

    color:#929daa;

    font-size:12px;
}


.card-body {

    padding:18px;
}


/* =========================================================
   CUSTOMER
========================================================= */

.customer-top {

    display:flex;

    align-items:center;

    gap:13px;

    margin-bottom:17px;
}


.avatar {

    width:53px;
    height:53px;

    flex:0 0 53px;

    border-radius:15px;

    display:grid;

    place-items:center;

    background:
        linear-gradient(
            135deg,
            #e8f2ff,
            #f3f8ff
        );

    color:var(--blue);

    font-family:
        'Manrope',
        sans-serif;

    font-size:19px;

    font-weight:800;
}


.customer-top h3 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:17px;
}


.customer-top p {

    margin-top:3px;

    color:#8995a3;

    font-size:13px;
}


.contact-actions {

    display:grid;

    grid-template-columns:
        repeat(2,1fr);

    gap:8px;

    margin-bottom:17px;
}


.contact-btn {

    min-height:41px;

    border:1px solid var(--border);

    border-radius:9px;

    display:flex;

    align-items:center;

    justify-content:center;

    gap:7px;

    background:#fbfcfe;

    color:#607083;

    font-size:13px;

    font-weight:800;
}


.contact-btn:hover {

    border-color:#a7cbfa;

    background:#f0f7ff;

    color:var(--blue);
}


/* =========================================================
   DETAILS
========================================================= */

.detail-grid {

    display:grid;

    grid-template-columns:
        repeat(2,minmax(0,1fr));

    gap:10px;
}


.detail {

    padding:13px;

    border:1px solid #e8edf2;

    border-radius:10px;

    background:#fbfcfe;
}


.detail.full {

    grid-column:1 / -1;
}


.detail-label {

    display:flex;

    align-items:center;

    gap:5px;

    color:#98a2ae;

    font-size:11px;

    font-weight:800;

    text-transform:uppercase;

    letter-spacing:.5px;
}


.detail strong {

    display:block;

    margin-top:6px;

    color:#526175;

    font-size:14px;

    line-height:1.55;
}


.message-box {

    padding:15px;

    border-radius:11px;

    background:#f7f9fc;

    color:#657386;

    font-size:14px;

    line-height:1.8;

    white-space:pre-wrap;

    overflow-wrap:anywhere;
}


/* =========================================================
   PACKAGE
========================================================= */

.package-title {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:18px;

    line-height:1.5;
}


.package-code {

    margin-top:5px;

    color:var(--blue);

    font-size:12px;

    font-weight:800;
}


.package-meta {

    margin-top:14px;

    display:grid;

    grid-template-columns:
        repeat(2,1fr);

    gap:8px;
}


.package-meta-item {

    padding:11px;

    border-radius:9px;

    background:#f5f8fc;
}


.package-meta-item span {

    display:block;

    color:#98a3af;

    font-size:11px;

    text-transform:uppercase;
}


.package-meta-item strong {

    display:block;

    margin-top:4px;

    color:#59687a;

    font-size:13px;
}


.package-link {

    width:100%;

    min-height:40px;

    margin-top:13px;

    border:1px solid #bdd8fb;

    border-radius:9px;

    display:flex;

    align-items:center;

    justify-content:center;

    gap:6px;

    color:var(--blue);

    font-size:13px;

    font-weight:800;
}


/* =========================================================
   FORM
========================================================= */

.form-group {

    margin-bottom:13px;
}


.form-group:last-child {
    margin-bottom:0;
}


.form-group label {

    display:block;

    margin-bottom:6px;

    color:#667487;

    font-size:12px;

    font-weight:800;
}


.form-control {

    width:100%;

    min-height:43px;

    padding:0 11px;

    border:1px solid var(--border);

    border-radius:9px;

    outline:none;

    background:white;

    color:#536174;

    font-size:14px;
}


textarea.form-control {

    min-height:130px;

    padding:11px;

    resize:vertical;

    line-height:1.7;
}


.form-control:focus {

    border-color:#8bbcff;

    box-shadow:
        0 0 0 3px
        rgba(11,116,255,.06);
}


.save-button {

    width:100%;

    min-height:45px;

    border:0;

    border-radius:9px;

    cursor:pointer;

    display:flex;

    align-items:center;

    justify-content:center;

    gap:7px;

    background:var(--navy);

    color:white;

    font-size:14px;

    font-weight:800;
}


.save-button:hover {
    background:var(--blue);
}


/* =========================================================
   CONVERT
========================================================= */

.convert-card {

    border-color:#c8dffd;
}


.convert-intro {

    margin-bottom:15px;

    padding:12px;

    border-radius:10px;

    background:#edf6ff;

    color:#55718d;

    font-size:14px;

    line-height:1.7;
}


.convert-intro strong {

    color:var(--navy);
}


.convert-grid {

    display:grid;

    grid-template-columns:
        repeat(2,minmax(0,1fr));

    gap:10px;
}


.convert-grid
.form-group.full {

    grid-column:1 / -1;
}


.amount-wrap {

    position:relative;
}


.amount-symbol {

    position:absolute;

    top:50%;
    left:12px;

    transform:translateY(-50%);

    color:#788697;

    font-size:14px;

    font-weight:800;
}


.amount-wrap
.form-control {

    padding-left:28px;
}


.price-reference {

    margin-top:5px;

    color:#919ca9;

    font-size:12px;

    line-height:1.5;
}


.convert-button {

    width:100%;

    min-height:48px;

    margin-top:4px;

    border:0;

    border-radius:10px;

    cursor:pointer;

    display:flex;

    align-items:center;

    justify-content:center;

    gap:7px;

    background:
        linear-gradient(
            135deg,
            #087952,
            #0a9a69
        );

    color:white;

    font-size:14px;

    font-weight:800;

    box-shadow:
        0 10px 24px
        rgba(8,121,82,.17);
}


.convert-warning {

    margin-top:9px;

    display:flex;

    align-items:flex-start;

    gap:6px;

    color:#919ca9;

    font-size:12px;

    line-height:1.5;
}


/* =========================================================
   V24.1 CLEAR QUOTATION WORKFLOW
========================================================= */

.quote-workflow-card{border-color:#cfe1f6;overflow:hidden}
.quote-workflow-hero{padding:16px;border:1px solid #dbe9f8;border-radius:12px;background:linear-gradient(135deg,#f7fbff,#eef6ff)}
.quote-flow{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:7px;margin:0 0 14px}
.quote-step{position:relative;padding:10px 7px;border:1px solid #e3eaf2;border-radius:10px;background:#fff;text-align:center;color:#8190a1;font-size:10px;font-weight:800;line-height:1.35}
.quote-step i{display:block;margin-bottom:5px;font-size:14px}
.quote-step.done{background:#eef9f5;border-color:#c5e9db;color:#087952}
.quote-step.active{background:#eaf4ff;border-color:#9ecbff;color:#0b74ff;box-shadow:0 0 0 2px rgba(11,116,255,.06)}
.quote-status-row{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;flex-wrap:wrap}
.quote-status-main{min-width:220px;flex:1}
.quote-status-label{display:inline-flex;align-items:center;gap:6px;padding:5px 8px;border-radius:999px;background:#07192d;color:#fff;font-size:10px;font-weight:900;text-transform:uppercase;letter-spacing:.04em}
.quote-status-main h3{margin:8px 0 4px;color:#10253d;font-size:18px}
.quote-status-main p{margin:0;color:#66798d;font-size:13px;line-height:1.55}
.quote-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:14px}
.quote-summary-item{padding:10px;border:1px solid #e3ebf4;border-radius:9px;background:#fff}
.quote-summary-item span{display:block;color:#8b99a8;font-size:9px;font-weight:800;text-transform:uppercase;margin-bottom:3px}
.quote-summary-item strong{display:block;color:#152b43;font-size:12px;line-height:1.4}
.quote-actions{display:flex;gap:7px;flex-wrap:wrap;margin-top:14px}
.quote-action{min-height:38px;padding:0 11px;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;gap:6px;text-decoration:none;font-size:11px;font-weight:900;border:1px solid #d7e5f3;background:#fff;color:#31516f}
.quote-action.primary{border-color:#0b74ff;background:#0b74ff;color:#fff}
.quote-action.success{border-color:#bfe4d6;background:#eaf9f3;color:#087952}
.quote-action.warning{border-color:#f3d49d;background:#fff7e8;color:#9a6200}
.quote-next{margin-top:12px;padding:10px;border-radius:9px;background:#fff;border:1px dashed #cddbea;color:#60758a;font-size:12px;line-height:1.55}
.quote-next strong{color:#17314e}
@media(max-width:900px){.quote-flow{grid-template-columns:repeat(3,1fr)}.quote-summary{grid-template-columns:repeat(2,1fr)}}
@media(max-width:520px){.quote-flow{grid-template-columns:repeat(2,1fr)}.quote-summary{grid-template-columns:1fr}.quote-action{width:100%}}


/* =========================================================
   EXISTING BOOKING
========================================================= */

.booking-success {

    padding:15px;

    border:1px solid #bce5d4;

    border-radius:11px;

    background:var(--green-bg);
}


.booking-success-icon {

    width:42px;
    height:42px;

    margin-bottom:10px;

    border-radius:11px;

    display:grid;

    place-items:center;

    background:white;

    color:var(--green);

    font-size:16px;
}


.booking-success h3 {

    color:#075d40;

    font-size:16px;
}


.booking-success p {

    margin-top:5px;

    color:#4d806e;

    font-size:13px;

    line-height:1.6;
}


.booking-view {

    min-height:40px;

    margin-top:12px;

    border-radius:9px;

    display:flex;

    align-items:center;

    justify-content:center;

    gap:6px;

    background:var(--green);

    color:white;

    font-size:13px;

    font-weight:800;
}


/* =========================================================
   TIMELINE
========================================================= */

.timeline {

    display:flex;

    flex-direction:column;
}


.timeline-item {

    position:relative;

    padding:
        0 0 18px 27px;
}


.timeline-item:last-child {

    padding-bottom:0;
}


.timeline-item::before {

    content:"";

    position:absolute;

    top:10px;
    bottom:-2px;
    left:7px;

    width:1px;

    background:#dfe6ed;
}


.timeline-item:last-child::before {

    display:none;
}


.timeline-dot {

    width:15px;
    height:15px;

    position:absolute;

    top:1px;
    left:0;

    border:3px solid white;

    border-radius:50%;

    background:var(--blue);

    box-shadow:
        0 0 0 1px
        #b9d6fa;
}


.timeline-item strong {

    display:block;

    color:#59687a;

    font-size:13px;
}


.timeline-item span {

    display:block;

    margin-top:3px;

    color:#98a2ae;

    font-size:12px;

    line-height:1.5;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:900px) {

    .layout {
        grid-template-columns:1fr;
    }
}


@media(max-width:650px) {

    .topbar {
        padding:0 14px;
    }


    .top-actions
    .hide-mobile {
        display:none;
    }


    .page {
        width:94%;
        margin-top:20px;
    }


    .head {
        flex-direction:column;
    }


    .detail-grid,
    .convert-grid {
        grid-template-columns:1fr;
    }


    .detail.full,
    .convert-grid
    .form-group.full {

        grid-column:auto;
    }


    .package-meta {
        grid-template-columns:1fr;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.page{
    margin:0 0 0 var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
    padding:16px 18px 20px!important;
}
.admin-main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>


<body class="ts-dashboard-sidebar-added">

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->





<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->





<!-- =========================================================
     TOP BAR
========================================================= -->

<header class="topbar">


<a
    href="<?= e(BASE_URL . 'admin-dashboard.php'); ?>"
    class="brand"
>

<span class="brand-icon">

    <i class="fa-solid fa-plane"></i>

</span>

TRAV<span>SCOPE</span> ADMIN

</a>


<div class="top-actions">


<a
    href="<?= e(BASE_URL . 'admin-enquiries.php'); ?>"
    class="top-link hide-mobile"
>

<i class="fa-regular fa-message"></i>

Enquiries

</a>


<a
    href="<?= e(BASE_URL . 'admin-bookings.php'); ?>"
    class="top-link hide-mobile"
>

<i class="fa-solid fa-suitcase"></i>

Bookings

</a>


<a
    href="<?= e(BASE_URL . 'admin-dashboard.php'); ?>"
    class="top-link"
>

<i class="fa-solid fa-gauge-high"></i>

Dashboard

</a>


</div>


</header>


<main class="page">


<a
    href="<?= e(BASE_URL . 'admin-enquiries.php'); ?>"
    class="back"
>

<i class="fa-solid fa-arrow-left"></i>

Back to Enquiries

</a>


<!-- =========================================================
     PHASE 0A — TRIP FOUNDATION
========================================================= -->
<section style="margin:0 0 16px;padding:16px 18px;border:1px solid #dbeafe;border-radius:16px;background:linear-gradient(135deg,#eff6ff,#f8fafc);display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
    <div>
        <div style="font-size:11px;font-weight:800;letter-spacing:.08em;color:#2563eb;">TRIP / OPPORTUNITY</div>
        <?php if ($trip): ?>
            <div style="font-size:22px;font-weight:900;color:#0f172a;margin-top:3px;"><?= e((string)$trip['trip_code']); ?></div>
            <div style="font-size:12px;color:#64748b;margin-top:3px;">Stage: <?= e(function_exists('crmTripStageLabel') ? crmTripStageLabel((string)$trip['stage']) : (string)$trip['stage']); ?> · <?= e((string)$enquiry['destination']); ?></div>
        <?php else: ?>
            <div style="font-size:16px;font-weight:800;color:#0f172a;margin-top:4px;">No Trip created yet</div>
            <div style="font-size:12px;color:#64748b;margin-top:3px;">Create the permanent Trip record for this enquiry.</div>
        <?php endif; ?>
    </div>
    <?php if ($trip): ?>
        <a href="<?= e(BASE_URL . 'admin-crm.php?lead=' . $enquiryId . '&trip=' . (int)$trip['id']); ?>" style="text-decoration:none;padding:11px 16px;border-radius:10px;background:#2563eb;color:#fff;font-weight:800;font-size:13px;"><i class="fa-solid fa-route"></i> Open Trip Workspace</a>
    <?php else: ?>
        <form method="post" style="margin:0;">
            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
            <input type="hidden" name="enquiry_id" value="<?= (int)$enquiryId; ?>">
            <button type="submit" name="create_trip" value="1" style="border:0;padding:11px 16px;border-radius:10px;background:#16a34a;color:#fff;font-weight:800;font-size:13px;cursor:pointer;"><i class="fa-solid fa-plus"></i> Create Trip</button>
        </form>
    <?php endif; ?>
</section>

<!-- =========================================================
     HEADING
========================================================= -->

<section class="head">


<div>

<div class="eyebrow">

CUSTOMER ENQUIRY

</div>


<h1>

Enquiry #ENQ<?= str_pad(
    (string)$enquiryId,
    5,
    '0',
    STR_PAD_LEFT
); ?>

</h1>


<div class="head-meta">

<span>

<i class="fa-regular fa-clock"></i>

Received
<?= e(
    enquiryDate(
        $enquiry['created_at']
    )
); ?>

</span>


<span>•</span>


<span>

Last updated
<?= e(
    enquiryDate(
        $enquiry['updated_at']
    )
); ?>

</span>

</div>

</div>


<span
    class="status <?= e(
        enquiryStatusClass(
            $enquiry['status']
        )
    ); ?>"
>

<?= e(
    enquiryStatusLabel(
        $enquiry['status']
    )
); ?>

</span>


</section>


<!-- =========================================================
     ALERTS
========================================================= -->

<?php if ($success !== ''): ?>

<div class="alert alert-success">

<i class="fa-solid fa-circle-check"></i>

<div>
<?= e($success); ?>
</div>

</div>

<?php endif; ?>


<?php if ($error !== ''): ?>

<div class="alert alert-error">

<i class="fa-solid fa-circle-exclamation"></i>

<div>
<?= e($error); ?>
</div>

</div>

<?php endif; ?>


<div class="layout">


<!-- =========================================================
     LEFT
========================================================= -->

<div class="stack">


<!-- CUSTOMER -->

<section class="card">


<div class="card-head">

<h2>
Customer Information
</h2>

<span>
Enquiry contact
</span>

</div>


<div class="card-body">


<div class="customer-top">


<div class="avatar">

<?= e(
    strtoupper(
        mb_substr(
            trim(
                $enquiry['name']
            ),
            0,
            1
        )
    )
); ?>

</div>


<div>

<h3>

<?= e(
    $enquiry['name']
); ?>

</h3>


<p>

<?= e(
    $enquiry['email']
    ?: 'No email provided'
); ?>

</p>


<p>

<?= e(
    $enquiry['mobile']
); ?>

</p>

</div>


</div>


<div class="contact-actions">


<?php if ($phoneLink !== ''): ?>

<a
    href="tel:<?= e($phoneLink); ?>"
    class="contact-btn"
>

<i class="fa-solid fa-phone"></i>

Call Customer

</a>

<?php endif; ?>


<?php if (
    $emailLink !== ''
    &&
    filter_var(
        $emailLink,
        FILTER_VALIDATE_EMAIL
    )
): ?>

<a
    href="mailto:<?= e($emailLink); ?>"
    class="contact-btn"
>

<i class="fa-regular fa-envelope"></i>

Send Email

</a>

<?php endif; ?>


</div>


<div class="detail-grid">


<div class="detail">

<div class="detail-label">

<i class="fa-solid fa-location-dot"></i>

Destination

</div>

<strong>

<?= e(
    $enquiry['destination']
    ?: (
        $enquiry[
            'package_destination'
        ]
        ?: 'Not specified'
    )
); ?>

</strong>

</div>


<div class="detail">

<div class="detail-label">

<i class="fa-regular fa-calendar"></i>

Travel Date

</div>

<strong>

<?= e(
    !empty(
        $enquiry['travel_date']
    )
        ? enquiryDate(
            $enquiry['travel_date'],
            false
        )
        : 'Flexible / Not specified'
); ?>

</strong>

</div>


<div class="detail">

<div class="detail-label">

<i class="fa-solid fa-user-group"></i>

Travellers

</div>

<strong>

<?= (int)$enquiry['adults']; ?>

Adult<?= (int)$enquiry['adults'] === 1 ? '' : 's'; ?>

&nbsp;•&nbsp;

<?= (int)$enquiry['children']; ?>

Child<?= (int)$enquiry['children'] === 1 ? '' : 'ren'; ?>

</strong>

</div>


<div class="detail">

<div class="detail-label">

<i class="fa-solid fa-wallet"></i>

Customer Budget

</div>

<strong>

<?= e(
    enquiryMoney(
        $enquiry['budget']
    )
); ?>

</strong>

</div>


</div>


</div>


</section>


<!-- CUSTOMER MESSAGE -->

<section class="card">


<div class="card-head">

<h2>
Customer Message
</h2>

<span>
Original enquiry
</span>

</div>


<div class="card-body">


<div class="message-box"><?=
    e(
        $enquiry['message']
        ?: 'The customer did not provide an additional message.'
    );
?></div>


</div>


</section>


<!-- QUOTATION WORKFLOW -->

<section class="card quote-workflow-card" id="quotation-workflow">

<div class="card-head">
    <h2>Enquiry → Quotation Workspace</h2>
    <span>One clear next step</span>
</div>

<div class="card-body">

<?php
$flowRank = 1;
if ($latestQuotation) $flowRank = 2;
if (in_array($quotationWorkflowState, ['accepted','change_requested','rejected'], true)) $flowRank = 4;
if ($quotationWorkflowState === 'accepted') $flowRank = 4;
if ($quotationWorkflowState === 'converted' || $existingBooking) $flowRank = 6;
?>

<div class="quote-workflow-hero">
    <div class="quote-flow">
        <div class="quote-step <?= $flowRank > 1 ? 'done' : 'active'; ?>"><i class="fa-solid fa-inbox"></i>1. Enquiry</div>
        <div class="quote-step <?= $flowRank > 2 ? 'done' : ($flowRank === 2 ? 'active' : ''); ?>"><i class="fa-solid fa-file-pen"></i>2. Quotation</div>
        <div class="quote-step <?= $flowRank > 3 ? 'done' : ($flowRank === 3 ? 'active' : ''); ?>"><i class="fa-solid fa-paper-plane"></i>3. Send</div>
        <div class="quote-step <?= $flowRank > 4 ? 'done' : ($flowRank === 4 ? 'active' : ''); ?>"><i class="fa-solid fa-user-check"></i>4. Decision</div>
        <div class="quote-step <?= $flowRank > 5 ? 'done' : ($flowRank === 5 ? 'active' : ''); ?>"><i class="fa-solid fa-clipboard-check"></i>5. Admin Review</div>
        <div class="quote-step <?= ($flowRank >= 6) ? 'done active' : ''; ?>"><i class="fa-solid fa-suitcase"></i>6. Booking</div>
    </div>

    <div class="quote-status-row">
        <div class="quote-status-main">
            <span class="quote-status-label"><i class="fa-solid fa-route"></i><?= e($quotationWorkflowLabel); ?></span>
            <h3><?= e($enquiry['name']); ?> · <?= e($enquiry['destination'] ?: ($enquiry['package_destination'] ?? 'Custom Trip')); ?></h3>
            <p><?= e($quotationWorkflowHint); ?></p>
        </div>
    </div>

    <div class="quote-summary">
        <div class="quote-summary-item"><span>Travel Date</span><strong><?= e(enquiryDate($enquiry['travel_date'], false)); ?></strong></div>
        <div class="quote-summary-item"><span>Travellers</span><strong><?= (int)$enquiry['adults']; ?> Adult<?= (int)$enquiry['adults'] === 1 ? '' : 's'; ?> + <?= (int)$enquiry['children']; ?> Child<?= (int)$enquiry['children'] === 1 ? '' : 'ren'; ?></strong></div>
        <div class="quote-summary-item"><span>Customer Budget</span><strong><?= e(enquiryMoney($enquiry['budget'])); ?></strong></div>
        <div class="quote-summary-item"><span>Latest Selling Price</span><strong><?= $latestQuotation ? '₹' . number_format((float)($latestQuotation['final_price'] ?? 0), 2) : 'Not quoted yet'; ?></strong></div>
    </div>

    <?php if ($latestQuotation): ?>
    <div class="quote-summary">
        <div class="quote-summary-item"><span>Latest Version</span><strong>V<?= max(1,(int)$latestQuotation['version_number']); ?></strong></div>
        <div class="quote-summary-item"><span>Package</span><strong><?= e($latestQuotation['package_title'] ?: 'Custom Package'); ?></strong></div>
        <div class="quote-summary-item"><span>Hotel Category</span><strong><?= e($latestQuotation['hotel_category'] ?: 'Not selected'); ?></strong></div>
        <div class="quote-summary-item"><span>Created</span><strong><?= e(enquiryDate($latestQuotation['created_at'])); ?></strong></div>
    </div>
    <?php endif; ?>

    <div class="quote-actions">
        <?php if (!$latestQuotation): ?>
            <a class="quote-action primary" href="<?= e(BASE_URL . 'admin-crm.php?lead=' . (int)$enquiryId . '#crm-package'); ?>"><i class="fa-solid fa-plus"></i>Create Quotation</a>
        <?php else: ?>
            <a class="quote-action primary" href="<?= e(BASE_URL . 'admin-crm.php?lead=' . (int)$enquiryId . '&quote_version=' . (int)$latestQuotation['id'] . '#quotationVersion-' . (int)$latestQuotation['id']); ?>"><i class="fa-solid fa-pen-to-square"></i>Open / Edit Quotation</a>
            <a class="quote-action" target="_blank" href="<?= e(BASE_URL . 'admin-crm.php?quotation_preview=1&lead=' . (int)$enquiryId . '&version=' . (int)$latestQuotation['id']); ?>"><i class="fa-solid fa-eye"></i>Preview Customer View</a>
            <a class="quote-action" href="<?= e(BASE_URL . 'admin-customer-quotations.php?lead=' . (int)$enquiryId); ?>"><i class="fa-solid fa-clock-rotate-left"></i>Quotation Versions</a>
        <?php endif; ?>

        <?php if ($quotationWorkflowState === 'accepted'): ?>
            <a class="quote-action success" href="<?= e(BASE_URL . 'admin-customer-quotations.php?lead=' . (int)$enquiryId . '&review=' . (int)$latestQuotation['id']); ?>"><i class="fa-solid fa-clipboard-check"></i>Review Accepted Quotation</a>
        <?php elseif ($quotationWorkflowState === 'change_requested'): ?>
            <a class="quote-action warning" href="<?= e(BASE_URL . 'admin-crm.php?lead=' . (int)$enquiryId . '&quote_version=' . (int)$latestQuotation['id'] . '#quotationVersion-' . (int)$latestQuotation['id']); ?>"><i class="fa-solid fa-rotate"></i>Create Revised Version</a>
        <?php endif; ?>

        <?php if ($quotationBooking): ?>
            <a class="quote-action success" href="<?= e(BASE_URL . 'admin-booking-details.php?id=' . (int)$quotationBooking['id']); ?>"><i class="fa-solid fa-suitcase"></i>Open Booking <?= e($quotationBooking['booking_number']); ?></a>
        <?php elseif ($existingBooking): ?>
            <a class="quote-action success" href="<?= e(BASE_URL . 'admin-booking-details.php?id=' . (int)$existingBooking['id']); ?>"><i class="fa-solid fa-suitcase"></i>Open Existing Booking</a>
        <?php endif; ?>
    </div>

    <div class="quote-next">
        <strong>Next action:</strong>
        <?php if (!$latestQuotation): ?>Create the quotation and add itinerary, hotel, vehicle/services, costing and selling price.
        <?php elseif ($quotationWorkflowState === 'accepted'): ?>Review supplier/availability requirements and the accepted customer-facing version. Convert to booking only from the Quotation Desk after all checks pass.
        <?php elseif ($quotationWorkflowState === 'change_requested'): ?>Review the customer request, revise the quotation and issue a new version.
        <?php elseif ($quotationWorkflowState === 'rejected'): ?>Review the rejection note before deciding whether to follow up or revise the quotation.
        <?php elseif ($quotationWorkflowState === 'converted' || $existingBooking): ?>Quotation workflow is complete. Continue from Booking Operations.
        <?php else: ?>Open the latest quotation, verify all details, preview the customer view and send it for decision.
        <?php endif; ?>
    </div>
</div>

</div>
</section>


</div>


<!-- =========================================================
     RIGHT
========================================================= -->

<aside class="stack">


<!-- PACKAGE -->

<section class="card">


<div class="card-head">

<h2>
Linked Package
</h2>

</div>


<div class="card-body">


<?php if (
    !empty(
        $enquiry['package_title']
    )
): ?>


<div class="package-title">

<?= e(
    $enquiry['package_title']
); ?>

</div>


<?php if (
    !empty(
        $enquiry['package_code']
    )
): ?>

<div class="package-code">

<?= e(
    $enquiry['package_code']
); ?>

</div>

<?php endif; ?>


<div class="package-meta">


<div class="package-meta-item">

<span>
Destination
</span>

<strong>

<?= e(
    trim(
        (
            $enquiry[
                'package_destination'
            ]
            ?? ''
        )
        .
        (
            !empty(
                $enquiry[
                    'package_country'
                ]
            )
                ? ', '
                  . $enquiry[
                      'package_country'
                  ]
                : ''
        )
    )
    ?: '—'
); ?>

</strong>

</div>


<div class="package-meta-item">

<span>
Duration
</span>

<strong>

<?= (int)$enquiry['duration_days']; ?>

Days /

<?= (int)$enquiry['duration_nights']; ?>

Nights

</strong>

</div>


<div class="package-meta-item">

<span>
Package Price
</span>

<strong>

<?php

$displayPackagePrice =
    (float)(
        $enquiry[
            'package_sale_price'
        ]
        ?? 0
    ) > 0

        ? $enquiry[
            'package_sale_price'
        ]

        : $enquiry[
            'package_regular_price'
        ];

?>

<?= e(
    enquiryMoney(
        $displayPackagePrice
    )
); ?>

</strong>

</div>


<div class="package-meta-item">

<span>
Package ID
</span>

<strong>

#<?= (int)$enquiry['package_id']; ?>

</strong>

</div>


</div>


<?php if (
    !empty(
        $enquiry['slug']
    )
): ?>

<a
    href="<?= e(
        BASE_URL
        . 'package-details.php?slug='
        . urlencode(
            $enquiry['slug']
        )
    ); ?>"
    target="_blank"
    class="package-link"
>

<i class="fa-solid fa-arrow-up-right-from-square"></i>

Open Package

</a>

<?php endif; ?>


<?php else: ?>


<div class="message-box">

This customer submitted a general enquiry and did not select a package.

</div>


<?php endif; ?>


</div>


</section>


<!-- STATUS / NOTES -->

<section class="card">


<div class="card-head">

<h2>
Manage Enquiry
</h2>

</div>


<div class="card-body">


<form
    method="post"
    action=""
>


<input
    type="hidden"
    name="csrf_token"
    value="<?= e($csrfToken); ?>"
>


<input
    type="hidden"
    name="enquiry_id"
    value="<?= (int)$enquiryId; ?>"
>


<div class="form-group">

<label for="status">
ENQUIRY STATUS
</label>


<select
    name="status"
    id="status"
    class="form-control"
    required
>


<?php foreach (
    $allowedStatuses
    as $status
): ?>

<option
    value="<?= e($status); ?>"
    <?= $enquiry['status'] === $status
        ? 'selected'
        : ''; ?>
>

<?= e(
    enquiryStatusLabel(
        $status
    )
); ?>

</option>

<?php endforeach; ?>


</select>

</div>


<div class="form-group">

<label for="admin_notes">
ADMIN NOTES
</label>


<textarea
    name="admin_notes"
    id="admin_notes"
    class="form-control"
    maxlength="10000"
    placeholder="Add call notes, customer preferences, follow-up information..."
><?= e(
    $enquiry['admin_notes']
    ?? ''
); ?></textarea>

</div>


<button
    type="submit"
    name="save_enquiry"
    value="1"
    class="save-button"
>

<i class="fa-solid fa-floppy-disk"></i>

Save Enquiry

</button>


</form>


</div>


</section>


<!-- ACTIVITY -->

<section class="card">


<div class="card-head">

<h2>
Activity
</h2>

</div>


<div class="card-body">


<div class="timeline">


<div class="timeline-item">

<span class="timeline-dot"></span>

<strong>
Enquiry received
</strong>

<span>

<?= e(
    enquiryDate(
        $enquiry['created_at']
    )
); ?>

</span>

</div>


<div class="timeline-item">

<span class="timeline-dot"></span>

<strong>
Current status
</strong>

<span>

<?= e(
    enquiryStatusLabel(
        $enquiry['status']
    )
); ?>

</span>

</div>


<?php if (
    $enquiry['updated_at']
    !==
    $enquiry['created_at']
): ?>

<div class="timeline-item">

<span class="timeline-dot"></span>

<strong>
Last updated
</strong>

<span>

<?= e(
    enquiryDate(
        $enquiry['updated_at']
    )
); ?>

</span>

</div>

<?php endif; ?>


<?php if ($existingBooking): ?>

<div class="timeline-item">

<span class="timeline-dot"></span>

<strong>
Booking created
</strong>

<span>

<?= e(
    $existingBooking[
        'booking_number'
    ]
); ?>

<br>

<?= e(
    enquiryDate(
        $existingBooking[
            'created_at'
        ]
    )
); ?>

</span>

</div>

<?php endif; ?>


</div>


</div>


</section>


</aside>


</div>


</main>











<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>