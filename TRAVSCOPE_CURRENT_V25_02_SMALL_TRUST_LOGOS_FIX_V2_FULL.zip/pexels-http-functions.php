<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE PEXELS HTTPS CLIENT
| V21.9 - shared-hosting resilient outbound HTTPS
|--------------------------------------------------------------------------
| Keeps TLS verification enabled. Retries transient DNS/connect/TLS/timeouts
| and uses IPv4 + HTTP/1.1 on retry, which avoids common shared-hosting
| IPv6/TLS stalls without weakening SSL security.
|--------------------------------------------------------------------------
*/

if (!function_exists('tsPexelsHttpRequest')) {
    /**
     * @return array{body:string,status:int,content_type:string}
     */
    function tsPexelsHttpRequest(
        string $url,
        array $headers = [],
        ?string $downloadFile = null,
        int $timeout = 45
    ): array {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('PHP cURL is required for Pexels requests.');
        }

        $attempts = [
            ['connect' => 12, 'timeout' => max(30, $timeout), 'ipv4' => false],
            ['connect' => 20, 'timeout' => max(45, $timeout), 'ipv4' => true],
            ['connect' => 25, 'timeout' => max(60, $timeout), 'ipv4' => true],
        ];

        $lastError = '';
        $lastErrno = 0;

        foreach ($attempts as $index => $attempt) {
            $curl = curl_init($url);
            $handle = null;

            if ($downloadFile !== null) {
                $handle = @fopen($downloadFile, 'wb');
                if (!$handle) {
                    throw new RuntimeException('Unable to prepare the Pexels download file.');
                }
            }

            $options = [
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 4,
                CURLOPT_CONNECTTIMEOUT => (int)$attempt['connect'],
                CURLOPT_TIMEOUT => (int)$attempt['timeout'],
                CURLOPT_NOSIGNAL => true,
                CURLOPT_HTTPHEADER => array_values($headers),
                CURLOPT_USERAGENT => 'TRAVSCOPE/21.9 Pexels Client',
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
            ];

            if (defined('CURL_HTTP_VERSION_1_1')) {
                $options[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
            }

            if (!empty($attempt['ipv4']) && defined('CURL_IPRESOLVE_V4')) {
                $options[CURLOPT_IPRESOLVE] = CURL_IPRESOLVE_V4;
            }

            if ($downloadFile === null) {
                $options[CURLOPT_RETURNTRANSFER] = true;
            } else {
                $options[CURLOPT_FILE] = $handle;
            }

            curl_setopt_array($curl, $options);
            $result = curl_exec($curl);
            $errno = curl_errno($curl);
            $error = trim((string)curl_error($curl));
            $status = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
            $contentType = strtolower((string)curl_getinfo($curl, CURLINFO_CONTENT_TYPE));
            curl_close($curl);

            if (is_resource($handle)) {
                fclose($handle);
            }

            if ($result !== false) {
                return [
                    'body' => $downloadFile === null ? (string)$result : '',
                    'status' => $status,
                    'content_type' => $contentType,
                ];
            }

            $lastErrno = $errno;
            $lastError = $error !== '' ? $error : ('cURL error ' . $errno);

            if ($downloadFile !== null && is_file($downloadFile)) {
                @unlink($downloadFile);
            }

            $retryable = in_array($errno, [6, 7, 28, 35, 52, 56], true);
            if (!$retryable || $index === count($attempts) - 1) {
                break;
            }

            usleep(250000 * ($index + 1));
        }

        $message = 'Pexels connection failed';
        if ($lastError !== '') {
            $message .= ': ' . $lastError;
        }

        if ($lastErrno === 28 || stripos($lastError, 'SSL connection timeout') !== false) {
            $message .= '. TRAVSCOPE retried over IPv4. If this still occurs, the hosting server is timing out outbound HTTPS to api.pexels.com:443.';
        }

        throw new RuntimeException($message);
    }
}
