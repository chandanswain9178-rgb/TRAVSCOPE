TRAVSCOPE V24.99 — RESPONSIVE LAYOUT & TYPOGRAPHY FOUNDATION
Base: TRAVSCOPE V24.98 Laptop-first CRM Workspaces
Release type: Screen/UI-only upgrade; no database/schema changes.

SCOPE
-----
- Applied shared screen-only CSS and progressive table overflow handling to 97 HTML-rendering PHP pages:
  68 administration/staff pages; 29 customer/public pages.
- Added three purpose-specific CSS assets and one lightweight JavaScript asset:
  assets/travscope-responsive-core-v2499.css
  assets/travscope-responsive-admin-v2499.css
  assets/travscope-responsive-public-v2499.css
  assets/travscope-responsive-v2499.js
- Shared DM Sans / Manrope font stacks with Nirmala UI and Indic-script fallbacks.
  Pages missing a direct web-font link now load a consistent Google Fonts stylesheet.
- Raised several small admin labels, field values, buttons and itinerary-studio text.
- Adjusted form/grid wrapping, max-width and overflow behaviour at 1366 / 1100 / 1024 / 767 / 390px.
- Mobile form controls use 16px input text to reduce unwanted browser zoom.
- Oversized native HTML tables get an accessible, keyboard-focusable horizontal-scroll region
  without moving the table or changing its structure.
- Existing media queries, menu behaviour, costing, SQL, booking, quotation saving and
  administrative business logic remain in place.
- Financial/print-document layouts were deliberately NOT restyled. New stylesheets declare
  media=screen and CSS rules are explicitly scoped to @media screen.

PRIORITY PAGES COVERED
----------------------
admin-crm.php
admin-dashboard.php
admin-bookings.php
admin-booking-details.php
admin-supplier-packages.php
admin-supplier-requests.php
admin-trip-hotel-allocations.php
admin-trip-transport-allocations.php
admin-supplier-package-import.php
admin-settings.php
package-details.php
packages.php
index.php
book-package.php
dashboard.php
login.php
register.php
payment.php

DEPLOYMENT ON MILESWEB DEVELOPMENT HOST
--------------------------------------
1. Back up the complete existing V24.98 website and database.
2. Upload the PATCH ZIP to the site's actual web-root and preserve its folder structure.
3. Ensure the four new files exist under the site /assets/ directory.
4. Hard-refresh (Ctrl+Shift+R). Query-string ?v=2499 helps bust CSS/JS cache.
5. Test with at least one representative quotation/package/booking record as Admin
   and one customer login. Check supplier RFQ and pricing selectors still save.
6. Test screen widths: 1920x1080, 1366x768, 1280x800, 768x1024,
   390x844, 360x800, 320x568; also 200% browser zoom.
7. Export a complete quotation at A4 and ensure no unexpected changes from V24.98.
8. If a module behaves unexpectedly, restore the V24.98 backup and report
   page URL, screen resolution, browser zoom and a screenshot.

VALIDATION SCOPE / LIMITATIONS
-----------------------------
- Syntax: PHP and JavaScript checked locally; archive/asset consistency checked.
- Responsive rendering: representative STATIC UI fixture tested in Chromium across
  eight screen widths. Full authenticated CRM/browser flows and PDF export need QA
  on the MilesWeb development installation; not represented as passed.
- No server files, settings, database tables or production data were changed remotely.

DATABASE
--------
No SQL required.
