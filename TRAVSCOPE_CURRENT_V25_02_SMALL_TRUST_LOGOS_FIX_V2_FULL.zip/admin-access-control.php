<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/access-control-functions.php';

requireAdmin();
$admin = currentAdmin($pdo);
if (!$admin || strtolower((string)($admin['status'] ?? '')) !== 'active') {
    unset($_SESSION['admin_id'], $_SESSION['admin_name'], $_SESSION['admin_email'], $_SESSION['admin_role']);
    redirect(BASE_URL . 'admin-login.php');
}

$adminId = (int)$admin['id'];
if (!tsAclReady($pdo)) {
    $aclReady = false;
} else {
    $aclReady = true;
    if (!tsAclCan($pdo, $adminId, 'manage_access') && !tsAclCan($pdo, $adminId, 'view_audit')) {
        http_response_code(403);
        exit('Permission denied.');
    }
}

if (empty($_SESSION['admin_access_csrf'])) $_SESSION['admin_access_csrf'] = bin2hex(random_bytes(32));
$csrf = (string)$_SESSION['admin_access_csrf'];
$error=''; $success='';
if (!empty($_SESSION['admin_access_success'])) { $success=(string)$_SESSION['admin_access_success']; unset($_SESSION['admin_access_success']); }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        if (!hash_equals($csrf, (string)($_POST['csrf_token'] ?? ''))) throw new RuntimeException('Security verification failed.');
        if (!$aclReady) throw new RuntimeException('Import TRAVSCOPE_Permissions_Approval_Control_Matrix.sql first.');
        if (!tsAclCan($pdo, $adminId, 'manage_access')) throw new RuntimeException('Permission denied: Manage Permissions.');

        $action=(string)($_POST['action'] ?? '');
        if ($action !== 'save_access') throw new RuntimeException('Invalid access action.');
        $target=max(0,(int)($_POST['target_admin_id'] ?? 0));
        $profile=(string)($_POST['access_profile'] ?? 'admin');
        $overrides=is_array($_POST['permission_override'] ?? null) ? $_POST['permission_override'] : [];
        tsAclSaveAdminAccess($pdo,$adminId,$target,$profile,$overrides);
        $_SESSION['admin_access_success']='Access profile and permission overrides saved.';
        redirect(BASE_URL . 'admin-access-control.php?admin_id=' . $target);
    } catch (RuntimeException $e) { $error=$e->getMessage(); }
      catch (Throwable $e) { error_log('Admin Access Control: '.$e->getMessage()); $error='Unable to save access settings: '.$e->getMessage(); }
}

$admins=[];
try {
    $admins=$pdo->query("SELECT id,name,email,role,status FROM admins ORDER BY status='active' DESC,name ASC,id ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

$selectedId=max(0,(int)($_GET['admin_id'] ?? 0));
if ($selectedId<=0 && $admins) $selectedId=(int)$admins[0]['id'];
$selected=null;
foreach ($admins as $row) if ((int)$row['id']===$selectedId) { $selected=$row; break; }

$profile=$selected ? tsAclProfile($pdo,$selectedId,(string)$selected['role']) : 'admin';
$overrides=$selected ? tsAclOverrides($pdo,$selectedId) : [];
$effective=$selected ? tsAclEffective($pdo,$selectedId,(string)$selected['role']) : [];
$catalog=tsAclPermissionCatalog();
$profiles=tsAclProfiles();
$audit=(tsAclReady($pdo) && tsAclCan($pdo,$adminId,'view_audit')) ? tsAclAuditRows($pdo,250) : [];

function acE($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function acLabel($s): string { return ucwords(str_replace('_',' ',(string)$s)); }
?><!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Access Control & Audit | TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:66px;padding:10px 4%;display:flex;justify-content:space-between;align-items:center;gap:10px;background:#fff;border-bottom:1px solid #dfe7f0;position:sticky;top:0;z-index:20}.brand{font-weight:900}.brand span{color:#2563eb}.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 10px;border:1px solid #cbd5e1;border-radius:9px;background:#fff;color:#334155;text-decoration:none;font-size:9px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.wrap{max-width:1400px;margin:20px auto;padding:0 13px}.hero{padding:16px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:20px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px}.notice{margin-top:10px;padding:10px 12px;border-radius:10px;font-size:10px}.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#047857}.err{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c}.grid{display:grid;grid-template-columns:300px 1fr;gap:11px;margin-top:11px}.card{background:#fff;border:1px solid #dfe7f0;border-radius:13px;overflow:hidden}.card.full{grid-column:1/-1}.head{padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff}.head h2{margin:0;font-size:12px}.head p{margin:4px 0 0;color:#64748b;font-size:8.5px}.body{padding:11px}.admin-row{display:block;padding:9px;border:1px solid #e2e8f0;border-radius:9px;margin-bottom:6px;color:#334155;text-decoration:none}.admin-row.active{background:#eff6ff;border-color:#bfdbfe}.admin-row strong{display:block;font-size:9.5px}.admin-row small{display:block;margin-top:3px;color:#64748b;font-size:8px}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.field label{display:block;margin-bottom:4px;color:#475569;font-size:8px;font-weight:900}.field select{width:100%;min-height:34px;border:1px solid #cbd5e1;border-radius:8px;padding:6px 8px;font-size:9px}.perm-group{margin-top:10px;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden}.perm-title{padding:8px 10px;background:#f8fafc;font-size:9px;font-weight:900}.perm-row{display:grid;grid-template-columns:minmax(220px,1fr) 120px 100px;gap:8px;align-items:center;padding:8px 10px;border-top:1px solid #eef2f7}.perm-row strong{font-size:8.5px}.perm-row select{min-height:31px;border:1px solid #cbd5e1;border-radius:7px;font-size:8px}.state{padding:4px 7px;border-radius:999px;font-size:7.5px;font-weight:900;text-align:center}.state.yes{background:#dcfce7;color:#166534}.state.no{background:#fef2f2;color:#b91c1c}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse}th,td{padding:7px 8px;border-bottom:1px solid #eef2f7;text-align:left;font-size:8px;white-space:nowrap}th{background:#f8fafc;color:#64748b;font-size:7px;text-transform:uppercase}.pill{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:7px;font-weight:900}.pill.authorized{background:#ecfdf5;color:#047857}.pill.denied{background:#fef2f2;color:#b91c1c}.preset{display:grid;grid-template-columns:repeat(5,1fr);gap:7px;margin-top:8px}.preset div{padding:8px;border:1px solid #e2e8f0;border-radius:9px;background:#f8fafc}.preset strong{display:block;font-size:8px}.preset small{display:block;margin-top:3px;color:#64748b;font-size:7.5px;line-height:1.4}@media(max-width:900px){.grid{grid-template-columns:1fr}.preset{grid-template-columns:1fr 1fr}.perm-row{grid-template-columns:1fr 100px 85px}}@media(max-width:600px){.top{flex-direction:column;align-items:flex-start}.form-grid,.preset,.perm-row{grid-template-columns:1fr}}
</style>
<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head><body>
<header class="top"><div class="brand">TRAV<span>SCOPE</span> · ACCESS CONTROL</div><div style="display:flex;gap:7px;flex-wrap:wrap"><a class="btn" href="<?=acE(BASE_URL.'admin-dashboard.php')?>"><i class="fa-solid fa-gauge-high"></i> Dashboard</a><a class="btn" href="<?=acE(BASE_URL.'admin-business-analytics.php')?>"><i class="fa-solid fa-chart-line"></i> Analytics</a></div></header>
<main class="wrap">
<section class="hero"><h1>Permissions + Approval Control Matrix</h1><p>Keep the existing admins.role field intact. Assign an operational access profile, then optionally Allow/Deny individual protected actions. Every protected-action authorization or denial is written to the audit log.</p></section>
<?php if($success):?><div class="notice ok"><?=acE($success)?></div><?php endif;?>
<?php if($error):?><div class="notice err"><?=acE($error)?></div><?php endif;?>
<?php if(!$aclReady):?><div class="notice err">Import <strong>TRAVSCOPE_Permissions_Approval_Control_Matrix.sql</strong>. Until then, existing admin access remains unchanged so deployment cannot lock you out.</div><?php endif;?>

<div class="grid">
<section class="card"><div class="head"><h2>Admin Accounts</h2><p>Existing accounts from your current admins table.</p></div><div class="body">
<?php foreach($admins as $row):?><a class="admin-row <?=(int)$row['id']===$selectedId?'active':''?>" href="<?=acE(BASE_URL.'admin-access-control.php?admin_id='.(int)$row['id'])?>"><strong><?=acE($row['name'])?></strong><small><?=acE($row['email'])?> · Legacy <?=acE(acLabel($row['role']))?> · <?=acE(strtoupper($row['status']))?></small></a><?php endforeach;?>
</div></section>

<section class="card"><div class="head"><h2>Access Profile & Overrides</h2><p>Preset permissions are inherited unless an individual override is selected.</p></div><div class="body">
<?php if($selected):?>
<form method="post"><input type="hidden" name="csrf_token" value="<?=acE($csrf)?>"><input type="hidden" name="action" value="save_access"><input type="hidden" name="target_admin_id" value="<?=(int)$selected['id']?>">
<div class="form-grid"><div class="field"><label>Admin</label><select disabled><option><?=acE($selected['name'].' · '.$selected['email'])?></option></select></div><div class="field"><label>Access Profile</label><select name="access_profile" <?=$aclReady&&tsAclCan($pdo,$adminId,'manage_access')?'':'disabled'?>><?php foreach(array_keys($profiles) as $p):?><option value="<?=acE($p)?>" <?=$profile===$p?'selected':''?>><?=acE(acLabel($p))?></option><?php endforeach;?></select></div></div>
<?php foreach($catalog as $groupKey=>$group):?><div class="perm-group"><div class="perm-title"><?=acE(acLabel($groupKey))?></div><?php foreach($group as $key=>$label):?><div class="perm-row"><strong><?=acE($label)?></strong><select name="permission_override[<?=acE($key)?>]" <?=$aclReady&&tsAclCan($pdo,$adminId,'manage_access')?'':'disabled'?>><option value="inherit" <?=!isset($overrides[$key])?'selected':''?>>Inherit Profile</option><option value="allow" <?=($overrides[$key]??'')==='allow'?'selected':''?>>Allow</option><option value="deny" <?=($overrides[$key]??'')==='deny'?'selected':''?>>Deny</option></select><span class="state <?=!empty($effective[$key])?'yes':'no'?>"><?=!empty($effective[$key])?'ALLOWED':'DENIED'?></span></div><?php endforeach;?></div><?php endforeach;?>
<?php if($aclReady&&tsAclCan($pdo,$adminId,'manage_access')):?><button class="btn primary" type="submit" style="margin-top:10px"><i class="fa-solid fa-floppy-disk"></i> Save Access</button><?php endif;?>
</form><?php endif;?>
</div></section>

<section class="card full"><div class="head"><h2>Preset Role Matrix</h2><p>Operational profiles do not modify the current admins.role enum.</p></div><div class="body"><div class="preset">
<div><strong>Super Admin</strong><small>All protected commercial, operations, finance and access-control permissions.</small></div>
<div><strong>Admin</strong><small>All permissions by default for backward compatibility with your current Admin account.</small></div>
<div><strong>Sales</strong><small>Supplier-cost visibility, quotation markup and sending. Margin and discount approval remain separate.</small></div>
<div><strong>Operations</strong><small>Supplier selection/procurement, booking confirmation, amendments, operations, final voucher and document pack.</small></div>
<div><strong>Finance</strong><small>Supplier/customer money, margin visibility, quotation discount approval, billing adjustment, amendments and profitability closure.</small></div>
</div></div></section>

<?php if($aclReady&&tsAclCan($pdo,$adminId,'view_audit')):?><section class="card full"><div class="head"><h2>Protected Action Audit</h2><p>Latest authorization decisions. DENIED attempts are preserved too.</p></div><div class="body table-wrap"><table><thead><tr><th>Date</th><th>Admin</th><th>Profile</th><th>Permission</th><th>Action</th><th>Entity</th><th>Result</th><th>IP</th></tr></thead><tbody><?php foreach($audit as $row):?><tr><td><?=acE(date('d M Y H:i',strtotime((string)$row['created_at'])))?></td><td><?=acE($row['admin_name']?:'Unknown')?></td><td><?=acE(acLabel($row['access_profile']))?></td><td><?=acE(acLabel($row['permission_key']))?></td><td><?=acE(acLabel($row['action_key']))?></td><td><?=acE(($row['entity_type']?:'-').($row['entity_id']?' #'.$row['entity_id']:''))?></td><td><span class="pill <?=acE($row['result'])?>"><?=acE(strtoupper($row['result']))?></span></td><td><?=acE($row['ip_address'])?></td></tr><?php endforeach;?></tbody></table></div></section><?php endif;?>
</div></main>
<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
