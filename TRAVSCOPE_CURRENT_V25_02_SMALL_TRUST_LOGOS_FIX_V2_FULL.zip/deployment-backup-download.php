<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/deployment-functions.php';

requireAdmin();

$admin = currentAdmin($pdo);

if (!$admin || strtolower((string)($admin['status'] ?? '')) !== 'active') {
    http_response_code(403);
    exit('Admin session is not active.');
}

$adminId = (int)$admin['id'];

if (function_exists('tsAclRequire')) {
    tsAclRequire(
        $pdo,
        $adminId,
        'manage_access',
        'generate_deployment_backup',
        'deployment_backup',
        null
    );
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('POST required.');
}

if (!tsDeployReady($pdo)) {
    http_response_code(503);
    exit('Deployment Safety SQL is not installed.');
}

$sessionToken = (string)($_SESSION['admin_deployment_csrf'] ?? '');
$postedToken = (string)($_POST['csrf_token'] ?? '');

if (
    $sessionToken === ''
    || $postedToken === ''
    || !hash_equals($sessionToken, $postedToken)
) {
    http_response_code(403);
    exit('Security verification failed.');
}

if (strtoupper(trim((string)($_POST['confirm_text'] ?? ''))) !== 'BACKUP') {
    http_response_code(422);
    exit('Type BACKUP to generate a downloadable backup.');
}

$type = (string)($_POST['backup_type'] ?? '');
$releaseId = max(0, (int)($_POST['release_id'] ?? 0));

if (!in_array($type, ['database_sql','settings_json'], true)) {
    http_response_code(422);
    exit('Invalid backup type.');
}

$meta = null;

try {
    if ($type === 'database_sql') {
        $meta = tsDeployGenerateDatabaseBackup($pdo);
        $extension = 'sql';
        $contentType = 'application/sql; charset=UTF-8';
        $label = 'database-table-backup';
    } else {
        $meta = tsDeployGenerateSettingsBackup($pdo);
        $extension = 'json';
        $contentType = 'application/json; charset=UTF-8';
        $label = 'settings-backup';
    }

    $filename =
        'TRAVSCOPE-'
        . $label
        . '-'
        . date('Ymd-His')
        . '.'
        . $extension;

    tsDeployRegisterBackup(
        $pdo,
        $releaseId > 0 ? $releaseId : null,
        $type,
        $filename,
        $meta,
        $adminId
    );

    header('Content-Type: ' . $contentType);
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . (int)$meta['size']);
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('X-Content-Type-Options: nosniff');

    $handle = fopen((string)$meta['path'], 'rb');

    if ($handle === false) {
        throw new RuntimeException('Generated backup file could not be opened.');
    }

    while (!feof($handle)) {
        $chunk = fread($handle, 1024 * 1024);
        if ($chunk === false) {
            break;
        }
        echo $chunk;
        flush();
    }

    fclose($handle);
    @unlink((string)$meta['path']);
    exit;

} catch (Throwable $e) {
    if (is_array($meta) && !empty($meta['path'])) {
        @unlink((string)$meta['path']);
    }

    error_log('TRAVSCOPE deployment backup: ' . $e->getMessage());
    http_response_code(500);
    exit('Unable to generate backup: ' . $e->getMessage());
}
