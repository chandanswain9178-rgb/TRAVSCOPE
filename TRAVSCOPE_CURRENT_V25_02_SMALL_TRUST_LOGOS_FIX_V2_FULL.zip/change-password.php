<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| PASSWORD SECURITY COMPATIBILITY ROUTE
|--------------------------------------------------------------------------
|
| The complete password-change flow already exists in profile.php#security.
| Keep a dedicated route because customer pages already link here, but do not
| duplicate password validation/update logic in a second file.
|
*/

require_once __DIR__ . '/config.php';

requireLogin();

$user = currentUser($pdo);

if (!$user || strtolower((string)($user['status'] ?? '')) !== 'active') {
    unset($_SESSION['user_id']);
    session_regenerate_id(true);
    redirect(BASE_URL . 'login.php');
}

redirect(BASE_URL . 'profile.php#security');
