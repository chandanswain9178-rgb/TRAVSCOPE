<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/supplier-functions.php';
require_once __DIR__ . '/supplier-document-functions.php';
if (is_file(__DIR__ . '/supplier-contract-inventory-functions.php')) {
    require_once __DIR__ . '/supplier-contract-inventory-functions.php';
}
if (is_file(__DIR__ . '/supplier-contract-rate-functions.php')) {
    require_once __DIR__ . '/supplier-contract-rate-functions.php';
}

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . BASE_URL . 'login.php'); exit;
}
$adminId=(int)$_SESSION['admin_id'];
$stmt=$pdo->prepare("SELECT id,name,email,role,status FROM admins WHERE id=? LIMIT 1");
$stmt->execute([$adminId]);
$admin=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$admin || ($admin['status']??'')!=='active'){
    unset($_SESSION['admin_id']); header('Location: '.BASE_URL.'login.php'); exit;
}

function sdvE(?string $v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function sdvTypeLabel(string $v):string{return ucwords(str_replace('_',' ',$v));}

try { tsSupplierDocumentEnsureSchema($pdo); } catch (Throwable $ignored) {}
if(!tsSupplierDocumentCenterReady($pdo)){
    http_response_code(503); exit('Step 11A document/version tables are unavailable. Import travscope-step-11a-milesweb-safe.sql.');
}

$id=max(0,(int)($_GET['id']??$_POST['document_id']??0));
$document=tsSupplierDocumentGet($pdo,$id);
if(!$document){http_response_code(404);exit('Supplier document not found.');}

if(isset($_GET['open_pdf'])){
    try{
        $path=tsSupplierDocumentStoredPath((string)$document['stored_path']);
        $filename=str_replace(['"',"\r","\n"],'',basename((string)$document['original_filename']));
        $ext=strtolower(pathinfo($filename,PATHINFO_EXTENSION));
        $mime=trim((string)($document['mime_type']??''));
        if($mime==='')$mime=$ext==='docx'?'application/vnd.openxmlformats-officedocument.wordprocessingml.document':'application/pdf';
        header('Content-Type: '.$mime);
        header('Content-Disposition: '.($ext==='pdf'?'inline':'attachment').'; filename="'.$filename.'"');
        header('Content-Length: '.(string)filesize($path));
        header('X-Content-Type-Options: nosniff');
        readfile($path); exit;
    }catch(Throwable $e){http_response_code(404);exit('Supplier source document is not available.');}
}

if(empty($_SESSION['supplier_document_view_csrf']))$_SESSION['supplier_document_view_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['supplier_document_view_csrf'];
$success=(string)($_SESSION['supplier_document_view_success']??'');
$error=(string)($_SESSION['supplier_document_view_error']??'');
unset($_SESSION['supplier_document_view_success'],$_SESSION['supplier_document_view_error']);

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        if(!hash_equals($csrf,(string)($_POST['csrf']??'')))throw new RuntimeException('Security verification failed.');
        $action=trim((string)($_POST['action']??''));

        if($action==='reanalyze'){
            $analysis=tsSupplierDocumentReanalyze($pdo,$id);
            $_SESSION['supplier_document_view_success']='Document analyzed again. Source coverage: '.number_format((float)$analysis['source_coverage'],0).'%. No rates were activated automatically.';
        }elseif($action==='create_contract'){
            $result=tsSupplierDocumentCreateContractFromDocument($pdo,$id,$adminId,$_POST);
            $_SESSION['supplier_document_view_success']='Draft contract '.$result['contract_code'].' created as Version 1. Review it, then activate the version when correct.';
        }elseif($action==='add_contract_version'){
            $contractId=max(0,(int)($_POST['contract_id']??0));
            if($contractId<=0)throw new RuntimeException('Select an existing supplier contract.');
            $versionId=tsSupplierDocumentAddContractVersion($pdo,$id,$contractId,$adminId,$_POST);
            $_SESSION['supplier_document_view_success']='A new review version was linked to the existing contract. Version ID '.$versionId.'.';
        }elseif($action==='activate_version'){
            $versionId=max(0,(int)($_POST['version_id']??0));
            if($versionId<=0)throw new RuntimeException('Invalid contract version.');
            tsSupplierDocumentActivateContractVersion($pdo,$versionId,$adminId);
            $_SESSION['supplier_document_view_success']='Seasonal contract version activated. Other active seasons remain available; only an older revision of the same season is superseded.';
        }elseif($action==='archive_document'){
            $pdo->prepare("UPDATE supplier_documents SET status='archived',updated_at=NOW() WHERE id=?")->execute([$id]);
            $_SESSION['supplier_document_view_success']='Supplier document archived. Contract/version history was not deleted.';
        }elseif($action==='restore_document'){
            $pdo->prepare("UPDATE supplier_documents SET status='review',updated_at=NOW() WHERE id=?")->execute([$id]);
            $_SESSION['supplier_document_view_success']='Supplier document restored for review.';
        }else{
            throw new RuntimeException('Invalid Supplier Document action.');
        }

        header('Location: admin-supplier-document.php?id='.$id);exit;
    }catch(Throwable $e){
        $_SESSION['supplier_document_view_error']=$e->getMessage();
        header('Location: admin-supplier-document.php?id='.$id);exit;
    }
}

$document=tsSupplierDocumentGet($pdo,$id);
$analysis=json_decode((string)($document['analysis_json']??''),true);
if(!is_array($analysis))$analysis=[];

$stmt=$pdo->prepare("SELECT * FROM supplier_contracts WHERE supplier_id=? ORDER BY CASE status WHEN 'active' THEN 1 WHEN 'draft' THEN 2 ELSE 3 END,valid_to DESC,id DESC");
$stmt->execute([(int)$document['supplier_id']]);
$contracts=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];

$stmt=$pdo->prepare("\n    SELECT v.*,c.contract_code,c.contract_name,a.name activated_by_name\n    FROM supplier_contract_versions v\n    JOIN supplier_contracts c ON c.id=v.contract_id\n    LEFT JOIN admins a ON a.id=v.activated_by_admin_id\n    WHERE v.supplier_document_id=?\n    ORDER BY v.id DESC\n");
$stmt->execute([$id]);
$versions=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];

$defaultContractName=trim((string)$document['title']);
$defaultCancellation=trim((string)($document['detected_cancellation_terms']??''));
$defaultTransport=trim((string)($document['detected_transport_terms']??''));
$defaultMeal=trim((string)($document['detected_meal_plan']??''));
$coverage=(float)($document['source_coverage']??0);
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=sdvE((string)$document['document_code'])?> | Supplier Document | TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f5f7fb;color:#172033;font-family:Arial,sans-serif}.sidebar{position:fixed;inset:0 auto 0 0;width:260px;background:#07192d;color:#fff;padding:22px 14px;overflow:auto}.brand{display:flex;gap:12px;align-items:center;color:#fff;text-decoration:none;padding:7px 10px 20px}.brand strong{display:block}.brand small{color:#9fb0c6}.menu-title{font-size:10px;letter-spacing:.12em;color:#70849d;padding:19px 12px 7px;font-weight:800}.menu-link{display:flex;gap:11px;align-items:center;color:#c8d2df;text-decoration:none;padding:11px 12px;border-radius:10px;font-size:14px}.menu-link:hover,.menu-link.active{background:#122b47;color:#fff}.main{margin-left:260px}.topbar{height:72px;background:#fff;border-bottom:1px solid #e4e8ef;display:flex;align-items:center;justify-content:space-between;padding:0 26px}.page{padding:26px}.heading{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;margin-bottom:18px}.heading h1{margin:10px 0 0;font-size:25px}.heading p{margin:6px 0;color:#718096}.btn{border:0;border-radius:10px;padding:10px 14px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;gap:7px;align-items:center}.primary{background:#0b74ff;color:#fff}.soft{background:#edf4ff;color:#145fb7}.danger{background:#fff0f0;color:#a72a2a}.good{background:#047857;color:#fff}.panel{background:#fff;border:1px solid #e5e9f0;border-radius:16px;padding:19px;margin-bottom:17px;box-shadow:0 6px 24px rgba(7,25,45,.04)}.panel h2{margin:0 0 14px;font-size:18px}.alert{padding:12px 14px;border-radius:10px;margin-bottom:15px}.ok{background:#e9f8ef;color:#17663e}.err{background:#fff0f0;color:#a23030}.summary{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin-bottom:17px}.summary>div{background:#fff;border:1px solid #e3e8ef;border-radius:13px;padding:13px}.summary span{display:block;color:#718096;font-size:10px;font-weight:800;text-transform:uppercase}.summary strong{display:block;margin-top:5px;font-size:17px}.score{font-size:29px!important;color:#0f766e}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:11px}.full{grid-column:1/-1}.label{display:block;font-size:11px;font-weight:800;margin-bottom:6px}.input,select,textarea{width:100%;border:1px solid #d8e0ea;border-radius:10px;padding:10px;font:inherit;background:#fff}textarea{min-height:95px}.chips{display:flex;gap:7px;flex-wrap:wrap}.chip{padding:6px 8px;background:#eef4fb;border-radius:999px;font-size:10px;font-weight:800}.warn{background:#fff7ed;color:#9a3412}.meta{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.meta div{border-bottom:1px solid #edf1f5;padding:8px 0}.meta small{display:block;color:#718096}.text-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:11px;padding:12px;white-space:pre-wrap;line-height:1.55;font-size:12px;max-height:330px;overflow:auto}.version{border:1px solid #dbeafe;background:#f8fbff;border-radius:12px;padding:12px;margin-bottom:9px}.version-head{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.badge{display:inline-flex;padding:5px 8px;border-radius:999px;font-size:9px;font-weight:900;background:#eef4fb;color:#335a87}.badge.active{background:#ecfdf5;color:#047857}.badge.review{background:#fff7ed;color:#c2410c}.badge.superseded{background:#f1f5f9;color:#64748b}.actions{display:flex;gap:8px;flex-wrap:wrap}.muted{color:#778494}@media(max-width:900px){.sidebar{position:static;width:auto}.main{margin-left:0}.summary,.grid,.meta{grid-template-columns:1fr}.full{grid-column:auto}.page{padding:15px}.topbar{padding:0 15px}.heading{display:block}.actions{margin-top:12px}}
</style>
<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v6">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head><body>
<aside class="sidebar">
<a class="brand" href="admin-dashboard.php"><i class="fa-solid fa-plane-departure"></i><span><strong>TRAVSCOPE</strong><small>Travel Business System</small></span></a>
<div class="menu-title">OVERVIEW</div><a class="menu-link" href="admin-dashboard.php"><i class="fa-solid fa-chart-pie"></i>Dashboard</a>
<div class="menu-title">SALES & CRM</div><a class="menu-link" href="admin-enquiries.php"><i class="fa-regular fa-message"></i>Enquiries</a><a class="menu-link" href="admin-customers.php"><i class="fa-solid fa-users"></i>Customers</a>
<div class="menu-title">TRAVEL PRODUCTS</div><a class="menu-link" href="admin-destinations.php"><i class="fa-solid fa-earth-americas"></i>Destinations</a><a class="menu-link" href="admin-packages.php"><i class="fa-solid fa-suitcase-rolling"></i>Packages</a>
<div class="menu-title">SUPPLIERS</div><a class="menu-link" href="admin-suppliers.php"><i class="fa-solid fa-handshake"></i>Suppliers</a><a class="menu-link active" href="admin-supplier-documents.php"><i class="fa-solid fa-file-contract"></i>Supplier Documents</a><a class="menu-link" href="admin-supplier-rate-books.php"><i class="fa-solid fa-book-open"></i>Rate Books</a><a class="menu-link" href="admin-supplier-requests.php"><i class="fa-solid fa-paper-plane"></i>Supplier Requests</a>
<div class="menu-title">OPERATIONS</div><a class="menu-link" href="admin-bookings.php"><i class="fa-solid fa-calendar-check"></i>Bookings</a>
<div class="menu-title">ADMINISTRATION</div><a class="menu-link" href="admin-settings.php"><i class="fa-solid fa-gear"></i>Settings</a><a class="menu-link" href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i>Logout</a>
</aside>
<main class="main"><header class="topbar"><strong>TRAVSCOPE Administration</strong><span><?=sdvE((string)$admin['name'])?></span></header><div class="page">
<?php if($success):?><div class="alert ok"><?=sdvE($success)?></div><?php endif;?>
<?php if($error):?><div class="alert err"><?=sdvE($error)?></div><?php endif;?>

<div class="heading">
<div><a class="btn soft" href="admin-supplier-documents.php">← Supplier Documents</a><h1><?=sdvE((string)$document['title'])?></h1><p><?=sdvE((string)$document['document_code'])?> · <?=sdvE((string)$document['company_name'])?> · <?=sdvE((string)$document['original_filename'])?></p></div>
<div class="actions"><a class="btn soft" target="_blank" href="admin-supplier-document.php?id=<?=$id?>&open_pdf=1"><i class="fa-solid fa-file-lines"></i> Open Original Document</a><a class="btn soft" href="admin-supplier-details.php?id=<?=(int)$document['supplier_id']?>#contracts-rates"><i class="fa-solid fa-handshake"></i> Supplier 360</a></div>
</div>

<div class="summary">
<div><span>Source Coverage</span><strong class="score"><?=number_format($coverage,0)?>%</strong></div>
<div><span>Detected Type</span><strong><?=sdvE(sdvTypeLabel((string)$document['document_type']))?></strong></div>
<div><span>Itineraries</span><strong><?=number_format((int)$document['detected_itinerary_count'])?></strong></div>
<div><span>Hotel Categories</span><strong><?=number_format((int)$document['detected_hotel_category_count'])?></strong></div>
<div><span>Rate Groups</span><strong><?=number_format((int)$document['detected_rate_group_count'])?></strong></div>
</div>

<div class="panel"><h2>Source Document Intelligence</h2>
<div class="meta">
<div><small>Selected Supplier</small><strong><?=sdvE((string)$document['company_name'])?></strong></div>
<div><small>Detected Letterhead</small><strong><?=sdvE((string)($document['detected_supplier_name']?:'Not detected'))?></strong></div>
<div><small>Validity</small><strong><?=!empty($document['valid_from'])?sdvE((string)$document['valid_from']).' → '.sdvE((string)$document['valid_to']):'Needs review'?></strong></div>
<div><small>Meal Plan</small><strong><?=sdvE((string)($document['detected_meal_plan']?:'Not detected'))?></strong></div>
<div><small>Extraction</small><strong><?=sdvE((string)$document['extraction_method'])?> · <?=sdvE((string)$document['extraction_status'])?></strong></div>
<div><small>Received</small><strong><?=sdvE(date('d M Y H:i',strtotime((string)$document['received_at'])))?></strong></div>
</div>
<?php if(!empty($analysis['itineraries'])):?><h3>Detected Itinerary Products</h3><div class="chips"><?php foreach($analysis['itineraries'] as $it):?><span class="chip"><?=sdvE((string)($it['label']??''))?></span><?php endforeach;?></div><?php endif;?>
<?php if(!empty($analysis['hotel_categories'])):?><h3>Detected Supplier Categories</h3><div class="chips"><?php foreach($analysis['hotel_categories'] as $cat):?><span class="chip"><?=sdvE((string)$cat)?></span><?php endforeach;?></div><?php endif;?>
<?php if(!empty($analysis['warnings'])):?><h3>Review Warnings</h3><div class="chips"><?php foreach($analysis['warnings'] as $w):?><span class="chip warn"><?=sdvE((string)$w)?></span><?php endforeach;?></div><?php endif;?>
<div class="actions" style="margin-top:14px"><form method="post"><input type="hidden" name="csrf" value="<?=sdvE($csrf)?>"><input type="hidden" name="action" value="reanalyze"><input type="hidden" name="document_id" value="<?=$id?>"><button class="btn soft"><i class="fa-solid fa-rotate"></i> Re-analyze Document</button></form><?php if($document['status']==='archived'):?><form method="post"><input type="hidden" name="csrf" value="<?=sdvE($csrf)?>"><input type="hidden" name="action" value="restore_document"><input type="hidden" name="document_id" value="<?=$id?>"><button class="btn soft">Restore</button></form><?php else:?><form method="post" onsubmit="return confirm('Archive this source document? Contract/version history will remain.');"><input type="hidden" name="csrf" value="<?=sdvE($csrf)?>"><input type="hidden" name="action" value="archive_document"><input type="hidden" name="document_id" value="<?=$id?>"><button class="btn danger">Archive</button></form><?php endif;?></div>
</div>

<?php if($defaultCancellation):?><div class="panel"><h2>Detected Cancellation Policy</h2><div class="text-box"><?=sdvE($defaultCancellation)?></div></div><?php endif;?>
<?php if($defaultTransport):?><div class="panel"><h2>Detected Transport / Vehicle Rules</h2><div class="text-box"><?=sdvE($defaultTransport)?></div></div><?php endif;?>
<?php if(!empty($document['detected_tax_notes'])):?><div class="panel"><h2>Detected Tax Notes</h2><div class="text-box"><?=sdvE((string)$document['detected_tax_notes'])?></div></div><?php endif;?>

<div class="panel"><h2>Contract Version History from This Document</h2>
<p class="muted">A document can become Version 1 of a new contract or the next seasonal/revised tariff of an existing supplier contract. Multiple seasons can stay active together. When periods overlap, the higher priority season wins in the CRM Rate Engine; a new revision of the same season supersedes only that season's older active version.</p>
<?php if(!$versions):?><p class="muted">This source document has not been linked to a contract yet.</p><?php endif;?>
<?php foreach($versions as $v):?>
<div class="version"><div class="version-head"><div><strong><?=sdvE((string)$v['contract_code'])?> · <?=sdvE((string)$v['contract_name'])?> · <?=sdvE((string)($v['version_label']?:('V'.$v['version_no'])))?></strong><br><span class="muted"><strong><?=sdvE((string)($v['season_name']??'Regular Season'))?></strong> · <?=sdvE(ucwords(str_replace('_',' ',(string)($v['season_type']??'regular'))))?> · Priority <?=(int)($v['rate_priority']??10)?> · <?=sdvE(ucwords(str_replace('_',' ',(string)($v['applicability_basis']??'arrival_date'))))?><br><?=sdvE((string)$v['valid_from'])?> → <?=sdvE((string)$v['valid_to'])?> · <?=sdvE((string)$v['currency'])?> · <?=sdvE((string)($v['meal_plan']?:'Meal plan not set'))?></span></div><span class="badge <?=sdvE((string)$v['status'])?>"><?=sdvE(ucfirst((string)$v['status']))?></span></div>
<div class="actions" style="margin-top:10px">
<?php if(function_exists('tsSCIReady') && tsSCIReady($pdo)):?><a class="btn soft" href="admin-supplier-contract-inventory.php?version_id=<?=(int)$v['id']?>"><i class="fa-solid fa-hotel"></i> Hotel + Vehicle Inventory</a><?php endif;?>
<?php if(function_exists('tsSCRReady') && tsSCRReady($pdo)):?><a class="btn soft" href="admin-supplier-contract-rates.php?version_id=<?=(int)$v['id']?>"><i class="fa-solid fa-table-cells"></i> PAX Rate Engine</a><?php endif;?><a class="btn primary" href="admin-supplier-rate-book.php?version_id=<?=(int)$v['id']?>"><i class="fa-solid fa-book-open"></i> Organised Rate Book</a>
<?php if($v['status']!=='active'):?><form method="post" onsubmit="return confirm('Activate this seasonal tariff? A prior active revision with the same season name will be superseded. Other seasons stay active; overlapping seasons must have different priorities.');"><input type="hidden" name="csrf" value="<?=sdvE($csrf)?>"><input type="hidden" name="action" value="activate_version"><input type="hidden" name="document_id" value="<?=$id?>"><input type="hidden" name="version_id" value="<?=(int)$v['id']?>"><button class="btn good"><i class="fa-solid fa-circle-check"></i> Activate Reviewed Version</button></form><?php endif;?>
</div>
</div>
<?php endforeach;?>
</div>

<div class="panel"><h2>Create New Supplier Contract from This Document</h2>
<p class="muted">Use this for a new tariff/contract family. Define the supplier's exact travel period and season. It creates the supplier contract as <strong>Draft</strong> and stores this document as Version 1; rates still require review/approval before activation.</p>
<form method="post"><input type="hidden" name="csrf" value="<?=sdvE($csrf)?>"><input type="hidden" name="action" value="create_contract"><input type="hidden" name="document_id" value="<?=$id?>">
<div class="grid">
<div class="full"><label class="label">Contract Name *</label><input class="input" name="contract_name" required value="<?=sdvE($defaultContractName)?>"></div>
<div><label class="label">Valid From *</label><input class="input" type="date" name="valid_from" required value="<?=sdvE((string)$document['valid_from'])?>"></div><div><label class="label">Valid To *</label><input class="input" type="date" name="valid_to" required value="<?=sdvE((string)$document['valid_to'])?>"></div>
<div><label class="label">Rate Season / Period *</label><input class="input" name="season_name" required value="Regular Season" placeholder="Regular / Summer / Christmas Peak"></div><div><label class="label">Season Type</label><select name="season_type"><option value="regular">Regular</option><option value="shoulder">Shoulder</option><option value="high">High Season</option><option value="peak">Peak Season</option><option value="festival">Festival / Holiday</option><option value="special">Special Override</option></select></div>
<div><label class="label">Season Priority</label><input class="input" type="number" min="0" max="1000" name="rate_priority" placeholder="Auto: Regular 10, High 50, Peak 100"></div><div><label class="label">Rate Applies By</label><select name="applicability_basis"><option value="arrival_date">Arrival / Trip Start Date</option><option value="departure_date">Departure / Trip End Date</option><option value="majority_nights">Majority Nights</option><option value="manual_confirmation">Manual Supplier Confirmation</option></select></div>
<div><label class="label">Currency</label><input class="input" name="currency" value="<?=sdvE((string)$document['currency'])?>"></div><div><label class="label">Supplier GST / Tax %</label><input class="input" type="number" min="0" step=".01" name="supplier_tax_percent" value="0"></div>
<div class="full"><label><input type="checkbox" name="tax_included" value="1"> Supplier tax is included in the quoted supplier rate</label></div>
<div><label class="label">Meal Plan</label><input class="input" name="meal_plan" value="<?=sdvE($defaultMeal)?>" placeholder="MAPAI / CPAI / CP"></div><div><label class="label">Payment Terms</label><input class="input" name="payment_terms"></div>
<div class="full"><label class="label">Cancellation Terms</label><textarea name="cancellation_terms"><?=sdvE($defaultCancellation)?></textarea></div>
<div class="full"><label class="label">Transport / Vehicle Rules</label><textarea name="transport_terms"><?=sdvE($defaultTransport)?></textarea></div>
<div class="full"><label class="label">Contract Notes</label><textarea name="notes"><?=sdvE((string)$document['notes'])?></textarea></div>
<div class="full"><button class="btn primary"><i class="fa-solid fa-file-signature"></i> Create Draft Contract + Version 1</button></div>
</div></form></div>

<?php if($contracts):?><div class="panel"><h2>Add This Document as a New Version of an Existing Contract</h2>
<p class="muted">Use this when the same supplier sends another season or a revised tariff for the same commercial agreement. Give each season a clear name/priority. Old versions remain immutable for quotation and audit history.</p>
<form method="post"><input type="hidden" name="csrf" value="<?=sdvE($csrf)?>"><input type="hidden" name="action" value="add_contract_version"><input type="hidden" name="document_id" value="<?=$id?>">
<div class="grid">
<div class="full"><label class="label">Existing Contract *</label><select name="contract_id" required><option value="">Select Contract</option><?php foreach($contracts as $c):?><option value="<?=(int)$c['id']?>"><?=sdvE((string)$c['contract_code'])?> · <?=sdvE((string)$c['contract_name'])?> · <?=sdvE((string)$c['status'])?></option><?php endforeach;?></select></div>
<div><label class="label">Valid From *</label><input class="input" type="date" name="valid_from" required value="<?=sdvE((string)$document['valid_from'])?>"></div><div><label class="label">Valid To *</label><input class="input" type="date" name="valid_to" required value="<?=sdvE((string)$document['valid_to'])?>"></div>
<div><label class="label">Rate Season / Period *</label><input class="input" name="season_name" required value="" placeholder="Regular / Summer / Christmas Peak"></div><div><label class="label">Season Type</label><select name="season_type"><option value="regular">Regular</option><option value="shoulder">Shoulder</option><option value="high">High Season</option><option value="peak">Peak Season</option><option value="festival">Festival / Holiday</option><option value="special">Special Override</option></select></div>
<div><label class="label">Season Priority</label><input class="input" type="number" min="0" max="1000" name="rate_priority" placeholder="Auto: Regular 10, High 50, Peak 100"></div><div><label class="label">Rate Applies By</label><select name="applicability_basis"><option value="arrival_date">Arrival / Trip Start Date</option><option value="departure_date">Departure / Trip End Date</option><option value="majority_nights">Majority Nights</option><option value="manual_confirmation">Manual Supplier Confirmation</option></select></div>
<div><label class="label">Currency</label><input class="input" name="currency" value="<?=sdvE((string)$document['currency'])?>"></div><div><label class="label">Supplier GST / Tax %</label><input class="input" type="number" min="0" step=".01" name="supplier_tax_percent" value="0"></div>
<div class="full"><label><input type="checkbox" name="tax_included" value="1"> Supplier tax included</label></div>
<div><label class="label">Meal Plan</label><input class="input" name="meal_plan" value="<?=sdvE($defaultMeal)?>"></div><div><label class="label">Payment Terms</label><input class="input" name="payment_terms"></div>
<div class="full"><label class="label">Cancellation Terms</label><textarea name="cancellation_terms"><?=sdvE($defaultCancellation)?></textarea></div>
<div class="full"><label class="label">Transport / Vehicle Rules</label><textarea name="transport_terms"><?=sdvE($defaultTransport)?></textarea></div>
<div class="full"><button class="btn primary"><i class="fa-solid fa-code-branch"></i> Add Review Version</button></div>
</div></form></div><?php endif;?>

</div></main>
<script src="assets/travscope-pro-admin.js?v=20260916-v6" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
