<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
require_once __DIR__.'/communication-center-functions.php';
if(empty($_SESSION['admin_id'])){header('Location: '.BASE_URL.'admin-login.php');exit;}
$id=max(0,(int)($_GET['id']??0));
$stmt=$pdo->prepare('SELECT * FROM communication_attachments WHERE id=? LIMIT 1');$stmt->execute([$id]);$a=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$a){http_response_code(404);exit('Attachment not found.');}
try{$path=tsCommStoredPath((string)$a['stored_path']);}catch(Throwable $e){http_response_code(404);exit('Attachment file is unavailable.');}
$mime=trim((string)($a['mime_type']??''))?:'application/octet-stream';$name=basename((string)$a['original_filename']);
// Treat active content as a download, never as an executable page on the admin origin.
$risky=(bool)preg_match('~(?:text/html|application/xhtml\+xml|image/svg\+xml|javascript|xml)~i',$mime) || (bool)preg_match('/\.(?:html?|svg|xhtml|xml|js|mjs)$/i',$name);
if($risky)$mime='application/octet-stream';
header('Content-Type: '.$mime);header('Content-Length: '.filesize($path));header('Content-Disposition: '.($risky?'attachment':'inline').'; filename="'.str_replace('"','',$name).'"');header('X-Content-Type-Options: nosniff');readfile($path);exit;
