<?php
declare(strict_types=1);
require_once __DIR__ . '/receipt-pdf-functions.php';

function tsBillTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];
    $key = strtolower($table);
    if (array_key_exists($key, $cache)) return $cache[$key];
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?");
        $stmt->execute([$table]);
        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}

function tsBillReady(PDO $pdo): bool
{
    foreach ([
        'booking_payment_schedules','booking_payment_installments','payment_installment_allocations',
        'booking_invoice_versions','booking_payment_receipts','booking_customer_refunds',
        'booking_billing_adjustments','booking_billing_reminders','bookings','payments'
    ] as $table) {
        if (!tsBillTableExists($pdo, $table)) return false;
    }
    return true;
}

function tsBillAssertOpen(PDO $pdo, int $bookingId): void
{
    if (!tsBillReady($pdo)) throw new RuntimeException('Customer Billing SQL is not installed yet.');
    if (tsBillTableExists($pdo, 'booking_profitability_closures')) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM booking_profitability_closures WHERE booking_id = ?");
        $stmt->execute([$bookingId]);
        if ((int)$stmt->fetchColumn() > 0) {
            throw new RuntimeException('Customer Billing is locked because this Booking is financially closed.');
        }
    }
}

function tsBillBooking(PDO $pdo, int $bookingId): array
{
    $stmt = $pdo->prepare("SELECT * FROM bookings WHERE id = ? LIMIT 1");
    $stmt->execute([$bookingId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) throw new RuntimeException('Booking was not found.');
    return $row;
}

function tsBillCurrency(array $booking): string
{
    $v = strtoupper(trim((string)($booking['currency'] ?? 'INR')));
    return $v !== '' ? $v : 'INR';
}

function tsBillOutstanding(array $booking): float
{
    if (strtolower((string)($booking['booking_status'] ?? '')) === 'cancelled') {
        return 0.0;
    }

    return max(0, round((float)($booking['total_amount'] ?? 0) - (float)($booking['paid_amount'] ?? 0), 2));
}

/**
 * Return the latest currently-final customer tax invoice, even when an older
 * build did not sync its GST/TCS grand total back to bookings.total_amount.
 */
function tsBillLatestFinalInvoiceAny(PDO $pdo, int $bookingId): ?array
{
    if (!tsBillReady($pdo) || $bookingId <= 0) return null;
    $stmt = $pdo->prepare("SELECT * FROM booking_invoice_versions WHERE booking_id=? AND status='final' ORDER BY version_number DESC,id DESC LIMIT 1");
    $stmt->execute([$bookingId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

/**
 * Customer payable total. A FINAL GST/TCS invoice is authoritative because it
 * contains the statutory grand total. This also repairs V12-and-earlier cases
 * where the invoice was final but the booking payable was not synchronized.
 */
function tsBillCollectibleTotal(PDO $pdo, array $booking): float
{
    $bookingTotal = max(0, round((float)($booking['total_amount'] ?? 0), 2));
    $bookingId = (int)($booking['id'] ?? 0);
    if ($bookingId <= 0 || strtolower((string)($booking['booking_status'] ?? '')) === 'cancelled') return $bookingTotal;
    $invoice = tsBillLatestFinalInvoiceAny($pdo, $bookingId);
    if ($invoice) return max(0, round((float)($invoice['booking_total'] ?? $bookingTotal), 2));
    return $bookingTotal;
}

function tsBillCollectibleOutstanding(PDO $pdo, array $booking): float
{
    if (strtolower((string)($booking['booking_status'] ?? '')) === 'cancelled') return 0.0;
    return max(0, round(tsBillCollectibleTotal($pdo, $booking) - (float)($booking['paid_amount'] ?? 0), 2));
}

/**
 * Keep bookings.total_amount aligned with the latest FINAL GST/TCS invoice.
 * Safe/idempotent and used before collecting/approving customer payments.
 */
function tsBillSyncBookingPayableFromFinalInvoice(PDO $pdo, int $bookingId): ?array
{
    if (!tsBillReady($pdo) || $bookingId <= 0) return null;
    $booking = tsBillBooking($pdo, $bookingId);
    if (strtolower((string)($booking['booking_status'] ?? '')) === 'cancelled') return $booking;
    $invoice = tsBillLatestFinalInvoiceAny($pdo, $bookingId);
    if (!$invoice) return $booking;
    $invoiceTotal = max(0, round((float)($invoice['booking_total'] ?? 0), 2));
    $current = max(0, round((float)($booking['total_amount'] ?? 0), 2));
    if ($invoiceTotal > 0 && abs($invoiceTotal - $current) > .01) {
        $paid = max(0, (float)($booking['paid_amount'] ?? 0));
        $pdo->prepare("UPDATE bookings SET total_amount=?, payment_status=?, updated_at=NOW() WHERE id=?")
            ->execute([$invoiceTotal, tsBillPaymentStatus($invoiceTotal, $paid), $bookingId]);
        $booking['total_amount'] = $invoiceTotal;
        $booking['payment_status'] = tsBillPaymentStatus($invoiceTotal, $paid);
    }
    return $booking;
}

/**
 * Generate a unique customer payment receipt code.
 *
 * Example: RCPT-2026-B123-A1B2C3
 */
function tsBillReceiptCode(PDO $pdo, int $bookingId): string
{
    if ($bookingId <= 0) {
        throw new RuntimeException('A valid Booking is required to generate a payment receipt.');
    }

    $prefix = 'RCPT-' . date('Y') . '-B' . $bookingId . '-';

    for ($attempt = 0; $attempt < 10; $attempt++) {
        $code = $prefix . strtoupper(bin2hex(random_bytes(3)));

        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM booking_payment_receipts WHERE receipt_code = ?"
        );
        $stmt->execute([$code]);

        if ((int)$stmt->fetchColumn() === 0) {
            return $code;
        }
    }

    throw new RuntimeException('Unable to generate a unique payment receipt code. Please try again.');
}

function tsBillPaymentStatus(float $total, float $paid): string
{
    if ($paid <= .009) return 'unpaid';
    if ($paid + .009 < $total) return 'partial';
    return 'paid';
}


/**
 * Signed public payment-collection links.
 * The token grants access only to one Booking/payment target until expiry;
 * it does not expose the application's secret in the URL.
 */
function tsBillPaymentCollectionSecret(): string
{
    foreach ([
        defined('APP_KEY') ? (string) APP_KEY : '',
        defined('GOOGLE_CLIENT_SECRET') ? (string) GOOGLE_CLIENT_SECRET : '',
        defined('SMTP_PASSWORD') ? (string) SMTP_PASSWORD : '',
    ] as $candidate) {
        $candidate = trim($candidate);
        if ($candidate !== '') return hash('sha256', 'travscope-payment-collection|' . $candidate);
    }

    return hash(
        'sha256',
        (defined('BASE_URL') ? (string) BASE_URL : 'TRAVSCOPE') . '|payment-collection'
    );
}

function tsBillPaymentCollectionToken(int $bookingId, int $installmentId, int $expires): string
{
    return hash_hmac(
        'sha256',
        'v1:' . $bookingId . ':' . max(0, $installmentId) . ':' . $expires,
        tsBillPaymentCollectionSecret()
    );
}

function tsBillPaymentCollectionTokenValid(
    int $bookingId,
    int $installmentId,
    int $expires,
    string $token
): bool {
    if ($bookingId <= 0 || $expires <= 0 || $expires < time() || trim($token) === '') return false;
    return hash_equals(
        tsBillPaymentCollectionToken($bookingId, max(0, $installmentId), $expires),
        trim($token)
    );
}

function tsBillPaymentCollectionUrl(
    int $bookingId,
    int $installmentId = 0,
    int $validDays = 7
): string {
    $validDays = max(1, min(30, $validDays));
    $expires = time() + ($validDays * 86400);
    $installmentId = max(0, $installmentId);

    return BASE_URL
        . 'payment.php?booking=' . $bookingId
        . ($installmentId > 0 ? '&installment=' . $installmentId : '')
        . '&expires=' . $expires
        . '&token=' . rawurlencode(
            tsBillPaymentCollectionToken($bookingId, $installmentId, $expires)
        );
}


/**
 * Secret used only for customer payment-receipt email links.
 * Reuses the application's configured secret without exposing it in the URL.
 */
function tsBillReceiptEmailSecret(): string
{
    foreach ([
        defined('APP_KEY') ? (string) APP_KEY : '',
        defined('GOOGLE_CLIENT_SECRET') ? (string) GOOGLE_CLIENT_SECRET : '',
        defined('SMTP_PASSWORD') ? (string) SMTP_PASSWORD : '',
    ] as $candidate) {
        $candidate = trim($candidate);
        if ($candidate !== '') {
            return hash('sha256', 'travscope-payment-receipt|' . $candidate);
        }
    }

    return hash(
        'sha256',
        (defined('BASE_URL') ? (string) BASE_URL : 'TRAVSCOPE')
        . '|payment-receipt-email'
    );
}

function tsBillReceiptEmailToken(int $receiptId, int $expires): string
{
    return hash_hmac(
        'sha256',
        'v1:' . $receiptId . ':' . $expires,
        tsBillReceiptEmailSecret()
    );
}

function tsBillReceiptEmailTokenValid(
    int $receiptId,
    int $expires,
    string $token
): bool {
    if (
        $receiptId <= 0
        || $expires <= 0
        || $expires < time()
        || trim($token) === ''
    ) {
        return false;
    }

    return hash_equals(
        tsBillReceiptEmailToken($receiptId, $expires),
        trim($token)
    );
}

function tsBillReceiptEmailUrl(int $receiptId, int $validDays = 90): string
{
    $validDays = max(1, min(365, $validDays));
    $expires = time() + ($validDays * 86400);

    return BASE_URL
        . 'payment-receipt.php?receipt=' . $receiptId
        . '&expires=' . $expires
        . '&token=' . rawurlencode(
            tsBillReceiptEmailToken($receiptId, $expires)
        );
}

/**
 * Email a verified payment receipt to the booking customer.
 * Payment approval must already be committed before calling this helper.
 * Mail failure never changes the financial transaction.
 */
function tsBillSendApprovedPaymentReceiptEmail(
    PDO $pdo,
    int $receiptId
): array {
    if ($receiptId <= 0 || !tsBillReady($pdo)) {
        return [
            'sent' => false,
            'message' => 'Payment receipt was not available for email.',
        ];
    }

    $stmt = $pdo->prepare("\n        SELECT\n            r.*,\n            b.booking_number,\n            b.customer_name,\n            b.customer_email,\n            b.total_amount,\n            b.paid_amount,\n            b.payment_status\n        FROM booking_payment_receipts r\n        INNER JOIN bookings b\n            ON b.id = r.booking_id\n        WHERE r.id = ?\n        LIMIT 1\n    ");
    $stmt->execute([$receiptId]);
    $receipt = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

    if (!$receipt) {
        return [
            'sent' => false,
            'message' => 'Payment receipt record was not found.',
        ];
    }

    $email = trim((string) ($receipt['customer_email'] ?? ''));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return [
            'sent' => false,
            'message' => 'Customer email is not available.',
        ];
    }

    if (!class_exists('\\PHPMailer\\PHPMailer\\PHPMailer')) {
        return [
            'sent' => false,
            'message' => 'Mail service is not available.',
        ];
    }

    $snapshot = json_decode(
        (string) ($receipt['snapshot_json'] ?? ''),
        true
    );
    if (!is_array($snapshot)) {
        $snapshot = [];
    }

    $currency = strtoupper(
        trim((string) ($receipt['currency'] ?? 'INR'))
    );
    if ($currency === '') {
        $currency = 'INR';
    }

    $amount = max(0, (float) ($receipt['amount'] ?? 0));
    $bookingTotal = max(0, (float) ($receipt['total_amount'] ?? 0));
    $bookingPaid = max(0, (float) ($receipt['paid_amount'] ?? 0));
    $bookingBalance = max(0, round($bookingTotal - $bookingPaid, 2));

    if (isset($snapshot['booking_balance'])) {
        $bookingBalance = max(
            0,
            round((float) $snapshot['booking_balance'], 2)
        );
    }

    $receiptUrl = tsBillReceiptEmailUrl($receiptId, 90);
    $receiptPdfUrl = $receiptUrl . '&format=pdf';
    $invoiceUrl = ''; $invoiceCode = '';
    try { $ix=$pdo->prepare("SELECT id,invoice_code FROM booking_invoice_versions WHERE booking_id=? AND status='final' ORDER BY version_number DESC,id DESC LIMIT 1"); $ix->execute([(int)$receipt['booking_id']]); $ir=$ix->fetch(PDO::FETCH_ASSOC); if($ir){ $invoiceCode=(string)$ir['invoice_code']; $invoiceUrl=tsBillInvoiceEmailUrl((int)$ir['id'],90); } } catch(Throwable $ignore) {}
    $sellerProfile = tsBillTaxDefaults($pdo);
    $siteName = trim((string)($sellerProfile['trade_name'] ?? 'Travscope')) ?: 'Travscope';
    $sellerLegalName = trim((string)($sellerProfile['legal_name'] ?? 'MEMORABLE HOSPITALITY PRIVATE LIMITED'));
    $sellerGstin = trim((string)($sellerProfile['gstin'] ?? ''));
    $sellerHeaderName = trim((string)($sellerProfile['header_name'] ?? 'Memorable Hospitality Pvt. Ltd.'));
    $documentLogoUrl = trim((string)($sellerProfile['logo_url'] ?? ''));

    $customerName = trim(
        (string) ($receipt['customer_name'] ?? 'Traveller')
    );
    if ($customerName === '') {
        $customerName = 'Traveller';
    }

    $bookingNumber = (string) ($receipt['booking_number'] ?? '');
    $receiptCode = (string) ($receipt['receipt_code'] ?? '');
    $transactionId = trim(
        (string) ($receipt['transaction_id'] ?? '')
    );
    $paymentMethod = trim(
        (string) ($receipt['payment_method'] ?? '')
    );
    $installmentSummary = trim(
        (string) ($receipt['installment_summary'] ?? '')
    );
    $paidAtRaw = (string) ($receipt['paid_at'] ?? '');
    $paidAt = $paidAtRaw !== '' && strtotime($paidAtRaw)
        ? date('d M Y, h:i A', strtotime($paidAtRaw))
        : date('d M Y, h:i A');

    $esc = static function (string $value): string {
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    };

    $subject = 'Payment Received · ' . $bookingNumber
        . ($receiptCode !== '' ? ' · ' . $receiptCode : '');

    $statusLine = $bookingBalance <= 0.009
        ? 'Your booking is fully paid.'
        : 'Remaining booking balance: <strong>'
            . $esc($currency) . ' '
            . number_format($bookingBalance, 2)
            . '</strong>';

    $body = '<div style="margin:0;padding:24px;background:#f3f6fa;font-family:Arial,sans-serif;color:#172033">'
        . '<div style="max-width:680px;margin:auto;background:#ffffff;border:1px solid #dbe3ee;border-radius:16px;overflow:hidden">'
        . '<div style="padding:20px 24px;background:#ffffff;border-top:6px solid #0f172a;border-bottom:1px solid #dbe3ee">'
        . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr>'
        . '<td style="vertical-align:middle;width:310px">'
        . ($documentLogoUrl!=='' ? '<img src="'.$esc($documentLogoUrl).'" alt="Travscope" width="288" style="display:block;width:288px;max-width:100%;height:auto">' : '<div style="font-size:22px;font-weight:900;color:#0f172a">Travscope</div>')
        . '</td><td style="vertical-align:middle;text-align:right">'
        . '<div style="font-size:15px;font-weight:900;color:#0f172a">'.$esc($sellerHeaderName).'</div>'
        . '<div style="margin-top:4px;color:#64748b;font-size:11px">Verified Customer Payment Receipt</div>'
        . ($sellerGstin!==''?'<div style="margin-top:4px;color:#64748b;font-size:10px">GSTIN '.$esc($sellerGstin).'</div>':'')
        . '</td></tr></table>'
        . '</div>'
        . '<div style="padding:24px">'
        . '<p style="margin-top:0">Dear ' . $esc($customerName) . ',</p>'
        . '<p>Thank you. We have verified and approved your payment for booking <strong>' . $esc($bookingNumber) . '</strong>.</p>'
        . '<div style="margin:20px 0;padding:20px;text-align:center;background:#ecfdf5;border:1px solid #a7f3d0;border-radius:12px">'
        . '<div style="font-size:12px;font-weight:800;color:#047857;text-transform:uppercase">Payment Received</div>'
        . '<div style="margin-top:6px;font-size:30px;font-weight:800;color:#047857">' . $esc($currency) . ' ' . number_format($amount, 2) . '</div>'
        . '</div>'
        . '<table role="presentation" style="width:100%;border-collapse:collapse;font-size:14px">'
        . '<tr><td style="padding:8px 0;color:#64748b">Receipt</td><td style="padding:8px 0;text-align:right;font-weight:700">' . $esc($receiptCode) . '</td></tr>'
        . '<tr><td style="padding:8px 0;color:#64748b">Payment date</td><td style="padding:8px 0;text-align:right;font-weight:700">' . $esc($paidAt) . '</td></tr>'
        . ($paymentMethod !== '' ? '<tr><td style="padding:8px 0;color:#64748b">Payment method</td><td style="padding:8px 0;text-align:right;font-weight:700">' . $esc($paymentMethod) . '</td></tr>' : '')
        . ($transactionId !== '' ? '<tr><td style="padding:8px 0;color:#64748b">Transaction / UTR</td><td style="padding:8px 0;text-align:right;font-weight:700">' . $esc($transactionId) . '</td></tr>' : '')
        . ($installmentSummary !== '' ? '<tr><td style="padding:8px 0;color:#64748b">Against</td><td style="padding:8px 0;text-align:right;font-weight:700">' . $esc($installmentSummary) . '</td></tr>' : '')
        . '<tr><td style="padding:8px 0;color:#64748b">Total paid till now</td><td style="padding:8px 0;text-align:right;font-weight:700">' . $esc($currency) . ' ' . number_format($bookingPaid, 2) . '</td></tr>'
        . '<tr><td style="padding:8px 0;color:#64748b">Balance</td><td style="padding:8px 0;text-align:right;font-weight:700">' . $esc($currency) . ' ' . number_format($bookingBalance, 2) . '</td></tr>'
        . '</table>'
        . '<div style="margin-top:18px;padding:12px 14px;background:#f8fafc;border-radius:10px;color:#475569">' . $statusLine . '</div>'
        . '<div style="margin-top:22px;text-align:center">'
        . '<a href="' . $esc($receiptPdfUrl) . '" style="display:inline-block;padding:12px 18px;background:#0f172a;color:#ffffff;text-decoration:none;border-radius:9px;font-weight:800">View / Download PDF Payment Receipt</a>'
        . ($invoiceUrl!=='' ? '<div style="margin-top:10px"><a href="'.$esc($invoiceUrl).'" style="display:inline-block;padding:11px 16px;background:#2563eb;color:#ffffff;text-decoration:none;border-radius:9px;font-weight:800">View Tax Invoice</a></div>' : '')
        . '</div>'
        . '<p style="margin:22px 0 0;color:#64748b;font-size:12px;line-height:1.6">For security, this direct receipt link expires after 90 days. Your receipt remains available through your TRAVSCOPE account.</p>'
        . '<p style="margin-bottom:0">Thank you,<br><strong>' . $esc($siteName) . '</strong><br><span style="font-size:11px;color:#64748b">' . $esc($sellerLegalName) . ($sellerGstin!==''?' · GSTIN '.$esc($sellerGstin):'') . '</span></p>'
        . '</div></div></div>';

    $altBody = "Dear {$customerName},\n\n"
        . "We received {$currency} " . number_format($amount, 2)
        . " for booking {$bookingNumber}.\n"
        . "Receipt: {$receiptCode}\n"
        . "Total paid: {$currency} " . number_format($bookingPaid, 2) . "\n"
        . "Balance: {$currency} " . number_format($bookingBalance, 2) . "\n"
        . "Download PDF receipt: {$receiptPdfUrl}\n\n"
        . "Thank you,\n{$siteName}";

    try {
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);

        if (defined('SMTP_ENABLED') && SMTP_ENABLED) {
            $mail->isSMTP();
            $mail->Host = defined('SMTP_HOST')
                ? SMTP_HOST
                : 'smtp.gmail.com';
            $mail->SMTPAuth = defined('SMTP_AUTH')
                ? (bool) SMTP_AUTH
                : true;
            $mail->Username = defined('SMTP_USERNAME')
                ? SMTP_USERNAME
                : '';
            $mail->Password = defined('SMTP_PASSWORD')
                ? SMTP_PASSWORD
                : '';
            $mail->SMTPSecure = defined('SMTP_ENCRYPTION')
                ? SMTP_ENCRYPTION
                : 'tls';
            $mail->Port = defined('SMTP_PORT')
                ? (int) SMTP_PORT
                : 587;
        }

        $fromAddress = defined('MAIL_FROM_ADDRESS')
            ? (string) MAIL_FROM_ADDRESS
            : (defined('SMTP_USERNAME') ? (string) SMTP_USERNAME : '');
        $fromName = defined('MAIL_FROM_NAME')
            ? (string) MAIL_FROM_NAME
            : $siteName;

        $mail->setFrom($fromAddress, $fromName);
        $mail->addAddress($email, $customerName);

        if (
            defined('MAIL_REPLY_TO')
            && filter_var((string) MAIL_REPLY_TO, FILTER_VALIDATE_EMAIL)
        ) {
            $mail->addReplyTo((string) MAIL_REPLY_TO, $fromName);
        }

        // The attachment is the same PDF rendered by the Booking Details preview.
        // Never send an unverified/pending payment as a paid receipt.
        $pdfBytes = tsBillVerifiedReceiptPdf($receipt, $pdo);
        $safeCode = preg_replace('/[^A-Za-z0-9_-]/', '-', $receiptCode) ?: ('receipt-' . $receiptId);
        $mail->addStringAttachment(
            $pdfBytes,
            'TRAVSCOPE-' . $safeCode . '.pdf',
            'base64',
            'application/pdf'
        );
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->AltBody = $altBody;
        $mail->send();

        return [
            'sent' => true,
            'message' => 'PDF payment receipt emailed to ' . $email . '.',
            'receipt_url' => $receiptPdfUrl,
        ];
    } catch (Throwable $e) {
        error_log(
            'TRAVSCOPE payment receipt email error: '
            . $e->getMessage()
        );

        return [
            'sent' => false,
            'message' => 'Payment was approved, but the receipt email could not be sent.',
            'error' => $e->getMessage(),
            'receipt_url' => $receiptPdfUrl,
        ];
    }
}

function tsBillActiveSchedule(PDO $pdo, int $bookingId): ?array
{
    if (!tsBillReady($pdo) || $bookingId <= 0) return null;
    $stmt = $pdo->prepare("SELECT s.* FROM booking_payment_schedules s JOIN bookings b ON b.id=s.booking_id WHERE s.booking_id = ? AND s.status = 'active' AND b.booking_status <> 'cancelled' ORDER BY s.version_number DESC,s.id DESC LIMIT 1");
    $stmt->execute([$bookingId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsBillInstallments(PDO $pdo, int $bookingId, ?int $scheduleId = null): array
{
    if (!tsBillReady($pdo) || $bookingId <= 0) return [];
    if ($scheduleId === null) {
        $schedule = tsBillActiveSchedule($pdo, $bookingId);
        if (!$schedule) return [];
        $scheduleId = (int)$schedule['id'];
    }
    $stmt = $pdo->prepare("SELECT * FROM booking_payment_installments WHERE booking_id = ? AND schedule_id = ? ORDER BY sort_order ASC,installment_number ASC,id ASC");
    $stmt->execute([$bookingId,$scheduleId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function tsBillAllSchedules(PDO $pdo, int $bookingId): array
{
    if (!tsBillReady($pdo)) return [];
    $stmt = $pdo->prepare("SELECT * FROM booking_payment_schedules WHERE booking_id = ? ORDER BY version_number DESC,id DESC");
    $stmt->execute([$bookingId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function tsBillSupersedeActiveSchedule(PDO $pdo, int $bookingId): void
{
    if (!tsBillReady($pdo)) return;
    $pdo->prepare("UPDATE booking_payment_schedules SET status='superseded',updated_at=NOW() WHERE booking_id=? AND status='active'")->execute([$bookingId]);
}

function tsBillCreateSchedule(PDO $pdo, int $bookingId, int $adminId, array $input): array
{
    tsBillAssertOpen($pdo,$bookingId);
    $booking = tsBillBooking($pdo,$bookingId);
    if (strtolower((string)$booking['booking_status']) === 'cancelled') throw new RuntimeException('A cancelled Booking cannot create a payment schedule.');
    $outstanding = tsBillCollectibleOutstanding($pdo, $booking);
    if ($outstanding <= .009) throw new RuntimeException('This Booking has no customer balance to schedule.');
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM payments WHERE booking_id=? AND status='pending'");
    $stmt->execute([$bookingId]);
    if ((int)$stmt->fetchColumn() > 0) throw new RuntimeException('A payment is waiting for verification. Process it before changing the payment schedule.');

    $titles=(array)($input['installment_title']??[]); $dates=(array)($input['installment_due_date']??[]); $amounts=(array)($input['installment_amount']??[]);
    $rows=[]; $max=max(count($titles),count($dates),count($amounts));
    for($i=0;$i<$max;$i++){
        $title=trim((string)($titles[$i]??'')); $date=trim((string)($dates[$i]??'')); $amount=round(max(0,(float)($amounts[$i]??0)),2);
        if($title==='' && $date==='' && $amount<=.009) continue;
        if($amount<=.009) throw new RuntimeException('Every installment amount must be greater than zero.');
        if($title==='') $title='Installment '.(count($rows)+1);
        $rows[]=['title'=>$title,'due_date'=>$date!==''?$date:null,'amount'=>$amount];
    }
    if(!$rows) throw new RuntimeException('Add at least one payment installment.');
    if(count($rows)>12) throw new RuntimeException('A payment schedule can contain a maximum of 12 installments.');
    $scheduled=round(array_sum(array_column($rows,'amount')),2);
    if(abs($scheduled-$outstanding)>.01) throw new RuntimeException('Installment total must equal current Booking balance '.number_format($outstanding,2).'.');

    $pdo->beginTransaction();
    try{
        tsBillSupersedeActiveSchedule($pdo,$bookingId);
        $stmt=$pdo->prepare("SELECT COALESCE(MAX(version_number),0)+1 FROM booking_payment_schedules WHERE booking_id=?");
        $stmt->execute([$bookingId]); $version=max(1,(int)$stmt->fetchColumn());
        $stmt=$pdo->prepare("INSERT INTO booking_payment_schedules (booking_id,version_number,status,currency,booking_total_at_create,paid_at_create,scheduled_amount,notes,created_by_admin_id) VALUES (?,?,'active',?,?,?,?,?,?)");
        $stmt->execute([$bookingId,$version,tsBillCurrency($booking),tsBillCollectibleTotal($pdo,$booking),(float)$booking['paid_amount'],$scheduled,trim((string)($input['schedule_notes']??''))?:null,$adminId?:null]);
        $scheduleId=(int)$pdo->lastInsertId();
        $ins=$pdo->prepare("INSERT INTO booking_payment_installments (schedule_id,booking_id,installment_number,title,due_date,amount,paid_amount,status,sort_order) VALUES (?,?,?,?,?,?,0,'pending',?)");
        foreach($rows as $i=>$row){$n=$i+1;$ins->execute([$scheduleId,$bookingId,$n,$row['title'],$row['due_date'],$row['amount'],$n*10]);}
        $pdo->commit();
        return ['schedule_id'=>$scheduleId,'version_number'=>$version,'scheduled_amount'=>$scheduled];
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}


/**
 * Create a customer-facing payment request using the existing versioned
 * installment schedule. The current request is installment #1; any remainder
 * is preserved as a second installment instead of disappearing from Billing.
 */
function tsBillCreateQuickPaymentRequest(
    PDO $pdo,
    int $bookingId,
    int $adminId,
    string $mode,
    float $customAmount = 0,
    float $advancePercent = 25,
    int $validDays = 7
): array {
    tsBillAssertOpen($pdo, $bookingId);
    $booking = tsBillBooking($pdo, $bookingId);
    $outstanding = tsBillCollectibleOutstanding($pdo, $booking);
    if ($outstanding <= .009) throw new RuntimeException('This Booking has no outstanding customer balance.');

    $mode = strtolower(trim($mode));
    $advancePercent = max(1, min(99, $advancePercent));
    $requestAmount = 0.0;
    $title = '';

    if ($mode === 'full') {
        $requestAmount = $outstanding;
        $title = 'Full Payment';
    } elseif ($mode === 'half') {
        $requestAmount = round($outstanding * .50, 2);
        $title = '50% Payment';
    } elseif ($mode === 'advance') {
        $requestAmount = round($outstanding * ($advancePercent / 100), 2);
        $title = rtrim(rtrim(number_format($advancePercent, 2, '.', ''), '0'), '.') . '% Booking Advance';
    } elseif ($mode === 'custom') {
        $requestAmount = round(max(0, $customAmount), 2);
        if ($requestAmount <= .009) throw new RuntimeException('Enter a valid custom payment amount.');
        $title = 'Custom Payment Request';
    } else {
        throw new RuntimeException('Select Advance, 50%, Full or Custom payment request.');
    }

    $requestAmount = min($outstanding, max(.01, $requestAmount));
    $remainder = round(max(0, $outstanding - $requestAmount), 2);

    $titles = [$title];
    $dates = [date('Y-m-d')];
    $amounts = [$requestAmount];
    if ($remainder > .009) {
        $titles[] = 'Remaining Balance';
        $dates[] = '';
        $amounts[] = $remainder;
    }

    $schedule = tsBillCreateSchedule($pdo, $bookingId, $adminId, [
        'installment_title' => $titles,
        'installment_due_date' => $dates,
        'installment_amount' => $amounts,
        'schedule_notes' => 'Quick payment collection request: ' . $title,
    ]);

    $installments = tsBillInstallments($pdo, $bookingId, (int)$schedule['schedule_id']);
    if (!$installments) throw new RuntimeException('Payment request schedule was created without a payable installment.');
    $first = $installments[0];
    $link = tsBillPaymentCollectionUrl($bookingId, (int)$first['id'], $validDays);

    return [
        'mode' => $mode,
        'title' => $title,
        'amount' => $requestAmount,
        'remainder' => $remainder,
        'currency' => tsBillCurrency($booking),
        'schedule_id' => (int)$schedule['schedule_id'],
        'schedule_version' => (int)$schedule['version_number'],
        'installment_id' => (int)$first['id'],
        'expires_in_days' => max(1, min(30, $validDays)),
        'url' => $link,
    ];
}

function tsBillInstallment(PDO $pdo, int $bookingId, int $installmentId): ?array
{
    if (!tsBillReady($pdo) || $bookingId<=0 || $installmentId<=0) return null;
    $stmt=$pdo->prepare("SELECT i.*,s.status AS schedule_status,s.version_number AS schedule_version FROM booking_payment_installments i JOIN booking_payment_schedules s ON s.id=i.schedule_id WHERE i.id=? AND i.booking_id=? LIMIT 1");
    $stmt->execute([$installmentId,$bookingId]); $row=$stmt->fetch(PDO::FETCH_ASSOC); return $row?:null;
}

function tsBillPaymentTarget(PDO $pdo, int $bookingId, int $installmentId, float $bookingOutstanding): array
{
    $bookingOutstanding=max(0,round($bookingOutstanding,2));
    if($installmentId<=0 || !tsBillReady($pdo)) return ['amount'=>$bookingOutstanding,'installment'=>null,'label'=>'Outstanding Booking Balance'];
    $i=tsBillInstallment($pdo,$bookingId,$installmentId);
    if(!$i) throw new RuntimeException('Selected payment installment was not found.');
    if((string)$i['schedule_status']!=='active') throw new RuntimeException('This payment schedule has been replaced. Please use the latest schedule.');
    if(in_array((string)$i['status'],['paid','cancelled'],true)) throw new RuntimeException('This installment is no longer payable.');
    $due=max(0,round((float)$i['amount']-(float)$i['paid_amount'],2));
    $amount=min($bookingOutstanding,$due);
    if($amount<=.009) throw new RuntimeException('This installment has no outstanding amount.');
    return ['amount'=>$amount,'installment'=>$i,'label'=>(string)$i['title'].' · Schedule V'.(int)$i['schedule_version']];
}

function tsBillLinkPendingPaymentToInstallment(PDO $pdo, int $paymentId, int $installmentId, float $amount): void
{
    if(!tsBillReady($pdo)||$paymentId<=0||$installmentId<=0||$amount<=0)return;
    $stmt=$pdo->prepare("INSERT INTO payment_installment_allocations (payment_id,installment_id,allocated_amount) VALUES (?,?,?) ON DUPLICATE KEY UPDATE allocated_amount=VALUES(allocated_amount)");
    $stmt->execute([$paymentId,$installmentId,round($amount,2)]);
}

function tsBillRefreshInstallment(PDO $pdo, int $installmentId): void
{
    $stmt=$pdo->prepare("SELECT amount,paid_amount,status FROM booking_payment_installments WHERE id=? LIMIT 1");
    $stmt->execute([$installmentId]);$r=$stmt->fetch(PDO::FETCH_ASSOC);if(!$r||$r['status']==='cancelled')return;
    $amount=max(0,(float)$r['amount']);$paid=max(0,(float)$r['paid_amount']);
    if($paid<=.009)$status='pending';elseif($paid+.009<$amount)$status='partially_paid';else{$status='paid';$paid=$amount;}
    $pdo->prepare("UPDATE booking_payment_installments SET paid_amount=?,status=?,updated_at=NOW() WHERE id=?")->execute([$paid,$status,$installmentId]);
}

function tsBillAllocateApprovedPayment(
    PDO $pdo,
    int $paymentId,
    int $bookingId,
    float $paymentAmount
): array {
    if (
        !tsBillReady($pdo)
        || $paymentId <= 0
        || $bookingId <= 0
        || $paymentAmount <= 0
    ) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT
            a.*,
            i.title
        FROM payment_installment_allocations a
        JOIN booking_payment_installments i
            ON i.id = a.installment_id
        WHERE a.payment_id = ?
        ORDER BY a.id ASC
    ");
    $stmt->execute([$paymentId]);

    $allocations =
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        ?: [];

    if (!$allocations) {
        $schedule =
            tsBillActiveSchedule(
                $pdo,
                $bookingId
            );

        /*
         * IMPORTANT BACKFILL SAFETY
         *
         * Historical SUCCESS payments can exist before this Billing module
         * is installed. When receipts are backfilled, those payments must
         * not be applied again to a newly-created installment schedule.
         *
         * Automatic allocation is allowed only when the payment itself was
         * created on/after the active schedule was created.
         */
        $stmt = $pdo->prepare("
            SELECT created_at
            FROM payments
            WHERE id = ?
              AND booking_id = ?
            LIMIT 1
        ");
        $stmt->execute([
            $paymentId,
            $bookingId
        ]);

        $paymentCreatedAt =
            $stmt->fetchColumn()
            ?: null;

        $mayAutoAllocate =
            $schedule
            && $paymentCreatedAt
            && !empty($schedule['created_at'])
            && strtotime((string)$paymentCreatedAt)
                >= strtotime((string)$schedule['created_at']);

        if ($mayAutoAllocate) {
            $stmt = $pdo->prepare("
                SELECT *
                FROM booking_payment_installments
                WHERE schedule_id = ?
                  AND booking_id = ?
                  AND status IN (
                      'pending',
                      'partially_paid'
                  )
                ORDER BY
                    CASE
                        WHEN due_date IS NULL
                        THEN 1
                        ELSE 0
                    END,
                    due_date ASC,
                    sort_order ASC,
                    id ASC
                FOR UPDATE
            ");
            $stmt->execute([
                (int)$schedule['id'],
                $bookingId
            ]);

            $remaining =
                round(
                    $paymentAmount,
                    2
                );

            foreach (
                $stmt->fetchAll(PDO::FETCH_ASSOC)
                ?: []
                as $installment
            ) {
                if ($remaining <= 0.009) {
                    break;
                }

                $due =
                    max(
                        0,
                        round(
                            (float)$installment['amount']
                            - (float)$installment['paid_amount'],
                            2
                        )
                    );

                if ($due <= 0.009) {
                    continue;
                }

                $allocate =
                    min(
                        $remaining,
                        $due
                    );

                tsBillLinkPendingPaymentToInstallment(
                    $pdo,
                    $paymentId,
                    (int)$installment['id'],
                    $allocate
                );

                $remaining =
                    round(
                        $remaining - $allocate,
                        2
                    );
            }

            $stmt = $pdo->prepare("
                SELECT
                    a.*,
                    i.title
                FROM payment_installment_allocations a
                JOIN booking_payment_installments i
                    ON i.id = a.installment_id
                WHERE a.payment_id = ?
                ORDER BY a.id ASC
            ");
            $stmt->execute([$paymentId]);

            $allocations =
                $stmt->fetchAll(PDO::FETCH_ASSOC)
                ?: [];
        }
    }

    foreach ($allocations as $allocation) {
        $installmentId =
            (int)$allocation['installment_id'];

        $allocated =
            max(
                0,
                (float)$allocation['allocated_amount']
            );

        if ($allocated <= 0.009) {
            continue;
        }

        $stmt = $pdo->prepare("
            SELECT
                amount,
                paid_amount,
                status
            FROM booking_payment_installments
            WHERE id = ?
            LIMIT 1
            FOR UPDATE
        ");
        $stmt->execute([$installmentId]);

        $installment =
            $stmt->fetch(PDO::FETCH_ASSOC)
            ?: null;

        if (
            !$installment
            || (string)$installment['status'] === 'cancelled'
        ) {
            continue;
        }

        $newPaid =
            min(
                (float)$installment['amount'],
                max(
                    0,
                    (float)$installment['paid_amount']
                    + $allocated
                )
            );

        $pdo->prepare("
            UPDATE booking_payment_installments
            SET
                paid_amount = ?,
                updated_at = NOW()
            WHERE id = ?
        ")->execute([
            $newPaid,
            $installmentId
        ]);

        tsBillRefreshInstallment(
            $pdo,
            $installmentId
        );
    }

    return $allocations;
}

function tsBillOnPaymentApproved(PDO $pdo, int $paymentId, int $adminId=0): ?array
{
    if(!tsBillReady($pdo)||$paymentId<=0)return null;
    $stmt=$pdo->prepare("SELECT * FROM booking_payment_receipts WHERE payment_id=? LIMIT 1");$stmt->execute([$paymentId]);$existing=$stmt->fetch(PDO::FETCH_ASSOC);if($existing)return $existing;
    $stmt=$pdo->prepare("SELECT p.*,b.booking_number,b.customer_name,b.customer_email,b.customer_mobile,b.total_amount,b.paid_amount,b.currency AS booking_currency FROM payments p JOIN bookings b ON b.id=p.booking_id WHERE p.id=? LIMIT 1");$stmt->execute([$paymentId]);$p=$stmt->fetch(PDO::FETCH_ASSOC);if(!$p||strtolower((string)$p['status'])!=='success')return null;
    $allocs=tsBillAllocateApprovedPayment($pdo,$paymentId,(int)$p['booking_id'],max(0,(float)$p['amount']));$parts=[];foreach($allocs as $a){if(trim((string)($a['title']??''))!=='')$parts[]=(string)$a['title'].' '.number_format((float)$a['allocated_amount'],2);} $summary=$parts?implode(' · ',$parts):null;
    $snapshot=['schema'=>1,'booking_id'=>(int)$p['booking_id'],'booking_number'=>(string)$p['booking_number'],'customer'=>['name'=>(string)$p['customer_name'],'email'=>(string)($p['customer_email']??''),'mobile'=>(string)($p['customer_mobile']??'')],'payment'=>['payment_id'=>$paymentId,'amount'=>(float)$p['amount'],'currency'=>(string)($p['currency']?:$p['booking_currency']),'payment_gateway'=>(string)($p['payment_gateway']??''),'payment_method'=>(string)($p['payment_method']??''),'transaction_id'=>(string)($p['transaction_id']??''),'paid_at'=>$p['paid_at']??null],'allocations'=>$allocs,'booking_total'=>(float)$p['total_amount'],'booking_paid'=>(float)$p['paid_amount'],'booking_balance'=>max(0,(float)$p['total_amount']-(float)$p['paid_amount']),'issued_at'=>date('c')];
    $code=tsBillReceiptCode($pdo,(int)$p['booking_id']);
    $stmt=$pdo->prepare("INSERT INTO booking_payment_receipts (booking_id,payment_id,receipt_code,currency,amount,payment_method,transaction_id,paid_at,installment_summary,snapshot_json,created_by_admin_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
    $stmt->execute([(int)$p['booking_id'],$paymentId,$code,strtoupper(trim((string)($p['currency']?:$p['booking_currency']?:'INR'))),max(0,(float)$p['amount']),trim((string)($p['payment_method']??''))?:null,trim((string)($p['transaction_id']??''))?:null,$p['paid_at']??date('Y-m-d H:i:s'),$summary,json_encode($snapshot,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$adminId?:null]);
    $id=(int)$pdo->lastInsertId();$stmt=$pdo->prepare("SELECT * FROM booking_payment_receipts WHERE id=? LIMIT 1");$stmt->execute([$id]);return $stmt->fetch(PDO::FETCH_ASSOC)?:null;
}

function tsBillSyncSuccessfulPayments(PDO $pdo, int $bookingId, int $adminId=0): void
{
    if(!tsBillReady($pdo))return;
    $stmt=$pdo->prepare("SELECT p.id FROM payments p LEFT JOIN booking_payment_receipts r ON r.payment_id=p.id WHERE p.booking_id=? AND p.status='success' AND r.id IS NULL ORDER BY p.id ASC");$stmt->execute([$bookingId]);
    foreach($stmt->fetchAll(PDO::FETCH_COLUMN)?:[] as $id){try{tsBillOnPaymentApproved($pdo,(int)$id,$adminId);}catch(Throwable $e){error_log('Billing receipt sync error: '.$e->getMessage());}}
}

function tsBillReceipts(PDO $pdo, int $bookingId): array
{
    if(!tsBillReady($pdo))return [];$stmt=$pdo->prepare("SELECT * FROM booking_payment_receipts WHERE booking_id=? ORDER BY paid_at DESC,id DESC");$stmt->execute([$bookingId]);return $stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
}

function tsBillCustomerSafeSnapshot(PDO $pdo, int $bookingId): array
{
    $b=tsBillBooking($pdo,$bookingId);$package=['title'=>'Travel Booking','description'=>'','destination'=>'','travel_date'=>$b['travel_date']??null];
    if(tsBillTableExists($pdo,'booking_quotation_snapshots')){$stmt=$pdo->prepare("SELECT * FROM booking_quotation_snapshots WHERE booking_id=? LIMIT 1");$stmt->execute([$bookingId]);$q=$stmt->fetch(PDO::FETCH_ASSOC);if($q)$package=['title'=>(string)($q['package_title']??'Travel Booking'),'description'=>(string)($q['package_description']??''),'destination'=>(string)($q['destination_name']??''),'travel_date'=>$q['travel_date']??($b['travel_date']??null)];}
    $services=[];if(tsBillTableExists($pdo,'booking_service_snapshots')){$stmt=$pdo->prepare("SELECT service_type,title,destination_name,service_date_from,service_date_to,quantity,specifications FROM booking_service_snapshots WHERE booking_id=? AND procurement_status<>'cancelled' ORDER BY sort_order ASC,id ASC");$stmt->execute([$bookingId]);$services=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];}
    return ['schema'=>1,'booking'=>['id'=>$bookingId,'booking_number'=>(string)$b['booking_number'],'customer_name'=>(string)$b['customer_name'],'customer_email'=>(string)($b['customer_email']??''),'customer_mobile'=>(string)($b['customer_mobile']??''),'travel_date'=>$b['travel_date']??null,'adults'=>(int)($b['adults']??0),'children'=>(int)($b['children']??0),'currency'=>tsBillCurrency($b),'total_amount'=>max(0,(float)$b['total_amount']),'paid_amount'=>max(0,(float)$b['paid_amount']),'balance_due'=>tsBillOutstanding($b),'booking_status'=>(string)$b['booking_status'],'payment_status'=>(string)$b['payment_status']],'package'=>$package,'services'=>$services,'issued_at'=>date('c')];
}

function tsBillCreateInvoice(PDO $pdo, int $bookingId, int $adminId, string $status='draft'): array
{
    tsBillAssertOpen($pdo,$bookingId);$status=strtolower(trim($status));if(!in_array($status,['draft','final'],true))$status='draft';$b=tsBillBooking($pdo,$bookingId);if(strtolower((string)$b['booking_status'])==='cancelled')throw new RuntimeException('A cancelled Booking cannot issue a new Booking invoice.');
    $stmt=$pdo->prepare("SELECT COALESCE(MAX(version_number),0)+1 FROM booking_invoice_versions WHERE booking_id=?");$stmt->execute([$bookingId]);$v=max(1,(int)$stmt->fetchColumn());if($status==='final')$pdo->prepare("UPDATE booking_invoice_versions SET status='void' WHERE booking_id=? AND status='final'")->execute([$bookingId]);
    $code='INV-'.date('Y').'-B'.$bookingId.'-V'.$v;$total=max(0,(float)$b['total_amount']);$paid=max(0,(float)$b['paid_amount']);$balance=max(0,$total-$paid);$snap=tsBillCustomerSafeSnapshot($pdo,$bookingId);
    $stmt=$pdo->prepare("INSERT INTO booking_invoice_versions (booking_id,version_number,invoice_code,status,currency,booking_total,paid_amount_at_issue,balance_due_at_issue,snapshot_json,created_by_admin_id,finalized_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)");$stmt->execute([$bookingId,$v,$code,$status,tsBillCurrency($b),$total,$paid,$balance,json_encode($snap,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$adminId?:null,$status==='final'?date('Y-m-d H:i:s'):null]);$id=(int)$pdo->lastInsertId();$stmt=$pdo->prepare("SELECT * FROM booking_invoice_versions WHERE id=? LIMIT 1");$stmt->execute([$id]);return $stmt->fetch(PDO::FETCH_ASSOC)?:[];
}

function tsBillInvoices(PDO $pdo, int $bookingId): array{if(!tsBillReady($pdo))return[];$s=$pdo->prepare("SELECT * FROM booking_invoice_versions WHERE booking_id=? ORDER BY version_number DESC,id DESC");$s->execute([$bookingId]);return$s->fetchAll(PDO::FETCH_ASSOC)?:[];}
function tsBillLatestFinalInvoice(PDO $pdo, int $bookingId): ?array{if(!tsBillReady($pdo))return null;$s=$pdo->prepare("SELECT i.* FROM booking_invoice_versions i JOIN bookings b ON b.id=i.booking_id WHERE i.booking_id=? AND i.status='final' AND b.booking_status<>'cancelled' ORDER BY i.version_number DESC,i.id DESC LIMIT 1");$s->execute([$bookingId]);$r=$s->fetch(PDO::FETCH_ASSOC);return$r?:null;}
function tsBillVoidFinalInvoices(PDO $pdo,int $bookingId):void{if(tsBillReady($pdo))$pdo->prepare("UPDATE booking_invoice_versions SET status='void' WHERE booking_id=? AND status='final'")->execute([$bookingId]);}
function tsBillAdjustments(PDO $pdo,int $bookingId):array{if(!tsBillReady($pdo))return[];$s=$pdo->prepare("SELECT * FROM booking_billing_adjustments WHERE booking_id=? ORDER BY posted_at DESC,id DESC");$s->execute([$bookingId]);return$s->fetchAll(PDO::FETCH_ASSOC)?:[];}

function tsBillPostAdjustment(PDO $pdo,int $bookingId,int $adminId,string $type,float $amount,string $reason,string $notes=''):array
{
    tsBillAssertOpen($pdo,$bookingId);$type=strtolower(trim($type));if(!in_array($type,['debit','credit'],true))throw new RuntimeException('Select Debit Note or Credit Note.');$amount=round(max(0,$amount),2);if($amount<=.009)throw new RuntimeException('Billing adjustment amount must be greater than zero.');$reason=trim($reason);if($reason==='')throw new RuntimeException('Billing adjustment reason is required.');$b=tsBillBooking($pdo,$bookingId);if(strtolower((string)$b['booking_status'])==='cancelled')throw new RuntimeException('Use Cancellation financial workflow for a cancelled Booking.');$current=max(0,(float)$b['total_amount']);$new=$type==='debit'?$current+$amount:$current-$amount;if($new<-.009)throw new RuntimeException('Credit Note cannot reduce Booking total below zero.');$new=max(0,round($new,2));$paid=max(0,(float)$b['paid_amount']);
    $pdo->beginTransaction();try{$code=strtoupper($type==='credit'?'CN':'DN').'-'.date('Y').'-B'.$bookingId.'-'.strtoupper(substr(bin2hex(random_bytes(4)),0,6));$s=$pdo->prepare("INSERT INTO booking_billing_adjustments (booking_id,adjustment_code,adjustment_type,amount,reason,status,notes,created_by_admin_id,posted_at) VALUES (?,?,?,?,?,'posted',?,?,NOW())");$s->execute([$bookingId,$code,$type,$amount,$reason,trim($notes)?:null,$adminId?:null]);$id=(int)$pdo->lastInsertId();$pdo->prepare("UPDATE bookings SET total_amount=?,payment_status=?,updated_at=NOW() WHERE id=?")->execute([$new,tsBillPaymentStatus($new,$paid),$bookingId]);tsBillVoidFinalInvoices($pdo,$bookingId);tsBillSupersedeActiveSchedule($pdo,$bookingId);$pdo->commit();$s=$pdo->prepare("SELECT * FROM booking_billing_adjustments WHERE id=?");$s->execute([$id]);return$s->fetch(PDO::FETCH_ASSOC)?:[];}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw$e;}
}

function tsBillVoidAdjustment(PDO $pdo,int $bookingId,int $adjustmentId,int $adminId):void
{
    tsBillAssertOpen($pdo,$bookingId);$pdo->beginTransaction();try{$s=$pdo->prepare("SELECT * FROM booking_billing_adjustments WHERE id=? AND booking_id=? LIMIT 1 FOR UPDATE");$s->execute([$adjustmentId,$bookingId]);$a=$s->fetch(PDO::FETCH_ASSOC);if(!$a||$a['status']!=='posted')throw new RuntimeException('Billing adjustment could not be voided.');$b=tsBillBooking($pdo,$bookingId);$current=max(0,(float)$b['total_amount']);$amount=max(0,(float)$a['amount']);$new=$a['adjustment_type']==='debit'?$current-$amount:$current+$amount;$new=max(0,round($new,2));$paid=max(0,(float)$b['paid_amount']);$pdo->prepare("UPDATE bookings SET total_amount=?,payment_status=?,updated_at=NOW() WHERE id=?")->execute([$new,tsBillPaymentStatus($new,$paid),$bookingId]);$pdo->prepare("UPDATE booking_billing_adjustments SET status='void',voided_by_admin_id=?,voided_at=NOW(),updated_at=NOW() WHERE id=?")->execute([$adminId?:null,$adjustmentId]);tsBillVoidFinalInvoices($pdo,$bookingId);tsBillSupersedeActiveSchedule($pdo,$bookingId);$pdo->commit();}catch(Throwable$e){if($pdo->inTransaction())$pdo->rollBack();throw$e;}
}

function tsBillSyncRefundObligations(PDO $pdo,int $bookingId,int $adminId=0):void
{
    if(!tsBillReady($pdo))return;$b=tsBillBooking($pdo,$bookingId);$currency=tsBillCurrency($b);
    if(tsBillTableExists($pdo,'booking_amendments')){$s=$pdo->prepare("SELECT id,version_number,customer_financial_amount,customer_message FROM booking_amendments WHERE booking_id=? AND status='approved' AND customer_financial_action='refund' AND customer_financial_amount>0");$s->execute([$bookingId]);$ins=$pdo->prepare("INSERT IGNORE INTO booking_customer_refunds (booking_id,source_type,source_id,amount,currency,status,reason,requested_at,notes,created_by_admin_id) VALUES (?,'amendment',?,?,?,'pending',?,NOW(),?,?)");foreach($s->fetchAll(PDO::FETCH_ASSOC)?:[] as $r){$ins->execute([$bookingId,(int)$r['id'],max(0,(float)$r['customer_financial_amount']),$currency,'Booking Amendment V'.(int)$r['version_number'].' refund',trim((string)($r['customer_message']??''))?:null,$adminId?:null]);}}
    if(tsBillTableExists($pdo,'booking_cancellation_financials')){$s=$pdo->prepare("SELECT booking_cancellation_id,customer_refund_amount,customer_refund_status,customer_finance_note FROM booking_cancellation_financials WHERE booking_id=? AND customer_refund_amount>0");$s->execute([$bookingId]);$ins=$pdo->prepare("INSERT IGNORE INTO booking_customer_refunds (booking_id,source_type,source_id,amount,currency,status,reason,requested_at,notes,created_by_admin_id) VALUES (?,'cancellation',?,?,?,?,?,NOW(),?,?)");foreach($s->fetchAll(PDO::FETCH_ASSOC)?:[] as $r){$status=$r['customer_refund_status']==='paid'?'paid':'pending';$ins->execute([$bookingId,(int)$r['booking_cancellation_id'],max(0,(float)$r['customer_refund_amount']),$currency,$status,'Booking cancellation refund',trim((string)($r['customer_finance_note']??''))?:null,$adminId?:null]);}}
}

function tsBillRefunds(PDO $pdo,int $bookingId):array{if(!tsBillReady($pdo))return[];tsBillSyncRefundObligations($pdo,$bookingId);$s=$pdo->prepare("SELECT * FROM booking_customer_refunds WHERE booking_id=? ORDER BY requested_at DESC,id DESC");$s->execute([$bookingId]);return$s->fetchAll(PDO::FETCH_ASSOC)?:[];}
function tsBillPendingRefundTotal(PDO $pdo,int $bookingId):float{if(!tsBillReady($pdo))return 0;tsBillSyncRefundObligations($pdo,$bookingId);$s=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM booking_customer_refunds WHERE booking_id=? AND status='pending'");$s->execute([$bookingId]);return max(0,(float)$s->fetchColumn());}

function tsBillCreateManualRefund(PDO $pdo,int $bookingId,int $adminId,float $amount,string $reason,string $notes=''):array
{
    tsBillAssertOpen($pdo,$bookingId);$b=tsBillBooking($pdo,$bookingId);$amount=round(max(0,$amount),2);if($amount<=.009)throw new RuntimeException('Refund amount must be greater than zero.');if($amount>max(0,(float)$b['paid_amount'])+.01)throw new RuntimeException('Refund cannot exceed the customer amount currently retained.');$reason=trim($reason);if($reason==='')throw new RuntimeException('Refund reason is required.');$s=$pdo->prepare("INSERT INTO booking_customer_refunds (booking_id,source_type,source_id,amount,currency,status,reason,requested_at,notes,created_by_admin_id) VALUES (?,'manual',NULL,?,?,'pending',?,NOW(),?,?)");$s->execute([$bookingId,$amount,tsBillCurrency($b),$reason,trim($notes)?:null,$adminId?:null]);$id=(int)$pdo->lastInsertId();$s=$pdo->prepare("SELECT * FROM booking_customer_refunds WHERE id=?");$s->execute([$id]);return$s->fetch(PDO::FETCH_ASSOC)?:[];
}

function tsBillMarkRefundPaid(PDO $pdo,int $bookingId,int $refundId,int $adminId,string $method,string $reference,string $notes=''):void
{
    if(!tsBillReady($pdo))throw new RuntimeException('Customer Billing SQL is not installed yet.');$pdo->beginTransaction();try{$s=$pdo->prepare("SELECT * FROM booking_customer_refunds WHERE id=? AND booking_id=? LIMIT 1 FOR UPDATE");$s->execute([$refundId,$bookingId]);$r=$s->fetch(PDO::FETCH_ASSOC);if(!$r||$r['status']!=='pending')throw new RuntimeException('Pending customer refund was not found.');$s=$pdo->prepare("SELECT * FROM bookings WHERE id=? LIMIT 1 FOR UPDATE");$s->execute([$bookingId]);$b=$s->fetch(PDO::FETCH_ASSOC);if(!$b)throw new RuntimeException('Booking was not found.');$amount=max(0,(float)$r['amount']);$paid=max(0,(float)$b['paid_amount']);if($amount>$paid+.01)throw new RuntimeException('Refund amount exceeds customer amount currently retained.');$newPaid=max(0,round($paid-$amount,2));$total=max(0,(float)$b['total_amount']);$updatedPaymentStatus=tsBillPaymentStatus($total,$newPaid);if($r['source_type']==='cancellation'&&$newPaid<.01&&$paid>.009)$updatedPaymentStatus='refunded';$pdo->prepare("UPDATE bookings SET paid_amount=?,payment_status=?,updated_at=NOW() WHERE id=?")->execute([$newPaid,$updatedPaymentStatus,$bookingId]);$pdo->prepare("UPDATE booking_customer_refunds SET status='paid',payment_method=?,reference_number=?,paid_at=NOW(),notes=?,paid_by_admin_id=?,updated_at=NOW() WHERE id=?")->execute([trim($method)?:'bank_transfer',trim($reference)?:null,trim($notes)?:($r['notes']??null),$adminId?:null,$refundId]);if($r['source_type']==='cancellation'&&!empty($r['source_id'])&&tsBillTableExists($pdo,'booking_cancellation_financials'))$pdo->prepare("UPDATE booking_cancellation_financials SET customer_refund_status='paid',updated_at=NOW() WHERE booking_cancellation_id=?")->execute([(int)$r['source_id']]);tsBillSupersedeActiveSchedule($pdo,$bookingId);$pdo->commit();}catch(Throwable$e){if($pdo->inTransaction())$pdo->rollBack();throw$e;}
}

function tsBillReminders(PDO $pdo,int $bookingId):array{if(!tsBillReady($pdo))return[];$s=$pdo->prepare("SELECT * FROM booking_billing_reminders WHERE booking_id=? ORDER BY sent_at DESC,id DESC LIMIT 20");$s->execute([$bookingId]);return$s->fetchAll(PDO::FETCH_ASSOC)?:[];}



/* ================================================================
 * STEP 03B — GST/TCS Tax Invoice helpers
 * Tax treatment is stored inside each invoice snapshot so an issued
 * document never changes when global settings are edited later.
 * ================================================================ */
function tsBillSetting(PDO $pdo,string $key,string $default=''):string{
    try{$s=$pdo->prepare("SELECT setting_value FROM settings WHERE setting_key=? LIMIT 1");$s->execute([$key]);$v=$s->fetchColumn();return $v===false?$default:(string)$v;}catch(Throwable$e){return $default;}
}
function tsBillSaveSetting(PDO $pdo,string $key,string $value):void{
    $s=$pdo->prepare("INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");$s->execute([$key,$value]);
}
function tsBillInvoiceEmailSecret():string{
    foreach([defined('APP_KEY')?(string)APP_KEY:'',defined('GOOGLE_CLIENT_SECRET')?(string)GOOGLE_CLIENT_SECRET:'',defined('SMTP_PASSWORD')?(string)SMTP_PASSWORD:''] as $c){$c=trim($c);if($c!=='')return hash('sha256','travscope-tax-invoice|'.$c);}return hash('sha256',(defined('BASE_URL')?(string)BASE_URL:'TRAVSCOPE').'|tax-invoice');
}
function tsBillInvoiceEmailToken(int $invoiceId,int $expires):string{return hash_hmac('sha256','v1:'.$invoiceId.':'.$expires,tsBillInvoiceEmailSecret());}
function tsBillInvoiceEmailTokenValid(int $invoiceId,int $expires,string $token):bool{return $invoiceId>0&&$expires>=time()&&$token!==''&&hash_equals(tsBillInvoiceEmailToken($invoiceId,$expires),trim($token));}
function tsBillInvoiceEmailUrl(int $invoiceId,int $validDays=90):string{$validDays=max(1,min(365,$validDays));$expires=time()+$validDays*86400;return BASE_URL.'booking-invoice.php?invoice='.$invoiceId.'&expires='.$expires.'&token='.rawurlencode(tsBillInvoiceEmailToken($invoiceId,$expires));}
function tsBillMoneyWords(float $amount):string{
    $n=(int)floor($amount);$paise=(int)round(($amount-$n)*100);$ones=['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'];$tens=['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];
    $two=function($x)use($ones,$tens){$x=(int)$x;return $x<20?$ones[$x]:trim($tens[intdiv($x,10)].' '.$ones[$x%10]);};
    $parts=[];if($n>=10000000){$parts[]=$two(intdiv($n,10000000)).' Crore';$n%=10000000;}if($n>=100000){$parts[]=$two(intdiv($n,100000)).' Lakh';$n%=100000;}if($n>=1000){$parts[]=$two(intdiv($n,1000)).' Thousand';$n%=1000;}if($n>=100){$parts[]=$ones[intdiv($n,100)].' Hundred';$n%=100;}if($n>0)$parts[]=$two($n);$r=trim(implode(' ',$parts));if($r==='')$r='Zero';$r.=' Rupees';if($paise>0)$r.=' and '.$two($paise).' Paise';return $r.' Only';
}
function tsBillVerifiedSellerProfile():array{return[
    'legal_name'=>'MEMORABLE HOSPITALITY PRIVATE LIMITED',
    'header_name'=>'Memorable Hospitality Pvt. Ltd.',
    'trade_name'=>'Travscope',
    'gstin'=>'21AALCM7012J1ZM',
    'pan'=>'AALCM7012J',
    'address'=>'PLOT NO - 1215/1416, KHANDAGIRI BARI, KHANDAGIRI, BHUBANESWAR, Khordha, Odisha, 751030',
    'state'=>'Odisha',
    'state_code'=>'21',
    'registration_type'=>'Regular',
    'registration_date'=>'05/05/2018'
];}
function tsBillInvoiceLogoUrl(PDO $pdo):string{
    // Customer documents use their own logo setting. Website/admin branding
    // remains controlled independently by General Settings -> Website Logo.
    $rel=trim(tsBillSetting($pdo,'document_logo','assets/travscope-document-logo-wide.png'));
    if($rel==='')$rel='assets/travscope-document-logo-wide.png';
    if(preg_match('#^https?://#i',$rel))return $rel;
    return rtrim((string)BASE_URL,'/').'/'.ltrim($rel,'/');
}
function tsBillInvoiceServiceRule(string $type):array{
    $type=strtolower(trim($type));
    $rules=[
        'domestic_tour'=>['label'=>'Domestic Tour Package','gst_rate'=>5.0,'tcs_on'=>false,'tcs_rate'=>0.0,'sac'=>'998555','note'=>'Tour-operator 5% GST preset. Confirm eligibility/conditions before final issue.'],
        'international_tour'=>['label'=>'International / Overseas Tour Package','gst_rate'=>5.0,'tcs_on'=>true,'tcs_rate'=>2.0,'sac'=>'998555','note'=>'Current overseas-tour TCS preset is 2% from 01 Apr 2026. GST treatment remains subject to the actual supply/place-of-supply conditions.'],
        'hotel_commission'=>['label'=>'Hotel Commission / Service Fee','gst_rate'=>18.0,'tcs_on'=>false,'tcs_rate'=>0.0,'sac'=>'998599','note'=>'18% GST preset applies to the Travscope commission/service-fee line, not automatically to the hotel gross booking value.'],
        'flight_commission'=>['label'=>'Flight Ticketing Commission / Service Fee','gst_rate'=>18.0,'tcs_on'=>false,'tcs_rate'=>0.0,'sac'=>'998551','note'=>'18% GST preset on agency/service value. Air-travel-agent special valuation rules may apply; confirm the taxable value before final issue.'],
        'visa_commission'=>['label'=>'Visa / Documentation Service Fee','gst_rate'=>18.0,'tcs_on'=>false,'tcs_rate'=>0.0,'sac'=>'998599','note'=>'18% GST preset on Travscope service/commission value; confirm the correct SAC and place-of-supply.'],
        'cab_commission'=>['label'=>'Cab / Transport Facilitation Fee','gst_rate'=>18.0,'tcs_on'=>false,'tcs_rate'=>0.0,'sac'=>'998599','note'=>'18% GST preset on Travscope facilitation/commission value, not automatically on the underlying transport fare.'],
        'other_commission'=>['label'=>'Other Travel Service / Commission','gst_rate'=>18.0,'tcs_on'=>false,'tcs_rate'=>0.0,'sac'=>'998599','note'=>'18% support-service preset. Confirm classification, SAC and place-of-supply before final issue.'],
        'custom'=>['label'=>'Custom Tax Treatment','gst_rate'=>0.0,'tcs_on'=>false,'tcs_rate'=>0.0,'sac'=>'998555','note'=>'Manual tax treatment selected.']
    ];
    return $rules[$type]??$rules['custom'];
}
function tsBillTaxDefaults(PDO $pdo):array{
    $verified=tsBillVerifiedSellerProfile();
    $legal=trim(tsBillSetting($pdo,'invoice_legal_name',''));
    if($legal===''||in_array(strtoupper($legal),['TRAVSCOPE','TRAVSCOPE.COM'],true))$legal=$verified['legal_name'];
    $trade=trim(tsBillSetting($pdo,'invoice_trade_name',''));if($trade==='')$trade=$verified['trade_name'];
    $gstin=strtoupper(trim(tsBillSetting($pdo,'invoice_gstin','')));if($gstin==='')$gstin=$verified['gstin'];
    $pan=strtoupper(trim(tsBillSetting($pdo,'invoice_pan','')));if($pan==='')$pan=$verified['pan'];
    $address=trim(tsBillSetting($pdo,'invoice_address',''));if($address===''||strcasecmp($address,'Odisha, India')===0)$address=$verified['address'];
    $state=trim(tsBillSetting($pdo,'invoice_state',''));if($state==='')$state=$verified['state'];
    $stateCode=trim(tsBillSetting($pdo,'invoice_state_code',''));if($stateCode==='')$stateCode=$verified['state_code'];
    $email=trim(tsBillSetting($pdo,'invoice_email',''));if($email==='')$email=trim(tsBillSetting($pdo,'support_email',tsBillSetting($pdo,'site_email','')));
    $phone=trim(tsBillSetting($pdo,'invoice_phone',''));if($phone==='')$phone=trim(tsBillSetting($pdo,'support_mobile',tsBillSetting($pdo,'site_phone','')));
    $upi=trim(tsBillSetting($pdo,'invoice_upi',''));if($upi==='')$upi=trim(tsBillSetting($pdo,'upi_id',''));
    $upiName=trim(tsBillSetting($pdo,'payment_receiver_name',''));if($upiName==='')$upiName=$trade;
    return[
    'legal_name'=>$legal,'header_name'=>$verified['header_name'],'trade_name'=>$trade,'gstin'=>$gstin,'pan'=>$pan,
    'address'=>$address,'state'=>$state,'state_code'=>$stateCode,
    'registration_type'=>$verified['registration_type'],'registration_date'=>$verified['registration_date'],'logo_url'=>tsBillInvoiceLogoUrl($pdo),
    'email'=>$email,'phone'=>$phone,
    'sac'=>tsBillSetting($pdo,'invoice_sac','998555'),'gst_rate'=>(float)tsBillSetting($pdo,'invoice_default_gst_rate','5'),'tcs_rate'=>(float)tsBillSetting($pdo,'invoice_default_tcs_rate','2'),
    'bank_name'=>tsBillSetting($pdo,'invoice_bank_name',''),'bank_account'=>tsBillSetting($pdo,'invoice_bank_account',''),'bank_ifsc'=>tsBillSetting($pdo,'invoice_bank_ifsc',''),'upi'=>$upi,'upi_name'=>$upiName];}
function tsBillCreateTaxInvoice(PDO $pdo,int $bookingId,int $adminId,array $data):array{
    tsBillAssertOpen($pdo,$bookingId);$b=tsBillBooking($pdo,$bookingId);if(strtolower((string)$b['booking_status'])==='cancelled')throw new RuntimeException('A cancelled Booking cannot issue a Tax Invoice.');
    $status=strtolower(trim((string)($data['invoice_status']??'draft')));if(!in_array($status,['draft','final'],true))$status='draft';
    $taxable=round(max(0,(float)($data['taxable_value']??0)),2);if($taxable<=0)throw new RuntimeException('Taxable value must be greater than zero.');
    $serviceType=strtolower(trim((string)($data['invoice_service_type']??'domestic_tour')));$rule=tsBillInvoiceServiceRule($serviceType);$autoRule=!empty($data['auto_tax_rule']);
    $gstRate=$autoRule?(float)$rule['gst_rate']:round(max(0,min(100,(float)($data['gst_rate']??0))),3);$gstType=strtolower(trim((string)($data['gst_type']??'intra')));if(!in_array($gstType,['intra','inter','none'],true))$gstType='intra';if($gstType==='none')$gstRate=0;
    $gst=round($taxable*$gstRate/100,2);$cgst=$gstType==='intra'?round($gst/2,2):0;$sgst=$gstType==='intra'?round($gst-$cgst,2):0;$igst=$gstType==='inter'?$gst:0;$sub=round($taxable+$cgst+$sgst+$igst,2);
    $tcsOn=$autoRule?(bool)$rule['tcs_on']:!empty($data['tcs_applicable']);$tcsRate=$tcsOn?($autoRule?(float)$rule['tcs_rate']:round(max(0,min(100,(float)($data['tcs_rate']??0))),3)):0;$tcsBasis=(string)($data['tcs_basis']??'subtotal');if(!in_array($tcsBasis,['taxable','subtotal'],true))$tcsBasis='subtotal';$tcsBase=$tcsBasis==='taxable'?$taxable:$sub;$tcs=round($tcsBase*$tcsRate/100,2);$grand=round($sub+$tcs,2);
    $sync=!empty($data['sync_booking_total'])||$status==='final';$current=round((float)$b['total_amount'],2);
    $company=tsBillTaxDefaults($pdo); // Seller/GST/bank/UPI identity is controlled centrally in General Settings.
    $customer=['name'=>(string)$b['customer_name'],'email'=>(string)($b['customer_email']??''),'mobile'=>(string)($b['customer_mobile']??''),'gstin'=>strtoupper(trim((string)($data['customer_gstin']??''))),'pan'=>strtoupper(trim((string)($data['customer_pan']??''))),'address'=>trim((string)($data['billing_address']??'')),'place_of_supply'=>trim((string)($data['place_of_supply']??'')),'place_of_supply_code'=>trim((string)($data['place_of_supply_code']??''))];
    $pax=max(1,(int)($data['service_pax']??((int)($b['adults']??0)+(int)($b['children']??0))));
    $serviceInvoice=['type'=>$serviceType,'label'=>(string)$rule['label'],'auto_tax_rule'=>$autoRule,'rule_note'=>(string)$rule['note'],'description'=>trim((string)($data['service_description']??'')),'service_date'=>trim((string)($data['service_date']??($b['travel_date']??''))),'pax'=>$pax,'reference'=>trim((string)($data['service_reference']??'')),'flight_number'=>strtoupper(trim((string)($data['flight_number']??''))),'flight_date'=>trim((string)($data['flight_date']??'')),'flight_pax'=>max(0,(int)($data['flight_pax']??0)),'flight_route'=>trim((string)($data['flight_route']??'')),'flight_pnr'=>strtoupper(trim((string)($data['flight_pnr']??'')))];
    $sac=trim((string)($data['sac_code']??($autoRule?$rule['sac']:($company['sac']??'998555'))));$note=trim((string)($data['invoice_note']??''));$paid=max(0,(float)$b['paid_amount']);$snap=tsBillCustomerSafeSnapshot($pdo,$bookingId);$snap['schema']=3;$snap['document']='tax_invoice';$snap['company']=$company;$snap['customer_tax']=$customer;$snap['service_invoice']=$serviceInvoice;$snap['tax']=['sac'=>$sac,'taxable_value'=>$taxable,'gst_type'=>$gstType,'gst_rate'=>$gstRate,'cgst'=>$cgst,'sgst'=>$sgst,'igst'=>$igst,'subtotal_after_gst'=>$sub,'tcs_applicable'=>$tcsOn,'tcs_rate'=>$tcsRate,'tcs_basis'=>$tcsBasis,'tcs_base'=>$tcsBase,'tcs_amount'=>$tcs,'grand_total'=>$grand,'amount_words'=>tsBillMoneyWords($grand),'note'=>$note,'rule_code'=>$serviceType,'auto_tax_rule'=>$autoRule,'rule_note'=>(string)$rule['note']];$snap['invoice_date']=date('Y-m-d');
    $pdo->beginTransaction();try{
        if($sync&&abs($grand-$current)>.01){$pdo->prepare("UPDATE bookings SET total_amount=?,payment_status=?,updated_at=NOW() WHERE id=?")->execute([$grand,tsBillPaymentStatus($grand,$paid),$bookingId]);if(function_exists('tsBillSupersedeActiveSchedule'))tsBillSupersedeActiveSchedule($pdo,$bookingId);$snap['booking']['total_amount']=$grand;$snap['booking']['balance_due']=max(0,$grand-$paid);}
        $st=$pdo->prepare("SELECT COALESCE(MAX(version_number),0)+1 FROM booking_invoice_versions WHERE booking_id=?");$st->execute([$bookingId]);$v=max(1,(int)$st->fetchColumn());if($status==='final')$pdo->prepare("UPDATE booking_invoice_versions SET status='void' WHERE booking_id=? AND status='final'")->execute([$bookingId]);$code='TAX-INV-'.date('Y').'-B'.$bookingId.'-V'.$v;
        $st=$pdo->prepare("INSERT INTO booking_invoice_versions(booking_id,version_number,invoice_code,status,currency,booking_total,paid_amount_at_issue,balance_due_at_issue,snapshot_json,created_by_admin_id,finalized_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)");$st->execute([$bookingId,$v,$code,$status,tsBillCurrency($b),$grand,$paid,max(0,$grand-$paid),json_encode($snap,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$adminId?:null,$status==='final'?date('Y-m-d H:i:s'):null]);$id=(int)$pdo->lastInsertId();$pdo->commit();$st=$pdo->prepare("SELECT * FROM booking_invoice_versions WHERE id=?");$st->execute([$id]);return $st->fetch(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable$e){if($pdo->inTransaction())$pdo->rollBack();throw$e;}
}
function tsBillSendInvoiceEmail(PDO $pdo,int $invoiceId):array{
    $st=$pdo->prepare("SELECT i.*,b.customer_name,b.customer_email,b.booking_number FROM booking_invoice_versions i JOIN bookings b ON b.id=i.booking_id WHERE i.id=? LIMIT 1");$st->execute([$invoiceId]);$i=$st->fetch(PDO::FETCH_ASSOC);if(!$i||$i['status']!=='final')return['sent'=>false,'message'=>'Only a final invoice can be emailed.'];$email=trim((string)$i['customer_email']);if(!filter_var($email,FILTER_VALIDATE_EMAIL)||!class_exists('\\PHPMailer\\PHPMailer\\PHPMailer'))return['sent'=>false,'message'=>'Customer email or mail service is unavailable.'];$url=tsBillInvoiceEmailUrl($invoiceId,90);$site=tsBillSetting($pdo,'site_name','TRAVSCOPE.COM');$name=trim((string)$i['customer_name'])?:'Traveller';$e=fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');
    try{$m=new \PHPMailer\PHPMailer\PHPMailer(true);if(defined('SMTP_ENABLED')&&SMTP_ENABLED){$m->isSMTP();$m->Host=defined('SMTP_HOST')?SMTP_HOST:'smtp.gmail.com';$m->SMTPAuth=defined('SMTP_AUTH')?SMTP_AUTH:true;$m->Username=defined('SMTP_USERNAME')?SMTP_USERNAME:'';$m->Password=defined('SMTP_PASSWORD')?SMTP_PASSWORD:'';$m->SMTPSecure=defined('SMTP_ENCRYPTION')?SMTP_ENCRYPTION:'tls';$m->Port=defined('SMTP_PORT')?SMTP_PORT:587;}$from=defined('MAIL_FROM_ADDRESS')?MAIL_FROM_ADDRESS:(defined('SMTP_USERNAME')?SMTP_USERNAME:'');$fromName=defined('MAIL_FROM_NAME')?MAIL_FROM_NAME:$site;$m->setFrom($from,$fromName);$m->addAddress($email,$name);$m->isHTML(true);$m->Subject='Tax Invoice · '.$i['invoice_code'].' · '.$i['booking_number'];$m->Body='<div style="font-family:Arial,sans-serif;background:#f4f7fb;padding:24px"><div style="max-width:680px;margin:auto;background:#fff;border-radius:16px;padding:24px"><h2 style="margin-top:0">'.$e($site).' Tax Invoice</h2><p>Dear '.$e($name).',</p><p>Your final tax invoice for booking <strong>'.$e($i['booking_number']).'</strong> is ready.</p><div style="padding:15px;background:#f8fafc;border-radius:10px"><strong>'.$e($i['invoice_code']).'</strong><br>Total: '.$e($i['currency']).' '.number_format((float)$i['booking_total'],2).'<br>Balance at issue: '.$e($i['currency']).' '.number_format((float)$i['balance_due_at_issue'],2).'</div><p style="text-align:center;margin-top:22px"><a href="'.$e($url).'" style="background:#0f172a;color:#fff;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:bold">View / Print Tax Invoice</a></p><p>Thank you,<br><strong>'.$e($site).'</strong></p></div></div>';$m->AltBody='Tax Invoice '.$i['invoice_code'].' for booking '.$i['booking_number'].'\n'.$url;$m->send();return['sent'=>true,'message'=>'Tax invoice emailed to '.$email.'.'];}catch(Throwable$e){error_log('Tax invoice email: '.$e->getMessage());return['sent'=>false,'message'=>'Invoice created, but email could not be sent.'];}
}

function tsBillSendPaymentReminder(PDO $pdo,int $bookingId,int $installmentId,int $adminId):array
{
    if(!tsBillReady($pdo))throw new RuntimeException('Customer Billing SQL is not installed yet.');$b=tsBillBooking($pdo,$bookingId);$email=trim((string)($b['customer_email']??''));if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Customer email is not available for a payment reminder.');$b=tsBillSyncBookingPayableFromFinalInvoice($pdo,$bookingId)?:$b;$out=tsBillCollectibleOutstanding($pdo,$b);if($out<=.009)throw new RuntimeException('This Booking has no outstanding customer balance.');$amount=$out;$label='Outstanding Booking Balance';$inst=null;if($installmentId>0){$target=tsBillPaymentTarget($pdo,$bookingId,$installmentId,$out);$amount=(float)$target['amount'];$label=(string)$target['label'];$inst=$target['installment'];}$payUrl=BASE_URL.'payment.php?booking='.$bookingId.($installmentId>0?'&installment='.$installmentId:'');$currency=tsBillCurrency($b);$message='Payment reminder for Booking '.(string)$b['booking_number'].': '.$label.' · '.$currency.' '.number_format($amount,2);if($inst&&!empty($inst['due_date']))$message.=' · Due '.date('d M Y',strtotime((string)$inst['due_date']));$sent=false;$err='';
    try{$mail=new \PHPMailer\PHPMailer\PHPMailer(true);if(defined('SMTP_ENABLED')&&SMTP_ENABLED){$mail->isSMTP();$mail->Host=defined('SMTP_HOST')?SMTP_HOST:'smtp.gmail.com';$mail->SMTPAuth=defined('SMTP_AUTH')?SMTP_AUTH:true;$mail->Username=defined('SMTP_USERNAME')?SMTP_USERNAME:'';$mail->Password=defined('SMTP_PASSWORD')?SMTP_PASSWORD:'';$mail->SMTPSecure=defined('SMTP_ENCRYPTION')?SMTP_ENCRYPTION:'tls';$mail->Port=defined('SMTP_PORT')?SMTP_PORT:587;}$from=defined('MAIL_FROM_ADDRESS')?MAIL_FROM_ADDRESS:(defined('SMTP_USERNAME')?SMTP_USERNAME:'');$fromName=defined('MAIL_FROM_NAME')?MAIL_FROM_NAME:'TRAVSCOPE.COM';$mail->setFrom($from,$fromName);$mail->addAddress($email,(string)($b['customer_name']??'Traveller'));if(defined('MAIL_REPLY_TO')&&filter_var(MAIL_REPLY_TO,FILTER_VALIDATE_EMAIL))$mail->addReplyTo(MAIL_REPLY_TO,$fromName);$mail->isHTML(true);$mail->Subject='Payment Reminder · Booking '.(string)$b['booking_number'];$mail->Body='<div style="font-family:Arial,sans-serif;line-height:1.6"><p>Dear '.htmlspecialchars((string)($b['customer_name']??'Traveller'),ENT_QUOTES,'UTF-8').',</p><p>Payment reminder for Booking <strong>'.htmlspecialchars((string)$b['booking_number'],ENT_QUOTES,'UTF-8').'</strong>.</p><p><strong>'.htmlspecialchars($label,ENT_QUOTES,'UTF-8').'</strong><br>'.htmlspecialchars($currency,ENT_QUOTES,'UTF-8').' '.number_format($amount,2).'</p>'.($inst&&!empty($inst['due_date'])?'<p>Due: <strong>'.date('d M Y',strtotime((string)$inst['due_date'])).'</strong></p>':'').'<p><a href="'.htmlspecialchars($payUrl,ENT_QUOTES,'UTF-8').'" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;padding:11px 16px;border-radius:8px;font-weight:bold">Pay Now</a></p><p>Thank you,<br>TRAVSCOPE.COM</p></div>';$mail->AltBody=$message."\nPay: ".$payUrl;$mail->send();$sent=true;}catch(Throwable$e){$err=$e->getMessage();error_log('TRAVSCOPE payment reminder email: '.$err);}
    $s=$pdo->prepare("INSERT INTO booking_billing_reminders (booking_id,installment_id,channel,recipient,message,status,sent_by_admin_id,sent_at) VALUES (?,?,'email',?,?,?,?,NOW())");$s->execute([$bookingId,$installmentId?:null,$email,$message,$sent?'sent':'failed',$adminId?:null]);if(!$sent)throw new RuntimeException('Payment reminder email could not be sent. '.($err?:'Check SMTP configuration.'));return['sent'=>true,'recipient'=>$email,'amount'=>$amount,'label'=>$label];
}

function tsBillStatement(PDO $pdo,int $bookingId):array
{
    if(!tsBillReady($pdo))throw new RuntimeException('Customer Billing SQL is not installed yet.');$b=tsBillBooking($pdo,$bookingId);$s=$pdo->prepare("SELECT id,transaction_id,payment_gateway,amount,currency,payment_method,status,paid_at,created_at FROM payments WHERE booking_id=? AND status='success' ORDER BY COALESCE(paid_at,created_at) ASC,id ASC");$s->execute([$bookingId]);$payments=$s->fetchAll(PDO::FETCH_ASSOC)?:[];$refunds=tsBillRefunds($pdo,$bookingId);$adjustments=tsBillAdjustments($pdo,$bookingId);$receipts=tsBillReceipts($pdo,$bookingId);$schedule=tsBillActiveSchedule($pdo,$bookingId);return['booking'=>$b,'payments'=>$payments,'refunds'=>$refunds,'adjustments'=>$adjustments,'receipts'=>$receipts,'active_schedule'=>$schedule,'installments'=>$schedule?tsBillInstallments($pdo,$bookingId,(int)$schedule['id']):[],'outstanding'=>tsBillCollectibleOutstanding($pdo,$b),'pending_refund'=>tsBillPendingRefundTotal($pdo,$bookingId)];
}
