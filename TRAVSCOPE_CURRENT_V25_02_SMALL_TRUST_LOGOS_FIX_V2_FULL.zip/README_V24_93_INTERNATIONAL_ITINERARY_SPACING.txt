TRAVSCOPE V24.93 — International Itinerary Spacing
Built from V24.92.

Changes
- Tightened day-wise itinerary spacing for a cleaner international brochure-style layout.
- Balanced desktop photo/text proportions to reduce unnecessary blank space.
- Reduced card padding, timeline gaps, photo-caption spacing and title/paragraph spacing.
- Preserved justified itinerary narrative text with improved line rhythm.
- Converted Start / Via / End / Distance / Travel Time facts into compact responsive segments with separators.
- Improved tablet/mobile breakpoints and compact day markers.
- Preserved full uncropped itinerary images and V24.89/V24.92 content guards.
- No database/schema changes.

No SQL required.
