<?php
require_once __DIR__ . '/config.php';

$siteName = (string)getSetting($pdo, 'site_name', 'TRAVSCOPE.COM');
$siteTagline = (string)getSetting($pdo, 'site_tagline', 'Explore More. Travel Better.');
$supportEmail = (string)getSetting($pdo, 'support_email', 'support@travscope.com');
$supportMobile = (string)getSetting($pdo, 'support_mobile', '');

function storyImage(?string $image): string {
    $image=trim((string)$image);
    if($image==='') return 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1200&q=85';
    if(preg_match('#^https?://#i',$image)) return $image;
    return BASE_URL.ltrim($image,'/');
}
function storyExcerpt(array $r): string {
    $v=trim((string)($r['excerpt']??''));
    if($v!=='') return $v;
    $v=trim(preg_replace('/\s+/',' ',strip_tags((string)($r['content']??''))));
    return mb_strlen($v)>190?mb_substr($v,0,190).'...':$v;
}

$q=trim((string)($_GET['q']??''));
$category=trim((string)($_GET['category']??''));
$destination=(int)($_GET['destination']??0);
$location=trim((string)($_GET['location']??''));

$categories=[];$destinations=[];$stories=[];$featured=null;

try{$categories=$pdo->query("SELECT id,name,slug FROM blog_categories WHERE status='active' ORDER BY sort_order ASC,name ASC")->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){}
try{$destinations=$pdo->query("SELECT DISTINCT d.id,d.name,d.country FROM destinations d INNER JOIN blogs b ON b.destination_id=d.id AND b.status='published' WHERE d.status='active' ORDER BY d.name ASC")->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){}

try{
 $where=["b.status='published'","(b.published_at IS NULL OR b.published_at<=NOW())"];$params=[];
 if($q!==''){$where[]="(b.title LIKE ? OR b.excerpt LIKE ? OR b.content LIKE ? OR b.location_name LIKE ? OR b.city LIKE ? OR b.state_name LIKE ? OR b.country LIKE ?)";$like='%'.$q.'%';array_push($params,$like,$like,$like,$like,$like,$like,$like);}
 if($category!==''){$where[]="c.slug=?";$params[]=$category;}
 if($destination>0){$where[]="b.destination_id=?";$params[]=$destination;}
 if($location!==''){$where[]="(b.location_name LIKE ? OR b.city LIKE ? OR b.state_name LIKE ? OR b.country LIKE ?)";$like='%'.$location.'%';array_push($params,$like,$like,$like,$like);}
 $sql="SELECT b.*,c.name category_name,c.slug category_slug,d.name destination_name,d.country destination_country FROM blogs b LEFT JOIN blog_categories c ON c.id=b.category_id LEFT JOIN destinations d ON d.id=b.destination_id WHERE ".implode(' AND ',$where)." ORDER BY b.featured DESC,COALESCE(b.published_at,b.created_at) DESC,b.id DESC";
 $s=$pdo->prepare($sql);$s->execute($params);$stories=$s->fetchAll(PDO::FETCH_ASSOC);
 if($stories){foreach($stories as $r){if((int)$r['featured']===1){$featured=$r;break;}}}
}catch(Throwable $e){$stories=[];}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="TRAVSCOPE travel stories, destination guides, local experiences and travel inspiration.">
<title>Travel Stories & Blog | <?= e($siteName); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
:root{--navy:#07192d;--blue:#0b74ff;--bg:#f5f8fc;--text:#172033;--muted:#748196;--border:#e4eaf1;--white:#fff;--shadow:0 16px 45px rgba(7,25,45,.09)}
*{box-sizing:border-box;margin:0;padding:0}body{font-family:'DM Sans',sans-serif;color:var(--text);background:#fff;line-height:1.6;font-size:16px}a{text-decoration:none;color:inherit}img{display:block;width:100%}.container{width:min(1180px,calc(100% - 34px));margin:auto}
.topbar{background:var(--navy);color:#b9c9d8;font-size:13px}.topbar .container{min-height:38px;display:flex;justify-content:space-between;align-items:center}.nav{position:sticky;top:0;z-index:1000;background:rgba(255,255,255,.97);border-bottom:1px solid var(--border)}.navin{height:76px;display:flex;align-items:center;justify-content:space-between;gap:20px}.logo{display:flex;align-items:center;gap:10px;font:800 21px 'Manrope';color:var(--navy)}.logoicon{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;color:#fff;background:linear-gradient(135deg,var(--blue),#00b8ff)}.logo span{color:var(--blue)}.links{display:flex;align-items:center;gap:24px}.links a{font-size:14px;font-weight:700;color:#405067}.links a.active,.links a:hover{color:var(--blue)}.btn{min-height:44px;padding:0 16px;border-radius:9px;display:inline-flex;align-items:center;justify-content:center;gap:7px;background:var(--blue);color:#fff;font-size:13px;font-weight:800}
.hero{padding:90px 0 70px;color:#fff;background:linear-gradient(120deg,rgba(7,25,45,.96),rgba(11,116,255,.78)),url('https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1800&q=85') center/cover}.hero .eyebrow{font-size:12px;font-weight:800;letter-spacing:1.2px}.hero h1{max-width:800px;margin-top:10px;font:800 clamp(38px,6vw,65px)/1.08 'Manrope'}.hero p{max-width:720px;margin-top:16px;color:#dae6f2;font-size:17px}
.search{position:relative;margin-top:-32px;padding:18px;border-radius:15px;background:#fff;box-shadow:var(--shadow)}.search form{display:grid;grid-template-columns:1.5fr 1fr 1fr 1fr auto;gap:9px}.control{height:48px;padding:0 12px;border:1px solid var(--border);border-radius:9px;background:#fff;font-size:14px}
.section{padding:75px 0}.heading{text-align:center;max-width:720px;margin:0 auto 35px}.heading span{color:var(--blue);font-size:12px;font-weight:800;letter-spacing:1px}.heading h2{margin-top:6px;font:800 clamp(28px,4vw,40px) 'Manrope';color:var(--navy)}.heading p{margin-top:8px;color:var(--muted)}
.feature{display:grid;grid-template-columns:1.1fr .9fr;overflow:hidden;border-radius:20px;background:#fff;border:1px solid var(--border);box-shadow:var(--shadow);margin-bottom:35px}.feature-img{min-height:390px}.feature-img img{height:100%;object-fit:cover}.feature-body{padding:38px}.tag{display:inline-flex;padding:6px 10px;border-radius:20px;background:#edf5ff;color:var(--blue);font-size:11px;font-weight:800}.feature h2{margin-top:12px;font:800 31px/1.25 'Manrope';color:var(--navy)}.meta{display:flex;gap:14px;flex-wrap:wrap;margin-top:12px;color:#738095;font-size:13px}.feature p{margin-top:15px;color:#5e6b7d;font-size:15px;line-height:1.75}.read{margin-top:20px}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}.card{overflow:hidden;border:1px solid var(--border);border-radius:16px;background:#fff;box-shadow:var(--shadow);transition:.25s}.card:hover{transform:translateY(-4px)}.card-img{height:220px;overflow:hidden}.card-img img{height:100%;object-fit:cover;transition:.4s}.card:hover img{transform:scale(1.04)}.card-body{padding:18px}.card h3{margin-top:8px;font:800 18px/1.4 'Manrope';color:var(--navy)}.card p{margin-top:8px;color:var(--muted);font-size:14px;line-height:1.65}.card .meta{font-size:12px}.empty{padding:55px 20px;text-align:center;color:var(--muted)}
.footer{padding:42px 0;background:#051525;color:#9db0c2}.foot{display:flex;align-items:center;justify-content:space-between;gap:20px}.footer .logo{color:#fff}.footer p{font-size:13px}
@media(max-width:1000px){.search form{grid-template-columns:1fr 1fr}.search .btn{min-height:48px}.grid{grid-template-columns:repeat(2,1fr)}.feature{grid-template-columns:1fr}.feature-img{min-height:320px}.links{display:none}}
@media(max-width:650px){.hero{padding:65px 0 55px}.search form{grid-template-columns:1fr}.grid{grid-template-columns:1fr}.feature-body{padding:23px}.feature h2{font-size:25px}.feature-img{min-height:245px}.section{padding:55px 0}.foot{align-items:flex-start;flex-direction:column}}


/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-public-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="public"></script>
</head><body>
<div class="topbar"><div class="container"><span>TRAVSCOPE Travel Stories</span><span><?= e($supportMobile ?: $supportEmail); ?></span></div></div>
<nav class="nav"><div class="container navin">
<a href="<?= e(BASE_URL); ?>" class="logo"><span class="logoicon"><i class="fa-solid fa-plane"></i></span>TRAV<span>SCOPE</span></a>
<div class="links"><a href="index.php">Home</a><a href="packages.php">Packages</a><a href="destinations.php">Destinations</a><a href="blog.php" class="active">Travel Stories</a><a href="contact.php">Contact</a></div>
<a href="packages.php" class="btn"><i class="fa-solid fa-compass"></i> Explore Trips</a>
</div></nav>
<section class="hero"><div class="container"><div class="eyebrow">TRAVSCOPE JOURNAL</div><h1>Stories, places and experiences worth travelling for.</h1><p>Discover destination guides, local experiences, practical travel ideas and memorable journeys from TRAVSCOPE.</p></div></section>
<div class="container"><div class="search"><form method="get">
<input class="control" type="search" name="q" value="<?= e($q); ?>" placeholder="Search stories or places...">
<select class="control" name="category"><option value="">All Categories</option><?php foreach($categories as $c): ?><option value="<?= e($c['slug']); ?>" <?= $category===$c['slug']?'selected':''; ?>><?= e($c['name']); ?></option><?php endforeach; ?></select>
<select class="control" name="destination"><option value="0">All Destinations</option><?php foreach($destinations as $d): ?><option value="<?= (int)$d['id']; ?>" <?= $destination===(int)$d['id']?'selected':''; ?>><?= e($d['name']); ?></option><?php endforeach; ?></select>
<input class="control" type="search" name="location" value="<?= e($location); ?>" placeholder="Specific location...">
<button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
</form></div></div>

<section class="section"><div class="container">
<div class="heading"><span>TRAVEL INSPIRATION</span><h2>Travel Stories & Destination Guides</h2><p>Explore stories by destination, location or travel interest.</p></div>

<?php if($featured && $q==='' && $category==='' && $destination===0 && $location===''): ?>
<article class="feature"><a class="feature-img" href="blog-details.php?slug=<?= urlencode($featured['slug']); ?>"><img src="<?= e(storyImage($featured['main_image'])); ?>" alt="<?= e($featured['image_alt'] ?: $featured['title']); ?>"></a><div class="feature-body"><span class="tag">Featured Story</span><h2><a href="blog-details.php?slug=<?= urlencode($featured['slug']); ?>"><?= e($featured['title']); ?></a></h2><div class="meta"><span><i class="fa-solid fa-location-dot"></i> <?= e($featured['location_name'] ?: $featured['destination_name'] ?: $featured['country']); ?></span><span><i class="fa-regular fa-calendar"></i> <?= e(date('d M Y',strtotime($featured['published_at'] ?: $featured['created_at']))); ?></span></div><p><?= e(storyExcerpt($featured)); ?></p><a href="blog-details.php?slug=<?= urlencode($featured['slug']); ?>" class="btn read">Read Story <i class="fa-solid fa-arrow-right"></i></a></div></article>
<?php endif; ?>

<?php if($stories): ?><div class="grid">
<?php foreach($stories as $r): if($featured && (int)$featured['id']===(int)$r['id'] && $q==='' && $category==='' && $destination===0 && $location==='') continue; ?>
<article class="card"><a href="blog-details.php?slug=<?= urlencode($r['slug']); ?>" class="card-img"><img src="<?= e(storyImage($r['main_image'])); ?>" alt="<?= e($r['image_alt'] ?: $r['title']); ?>"></a><div class="card-body"><span class="tag"><?= e($r['category_name'] ?: 'Travel Story'); ?></span><h3><a href="blog-details.php?slug=<?= urlencode($r['slug']); ?>"><?= e($r['title']); ?></a></h3><div class="meta"><span><i class="fa-solid fa-location-dot"></i> <?= e($r['location_name'] ?: $r['destination_name'] ?: $r['country'] ?: 'Travel'); ?></span><span><i class="fa-regular fa-clock"></i> <?= max(1,(int)ceil(str_word_count(strip_tags($r['content']))/220)); ?> min read</span></div><p><?= e(storyExcerpt($r)); ?></p></div></article>
<?php endforeach; ?></div><?php else: ?><div class="empty"><i class="fa-regular fa-compass" style="font-size:35px"></i><h3 style="margin-top:10px">No stories found</h3><p>Try another destination, location or category.</p></div><?php endif; ?>
</div></section>
<footer class="footer"><div class="container foot"><a href="<?= e(BASE_URL); ?>" class="logo"><span class="logoicon"><i class="fa-solid fa-plane"></i></span>TRAV<span>SCOPE</span></a><p><?= e($siteTagline); ?> &copy; <?= date('Y'); ?> TRAVSCOPE.COM</p></div></footer>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
