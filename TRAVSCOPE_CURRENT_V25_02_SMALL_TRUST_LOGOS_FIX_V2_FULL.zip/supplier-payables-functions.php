<?php
declare(strict_types=1);

/* TRAVSCOPE V24.86 — Supplier Payables / Accounts Payable controls. */

function spaTable(PDO $pdo, string $table): bool {
    static $cache=[]; $k=strtolower($table);
    if(array_key_exists($k,$cache)) return $cache[$k];
    try{$s=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");$s->execute([$table]);return $cache[$k]=(int)$s->fetchColumn()>0;}catch(Throwable $e){return $cache[$k]=false;}
}
function spaReady(PDO $pdo): bool {
    foreach(['supplier_invoice_controls','supplier_payment_controls','supplier_advances','supplier_advance_allocations','supplier_finance_adjustments','supplier_payment_vouchers','supplier_finance_audit'] as $t){if(!spaTable($pdo,$t)) return false;} return true;
}
function spaMoney(float $n,string $currency='INR'):string{return (strtoupper($currency)==='INR'?'₹':strtoupper($currency).' ').number_format($n,2);}
function spaAudit(PDO $pdo,string $entityType,int $entityId,string $action,int $adminId,array $before=[],array $after=[],string $reason=''):void{
    if(!spaTable($pdo,'supplier_finance_audit'))return;
    try{$s=$pdo->prepare("INSERT INTO supplier_finance_audit(entity_type,entity_id,action_name,before_json,after_json,reason,admin_id,created_at) VALUES(?,?,?,?,?,?,?,NOW())");$s->execute([$entityType,$entityId,$action,$before?json_encode($before,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):null,$after?json_encode($after,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):null,trim($reason)?:null,$adminId>0?$adminId:null]);}catch(Throwable $e){error_log('Supplier finance audit: '.$e->getMessage());}
}
function spaCommittedCost(PDO $pdo,int $bookingId,int $supplierId):float{
    if(!spaTable($pdo,'booking_service_snapshots'))return 0.0;
    try{$s=$pdo->prepare("SELECT COALESCE(SUM(internal_supplier_cost),0) FROM booking_service_snapshots WHERE booking_id=? AND source_supplier_id=?");$s->execute([$bookingId,$supplierId]);return round((float)$s->fetchColumn(),2);}catch(Throwable $e){return 0.0;}
}
function spaInvoiceControl(PDO $pdo,int $invoiceId):array{
    if(!spaTable($pdo,'supplier_invoice_controls'))return [];
    try{$s=$pdo->prepare("SELECT * FROM supplier_invoice_controls WHERE supplier_invoice_id=? LIMIT 1");$s->execute([$invoiceId]);return $s->fetch(PDO::FETCH_ASSOC)?:[];}catch(Throwable $e){return [];}
}
function spaUpsertInvoiceControl(PDO $pdo,int $invoiceId,array $data):void{
    if(!spaTable($pdo,'supplier_invoice_controls'))throw new RuntimeException('V24.86 Supplier Payables SQL is not installed.');
    $s=$pdo->prepare("INSERT INTO supplier_invoice_controls(supplier_invoice_id,supplier_gstin,taxable_value,gst_amount,tds_amount,discount_amount,other_adjustment_amount,committed_cost_amount,variance_amount,approved_payable_amount,review_status,match_status,approval_reason,approved_by_admin_id,approved_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE supplier_gstin=VALUES(supplier_gstin),taxable_value=VALUES(taxable_value),gst_amount=VALUES(gst_amount),tds_amount=VALUES(tds_amount),discount_amount=VALUES(discount_amount),other_adjustment_amount=VALUES(other_adjustment_amount),committed_cost_amount=VALUES(committed_cost_amount),variance_amount=VALUES(variance_amount),approved_payable_amount=COALESCE(VALUES(approved_payable_amount),approved_payable_amount),review_status=VALUES(review_status),match_status=VALUES(match_status),approval_reason=COALESCE(VALUES(approval_reason),approval_reason),approved_by_admin_id=COALESCE(VALUES(approved_by_admin_id),approved_by_admin_id),approved_at=COALESCE(VALUES(approved_at),approved_at),updated_at=NOW()");
    $s->execute([$invoiceId,trim((string)($data['supplier_gstin']??''))?:null,round((float)($data['taxable_value']??0),2),round((float)($data['gst_amount']??0),2),round((float)($data['tds_amount']??0),2),round((float)($data['discount_amount']??0),2),round((float)($data['other_adjustment_amount']??0),2),round((float)($data['committed_cost_amount']??0),2),round((float)($data['variance_amount']??0),2),array_key_exists('approved_payable_amount',$data)&&$data['approved_payable_amount']!==null?round((float)$data['approved_payable_amount'],2):null,(string)($data['review_status']??'submitted'),(string)($data['match_status']??'needs_review'),trim((string)($data['approval_reason']??''))?:null,!empty($data['approved_by_admin_id'])?(int)$data['approved_by_admin_id']:null,!empty($data['approved_at'])?(string)$data['approved_at']:null]);
}
function spaEffectiveInvoiceTotal(PDO $pdo,array $invoice):float{
    $base=(float)($invoice['total_amount']??0);$c=spaInvoiceControl($pdo,(int)($invoice['id']??0));
    if(strtolower((string)($invoice['status']??''))==='approved' && isset($c['approved_payable_amount']) && $c['approved_payable_amount']!==null) return max(0,round((float)$c['approved_payable_amount'],2));
    return max(0,round($base,2));
}
function spaInvoiceAdjustmentsNet(PDO $pdo,int $invoiceId):float{
    if(!spaTable($pdo,'supplier_finance_adjustments'))return 0.0;
    try{$s=$pdo->prepare("SELECT COALESCE(SUM(CASE WHEN effect='increase' THEN amount ELSE -amount END),0) FROM supplier_finance_adjustments WHERE supplier_invoice_id=? AND status='posted'");$s->execute([$invoiceId]);return round((float)$s->fetchColumn(),2);}catch(Throwable $e){return 0.0;}
}
function spaInvoiceAdvanceAllocated(PDO $pdo,int $invoiceId):float{
    if(!spaTable($pdo,'supplier_advance_allocations'))return 0.0;
    try{$s=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM supplier_advance_allocations WHERE supplier_invoice_id=? AND status='posted'");$s->execute([$invoiceId]);return round((float)$s->fetchColumn(),2);}catch(Throwable $e){return 0.0;}
}
function spaInvoicePaid(PDO $pdo,int $invoiceId):float{
    try{$s=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM supplier_payments WHERE supplier_invoice_id=? AND status='paid'");$s->execute([$invoiceId]);return round((float)$s->fetchColumn(),2);}catch(Throwable $e){return 0.0;}
}
function spaInvoiceOutstanding(PDO $pdo,array $invoice):float{
    $id=(int)$invoice['id'];$gross=spaEffectiveInvoiceTotal($pdo,$invoice)+spaInvoiceAdjustmentsNet($pdo,$id);$settled=spaInvoicePaid($pdo,$id)+spaInvoiceAdvanceAllocated($pdo,$id);return max(0,round($gross-$settled,2));
}
function spaInvoiceMatch(PDO $pdo,array $invoice):array{
    $committed=spaCommittedCost($pdo,(int)$invoice['booking_id'],(int)$invoice['supplier_id']);$bill=(float)$invoice['total_amount'];$variance=round($bill-$committed,2);
    $hasConfirm=false;if(spaTable($pdo,'supplier_booking_orders')){try{$s=$pdo->prepare("SELECT status,supplier_confirmation_ref FROM supplier_booking_orders WHERE booking_id=? AND supplier_id=? LIMIT 1");$s->execute([(int)$invoice['booking_id'],(int)$invoice['supplier_id']]);$o=$s->fetch(PDO::FETCH_ASSOC);$hasConfirm=$o && (trim((string)($o['supplier_confirmation_ref']??''))!=='' || in_array(strtolower((string)($o['status']??'')),['confirmed','accepted','completed'],true));}catch(Throwable $e){}}
    $status=!$hasConfirm?'missing_confirmation':(abs($variance)<=0.01?'matched':'variance');return['committed'=>$committed,'bill'=>$bill,'variance'=>$variance,'status'=>$status,'has_confirmation'=>$hasConfirm];
}
function spaSetInvoiceReviewStatus(PDO $pdo,int $invoiceId,int $adminId,string $status,string $reason=''):void{
    $allowed=['submitted','under_review','on_hold','rejected','disputed'];if(!in_array($status,$allowed,true))throw new RuntimeException('Invalid supplier invoice review status.');
    $s=$pdo->prepare("SELECT * FROM supplier_invoices WHERE id=? AND status<>'void' LIMIT 1");$s->execute([$invoiceId]);$inv=$s->fetch(PDO::FETCH_ASSOC);if(!$inv)throw new RuntimeException('Supplier invoice not found.');if(strtolower((string)$inv['status'])==='approved')throw new RuntimeException('Approved invoice status cannot be changed here.');
    $c=spaInvoiceControl($pdo,$invoiceId);$m=spaInvoiceMatch($pdo,$inv);spaUpsertInvoiceControl($pdo,$invoiceId,['supplier_gstin'=>(string)($c['supplier_gstin']??''),'taxable_value'=>(float)($c['taxable_value']??$inv['net_amount']),'gst_amount'=>(float)($c['gst_amount']??$inv['tax_amount']),'tds_amount'=>(float)($c['tds_amount']??0),'discount_amount'=>(float)($c['discount_amount']??0),'other_adjustment_amount'=>(float)($c['other_adjustment_amount']??0),'committed_cost_amount'=>$m['committed'],'variance_amount'=>$m['variance'],'approved_payable_amount'=>$c['approved_payable_amount']??null,'review_status'=>$status,'match_status'=>$m['status'],'approval_reason'=>trim($reason)?:($c['approval_reason']??null)]);spaAudit($pdo,'supplier_invoice',$invoiceId,'review_status',$adminId,['review_status'=>$c['review_status']??'submitted'],['review_status'=>$status],$reason);
}

function spaApproveInvoice(PDO $pdo,int $invoiceId,int $adminId,float $approvedPayable,string $reason):void{
    $s=$pdo->prepare("SELECT * FROM supplier_invoices WHERE id=? LIMIT 1");$s->execute([$invoiceId]);$inv=$s->fetch(PDO::FETCH_ASSOC);if(!$inv)throw new RuntimeException('Supplier invoice not found.');
    if(in_array(strtolower((string)$inv['status']),['void'],true))throw new RuntimeException('A void supplier invoice cannot be approved.');
    $approvedPayable=round(max(0,$approvedPayable),2);if($approvedPayable<=0)throw new RuntimeException('Approved payable amount must be greater than zero.');
    $existingControl=spaInvoiceControl($pdo,$invoiceId);$supplierGstin=(string)($existingControl['supplier_gstin']??'');
    if($supplierGstin===''){try{$gs=$pdo->prepare("SELECT gstin FROM suppliers WHERE id=? LIMIT 1");$gs->execute([(int)$inv['supplier_id']]);$supplierGstin=(string)($gs->fetchColumn()?:'');}catch(Throwable $e){}}
    $before=['status'=>$inv['status'],'total_amount'=>$inv['total_amount'],'control'=>$existingControl];
    $m=spaInvoiceMatch($pdo,$inv);$pdo->beginTransaction();try{
        $u=$pdo->prepare("UPDATE supplier_invoices SET status='approved',approved_by_admin_id=?,approved_at=NOW(),updated_at=NOW() WHERE id=? AND status<>'void'");$u->execute([$adminId>0?$adminId:null,$invoiceId]);
        spaUpsertInvoiceControl($pdo,$invoiceId,['supplier_gstin'=>$supplierGstin,'taxable_value'=>(float)$inv['net_amount'],'gst_amount'=>(float)$inv['tax_amount'],'tds_amount'=>(float)($existingControl['tds_amount']??0),'discount_amount'=>(float)($existingControl['discount_amount']??0),'other_adjustment_amount'=>(float)($existingControl['other_adjustment_amount']??0),'committed_cost_amount'=>$m['committed'],'variance_amount'=>$approvedPayable-$m['committed'],'approved_payable_amount'=>$approvedPayable,'review_status'=>'approved','match_status'=>$m['status'],'approval_reason'=>$reason,'approved_by_admin_id'=>$adminId,'approved_at'=>date('Y-m-d H:i:s')]);
        $pdo->commit();spaAudit($pdo,'supplier_invoice',$invoiceId,'approve',$adminId,$before,['approved_payable_amount'=>$approvedPayable,'match'=>$m],$reason);
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function spaCreateVoucher(PDO $pdo,int $paymentId,int $adminId):array{
    if(!spaReady($pdo))throw new RuntimeException('V24.86 Supplier Payables SQL is not installed.');
    $s=$pdo->prepare("SELECT p.*,pc.transfer_amount,pc.tds_amount,pc.other_deduction,pc.bank_charge,i.invoice_number,i.invoice_date,i.total_amount,i.currency,s.company_name,s.legal_name,s.gstin,s.tax_id,b.booking_number,b.customer_name,b.travel_date FROM supplier_payments p JOIN supplier_invoices i ON i.id=p.supplier_invoice_id JOIN suppliers s ON s.id=p.supplier_id JOIN bookings b ON b.id=p.booking_id LEFT JOIN supplier_payment_controls pc ON pc.supplier_payment_id=p.id WHERE p.id=? LIMIT 1");$s->execute([$paymentId]);$r=$s->fetch(PDO::FETCH_ASSOC);if(!$r)throw new RuntimeException('Supplier payment not found.');
    $existing=$pdo->prepare("SELECT * FROM supplier_payment_vouchers WHERE supplier_payment_id=? LIMIT 1");$existing->execute([$paymentId]);$old=$existing->fetch(PDO::FETCH_ASSOC);if($old)return $old;
    $code='SPV-'.date('Y').'-P'.$paymentId.'-'.strtoupper(substr(hash('sha256',$paymentId.'|'.microtime(true)),0,5));
    $snap=['supplier'=>['name'=>$r['company_name'],'legal_name'=>$r['legal_name'],'gstin'=>$r['gstin'],'pan'=>$r['tax_id']],'booking'=>['number'=>$r['booking_number'],'customer'=>$r['customer_name'],'travel_date'=>$r['travel_date']],'invoice'=>['number'=>$r['invoice_number'],'date'=>$r['invoice_date'],'total'=>(float)$r['total_amount'],'currency'=>$r['currency']],'payment'=>['settlement'=>(float)$r['amount'],'transfer'=>(float)($r['transfer_amount']??$r['amount']),'tds'=>(float)($r['tds_amount']??0),'other_deduction'=>(float)($r['other_deduction']??0),'bank_charge'=>(float)($r['bank_charge']??0),'method'=>$r['payment_method'],'reference'=>$r['reference_number'],'date'=>$r['payment_date'],'notes'=>$r['notes']]];
    $ins=$pdo->prepare("INSERT INTO supplier_payment_vouchers(voucher_number,supplier_payment_id,supplier_id,booking_id,supplier_invoice_id,currency,settlement_amount,transfer_amount,status,snapshot_json,created_by_admin_id,created_at) VALUES(?,?,?,?,?,?,?,?, 'issued',?,?,NOW())");$ins->execute([$code,$paymentId,(int)$r['supplier_id'],(int)$r['booking_id'],(int)$r['supplier_invoice_id'],(string)$r['currency'],(float)$r['amount'],(float)($r['transfer_amount']??$r['amount']),json_encode($snap,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$adminId>0?$adminId:null]);
    $id=(int)$pdo->lastInsertId();$v=['id'=>$id,'voucher_number'=>$code,'supplier_payment_id'=>$paymentId,'snapshot_json'=>json_encode($snap)];spaAudit($pdo,'supplier_payment_voucher',$id,'issue',$adminId,[],$v,'Automatic voucher issued after supplier payment.');return $v;
}
function spaRecordPayment(PDO $pdo,int $invoiceId,int $adminId,array $input,array $file=[]):array{
    $s=$pdo->prepare("SELECT * FROM supplier_invoices WHERE id=? AND status='approved' LIMIT 1");$s->execute([$invoiceId]);$inv=$s->fetch(PDO::FETCH_ASSOC);if(!$inv)throw new RuntimeException('Select an approved supplier invoice.');
    $outstanding=spaInvoiceOutstanding($pdo,$inv);$settlement=round(max(0,(float)($input['settlement_amount']??0)),2);if($settlement<=0||$settlement>$outstanding+.01)throw new RuntimeException('Settlement amount must be within the outstanding payable.');
    $tds=round(max(0,(float)($input['tds_amount']??0)),2);$ded=round(max(0,(float)($input['other_deduction']??0)),2);$bank=round(max(0,(float)($input['bank_charge']??0)),2);$transfer=round(max(0,(float)($input['transfer_amount']??($settlement-$tds-$ded))),2);if($transfer+$tds+$ded>$settlement+.01)throw new RuntimeException('Transfer + TDS + deductions cannot exceed the settled amount.');
    $upload=['path'=>null,'name'=>null];if($file && isset($file['error']) && (int)$file['error']!==UPLOAD_ERR_NO_FILE)$upload=tsFinUpload($file,'supplier-payment-proof');
    $base=['supplier_invoice_id'=>$invoiceId,'supplier_payment_amount'=>$settlement,'supplier_payment_date'=>(string)($input['payment_date']??date('Y-m-d')),'supplier_payment_method'=>(string)($input['payment_method']??'bank_transfer'),'supplier_payment_reference'=>(string)($input['reference_number']??''),'supplier_payment_notes'=>(string)($input['notes']??'')];
    $pdo->beginTransaction();try{
        $p=tsFinRecordSupplierPayment($pdo,(int)$inv['booking_id'],$adminId,$base);$paymentId=(int)$p['payment_id'];
        $ins=$pdo->prepare("INSERT INTO supplier_payment_controls(supplier_payment_id,settlement_amount,transfer_amount,tds_amount,other_deduction,bank_charge,proof_path,original_filename,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,NOW(),NOW()) ON DUPLICATE KEY UPDATE settlement_amount=VALUES(settlement_amount),transfer_amount=VALUES(transfer_amount),tds_amount=VALUES(tds_amount),other_deduction=VALUES(other_deduction),bank_charge=VALUES(bank_charge),proof_path=VALUES(proof_path),original_filename=VALUES(original_filename),updated_at=NOW()");$ins->execute([$paymentId,$settlement,$transfer,$tds,$ded,$bank,$upload['path'],$upload['name']]);
        $voucher=spaCreateVoucher($pdo,$paymentId,$adminId);$pdo->commit();
        spaAudit($pdo,'supplier_payment',$paymentId,'record',$adminId,[],['invoice_id'=>$invoiceId,'settlement'=>$settlement,'transfer'=>$transfer,'tds'=>$tds,'deduction'=>$ded,'voucher'=>$voucher['voucher_number']??''],trim((string)($input['notes']??'')));return['payment_id'=>$paymentId,'voucher'=>$voucher,'settlement'=>$settlement,'transfer'=>$transfer];
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}

function spaCreateAdvance(PDO $pdo,int $adminId,array $input,array $file=[]):int{
    if(!spaReady($pdo))throw new RuntimeException('V24.86 Supplier Payables SQL is not installed.');$supplierId=(int)($input['supplier_id']??0);$amount=round(max(0,(float)($input['amount']??0)),2);if($supplierId<=0||$amount<=0)throw new RuntimeException('Supplier and advance amount are required.');
    $upload=['path'=>null,'name'=>null];if($file && isset($file['error']) && (int)$file['error']!==UPLOAD_ERR_NO_FILE)$upload=tsFinUpload($file,'supplier-advance');
    $s=$pdo->prepare("INSERT INTO supplier_advances(supplier_id,booking_id,currency,amount,allocated_amount,advance_date,payment_method,reference_number,status,notes,proof_path,original_filename,created_by_admin_id,created_at,updated_at) VALUES(?,?,?,?,0,?,?,?, 'posted',?,?,?,?,NOW(),NOW())");
    $s->execute([$supplierId,!empty($input['booking_id'])?(int)$input['booking_id']:null,strtoupper(trim((string)($input['currency']??'INR')))?:'INR',$amount,(string)($input['advance_date']??date('Y-m-d')),(string)($input['payment_method']??'bank_transfer'),trim((string)($input['reference_number']??''))?:null,trim((string)($input['notes']??''))?:null,$upload['path'],$upload['name'],$adminId>0?$adminId:null]);$id=(int)$pdo->lastInsertId();spaAudit($pdo,'supplier_advance',$id,'post',$adminId,[],['amount'=>$amount,'supplier_id'=>$supplierId],'Supplier advance posted.');return $id;
}
function spaAllocateAdvance(PDO $pdo,int $advanceId,int $invoiceId,float $amount,int $adminId):void{
    $amount=round(max(0,$amount),2);if($amount<=0)throw new RuntimeException('Allocation amount must be greater than zero.');
    $pdo->beginTransaction();try{$a=$pdo->prepare("SELECT * FROM supplier_advances WHERE id=? AND status='posted' FOR UPDATE");$a->execute([$advanceId]);$adv=$a->fetch(PDO::FETCH_ASSOC);if(!$adv)throw new RuntimeException('Supplier advance not found.');$i=$pdo->prepare("SELECT * FROM supplier_invoices WHERE id=? AND status='approved' FOR UPDATE");$i->execute([$invoiceId]);$inv=$i->fetch(PDO::FETCH_ASSOC);if(!$inv||(int)$inv['supplier_id']!==(int)$adv['supplier_id'])throw new RuntimeException('Advance and invoice must belong to the same supplier.');$available=max(0,(float)$adv['amount']-(float)$adv['allocated_amount']);$out=spaInvoiceOutstanding($pdo,$inv);if($amount>$available+.01||$amount>$out+.01)throw new RuntimeException('Allocation exceeds available advance or invoice outstanding.');$ins=$pdo->prepare("INSERT INTO supplier_advance_allocations(supplier_advance_id,supplier_invoice_id,amount,status,created_by_admin_id,created_at) VALUES(?,?,?,'posted',?,NOW())");$ins->execute([$advanceId,$invoiceId,$amount,$adminId>0?$adminId:null]);$u=$pdo->prepare("UPDATE supplier_advances SET allocated_amount=allocated_amount+?,updated_at=NOW() WHERE id=?");$u->execute([$amount,$advanceId]);$pdo->commit();spaAudit($pdo,'supplier_invoice',$invoiceId,'allocate_advance',$adminId,[],['advance_id'=>$advanceId,'amount'=>$amount],'Supplier advance allocated.');}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function spaCreateAdjustment(PDO $pdo,int $adminId,array $input,array $file=[]):int{
    $supplierId=(int)($input['supplier_id']??0);$invoiceId=!empty($input['supplier_invoice_id'])?(int)$input['supplier_invoice_id']:null;$bookingId=!empty($input['booking_id'])?(int)$input['booking_id']:null;$amount=round(max(0,(float)($input['amount']??0)),2);$type=(string)($input['adjustment_type']??'credit_note');$effect=in_array($type,['debit_adjustment','cancellation_charge'],true)?'increase':'decrease';if($supplierId<=0||$amount<=0)throw new RuntimeException('Supplier and adjustment amount are required.');
    $upload=['path'=>null,'name'=>null];if($file && isset($file['error']) && (int)$file['error']!==UPLOAD_ERR_NO_FILE)$upload=tsFinUpload($file,'supplier-adjustment');$s=$pdo->prepare("INSERT INTO supplier_finance_adjustments(supplier_id,booking_id,supplier_invoice_id,adjustment_type,effect,reference_number,amount,currency,adjustment_date,status,notes,proof_path,original_filename,created_by_admin_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?, ?,?,'posted',?,?,?,?,NOW(),NOW())");$s->execute([$supplierId,$bookingId,$invoiceId,$type,$effect,trim((string)($input['reference_number']??''))?:null,$amount,strtoupper(trim((string)($input['currency']??'INR')))?:'INR',(string)($input['adjustment_date']??date('Y-m-d')),trim((string)($input['notes']??''))?:null,$upload['path'],$upload['name'],$adminId>0?$adminId:null]);$id=(int)$pdo->lastInsertId();spaAudit($pdo,'supplier_adjustment',$id,'post',$adminId,[],['type'=>$type,'effect'=>$effect,'amount'=>$amount],'Supplier finance adjustment posted.');return $id;
}

function spaVoidAdvance(PDO $pdo,int $advanceId,int $adminId,string $reason=''):void{
    $s=$pdo->prepare("SELECT * FROM supplier_advances WHERE id=? AND status='posted' LIMIT 1");$s->execute([$advanceId]);$a=$s->fetch(PDO::FETCH_ASSOC);if(!$a)throw new RuntimeException('Posted supplier advance not found.');if((float)$a['allocated_amount']>.009)throw new RuntimeException('This advance has allocations. Reverse/reconcile the allocations before voiding it.');$u=$pdo->prepare("UPDATE supplier_advances SET status='void',notes=CONCAT(COALESCE(notes,''),?),updated_at=NOW() WHERE id=? AND status='posted'");$u->execute([trim($reason)!==''?"
VOID: ".trim($reason):"
VOIDED",$advanceId]);spaAudit($pdo,'supplier_advance',$advanceId,'void',$adminId,$a,['status'=>'void'],$reason);
}
function spaVoidAdjustment(PDO $pdo,int $adjustmentId,int $adminId,string $reason=''):void{
    $s=$pdo->prepare("SELECT * FROM supplier_finance_adjustments WHERE id=? AND status='posted' LIMIT 1");$s->execute([$adjustmentId]);$a=$s->fetch(PDO::FETCH_ASSOC);if(!$a)throw new RuntimeException('Posted supplier adjustment not found.');$u=$pdo->prepare("UPDATE supplier_finance_adjustments SET status='void',notes=CONCAT(COALESCE(notes,''),?),updated_at=NOW() WHERE id=? AND status='posted'");$u->execute([trim($reason)!==''?"
VOID: ".trim($reason):"
VOIDED",$adjustmentId]);spaAudit($pdo,'supplier_adjustment',$adjustmentId,'void',$adminId,$a,['status'=>'void'],$reason);
}
