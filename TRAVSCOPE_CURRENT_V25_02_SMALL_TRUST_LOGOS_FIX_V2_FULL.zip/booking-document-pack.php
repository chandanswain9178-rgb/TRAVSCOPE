<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/document-functions.php';

$packId =
    max(
        0,
        (int)(
            $_GET['pack']
            ?? 0
        )
    );

if (
    $packId <= 0
    || !tsDocReady($pdo)
) {
    http_response_code(404);
    exit('Trip Document Pack not found.');
}

$pack =
    tsDocPackById(
        $pdo,
        $packId
    );

if (!$pack) {
    http_response_code(404);
    exit('Trip Document Pack not found.');
}

$isAdmin =
    !empty($_SESSION['admin_id']);

$isCurrent =
    tsDocPackIsCurrent(
        $pdo,
        $pack
    );

if (!$isAdmin) {
    requireLogin();

    $user =
        currentUser($pdo);

    if (
        !$user
        || (int)$pack['user_id']
            !== (int)$user['id']
        || (string)$pack['status']
            !== 'final'
        || !$isCurrent
    ) {
        http_response_code(403);
        exit(
            'This Trip Document Pack is not available to your account.'
        );
    }
}

$snapshot =
    json_decode(
        (string)$pack['snapshot_json'],
        true
    );

if (!is_array($snapshot)) {
    http_response_code(500);
    exit('Trip Document Pack snapshot is invalid.');
}

function tdpE(?string $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function tdpDate(?string $value): string
{
    if (!$value) {
        return 'Not set';
    }

    $ts = strtotime($value);

    return
        $ts
            ? date('d M Y', $ts)
            : (string)$value;
}

$siteName =
    getSetting(
        $pdo,
        'site_name',
        'TRAVSCOPE.COM'
    );

$booking =
    is_array(
        $snapshot['booking']
        ?? null
    )
        ? $snapshot['booking']
        : [];

$travellers =
    is_array(
        $snapshot['travellers']
        ?? null
    )
        ? $snapshot['travellers']
        : [];

$documents =
    is_array(
        $snapshot['documents']
        ?? null
    )
        ? $snapshot['documents']
        : [];

$voucher =
    is_array(
        $snapshot['voucher']
        ?? null
    )
        ? $snapshot['voucher']
        : null;

$invoice =
    is_array(
        $snapshot['invoice']
        ?? null
    )
        ? $snapshot['invoice']
        : null;

$docsByTraveller = [];
$groupDocs = [];

foreach ($documents as $document) {
    $travellerId =
        (int)(
            $document['traveller_id']
            ?? 0
        );

    if ($travellerId > 0) {
        $docsByTraveller[$travellerId][] =
            $document;
    } else {
        $groupDocs[] =
            $document;
    }
}

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= tdpE((string)$pack['pack_code']); ?> · Trip Document Pack</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#eef2f7;color:#172033;font-family:Arial,Helvetica,sans-serif}.tools{max-width:900px;margin:14px auto 0;padding:0 12px;display:flex;justify-content:flex-end;gap:7px;flex-wrap:wrap}.tools a,.tools button{display:inline-flex;align-items:center;gap:6px;border:0;border-radius:9px;padding:9px 12px;background:#0f172a;color:#fff;text-decoration:none;font-weight:800;font-size:10px;cursor:pointer}.tools a.green{background:#059669}.sheet{max-width:900px;margin:10px auto 28px;background:#fff;border:1px solid #dbe3ee;border-radius:15px;overflow:hidden;box-shadow:0 14px 35px rgba(15,23,42,.08)}.hero{padding:22px;background:linear-gradient(135deg,#0f172a,#1d4ed8);color:#fff;display:flex;justify-content:space-between;gap:15px}.hero h1{margin:0;font-size:21px}.hero small{display:block;margin-top:5px;color:#bfdbfe}.code{text-align:right}.body{padding:19px}.alert{padding:10px;border-radius:10px;background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;font-size:9px;margin-bottom:12px}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}.box{padding:10px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc}.box span{display:block;color:#64748b;font-size:8px;font-weight:900;text-transform:uppercase}.box strong{display:block;margin-top:4px;font-size:11px}.section{margin-top:17px}.section h2{margin:0 0 8px;font-size:13px;color:#0f172a}.traveller{padding:11px;border:1px solid #e2e8f0;border-radius:11px;margin-bottom:8px}.traveller h3{margin:0;font-size:11px}.traveller small{display:block;margin-top:3px;color:#64748b;font-size:8px}.docs{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;margin-top:8px}.doc{padding:9px;border:1px solid #dbeafe;border-radius:9px;background:#eff6ff}.doc strong{font-size:9px}.doc small{display:block;margin-top:3px;color:#64748b;font-size:8px;line-height:1.45}.doc a{display:inline-block;margin-top:6px;color:#1d4ed8;font-size:8px;font-weight:900;text-decoration:none}.links{display:flex;gap:7px;flex-wrap:wrap}.link{display:inline-flex;padding:9px 11px;border-radius:9px;background:#ecfdf5;border:1px solid #a7f3d0;color:#047857;text-decoration:none;font-size:9px;font-weight:900}.note{margin-top:15px;padding:10px;border-radius:10px;background:#f8fafc;color:#64748b;font-size:9px;line-height:1.55}
@media(max-width:700px){.grid{grid-template-columns:1fr 1fr}.docs{grid-template-columns:1fr}.hero{display:block}.code{text-align:left;margin-top:10px}}
@media print{body{background:#fff}.tools{display:none}.sheet{margin:0;max-width:none;border:0;border-radius:0;box-shadow:none}@page{size:A4;margin:10mm}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>
<body>

<div class="tools">
    <?php if ((string)$pack['status'] === 'final' && ($isAdmin || $isCurrent)): ?>
        <a class="green" href="<?= tdpE(BASE_URL . 'booking-document-pack-download.php?pack=' . (int)$pack['id']); ?>">
            Download Verified Files ZIP
        </a>
    <?php endif; ?>

    <button type="button" onclick="window.print()">Print / Save PDF</button>
</div>

<main class="sheet">
    <header class="hero">
        <div>
            <h1><?= tdpE($siteName); ?></h1>
            <small>Verified Trip Document Pack</small>
        </div>

        <div class="code">
            <strong><?= tdpE((string)$pack['pack_code']); ?></strong>
            <small>
                Version <?= (int)$pack['version_number']; ?>
                · <?= tdpE(strtoupper((string)$pack['status'])); ?>
            </small>
        </div>
    </header>

    <div class="body">
        <?php if ($isAdmin && (string)$pack['status'] === 'final' && !$isCurrent): ?>
            <div class="alert">
                This historical Final Pack is no longer current because traveller documents, requirements or the Final Travel Voucher changed after it was issued.
            </div>
        <?php endif; ?>

        <div class="grid">
            <div class="box"><span>Booking</span><strong><?= tdpE((string)($booking['booking_number'] ?? '')); ?></strong></div>
            <div class="box"><span>Trip ID</span><strong><?= tdpE((string)($booking['trip_code'] ?? '-')); ?></strong></div>
            <div class="box"><span>Customer</span><strong><?= tdpE((string)($booking['customer_name'] ?? '')); ?></strong></div>
            <div class="box"><span>Travel Date</span><strong><?= tdpE(tdpDate($booking['travel_date'] ?? null)); ?></strong></div>
            <div class="box"><span>Destination</span><strong><?= tdpE((string)($booking['destination'] ?? '-')); ?></strong></div>
            <div class="box"><span>Package</span><strong><?= tdpE((string)($booking['package_title'] ?? 'Travel Booking')); ?></strong></div>
            <div class="box"><span>Adults</span><strong><?= (int)($booking['adults'] ?? 0); ?></strong></div>
            <div class="box"><span>Children</span><strong><?= (int)($booking['children'] ?? 0); ?></strong></div>
        </div>

        <section class="section">
            <h2>Traveller Documents</h2>

            <?php foreach ($travellers as $traveller): ?>
                <?php
                $travellerId =
                    (int)(
                        $traveller['id']
                        ?? 0
                    );

                $travellerDocs =
                    $docsByTraveller[
                        $travellerId
                    ]
                    ?? [];
                ?>

                <div class="traveller">
                    <h3><?= tdpE((string)($traveller['full_name'] ?? 'Traveller')); ?></h3>
                    <small>
                        <?= tdpE(ucfirst((string)($traveller['traveller_type'] ?? 'traveller'))); ?>
                        <?php if (!empty($traveller['relationship'])): ?> · <?= tdpE((string)$traveller['relationship']); ?><?php endif; ?>
                        <?php if (!empty($traveller['date_of_birth'])): ?> · DOB <?= tdpE(tdpDate((string)$traveller['date_of_birth'])); ?><?php endif; ?>
                        <?php if (!empty($traveller['nationality'])): ?> · <?= tdpE((string)$traveller['nationality']); ?><?php endif; ?>
                    </small>

                    <?php if ($travellerDocs): ?>
                        <div class="docs">
                            <?php foreach ($travellerDocs as $document): ?>
                                <div class="doc">
                                    <strong><?= tdpE((string)$document['document_type']); ?></strong>
                                    <small>
                                        <?= tdpE((string)($document['document_number_masked'] ?? '')); ?>
                                        <?php if (!empty($document['issuing_country'])): ?> · <?= tdpE((string)$document['issuing_country']); ?><?php endif; ?>
                                        <?php if (!empty($document['expiry_date'])): ?> · Valid until <?= tdpE(tdpDate((string)$document['expiry_date'])); ?><?php endif; ?>
                                    </small>

                                    <a target="_blank" href="<?= tdpE(BASE_URL . 'booking-document-file.php?document=' . (int)$document['id']); ?>">
                                        Open Verified File
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="note">No customer-visible verified file is attached to this traveller in this pack.</div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>

        <?php if ($groupDocs): ?>
            <section class="section">
                <h2>Booking / Group Documents</h2>

                <div class="docs">
                    <?php foreach ($groupDocs as $document): ?>
                        <div class="doc">
                            <strong><?= tdpE((string)$document['document_type']); ?></strong>
                            <small>
                                <?= tdpE((string)($document['document_number_masked'] ?? '')); ?>
                                <?php if (!empty($document['expiry_date'])): ?> · Valid until <?= tdpE(tdpDate((string)$document['expiry_date'])); ?><?php endif; ?>
                            </small>

                            <a target="_blank" href="<?= tdpE(BASE_URL . 'booking-document-file.php?document=' . (int)$document['id']); ?>">
                                Open Verified File
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if ($voucher || $invoice): ?>
            <section class="section">
                <h2>TRAVSCOPE Travel Documents</h2>

                <div class="links">
                    <?php if ($voucher): ?>
                        <a class="link" target="_blank" href="<?= tdpE(BASE_URL . 'booking-voucher.php?voucher=' . (int)$voucher['id']); ?>">
                            Travel Voucher · <?= tdpE((string)$voucher['voucher_code']); ?>
                        </a>
                    <?php endif; ?>

                    <?php if ($invoice): ?>
                        <a class="link" target="_blank" href="<?= tdpE(BASE_URL . 'booking-invoice.php?invoice=' . (int)$invoice['id']); ?>">
                            Final Invoice · <?= tdpE((string)$invoice['invoice_code']); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>

        <div class="note">
            This pack is an immutable manifest of the customer-visible verified documents attached to the Booking when this version was issued. Original files are opened through TRAVSCOPE authorization checks; supplier costs, margins, RFQ data and internal notes are excluded.
        </div>
    </div>
</main>


<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
