<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| PAYMENT PENDING / VERIFICATION PAGE
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';
$billingFunctionsFile = __DIR__ . '/billing-functions.php';
if (is_file($billingFunctionsFile)) require_once $billingFunctionsFile;

$pendingAccessBookingId = (int)($_GET['booking'] ?? 0);
$pendingAccessInstallmentId = max(0, (int)($_GET['installment'] ?? 0));
$pendingAccessExpires = (int)($_GET['expires'] ?? 0);
$pendingAccessToken = trim((string)($_GET['token'] ?? ''));
$paymentLinkAccess = function_exists('tsBillPaymentCollectionTokenValid')
    && tsBillPaymentCollectionTokenValid(
        $pendingAccessBookingId,
        $pendingAccessInstallmentId,
        $pendingAccessExpires,
        $pendingAccessToken
    );



/*
|--------------------------------------------------------------------------
| ACCESS: LOGGED-IN CUSTOMER OR SIGNED PAYMENT LINK
|--------------------------------------------------------------------------
*/
$user = null;
$userId = 0;
if (!$paymentLinkAccess) {
    if (!isLoggedIn()) {
        setFlash('error', 'Please login to view your payment status.');
        redirect(BASE_URL . 'login.php');
    }
    $user = currentUser($pdo);
    if (!$user || strtolower((string)$user['status']) !== 'active') {
        unset($_SESSION['user_id']);
        setFlash('error', 'Please login again.');
        redirect(BASE_URL . 'login.php');
    }
    $userId = (int)$user['id'];
}


/*
|--------------------------------------------------------------------------
| SETTINGS
|--------------------------------------------------------------------------
*/

$siteName = getSetting(
    $pdo,
    'site_name',
    'TRAVSCOPE.COM'
);

$currencySymbol = getSetting(
    $pdo,
    'currency_symbol',
    '₹'
);


/*
|--------------------------------------------------------------------------
| BOOKING ID
|--------------------------------------------------------------------------
*/

$bookingId = (int)(
    $_GET['booking']
    ?? 0
);

if ($bookingId <= 0) {

    setFlash(
        'error',
        'Invalid booking.'
    );

    redirect(BASE_URL . 'dashboard.php');
}


/*
|--------------------------------------------------------------------------
| FETCH BOOKING
|--------------------------------------------------------------------------
|
| user_id check is important:
| A logged-in user cannot view another customer's booking.
|--------------------------------------------------------------------------
*/

$bookingSql = "
    SELECT b.*,p.title AS package_title,p.main_image AS package_image,p.duration_days,p.duration_nights,
           d.name AS destination_name,d.country AS destination_country
    FROM bookings b
    LEFT JOIN packages p ON p.id=b.package_id
    LEFT JOIN destinations d ON d.id=p.destination_id
    WHERE b.id=?";
$bookingParams = [$bookingId];
if (!$paymentLinkAccess) { $bookingSql .= " AND b.user_id=?"; $bookingParams[] = $userId; }
$bookingSql .= " LIMIT 1";
$stmt = $pdo->prepare($bookingSql);
$stmt->execute($bookingParams);
$booking = $stmt->fetch();

if (!$booking) {

    http_response_code(404);

    exit(
        'Booking not found or you do not have permission to view it.'
    );
}


/*
|--------------------------------------------------------------------------
| BOOKING ALREADY PAID
|--------------------------------------------------------------------------
*/

if (
    strtolower((string)$booking['payment_status']) === 'paid'
    && !$paymentLinkAccess
) {
    redirect(BASE_URL . 'booking-success.php?booking=' . $bookingId);
}


/*
|--------------------------------------------------------------------------
| GET LATEST PAYMENT
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM payments

    WHERE booking_id = ?

    ORDER BY id DESC

    LIMIT 1
");

$stmt->execute([
    $bookingId
]);

$payment = $stmt->fetch();


/*
|--------------------------------------------------------------------------
| NO PAYMENT FOUND
|--------------------------------------------------------------------------
*/

if (!$payment) {
    $backUrl = BASE_URL . 'payment.php?booking=' . $bookingId;
    if ($paymentLinkAccess) {
        $backUrl .= '&installment=' . $pendingAccessInstallmentId
            . '&expires=' . $pendingAccessExpires
            . '&token=' . rawurlencode($pendingAccessToken);
    }
    redirect($backUrl);
}


/*
|--------------------------------------------------------------------------
| PAYMENT STATUS
|--------------------------------------------------------------------------
*/

$paymentStatus =
    strtolower(
        (string)$payment['status']
    );


/*
|--------------------------------------------------------------------------
| SUCCESSFUL PAYMENT
|--------------------------------------------------------------------------
|
| Normally admin-payments.php also changes booking.payment_status
| to paid.
|
| This additional check makes the flow more reliable.
|--------------------------------------------------------------------------
*/

if ($paymentStatus === 'success') {

    /*
    | Reload booking in case admin just approved it.
    */

    $statusSql = "SELECT payment_status FROM bookings WHERE id=?";
    $statusParams = [$bookingId];
    if (!$paymentLinkAccess) { $statusSql .= " AND user_id=?"; $statusParams[] = $userId; }
    $statusSql .= " LIMIT 1";
    $stmt = $pdo->prepare($statusSql);
    $stmt->execute($statusParams);
    $latestBookingStatus = strtolower((string)$stmt->fetchColumn());

    if ($latestBookingStatus === 'paid' && !$paymentLinkAccess) {
        redirect(BASE_URL . 'booking-success.php?booking=' . $bookingId);
    }
}


/*
|--------------------------------------------------------------------------
| VALUES
|--------------------------------------------------------------------------
*/

$totalAmount =
    (float)$booking['total_amount'];

$paidAmount =
    (float)$booking['paid_amount'];

$remainingAmount =
    max(
        0,
        $totalAmount - $paidAmount
    );


/*
|--------------------------------------------------------------------------
| USER NAME
|--------------------------------------------------------------------------
*/

$firstName = trim(
    (string)$user['full_name']
);

if ($firstName !== '') {

    $parts =
        preg_split(
            '/\s+/',
            $firstName
        );

    $firstName =
        $parts[0] ?? 'Traveller';

} else {

    $firstName =
        'Traveller';
}


/*
|--------------------------------------------------------------------------
| PAYMENT STATUS CONFIGURATION
|--------------------------------------------------------------------------
*/

if ($paymentStatus === 'failed') {

    $statusIcon =
        'fa-circle-xmark';

    $statusClass =
        'failed';

    $statusTitle =
        'Payment verification failed';

    $statusText =
        'We could not verify the submitted transaction. Please check your payment details and submit a valid transaction reference.';

} elseif ($paymentStatus === 'refunded') {

    $statusIcon =
        'fa-arrow-rotate-left';

    $statusClass =
        'refunded';

    $statusTitle =
        'Payment refunded';

    $statusText =
        'This payment has been marked as refunded. Please contact TRAVSCOPE support if you need assistance.';

} elseif ($paymentStatus === 'success') {

    $statusIcon =
        'fa-circle-check';

    $statusClass =
        'success';

    $statusTitle =
        'Payment verified';

    $statusText =
        'Your payment has been successfully verified. Your booking information is being updated.';

} else {

    $statusIcon =
        'fa-clock';

    $statusClass =
        'pending';

    $statusTitle =
        'Payment submitted successfully';

    $statusText =
        'We received your payment reference. Our team will verify the transaction before confirming your booking.';
}


/*
|--------------------------------------------------------------------------
| AUTO REFRESH
|--------------------------------------------------------------------------
|
| Only pending pages refresh.
| Once admin approves, the page will automatically redirect
| to booking-success.php.
|--------------------------------------------------------------------------
*/

$autoRefresh =
    $paymentStatus === 'pending';

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#07192d"
>

<?php if ($autoRefresh): ?>

<meta
    http-equiv="refresh"
    content="15"
>

<?php endif; ?>

<title>
Payment Status |
<?= e($booking['booking_number']); ?>
| <?= e($siteName); ?>
</title>


<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

:root {

    --navy:#07192d;
    --navy2:#0d2a48;

    --blue:#0b74ff;
    --blue-dark:#075fd2;

    --green:#07966a;
    --orange:#e28a16;
    --red:#db4255;
    --purple:#7358ce;

    --background:#f5f7fa;
    --white:#ffffff;

    --text:#172235;
    --muted:#788496;

    --border:#e3e8ee;

    --shadow:
        0 20px 60px
        rgba(7,25,45,.10);
}


* {

    margin:0;
    padding:0;
    box-sizing:border-box;
}


body {

    min-height:100vh;

    background:
        linear-gradient(
            180deg,
            #f7faff 0,
            #f5f7fa 350px
        );

    color:var(--text);

    font-family:
        'DM Sans',
        sans-serif;
}


a {

    color:inherit;
    text-decoration:none;
}


/* =========================================================
   HEADER
========================================================= */

.header {

    height:74px;

    padding:0 5%;

    display:flex;
    align-items:center;
    justify-content:space-between;

    background:white;

    border-bottom:
        1px solid
        var(--border);
}


.logo {

    display:flex;
    align-items:center;

    gap:10px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:20px;
    font-weight:800;
}


.logo-icon {

    width:40px;
    height:40px;

    border-radius:12px;

    display:grid;
    place-items:center;

    color:white;

    background:
        linear-gradient(
            135deg,
            #0b74ff,
            #00b8ff
        );
}


.logo span {

    color:var(--blue);
}


.secure {

    display:flex;
    align-items:center;

    gap:7px;

    color:#687587;

    font-size:10px;
    font-weight:700;
}


.secure i {

    color:var(--green);
}


/* =========================================================
   PROGRESS
========================================================= */

.progress-wrap {

    background:white;

    border-bottom:
        1px solid
        var(--border);
}


.progress {

    min-height:70px;

    display:flex;
    align-items:center;
    justify-content:center;
}


.step {

    display:flex;
    align-items:center;

    gap:7px;

    color:#9ba5b2;

    font-size:9px;
    font-weight:700;
}


.step-circle {

    width:28px;
    height:28px;

    border-radius:50%;

    display:grid;
    place-items:center;

    background:#edf1f5;
}


.step.done {

    color:var(--green);
}


.step.done .step-circle {

    background:var(--green);

    color:white;
}


.step.active {

    color:var(--orange);
}


.step.active .step-circle {

    background:#fff2dd;

    color:var(--orange);
}


.step-line {

    width:70px;
    height:1px;

    margin:0 10px;

    background:#dce2e8;
}


/* =========================================================
   MAIN
========================================================= */

.container {

    max-width:1060px;

    margin:auto;

    padding:
        45px 20px
        70px;
}


.layout {

    display:grid;

    grid-template-columns:
        minmax(0,1fr)
        340px;

    gap:24px;
}


/* =========================================================
   STATUS CARD
========================================================= */

.status-card {

    padding:38px;

    border:
        1px solid
        var(--border);

    border-radius:18px;

    background:white;

    box-shadow:var(--shadow);

    text-align:center;
}


.status-icon {

    width:82px;
    height:82px;

    margin:
        0 auto
        20px;

    border-radius:50%;

    display:grid;
    place-items:center;

    font-size:31px;
}


.status-card.pending
.status-icon {

    background:#fff5e6;

    color:var(--orange);
}


.status-card.failed
.status-icon {

    background:#ffedef;

    color:var(--red);
}


.status-card.success
.status-icon {

    background:#e9faf3;

    color:var(--green);
}


.status-card.refunded
.status-icon {

    background:#f1edff;

    color:var(--purple);
}


.status-card h1 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:27px;

    line-height:1.3;
}


.status-message {

    max-width:560px;

    margin:
        10px auto
        0;

    color:var(--muted);

    font-size:11px;

    line-height:1.8;
}


.hello {

    margin-top:18px;

    color:#667487;

    font-size:10px;
}


/* =========================================================
   PENDING ANIMATION
========================================================= */

.pending-animation {

    width:9px;
    height:9px;

    margin-left:5px;

    border-radius:50%;

    display:inline-block;

    background:var(--orange);

    animation:
        pulse 1.4s
        infinite;
}


@keyframes pulse {

    0% {

        opacity:.3;

        transform:
            scale(.8);
    }

    50% {

        opacity:1;

        transform:
            scale(1.2);
    }

    100% {

        opacity:.3;

        transform:
            scale(.8);
    }
}


/* =========================================================
   DETAILS
========================================================= */

.details {

    margin-top:27px;

    padding:20px;

    border-radius:13px;

    background:#f7f9fc;

    text-align:left;
}


.detail-row {

    min-height:45px;

    padding:10px 0;

    border-bottom:
        1px solid
        #e5eaf0;

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:20px;
}


.detail-row:last-child {

    border-bottom:0;
}


.detail-row span {

    color:#7b8797;

    font-size:9px;
}


.detail-row strong {

    color:var(--navy);

    text-align:right;

    font-size:10px;

    word-break:break-word;
}


.transaction {

    font-family:monospace;

    color:var(--blue) !important;
}


/* =========================================================
   VERIFICATION
========================================================= */

.verification {

    margin-top:22px;

    padding:17px;

    border:
        1px solid
        #f2ddb8;

    border-radius:11px;

    display:flex;
    align-items:flex-start;

    gap:11px;

    background:#fff9ee;

    text-align:left;
}


.verification i {

    margin-top:2px;

    color:var(--orange);
}


.verification strong {

    display:block;

    color:#72501a;

    font-size:10px;
}


.verification p {

    margin-top:4px;

    color:#8b6d3a;

    font-size:9px;

    line-height:1.6;
}


/* =========================================================
   BUTTONS
========================================================= */

.actions {

    margin-top:25px;

    display:flex;
    justify-content:center;

    gap:10px;

    flex-wrap:wrap;
}


.btn {

    min-height:47px;

    padding:0 20px;

    border-radius:9px;

    display:inline-flex;
    align-items:center;
    justify-content:center;

    gap:7px;

    font-size:10px;
    font-weight:800;

    transition:.2s;
}


.btn-primary {

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--blue-dark)
        );

    color:white;

    box-shadow:
        0 9px 24px
        rgba(11,116,255,.20);
}


.btn-secondary {

    border:
        1px solid
        var(--border);

    background:white;

    color:#5f6d80;
}


.btn-danger {

    background:var(--red);

    color:white;
}


.btn:hover {

    transform:
        translateY(-1px);
}


/* =========================================================
   SUMMARY
========================================================= */

.summary {

    overflow:hidden;

    border:
        1px solid
        var(--border);

    border-radius:16px;

    background:white;

    box-shadow:
        0 12px 40px
        rgba(7,25,45,.07);
}


.summary-image {

    height:175px;

    position:relative;

    overflow:hidden;

    background:
        linear-gradient(
            135deg,
            #102c4b,
            #0b74ff
        );
}


.summary-image img {

    width:100%;
    height:100%;

    object-fit:cover;
}


.summary-overlay {

    position:absolute;

    inset:0;

    background:
        linear-gradient(
            transparent,
            rgba(7,25,45,.55)
        );
}


.summary-ref {

    position:absolute;

    left:15px;
    bottom:13px;

    padding:
        5px 8px;

    border-radius:5px;

    background:
        rgba(255,255,255,.92);

    color:var(--navy);

    font-size:8px;
    font-weight:800;
}


.summary-body {

    padding:20px;
}


.summary-body h2 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:17px;

    line-height:1.4;
}


.destination {

    margin-top:6px;

    color:#7c8898;

    font-size:9px;
}


.destination i {

    margin-right:3px;

    color:var(--blue);
}


.summary-list {

    margin-top:17px;
}


.summary-row {

    padding:9px 0;

    border-top:
        1px solid
        #edf0f3;

    display:flex;
    justify-content:space-between;

    gap:15px;

    font-size:9px;
}


.summary-row span {

    color:#8290a0;
}


.summary-row strong {

    color:var(--navy);

    text-align:right;
}


.amount-box {

    margin-top:12px;

    padding:14px;

    border-radius:9px;

    background:#f5f8fb;
}


.amount-line {

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:15px;
}


.amount-line span {

    color:#69778a;

    font-size:9px;
}


.amount-line strong {

    color:var(--blue);

    font-family:
        'Manrope',
        sans-serif;

    font-size:18px;
}


/* =========================================================
   SECURITY
========================================================= */

.security {

    margin-top:15px;

    padding:12px;

    border-radius:9px;

    display:flex;
    align-items:flex-start;

    gap:8px;

    background:#edf9f4;

    color:#28745a;

    font-size:8px;

    line-height:1.5;
}


.security i {

    margin-top:2px;

    color:var(--green);
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:850px) {

    .layout {

        grid-template-columns:1fr;
    }
}


@media(max-width:600px) {

    .header {

        height:65px;

        padding:0 14px;
    }


    .logo {

        font-size:17px;
    }


    .secure span {

        display:none;
    }


    .container {

        padding:
            27px 13px
            50px;
    }


    .status-card {

        padding:
            28px 17px;
    }


    .status-card h1 {

        font-size:22px;
    }


    .step span {

        display:none;
    }


    .step-line {

        width:38px;
    }


    .detail-row {

        align-items:flex-start;

        flex-direction:column;

        gap:4px;
    }


    .detail-row strong {

        text-align:left;
    }


    .actions {

        flex-direction:column;
    }


    .btn {

        width:100%;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-public-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="public"></script>
</head>

<body>


<!-- =========================================================
     HEADER
========================================================= -->

<header class="header">


<a
    href="<?= e(BASE_URL); ?>"
    class="logo"
>

    <div class="logo-icon">

        <i class="fa-solid fa-plane"></i>

    </div>

    TRAV<span>SCOPE</span>

</a>


<div class="secure">

    <i class="fa-solid fa-shield-halved"></i>

    <span>
        Secure Booking
    </span>

</div>


</header>


<!-- =========================================================
     PROGRESS
========================================================= -->

<div class="progress-wrap">

<div class="progress">


    <div class="step done">

        <div class="step-circle">

            <i class="fa-solid fa-check"></i>

        </div>

        <span>
            Traveller Details
        </span>

    </div>


    <div class="step-line"></div>


    <div class="step done">

        <div class="step-circle">

            <i class="fa-solid fa-check"></i>

        </div>

        <span>
            Payment
        </span>

    </div>


    <div class="step-line"></div>


    <div
        class="step
        <?= $paymentStatus === 'success'
            ? 'done'
            : 'active'; ?>"
    >

        <div class="step-circle">

            <?php if (
                $paymentStatus === 'success'
            ): ?>

                <i class="fa-solid fa-check"></i>

            <?php else: ?>

                3

            <?php endif; ?>

        </div>

        <span>
            Verification
        </span>

    </div>


</div>

</div>


<!-- =========================================================
     CONTENT
========================================================= -->

<main class="container">


<div class="layout">


<!-- =========================================================
     STATUS
========================================================= -->

<section
    class="status-card
    <?= e($statusClass); ?>"
>


    <div class="status-icon">

        <i
            class="fa-solid
            <?= e($statusIcon); ?>"
        ></i>

    </div>


    <h1>

        <?= e($statusTitle); ?>

        <?php if (
            $paymentStatus === 'pending'
        ): ?>

            <span
                class="pending-animation"
            ></span>

        <?php endif; ?>

    </h1>


    <p class="status-message">

        <?= e($statusText); ?>

    </p>


    <div class="hello">

        Hi <?= e($firstName); ?>,
        your booking reference is

        <strong>
            <?= e(
                $booking['booking_number']
            ); ?>
        </strong>.

    </div>


    <!-- PAYMENT DETAILS -->

    <div class="details">


        <div class="detail-row">

            <span>
                Booking Number
            </span>

            <strong>

                <?= e(
                    $booking['booking_number']
                ); ?>

            </strong>

        </div>


        <div class="detail-row">

            <span>
                Transaction ID / UTR
            </span>

            <strong class="transaction">

                <?= e(
                    $payment['transaction_id']
                    ?: '-'
                ); ?>

            </strong>

        </div>


        <div class="detail-row">

            <span>
                Payment Method
            </span>

            <strong>

                <?= e(
                    $payment['payment_method']
                    ?: 'Manual Payment'
                ); ?>

            </strong>

        </div>


        <div class="detail-row">

            <span>
                Submitted Amount
            </span>

            <strong>

                <?= e($currencySymbol); ?>

                <?= number_format(
                    (float)$payment['amount'],
                    2
                ); ?>

            </strong>

        </div>


        <div class="detail-row">

            <span>
                Payment Status
            </span>

            <strong>

                <?= e(
                    strtoupper(
                        $paymentStatus
                    )
                ); ?>

            </strong>

        </div>


        <div class="detail-row">

            <span>
                Submitted On
            </span>

            <strong>

                <?= date(
                    'd M Y, h:i A',
                    strtotime(
                        $payment['created_at']
                    )
                ); ?>

            </strong>

        </div>


    </div>


    <?php if (
        $paymentStatus === 'pending'
    ): ?>


        <div class="verification">

            <i class="fa-solid fa-circle-info"></i>

            <div>

                <strong>
                    Verification in progress
                </strong>

                <p>
                    Please do not make another payment for this booking while this transaction is under verification. This page automatically checks for updates.
                </p>

            </div>

        </div>


    <?php elseif (
        $paymentStatus === 'failed'
    ): ?>


        <div class="verification">

            <i class="fa-solid fa-triangle-exclamation"></i>

            <div>

                <strong>
                    Transaction not verified
                </strong>

                <p>
                    If money was actually deducted, check the transaction reference carefully before submitting again or contact TRAVSCOPE support.
                </p>

            </div>

        </div>


    <?php endif; ?>


    <!-- ACTIONS -->

    <div class="actions">


        <?php if (
            $paymentStatus === 'failed'
        ): ?>


            <a
                href="<?= e(
                    BASE_URL
                    . 'payment.php?booking='
                    . $bookingId
                ); ?>"
                class="btn btn-primary"
            >

                <i class="fa-solid fa-rotate-right"></i>

                Submit Payment Again

            </a>


        <?php elseif (
            $paymentStatus === 'success'
        ): ?>


            <a
                href="<?= e(
                    BASE_URL
                    . 'booking-success.php?booking='
                    . $bookingId
                ); ?>"
                class="btn btn-primary"
            >

                <i class="fa-solid fa-circle-check"></i>

                View Booking Confirmation

            </a>


        <?php else: ?>


            <a
                href="<?= e(
                    BASE_URL
                    . 'payment-pending.php?booking='
                    . $bookingId
                ); ?>"
                class="btn btn-primary"
            >

                <i class="fa-solid fa-rotate"></i>

                Check Status

            </a>


        <?php endif; ?>


        <a
            href="<?= e(
                BASE_URL
                . 'dashboard.php'
            ); ?>"
            class="btn btn-secondary"
        >

            <i class="fa-solid fa-house"></i>

            Go to Dashboard

        </a>


    </div>


</section>


<!-- =========================================================
     BOOKING SUMMARY
========================================================= -->

<aside>


<div class="summary">


    <div class="summary-image">


        <?php if (
            !empty(
                $booking['package_image']
            )
        ): ?>


            <?php

            $packageImage =
                trim(
                    (string)$booking['package_image']
                );

            if (
                !preg_match(
                    '#^https?://#i',
                    $packageImage
                )
            ) {

                $packageImage =
                    BASE_URL
                    . ltrim(
                        $packageImage,
                        '/'
                    );
            }

            ?>


            <img
                src="<?= e($packageImage); ?>"
                alt="<?= e(
                    $booking['package_title']
                    ?: 'Travel Package'
                ); ?>"
            >


            <div
                class="summary-overlay"
            ></div>


        <?php endif; ?>


        <div class="summary-ref">

            <?= e(
                $booking['booking_number']
            ); ?>

        </div>


    </div>


    <div class="summary-body">


        <h2>

            <?= e(
                $booking['package_title']
                ?: 'Travel Package'
            ); ?>

        </h2>


        <div class="destination">

            <i class="fa-solid fa-location-dot"></i>

            <?= e(
                $booking['destination_name']
                ?: 'Destination'
            ); ?>


            <?php if (
                !empty(
                    $booking['destination_country']
                )
            ): ?>

                ,
                <?= e(
                    $booking['destination_country']
                ); ?>

            <?php endif; ?>

        </div>


        <div class="summary-list">


            <div class="summary-row">

                <span>
                    Travel Date
                </span>

                <strong>

                    <?= !empty(
                        $booking['travel_date']
                    )
                    ? e(
                        date(
                            'd M Y',
                            strtotime(
                                $booking['travel_date']
                            )
                        )
                    )
                    : '-'; ?>

                </strong>

            </div>


            <div class="summary-row">

                <span>
                    Duration
                </span>

                <strong>

                    <?= (int)$booking['duration_days']; ?>
                    Days /

                    <?= (int)$booking['duration_nights']; ?>
                    Nights

                </strong>

            </div>


            <div class="summary-row">

                <span>
                    Travellers
                </span>

                <strong>

                    <?= (int)$booking['adults']; ?>
                    Adult<?= (int)$booking['adults'] !== 1 ? 's' : ''; ?>

                    <?php if (
                        (int)$booking['children'] > 0
                    ): ?>

                        +
                        <?= (int)$booking['children']; ?>
                        Child<?= (int)$booking['children'] !== 1 ? 'ren' : ''; ?>

                    <?php endif; ?>

                </strong>

            </div>


            <div class="summary-row">

                <span>
                    Booking Status
                </span>

                <strong>

                    <?= e(
                        ucfirst(
                            $booking['booking_status']
                        )
                    ); ?>

                </strong>

            </div>


        </div>


        <div class="amount-box">


            <div class="amount-line">

                <span>
                    Booking Total
                </span>

                <strong>

                    <?= e($currencySymbol); ?>

                    <?= number_format(
                        $totalAmount,
                        2
                    ); ?>

                </strong>

            </div>


        </div>


        <div class="security">

            <i class="fa-solid fa-shield-halved"></i>

            <div>
                Your payment submission is linked securely to your TRAVSCOPE account and booking.
            </div>

        </div>


    </div>


</div>


</aside>


</div>


</main>



<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>