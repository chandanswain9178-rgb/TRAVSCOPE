<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . BASE_URL . 'login.php');
    exit;
}

$adminId = (int)$_SESSION['admin_id'];

$stmt = $pdo->prepare("SELECT id,name,email,role,status FROM admins WHERE id=? LIMIT 1");
$stmt->execute([$adminId]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin || ($admin['status'] ?? '') !== 'active') {
    unset($_SESSION['admin_id']);
    header('Location: ' . BASE_URL . 'login.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| TRAVSCOPE GEO LOCATION SELECTOR
| Country -> State -> City dropdown helper for Add Supplier.
| Supplier database fields remain: country, state_region, city.
|--------------------------------------------------------------------------
*/

function supplierGeoApiRequest(string $url, ?array $payload = null): array
{
    if (!function_exists('curl_init')) {
        throw new RuntimeException('PHP cURL is required for automatic location selection.');
    }

    $curl = curl_init($url);

    $options = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Content-Type: application/json'
        ],
        CURLOPT_USERAGENT => 'TRAVSCOPE Supplier Geo Selector'
    ];

    if ($payload !== null) {
        $options[CURLOPT_POST] = true;
        $options[CURLOPT_POSTFIELDS] = json_encode($payload, JSON_UNESCAPED_UNICODE);
    }

    curl_setopt_array($curl, $options);

    $response = curl_exec($curl);
    $status = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $curlError = curl_error($curl);
    curl_close($curl);

    if ($response === false || $status < 200 || $status >= 300) {
        throw new RuntimeException(
            $curlError !== ''
                ? 'Location service error: ' . $curlError
                : 'Unable to load location data.'
        );
    }

    $decoded = json_decode((string)$response, true);

    if (!is_array($decoded) || !empty($decoded['error'])) {
        throw new RuntimeException(
            is_array($decoded) && !empty($decoded['msg'])
                ? (string)$decoded['msg']
                : 'Invalid location service response.'
        );
    }

    return $decoded;
}

function supplierGeoCountryStateData(): array
{
    $cacheFile = sys_get_temp_dir() . '/travscope_geo_country_states_v1.json';

    if (
        is_file($cacheFile)
        && (time() - (int)@filemtime($cacheFile)) < 86400
    ) {
        $cached = json_decode((string)@file_get_contents($cacheFile), true);

        if (is_array($cached) && !empty($cached)) {
            return $cached;
        }
    }

    $response = supplierGeoApiRequest(
        'https://countriesnow.space/api/v0.1/countries/states'
    );

    $data = is_array($response['data'] ?? null)
        ? $response['data']
        : [];

    if (!$data) {
        throw new RuntimeException('No country/state information was returned.');
    }

    @file_put_contents(
        $cacheFile,
        json_encode($data, JSON_UNESCAPED_UNICODE)
    );

    return $data;
}

if (isset($_GET['geo_ajax'])) {
    header('Content-Type: application/json; charset=utf-8');

    try {
        $geoAction = trim((string)$_GET['geo_ajax']);

        if ($geoAction === 'countries') {
            $countries = [];

            foreach (supplierGeoCountryStateData() as $row) {
                $name = trim((string)($row['name'] ?? ''));

                if ($name !== '') {
                    $countries[] = $name;
                }
            }

            $countries = array_values(array_unique($countries));
            natcasesort($countries);

            echo json_encode([
                'success' => true,
                'data' => array_values($countries)
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($geoAction === 'states') {
            $country = trim((string)($_GET['country'] ?? ''));

            if ($country === '') {
                throw new RuntimeException('Country is required.');
            }

            $states = [];

            foreach (supplierGeoCountryStateData() as $row) {
                if (strcasecmp(trim((string)($row['name'] ?? '')), $country) !== 0) {
                    continue;
                }

                foreach (($row['states'] ?? []) as $state) {
                    $name = trim((string)($state['name'] ?? ''));

                    if ($name !== '') {
                        $states[] = $name;
                    }
                }

                break;
            }

            $states = array_values(array_unique($states));
            natcasesort($states);

            echo json_encode([
                'success' => true,
                'data' => array_values($states)
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($geoAction === 'cities') {
            $country = trim((string)($_GET['country'] ?? ''));
            $state = trim((string)($_GET['state'] ?? ''));

            if ($country === '' || $state === '') {
                throw new RuntimeException('Country and state are required.');
            }

            $response = supplierGeoApiRequest(
                'https://countriesnow.space/api/v0.1/countries/state/cities',
                [
                    'country' => $country,
                    'state' => $state
                ]
            );

            $cities = is_array($response['data'] ?? null)
                ? $response['data']
                : [];

            $cities = array_values(array_unique(array_filter(
                array_map(
                    static fn($value): string => trim((string)$value),
                    $cities
                ),
                static fn(string $value): bool => $value !== ''
            )));

            natcasesort($cities);

            echo json_encode([
                'success' => true,
                'data' => array_values($cities)
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        throw new RuntimeException('Invalid location request.');

    } catch (Throwable $e) {
        http_response_code(422);

        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}


function supplierE(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function supplierCode(PDO $pdo): string {
    $year = date('Y');
    $stmt = $pdo->query("SELECT COALESCE(MAX(id),0)+1 FROM suppliers");
    $next = (int)$stmt->fetchColumn();
    return 'SUP-' . $year . '-' . str_pad((string)$next, 5, '0', STR_PAD_LEFT);
}

if (empty($_SESSION['supplier_csrf'])) {
    $_SESSION['supplier_csrf'] = bin2hex(random_bytes(32));
}
$csrf = (string)$_SESSION['supplier_csrf'];

$success = (string)($_SESSION['supplier_success'] ?? '');
$error = (string)($_SESSION['supplier_error'] ?? '');
unset($_SESSION['supplier_success'], $_SESSION['supplier_error']);

// Professional supplier add uses REAL master-data IDs.
// This prevents spelling errors in destination/service capability.
$destinationOptions = $pdo->query("
    SELECT id,name,country
    FROM destinations
    WHERE status='active'
    ORDER BY country,name
")->fetchAll(PDO::FETCH_ASSOC) ?: [];

$serviceOptions = $pdo->query("
    SELECT id,service_name
    FROM supplier_service_types
    WHERE active=1
    ORDER BY sort_order,service_name
")->fetchAll(PDO::FETCH_ASSOC) ?: [];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) {
            throw new RuntimeException('Security verification failed.');
        }

        $action = trim((string)($_POST['action'] ?? ''));

        if ($action === 'save_supplier') {
            $id = max(0, (int)($_POST['id'] ?? 0));
            $company = trim((string)($_POST['company_name'] ?? ''));
            if ($company === '') {
                throw new RuntimeException('Supplier company name is required.');
            }

            $type = trim((string)($_POST['supplier_type'] ?? ''));
            $legal = trim((string)($_POST['legal_name'] ?? ''));
            $gstin = strtoupper(trim((string)($_POST['gstin'] ?? '')));
            $taxId = trim((string)($_POST['tax_id'] ?? ''));
            $website = trim((string)($_POST['website'] ?? ''));
            $country = trim((string)($_POST['country'] ?? ''));
            $state = trim((string)($_POST['state_region'] ?? ''));
            $city = trim((string)($_POST['city'] ?? ''));
            $address = trim((string)($_POST['address'] ?? ''));
            $currency = strtoupper(trim((string)($_POST['default_currency'] ?? 'INR')));
            $priority = trim((string)($_POST['priority'] ?? 'regular'));
            $ratingRaw = trim((string)($_POST['internal_rating'] ?? ''));
            $rating = $ratingRaw === '' ? null : max(0, min(5, (float)$ratingRaw));
            $payment = trim((string)($_POST['payment_terms'] ?? ''));
            $cancel = trim((string)($_POST['cancellation_terms'] ?? ''));
            $notes = trim((string)($_POST['notes'] ?? ''));
            $status = in_array((string)($_POST['status'] ?? ''), ['active','inactive'], true)
                ? (string)$_POST['status'] : 'active';

            if (!in_array($priority, ['preferred','regular','backup'], true)) {
                $priority = 'regular';
            }

            if ($id > 0) {
                $stmt = $pdo->prepare("
                    UPDATE suppliers SET
                        company_name=?, supplier_type=?, legal_name=?, gstin=?, tax_id=?,
                        website=?, country=?, state_region=?, city=?, address=?,
                        default_currency=?, priority=?, internal_rating=?,
                        payment_terms=?, cancellation_terms=?, notes=?, status=?,
                        updated_by_admin_id=?
                    WHERE id=?
                ");
                $stmt->execute([
                    $company,$type ?: null,$legal ?: null,$gstin ?: null,$taxId ?: null,
                    $website ?: null,$country ?: null,$state ?: null,$city ?: null,$address ?: null,
                    $currency ?: 'INR',$priority,$rating,$payment ?: null,$cancel ?: null,$notes ?: null,
                    $status,$adminId,$id
                ]);
                $_SESSION['supplier_success'] = 'Supplier updated successfully.';
            } else {
                $destinationIds = array_values(array_unique(array_filter(
                    array_map('intval', (array)($_POST['destination_ids'] ?? []))
                )));
                $serviceIds = array_values(array_unique(array_filter(
                    array_map('intval', (array)($_POST['service_ids'] ?? []))
                )));

                if (!$destinationIds) {
                    throw new RuntimeException('Select at least one destination this supplier handles.');
                }

                if (!$serviceIds) {
                    throw new RuntimeException('Select at least one service this supplier provides.');
                }

                $contactName = trim((string)($_POST['primary_contact_name'] ?? ''));
                $contactMobile = trim((string)($_POST['primary_contact_mobile'] ?? ''));
                $contactWhatsapp = trim((string)($_POST['primary_contact_whatsapp'] ?? ''));
                $contactEmail = strtolower(trim((string)($_POST['primary_contact_email'] ?? '')));

                if ($contactName === '') {
                    throw new RuntimeException('Primary supplier contact name is required.');
                }

                if ($contactEmail !== '' && !filter_var($contactEmail, FILTER_VALIDATE_EMAIL)) {
                    throw new RuntimeException('Enter a valid supplier email address.');
                }

                $pdo->beginTransaction();

                $code = supplierCode($pdo);
                $stmt = $pdo->prepare("
                    INSERT INTO suppliers
                    (supplier_code,company_name,supplier_type,legal_name,gstin,tax_id,website,
                     country,state_region,city,address,default_currency,priority,internal_rating,
                     payment_terms,cancellation_terms,notes,status,created_by_admin_id,updated_by_admin_id)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ");
                $stmt->execute([
                    $code,$company,$type ?: null,$legal ?: null,$gstin ?: null,$taxId ?: null,$website ?: null,
                    $country ?: null,$state ?: null,$city ?: null,$address ?: null,$currency ?: 'INR',
                    $priority,$rating,$payment ?: null,$cancel ?: null,$notes ?: null,$status,$adminId,$adminId
                ]);
                $id = (int)$pdo->lastInsertId();

                $stmt = $pdo->prepare("
                    INSERT INTO supplier_contacts
                    (supplier_id,contact_name,department,mobile,whatsapp,email,is_primary,status)
                    VALUES (?,?,'Sales',?,?,?,1,'active')
                ");
                $stmt->execute([
                    $id,
                    $contactName,
                    $contactMobile !== '' ? $contactMobile : null,
                    $contactWhatsapp !== '' ? $contactWhatsapp : null,
                    $contactEmail !== '' ? $contactEmail : null
                ]);

                $checkDestination = $pdo->prepare("
                    SELECT id FROM destinations WHERE id=? AND status='active' LIMIT 1
                ");
                $insertDestination = $pdo->prepare("
                    INSERT IGNORE INTO supplier_destinations (supplier_id,destination_id)
                    VALUES (?,?)
                ");
                foreach ($destinationIds as $destinationId) {
                    $checkDestination->execute([$destinationId]);
                    if ($checkDestination->fetchColumn()) {
                        $insertDestination->execute([$id,$destinationId]);
                    }
                }

                $checkService = $pdo->prepare("
                    SELECT id FROM supplier_service_types WHERE id=? AND active=1 LIMIT 1
                ");
                $insertService = $pdo->prepare("
                    INSERT IGNORE INTO supplier_services (supplier_id,service_type_id)
                    VALUES (?,?)
                ");
                foreach ($serviceIds as $serviceId) {
                    $checkService->execute([$serviceId]);
                    if ($checkService->fetchColumn()) {
                        $insertService->execute([$id,$serviceId]);
                    }
                }

                $pdo->commit();

                $_SESSION['supplier_success'] = 'Supplier created with contact, destinations and services.';
                header('Location: admin-supplier-details.php?id=' . $id);
                exit;
            }
        }

        if ($action === 'toggle_status') {
            $id = max(0, (int)($_POST['id'] ?? 0));
            $stmt = $pdo->prepare("
                UPDATE suppliers
                SET status = CASE WHEN status='active' THEN 'inactive' ELSE 'active' END,
                    updated_by_admin_id=?
                WHERE id=?
            ");
            $stmt->execute([$adminId,$id]);
            $_SESSION['supplier_success'] = 'Supplier status updated.';
        }


        if ($action === 'delete_supplier') {
            $id = max(0, (int)($_POST['id'] ?? 0));

            if ($id <= 0) {
                throw new RuntimeException('Invalid supplier selected.');
            }

            $stmt = $pdo->prepare("
                SELECT company_name
                FROM suppliers
                WHERE id=?
                LIMIT 1
            ");
            $stmt->execute([$id]);
            $supplierName = trim((string)($stmt->fetchColumn() ?: ''));

            if ($supplierName === '') {
                throw new RuntimeException('Supplier not found.');
            }

            $pdo->beginTransaction();

            /*
             * TRUE DELETE:
             * Remove dependent supplier records first so foreign-key constraints
             * cannot block deletion.
             */
            foreach ([
                'supplier_contacts',
                'supplier_destinations',
                'supplier_services'
            ] as $childTable) {
                try {
                    $stmt = $pdo->prepare("DELETE FROM {$childTable} WHERE supplier_id=?");
                    $stmt->execute([$id]);
                } catch (Throwable $ignored) {
                    // Optional/older installation table.
                }
            }

            /*
             * Supplier sourcing/request records may reference suppliers.id.
             * For a permanent delete requested by Super Admin, remove those
             * supplier-specific request rows as well.
             */
            try {
                $tableCheck = $pdo->query("SHOW TABLES LIKE 'supplier_requests'");
                if ($tableCheck && $tableCheck->fetchColumn()) {
                    $stmt = $pdo->prepare("DELETE FROM supplier_requests WHERE supplier_id=?");
                    $stmt->execute([$id]);
                }
            } catch (Throwable $ignored) {
                // Continue for installations without supplier_requests.
            }

            /*
             * Clean common optional supplier child tables if present.
             * Each is isolated so older schemas remain compatible.
             */
            foreach ([
                'supplier_quotes',
                'supplier_quotations',
                'supplier_request_responses',
                'supplier_rates',
                'supplier_notes',
                'supplier_documents'
            ] as $optionalChildTable) {
                try {
                    $stmt = $pdo->prepare("DELETE FROM {$optionalChildTable} WHERE supplier_id=?");
                    $stmt->execute([$id]);
                } catch (Throwable $ignored) {
                    // Table/column may not exist in this installation.
                }
            }

            $stmt = $pdo->prepare("DELETE FROM suppliers WHERE id=? LIMIT 1");
            $stmt->execute([$id]);

            if ($stmt->rowCount() !== 1) {
                throw new RuntimeException('Supplier could not be deleted.');
            }

            $pdo->commit();

            $_SESSION['supplier_success'] =
                'Supplier "' . $supplierName . '" deleted permanently.';

            header('Location: admin-suppliers.php');
            exit;
        }

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['supplier_error'] = $e->getMessage();
        header('Location: admin-suppliers.php');
        exit;
    }
}

$q = trim((string)($_GET['q'] ?? ''));
$status = trim((string)($_GET['status'] ?? ''));
$priority = trim((string)($_GET['priority'] ?? ''));

$where = [];
$params = [];

if ($q !== '') {
    $where[] = "(s.company_name LIKE ? OR s.supplier_code LIKE ? OR s.city LIKE ? OR s.country LIKE ? OR c.contact_name LIKE ? OR c.mobile LIKE ? OR c.whatsapp LIKE ? OR c.email LIKE ?)";
    for ($i=0;$i<8;$i++) $params[] = '%' . $q . '%';
}
if (in_array($status, ['active','inactive'], true)) {
    $where[] = "s.status=?";
    $params[] = $status;
}
if (in_array($priority, ['preferred','regular','backup'], true)) {
    $where[] = "s.priority=?";
    $params[] = $priority;
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$sql = "
SELECT
    s.*,
    MAX(CASE WHEN c.is_primary=1 THEN c.contact_name END) AS primary_contact,
    MAX(CASE WHEN c.is_primary=1 THEN c.mobile END) AS primary_mobile,
    MAX(CASE WHEN c.is_primary=1 THEN c.whatsapp END) AS primary_whatsapp,
    MAX(CASE WHEN c.is_primary=1 THEN c.email END) AS primary_email,
    COUNT(DISTINCT sd.destination_id) AS destination_count,
    COUNT(DISTINCT ss.service_type_id) AS service_count
FROM suppliers s
LEFT JOIN supplier_contacts c ON c.supplier_id=s.id AND c.status='active'
LEFT JOIN supplier_destinations sd ON sd.supplier_id=s.id
LEFT JOIN supplier_services ss ON ss.supplier_id=s.id
{$whereSql}
GROUP BY s.id
ORDER BY
    CASE s.priority WHEN 'preferred' THEN 1 WHEN 'regular' THEN 2 ELSE 3 END,
    s.company_name ASC
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$suppliers = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

$stats = $pdo->query("
SELECT
 COUNT(*) total,
 SUM(status='active') active_count,
 SUM(priority='preferred' AND status='active') preferred_count,
 SUM(status='inactive') inactive_count
FROM suppliers
")->fetch(PDO::FETCH_ASSOC) ?: [];

$currentScript = basename($_SERVER['PHP_SELF']);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Suppliers | TRAVSCOPE</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">

<link rel="preconnect" href="https://cdnjs.cloudflare.com">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f5f7fb;color:#172033;font-family:Arial,sans-serif}
.layout{min-height:100vh}.sidebar{position:fixed;left:0;top:0;bottom:0;width:260px;background:#07192d;color:#fff;padding:22px 14px;overflow:auto}
.brand{display:flex;gap:12px;align-items:center;color:#fff;text-decoration:none;padding:7px 10px 20px}.brand i{font-size:25px}.brand strong{display:block}.brand small{color:#9fb0c6}
.menu-title{font-size:10px;letter-spacing:.12em;color:#70849d;padding:19px 12px 7px;font-weight:800}.menu-link{display:flex;gap:11px;align-items:center;color:#c8d2df;text-decoration:none;padding:11px 12px;border-radius:10px;font-size:14px}.menu-link:hover,.menu-link.active{background:#122b47;color:#fff}.menu-link i{width:18px}
.main{margin-left:260px;min-height:100vh}.topbar{height:72px;background:#fff;border-bottom:1px solid #e4e8ef;display:flex;align-items:center;justify-content:space-between;padding:0 26px;position:sticky;top:0;z-index:5}
.page{padding:26px}.heading{display:flex;justify-content:space-between;gap:20px;align-items:flex-start;margin-bottom:20px}.heading h1{margin:0;font-size:28px}.heading p{margin:7px 0 0;color:#718096}
.btn{border:0;border-radius:10px;padding:11px 15px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;gap:8px;align-items:center}.btn-primary{background:#0b74ff;color:#fff}.btn-soft{background:#eef4ff;color:#175fc3}.btn-dark{background:#07192d;color:#fff}
.cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:18px}.card,.panel{background:#fff;border:1px solid #e5e9f0;border-radius:16px;box-shadow:0 6px 24px rgba(7,25,45,.04)}
.card{padding:18px}.card small{color:#7a8798}.card strong{display:block;font-size:25px;margin-top:7px}
.panel{padding:18px;margin-bottom:18px}.filters{display:grid;grid-template-columns:2fr 1fr 1fr auto;gap:10px}.input,select,textarea{width:100%;border:1px solid #d9e0ea;border-radius:10px;padding:10px 11px;background:#fff;font:inherit}textarea{min-height:90px}
.table-wrap{overflow:auto}.table{width:100%;border-collapse:collapse;min-width:1000px}.table th{text-align:left;color:#6b7788;font-size:12px;padding:12px;border-bottom:1px solid #e8edf3}.table td{padding:13px 12px;border-bottom:1px solid #edf1f5;font-size:13px;vertical-align:middle}
.badge{display:inline-flex;padding:6px 9px;border-radius:999px;font-size:11px;font-weight:800}.active{background:#e8f8ef;color:#167046}.inactive{background:#f1f3f6;color:#687386}.preferred{background:#fff5d9;color:#906800}.regular{background:#eaf3ff;color:#1a5da7}.backup{background:#f1f3f6;color:#5f6875}
.alert{padding:12px 14px;border-radius:10px;margin-bottom:15px}.ok{background:#e9f8ef;color:#17663e}.err{background:#fff0f0;color:#a23030}
.modal{display:none;position:fixed;inset:0;background:rgba(4,17,31,.55);z-index:20;align-items:center;justify-content:center;padding:20px}.modal.open{display:flex}.modal-card{width:min(850px,100%);max-height:92vh;overflow:auto;background:#fff;border-radius:18px;padding:22px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px}.full{grid-column:1/-1}.label{font-size:12px;font-weight:700;margin-bottom:6px;display:block}
.actions{display:flex;gap:7px;flex-wrap:wrap}.muted{color:#7a8798}.empty{text-align:center;padding:40px;color:#7b8796}
.supplier-action-btn{
    min-height:34px!important;
    padding:8px 11px!important;
    border-radius:9px!important;
    font-size:11px!important;
    font-weight:800!important;
    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;
    gap:6px!important;
    border:1px solid transparent!important;
    text-decoration:none!important;
    white-space:nowrap!important;
    transition:transform .15s ease,box-shadow .15s ease,filter .15s ease!important;
}
.supplier-action-btn:hover{
    transform:translateY(-1px)!important;
    filter:saturate(1.04)!important;
}
.supplier-btn-manage{
    background:linear-gradient(135deg,#e9f4ff,#f5faff)!important;
    border-color:#c8e1fb!important;
    color:#1264bd!important;
}
.supplier-btn-edit{
    background:linear-gradient(135deg,#f2ecff,#faf8ff)!important;
    border-color:#dacbf8!important;
    color:#7043bf!important;
}
.supplier-btn-active{
    background:linear-gradient(135deg,#eafaf2,#f8fdfb)!important;
    border-color:#c7e8d6!important;
    color:#177047!important;
}
.supplier-btn-inactive{
    background:linear-gradient(135deg,#fff5df,#fffaf1)!important;
    border-color:#efd8a9!important;
    color:#966509!important;
}
.supplier-btn-delete{
    background:linear-gradient(135deg,#fff0f0,#fff8f8)!important;
    border-color:#f2c5c5!important;
    color:#b33a3a!important;
}
.supplier-btn-manage:hover{box-shadow:0 5px 13px rgba(18,100,189,.12)!important}
.supplier-btn-edit:hover{box-shadow:0 5px 13px rgba(112,67,191,.12)!important}
.supplier-btn-active:hover{box-shadow:0 5px 13px rgba(23,112,71,.12)!important}
.supplier-btn-inactive:hover{box-shadow:0 5px 13px rgba(150,101,9,.12)!important}
.supplier-btn-delete:hover{box-shadow:0 5px 13px rgba(179,58,58,.12)!important}
.actions form{margin:0!important}

@media(max-width:900px){.sidebar{position:static;width:100%;height:auto}.main{margin-left:0}.cards{grid-template-columns:repeat(2,1fr)}.filters,.grid{grid-template-columns:1fr}.full{grid-column:auto}}

.supplier-geo-panel{
    border:1px solid #dce4f1;
    border-radius:16px;
    padding:14px;
    background:
        radial-gradient(circle at 100% 0,rgba(103,84,255,.10),transparent 32%),
        linear-gradient(135deg,#f8fbff,#fbf9ff 54%,#fffaf4);
}
.supplier-geo-heading{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    margin-bottom:12px;
}
.supplier-geo-heading strong{
    display:block;
    font-size:13px;
}
.supplier-geo-heading span:not(.supplier-geo-badge){
    display:block;
    margin-top:4px;
    color:#728095;
    font-size:10px;
}
.supplier-geo-badge{
    display:inline-flex;
    align-items:center;
    gap:5px;
    padding:6px 9px;
    border-radius:999px;
    background:#eafff2;
    color:#177149;
    font-size:10px;
    font-weight:800;
    white-space:nowrap;
}
.supplier-geo-grid{
    display:grid;
    grid-template-columns:repeat(3,minmax(0,1fr));
    gap:10px;
}
.supplier-geo-card{
    position:relative;
    border-radius:14px;
    padding:12px;
    border:1px solid transparent;
}
.supplier-country-card{
    background:linear-gradient(145deg,#eaf5ff,#f8fbff);
    border-color:#cde4ff;
}
.supplier-state-card{
    background:linear-gradient(145deg,#f2edff,#fbf9ff);
    border-color:#ded2ff;
}
.supplier-city-card{
    background:linear-gradient(145deg,#fff2e4,#fffaf4);
    border-color:#ffddb5;
}
.supplier-geo-number{
    position:absolute;
    right:9px;
    top:8px;
    width:22px;
    height:22px;
    border-radius:50%;
    display:grid;
    place-items:center;
    background:#fff;
    box-shadow:0 3px 10px rgba(21,37,64,.08);
    font-size:10px;
    font-weight:900;
}
.supplier-geo-card small{
    display:block;
    margin-top:6px;
    color:#718096;
    font-size:9px;
    line-height:1.4;
}
.supplier-geo-path{
    margin-top:10px;
    padding:8px 10px;
    border-radius:10px;
    background:#fff;
    border:1px dashed #cad6e5;
    color:#64748a;
    font-size:10px;
}
@media(max-width:900px){
    .supplier-geo-grid{grid-template-columns:1fr;}
    .supplier-geo-heading{align-items:flex-start;flex-direction:column;}
}

</style>

<style>
/* ==========================================================
   TRAVSCOPE DESTINATION-MATCHED VISUAL FORMULA
   VISUAL / SIDEBAR / TYPOGRAPHY ONLY.
   No supplier PHP/database/business logic changed.
   ========================================================== */

:root{
    --ts-navy:#07192d;
    --ts-blue:#0b74ff;
    --ts-blue2:#075fcf;
    --ts-cyan:#00b8ff;
    --ts-text:#172235;
    --ts-muted:#7e8a9b;
    --ts-border:#e1e8ef;
}

/* Same text family/formula as admin-destinations.php */
body{
    font-family:'DM Sans',sans-serif!important;
    color:var(--ts-text)!important;
}
.heading h1,
.topbar strong{
    font-family:'Manrope',sans-serif!important;
}
.heading h1{
    color:var(--ts-navy)!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
    line-height:1.55!important;
}
.panel h2{
    color:var(--ts-navy)!important;
    font-family:'Manrope',sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card small{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:700!important;
}
.card strong{
    color:var(--ts-navy)!important;
    font-family:'Manrope',sans-serif!important;
    font-size:21px!important;
    font-weight:800!important;
}
.label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
.table th{
    font-size:11px!important;
    font-weight:800!important;
}
.table td{
    font-size:12px!important;
}

/* Exact same left-panel visual formula as Destination admin */
.sidebar{
    width:250px!important;
    padding:20px 13px!important;
    background:var(--ts-navy)!important;
    color:#fff!important;
}
.main{
    margin-left:250px!important;
}
.sidebar-logo{
    min-height:58px!important;
    margin:0 0 14px!important;
    padding:7px 10px!important;
    display:flex!important;
    align-items:center!important;
    gap:10px!important;
    color:#fff!important;
    text-decoration:none!important;
}
.logo-icon{
    width:38px!important;
    height:38px!important;
    flex:0 0 38px!important;
    border-radius:11px!important;
    display:grid!important;
    place-items:center!important;
    background:linear-gradient(135deg,var(--ts-blue),var(--ts-cyan))!important;
    color:#fff!important;
    box-shadow:0 8px 18px rgba(11,116,255,.24)!important;
}
.sidebar-brand-text strong{
    display:block!important;
    font-family:'Manrope',sans-serif!important;
    font-size:15px!important;
    line-height:1.2!important;
    letter-spacing:.2px!important;
}
.sidebar-brand-text small{
    display:block!important;
    margin-top:3px!important;
    color:#8fa4b9!important;
    font-size:9px!important;
    line-height:1.2!important;
}
.menu-title{
    padding:0 12px!important;
    margin:16px 0 8px!important;
    color:#8fa4b9!important;
    font-size:10px!important;
    line-height:1.3!important;
    font-weight:800!important;
    text-transform:uppercase!important;
    letter-spacing:.8px!important;
}
.sidebar .menu-link{
    min-height:46px!important;
    margin-bottom:6px!important;
    padding:0 14px!important;
    border-radius:10px!important;
    display:flex!important;
    align-items:center!important;
    gap:11px!important;
    color:#c7d4e1!important;
    font-size:13px!important;
    line-height:1.35!important;
    font-weight:700!important;
    text-decoration:none!important;
    transition:background .2s ease,color .2s ease,transform .2s ease!important;
}
.sidebar .menu-link i{
    width:22px!important;
    flex:0 0 22px!important;
    text-align:center!important;
    font-size:14px!important;
}
.sidebar .menu-link:hover{
    color:#fff!important;
    background:rgba(255,255,255,.12)!important;
    transform:translateX(2px)!important;
}
.sidebar .menu-link.active{
    color:#fff!important;
    background:linear-gradient(135deg,var(--ts-blue),#0866dd)!important;
    box-shadow:0 6px 16px rgba(11,116,255,.20)!important;
}

/* Topbar text aligned with destination style */
.topbar{
    height:70px!important;
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.topbar strong{
    color:var(--ts-navy)!important;
    font-size:16px!important;
}
.topbar span{
    color:#708095!important;
    font-size:12px!important;
}

/* Location cards: COUNTRY BLUE / STATE PURPLE / CITY ORANGE */
.supplier-country-card{
    background:linear-gradient(145deg,#dff0ff 0%,#eef7ff 48%,#f8fcff 100%)!important;
    border-color:#9fd0ff!important;
    box-shadow:0 8px 20px rgba(37,99,235,.08)!important;
}
.supplier-country-card select{
    background:#eef7ff!important;
    border-color:#9fcaff!important;
    color:#14345c!important;
}

.supplier-state-card{
    background:linear-gradient(145deg,#eee6ff 0%,#f6f1ff 50%,#fcfaff 100%)!important;
    border-color:#c9b7ff!important;
    box-shadow:0 8px 20px rgba(124,58,237,.07)!important;
}
.supplier-state-card select{
    background:#f5efff!important;
    border-color:#cbb9ff!important;
    color:#3d2864!important;
}

.supplier-city-card{
    background:linear-gradient(145deg,#ffe8cf 0%,#fff2e4 50%,#fffaf4 100%)!important;
    border-color:#ffc98c!important;
    box-shadow:0 8px 20px rgba(234,88,12,.07)!important;
}
.supplier-city-card select{
    background:#fff2e3!important;
    border-color:#ffc68a!important;
    color:#633515!important;
}

.supplier-country-card .supplier-geo-number{color:#1769c2!important}
.supplier-state-card .supplier-geo-number{color:#7047c8!important}
.supplier-city-card .supplier-geo-number{color:#c66516!important}

.supplier-geo-path{
    background:linear-gradient(135deg,#e9fff5,#f6fffb)!important;
    border-color:#a9e7ca!important;
    color:#365b4c!important;
}

.supplier-geo-card select:disabled{
    opacity:.72!important;
    cursor:not-allowed!important;
    -webkit-text-fill-color:#6b7280!important;
}

/* Make professional supplier modal section boxes visually consistent */
.modal-card{
    font-family:'DM Sans',sans-serif!important;
}
.modal-card .grid > .full > strong{
    font-family:'Manrope',sans-serif!important;
    color:var(--ts-navy)!important;
    font-size:12px!important;
    letter-spacing:.2px!important;
}
.modal-card .input,
.modal-card select,
.modal-card textarea{
    border-radius:8px!important;
    border-color:#d7e1ed!important;
    font-size:12px!important;
}
.modal-card .input:focus,
.modal-card select:focus,
.modal-card textarea:focus{
    border-color:#60a5fa!important;
    box-shadow:0 0 0 3px rgba(59,130,246,.12)!important;
    outline:none!important;
}

/* Responsive preservation */
@media(max-width:900px){
    .sidebar{width:100%!important;}
    .main{margin-left:0!important;}
}
</style>


<style id="travscope-professional-ui-v3">
:root{
--ts-navy:#0a1b31;--ts-blue:#1677ff;--ts-text:#182235;--ts-muted:#7a8798;
--ts-border:#dfe7f0;--ts-bg:#f4f7fb;--ts-shadow:0 8px 26px rgba(31,55,88,.055)
}
html{-webkit-text-size-adjust:100%;text-size-adjust:100%}
body{background:var(--ts-bg)!important;color:var(--ts-text)!important;font-family:'DM Sans',Arial,sans-serif!important;font-size:14px!important;line-height:1.45!important}
h1,h2,h3,h4,strong,.topbar strong{font-family:'Manrope','DM Sans',Arial,sans-serif!important}
.main{background:var(--ts-bg)!important;margin-left:210px!important}
.page{padding:22px 24px!important}
.heading{margin-bottom:16px!important}.heading h1{font-size:26px!important;font-weight:800!important;line-height:1.18!important;letter-spacing:-.45px!important;color:var(--ts-navy)!important}.heading p{font-size:12px!important;color:var(--ts-muted)!important;margin-top:5px!important}
.btn,.btn-primary,.btn-soft,.btn-dark,.btn-secondary{min-height:38px!important;border-radius:9px!important;padding:9px 13px!important;font-size:12px!important;font-weight:700!important;line-height:1.1!important}
.btn-primary{background:linear-gradient(135deg,#1677ff,#0d6fe8)!important;color:#fff!important}.btn-soft{background:#edf5ff!important;color:#1265c9!important}.btn-dark{background:var(--ts-navy)!important;color:#fff!important}
.panel{border:1px solid #e0e8f1!important;border-radius:15px!important;box-shadow:var(--ts-shadow)!important;background:linear-gradient(135deg,#fff,#fbfdff)!important;padding:16px!important}
.cards{gap:12px!important}.card{border-radius:14px!important;border:1px solid #e1e8f0!important;box-shadow:var(--ts-shadow)!important;padding:15px 16px!important}
.cards .card:nth-child(4n+1){background:linear-gradient(135deg,#eef7ff,#fbfdff)!important;border-left:4px solid #2391ff!important}
.cards .card:nth-child(4n+2){background:linear-gradient(135deg,#effbf5,#fbfffd)!important;border-left:4px solid #22a96a!important}
.cards .card:nth-child(4n+3){background:linear-gradient(135deg,#fff7e9,#fffdfa)!important;border-left:4px solid #f59e0b!important}
.cards .card:nth-child(4n+4){background:linear-gradient(135deg,#f6f0ff,#fdfbff)!important;border-left:4px solid #8b5cf6!important}
.card small{font-size:10px!important;font-weight:700!important;color:#728096!important}.card strong{font-size:22px!important;font-weight:800!important;color:var(--ts-navy)!important}
.filters{gap:8px!important}.input,select,textarea,.form-control{min-height:38px!important;border-radius:8px!important;border:1px solid #d5dfeb!important;background:#fff!important;color:#253248!important;font:12px 'DM Sans',Arial,sans-serif!important;padding:8px 10px!important}
.input:focus,select:focus,textarea:focus,.form-control:focus{border-color:#70adff!important;box-shadow:0 0 0 3px rgba(22,119,255,.11)!important;outline:none!important}
textarea{min-height:88px!important}
.table th,table th{background:#f5f8fc!important;color:#65748a!important;font-size:10px!important;font-weight:800!important;padding:11px 10px!important}.table td,table td{font-size:12px!important;padding:11px 10px!important;color:#2a3548!important}.table tbody tr:nth-child(even),table tbody tr:nth-child(even){background:#fbfdff!important}.table tbody tr:hover,table tbody tr:hover{background:#f4f9ff!important}
.badge{border-radius:999px!important;padding:5px 8px!important;font-size:10px!important;font-weight:800!important}.active{background:#e7f8ef!important;color:#167047!important}.inactive{background:#f1f3f6!important;color:#677386!important}.preferred{background:#fff2d5!important;color:#966607!important}.regular{background:#e9f3ff!important;color:#1c62a9!important}.backup{background:#f1f2f5!important;color:#626d7b!important}
.modal-card{width:min(920px,96vw)!important;border-radius:18px!important;padding:20px!important;box-shadow:0 22px 60px rgba(13,29,49,.2)!important}.modal-card .grid{gap:11px!important}.modal-card .grid>div:not(.full){border-radius:12px!important;padding:10px!important}
.modal-card .grid>div:not(.full):nth-child(4n+1){background:#f2f8ff!important;border:1px solid #d5e8fb!important}.modal-card .grid>div:not(.full):nth-child(4n+2){background:#f3fbf7!important;border:1px solid #d5eee1!important}.modal-card .grid>div:not(.full):nth-child(4n+3){background:#fbf6ff!important;border:1px solid #eadcf8!important}.modal-card .grid>div:not(.full):nth-child(4n+4){background:#fff8ed!important;border:1px solid #f6e3c1!important}
.geo-country-box,.supplier-country-card{background:linear-gradient(145deg,#dfefff,#eef7ff 50%,#f9fcff)!important;border:1px solid #a7d2ff!important}.geo-state-box,.supplier-state-card{background:linear-gradient(145deg,#eee7ff,#f7f3ff 50%,#fdfbff)!important;border:1px solid #ccbaff!important}.geo-city-box,.supplier-city-card{background:linear-gradient(145deg,#ffe9d3,#fff4e8 50%,#fffaf5)!important;border:1px solid #ffc98f!important}.geo-destination-result,.supplier-geo-path{background:linear-gradient(135deg,#eafff4,#f7fffb)!important;border:1px solid #a9e6ca!important;color:#315b49!important}
.geo-country-box select,.supplier-country-card select{background:#eaf5ff!important;border-color:#9fcbff!important}.geo-state-box select,.supplier-state-card select{background:#f3eeff!important;border-color:#c8b7ff!important}.geo-city-box select,.supplier-city-card select{background:#fff0df!important;border-color:#ffc286!important}
.sidebar{width:210px!important;padding:14px 8px 20px!important;background:#0a1b31!important;overflow-y:auto!important}.sidebar-logo,.brand{min-height:58px!important;margin:0 0 10px!important;padding:8px 9px!important;border:1px solid rgba(255,255,255,.08)!important;border-radius:9px!important;background:rgba(255,255,255,.025)!important}.logo-icon{width:34px!important;height:34px!important;flex:0 0 34px!important;border-radius:9px!important}.sidebar-brand-text strong,.brand strong{font-size:13px!important}.sidebar-brand-text small,.brand small{font-size:8px!important}.menu-title{padding:0 7px!important;margin:12px 0 5px!important;font-size:8px!important;letter-spacing:.7px!important;color:#8499b2!important}.sidebar .menu-link{min-height:34px!important;margin-bottom:3px!important;padding:0 9px!important;border-radius:7px!important;gap:8px!important;font-size:11px!important;font-weight:700!important;color:#d0dbea!important}.sidebar .menu-link i{width:18px!important;flex:0 0 18px!important;font-size:11px!important}.sidebar .menu-link.active{background:linear-gradient(135deg,#177af7,#2088ff)!important;box-shadow:0 5px 13px rgba(23,122,247,.25)!important}.sidebar .menu-link:hover{background:rgba(255,255,255,.085)!important}
.topbar{height:62px!important;padding:0 22px!important;background:#fff!important}.topbar strong{font-size:14px!important}.topbar span{font-size:10px!important;color:#748196!important}
@media(max-width:1200px){.page{padding:18px!important}.cards{grid-template-columns:repeat(2,minmax(0,1fr))!important}.filters{grid-template-columns:1.5fr 1fr 1fr auto!important}}
@media(max-width:900px){.sidebar{position:static!important;width:100%!important;height:auto!important}.main{margin-left:0!important}.sidebar-menu,.sidebar nav{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:4px!important}.menu-title{grid-column:1/-1!important}.cards{grid-template-columns:repeat(2,minmax(0,1fr))!important}.filters{grid-template-columns:1fr 1fr!important}.modal-card{width:98vw!important}}
@media(max-width:600px){body{font-size:13px!important}.page{padding:12px!important}.heading{display:block!important}.heading h1{font-size:21px!important}.cards,.filters,.sidebar-menu,.sidebar nav{grid-template-columns:1fr!important}.menu-title{grid-column:auto!important}.table-wrap{overflow-x:auto!important;-webkit-overflow-scrolling:touch!important}.modal{padding:7px!important;align-items:flex-start!important}.modal-card{width:100%!important;max-height:96vh!important;padding:13px!important;border-radius:13px!important}.modal-card .grid,.geo-selector-grid,.supplier-geo-grid{grid-template-columns:1fr!important}.full{grid-column:auto!important}}
</style>

<style id="supplier-color-completion">
#supplierModal .full:has(textarea){background:linear-gradient(135deg,#f8fbff,#fcfdff)!important;border:1px solid #e0eaf4!important;padding:10px!important}
#supplierModal .full:has(#destinationChooser){background:linear-gradient(135deg,#f0f8ff,#f8fbff)!important;border:1px solid #d3e8fb!important;padding:11px!important}
#destinationChooser{background:linear-gradient(135deg,#f9fcff,#fff)!important}
.destination-choice:nth-child(4n+1){background:#eaf5ff!important;border-color:#cce4fb!important}
.destination-choice:nth-child(4n+2){background:#eefaf3!important;border-color:#cfe9db!important}
.destination-choice:nth-child(4n+3){background:#f5efff!important;border-color:#ded0fa!important}
.destination-choice:nth-child(4n+4){background:#fff5e7!important;border-color:#f5ddba!important}
</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<style id="supplier-international-v2468">
/* TRAVSCOPE V24.68 — International Supplier Directory */
.supplier-hub{
    margin-bottom:14px;
    border:1px solid #dbe6f1;
    border-radius:17px;
    background:
      radial-gradient(circle at 92% 10%,rgba(22,119,255,.09),transparent 30%),
      linear-gradient(135deg,#ffffff 0%,#f8fbff 100%);
    box-shadow:0 10px 30px rgba(20,48,84,.055);
    overflow:hidden;
}
.supplier-hub-main{
    min-height:92px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:18px;
    padding:17px 18px 14px;
    border-left:4px solid #1478ff;
}
.supplier-hub-copy{min-width:0}
.supplier-hub-eyebrow{
    margin-bottom:3px;
    color:#1478ff;
    font:800 9px/1.25 'DM Sans',sans-serif;
    letter-spacing:.115em;
    text-transform:uppercase;
}
.supplier-hub-title-row{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
.supplier-hub h1{
    margin:0!important;
    color:#0a1b31!important;
    font:800 25px/1.12 'Manrope',sans-serif!important;
    letter-spacing:-.45px!important;
}
.supplier-hub-copy p{
    margin:5px 0 0;
    max-width:720px;
    color:#728197;
    font-size:11px;
    line-height:1.45;
}
.supplier-kpis{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.supplier-kpi{
    min-width:92px;
    min-height:42px;
    padding:7px 10px;
    display:grid;
    grid-template-columns:28px 1fr;
    grid-template-rows:auto auto;
    column-gap:8px;
    align-items:center;
    border:1px solid #e0e8f1;
    border-radius:11px;
    background:rgba(255,255,255,.88);
    box-shadow:0 5px 14px rgba(27,55,88,.035);
}
.supplier-kpi i{
    grid-row:1/3;
    width:28px;height:28px;border-radius:8px;
    display:grid;place-items:center;
    font-size:11px;
}
.supplier-kpi span{color:#7a8798;font-size:8px;font-weight:800;text-transform:uppercase;letter-spacing:.04em;white-space:nowrap}
.supplier-kpi strong{color:#0a1b31;font:800 16px/1 'Manrope',sans-serif}
.supplier-kpi.total i{background:#e9f3ff;color:#1677ff}
.supplier-kpi.active i{background:#e9f9f1;color:#12a36a}
.supplier-kpi.preferred i{background:#fff4de;color:#d98500}
.supplier-kpi.inactive i{background:#f3efff;color:#7c55d9}
.supplier-hub-actions{display:flex;gap:7px;align-items:center;justify-content:flex-end;flex-wrap:wrap;flex:0 0 auto}
.supplier-hub-actions .btn{min-height:36px!important;padding:8px 11px!important;border-radius:9px!important;white-space:nowrap}
.supplier-hub-actions .btn-supplier-request{background:#eef5ff!important;color:#145fb7!important;border:1px solid #dcecff!important}
.supplier-hub-actions .btn-supplier-package{background:#eefbf6!important;color:#16855c!important;border:1px solid #d8f2e7!important}

.supplier-directory{
    padding:0!important;
    border-radius:16px!important;
    overflow:hidden;
    background:#fff!important;
    border:1px solid #dfe8f1!important;
    box-shadow:0 8px 28px rgba(25,52,84,.05)!important;
}
.supplier-directory-top{
    min-height:52px;
    padding:11px 14px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    border-bottom:1px solid #e5edf5;
    background:linear-gradient(135deg,#fbfdff,#f6faff);
}
.supplier-directory-title{display:flex;align-items:center;gap:9px;min-width:0}
.supplier-directory-icon{
    width:32px;height:32px;flex:0 0 32px;border-radius:9px;
    display:grid;place-items:center;
    background:linear-gradient(135deg,#e8f3ff,#f3f8ff);
    color:#1677ff;
    border:1px solid #dcecff;
}
.supplier-directory-title h2{margin:0!important;color:#0a1b31!important;font:800 14px/1.2 'Manrope',sans-serif!important}
.supplier-directory-title p{margin:2px 0 0;color:#8290a1;font-size:9px;line-height:1.35}
.supplier-result-chip{
    display:inline-flex;align-items:center;gap:5px;
    padding:5px 8px;border-radius:999px;
    background:#edf5ff;color:#176ac6;
    font-size:9px;font-weight:800;white-space:nowrap;
}
.supplier-directory-filters{
    display:grid!important;
    grid-template-columns:minmax(260px,1.6fr) minmax(150px,.52fr) minmax(150px,.52fr) auto auto;
    gap:7px!important;
    padding:10px 12px;
    margin:0!important;
    background:#fff;
    border-bottom:1px solid #e7edf4;
}
.supplier-directory-filters .input,
.supplier-directory-filters select{min-height:35px!important;height:35px!important;padding:7px 10px!important;border-radius:8px!important;font-size:11px!important}
.supplier-directory-filters .btn{min-height:35px!important;height:35px!important;padding:7px 11px!important;border-radius:8px!important;white-space:nowrap}
.supplier-reset-btn{background:#f4f7fa!important;color:#5f6d7e!important;border:1px solid #e2e8ef!important}

.supplier-directory .table-wrap{overflow:auto!important}
.supplier-directory .table{min-width:1120px!important;margin:0!important;border-collapse:separate!important;border-spacing:0!important}
.supplier-directory .table thead th{
    position:sticky;top:0;z-index:1;
    padding:9px 11px!important;
    background:#eef4fa!important;
    border-bottom:1px solid #d8e3ee!important;
    color:#52647a!important;
    font-size:8.5px!important;
    line-height:1.2!important;
    text-transform:uppercase;
    letter-spacing:.045em;
    white-space:nowrap;
}
.supplier-directory .table tbody td{
    padding:10px 11px!important;
    border-bottom:1px solid #e9eef4!important;
    vertical-align:middle!important;
    color:#334155!important;
    font-size:10px!important;
    line-height:1.35!important;
}
.supplier-directory .table tbody tr:last-child td{border-bottom:0!important}
.supplier-directory .table tbody tr{transition:background .15s ease,box-shadow .15s ease}
.supplier-directory .table tbody tr:hover{background:#f9fcff!important}
.supplier-identity{display:flex;align-items:center;gap:9px;min-width:210px}
.supplier-avatar{
    width:34px;height:34px;flex:0 0 34px;border-radius:10px;
    display:grid;place-items:center;
    background:linear-gradient(135deg,#e9f3ff,#dff8f1);
    color:#1469c7;
    border:1px solid #d7e8f7;
    font:800 12px/1 'Manrope',sans-serif;
}
.supplier-name{display:block;color:#102744;font-size:10.5px;font-weight:800;line-height:1.3}
.supplier-meta-line{display:flex;align-items:center;gap:5px;flex-wrap:wrap;margin-top:3px;color:#8290a2;font-size:8.5px}
.supplier-type-chip{
    display:inline-flex;align-items:center;padding:2px 6px;border-radius:999px;
    background:#f1f5fa;color:#596a7e;font-size:8px;font-weight:800;
}
.supplier-contact strong{display:block;color:#32465e;font-size:9.5px;font-weight:700}
.supplier-contact a{display:block;margin-top:2px;color:#2c6caf;text-decoration:none;font-size:8.5px;max-width:190px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.supplier-contact .muted{font-size:8.5px!important}
.supplier-location{min-width:115px}
.supplier-location strong{display:block;color:#354a62;font-size:9.5px;font-weight:700}
.supplier-location span{display:block;margin-top:2px;color:#8793a3;font-size:8.5px}
.supplier-capability{display:flex;gap:5px;align-items:center;flex-wrap:wrap;min-width:125px}
.supplier-count-chip{
    display:inline-flex;align-items:center;gap:4px;padding:4px 6px;border-radius:7px;
    border:1px solid #e0e8f1;background:#f8fafc;color:#526579;font-size:8.5px;font-weight:700;white-space:nowrap;
}
.supplier-count-chip.destinations{background:#edf6ff;border-color:#dbeeff;color:#1467be}
.supplier-count-chip.services{background:#effaf5;border-color:#d9f0e4;color:#16805a}
.supplier-directory .badge{padding:4px 7px!important;font-size:8.5px!important;border:1px solid transparent!important}
.supplier-directory .badge.preferred{border-color:#f3deb4!important}
.supplier-directory .badge.regular{border-color:#d8e9fb!important}
.supplier-directory .badge.backup{border-color:#e1e5ea!important}
.supplier-directory .badge.active{border-color:#d6efdf!important}
.supplier-directory .badge.inactive{border-color:#e2e5e9!important}
.supplier-directory .actions{
    min-width:325px!important;
    display:flex!important;
    align-items:center!important;
    gap:5px!important;
    flex-wrap:wrap!important;
}
.supplier-directory .actions form{margin:0!important;display:inline-flex!important}
.supplier-directory .supplier-action-btn{
    min-height:30px!important;
    padding:6px 8px!important;
    border-radius:7px!important;
    font-size:8.5px!important;
    font-weight:800!important;
    gap:5px!important;
    box-shadow:none!important;
}
.supplier-directory .supplier-btn-manage{background:#eaf4ff!important;color:#0f65c6!important;border-color:#cfe5fb!important}
.supplier-directory .supplier-btn-edit{background:#f4f0ff!important;color:#6946b7!important;border-color:#e0d6fb!important}
.supplier-directory .supplier-btn-active{background:#ebfaf3!important;color:#15835b!important;border-color:#cfefdf!important}
.supplier-directory .supplier-btn-inactive{background:#fff5df!important;color:#a66a00!important;border-color:#f3ddb3!important}
.supplier-directory .supplier-btn-delete{background:#fff0f0!important;color:#c53f3f!important;border-color:#f3d0d0!important}
.supplier-directory .empty{padding:34px!important;text-align:center!important;color:#8190a3!important;font-size:11px!important}

@media(max-width:1180px){
  .supplier-hub-main{align-items:flex-start;flex-direction:column}
  .supplier-hub-actions{width:100%;justify-content:flex-start}
  .supplier-directory-filters{grid-template-columns:1fr 1fr 1fr auto auto}
}
@media(max-width:760px){
  .supplier-hub-main{padding:14px}
  .supplier-hub-title-row{display:block}
  .supplier-kpis{margin-top:9px}
  .supplier-kpi{min-width:calc(50% - 3px);flex:1 1 calc(50% - 3px)}
  .supplier-hub-actions .btn{flex:1 1 auto;justify-content:center}
  .supplier-directory-top{align-items:flex-start}
  .supplier-directory-filters{grid-template-columns:1fr 1fr!important}
  .supplier-directory-filters .input{grid-column:1/-1}
  .supplier-directory-filters .btn{justify-content:center}
}
@media(max-width:520px){
  .supplier-hub h1{font-size:21px!important}
  .supplier-directory-filters{grid-template-columns:1fr!important}
  .supplier-directory-filters .input{grid-column:auto}
  .supplier-result-chip{display:none}
}
</style>


<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>
<body>
<div class="layout">
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>

        <div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>

        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php','admin-supplier-documents.php','admin-supplier-document.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= supplierE(BASE_URL) ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>

<main class="main">
<header class="topbar"><strong>TRAVSCOPE Administration</strong><span><?= supplierE((string)$admin['name']) ?> · <?= supplierE(ucwords(str_replace('_',' ',(string)$admin['role']))) ?></span></header>
<div class="page">

<?php if ($success !== ''): ?><div class="alert ok"><?= supplierE($success) ?></div><?php endif; ?>
<?php if ($error !== ''): ?><div class="alert err"><?= supplierE($error) ?></div><?php endif; ?>

<section class="supplier-hub" aria-label="Supplier management summary">
    <div class="supplier-hub-main">
        <div class="supplier-hub-copy">
            <div class="supplier-hub-eyebrow"><i class="fa-solid fa-handshake-angle"></i> Supplier Network</div>
            <div class="supplier-hub-title-row">
                <h1>Supplier Management</h1>
                <div class="supplier-kpis" aria-label="Supplier statistics">
                    <div class="supplier-kpi total">
                        <i class="fa-solid fa-building"></i>
                        <span>Total</span>
                        <strong><?= (int)($stats['total'] ?? 0) ?></strong>
                    </div>
                    <div class="supplier-kpi active">
                        <i class="fa-solid fa-circle-check"></i>
                        <span>Active</span>
                        <strong><?= (int)($stats['active_count'] ?? 0) ?></strong>
                    </div>
                    <div class="supplier-kpi preferred">
                        <i class="fa-solid fa-star"></i>
                        <span>Preferred</span>
                        <strong><?= (int)($stats['preferred_count'] ?? 0) ?></strong>
                    </div>
                    <div class="supplier-kpi inactive">
                        <i class="fa-solid fa-circle-pause"></i>
                        <span>Inactive</span>
                        <strong><?= (int)($stats['inactive_count'] ?? 0) ?></strong>
                    </div>
                </div>
            </div>
            <p>Maintain destination coverage, service capability, contacts and commercial supplier relationships from one operational directory.</p>
        </div>

        <div class="supplier-hub-actions">
            <a class="btn btn-supplier-package" href="admin-supplier-packages.php"><i class="fa-solid fa-box-open"></i> Supplier Packages</a>
            <a class="btn btn-supplier-request" href="admin-supplier-requests.php"><i class="fa-regular fa-paper-plane"></i> Supplier Requests</a>
            <button class="btn btn-primary" type="button" onclick="openSupplierModal()"><i class="fa-solid fa-plus"></i> Add Supplier</button>
        </div>
    </div>
</section>

<section class="panel supplier-directory" aria-label="Supplier directory">
    <div class="supplier-directory-top">
        <div class="supplier-directory-title">
            <div class="supplier-directory-icon"><i class="fa-solid fa-address-book"></i></div>
            <div>
                <h2>Supplier Directory</h2>
                <p>Search, review and manage contracted travel partners and their capabilities.</p>
            </div>
        </div>
        <span class="supplier-result-chip"><i class="fa-solid fa-list-check"></i> <?= count($suppliers) ?> supplier<?= count($suppliers) === 1 ? '' : 's' ?> shown</span>
    </div>

    <form class="supplier-directory-filters" method="get">
        <input class="input" name="q" value="<?= supplierE($q) ?>" placeholder="Search company, code, contact, mobile, email or location..." aria-label="Search suppliers">
        <select name="status" aria-label="Supplier status">
            <option value="">All Statuses</option>
            <option value="active" <?= $status==='active'?'selected':'' ?>>Active</option>
            <option value="inactive" <?= $status==='inactive'?'selected':'' ?>>Inactive</option>
        </select>
        <select name="priority" aria-label="Supplier priority">
            <option value="">All Priorities</option>
            <option value="preferred" <?= $priority==='preferred'?'selected':'' ?>>Preferred</option>
            <option value="regular" <?= $priority==='regular'?'selected':'' ?>>Regular</option>
            <option value="backup" <?= $priority==='backup'?'selected':'' ?>>Backup</option>
        </select>
        <button class="btn btn-dark" type="submit"><i class="fa-solid fa-filter"></i> Apply</button>
        <?php if ($q !== '' || $status !== '' || $priority !== ''): ?>
            <a class="btn supplier-reset-btn" href="admin-suppliers.php"><i class="fa-solid fa-rotate-left"></i> Reset</a>
        <?php else: ?>
            <a class="btn supplier-reset-btn" href="admin-suppliers.php" title="Refresh supplier directory"><i class="fa-solid fa-rotate"></i> Refresh</a>
        <?php endif; ?>
    </form>

    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Supplier</th>
                    <th>Primary Contact</th>
                    <th>Location</th>
                    <th>Coverage & Capability</th>
                    <th>Priority</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$suppliers): ?>
                <tr><td colspan="7" class="empty"><i class="fa-regular fa-folder-open"></i><br>No suppliers match the current filters.</td></tr>
            <?php endif; ?>
            <?php foreach ($suppliers as $s):
                $supplierName = trim((string)($s['company_name'] ?? ''));
                $supplierInitial = $supplierName !== '' ? strtoupper(substr($supplierName, 0, 1)) : 'S';
                $supplierCity = trim((string)($s['city'] ?? ''));
                $supplierCountry = trim((string)($s['country'] ?? ''));
            ?>
                <tr>
                    <td>
                        <div class="supplier-identity">
                            <div class="supplier-avatar" aria-hidden="true"><?= supplierE($supplierInitial) ?></div>
                            <div>
                                <span class="supplier-name"><?= supplierE($supplierName !== '' ? $supplierName : 'Unnamed Supplier') ?></span>
                                <div class="supplier-meta-line">
                                    <span><?= supplierE((string)$s['supplier_code']) ?></span>
                                    <span aria-hidden="true">•</span>
                                    <span class="supplier-type-chip"><?= supplierE((string)($s['supplier_type'] ?: 'General')) ?></span>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td class="supplier-contact">
                        <strong><?= supplierE((string)($s['primary_contact'] ?: 'No primary contact')) ?></strong>
                        <?php if (!empty($s['primary_mobile'])): ?><span class="muted"><i class="fa-solid fa-phone"></i> <?= supplierE((string)$s['primary_mobile']) ?></span><?php endif; ?>
                        <?php if (!empty($s['primary_email'])): ?><a href="mailto:<?= supplierE((string)$s['primary_email']) ?>"><i class="fa-regular fa-envelope"></i> <?= supplierE((string)$s['primary_email']) ?></a><?php endif; ?>
                    </td>
                    <td class="supplier-location">
                        <strong><i class="fa-solid fa-location-dot"></i> <?= supplierE($supplierCity !== '' ? $supplierCity : ($supplierCountry !== '' ? $supplierCountry : 'Not set')) ?></strong>
                        <?php if ($supplierCity !== '' && $supplierCountry !== ''): ?><span><?= supplierE($supplierCountry) ?></span><?php endif; ?>
                    </td>
                    <td>
                        <div class="supplier-capability">
                            <span class="supplier-count-chip destinations"><i class="fa-solid fa-map-location-dot"></i> <?= (int)$s['destination_count'] ?> destination<?= (int)$s['destination_count'] === 1 ? '' : 's' ?></span>
                            <span class="supplier-count-chip services"><i class="fa-solid fa-layer-group"></i> <?= (int)$s['service_count'] ?> service<?= (int)$s['service_count'] === 1 ? '' : 's' ?></span>
                        </div>
                    </td>
                    <td><span class="badge <?= supplierE((string)$s['priority']) ?>"><?= supplierE(ucfirst((string)$s['priority'])) ?></span></td>
                    <td><span class="badge <?= supplierE((string)$s['status']) ?>"><?= supplierE(ucfirst((string)$s['status'])) ?></span></td>
                    <td class="actions">
                        <a class="supplier-action-btn supplier-btn-manage" href="admin-supplier-details.php?id=<?= (int)$s['id'] ?>" title="Open complete supplier profile"><i class="fa-solid fa-arrow-up-right-from-square"></i> Manage</a>
                        <a class="supplier-action-btn supplier-btn-edit" href="admin-supplier-details.php?id=<?= (int)$s['id'] ?>#supplier-profile" title="Edit supplier"><i class="fa-solid fa-pen"></i> Edit</a>
                        <a class="supplier-action-btn supplier-btn-edit" href="admin-supplier-packages.php?supplier_id=<?= (int)$s['id'] ?>" title="Manage supplier packages and seasonal rates"><i class="fa-solid fa-box-open"></i> Packages</a>

                        <form method="post" onsubmit="return confirm('Change supplier status?')">
                            <input type="hidden" name="csrf" value="<?= supplierE($csrf) ?>">
                            <input type="hidden" name="action" value="toggle_status">
                            <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
                            <button class="supplier-action-btn <?= $s['status']==='active' ? 'supplier-btn-inactive' : 'supplier-btn-active' ?>" type="submit" title="<?= $s['status']==='active' ? 'Deactivate supplier' : 'Activate supplier' ?>">
                                <i class="fa-solid <?= $s['status']==='active' ? 'fa-circle-pause' : 'fa-circle-check' ?>"></i>
                                <?= $s['status']==='active' ? 'Deactivate' : 'Activate' ?>
                            </button>
                        </form>

                        <form method="post">
                            <input type="hidden" name="csrf" value="<?= supplierE($csrf) ?>">
                            <input type="hidden" name="action" value="delete_supplier">
                            <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
                            <button class="supplier-action-btn supplier-btn-delete" type="submit" title="Delete supplier"><i class="fa-solid fa-trash-can"></i> Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
</div>
</main>
</div>

<div class="modal" id="supplierModal">
<div class="modal-card">
<div class="heading">
<div>
<h2 style="margin:0">Add Supplier</h2>
<p>Create a complete supplier profile using master-data selections. No destination spelling is required.</p>
</div>
<button class="btn" type="button" onclick="closeSupplierModal()">✕</button>
</div>

<form method="post" id="supplierCreateForm">
<input type="hidden" name="csrf" value="<?= supplierE($csrf) ?>">
<input type="hidden" name="action" value="save_supplier">

<div class="grid">

<div class="full" style="padding:10px 0 2px">
<strong>1. COMPANY</strong>
<span class="muted" style="margin-left:8px">Basic supplier identity</span>
</div>

<div>
<label class="label">Company Name *</label>
<input class="input" name="company_name" required placeholder="Example: Kashmir Holidays DMC">
</div>

<div>
<label class="label">Supplier Type *</label>
<select name="supplier_type" required>
<option value="">Select Supplier Type</option>
<option value="DMC">DMC / Tour Operator</option>
<option value="Hotel">Hotel / Hotel Group</option>
<option value="Transporter">Transporter</option>
<option value="Visa Partner">Visa Partner</option>
<option value="Insurance Partner">Insurance Partner</option>
<option value="Flight Consolidator">Flight Consolidator</option>
<option value="Activity Supplier">Activity / Ticket Supplier</option>
<option value="Other">Other</option>
</select>
</div>

<div>
<label class="label">Legal Name</label>
<input class="input" name="legal_name">
</div>

<div>
<label class="label">GSTIN</label>
<input class="input" name="gstin" autocomplete="off">
</div>


<div class="full supplier-geo-panel">
    <div class="supplier-geo-heading">
        <div>
            <strong><i class="fa-solid fa-location-crosshairs"></i> Office Location</strong>
            <span>Country → State/Region → District/City</span>
        </div>
        <span class="supplier-geo-badge"><i class="fa-solid fa-wand-magic-sparkles"></i> Smart Select</span>
    </div>

    <div class="supplier-geo-grid">

        <div class="supplier-geo-card supplier-country-card">
            <span class="supplier-geo-number">1</span>
            <label class="label">Country</label>
            <select class="input" name="country" id="supplierGeoCountry">
                <option value="">Loading countries...</option>
            </select>
            <small>All countries are loaded automatically.</small>
        </div>

        <div class="supplier-geo-card supplier-state-card">
            <span class="supplier-geo-number">2</span>
            <label class="label">State / Region</label>
            <select class="input" name="state_region" id="supplierGeoState" disabled>
                <option value="">Select country first</option>
            </select>
            <small>Only states under the selected country appear.</small>
        </div>

        <div class="supplier-geo-card supplier-city-card">
            <span class="supplier-geo-number">3</span>
            <label class="label">District / City</label>
            <select class="input" name="city" id="supplierGeoCity" disabled>
                <option value="">Select state first</option>
            </select>
            <small>Only locations under the selected state appear.</small>
        </div>

    </div>

    <div class="supplier-geo-path" id="supplierGeoPath">
        <i class="fa-solid fa-route"></i> Select a country to begin.
    </div>
</div>


<div>
<label class="label">Website</label>
<input class="input" type="url" name="website" placeholder="https://...">
</div>

<div class="full" style="padding:14px 0 2px">
<strong>2. PRIMARY CONTACT</strong>
<span class="muted" style="margin-left:8px">Used first for supplier sourcing</span>
</div>

<div>
<label class="label">Contact Person *</label>
<input class="input" name="primary_contact_name" required placeholder="Sales contact name">
</div>

<div>
<label class="label">Mobile</label>
<input class="input" name="primary_contact_mobile" inputmode="tel">
</div>

<div>
<label class="label">WhatsApp</label>
<input class="input" name="primary_contact_whatsapp" inputmode="tel">
</div>

<div>
<label class="label">Email</label>
<input class="input" type="email" name="primary_contact_email">
</div>

<div class="full" style="padding:14px 0 2px">
<strong>3. DESTINATIONS HANDLED *</strong>
<span class="muted" style="margin-left:8px">Choose from Travscope Destination Master — no typing</span>
</div>

<div class="full">
<div style="display:flex;gap:8px;align-items:center;margin-bottom:8px">
<input class="input" type="search" id="destinationSearch" placeholder="Search Kashmir, Bali, Dubai..." style="max-width:380px">
<span class="muted" id="destinationSelectedCount">0 selected</span>
</div>
<div id="destinationChooser" style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;max-height:230px;overflow:auto;border:1px solid #e1e7ee;border-radius:12px;padding:10px">
<?php foreach ($destinationOptions as $destination): ?>
<label class="destination-choice" data-search="<?= supplierE(strtolower((string)$destination['name'].' '.(string)$destination['country'])) ?>" style="border:1px solid #e7ebf0;border-radius:9px;padding:9px;cursor:pointer">
<input type="checkbox" name="destination_ids[]" value="<?= (int)$destination['id'] ?>">
<strong><?= supplierE((string)$destination['name']) ?></strong>
<?php if (!empty($destination['country'])): ?>
<br><span class="muted"><?= supplierE((string)$destination['country']) ?></span>
<?php endif; ?>
</label>
<?php endforeach; ?>
</div>
</div>

<div class="full" style="padding:14px 0 2px">
<strong>4. SERVICES PROVIDED *</strong>
<span class="muted" style="margin-left:8px">Used to suggest the right supplier for the right requirement</span>
</div>

<div class="full" style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px">
<?php foreach ($serviceOptions as $service): ?>
<label style="border:1px solid #e7ebf0;border-radius:9px;padding:10px;cursor:pointer">
<input type="checkbox" name="service_ids[]" value="<?= (int)$service['id'] ?>">
<?= supplierE((string)$service['service_name']) ?>
</label>
<?php endforeach; ?>
</div>

<div class="full" style="padding:14px 0 2px">
<strong>5. COMMERCIAL / INTERNAL</strong>
</div>

<div>
<label class="label">Priority</label>
<select name="priority">
<option value="preferred">Preferred</option>
<option value="regular" selected>Regular</option>
<option value="backup">Backup</option>
</select>
</div>

<div>
<label class="label">Internal Rating</label>
<input class="input" type="number" name="internal_rating" min="0" max="5" step=".1" placeholder="0 - 5">
</div>

<div class="full">
<label class="label">Address</label>
<textarea name="address"></textarea>
</div>

<div class="full">
<label class="label">Payment Terms</label>
<textarea name="payment_terms" placeholder="Example: 30% advance, balance 7 days before arrival"></textarea>
</div>

<div class="full">
<label class="label">Cancellation Terms</label>
<textarea name="cancellation_terms"></textarea>
</div>

<div class="full">
<label class="label">Internal Notes</label>
<textarea name="notes"></textarea>
</div>

<div>
<label class="label">Status</label>
<select name="status">
<option value="active">Active</option>
<option value="inactive">Inactive</option>
</select>
</div>

<div style="display:flex;align-items:end;justify-content:flex-end;gap:8px">
<button type="button" class="btn" onclick="closeSupplierModal()">Cancel</button>
<button class="btn btn-primary">
<i class="fa-solid fa-floppy-disk"></i> Save Complete Supplier
</button>
</div>

</div>
</form>
</div>
</div>

<script>
function openSupplierModal(){document.getElementById('supplierModal').classList.add('open');supplierGeoLoadCountries();}
function closeSupplierModal(){document.getElementById('supplierModal').classList.remove('open')}
document.getElementById('supplierModal').addEventListener('click',function(e){if(e.target===this)closeSupplierModal()});

const destinationSearch=document.getElementById('destinationSearch');
const destinationChoices=[...document.querySelectorAll('.destination-choice')];
const destinationCounter=document.getElementById('destinationSelectedCount');

function updateDestinationCount(){
    const selected=document.querySelectorAll('input[name="destination_ids[]"]:checked').length;
    destinationCounter.textContent=selected+' selected';
}
destinationChoices.forEach(label=>{
    const box=label.querySelector('input[type="checkbox"]');
    box.addEventListener('change',updateDestinationCount);
});
destinationSearch?.addEventListener('input',function(){
    const q=this.value.trim().toLowerCase();
    destinationChoices.forEach(label=>{
        label.style.display=label.dataset.search.includes(q)?'block':'none';
    });
});
document.getElementById('supplierCreateForm')?.addEventListener('submit',function(e){
    if(!document.querySelector('input[name="destination_ids[]"]:checked')){
        e.preventDefault();
        alert('Select at least one destination handled by this supplier.');
        return;
    }
    if(!document.querySelector('input[name="service_ids[]"]:checked')){
        e.preventDefault();
        alert('Select at least one service provided by this supplier.');
    }
});


const supplierGeoCountry=document.getElementById('supplierGeoCountry');
const supplierGeoState=document.getElementById('supplierGeoState');
const supplierGeoCity=document.getElementById('supplierGeoCity');
const supplierGeoPath=document.getElementById('supplierGeoPath');
let supplierGeoLoaded=false;

function supplierGeoSetOptions(select,values,placeholder){
    select.innerHTML='';
    const first=document.createElement('option');
    first.value='';
    first.textContent=placeholder;
    select.appendChild(first);

    values.forEach(value=>{
        const option=document.createElement('option');
        option.value=value;
        option.textContent=value;
        select.appendChild(option);
    });
}

async function supplierGeoGet(action,params={}){
    const url=new URL('admin-suppliers.php',window.location.href);
    url.searchParams.set('geo_ajax',action);

    Object.entries(params).forEach(([key,value])=>{
        url.searchParams.set(key,value);
    });

    const response=await fetch(url.toString(),{
        headers:{'Accept':'application/json'}
    });

    const data=await response.json().catch(()=>null);

    if(!response.ok || !data || data.success!==true){
        throw new Error(data?.message || 'Unable to load location information.');
    }

    return Array.isArray(data.data) ? data.data : [];
}

function supplierGeoUpdatePath(){
    const parts=[
        supplierGeoCountry?.value,
        supplierGeoState?.value,
        supplierGeoCity?.value
    ].filter(Boolean);

    if(supplierGeoPath){
        supplierGeoPath.innerHTML='<i class="fa-solid fa-route"></i> '
            +(parts.length ? parts.join(' → ') : 'Select a country to begin.');
    }
}

async function supplierGeoLoadCountries(){
    if(!supplierGeoCountry || supplierGeoLoaded) return;

    supplierGeoCountry.disabled=true;
    supplierGeoSetOptions(supplierGeoCountry,[],'Loading countries...');

    try{
        const countries=await supplierGeoGet('countries');
        supplierGeoSetOptions(supplierGeoCountry,countries,'Select Country');
        supplierGeoCountry.disabled=false;
        supplierGeoLoaded=true;
    }catch(error){
        supplierGeoSetOptions(supplierGeoCountry,[],'Unable to load countries');
        if(supplierGeoPath) supplierGeoPath.textContent=error.message;
    }
}

async function supplierGeoLoadStates(){
    supplierGeoSetOptions(supplierGeoState,[],'Loading states...');
    supplierGeoSetOptions(supplierGeoCity,[],'Select state first');
    supplierGeoState.disabled=true;
    supplierGeoCity.disabled=true;

    if(!supplierGeoCountry.value){
        supplierGeoSetOptions(supplierGeoState,[],'Select country first');
        supplierGeoUpdatePath();
        return;
    }

    try{
        const states=await supplierGeoGet('states',{
            country:supplierGeoCountry.value
        });

        supplierGeoSetOptions(
            supplierGeoState,
            states,
            states.length ? 'Select State / Region' : 'No states returned'
        );

        supplierGeoState.disabled=states.length===0;
        supplierGeoUpdatePath();
    }catch(error){
        supplierGeoSetOptions(supplierGeoState,[],'Unable to load states');
        if(supplierGeoPath) supplierGeoPath.textContent=error.message;
    }
}

async function supplierGeoLoadCities(){
    supplierGeoSetOptions(supplierGeoCity,[],'Loading district/city...');
    supplierGeoCity.disabled=true;

    if(!supplierGeoState.value){
        supplierGeoSetOptions(supplierGeoCity,[],'Select state first');
        supplierGeoUpdatePath();
        return;
    }

    try{
        const cities=await supplierGeoGet('cities',{
            country:supplierGeoCountry.value,
            state:supplierGeoState.value
        });

        supplierGeoSetOptions(
            supplierGeoCity,
            cities,
            cities.length ? 'Select District / City' : 'No city/locality returned'
        );

        supplierGeoCity.disabled=cities.length===0;
        supplierGeoUpdatePath();
    }catch(error){
        supplierGeoSetOptions(supplierGeoCity,[],'Unable to load cities');
        if(supplierGeoPath) supplierGeoPath.textContent=error.message;
    }
}

supplierGeoCountry?.addEventListener('change',supplierGeoLoadStates);
supplierGeoState?.addEventListener('change',supplierGeoLoadCities);
supplierGeoCity?.addEventListener('change',supplierGeoUpdatePath);

</script>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
