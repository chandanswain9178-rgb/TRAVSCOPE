TRAVSCOPE V24.96 — International Quotation Print + Gallery
Built from V24.95.

CUSTOMER QUOTATION / PDF
- Print/PDF presentation is stabilised for A4 with fixed print measurements, print-safe page width, preserved colours and stronger break control.
- Browser Print / Save as PDF and server-side quotation PDF use the same print presentation.
- Headless Chrome PDF output disables browser PDF header/footer.
- Package feature image is now a large full-width hero image.
- Package short description and Package Overview use professional justified typography.
- Journey Gallery automatically uses unique itinerary images already stored in the quotation snapshot; no new database field is required.
- Customer name, mobile and email are highlighted in a dedicated customer panel.
- A permanent quotation reference is shown prominently: TSQ-{lead}-V{version}.
- Quotation version and preparation date are shown next to the reference for amendment/correspondence tracking.
- Company office/registered address is shown in the quotation header and footer when configured.
- Removed the quotation-specific "Memorable Hospitality Pvt. Ltd." hard-coded name. Quotations now use the configured TRAVSCOPE Website Name / site name.

TRUST / CREDENTIAL LOGOS
- New General Settings group: Quotation Trust & Credentials.
- Up to 4 optional credential/association marks can be configured using a label plus image path/URL.
- Example labels may include Odisha Tourism, Chhattisgarh Tourism, MSME, etc., but the system does NOT show any mark unless the administrator explicitly configures both its label and logo.
- This prevents an unauthorised or accidental affiliation claim.
- The configured marks render in a clean Recognitions & Associations strip near the quotation footer.

PRINT RELIABILITY
- A4 portrait @page rules use millimetre-based dimensions.
- Screen-only responsive widths do not control printed page width.
- Hero/customer summary/gallery/credential/footer blocks avoid internal page breaks.
- Pricing tables use stable table layout and repeating headers.
- Paragraph widows/orphans are improved for more professional pagination.

FILES CHANGED
- admin-crm.php
- admin-settings.php

DATABASE
No SQL required. Existing settings storage is reused.
