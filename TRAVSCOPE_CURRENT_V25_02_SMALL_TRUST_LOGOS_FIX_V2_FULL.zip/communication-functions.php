<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — CUSTOMER COMMUNICATION & AUTOMATION CENTER
|--------------------------------------------------------------------------
| Post-booking communication is stored separately from the immutable CRM
| quotation conversation. The Admin timeline merges both sources read-only.
|--------------------------------------------------------------------------
*/

$tsCommBillingFunctionsFile = __DIR__ . '/billing-functions.php';
if (is_file($tsCommBillingFunctionsFile) && !function_exists('tsBillPaymentCollectionUrl')) {
    require_once $tsCommBillingFunctionsFile;
}

$tsCommSystemSettingsFile = __DIR__ . '/system-settings-functions.php';
if (
    is_file($tsCommSystemSettingsFile)
    && !function_exists('tsSystemSettingInt')
) {
    require_once $tsCommSystemSettingsFile;
}

function tsCommTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];
    $key = strtolower($table);
    if (array_key_exists($key, $cache)) return $cache[$key];

    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
        $stmt->execute([$table]);
        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}

function tsCommReady(PDO $pdo): bool
{
    return tsCommTableExists($pdo, 'bookings')
        && tsCommTableExists($pdo, 'booking_communications')
        && tsCommTableExists($pdo, 'booking_communication_templates')
        && tsCommTableExists($pdo, 'booking_communication_jobs');
}

function tsCommBooking(PDO $pdo, int $bookingId): array
{
    $stmt = $pdo->prepare("SELECT b.*, p.title AS package_title, d.name AS package_destination FROM bookings b LEFT JOIN packages p ON p.id=b.package_id LEFT JOIN destinations d ON d.id=p.destination_id WHERE b.id=? LIMIT 1");
    $stmt->execute([$bookingId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    if (!$row) throw new RuntimeException('Booking was not found.');
    return $row;
}

function tsCommTripContext(PDO $pdo, int $bookingId): array
{
    $context = [
        'trip_id' => null,
        'trip_code' => '',
        'quotation_version_id' => null,
        'lead_id' => null,
        'owner_admin_id' => null,
        'owner_name' => '',
        'destination_name' => '',
        'package_title' => '',
    ];

    if (tsCommTableExists($pdo, 'booking_trip_links')) {
        $sql = "SELECT l.trip_id,l.quotation_version_id,l.enquiry_id";
        $sql .= tsCommTableExists($pdo, 'trips') ? ",t.trip_code" : ",NULL AS trip_code";
        $sql .= " FROM booking_trip_links l";
        if (tsCommTableExists($pdo, 'trips')) $sql .= " LEFT JOIN trips t ON t.id=l.trip_id";
        $sql .= " WHERE l.booking_id=? LIMIT 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$bookingId]);
        if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $context['trip_id'] = !empty($row['trip_id']) ? (int)$row['trip_id'] : null;
            $context['trip_code'] = trim((string)($row['trip_code'] ?? ''));
            $context['quotation_version_id'] = !empty($row['quotation_version_id']) ? (int)$row['quotation_version_id'] : null;
            $context['lead_id'] = !empty($row['enquiry_id']) ? (int)$row['enquiry_id'] : null;
        }
    }

    if (tsCommTableExists($pdo, 'booking_quotation_snapshots')) {
        $stmt = $pdo->prepare("SELECT lead_id,quotation_version_id,package_title,destination_name FROM booking_quotation_snapshots WHERE booking_id=? LIMIT 1");
        $stmt->execute([$bookingId]);
        if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            if (!$context['lead_id'] && !empty($row['lead_id'])) $context['lead_id'] = (int)$row['lead_id'];
            if (!$context['quotation_version_id'] && !empty($row['quotation_version_id'])) $context['quotation_version_id'] = (int)$row['quotation_version_id'];
            $context['package_title'] = trim((string)($row['package_title'] ?? ''));
            $context['destination_name'] = trim((string)($row['destination_name'] ?? ''));
        }
    }

    if (!empty($context['lead_id']) && tsCommTableExists($pdo, 'crm_lead_meta')) {
        try {
            $sql = "SELECT m.assigned_admin_id";
            $sql .= tsCommTableExists($pdo, 'admins') ? ",a.name AS owner_name" : ",NULL AS owner_name";
            $sql .= " FROM crm_lead_meta m";
            if (tsCommTableExists($pdo, 'admins')) $sql .= " LEFT JOIN admins a ON a.id=m.assigned_admin_id";
            $sql .= " WHERE m.enquiry_id=? LIMIT 1";
            $stmt=$pdo->prepare($sql);
            $stmt->execute([(int)$context['lead_id']]);
            if($owner=$stmt->fetch(PDO::FETCH_ASSOC)){
                $context['owner_admin_id']=!empty($owner['assigned_admin_id'])?(int)$owner['assigned_admin_id']:null;
                $context['owner_name']=trim((string)($owner['owner_name'] ?? ''));
            }
        } catch (Throwable $e) {}
    }

    return $context;
}

function tsCommThreadTag(int $bookingId): string
{
    return '[TRAVSCOPE-BKG-' . $bookingId . ']';
}

function tsCommWhatsAppNumber(?string $mobile): string
{
    $digits = preg_replace('/\D+/', '', (string)$mobile) ?? '';
    if ($digits === '') return '';
    if (strlen($digits) === 10) $digits = '91' . $digits;
    return $digits;
}

function tsCommMoney(float $amount, string $currency='INR'): string
{
    return strtoupper(trim($currency) ?: 'INR') . ' ' . number_format(max(0, $amount), 2);
}

function tsCommDate(?string $value, string $format='d M Y'): string
{
    if (!$value) return 'Not set';
    $ts = strtotime($value);
    return $ts ? date($format, $ts) : 'Not set';
}

function tsCommTemplates(PDO $pdo, bool $activeOnly=true): array
{
    if (!tsCommReady($pdo)) return [];
    $sql = "SELECT * FROM booking_communication_templates";
    if ($activeOnly) $sql .= " WHERE is_active=1";
    $sql .= " ORDER BY is_system DESC, template_name ASC";
    return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function tsCommTemplate(PDO $pdo, string $key): ?array
{
    if (!tsCommReady($pdo) || trim($key)==='') return null;
    $stmt = $pdo->prepare("SELECT * FROM booking_communication_templates WHERE template_key=? LIMIT 1");
    $stmt->execute([$key]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsCommSaveTemplate(PDO $pdo, int $adminId, string $key, string $name, string $subject, string $body, bool $active): void
{
    if (!tsCommReady($pdo)) throw new RuntimeException('Communication Center SQL is not installed.');
    $key = trim($key);
    $name = trim($name);
    $body = trim($body);
    if ($key==='' || $name==='' || $body==='') throw new RuntimeException('Template key, name and message body are required.');
    if (!preg_match('/^[a-z0-9_-]{2,80}$/', $key)) throw new RuntimeException('Template key can use lowercase letters, numbers, hyphen and underscore only.');
    $stmt = $pdo->prepare("INSERT INTO booking_communication_templates (template_key,template_name,default_channel,subject_template,body_template,is_system,is_active,updated_by_admin_id) VALUES (?,?,'email',?,?,0,?,?) ON DUPLICATE KEY UPDATE template_name=VALUES(template_name),subject_template=VALUES(subject_template),body_template=VALUES(body_template),is_active=VALUES(is_active),updated_by_admin_id=VALUES(updated_by_admin_id),updated_at=NOW()");
    $stmt->execute([$key, mb_substr($name,0,190), mb_substr(trim($subject),0,255), $body, $active?1:0, $adminId ?: null]);
}

function tsCommEnsureAutomationTemplates(PDO $pdo): void
{
    if (!tsCommTableExists($pdo, 'booking_communication_templates')) return;

    try {
        $stmt = $pdo->prepare("\n            INSERT IGNORE INTO booking_communication_templates\n            (template_key,template_name,default_channel,subject_template,body_template,is_system,is_active)\n            VALUES\n            ('travel_document_attention','Passport / Travel Document Validity Alert','email',\n             'Travel document needs attention · Booking {{booking_number}}',\n             'Dear {{customer_name}},\\n\\nA travel document linked to Booking {{booking_number}} needs attention.\\n\\nDocument: {{requirement_label}}\\nExpiry: {{document_expiry}}\\nStatus: {{document_validity_message}}\\n\\nPlease review/update your traveller documents here:\\n{{documents_link}}\\n\\nDestination entry and passport-validity rules can vary, so TRAVSCOPE will verify the applicable requirement before travel.\\n\\nThank you,\\nTRAVSCOPE.COM',\n             1,1)\n        ");
        $stmt->execute();
    } catch (Throwable $e) {
        error_log('Communication automation template ensure: ' . $e->getMessage());
    }
}

function tsCommCurrentVoucher(PDO $pdo, int $bookingId): ?array
{
    if (!tsCommTableExists($pdo, 'booking_voucher_versions')) return null;
    $stmt = $pdo->prepare("SELECT id,version_number,voucher_code,finalized_at,created_at FROM booking_voucher_versions WHERE booking_id=? AND status='final' ORDER BY version_number DESC,id DESC LIMIT 1");
    $stmt->execute([$bookingId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsCommCurrentDocumentPack(PDO $pdo, int $bookingId): ?array
{
    if (function_exists('tsDocLatestCurrentFinalPack')) {
        try { return tsDocLatestCurrentFinalPack($pdo, $bookingId); } catch (Throwable $e) {}
    }
    if (!tsCommTableExists($pdo, 'booking_document_pack_versions')) return null;
    $stmt = $pdo->prepare("SELECT * FROM booking_document_pack_versions WHERE booking_id=? AND status='final' ORDER BY version_number DESC,id DESC LIMIT 1");
    $stmt->execute([$bookingId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsCommTemplateContext(PDO $pdo, int $bookingId, ?array $job=null): array
{
    $booking = tsCommBooking($pdo, $bookingId);
    $trip = tsCommTripContext($pdo, $bookingId);
    $voucher = tsCommCurrentVoucher($pdo, $bookingId);
    $pack = tsCommCurrentDocumentPack($pdo, $bookingId);

    $destination = trim((string)($trip['destination_name'] ?: ($booking['package_destination'] ?? '')));
    $packageTitle = trim((string)($trip['package_title'] ?: ($booking['package_title'] ?? 'Travel Booking')));
    $currency = strtoupper(trim((string)($booking['currency'] ?? 'INR')) ?: 'INR');
    $balance = max(0, (float)($booking['total_amount'] ?? 0) - (float)($booking['paid_amount'] ?? 0));

    $dueDate = 'Not set';
    $paymentLink = function_exists('tsBillPaymentCollectionUrl')
        ? tsBillPaymentCollectionUrl($bookingId, 0, 7)
        : BASE_URL . 'payment.php?booking=' . $bookingId;
    $requirementLabel = 'Traveller document';
    $documentExpiry = 'Not set';
    $documentValidityMessage = '';

    if ($job) {
        $sourceTable = (string)($job['source_table'] ?? '');
        $sourceId = (int)($job['source_id'] ?? 0);

        if ($sourceTable==='booking_payment_installments' && $sourceId>0 && tsCommTableExists($pdo,'booking_payment_installments')) {
            $stmt = $pdo->prepare("SELECT title,due_date,amount,paid_amount FROM booking_payment_installments WHERE id=? AND booking_id=? LIMIT 1");
            $stmt->execute([$sourceId,$bookingId]);
            if ($row=$stmt->fetch(PDO::FETCH_ASSOC)) {
                $balance = max(0,(float)$row['amount']-(float)$row['paid_amount']);
                $dueDate = tsCommDate($row['due_date'] ?? null);
                $paymentLink = function_exists('tsBillPaymentCollectionUrl')
                    ? tsBillPaymentCollectionUrl($bookingId, $sourceId, 7)
                    : BASE_URL . 'payment.php?booking=' . $bookingId . '&installment=' . $sourceId;
            }
        }

        if ($sourceTable==='booking_document_requirements' && tsCommTableExists($pdo,'booking_document_requirements')) {
            if ($sourceId>0) {
                $stmt = $pdo->prepare("SELECT r.document_type,t.full_name FROM booking_document_requirements r LEFT JOIN booking_travellers t ON t.id=r.traveller_id WHERE r.id=? AND r.booking_id=? LIMIT 1");
                $stmt->execute([$sourceId,$bookingId]);
                if ($row=$stmt->fetch(PDO::FETCH_ASSOC)) {
                    $requirementLabel = (string)$row['document_type'] . (!empty($row['full_name']) ? ' · ' . (string)$row['full_name'] : '');
                }
            } else {
                $stmt = $pdo->prepare("SELECT r.document_type,t.full_name FROM booking_document_requirements r LEFT JOIN booking_travellers t ON t.id=r.traveller_id WHERE r.booking_id=? AND r.is_required=1 AND r.status IN ('required','rejected') ORDER BY t.full_name,r.document_type LIMIT 20");
                $stmt->execute([$bookingId]);
                $labels=[];
                foreach($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row){
                    $labels[]=(string)$row['document_type'] . (!empty($row['full_name']) ? ' · ' . (string)$row['full_name'] : '');
                }
                if($labels)$requirementLabel=implode('; ',$labels);
            }
        }


        if ($sourceTable==='booking_travel_documents' && $sourceId>0 && tsCommTableExists($pdo,'booking_travel_documents')) {
            $stmt = $pdo->prepare("SELECT d.*,t.full_name FROM booking_travel_documents d LEFT JOIN booking_travellers t ON t.id=d.traveller_id WHERE d.id=? AND d.booking_id=? LIMIT 1");
            $stmt->execute([$sourceId,$bookingId]);
            if ($row=$stmt->fetch(PDO::FETCH_ASSOC)) {
                $requirementLabel = (string)$row['document_type'] . (!empty($row['full_name']) ? ' · ' . (string)$row['full_name'] : '');
                $documentExpiry = tsCommDate($row['expiry_date'] ?? null);
                if (function_exists('tsDocValidity')) {
                    try {
                        $risk = tsDocValidity($row,$booking);
                        $documentValidityMessage = (string)($risk['message'] ?? 'Please review this document.');
                    } catch (Throwable $e) {
                        $documentValidityMessage = 'Please review this document before travel.';
                    }
                } else {
                    $documentValidityMessage = 'Please review this document before travel.';
                }
            }
        }
    }

    return [
        '{{customer_name}}' => (string)($booking['customer_name'] ?? 'Traveller'),
        '{{booking_number}}' => (string)($booking['booking_number'] ?? ('Booking #' . $bookingId)),
        '{{trip_id}}' => (string)($trip['trip_code'] ?: '-'),
        '{{package_title}}' => $packageTitle !== '' ? $packageTitle : 'Travel Booking',
        '{{destination}}' => $destination !== '' ? $destination : 'your destination',
        '{{travel_date}}' => tsCommDate($booking['travel_date'] ?? null),
        '{{balance_due}}' => tsCommMoney($balance, $currency),
        '{{due_date}}' => $dueDate,
        '{{payment_link}}' => $paymentLink,
        '{{documents_link}}' => BASE_URL . 'booking-documents.php?booking=' . $bookingId,
        '{{booking_link}}' => BASE_URL . 'booking-details.php?id=' . $bookingId,
        '{{voucher_link}}' => $voucher ? BASE_URL . 'booking-voucher.php?voucher=' . (int)$voucher['id'] : 'Will be shared when finalized.',
        '{{document_pack_link}}' => $pack ? BASE_URL . 'booking-document-pack.php?pack=' . (int)$pack['id'] : 'Will be shared when finalized.',
        '{{review_link}}' => BASE_URL . 'reviews.php',
        '{{requirement_label}}' => $requirementLabel,
        '{{document_expiry}}' => $documentExpiry,
        '{{document_validity_message}}' => $documentValidityMessage,
        '{{support_email}}' => defined('MAIL_REPLY_TO') ? (string)MAIL_REPLY_TO : (defined('MAIL_FROM_ADDRESS') ? (string)MAIL_FROM_ADDRESS : ''),
    ];
}

function tsCommRenderTemplate(PDO $pdo, int $bookingId, string $templateKey, ?array $job=null): array
{
    $template = tsCommTemplate($pdo, $templateKey);
    if (!$template) throw new RuntimeException('Communication template was not found.');
    if (empty($template['is_active'])) throw new RuntimeException('Communication template is disabled.');
    $context = tsCommTemplateContext($pdo, $bookingId, $job);
    return [
        'subject' => strtr((string)($template['subject_template'] ?? ''), $context),
        'body' => strtr((string)$template['body_template'], $context),
        'template' => $template,
        'context' => $context,
    ];
}

function tsCommStore(PDO $pdo, int $bookingId, array $data): int
{
    $trip = tsCommTripContext($pdo, $bookingId);
    $messageId = trim((string)($data['message_id'] ?? ''));
    if ($messageId==='') $messageId = null;

    $stmt = $pdo->prepare("INSERT INTO booking_communications (booking_id,trip_id,quotation_version_id,direction,channel,sender_name,sender_email,recipient_name,recipient_email,recipient_mobile,subject,body_text,message_id,in_reply_to,delivery_status,template_key,scheduled_for,sent_at,meta_json,created_by_admin_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    $stmt->execute([
        $bookingId,
        $trip['trip_id'],
        $trip['quotation_version_id'],
        $data['direction'] ?? 'outbound',
        $data['channel'] ?? 'email',
        $data['sender_name'] ?? null,
        $data['sender_email'] ?? null,
        $data['recipient_name'] ?? null,
        $data['recipient_email'] ?? null,
        $data['recipient_mobile'] ?? null,
        mb_substr(trim((string)($data['subject'] ?? '')),0,255) ?: null,
        (string)($data['body_text'] ?? ''),
        $messageId,
        trim((string)($data['in_reply_to'] ?? '')) ?: null,
        $data['delivery_status'] ?? 'recorded',
        trim((string)($data['template_key'] ?? '')) ?: null,
        $data['scheduled_for'] ?? null,
        $data['sent_at'] ?? null,
        !empty($data['meta']) ? json_encode($data['meta'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : null,
        !empty($data['created_by_admin_id']) ? (int)$data['created_by_admin_id'] : null,
    ]);
    $id = (int)$pdo->lastInsertId();

    if (
        in_array((string)($data['direction'] ?? ''), ['outbound','inbound'], true)
        && !empty($trip['lead_id'])
        && tsCommTableExists($pdo, 'crm_lead_meta')
    ) {
        try {
            $pdo->prepare("UPDATE crm_lead_meta SET last_contact_at=NOW(),updated_at=NOW() WHERE enquiry_id=?")
                ->execute([(int)$trip['lead_id']]);
        } catch (Throwable $e) {
            error_log('Communication last_contact_at sync: ' . $e->getMessage());
        }
    }

    return $id;
}

function tsCommEmailHtml(string $body): string
{
    $escaped=htmlspecialchars($body,ENT_QUOTES,'UTF-8');
    $linked=preg_replace_callback(
        '~https?://[^\s<]+~i',
        static function($match){
            $url=(string)$match[0];
            return '<a href="'.$url.'" style="color:#2563eb">'.$url.'</a>';
        },
        $escaped
    );
    return nl2br($linked ?? $escaped);
}

function tsCommSendEmail(PDO $pdo, int $bookingId, string $subject, string $body, int $adminId=0, ?string $templateKey=null, ?array $meta=null): int
{
    if (!tsCommReady($pdo)) throw new RuntimeException('Communication Center SQL is not installed.');
    $booking = tsCommBooking($pdo,$bookingId);
    $to = trim((string)($booking['customer_email'] ?? ''));
    if (!filter_var($to,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Customer email is not available.');
    if (!class_exists('\\PHPMailer\\PHPMailer\\PHPMailer')) throw new RuntimeException('PHPMailer is unavailable.');

    $subject = trim($subject);
    $body = trim($body);
    if ($body==='') throw new RuntimeException('Message body is required.');
    $tag = tsCommThreadTag($bookingId);
    if (stripos($subject,$tag)===false) $subject = trim($subject . ' ' . $tag);
    if ($subject===$tag) $subject = 'TRAVSCOPE Booking ' . (string)$booking['booking_number'] . ' ' . $tag;

    $status='failed'; $sentAt=null; $error=''; $messageId=null;
    try {
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        if (defined('SMTP_ENABLED') && SMTP_ENABLED) {
            $mail->isSMTP();
            $mail->Host = defined('SMTP_HOST') ? SMTP_HOST : 'smtp.gmail.com';
            $mail->SMTPAuth = defined('SMTP_AUTH') ? (bool)SMTP_AUTH : true;
            $mail->Username = defined('SMTP_USERNAME') ? SMTP_USERNAME : '';
            $mail->Password = defined('SMTP_PASSWORD') ? SMTP_PASSWORD : '';
            $mail->Port = defined('SMTP_PORT') ? (int)SMTP_PORT : 587;
            if (defined('SMTP_ENCRYPTION') && trim((string)SMTP_ENCRYPTION)!=='') $mail->SMTPSecure = SMTP_ENCRYPTION;
        }
        $from = defined('MAIL_FROM_ADDRESS') ? (string)MAIL_FROM_ADDRESS : (defined('SMTP_USERNAME') ? (string)SMTP_USERNAME : '');
        $fromName = defined('MAIL_FROM_NAME') ? (string)MAIL_FROM_NAME : 'TRAVSCOPE.COM';
        $mail->setFrom($from,$fromName);
        if (defined('MAIL_REPLY_TO') && filter_var((string)MAIL_REPLY_TO,FILTER_VALIDATE_EMAIL)) $mail->addReplyTo((string)MAIL_REPLY_TO,$fromName);
        $mail->addAddress($to,(string)($booking['customer_name'] ?? 'Traveller'));
        $mail->CharSet='UTF-8';
        $mail->isHTML(true);
        $mail->Subject=$subject;
        $safeBody = tsCommEmailHtml($body);
        $mail->Body='<div style="font-family:Arial,sans-serif;color:#172033;line-height:1.65;white-space:normal">'.$safeBody.'</div>';
        $mail->AltBody=$body;
        $mail->send();
        $status='sent'; $sentAt=date('Y-m-d H:i:s');
        $messageId = trim((string)$mail->getLastMessageID()) ?: null;
    } catch (Throwable $e) {
        $error=$e->getMessage();
        error_log('TRAVSCOPE Booking Communication Email: '.$error);
    }

    $id = tsCommStore($pdo,$bookingId,[
        'direction'=>'outbound','channel'=>'email','sender_name'=>defined('MAIL_FROM_NAME')?(string)MAIL_FROM_NAME:'TRAVSCOPE.COM',
        'sender_email'=>defined('MAIL_FROM_ADDRESS')?(string)MAIL_FROM_ADDRESS:null,'recipient_name'=>(string)($booking['customer_name'] ?? ''),
        'recipient_email'=>$to,'subject'=>$subject,'body_text'=>$body,'message_id'=>$messageId,'delivery_status'=>$status,
        'template_key'=>$templateKey,'sent_at'=>$sentAt,'created_by_admin_id'=>$adminId,'meta'=>array_merge($meta ?? [], $error!==''?['error'=>$error]:[]),
    ]);
    if ($status!=='sent') throw new RuntimeException('Customer email could not be sent. ' . ($error!=='' ? $error : 'Check SMTP configuration.'));
    return $id;
}

function tsCommRecordWhatsApp(PDO $pdo, int $bookingId, string $body, int $adminId=0, ?string $templateKey=null): array
{
    $booking = tsCommBooking($pdo,$bookingId);
    $body=trim($body);
    if ($body==='') throw new RuntimeException('WhatsApp message is required.');
    $number=tsCommWhatsAppNumber($booking['customer_mobile'] ?? '');
    if ($number==='') throw new RuntimeException('Customer mobile number is not available for WhatsApp.');
    $id=tsCommStore($pdo,$bookingId,[
        'direction'=>'outbound','channel'=>'whatsapp','sender_name'=>'TRAVSCOPE.COM','recipient_name'=>(string)($booking['customer_name'] ?? ''),
        'recipient_mobile'=>(string)($booking['customer_mobile'] ?? ''),'body_text'=>$body,'delivery_status'=>'handed_off','template_key'=>$templateKey,
        'sent_at'=>date('Y-m-d H:i:s'),'created_by_admin_id'=>$adminId,
        'meta'=>['audit_note'=>'WhatsApp Web/App handoff recorded; TRAVSCOPE cannot independently verify delivery without a WhatsApp API connection.'],
    ]);
    return ['id'=>$id,'url'=>'https://wa.me/'.$number.'?text='.rawurlencode($body)];
}

function tsCommRecordInboundWhatsApp(PDO $pdo, int $bookingId, string $body, int $adminId=0): int
{
    $booking = tsCommBooking($pdo,$bookingId);
    $body=trim($body);
    if ($body==='') throw new RuntimeException('Customer WhatsApp reply text is required.');
    return tsCommStore($pdo,$bookingId,[
        'direction'=>'inbound','channel'=>'whatsapp','sender_name'=>(string)($booking['customer_name'] ?? 'Customer'),
        'recipient_name'=>'TRAVSCOPE.COM','recipient_mobile'=>null,'body_text'=>$body,'delivery_status'=>'received',
        'sent_at'=>date('Y-m-d H:i:s'),'created_by_admin_id'=>$adminId,
        'meta'=>['audit_note'=>'Customer WhatsApp reply manually recorded by Admin.'],
    ]);
}

function tsCommInternalNote(PDO $pdo, int $bookingId, string $body, int $adminId=0): int
{
    $body=trim($body);
    if ($body==='') throw new RuntimeException('Internal note is required.');
    return tsCommStore($pdo,$bookingId,[
        'direction'=>'internal','channel'=>'internal','sender_name'=>'Admin','body_text'=>$body,'delivery_status'=>'recorded','sent_at'=>date('Y-m-d H:i:s'),'created_by_admin_id'=>$adminId,
    ]);
}

function tsCommDecodeImapHeader(string $value): string
{
    if ($value==='' || !function_exists('imap_mime_header_decode')) return $value;
    $parts=@imap_mime_header_decode($value);
    if (!is_array($parts)) return $value;
    $out='';
    foreach($parts as $part){
        $chunk=(string)($part->text ?? '');
        $charset=strtoupper((string)($part->charset ?? 'DEFAULT'));
        if ($charset!=='DEFAULT' && $charset!=='UTF-8' && function_exists('mb_convert_encoding')) $chunk=@mb_convert_encoding($chunk,'UTF-8',$charset) ?: $chunk;
        $out.=$chunk;
    }
    return trim($out);
}

function tsCommImapText($imap, int $messageNo, $structure, string $partNumber=''): string
{
    if (!$structure) return '';
    $type=(int)($structure->type ?? 0); $subtype=strtoupper((string)($structure->subtype ?? ''));
    if ($type===0 && in_array($subtype,['PLAIN','HTML'],true)) {
        $body=$partNumber!=='' ? @imap_fetchbody($imap,$messageNo,$partNumber,FT_PEEK) : @imap_body($imap,$messageNo,FT_PEEK);
        $body=(string)$body; $encoding=(int)($structure->encoding ?? 0);
        if ($encoding===3) { $d=base64_decode($body,true); if($d!==false)$body=$d; }
        elseif($encoding===4) $body=quoted_printable_decode($body);
        if ($subtype==='HTML') {
            $body=preg_replace('/<(br|br\/|p|div|li)[^>]*>/i',"\n",$body) ?? $body;
            $body=html_entity_decode(strip_tags($body),ENT_QUOTES|ENT_HTML5,'UTF-8');
        }
        return trim(preg_replace("/\n{3,}/","\n\n",str_replace(["\r\n","\r"],"\n",$body)) ?? $body);
    }
    if (!empty($structure->parts) && is_array($structure->parts)) {
        $plain=''; $html='';
        foreach($structure->parts as $i=>$part){
            $child=$partNumber===''?(string)($i+1):$partNumber.'.'.($i+1);
            $content=tsCommImapText($imap,$messageNo,$part,$child);
            if($content==='')continue;
            $st=strtoupper((string)($part->subtype ?? ''));
            if($st==='PLAIN')$plain.=($plain!==''?"\n\n":'').$content;
            elseif($st==='HTML')$html.=($html!==''?"\n\n":'').$content;
            elseif($plain==='')$plain=$content;
        }
        return trim($plain!==''?$plain:$html);
    }
    return '';
}

function tsCommSyncEmailReplies(PDO $pdo, int $bookingId): array
{
    $result=['available'=>false,'synced'=>0,'message'=>''];
    if (!tsCommReady($pdo)) { $result['message']='Communication Center SQL is not installed.'; return $result; }
    if (!function_exists('imap_open') || !defined('SMTP_USERNAME') || !defined('SMTP_PASSWORD') || trim((string)SMTP_USERNAME)==='' || trim((string)SMTP_PASSWORD)==='') {
        $result['message']='Incoming email reply sync requires PHP IMAP and the configured mailbox credentials.'; return $result;
    }
    $booking=tsCommBooking($pdo,$bookingId);
    $email=trim((string)($booking['customer_email'] ?? ''));
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)){ $result['message']='Customer email is not available.'; return $result; }
    $mailbox=defined('IMAP_MAILBOX') && trim((string)IMAP_MAILBOX)!=='' ? (string)IMAP_MAILBOX : '{imap.gmail.com:993/imap/ssl}INBOX';
    $imap=@imap_open($mailbox,(string)SMTP_USERNAME,(string)SMTP_PASSWORD,0,1);
    if($imap===false){ $result['message']='Could not connect to the communication inbox. Enable PHP IMAP / mailbox access.'; return $result; }
    $result['available']=true;
    try{
        $stmt=$pdo->prepare("SELECT MIN(COALESCE(sent_at,created_at)) FROM booking_communications WHERE booking_id=? AND channel='email'");
        $stmt->execute([$bookingId]);
        $since=(string)($stmt->fetchColumn() ?: ($booking['created_at'] ?? ''));
        $sinceTs=$since!==''?strtotime($since):false; if(!$sinceTs)$sinceTs=strtotime('-120 days');
        $criteria='FROM "'.addcslashes($email,'\\"').'" SINCE "'.date('d-M-Y',$sinceTs).'"';
        $uids=@imap_search($imap,$criteria,SE_UID);
        if(!is_array($uids)) return $result;
        $tag=tsCommThreadTag($bookingId);
        $bookingNumber=trim((string)($booking['booking_number'] ?? ''));
        $tripContext=tsCommTripContext($pdo,$bookingId);
        $quoteTag=!empty($tripContext['quotation_version_id'])
            ? '[TRAVSCOPE-QV-' . (int)$tripContext['quotation_version_id'] . ']'
            : '';
        foreach($uids as $uid){
            $no=@imap_msgno($imap,(int)$uid); if(!$no)continue;
            $overviewList=@imap_fetch_overview($imap,(string)$no,0); $ov=is_array($overviewList)&&isset($overviewList[0])?$overviewList[0]:null; if(!$ov)continue;
            $subject=tsCommDecodeImapHeader((string)($ov->subject ?? ''));
            $isQuoteReply=$quoteTag!=='' && stripos($subject,$quoteTag)!==false;
            $isBookingReply=stripos($subject,$tag)!==false || ($bookingNumber!=='' && stripos($subject,$bookingNumber)!==false);
            if(!$isQuoteReply && !$isBookingReply)continue;

            $header=@imap_headerinfo($imap,$no);
            $messageId=trim((string)($header->message_id ?? ($ov->message_id ?? '')));
            if($messageId==='')$messageId='imap-booking-'.$bookingId.'-uid-'.$uid;
            $body=tsCommImapText($imap,$no,@imap_fetchstructure($imap,$no));
            if($body==='')$body='(Customer email reply had no readable text body.)';
            $sentAt=!empty($ov->date) && strtotime((string)$ov->date) ? date('Y-m-d H:i:s',strtotime((string)$ov->date)) : date('Y-m-d H:i:s');

            if (
                $isQuoteReply
                && tsCommTableExists($pdo,'crm_quotation_messages')
                && !empty($tripContext['quotation_version_id'])
                && !empty($tripContext['lead_id'])
            ) {
                $stmt=$pdo->prepare("SELECT id FROM crm_quotation_messages WHERE message_id=? LIMIT 1");
                $stmt->execute([$messageId]);
                if($stmt->fetchColumn())continue;

                $stmt=$pdo->prepare("INSERT INTO crm_quotation_messages (lead_id,version_id,direction,sender_email,recipient_email,subject,body_text,message_id,in_reply_to,sent_at) VALUES (?,?,'inbound',?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE subject=VALUES(subject),body_text=VALUES(body_text),in_reply_to=VALUES(in_reply_to),sent_at=VALUES(sent_at)");
                $stmt->execute([
                    (int)$tripContext['lead_id'],
                    (int)$tripContext['quotation_version_id'],
                    $email,
                    defined('MAIL_FROM_ADDRESS')?(string)MAIL_FROM_ADDRESS:null,
                    $subject,
                    $body,
                    $messageId,
                    (string)($header->in_reply_to ?? ''),
                    $sentAt,
                ]);
                $result['synced']++;
                continue;
            }

            $stmt=$pdo->prepare("SELECT id FROM booking_communications WHERE message_id=? LIMIT 1");
            $stmt->execute([$messageId]);
            if($stmt->fetchColumn())continue;

            tsCommStore($pdo,$bookingId,[
                'direction'=>'inbound','channel'=>'email','sender_name'=>(string)($booking['customer_name'] ?? 'Customer'),'sender_email'=>$email,
                'recipient_email'=>defined('MAIL_FROM_ADDRESS')?(string)MAIL_FROM_ADDRESS:null,'subject'=>$subject,'body_text'=>$body,'message_id'=>$messageId,
                'in_reply_to'=>(string)($header->in_reply_to ?? ''),'delivery_status'=>'received','sent_at'=>$sentAt,'meta'=>['imap_uid'=>(int)$uid],
            ]);
            $result['synced']++;
        }
    } finally { @imap_close($imap); }
    $result['message']=$result['synced']>0 ? $result['synced'].' new customer email repl'.($result['synced']===1?'y':'ies').' synchronized.' : 'No new Booking email replies found.';
    return $result;
}

function tsCommSplitQuotedReply(string $body): array
{
    $body=trim(str_replace(["\r\n","\r"],"\n",$body));
    $patterns=[
        '/^On .+ wrote:\s*$/mi',
        '/^-{2,}\s*On .+ wrote\s*-{2,}\s*$/mi',
        '/^-{2,}\s*Original Message\s*-{2,}\s*$/mi',
        '/^From:\s.+\nSent:\s.+\nTo:\s.+\nSubject:\s.+$/mi',
    ];
    $pos=null;
    foreach($patterns as $pattern){
        if(preg_match($pattern,$body,$m,PREG_OFFSET_CAPTURE)){
            $p=(int)$m[0][1]; if($pos===null||$p<$pos)$pos=$p;
        }
    }
    if($pos===null) return ['current'=>$body,'quoted'=>''];
    return ['current'=>trim(substr($body,0,$pos)),'quoted'=>trim(substr($body,$pos))];
}

function tsCommBookingMessages(PDO $pdo, int $bookingId): array
{
    if(!tsCommReady($pdo))return[];
    $stmt=$pdo->prepare("SELECT * FROM booking_communications WHERE booking_id=? ORDER BY COALESCE(sent_at,created_at) ASC,id ASC");
    $stmt->execute([$bookingId]);
    $rows=$stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    foreach($rows as &$row){ $row['source']='booking'; $row['timeline_at']=$row['sent_at'] ?: $row['created_at']; }
    unset($row);
    return $rows;
}

function tsCommQuotationMessages(PDO $pdo, int $bookingId): array
{
    if(!tsCommTableExists($pdo,'crm_quotation_messages'))return[];
    $trip=tsCommTripContext($pdo,$bookingId);
    if(empty($trip['quotation_version_id']))return[];
    $stmt=$pdo->prepare("SELECT * FROM crm_quotation_messages WHERE version_id=? ORDER BY sent_at ASC,id ASC");
    $stmt->execute([(int)$trip['quotation_version_id']]);
    $rows=$stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    foreach($rows as &$row){
        $row['source']='quotation'; $row['timeline_at']=$row['sent_at']; $row['channel']='email'; $row['delivery_status']=$row['direction']==='inbound'?'received':'sent';
    }
    unset($row);
    return $rows;
}

function tsCommTimeline(PDO $pdo, int $bookingId, bool $includeInternal=true): array
{
    $rows=array_merge(tsCommQuotationMessages($pdo,$bookingId),tsCommBookingMessages($pdo,$bookingId));
    if(!$includeInternal)$rows=array_values(array_filter($rows,static function($row){
        if((string)($row['direction']??'')==='internal') return false;
        if((string)($row['channel']??'')==='whatsapp' && (string)($row['delivery_status']??'')==='handed_off') return false;
        return true;
    }));
    usort($rows,static function($a,$b){ $at=strtotime((string)($a['timeline_at']??''))?:0; $bt=strtotime((string)($b['timeline_at']??''))?:0; return $at<=>$bt ?: ((int)($a['id']??0)<=> (int)($b['id']??0)); });
    return $rows;
}

function tsCommUpsertJob(PDO $pdo, int $bookingId, string $jobKey, string $jobType, string $templateKey, string $dueAt, ?string $sourceTable=null, ?int $sourceId=null): void
{
    $trip=tsCommTripContext($pdo,$bookingId);
    $stmt=$pdo->prepare("INSERT INTO booking_communication_jobs (booking_id,trip_id,owner_admin_id,job_key,job_type,template_key,channel,due_at,status,source_table,source_id) VALUES (?,?,?,?,?,?,'email',?,'pending',?,?) ON DUPLICATE KEY UPDATE trip_id=VALUES(trip_id),owner_admin_id=VALUES(owner_admin_id),due_at=VALUES(due_at),source_table=VALUES(source_table),source_id=VALUES(source_id),status=CASE WHEN status IN ('sent','skipped') THEN status WHEN status='cancelled' THEN 'pending' ELSE status END,updated_at=NOW()");
    $stmt->execute([$bookingId,$trip['trip_id'],$trip['owner_admin_id'],$jobKey,$jobType,$templateKey,$dueAt,$sourceTable,$sourceId]);
}

function tsCommRefreshJobs(PDO $pdo, int $bookingId): void
{
    if(!tsCommReady($pdo))return;
    tsCommEnsureAutomationTemplates($pdo);

    $booking=tsCommBooking($pdo,$bookingId);
    $status=strtolower((string)($booking['booking_status'] ?? ''));
    if($status==='cancelled'){
        $pdo->prepare("UPDATE booking_communication_jobs SET status='cancelled',updated_at=NOW() WHERE booking_id=? AND status IN ('pending','failed')")->execute([$bookingId]);
        return;
    }

    $activeKeys=[];

    $autoPayment = function_exists('tsSystemSettingBool') ? tsSystemSettingBool($pdo,'ops_auto_payment_reminders',true) : true;
    $paymentReminderDays = function_exists('tsSystemSettingInt') ? tsSystemSettingInt($pdo,'ops_payment_reminder_days_before',3) : 3;
    $paymentOverdueDays = function_exists('tsSystemSettingInt') ? tsSystemSettingInt($pdo,'ops_payment_overdue_days_after',1) : 1;
    $repeatOverduePayments = function_exists('tsSystemSettingBool') ? tsSystemSettingBool($pdo,'ops_repeat_overdue_payment_reminders',false) : false;
    $paymentOverdueRepeatDays = function_exists('tsSystemSettingInt') ? tsSystemSettingInt($pdo,'ops_payment_overdue_repeat_days',3) : 3;
    $paymentOverdueMax = function_exists('tsSystemSettingInt') ? tsSystemSettingInt($pdo,'ops_payment_overdue_max_emails',3) : 3;

    $autoDocuments = function_exists('tsSystemSettingBool') ? tsSystemSettingBool($pdo,'ops_auto_document_reminders',true) : true;
    $repeatMissingDocuments = function_exists('tsSystemSettingBool') ? tsSystemSettingBool($pdo,'ops_repeat_missing_document_reminders',false) : false;
    $documentRepeatDays = function_exists('tsSystemSettingInt') ? tsSystemSettingInt($pdo,'ops_document_reminder_repeat_days',2) : 2;
    $documentReminderMax = function_exists('tsSystemSettingInt') ? tsSystemSettingInt($pdo,'ops_document_reminder_max_emails',5) : 5;
    $autoDocumentValidity = function_exists('tsSystemSettingBool') ? tsSystemSettingBool($pdo,'ops_auto_travel_document_validity_reminders',true) : true;

    $autoDeparture = function_exists('tsSystemSettingBool') ? tsSystemSettingBool($pdo,'ops_auto_departure_messages',true) : true;
    $departureFirstDays = function_exists('tsSystemSettingInt') ? tsSystemSettingInt($pdo,'ops_departure_message_first_days',7) : 7;
    $departureFinalDays = function_exists('tsSystemSettingInt') ? tsSystemSettingInt($pdo,'ops_departure_message_final_days',1) : 1;
    $autoVoucher = function_exists('tsSystemSettingBool') ? tsSystemSettingBool($pdo,'ops_auto_voucher_delivery',true) : true;
    $autoPack = function_exists('tsSystemSettingBool') ? tsSystemSettingBool($pdo,'ops_auto_document_pack_delivery',true) : true;
    $autoPostTrip = function_exists('tsSystemSettingBool') ? tsSystemSettingBool($pdo,'ops_auto_post_trip_review',true) : true;
    $postTripDays = function_exists('tsSystemSettingInt') ? tsSystemSettingInt($pdo,'ops_post_trip_review_days_after',1) : 1;

    if($autoPayment && tsCommTableExists($pdo,'booking_payment_schedules') && tsCommTableExists($pdo,'booking_payment_installments')){
        $stmt=$pdo->prepare("SELECT i.* FROM booking_payment_installments i JOIN booking_payment_schedules s ON s.id=i.schedule_id WHERE i.booking_id=? AND s.status='active' AND i.status IN ('pending','partially_paid') AND i.due_date IS NOT NULL ORDER BY i.due_date,i.id");
        $stmt->execute([$bookingId]);
        foreach($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row){
            $dueTs=strtotime((string)$row['due_date'].' 09:00:00');
            if(!$dueTs)continue;
            $todayStart=strtotime(date('Y-m-d 00:00:00'));

            if($dueTs >= $todayStart){
                $preKey='payment-'.$row['id'].'-'.$paymentReminderDays.'d';
                $preAt=date('Y-m-d H:i:s',strtotime('-'.$paymentReminderDays.' days',$dueTs));
                if(strtotime($preAt) < $todayStart) $preAt=date('Y-m-d H:i:s');
                tsCommUpsertJob($pdo,$bookingId,$preKey,'payment_due','payment_due',$preAt,'booking_payment_installments',(int)$row['id']);
                $activeKeys[]=$preKey;
            }

            $overKey='payment-'.$row['id'].'-overdue-'.$paymentOverdueDays.'d';
            $overAt=date('Y-m-d H:i:s',strtotime('+'.$paymentOverdueDays.' days',$dueTs));
            tsCommUpsertJob($pdo,$bookingId,$overKey,'payment_overdue','payment_due',$overAt,'booking_payment_installments',(int)$row['id']);
            $activeKeys[]=$overKey;

            if($repeatOverduePayments && $paymentOverdueMax > 1){
                $jobStmt=$pdo->prepare("SELECT job_key,status,sent_at FROM booking_communication_jobs WHERE booking_id=? AND job_type='payment_overdue' AND source_table='booking_payment_installments' AND source_id=? ORDER BY id ASC");
                $jobStmt->execute([$bookingId,(int)$row['id']]);
                $jobs=$jobStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
                $sentRows=array_values(array_filter($jobs,static fn($j)=>(string)($j['status']??'')==='sent'));
                $openRows=array_values(array_filter($jobs,static fn($j)=>in_array((string)($j['status']??''),['pending','failed'],true)));
                if(!$openRows && count($sentRows) < $paymentOverdueMax && $sentRows){
                    $last=end($sentRows);
                    $lastTs=strtotime((string)($last['sent_at']??''));
                    if($lastTs){
                        $nextNo=count($sentRows)+1;
                        $nextKey='payment-'.$row['id'].'-overdue-r'.$nextNo;
                        $nextAt=date('Y-m-d H:i:s',strtotime('+'.max(1,$paymentOverdueRepeatDays).' days',$lastTs));
                        tsCommUpsertJob($pdo,$bookingId,$nextKey,'payment_overdue','payment_due',$nextAt,'booking_payment_installments',(int)$row['id']);
                        $activeKeys[]=$nextKey;
                    }
                } elseif($openRows){
                    foreach($openRows as $j)$activeKeys[]=(string)$j['job_key'];
                }
            }
        }
    }

    if($autoDocuments && tsCommTableExists($pdo,'booking_document_requirements')){
        $stmt=$pdo->prepare("SELECT id FROM booking_document_requirements WHERE booking_id=? AND is_required=1 AND status IN ('required','rejected') ORDER BY id");
        $stmt->execute([$bookingId]);
        $missingIds=array_map('intval',$stmt->fetchAll(PDO::FETCH_COLUMN) ?: []);
        if($missingIds){
            $prefix='documents-missing-'.substr(sha1(implode(',',$missingIds)),0,12);
            $jobStmt=$pdo->prepare("SELECT job_key,status,sent_at FROM booking_communication_jobs WHERE booking_id=? AND job_type='document_required' AND job_key LIKE ? ORDER BY id ASC");
            $jobStmt->execute([$bookingId,$prefix.'%']);
            $jobs=$jobStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            $openRows=array_values(array_filter($jobs,static fn($j)=>in_array((string)($j['status']??''),['pending','failed'],true)));
            $sentRows=array_values(array_filter($jobs,static fn($j)=>(string)($j['status']??'')==='sent'));

            if($openRows){
                foreach($openRows as $j)$activeKeys[]=(string)$j['job_key'];
            } elseif(!$jobs){
                tsCommUpsertJob($pdo,$bookingId,$prefix,'document_required','document_required',date('Y-m-d H:i:s'),'booking_document_requirements',null);
                $activeKeys[]=$prefix;
            } elseif($repeatMissingDocuments && count($sentRows) < max(1,$documentReminderMax) && $sentRows){
                $last=end($sentRows);
                $lastTs=strtotime((string)($last['sent_at']??''));
                if($lastTs){
                    $nextNo=count($sentRows)+1;
                    $key=$prefix.'-r'.$nextNo;
                    $at=date('Y-m-d H:i:s',strtotime('+'.max(1,$documentRepeatDays).' days',$lastTs));
                    tsCommUpsertJob($pdo,$bookingId,$key,'document_required','document_required',$at,'booking_document_requirements',null);
                    $activeKeys[]=$key;
                }
            }
        }
    }

    if($autoDocumentValidity && function_exists('tsDocValidity') && tsCommTableExists($pdo,'booking_travel_documents')){
        $travelDate=(string)($booking['travel_date'] ?? '');
        if($travelDate==='' || strtotime($travelDate.' 23:59:59') >= time()){
            $stmt=$pdo->prepare("SELECT d.* FROM booking_travel_documents d WHERE d.booking_id=? AND d.verification_status IN ('pending','verified') AND d.id=(SELECT MAX(d2.id) FROM booking_travel_documents d2 WHERE d2.booking_id=d.booking_id AND d2.traveller_id=d.traveller_id AND d2.document_type=d.document_type AND d2.verification_status<>'archived') ORDER BY d.id");
            $stmt->execute([$bookingId]);
            foreach($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $document){
                try{$risk=tsDocValidity($document,$booking);}catch(Throwable $e){continue;}
                $state=(string)($risk['state'] ?? 'valid');
                if(!in_array($state,['expired','expires_before_travel','passport_validity_warning','passport_expiry_missing'],true))continue;
                $key='travel-document-'.(int)$document['id'].'-'.$state;
                tsCommUpsertJob($pdo,$bookingId,$key,'travel_document_attention','travel_document_attention',date('Y-m-d H:i:s'),'booking_travel_documents',(int)$document['id']);
                $activeKeys[]=$key;
            }
        }
    }

    $travelDate=(string)($booking['travel_date'] ?? '');
    if($autoDeparture && $travelDate!=='' && ($travelTs=strtotime($travelDate.' 09:00:00'))){
        $todayTs=strtotime(date('Y-m-d 00:00:00'));
        foreach([[$departureFirstDays,'departure_7d'],[$departureFinalDays,'departure_1d']] as [$days,$template]){
            $dueTs=strtotime('-'.$days.' days',$travelTs);
            $key='departure-'.$days.'d';
            if($dueTs >= $todayTs){
                tsCommUpsertJob($pdo,$bookingId,$key,'departure_countdown',$template,date('Y-m-d H:i:s',$dueTs));
                $activeKeys[]=$key;
            }
        }
    }

    $voucher=tsCommCurrentVoucher($pdo,$bookingId);
    if($autoVoucher && $voucher){
        $key='voucher-final-'.$voucher['id'];
        $at=(string)($voucher['finalized_at'] ?: $voucher['created_at']);
        tsCommUpsertJob($pdo,$bookingId,$key,'voucher_delivery','voucher_delivery',$at ?: date('Y-m-d H:i:s'),'booking_voucher_versions',(int)$voucher['id']);
        $activeKeys[]=$key;
    }

    $pack=tsCommCurrentDocumentPack($pdo,$bookingId);
    if($autoPack && $pack){
        $key='document-pack-final-'.$pack['id'];
        $at=(string)($pack['finalized_at'] ?? $pack['created_at'] ?? '');
        tsCommUpsertJob($pdo,$bookingId,$key,'document_pack_delivery','document_pack_delivery',$at ?: date('Y-m-d H:i:s'),'booking_document_pack_versions',(int)$pack['id']);
        $activeKeys[]=$key;
    }

    if($autoPostTrip && tsCommTableExists($pdo,'booking_execution_states')){
        $stmt=$pdo->prepare("SELECT completed_at FROM booking_execution_states WHERE booking_id=? AND execution_status='completed' LIMIT 1");
        $stmt->execute([$bookingId]);
        $completed=(string)($stmt->fetchColumn() ?: '');
        if($completed!=='' && ($cTs=strtotime($completed)) && $cTs>=strtotime('-30 days')){
            $key='post-trip-review-'.$postTripDays.'d';
            $at=date('Y-m-d H:i:s',strtotime('+'.$postTripDays.' days',$cTs));
            tsCommUpsertJob($pdo,$bookingId,$key,'post_trip_review','post_trip_review',$at,'booking_execution_states',null);
            $activeKeys[]=$key;
        }
    }

    $activeKeys=array_values(array_unique(array_filter($activeKeys,static fn($v)=>trim((string)$v)!=='')));
    if($activeKeys){
        $placeholders=implode(',',array_fill(0,count($activeKeys),'?'));
        $params=array_merge([$bookingId],$activeKeys);
        $pdo->prepare("UPDATE booking_communication_jobs SET status='cancelled',updated_at=NOW() WHERE booking_id=? AND status IN ('pending','failed') AND job_key NOT IN ($placeholders)")->execute($params);
    } else {
        $pdo->prepare("UPDATE booking_communication_jobs SET status='cancelled',updated_at=NOW() WHERE booking_id=? AND status IN ('pending','failed')")->execute([$bookingId]);
    }
}

function tsCommJobs(PDO $pdo, int $bookingId): array
{
    if(!tsCommReady($pdo))return[];
    tsCommRefreshJobs($pdo,$bookingId);
    $stmt=$pdo->prepare("SELECT j.*,t.template_name FROM booking_communication_jobs j LEFT JOIN booking_communication_templates t ON t.template_key=j.template_key WHERE j.booking_id=? ORDER BY CASE WHEN j.status='pending' AND j.due_at<=NOW() THEN 0 WHEN j.status='failed' THEN 1 WHEN j.status='pending' THEN 2 ELSE 3 END,j.due_at ASC,j.id ASC");
    $stmt->execute([$bookingId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function tsCommSendJob(PDO $pdo, int $jobId, int $adminId=0, bool $allowEarly=false): int
{
    if(!tsCommReady($pdo))throw new RuntimeException('Communication Center SQL is not installed.');
    $stmt=$pdo->prepare("SELECT * FROM booking_communication_jobs WHERE id=? LIMIT 1"); $stmt->execute([$jobId]); $job=$stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    if(!$job)throw new RuntimeException('Communication automation job was not found.');
    if((string)$job['status']==='sent')return (int)($job['communication_id'] ?? 0);
    if((string)$job['status']==='cancelled' || (string)$job['status']==='skipped')throw new RuntimeException('This communication job is no longer active.');
    if(!$allowEarly && strtotime((string)$job['due_at'])>time())throw new RuntimeException('This automated communication is not due yet.');

    try{
        $render=tsCommRenderTemplate($pdo,(int)$job['booking_id'],(string)$job['template_key'],$job);
        $commId=tsCommSendEmail($pdo,(int)$job['booking_id'],(string)$render['subject'],(string)$render['body'],$adminId,(string)$job['template_key'],['automation_job_id'=>(int)$job['id'],'job_type'=>(string)$job['job_type']]);
        $pdo->prepare("UPDATE booking_communication_jobs SET status='sent',communication_id=?,last_error=NULL,sent_at=NOW(),updated_at=NOW() WHERE id=?")->execute([$commId,$jobId]);

        if (
            in_array((string)$job['job_type'], ['payment_due','payment_overdue'], true)
            && tsCommTableExists($pdo, 'booking_billing_reminders')
        ) {
            $booking = tsCommBooking($pdo, (int)$job['booking_id']);
            $pdo->prepare("INSERT INTO booking_billing_reminders (booking_id,installment_id,channel,recipient,message,status,sent_by_admin_id,sent_at) VALUES (?,?,'email',?,?,'sent',?,NOW())")
                ->execute([
                    (int)$job['booking_id'],
                    (string)($job['source_table'] ?? '') === 'booking_payment_installments' ? (int)($job['source_id'] ?? 0) ?: null : null,
                    (string)($booking['customer_email'] ?? ''),
                    (string)$render['body'],
                    $adminId > 0 ? $adminId : null,
                ]);
        }

        return $commId;
    }catch(Throwable $e){
        $pdo->prepare("UPDATE booking_communication_jobs SET status='failed',last_error=?,updated_at=NOW() WHERE id=?")->execute([mb_substr($e->getMessage(),0,1000),$jobId]);
        throw $e;
    }
}

function tsCommRunDueJobs(PDO $pdo, ?int $bookingId=null, int $adminId=0, int $limit=25): array
{
    if(!tsCommReady($pdo))return ['sent'=>0,'failed'=>0,'errors'=>[]];
    $limit=max(1,min(100,$limit));
    $sql="SELECT id FROM booking_communication_jobs WHERE status='pending' AND due_at<=NOW()";
    $params=[];
    if($bookingId){$sql.=" AND booking_id=?";$params[]=$bookingId;}
    $sql.=" ORDER BY due_at ASC,id ASC LIMIT ".$limit;
    $stmt=$pdo->prepare($sql);$stmt->execute($params);
    $sent=0;$failed=0;$errors=[];
    foreach($stmt->fetchAll(PDO::FETCH_COLUMN) ?: [] as $id){
        try{ tsCommSendJob($pdo,(int)$id,$adminId,false);$sent++; }
        catch(Throwable $e){$failed++;$errors[]='#'.(int)$id.' '.$e->getMessage();}
    }
    return ['sent'=>$sent,'failed'=>$failed,'errors'=>$errors];
}

function tsCommSummary(PDO $pdo, int $bookingId): array
{
    if(!tsCommReady($pdo))return ['ready'=>false];
    tsCommRefreshJobs($pdo,$bookingId);
    $stmt=$pdo->prepare("SELECT COUNT(*) FROM booking_communication_jobs WHERE booking_id=? AND status IN ('pending','failed') AND due_at<=NOW()");$stmt->execute([$bookingId]);$due=(int)$stmt->fetchColumn();
    $stmt=$pdo->prepare("SELECT COUNT(*) FROM booking_communication_jobs WHERE booking_id=? AND status='pending' AND due_at>NOW()");$stmt->execute([$bookingId]);$upcoming=(int)$stmt->fetchColumn();
    $stmt=$pdo->prepare("SELECT channel,direction,COALESCE(sent_at,created_at) AS at_time,body_text FROM booking_communications WHERE booking_id=? ORDER BY COALESCE(sent_at,created_at) DESC,id DESC LIMIT 1");$stmt->execute([$bookingId]);$last=$stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    $stmt=$pdo->prepare("SELECT COUNT(*) FROM booking_communications WHERE booking_id=? AND direction='inbound'");$stmt->execute([$bookingId]);$inbound=(int)$stmt->fetchColumn();
    return ['ready'=>true,'due'=>$due,'upcoming'=>$upcoming,'last'=>$last,'inbound'=>$inbound];
}
