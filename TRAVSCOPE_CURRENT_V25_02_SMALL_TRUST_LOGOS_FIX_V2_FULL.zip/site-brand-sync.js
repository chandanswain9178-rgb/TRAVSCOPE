(function(){
'use strict';

var ENDPOINT='site-brand-config.php';
var STYLE_ID='ts-global-brand-sync-style-v2467';
var LOGO_CLASS='ts-global-site-logo';
var appliedUrl='';

function addStyles(){
  if(document.getElementById(STYLE_ID)) return;
  var style=document.createElement('style');
  style.id=STYLE_ID;
  style.textContent=[
    '.ts-global-brand-replaced{display:flex!important;align-items:center!important;gap:0!important;text-decoration:none!important}',
    '.ts-global-site-logo{display:block!important;width:auto!important;height:auto!important;object-fit:contain!important;object-position:left center!important;max-width:100%!important}',
    '.header>.logo.ts-global-brand-replaced{display:flex!important;align-items:center!important;justify-content:flex-start!important;flex:0 0 auto!important;min-width:0!important;max-width:230px!important;max-height:58px!important;overflow:hidden!important}',
    '.header>.logo .ts-global-site-logo{max-width:220px!important;max-height:52px!important;width:auto!important;height:auto!important}',
    '.login-visual>.logo.ts-global-brand-replaced{display:flex!important;align-items:center!important;justify-content:flex-start!important;width:auto!important;max-width:300px!important;max-height:86px!important;overflow:hidden!important}',
    '.login-visual>.logo .ts-global-site-logo{max-width:285px!important;max-height:78px!important;width:auto!important;height:auto!important}',
    '.login-area .mobile-logo .ts-global-site-logo{max-width:205px!important;max-height:54px!important;width:auto!important;height:auto!important}',
    '#tsProSidebar .ts-pro-brand.ts-global-brand-replaced{padding-left:16px!important;padding-right:16px!important}',
    '#tsProSidebar .ts-global-site-logo{max-width:176px!important;max-height:46px!important}',
    '#tsProTopbar .ts-pro-top-brand.ts-global-brand-replaced{min-width:220px!important}',
    '#tsProTopbar .ts-global-site-logo{max-width:205px!important;max-height:42px!important}',
    '.sidebar-logo.ts-global-brand-replaced{justify-content:flex-start!important;padding-left:16px!important;padding-right:16px!important}',
    '.sidebar-logo .ts-global-site-logo{max-width:178px!important;max-height:48px!important}',
    '.portal-top .brand.ts-global-brand-replaced{min-width:150px!important}',
    '.portal-top .brand .ts-global-site-logo{max-width:185px!important;max-height:48px!important}',
    '.nav .logo.ts-global-brand-replaced,.navbar .logo.ts-global-brand-replaced{min-width:120px!important}',
    '.nav .logo .ts-global-site-logo,.navbar .logo .ts-global-site-logo{max-width:180px!important;max-height:50px!important}',
    '.footer .logo .ts-global-site-logo,footer .logo .ts-global-site-logo{max-width:170px!important;max-height:48px!important}',
    '.mobile-logo .ts-global-site-logo{max-width:165px!important;max-height:48px!important}',
    '.ts-v20-brand .ts-global-site-logo{max-width:170px!important;max-height:42px!important}',
    '.ts-global-brand-inline{display:inline-flex!important;align-items:center!important;gap:8px!important}',
    '.ts-global-brand-inline .ts-global-site-logo{display:inline-block!important;max-width:150px!important;max-height:34px!important;vertical-align:middle!important}',
    '.ts-global-brand-suffix{display:inline-block!important}',
    '@media(max-width:820px){#tsProTopbar .ts-pro-top-brand.ts-global-brand-replaced{min-width:0!important}#tsProTopbar .ts-global-site-logo{max-width:142px!important;max-height:36px!important}}'
  ].join('');
  document.head.appendChild(style);
}

function normalizedText(el){
  return String(el && el.textContent || '').replace(/\s+/g,' ').trim();
}

function containsBrandWord(text){
  return /\bTRAV\s*SCOPE\b/i.test(text) || /\bTRAVSCOPE\b/i.test(text);
}

function makeImg(data){
  var img=document.createElement('img');
  img.src=data.logo_url;
  img.alt=data.site_name || 'Website logo';
  img.className=LOGO_CLASS;
  img.decoding='async';
  return img;
}

function alreadyApplied(el,data){
  var img=el && el.querySelector && el.querySelector('img.'+LOGO_CLASS);
  return !!(img && img.getAttribute('src')===data.logo_url);
}

function replaceWhole(el,data){
  if(!el) return;
  var text=normalizedText(el);
  var existing=el.querySelector('img[class*="brand-logo"],img[class*="site-logo"],img.ts-public-brand-logo,img.ts-login-brand-logo,img.ts-admin-brand-logo,img.'+LOGO_CLASS);
  var hasExistingUploaded=!!existing;
  if(!containsBrandWord(text) && !hasExistingUploaded) return;

  /* Preserve page-specific logo classes/sizing when an uploaded logo already exists. */
  if(existing){
    if(existing.getAttribute('src')!==data.logo_url) existing.setAttribute('src',data.logo_url);
    existing.setAttribute('alt',data.site_name || 'Website logo');
    existing.classList.add(LOGO_CLASS);
    el.classList.add('ts-global-brand-replaced');
    el.setAttribute('aria-label',data.site_name || 'Home');
    return;
  }

  while(el.firstChild) el.removeChild(el.firstChild);
  el.appendChild(makeImg(data));
  el.classList.add('ts-global-brand-replaced');
  el.setAttribute('aria-label',data.site_name || 'Home');
}

function replaceInlineBrand(el,data){
  if(!el || alreadyApplied(el,data)) return;
  var text=normalizedText(el);
  if(!containsBrandWord(text)) return;

  var m=text.match(/^\s*TRAV\s*SCOPE(?:\.COM)?\s*(.*)$/i);
  if(!m) m=text.match(/^\s*TRAVSCOPE(?:\.COM)?\s*(.*)$/i);
  if(!m) return;

  var suffix=String(m[1]||'').trim();
  if(suffix && !/^(?:[·|—–-]|ADMIN(?:ISTRATION)?\b|BUSINESS\b|TRAVEL\b)/i.test(suffix)) return;

  while(el.firstChild) el.removeChild(el.firstChild);
  el.appendChild(makeImg(data));
  if(suffix && !/^ADMINISTRATION$/i.test(suffix)){
    var span=document.createElement('span');
    span.className='ts-global-brand-suffix';
    span.textContent=' '+suffix;
    el.appendChild(span);
  }
  el.classList.add('ts-global-brand-inline');
}

function apply(data){
  if(!data || !data.has_logo || !data.logo_url) return;
  appliedUrl=data.logo_url;
  addStyles();

  var wholeSelectors=[
    '#tsProSidebar .ts-pro-brand',
    '#tsProTopbar .ts-pro-top-brand',
    'aside.sidebar .sidebar-logo',
    '.admin-sidebar .sidebar-logo',
    '.portal-top > .brand',
    'nav.nav .logo',
    '.navbar .logo',
    'header .mobile-logo',
    '.mobile-logo',
    'footer .logo',
    '.footer .logo',
    '.ts-v20-brand'
  ];
  wholeSelectors.forEach(function(sel){
    document.querySelectorAll(sel).forEach(function(el){replaceWhole(el,data)});
  });

  document.querySelectorAll('.logo').forEach(function(el){
    if(el.closest('.nav,.navbar,footer,.footer') || el.classList.contains('mobile-logo')) return;
    var t=normalizedText(el);
    if(containsBrandWord(t) || el.querySelector('img[class*="brand-logo"],img.ts-public-brand-logo,img.ts-login-brand-logo')) replaceWhole(el,data);
  });

  document.querySelectorAll('.brand').forEach(function(el){
    if(el.closest('.portal-top') || el.matches('.ts-v20-brand')) return;
    replaceInlineBrand(el,data);
  });

  document.querySelectorAll('.topbar-title').forEach(function(el){
    if(containsBrandWord(normalizedText(el))) replaceWhole(el,data);
  });
}


function ensureFinanceNav(){
  var path=String(window.location.pathname||'').split('/').pop().toLowerCase();
  var qs=new URLSearchParams(window.location.search||'');
  var view=String(qs.get('view')||'overview').toLowerCase();
  var defs=[
    {href:'admin-finance.php',label:'Finance Overview',icon:'fa-chart-line',key:'overview'},
    {href:'admin-finance.php?view=invoices',label:'Customer Invoices',icon:'fa-file-invoice-dollar',key:'invoices'},
    {href:'admin-finance.php?view=receipts',label:'Money Receipts',icon:'fa-receipt',key:'receipts'},
    {href:'admin-finance.php?view=supplier',label:'Supplier Payables',icon:'fa-money-bill-transfer',key:'supplier'},
    {href:'admin-finance.php?view=tax',label:'GST / TCS Tax Center',icon:'fa-building-columns',key:'tax'}
  ];
  var roots=[];
  document.querySelectorAll('.sidebar-menu,#tsProSidebar,aside.sidebar,.admin-sidebar').forEach(function(r){if(roots.indexOf(r)<0)roots.push(r)});
  roots.forEach(function(root){
    if(root.querySelector('[data-ts-finance-suite="1"]')) return;
    var anchors=Array.prototype.slice.call(root.querySelectorAll('a[href]'));
    var pay=anchors.find(function(a){return /admin-payments\.php(?:$|[?#])/i.test(a.getAttribute('href')||'')});
    if(!pay) return;
    var host=pay.parentElement;
    if(host && host.tagName==='LI' && host.parentElement) host=host.parentElement;
    if(!host) return;
    var existing=anchors.map(function(a){return String(a.getAttribute('href')||'').toLowerCase()});
    var make=function(d){
      var a=document.createElement('a');
      a.href=d.href;a.setAttribute('data-ts-finance-suite','1');
      var base=String(pay.className||'').replace(/\bactive\b/g,'').trim();
      a.className=base;
      if(path==='admin-finance.php' && view===d.key) a.className=(base+' active').trim();
      a.innerHTML='<i class="fa-solid '+d.icon+'"></i><span>'+d.label+'</span>';
      return a;
    };
    var first=defs[0];
    if(!existing.some(function(h){return /admin-finance\.php(?:$|[?#])/.test(h)})){
      host.insertBefore(make(first),pay);
    }
    var ref=pay.nextSibling;
    defs.slice(1).forEach(function(d){
      if(Array.prototype.slice.call(root.querySelectorAll('a[href]')).some(function(a){return String(a.getAttribute('href')||'')===d.href})) return;
      host.insertBefore(make(d),ref);
    });
  });
}

function fetchBrand(){
  ensureFinanceNav();
  fetch(ENDPOINT,{credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'}})
    .then(function(r){if(!r.ok) throw new Error('brand config'); return r.json()})
    .then(function(data){apply(data); observe(data); ensureFinanceNav()})
    .catch(function(){/* retain existing fallback branding */});
  setTimeout(ensureFinanceNav,250);
  setTimeout(ensureFinanceNav,900);
}

function observe(data){
  if(!window.MutationObserver) return;
  var scheduled=false;
  var observer=new MutationObserver(function(){
    if(scheduled) return;
    scheduled=true;
    setTimeout(function(){scheduled=false;apply(data);ensureFinanceNav()},30);
  });
  observer.observe(document.documentElement,{childList:true,subtree:true});
  setTimeout(function(){observer.disconnect()},15000);
}

if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fetchBrand,{once:true});
else fetchBrand();
})();
