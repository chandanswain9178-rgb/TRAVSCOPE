<?php
declare(strict_types=1);
$__cwFile = __DIR__ . '/commercial-workflow-functions.php';
if (is_file($__cwFile) && !function_exists('tsCWMarkSupplierCostChanged')) require_once $__cwFile;

/*
|--------------------------------------------------------------------------
| TRAVSCOPE STEP 11C - SUPPLIER PAX RATE ENGINE
|--------------------------------------------------------------------------
| Reads supplier tariff PDFs into versioned itinerary/category/pax rates,
| calculates only evidenced commercial values, and can freeze a selected
| contract rate into the existing Trip Cost Sheet without changing packages.
*/

function tsSCRTableExists(PDO $pdo, string $table): bool
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
    try { $s=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?"); $s->execute([$table]); if ((int)$s->fetchColumn()>0) return true; } catch (Throwable $e) {}
    try { $pdo->query('SELECT 1 FROM `'.$table.'` LIMIT 0'); return true; } catch (Throwable $e) {}
    try { $q=$pdo->quote($table); if ($q!==false) { $s=$pdo->query('SHOW TABLES LIKE '.$q); return $s?(bool)$s->fetchColumn():false; } } catch (Throwable $e) {}
    return false;
}

function tsSCRReady(PDO $pdo): bool
{
    if (function_exists('tsSupplierDocumentEnsureSchema')) {
        try { tsSupplierDocumentEnsureSchema($pdo); } catch (Throwable $ignored) {}
    }
    foreach ([
        'supplier_contract_itineraries',
        'supplier_contract_rate_groups',
        'supplier_contract_pax_rates',
        'cost_sheet_contract_package_sources',
    ] as $table) {
        if (!tsSCRTableExists($pdo, $table)) return false;
    }
    return true;
}

function tsSCRValidDate(?string $date): ?string
{
    $date = trim((string)$date);
    if ($date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) return null;
    $ts = strtotime($date . ' 00:00:00');
    return $ts === false ? null : date('Y-m-d', $ts);
}

function tsSCRDateInRange(?string $date, ?string $from, ?string $to): bool
{
    $date = tsSCRValidDate($date);
    if ($date === null) return true;
    $from = tsSCRValidDate($from);
    $to = tsSCRValidDate($to);
    if ($from !== null && $date < $from) return false;
    if ($to !== null && $date > $to) return false;
    return true;
}

function tsSCRDateOverlapDays(?string $start, ?string $end, ?string $from, ?string $to): int
{
    $start = tsSCRValidDate($start);
    $end = tsSCRValidDate($end) ?? $start;
    $from = tsSCRValidDate($from);
    $to = tsSCRValidDate($to);
    if ($start === null) return 1;
    if ($end !== null && $end < $start) [$start,$end] = [$end,$start];
    $left = $from !== null && $from > $start ? $from : $start;
    $right = $to !== null && $to < $end ? $to : $end;
    if ($right < $left) return 0;
    $a = new DateTimeImmutable($left);
    $b = new DateTimeImmutable($right);
    return (int)$a->diff($b)->days + 1;
}

function tsSCRSeasonMatch(array $row, array $trip): ?array
{
    $start = tsSCRValidDate((string)($trip['travel_start_date'] ?? $trip['enquiry_travel_date'] ?? ''));
    if($start===null)return null; // Never guess a season when the travel date is unknown.
    $end = tsSCRValidDate((string)($trip['travel_end_date'] ?? '')) ?? $start;
    $basis = strtolower(trim((string)($row['applicability_basis'] ?? 'arrival_date')));
    $from = tsSCRValidDate((string)($row['version_valid_from'] ?? $row['valid_from'] ?? ''));
    $to = tsSCRValidDate((string)($row['version_valid_to'] ?? $row['valid_to'] ?? ''));
    $groupFrom = tsSCRValidDate((string)($row['valid_from'] ?? ''));
    $groupTo = tsSCRValidDate((string)($row['valid_to'] ?? ''));
    if ($basis === 'manual_confirmation') return null;

    if ($basis === 'departure_date') {
        $date = $end ?? $start;
        if (!tsSCRDateInRange($date,$from,$to) || !tsSCRDateInRange($date,$groupFrom,$groupTo)) return null;
        return ['matched_date'=>$date,'overlap_days'=>1,'basis'=>$basis];
    }
    if ($basis === 'majority_nights') {
        // Checkout/departure date is not a hotel night. Count stay dates from
        // arrival through the day before departure; fall back to one date for
        // same-day/unknown-end trips.
        $nightEnd=$end;
        if($end>$start){$d=new DateTimeImmutable($end);$nightEnd=$d->modify('-1 day')->format('Y-m-d');}
        $overlap = tsSCRDateOverlapDays($start,$nightEnd,$from,$to);
        $groupOverlap = tsSCRDateOverlapDays($start,$nightEnd,$groupFrom,$groupTo);
        $overlap = min($overlap,$groupOverlap);
        if ($overlap <= 0) return null;
        return ['matched_date'=>$start,'overlap_days'=>$overlap,'basis'=>$basis];
    }

    $date = $start;
    if (!tsSCRDateInRange($date,$from,$to) || !tsSCRDateInRange($date,$groupFrom,$groupTo)) return null;
    return ['matched_date'=>$date,'overlap_days'=>1,'basis'=>'arrival_date'];
}

function tsSCRMoney($value): ?float
{
    if ($value === null) return null;
    $value = trim((string)$value);
    if ($value === '') return null;
    $value = str_ireplace([',','₹','INR','Rs.','Rs','/-'], '', $value);
    if (!preg_match('/-?\d+(?:\.\d+)?/', $value, $m)) return null;
    $n = (float)$m[0];
    return $n >= 0 ? $n : null;
}

function tsSCRNormalizeCategory(string $value): string
{
    $v = strtolower(trim(preg_replace('/\s+/u', ' ', $value) ?? $value));
    $v = preg_replace('/\bhotels?\b/u', '', $v) ?? $v;
    $v = trim(preg_replace('/\s+/u', ' ', $v) ?? $v);

    if (preg_match('/\b(?:05|5|five)\s*star\b/u', $v)) {
        if (preg_match('/\b(luxury|deluxe|premium)\b/u', $v, $m)) return '5 Star ' . ucfirst($m[1]);
        return '5 Star';
    }
    if (preg_match('/\b(?:04|4|four)\s*star\b/u', $v)) {
        if (preg_match('/\b(luxury|deluxe|premium)\b/u', $v, $m)) return '4 Star ' . ucfirst($m[1]);
        return '4 Star';
    }
    if (preg_match('/\b(?:03|3|three)\s*star\b/u', $v)) return '3 Star';
    if (preg_match('/\b(?:02|2|two)\s*star\b/u', $v)) return '2 Star';
    if (str_contains($v, 'super deluxe') || str_contains($v, 'superdeluxe')) return 'Super Deluxe';
    if (preg_match('/\bpremium\b/u', $v)) return 'Premium';
    if (preg_match('/\bsuperior\b/u', $v)) return 'Superior';
    if (preg_match('/\bdeluxe\b/u', $v)) return 'Deluxe';
    if (str_contains($v, 'standard')) return 'Standard';
    if (str_contains($v, 'budget')) return 'Budget';
    return ucwords($v);
}

function tsSCRStarFromCategory(string $category): ?int
{
    $c = tsSCRNormalizeCategory($category);
    if (str_starts_with($c, '5 Star')) return 5;
    if (str_starts_with($c, '4 Star')) return 4;
    if (str_starts_with($c, '3 Star')) return 3;
    return null;
}

function tsSCRGetVersion(PDO $pdo, int $versionId): ?array
{
    if (function_exists('tsSCIGetVersion')) return tsSCIGetVersion($pdo, $versionId);

    $stmt = $pdo->prepare("\n        SELECT v.*,c.supplier_id,c.contract_code,c.contract_name,\n               sd.document_code,sd.stored_path,sd.destination_id,sd.analysis_json,\n               sd.detected_meal_plan,sd.valid_from document_valid_from,sd.valid_to document_valid_to,\n               s.company_name,d.name destination_name,d.country destination_country\n        FROM supplier_contract_versions v\n        JOIN supplier_contracts c ON c.id=v.contract_id\n        JOIN supplier_documents sd ON sd.id=v.supplier_document_id\n        JOIN suppliers s ON s.id=c.supplier_id\n        LEFT JOIN destinations d ON d.id=sd.destination_id\n        WHERE v.id=? LIMIT 1\n    ");
    $stmt->execute([$versionId]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

function tsSCRExtractLayoutText(string $sourcePath): string
{
    // Prefer the shared PDF/DOCX extractor. DOCX table rows are preserved with tabs,
    // which lets the tariff parser map PAX rows to hotel categories safely.
    if (function_exists('tsSupplierDocumentExtractFileText')) {
        $extracted = tsSupplierDocumentExtractFileText($sourcePath);
        $text = is_array($extracted) ? (string)($extracted['text'] ?? '') : '';
        if (trim($text) !== '') return $text;
    }
    if (function_exists('tsSCIExtractLayoutText')) return tsSCIExtractLayoutText($sourcePath);
    if (function_exists('tsSupplierDocumentExtractNativePdfText')) return tsSupplierDocumentExtractNativePdfText($sourcePath);
    return '';
}

function tsSCRCategoryLabelsFromHeader(string $line): array
{
    if (!preg_match('/\b(?:MAPAI|CPAI|APAI|EPAI|MAP|CP|AP|EP|per\s*person)\b/iu', $line)) return [];

    preg_match_all(
        '/\b(?:0?[2-5]\s*Star(?:\s+(?:Luxury|Deluxe|Premium))?|Five\s*Star(?:\s+(?:Luxury|Deluxe|Premium))?|Super\s*Deluxe|SuperDeluxe|Superior|Premium|Deluxe|Budget|Standard)\b/iu',
        $line,
        $m
    );

    $out = [];
    foreach ($m[0] ?? [] as $raw) {
        $c = tsSCRNormalizeCategory((string)$raw);
        if ($c !== '' && !in_array($c, $out, true)) $out[] = $c;
    }
    return array_slice($out, 0, 3);
}

function tsSCRMealPlanFromText(string $text, string $fallback = ''): string
{
    foreach (['MAPAI','CPAI','APAI','EPAI','MAP','CP','AP','EP'] as $plan) {
        if (preg_match('/\b' . preg_quote($plan, '/') . '\b/iu', $text)) return $plan;
    }
    return trim($fallback);
}

function tsSCRExtractInclusions(string $section): string
{
    if (!preg_match('/Package\s+Included\s*:\s*(.*?)(?=\n\s*(?:Budget|Standard|0?[2-5]\s*Star)[^\n]*(?:MAPAI|CPAI|APAI|EP|per\s*person)|\z)/isu', $section, $m)) {
        return '';
    }
    $v = trim((string)$m[1]);
    $v = preg_replace('/^[\x{2022}\x{00B7}\-*\s]+/mu', '', $v) ?? $v;
    return trim($v);
}

function tsSCRExtractItineraryText(string $section): string
{
    $end = stripos($section, 'Package Included');
    $v = $end !== false ? substr($section, 0, $end) : $section;
    return trim($v);
}

function tsSCRParseRateGroups(string $section, string $defaultMealPlan = ''): array
{
    $lines = preg_split('/\R/u', str_replace("\f", "\n", $section)) ?: [];
    $groups = [];
    $current = [];
    $excerpt = [];

    $flush = static function () use (&$groups, &$current, &$excerpt, $defaultMealPlan): void {
        if (!$current) return;
        foreach ($current as $idx => $category) {
            if (!isset($groups[$category])) {
                $groups[$category] = [
                    'supplier_category' => $category,
                    'mapped_star_category' => tsSCRStarFromCategory($category),
                    'meal_plan' => $defaultMealPlan,
                    'pax_rates' => [],
                    'extra_bed_rate' => null,
                    'child_without_bed_rate' => null,
                    'child_with_bed_rate' => null,
                    'infant_rate' => null,
                    'source_excerpt' => '',
                ];
            }
            if ($excerpt) {
                $groups[$category]['source_excerpt'] = trim(implode("\n", array_slice($excerpt, 0, 10)));
            }
        }
        $current = [];
        $excerpt = [];
    };

    foreach ($lines as $lineRaw) {
        $line = rtrim((string)$lineRaw);
        $labels = tsSCRCategoryLabelsFromHeader($line);
        if ($labels) {
            $flush();
            $current = $labels;
            $excerpt = [$line];
            $meal = tsSCRMealPlanFromText($line, $defaultMealPlan);
            foreach ($current as $c) {
                if (!isset($groups[$c])) {
                    $groups[$c] = [
                        'supplier_category' => $c,
                        'mapped_star_category' => tsSCRStarFromCategory($c),
                        'meal_plan' => $meal,
                        'pax_rates' => [],
                        'extra_bed_rate' => null,
                        'child_without_bed_rate' => null,
                        'child_with_bed_rate' => null,
                        'infant_rate' => null,
                        'source_excerpt' => '',
                    ];
                } else {
                    $groups[$c]['meal_plan'] = $meal;
                }
            }
            continue;
        }

        if (!$current) continue;
        if (trim($line) === '') continue;
        $excerpt[] = $line;

        if (preg_match_all('/Pax\s*0?(\d{1,3})\s+([0-9][0-9,]*(?:\.\d+)?)/iu', $line, $m, PREG_SET_ORDER)) {
            foreach ($m as $i => $row) {
                if (!isset($current[$i])) continue;
                $category = $current[$i];
                $pax = max(1, (int)$row[1]);
                $amount = tsSCRMoney($row[2]);
                if ($amount !== null && $amount > 0) {
                    $groups[$category]['pax_rates'][$pax] = $amount;
                }
            }
            continue;
        }

        if (preg_match_all('/Extra\s*Bed\s+([0-9][0-9,]*(?:\.\d+)?)/iu', $line, $m, PREG_SET_ORDER)) {
            foreach ($m as $i => $row) {
                if (!isset($current[$i])) continue;
                $groups[$current[$i]]['extra_bed_rate'] = tsSCRMoney($row[1]);
            }
            continue;
        }

        if (preg_match_all('/Child\s*(?:w\/?o|without)\s*Bed\s+([0-9][0-9,]*(?:\.\d+)?)/iu', $line, $m, PREG_SET_ORDER)) {
            foreach ($m as $i => $row) {
                if (!isset($current[$i])) continue;
                $groups[$current[$i]]['child_without_bed_rate'] = tsSCRMoney($row[1]);
            }
            continue;
        }

        if (preg_match_all('/Child\s*(?:with|w\/?b)\s*Bed\s+([0-9][0-9,]*(?:\.\d+)?)/iu', $line, $m, PREG_SET_ORDER)) {
            foreach ($m as $i => $row) {
                if (!isset($current[$i])) continue;
                $groups[$current[$i]]['child_with_bed_rate'] = tsSCRMoney($row[1]);
            }
            continue;
        }

        if (preg_match_all('/Infant(?:\s+Rate)?\s+([0-9][0-9,]*(?:\.\d+)?)/iu', $line, $m, PREG_SET_ORDER)) {
            foreach ($m as $i => $row) {
                if (!isset($current[$i])) continue;
                $groups[$current[$i]]['infant_rate'] = tsSCRMoney($row[1]);
            }
        }
    }
    $flush();

    return array_values(array_filter($groups, static fn(array $g): bool => !empty($g['pax_rates'])));
}

function tsSCRNormalizePackageCode(string $value): string
{
    if (!preg_match('/\b([A-Z]{2,10})\s*[-–—]\s*(\d{2,6})\b/iu', trim($value), $m)) return '';
    return strtoupper((string)$m[1]) . '-' . (string)$m[2];
}

function tsSCRParseCodeMatrixTariff(string $text, array $version): array
{
    // Common B2B supplier layout:
    // package summary table: Code | Route | 5N-6D
    // then one table per package: NO OF PAX | Deluxe (CP) | Super Deluxe (CP) ...
    $lines = preg_split('/\R/u', str_replace("\f", "\n", $text)) ?: [];
    $summary = [];
    $summaryOrder = [];
    foreach ($lines as $line) {
        $cells = array_map('trim', explode("\t", (string)$line));
        if (count($cells) < 3) continue;
        $code = tsSCRNormalizePackageCode((string)$cells[0]);
        if ($code === '') continue;
        $duration = (string)end($cells);
        if (!preg_match('/\b(\d{1,2})\s*N\s*[-\/]\s*(\d{1,2})\s*D\b/iu', $duration, $dm)) continue;
        $route = trim(implode(' ', array_slice($cells, 1, -1)));
        $summary[$code] = [
            'route' => $route,
            'nights' => (int)$dm[1],
            'days' => (int)$dm[2],
        ];
        if (!in_array($code, $summaryOrder, true)) $summaryOrder[] = $code;
    }

    $result = [];
    $resultByCode = [];
    $defaultMealPlan = trim((string)($version['meal_plan'] ?? $version['detected_meal_plan'] ?? ''));
    $globalInclusions='';$globalExclusions='';
    if(preg_match('/Package\s+Inclusions?\s*:\s*(.*?)(?=\n\s*Package\s+Exclusions?\s*:)/isu',$text,$sm))$globalInclusions=trim((string)$sm[1]);
    if(preg_match('/Package\s+Exclusions?\s*:\s*(.*?)(?=\n\s*(?:Some\s+Mandatory\s+Notes|Mandatory\s+Notes|Child\s+Policy|Notes|PAYMENTS?)\b|\z)/isu',$text,$sm))$globalExclusions=trim((string)$sm[1]);
    $count = count($lines);

    for ($i = 0; $i < $count; $i++) {
        $heading = trim((string)$lines[$i]);
        $code = tsSCRNormalizePackageCode($heading);
        if ($code === '') continue;
        // Summary-table rows contain tabs and are metadata, not rate-section headings.
        if (str_contains($heading, "\t")) continue;

        // Find the table header close to this package heading.
        $headerIndex = null;
        $headerCells = [];
        for ($j = $i + 1; $j < min($count, $i + 7); $j++) {
            $candidate = trim((string)$lines[$j]);
            if (preg_match('/\bNO\s+OF\s+PAX\b/iu', $candidate) && str_contains($candidate, "\t")) {
                $headerIndex = $j;
                $headerCells = array_map('trim', explode("\t", $candidate));
                break;
            }
            // Another package heading means this one has no nearby rate matrix.
            if ($j > $i + 1 && tsSCRNormalizePackageCode($candidate) !== '') break;
        }
        if ($headerIndex === null || count($headerCells) < 2) continue;

        $categories = [];
        $mealPlans = [];
        for ($c = 1; $c < count($headerCells); $c++) {
            $raw = trim((string)$headerCells[$c]);
            if ($raw === '') continue;
            $meal = tsSCRMealPlanFromText($raw, $defaultMealPlan);
            $catRaw = preg_replace('/\s*\((?:MAPAI|CPAI|APAI|EPAI|MAP|CP|AP|EP)\)\s*/iu', ' ', $raw) ?? $raw;
            $catRaw = trim(preg_replace('/\s+/u', ' ', $catRaw) ?? $catRaw);
            $cat = tsSCRNormalizeCategory($catRaw);
            if ($cat === '') continue;
            $categories[$c] = $cat;
            $mealPlans[$c] = $meal;
        }
        if (!$categories) continue;

        $groups = [];
        foreach ($categories as $col => $cat) {
            $groups[$col] = [
                'supplier_category' => $cat,
                'mapped_star_category' => tsSCRStarFromCategory($cat),
                'meal_plan' => (string)($mealPlans[$col] ?? $defaultMealPlan),
                'pax_rates' => [],
                'extra_bed_rate' => null,
                'child_without_bed_rate' => null,
                'child_with_bed_rate' => null,
                'infant_rate' => null,
                'source_excerpt' => $heading . "\n" . (string)$lines[$headerIndex],
            ];
        }

        $rowExcerpt = [];
        for ($j = $headerIndex + 1; $j < $count; $j++) {
            $row = trim((string)$lines[$j]);
            if ($row === '') {
                if ($rowExcerpt) break;
                continue;
            }
            if (tsSCRNormalizePackageCode($row) !== '') break;
            if (!preg_match('/^0?(\d{1,3})\s*PAX\b/iu', $row, $pm)) {
                // Stop after the rate rows once a note/next section starts.
                if ($rowExcerpt) break;
                continue;
            }
            $pax = max(1, (int)$pm[1]);
            $cells = array_map('trim', explode("\t", $row));
            foreach ($categories as $col => $cat) {
                if (!array_key_exists($col, $cells)) continue;
                $amount = tsSCRMoney((string)$cells[$col]);
                if ($amount !== null && $amount > 0) $groups[$col]['pax_rates'][$pax] = $amount;
            }
            $rowExcerpt[] = $row;
        }

        $groups = array_values(array_filter($groups, static fn(array $g): bool => !empty($g['pax_rates'])));
        if (!$groups) continue;
        foreach ($groups as &$g) {
            $g['source_excerpt'] = trim($g['source_excerpt'] . "\n" . implode("\n", array_slice($rowExcerpt, 0, 6)));
        }
        unset($g);

        $meta = $summary[$code] ?? null;
        $route = '';
        if (preg_match('/\((.*?)\)/u', $heading, $hm)) $route = trim((string)$hm[1]);
        if ($route === '') $route = trim((string)($meta['route'] ?? ''));
        $nights = max(0, (int)($meta['nights'] ?? 0));
        $days = max(0, (int)($meta['days'] ?? 0));
        if ($nights <= 0 && preg_match_all('/\b(\d{1,2})\s*N\b/iu', $route, $nm)) {
            $nights = array_sum(array_map('intval', $nm[1] ?? []));
        }
        if ($days <= 0 && $nights > 0) $days = $nights + 1;
        $meal = $defaultMealPlan;
        foreach ($groups as $g) { if ((string)$g['meal_plan'] !== '') { $meal = (string)$g['meal_plan']; break; } }
        $order = array_search($code, $summaryOrder, true);
        $sourceOrder = $order === false ? count($result) + 1 : (int)$order + 1;

        $item = [
            'source_order' => $sourceOrder,
            'source_heading' => $heading,
            'title' => $code . ($route !== '' ? ' · ' . $route : ''),
            'duration_nights' => $nights,
            'duration_days' => $days,
            'itinerary_text' => $route,
            'inclusions' => $globalInclusions,
            'exclusions' => $globalExclusions,
            'meal_plan' => $meal,
            'rate_groups' => $groups,
        ];
        // Keep one safely detected rate matrix per package code.
        if (!isset($resultByCode[$code])) {
            $resultByCode[$code] = $item;
            $result[] = $item;
        }
    }

    usort($result, static fn(array $a, array $b): int => ((int)$a['source_order']) <=> ((int)$b['source_order']));
    return $result;
}

function tsSCRParseSupplierTariff(string $text, array $version): array
{
    $text = str_replace("\f", "\n", $text);
    $matrix = tsSCRParseCodeMatrixTariff($text, $version);
    if ($matrix) return $matrix;
    $pattern = '/(\d{1,2})\s*Nights?\s*&\s*(\d{1,2})\s*Days?/iu';
    preg_match_all($pattern, $text, $matches, PREG_OFFSET_CAPTURE);

    $starts = $matches[0] ?? [];
    $nightsMatches = $matches[1] ?? [];
    $daysMatches = $matches[2] ?? [];
    $result = [];
    $destinationName = trim((string)($version['destination_name'] ?? ''));
    $defaultMealPlan = trim((string)($version['meal_plan'] ?? $version['detected_meal_plan'] ?? ''));

    foreach ($starts as $i => $match) {
        $start = (int)$match[1];
        $end = isset($starts[$i + 1]) ? (int)$starts[$i + 1][1] : strlen($text);
        $section = substr($text, $start, max(0, $end - $start));
        $nights = max(0, (int)($nightsMatches[$i][0] ?? 0));
        $days = max(0, (int)($daysMatches[$i][0] ?? 0));
        if ($days <= 0) $days = $nights + 1;

        $groups = tsSCRParseRateGroups($section, $defaultMealPlan);
        if (!$groups) continue;

        $heading = trim((string)$match[0]);
        $title = ($destinationName !== '' ? $destinationName . ' · ' : '') . $nights . ' Nights / ' . $days . ' Days';

        $result[] = [
            'source_order' => $i + 1,
            'source_heading' => $heading,
            'title' => $title,
            'duration_nights' => $nights,
            'duration_days' => $days,
            'itinerary_text' => tsSCRExtractItineraryText($section),
            'inclusions' => tsSCRExtractInclusions($section),
            'exclusions' => '',
            'meal_plan' => tsSCRMealPlanFromText($section, $defaultMealPlan),
            'rate_groups' => $groups,
        ];
    }

    return $result;
}

function tsSCRBuildRatesFromDocument(PDO $pdo, int $versionId, int $adminId): array
{
    if (!tsSCRReady($pdo)) throw new RuntimeException('Step 11C SQL is not installed yet.');
    $version = tsSCRGetVersion($pdo, $versionId);
    if (!$version) throw new RuntimeException('Supplier contract version not found.');

    $path = function_exists('tsSupplierDocumentStoredPath')
        ? tsSupplierDocumentStoredPath((string)$version['stored_path'])
        : '';
    if ($path === '' || !is_file($path)) throw new RuntimeException('Original supplier source document is unavailable.');

    $layout = tsSCRExtractLayoutText($path);
    if (trim($layout) === '') throw new RuntimeException('Unable to read the supplier source document. PDF requires pdftotext; DOCX requires PHP ZipArchive and DOM extensions.');

    $parsed = tsSCRParseSupplierTariff($layout, $version);
    if (!$parsed) throw new RuntimeException('No itinerary/package + PAX pricing matrix was safely detected in this supplier source document.');

    $check = $pdo->prepare("SELECT COUNT(*) FROM supplier_contract_itineraries WHERE contract_version_id=? AND status='active'");
    $check->execute([$versionId]);
    if ((int)$check->fetchColumn() > 0) {
        throw new RuntimeException('This contract version already has ACTIVE PAX rates. Create/review a new supplier contract version instead of overwriting commercial history.');
    }

    $pdo->beginTransaction();
    try {
        $oldIdsStmt = $pdo->prepare("SELECT id FROM supplier_contract_itineraries WHERE contract_version_id=? AND status='review'");
        $oldIdsStmt->execute([$versionId]);
        $oldIds = array_map('intval', $oldIdsStmt->fetchAll(PDO::FETCH_COLUMN) ?: []);
        if ($oldIds) {
            $ph = implode(',', array_fill(0, count($oldIds), '?'));
            $pdo->prepare("DELETE FROM supplier_contract_pax_rates WHERE itinerary_id IN ($ph)")->execute($oldIds);
            $pdo->prepare("DELETE FROM supplier_contract_rate_groups WHERE itinerary_id IN ($ph)")->execute($oldIds);
        }
        $pdo->prepare("DELETE FROM supplier_contract_itineraries WHERE contract_version_id=? AND status='review'")->execute([$versionId]);

        $insertIt = $pdo->prepare("\n            INSERT INTO supplier_contract_itineraries\n            (contract_version_id,contract_id,supplier_document_id,supplier_id,destination_id,itinerary_code,title,duration_nights,duration_days,itinerary_text,inclusions,exclusions,meal_plan,currency,valid_from,valid_to,source_order,source_heading,status,created_by_admin_id,updated_by_admin_id)\n            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'review',?,?)\n        ");
        $insertGroup = $pdo->prepare("\n            INSERT INTO supplier_contract_rate_groups\n            (itinerary_id,contract_version_id,contract_id,supplier_id,supplier_category,mapped_star_category,meal_plan,currency,extra_bed_rate,child_without_bed_rate,child_with_bed_rate,infant_rate,child_with_bed_basis,tax_included,tax_percent,valid_from,valid_to,source_order,source_excerpt,status,created_by_admin_id,updated_by_admin_id)\n            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'review',?,?)\n        ");
        $insertPax = $pdo->prepare("\n            INSERT INTO supplier_contract_pax_rates\n            (rate_group_id,itinerary_id,contract_version_id,pax_min,pax_max,source_pax_label,rate_per_person,status,sort_order,created_by_admin_id,updated_by_admin_id)\n            VALUES (?,?,?,?,?,?,?,'review',?,?,?)\n        ");

        $itineraryCount = $groupCount = $paxCount = 0;
        foreach ($parsed as $it) {
            $code = 'SCIT-' . $versionId . '-' . str_pad((string)$it['source_order'], 2, '0', STR_PAD_LEFT);
            $insertIt->execute([
                $versionId,
                (int)$version['contract_id'],
                (int)$version['supplier_document_id'],
                (int)$version['supplier_id'],
                !empty($version['destination_id']) ? (int)$version['destination_id'] : null,
                $code,
                (string)$it['title'],
                (int)$it['duration_nights'],
                (int)$it['duration_days'],
                (string)$it['itinerary_text'],
                (string)$it['inclusions'],
                (string)$it['exclusions'],
                (string)$it['meal_plan'],
                strtoupper(trim((string)($version['currency'] ?? 'INR'))) ?: 'INR',
                $version['valid_from'] ?: ($version['document_valid_from'] ?? null),
                $version['valid_to'] ?: ($version['document_valid_to'] ?? null),
                (int)$it['source_order'],
                (string)$it['source_heading'],
                $adminId ?: null,
                $adminId ?: null,
            ]);
            $itineraryId = (int)$pdo->lastInsertId();
            $itineraryCount++;

            foreach ($it['rate_groups'] as $gIndex => $group) {
                $taxIncluded = !empty($version['tax_included']) ? 1 : 0;
                $taxPercent = max(0, (float)($version['supplier_tax_percent'] ?? 0));
                $insertGroup->execute([
                    $itineraryId,
                    $versionId,
                    (int)$version['contract_id'],
                    (int)$version['supplier_id'],
                    (string)$group['supplier_category'],
                    $group['mapped_star_category'] !== null ? (int)$group['mapped_star_category'] : null,
                    (string)($group['meal_plan'] ?: $it['meal_plan']),
                    strtoupper(trim((string)($version['currency'] ?? 'INR'))) ?: 'INR',
                    $group['extra_bed_rate'],
                    $group['child_without_bed_rate'],
                    $group['child_with_bed_rate'],
                    $group['infant_rate'],
                    $group['child_with_bed_rate'] !== null ? 'explicit' : 'not_available',
                    $taxIncluded,
                    $taxPercent,
                    $version['valid_from'] ?: ($version['document_valid_from'] ?? null),
                    $version['valid_to'] ?: ($version['document_valid_to'] ?? null),
                    $gIndex + 1,
                    mb_substr((string)($group['source_excerpt'] ?? ''), 0, 1000),
                    $adminId ?: null,
                    $adminId ?: null,
                ]);
                $groupId = (int)$pdo->lastInsertId();
                $groupCount++;

                $sort = 0;
                ksort($group['pax_rates']);
                foreach ($group['pax_rates'] as $pax => $rate) {
                    $pax = max(1, (int)$pax);
                    $insertPax->execute([
                        $groupId,
                        $itineraryId,
                        $versionId,
                        $pax,
                        $pax,
                        'Pax ' . str_pad((string)$pax, 2, '0', STR_PAD_LEFT),
                        (float)$rate,
                        ++$sort,
                        $adminId ?: null,
                        $adminId ?: null,
                    ]);
                    $paxCount++;
                }
            }
        }

        $pdo->commit();
        return ['itineraries'=>$itineraryCount,'rate_groups'=>$groupCount,'pax_rows'=>$paxCount];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function tsSCRSummary(PDO $pdo, int $versionId): array
{
    $out = ['itineraries'=>0,'groups'=>0,'pax_rows'=>0,'active_groups'=>0,'review_groups'=>0];
    if (!tsSCRReady($pdo)) return $out;
    $stmt=$pdo->prepare('SELECT COUNT(*) FROM supplier_contract_itineraries WHERE contract_version_id=?');$stmt->execute([$versionId]);$out['itineraries']=(int)$stmt->fetchColumn();
    $stmt=$pdo->prepare('SELECT COUNT(*) FROM supplier_contract_rate_groups WHERE contract_version_id=?');$stmt->execute([$versionId]);$out['groups']=(int)$stmt->fetchColumn();
    $stmt=$pdo->prepare('SELECT COUNT(*) FROM supplier_contract_pax_rates WHERE contract_version_id=?');$stmt->execute([$versionId]);$out['pax_rows']=(int)$stmt->fetchColumn();
    $stmt=$pdo->prepare("SELECT COUNT(*) FROM supplier_contract_rate_groups WHERE contract_version_id=? AND status='active'");$stmt->execute([$versionId]);$out['active_groups']=(int)$stmt->fetchColumn();
    $stmt=$pdo->prepare("SELECT COUNT(*) FROM supplier_contract_rate_groups WHERE contract_version_id=? AND status='review'");$stmt->execute([$versionId]);$out['review_groups']=(int)$stmt->fetchColumn();
    return $out;
}

function tsSCRItineraries(PDO $pdo, int $versionId): array
{
    $stmt=$pdo->prepare('SELECT * FROM supplier_contract_itineraries WHERE contract_version_id=? ORDER BY source_order,id');
    $stmt->execute([$versionId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function tsSCRRateGroups(PDO $pdo, int $itineraryId): array
{
    $stmt=$pdo->prepare('SELECT * FROM supplier_contract_rate_groups WHERE itinerary_id=? ORDER BY source_order,id');
    $stmt->execute([$itineraryId]);
    $groups=$stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $paxStmt=$pdo->prepare('SELECT * FROM supplier_contract_pax_rates WHERE rate_group_id=? ORDER BY pax_min,pax_max,id');
    foreach($groups as &$g){$paxStmt->execute([(int)$g['id']]);$g['pax_rates']=$paxStmt->fetchAll(PDO::FETCH_ASSOC)?:[];} unset($g);
    return $groups;
}

function tsSCRApproveRates(PDO $pdo, int $versionId, int $adminId): array
{
    $summary = tsSCRSummary($pdo, $versionId);
    if ($summary['groups'] <= 0 || $summary['pax_rows'] <= 0) throw new RuntimeException('Build and review the PAX rate matrix first.');
    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE supplier_contract_itineraries SET status='active',updated_by_admin_id=?,updated_at=NOW() WHERE contract_version_id=? AND status='review'")->execute([$adminId?:null,$versionId]);
        $pdo->prepare("UPDATE supplier_contract_rate_groups SET status='active',updated_by_admin_id=?,updated_at=NOW() WHERE contract_version_id=? AND status='review'")->execute([$adminId?:null,$versionId]);
        $pdo->prepare("UPDATE supplier_contract_pax_rates SET status='active',updated_by_admin_id=?,updated_at=NOW() WHERE contract_version_id=? AND status='review'")->execute([$adminId?:null,$versionId]);
        $pdo->commit();
    } catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
    return tsSCRSummary($pdo,$versionId);
}

function tsSCRSaveGroup(PDO $pdo, int $groupId, array $input, int $adminId): void
{
    $stmt=$pdo->prepare('SELECT * FROM supplier_contract_rate_groups WHERE id=? LIMIT 1');$stmt->execute([$groupId]);$group=$stmt->fetch(PDO::FETCH_ASSOC);
    if(!$group) throw new RuntimeException('Rate group not found.');
    if((string)$group['status']==='active') throw new RuntimeException('Active commercial rates are immutable. Create a new supplier contract version for revised rates.');

    $category=tsSCRNormalizeCategory((string)($input['supplier_category']??$group['supplier_category']));
    $basis=(string)($input['child_with_bed_basis']??'not_available');
    if(!in_array($basis,['explicit','use_extra_bed','not_available'],true))$basis='not_available';
    $extra=tsSCRMoney($input['extra_bed_rate']??null);
    $wob=tsSCRMoney($input['child_without_bed_rate']??null);
    $cwb=tsSCRMoney($input['child_with_bed_rate']??null);
    if($basis==='explicit' && $cwb===null) throw new RuntimeException('Enter Child With Bed rate or choose another Child With Bed basis.');
    if($basis==='use_extra_bed' && $extra===null) throw new RuntimeException('Extra Bed rate is required before it can be used for Child With Bed.');

    $pdo->beginTransaction();
    try{
        $pdo->prepare("UPDATE supplier_contract_rate_groups SET supplier_category=?,mapped_star_category=?,extra_bed_rate=?,child_without_bed_rate=?,child_with_bed_rate=?,child_with_bed_basis=?,updated_by_admin_id=?,updated_at=NOW() WHERE id=?")
            ->execute([$category,tsSCRStarFromCategory($category),$extra,$wob,$cwb,$basis,$adminId?:null,$groupId]);
        $paxValues=(array)($input['pax_rate']??[]);
        foreach($paxValues as $rateId=>$raw){
            $rateId=(int)$rateId;$amount=tsSCRMoney($raw);
            if($rateId<=0||$amount===null||$amount<=0)continue;
            $pdo->prepare("UPDATE supplier_contract_pax_rates SET rate_per_person=?,updated_by_admin_id=?,updated_at=NOW() WHERE id=? AND rate_group_id=? AND status='review'")
                ->execute([$amount,$adminId?:null,$rateId,$groupId]);
        }
        $pdo->commit();
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}

function tsSCRFindPaxRate(PDO $pdo, int $groupId, int $basePax, ?string $travelDate = null, ?string $travelEndDate = null): ?array
{
    if ($groupId <= 0 || $basePax <= 0) return null;
    $sql="SELECT pr.*,g.*,pr.id pax_rate_id,g.id rate_group_id,
                 i.title itinerary_title,i.duration_nights,i.duration_days,i.destination_id,i.contract_id itinerary_contract_id,i.contract_version_id itinerary_version_id,i.source_order itinerary_source_order,
                 c.contract_code,c.contract_name,s.company_name supplier_name,s.priority supplier_priority,
                 v.version_no,v.version_label,v.season_name,v.season_key,v.season_type,v.rate_priority,v.applicability_basis,
                 v.valid_from version_valid_from,v.valid_to version_valid_to
          FROM supplier_contract_pax_rates pr
          JOIN supplier_contract_rate_groups g ON g.id=pr.rate_group_id
          JOIN supplier_contract_itineraries i ON i.id=g.itinerary_id
          JOIN supplier_contract_versions v ON v.id=g.contract_version_id
          JOIN supplier_contracts c ON c.id=i.contract_id
          JOIN suppliers s ON s.id=i.supplier_id
          WHERE pr.rate_group_id=? AND pr.status='active' AND g.status='active' AND i.status='active'
            AND v.status='active' AND c.status='active'
            AND pr.pax_min<=? AND pr.pax_max>=?
          ORDER BY (pr.pax_max-pr.pax_min) ASC,pr.pax_min DESC,pr.id ASC LIMIT 1";
    $stmt=$pdo->prepare($sql);$stmt->execute([$groupId,$basePax,$basePax]);$row=$stmt->fetch(PDO::FETCH_ASSOC)?:null;
    if(!$row)return null;
    $trip=['travel_start_date'=>$travelDate,'travel_end_date'=>$travelEndDate,'enquiry_travel_date'=>$travelDate];
    $match=tsSCRSeasonMatch($row,$trip);
    if($match===null)return null;
    $row['_season_match']=$match;
    return $row;
}

function tsSCRCalculate(array $rate, int $basePax, int $extraBedCount=0, int $childWithoutBedCount=0, int $childWithBedCount=0): array
{
    $basePax=max(1,$basePax);$extraBedCount=max(0,$extraBedCount);$childWithoutBedCount=max(0,$childWithoutBedCount);$childWithBedCount=max(0,$childWithBedCount);
    $adultRate=max(0,(float)($rate['rate_per_person']??0));
    if($adultRate<=0)throw new RuntimeException('The selected supplier PAX rate is zero.');
    $extra=$rate['extra_bed_rate']!==null?(float)$rate['extra_bed_rate']:null;
    $wob=$rate['child_without_bed_rate']!==null?(float)$rate['child_without_bed_rate']:null;
    $cwb=$rate['child_with_bed_rate']!==null?(float)$rate['child_with_bed_rate']:null;
    $basis=(string)($rate['child_with_bed_basis']??'not_available');
    if($extraBedCount>0 && ($extra===null||$extra<0))throw new RuntimeException('Extra Bed rate is not defined for this supplier category.');
    if($childWithoutBedCount>0 && ($wob===null||$wob<0))throw new RuntimeException('Child Without Bed rate is not defined for this supplier category.');
    if($childWithBedCount>0){
        if($basis==='use_extra_bed'){$cwb=$extra;}
        if($cwb===null||$cwb<0)throw new RuntimeException('Child With Bed rate is not defined. Review the supplier rule instead of guessing.');
    }
    $base=round($adultRate*$basePax,2);
    $extraTotal=round(($extra??0)*$extraBedCount,2);
    $wobTotal=round(($wob??0)*$childWithoutBedCount,2);
    $cwbTotal=round(($cwb??0)*$childWithBedCount,2);
    $net=round($base+$extraTotal+$wobTotal+$cwbTotal,2);
    $taxIncluded=!empty($rate['tax_included']);
    $taxPercent=max(0,(float)($rate['tax_percent']??0));
    $tax=$taxIncluded?0.0:round($net*$taxPercent/100,2);
    return [
        'base_pax'=>$basePax,'adult_rate_per_person'=>$adultRate,'base_amount'=>$base,
        'extra_bed_count'=>$extraBedCount,'extra_bed_rate'=>$extra,'extra_bed_amount'=>$extraTotal,
        'child_without_bed_count'=>$childWithoutBedCount,'child_without_bed_rate'=>$wob,'child_without_bed_amount'=>$wobTotal,
        'child_with_bed_count'=>$childWithBedCount,'child_with_bed_rate'=>$cwb,'child_with_bed_amount'=>$cwbTotal,
        'supplier_net_amount'=>$net,'tax_included'=>$taxIncluded?1:0,'tax_percent'=>$taxPercent,'supplier_tax_amount'=>$tax,
        'supplier_total_amount'=>round($net+$tax,2),
    ];
}

function tsSCRTrip(PDO $pdo, int $tripId): ?array
{
    $stmt=$pdo->prepare("SELECT t.*,e.name customer_name,e.destination customer_destination,e.travel_date enquiry_travel_date,d.name destination_name FROM trips t JOIN enquiries e ON e.id=t.enquiry_id LEFT JOIN destinations d ON d.id=t.destination_id WHERE t.id=? LIMIT 1");
    $stmt->execute([$tripId]);return $stmt->fetch(PDO::FETCH_ASSOC)?:null;
}

function tsSCRActiveGroupsForTrip(PDO $pdo, array $trip): array
{
    $destinationId=max(0,(int)($trip['destination_id']??0));
    $sql="SELECT g.*,i.title itinerary_title,i.source_heading itinerary_source_heading,i.supplier_package_code supplier_package_code,i.duration_nights,i.duration_days,i.valid_from itinerary_valid_from,i.valid_to itinerary_valid_to,i.source_order itinerary_source_order,
                 c.contract_code,c.contract_name,s.company_name supplier_name,s.priority supplier_priority,
                 v.version_no,v.version_label,v.season_name,v.season_key,v.season_type,v.rate_priority,v.applicability_basis,
                 v.valid_from version_valid_from,v.valid_to version_valid_to
          FROM supplier_contract_rate_groups g
          JOIN supplier_contract_itineraries i ON i.id=g.itinerary_id
          JOIN supplier_contract_versions v ON v.id=g.contract_version_id
          JOIN supplier_contracts c ON c.id=g.contract_id
          JOIN suppliers s ON s.id=g.supplier_id
          WHERE g.status='active' AND i.status='active' AND v.status='active' AND c.status='active'";
    $params=[];
    if($destinationId>0){$sql.=' AND (i.destination_id=? OR i.destination_id IS NULL)';$params[]=$destinationId;}
    $sql.=" ORDER BY CASE s.priority WHEN 'preferred' THEN 1 WHEN 'regular' THEN 2 ELSE 3 END, i.duration_days, g.source_order, s.company_name, v.rate_priority DESC, v.version_no DESC";
    $stmt=$pdo->prepare($sql);$stmt->execute($params);$rows=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];

    $winners=[];
    foreach($rows as $row){
        $match=tsSCRSeasonMatch($row,$trip);
        if($match===null)continue;
        $row['_season_match']=$match;
        $productKey=tsSCRNormalizePackageCode((string)($row['itinerary_source_heading']??''));
        if($productKey===''){
            $productKey=strtolower(trim((string)($row['itinerary_title']??''))).'|'.(int)($row['duration_nights']??0).'N|'.(int)($row['duration_days']??0).'D';
        }
        $key=(int)$row['contract_id'].'|'.$productKey.'|'.strtolower(trim((string)$row['supplier_category'])).'|'.strtolower(trim((string)($row['meal_plan']??'')));
        if(!isset($winners[$key])){$winners[$key]=$row;continue;}
        $cur=$winners[$key];
        $p=(int)($row['rate_priority']??10);$cp=(int)($cur['rate_priority']??10);
        $ov=(int)($match['overlap_days']??0);$cov=(int)($cur['_season_match']['overlap_days']??0);
        $vn=(int)($row['version_no']??0);$cvn=(int)($cur['version_no']??0);
        if($p>$cp || ($p===$cp && $ov>$cov) || ($p===$cp && $ov===$cov && $vn>$cvn))$winners[$key]=$row;
    }
    $out=array_values($winners);
    usort($out,static function(array $a,array $b):int{
        $pa=['preferred'=>1,'regular'=>2];
        $sa=$pa[strtolower((string)($a['supplier_priority']??''))]??3;
        $sb=$pa[strtolower((string)($b['supplier_priority']??''))]??3;
        if($sa!==$sb)return $sa<=>$sb;
        $d=(int)($a['duration_days']??0)<=>(int)($b['duration_days']??0);if($d!==0)return $d;
        $p=(int)($b['rate_priority']??10)<=>(int)($a['rate_priority']??10);if($p!==0)return $p;
        return strcasecmp((string)($a['supplier_name']??''),(string)($b['supplier_name']??''));
    });
    return $out;
}

function tsSCREnsureCostSheet(PDO $pdo, array $trip, int $adminId, string $currency): array
{
    $currency = strtoupper(trim($currency)) ?: 'INR';
    if(function_exists('crmEnsureActiveCostSheet')) {
        $sheet = crmEnsureActiveCostSheet($pdo,(int)$trip['id'],(int)$trip['enquiry_id'],$adminId,$currency);
    } else {
        $stmt=$pdo->prepare("SELECT * FROM cost_sheets WHERE trip_id=? AND status='active' ORDER BY version_number DESC,id DESC LIMIT 1");
        $stmt->execute([(int)$trip['id']]);
        $sheet=$stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        if(!$sheet){
            $pdo->prepare("INSERT INTO cost_sheets(trip_id,enquiry_id,version_number,status,currency,created_by_admin_id) VALUES(?,?,1,'active',?,?)")
                ->execute([(int)$trip['id'],(int)$trip['enquiry_id'],$currency,$adminId?:null]);
            $stmt=$pdo->prepare('SELECT * FROM cost_sheets WHERE id=?');
            $stmt->execute([(int)$pdo->lastInsertId()]);
            $sheet=$stmt->fetch(PDO::FETCH_ASSOC) ?: [];
        }
    }

    if(!$sheet) throw new RuntimeException('Unable to prepare Trip Cost Sheet.');
    $sheetCurrency = strtoupper(trim((string)($sheet['currency'] ?? 'INR'))) ?: 'INR';
    $existingTotal = max(0,(float)($sheet['travscope_cost_total'] ?? 0));
    if($existingTotal > 0 && $sheetCurrency !== $currency) {
        throw new RuntimeException('Trip Cost Sheet is already in '.$sheetCurrency.'. Supplier contract rate '.$currency.' cannot be mixed until FX conversion is configured.');
    }
    if($existingTotal <= 0 && $sheetCurrency !== $currency) {
        $pdo->prepare('UPDATE cost_sheets SET currency=?,updated_at=NOW() WHERE id=?')->execute([$currency,(int)$sheet['id']]);
        $sheet['currency']=$currency;
    }
    return $sheet;
}

function tsSCRRecalculateCostSheet(PDO $pdo, int $sheetId): void
{
    if(function_exists('crmRecalculateCostSheet')){crmRecalculateCostSheet($pdo,$sheetId);return;}
    $stmt=$pdo->prepare("SELECT COALESCE(SUM(CASE WHEN source_type IN ('supplier_quote','contract_rate') THEN line_cost ELSE 0 END),0) supplier_total,COALESCE(SUM(CASE WHEN source_type NOT IN ('supplier_quote','contract_rate') THEN line_cost ELSE 0 END),0) direct_total FROM cost_sheet_items WHERE cost_sheet_id=?");$stmt->execute([$sheetId]);$r=$stmt->fetch(PDO::FETCH_ASSOC)?:[];
    $sup=(float)($r['supplier_total']??0);$dir=(float)($r['direct_total']??0);$pdo->prepare('UPDATE cost_sheets SET supplier_cost_total=?,direct_cost_total=?,travscope_cost_total=?,updated_at=NOW() WHERE id=?')->execute([$sup,$dir,$sup+$dir,$sheetId]);
}

function tsSCRApplyToTrip(PDO $pdo, int $tripId, int $groupId, int $basePax, int $extraBedCount, int $childWithoutBedCount, int $childWithBedCount, int $adminId): array
{
    if(!tsSCRReady($pdo))throw new RuntimeException('Step 11C SQL is not installed.');
    $trip=tsSCRTrip($pdo,$tripId);if(!$trip)throw new RuntimeException('Trip not found.');
    $travelDate=trim((string)($trip['travel_start_date']??$trip['enquiry_travel_date']??''));
    $travelEndDate=trim((string)($trip['travel_end_date']??''));
    $rate=tsSCRFindPaxRate($pdo,$groupId,$basePax,$travelDate!==''?$travelDate:null,$travelEndDate!==''?$travelEndDate:null);
    if(!$rate){
        $available=[];
        try{$st=$pdo->prepare("SELECT pax_min,pax_max,source_pax_label FROM supplier_contract_pax_rates WHERE rate_group_id=? AND status='active' ORDER BY pax_min,pax_max");$st->execute([$groupId]);foreach($st->fetchAll(PDO::FETCH_ASSOC)?:[] as $pr){$available[]=trim((string)($pr['source_pax_label']??''))?:((int)$pr['pax_min']===(int)$pr['pax_max']?(int)$pr['pax_min'].' PAX':(int)$pr['pax_min'].'-'.(int)$pr['pax_max'].' PAX');}}catch(Throwable $ignore){}
        $suffix=$available?' Available published slabs: '.implode(', ',array_unique($available)).'.':'';
        throw new RuntimeException('No ACTIVE exact supplier PAX rate matches '.$basePax.' paying PAX for this travel date.'.$suffix.' Do not estimate a missing supplier slab.');
    }
    if(!empty($trip['destination_id'])&&!empty($rate['destination_id'])&&(int)$trip['destination_id']!==(int)$rate['destination_id'])throw new RuntimeException('This supplier rate belongs to a different destination.');
    $calc=tsSCRCalculate($rate,$basePax,$extraBedCount,$childWithoutBedCount,$childWithBedCount);
    $currency=strtoupper(trim((string)($rate['currency']??'INR')))?:'INR';
    $sheet=tsSCREnsureCostSheet($pdo,$trip,$adminId,$currency);$sheetId=(int)($sheet['id']??0);if($sheetId<=0)throw new RuntimeException('Unable to prepare Trip Cost Sheet.');

    $pdo->beginTransaction();
    try{
        $src=$pdo->prepare('SELECT x.cost_sheet_item_id FROM cost_sheet_contract_package_sources x JOIN cost_sheet_items i ON i.id=x.cost_sheet_item_id WHERE x.trip_id=? AND i.cost_sheet_id=?');$src->execute([$tripId,$sheetId]);$old=array_map('intval',$src->fetchAll(PDO::FETCH_COLUMN)?:[]);
        if($old){$ph=implode(',',array_fill(0,count($old),'?'));$pdo->prepare("DELETE FROM cost_sheet_contract_package_sources WHERE cost_sheet_item_id IN ($ph)")->execute($old);$pdo->prepare("DELETE FROM cost_sheet_items WHERE id IN ($ph)")->execute($old);}
        $sortStmt=$pdo->prepare('SELECT COALESCE(MAX(sort_order),0)+10 FROM cost_sheet_items WHERE cost_sheet_id=?');$sortStmt->execute([$sheetId]);$sort=(int)$sortStmt->fetchColumn();
        $seasonLabel=trim((string)($rate['season_name']??''));
        $desc=(string)$rate['supplier_name'].' · '.(string)$rate['contract_code'].' · '.(string)$rate['itinerary_title'].' · '.(string)$rate['supplier_category'].' · '.(string)$rate['source_pax_label'].($seasonLabel!==''?' · '.$seasonLabel:'');
        $pdo->prepare("INSERT INTO cost_sheet_items(cost_sheet_id,service_requirement_id,supplier_id,source_type,item_type,description,quantity,unit_cost,line_cost,sort_order,created_by_admin_id) VALUES(?,NULL,?,'contract_rate','package',?,1,?,?,?,?)")
            ->execute([$sheetId,(int)$rate['supplier_id'],$desc,(float)$calc['supplier_total_amount'],(float)$calc['supplier_total_amount'],$sort,$adminId?:null]);
        $itemId=(int)$pdo->lastInsertId();
        $pdo->prepare("INSERT INTO cost_sheet_contract_package_sources(cost_sheet_item_id,trip_id,contract_version_id,itinerary_id,rate_group_id,pax_rate_id,base_pax,extra_bed_count,child_without_bed_count,child_with_bed_count,supplier_net_amount,supplier_tax_amount,supplier_total_amount,calculation_json,created_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
            ->execute([$itemId,$tripId,(int)$rate['contract_version_id'],(int)$rate['itinerary_id'],(int)$rate['rate_group_id'],(int)$rate['pax_rate_id'],$basePax,$extraBedCount,$childWithoutBedCount,$childWithBedCount,(float)$calc['supplier_net_amount'],(float)$calc['supplier_tax_amount'],(float)$calc['supplier_total_amount'],json_encode(['rate'=>$rate,'calculation'=>$calc],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$adminId?:null]);
        $pdo->commit();
        tsSCRRecalculateCostSheet($pdo,$sheetId);
        if (function_exists('tsCWMarkSupplierCostChanged')) {
            tsCWMarkSupplierCostChanged(
                $pdo,
                $tripId,
                (int)($trip['enquiry_id'] ?? 0),
                'Supplier Contract Rate applied/changed: ' . $desc . ' · ' . $currency . ' ' . number_format((float)$calc['supplier_total_amount'], 2),
                null,
                ['rate_group_id'=>$groupId,'pax_rate_id'=>(int)($rate['pax_rate_id']??0),'cost_sheet_id'=>$sheetId]
            );
        }
        return ['cost_sheet_id'=>$sheetId,'cost_sheet_item_id'=>$itemId,'rate'=>$rate,'calculation'=>$calc];
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
