<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — COMMUNICATION AUTOMATION CRON (CLI ONLY)
|--------------------------------------------------------------------------
| Example test:
| php communication-cron.php --run --booking=123 --limit=10
|
| After testing one Booking:
| php communication-cron.php --run --all --limit=25
|
| This file refuses browser execution.
|--------------------------------------------------------------------------
*/

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("CLI only.\n");
}

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/communication-functions.php';

$reminderFunctions = __DIR__ . '/reminder-functions.php';
if (is_file($reminderFunctions)) {
    require_once $reminderFunctions;
}

$docFunctions = __DIR__ . '/document-functions.php';
if (is_file($docFunctions)) {
    require_once $docFunctions;
}

$jobFunctions = __DIR__ . '/job-functions.php';
if (is_file($jobFunctions)) {
    require_once $jobFunctions;
}

$options =
    getopt(
        '',
        [
            'run',
            'all',
            'booking:',
            'limit::',
        ]
    );

if (!isset($options['run'])) {
    echo
        "DRY/SAFETY MODE: no messages sent. "
        . "Add --run and either --booking=ID or --all.\n";

    exit(0);
}

$limit =
    max(
        1,
        min(
            100,
            (int)(
                $options['limit']
                ?? 25
            )
        )
    );

$bookingId =
    max(
        0,
        (int)(
            $options['booking']
            ?? 0
        )
    );

$all =
    isset(
        $options['all']
    );

$job =
    function_exists('tsJobBegin')
        ? tsJobBegin(
            $pdo,
            'communication_automation',
            [
                'booking_id' =>
                    $bookingId > 0
                        ? $bookingId
                        : null,

                'all' => $all,
                'limit' => $limit,
            ]
        )
        : [
            'tracked' => false,
            'acquired' => true,
            'disabled' => false,
            'job_key' =>
                'communication_automation',
            'started_at' =>
                microtime(true),
        ];

if (!empty($job['disabled'])) {
    echo
        "Communication automation is disabled in System Jobs Control Center.\n";

    exit(0);
}

if (empty($job['acquired'])) {
    fwrite(
        STDERR,
        "Overlap prevented: another Communication cron is still running.\n"
    );

    exit(4);
}

if (!tsCommReady($pdo)) {
    if (function_exists('tsJobFinish')) {
        tsJobFinish(
            $pdo,
            $job,
            'failure',
            2,
            'Communication Center SQL is not installed.'
        );
    }

    fwrite(
        STDERR,
        "Communication Center SQL is not installed.\n"
    );

    exit(2);
}

if (!$bookingId && !$all) {
    if (function_exists('tsJobFinish')) {
        tsJobFinish(
            $pdo,
            $job,
            'failure',
            2,
            'Missing required --booking=ID or --all option.'
        );
    }

    fwrite(
        STDERR,
        "Choose --booking=ID for testing or --all for live automation.\n"
    );

    exit(2);
}

try {
    $bookingIds = [];

    if ($bookingId > 0) {
        $bookingIds = [
            $bookingId
        ];

    } else {
        $stmt =
            $pdo->query("
                SELECT id
                FROM bookings
                WHERE booking_status <> 'cancelled'
                ORDER BY id ASC
                LIMIT 500
            ");

        $bookingIds =
            array_map(
                'intval',
                $stmt->fetchAll(
                    PDO::FETCH_COLUMN
                )
                ?: []
            );
    }

    $refreshFailures = [];

    foreach ($bookingIds as $id) {
        try {
            tsCommRefreshJobs(
                $pdo,
                $id
            );

        } catch (Throwable $e) {
            $refreshFailures[] =
                'Booking #'
                . $id
                . ' refresh failed: '
                . $e->getMessage();

            fwrite(
                STDERR,
                end($refreshFailures)
                . PHP_EOL
            );
        }
    }

    $automation = [
        'sent' => 0,
        'failed' => 0,
        'errors' => [],
        'quotation' => ['eligible'=>0,'sent'=>0,'failed'=>0],
        'supplier_quote' => ['eligible'=>0,'sent'=>0,'failed'=>0],
        'supplier_confirmation' => ['eligible'=>0,'sent'=>0,'failed'=>0],
    ];

    if ($all && function_exists('tsAutoRun')) {
        $automation = tsAutoRun($pdo, $limit, null, true);

        echo "Cross-stage reminders:
";
        foreach ([
            'quotation' => 'Customer quotation',
            'supplier_quote' => 'Supplier RFQ',
            'supplier_confirmation' => 'Supplier booking confirmation',
        ] as $key => $label) {
            $bucket = (array)($automation[$key] ?? []);
            echo ' - ' . $label . ': '
                . (int)($bucket['sent'] ?? 0) . ' sent, '
                . (int)($bucket['failed'] ?? 0) . ' failed, '
                . (int)($bucket['eligible'] ?? 0) . " eligible.
";
        }
    }

    $result =
        tsCommRunDueJobs(
            $pdo,
            $bookingId > 0
                ? $bookingId
                : null,
            0,
            $limit
        );

    echo
        'Sent: '
        . (int)$result['sent']
        . PHP_EOL;

    echo
        'Failed: '
        . (int)$result['failed']
        . PHP_EOL;

    foreach (
        (array)$result['errors']
        as $error
    ) {
        fwrite(
            STDERR,
            $error
            . PHP_EOL
        );
    }

    foreach ((array)($automation['errors'] ?? []) as $error) {
        fwrite(STDERR, '[Reminder] ' . $error . PHP_EOL);
    }

    $failed =
        (int)$result['failed']
        + (int)($automation['failed'] ?? 0);

    $status =
        $failed > 0
            ? 'failure'
            : (
                $refreshFailures
                    ? 'warning'
                    : 'success'
            );

    $exitCode =
        $failed > 0
            ? 1
            : 0;

    $summary =
        'Booking/customer jobs sent '
        . (int)$result['sent']
        . '; cross-stage reminders sent '
        . (int)($automation['sent'] ?? 0)
        . '; total failures '
        . $failed
        . '; refresh warnings '
        . count($refreshFailures)
        . '.';

    if (function_exists('tsJobFinish')) {
        tsJobFinish(
            $pdo,
            $job,
            $status,
            $exitCode,
            $summary,
            [
                'sent' =>
                    (int)$result['sent'],

                'failed' =>
                    $failed,

                'refresh_failures' =>
                    $refreshFailures,

                'cross_stage_automation' =>
                    $automation,

                'errors' =>
                    (array)$result[
                        'errors'
                    ],
            ]
        );
    }

    exit($exitCode);

} catch (Throwable $e) {
    if (function_exists('tsJobFinish')) {
        tsJobFinish(
            $pdo,
            $job,
            'failure',
            1,
            'Communication cron failed: '
                . $e->getMessage()
        );
    }

    fwrite(
        STDERR,
        'Communication cron failed: '
        . $e->getMessage()
        . PHP_EOL
    );

    exit(1);
}
