<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE - UNSPLASH PHOTO SEARCH HELPERS
|--------------------------------------------------------------------------
| Server-side only. Uses UNSPLASH_ACCESS_KEY from config.php.
| Search results keep official Unsplash hotlinked image URLs. When staff
| chooses a photo, the Unsplash download-location tracking endpoint is called.
|--------------------------------------------------------------------------
*/

if (!function_exists('tsUnsplashAccessKey')) {
    function tsUnsplashAccessKey(): string
    {
        return defined('UNSPLASH_ACCESS_KEY')
            ? trim((string)UNSPLASH_ACCESS_KEY)
            : '';
    }
}

if (!function_exists('tsUnsplashUtmUrl')) {
    function tsUnsplashUtmUrl(string $url): string
    {
        $url = trim($url);
        if ($url === '') return '';
        $separator = str_contains($url, '?') ? '&' : '?';
        return $url . $separator . 'utm_source=travscope&utm_medium=referral';
    }
}

if (!function_exists('tsUnsplashSearchPhotos')) {
    function tsUnsplashSearchPhotos(string $query, int $page = 1, ?int $perPage = null): array
    {
        $apiKey = tsUnsplashAccessKey();
        if ($apiKey === '') {
            throw new RuntimeException('Unsplash Access Key is not configured in config.php.');
        }
        if (!function_exists('curl_init')) {
            throw new RuntimeException('PHP cURL is required for Unsplash photo search.');
        }
        if (!function_exists('tsPexelsHttpRequest')) {
            throw new RuntimeException('TRAVSCOPE HTTP helper is unavailable.');
        }

        $query = trim($query);
        if ($query === '') {
            throw new RuntimeException('Please enter a photo search keyword.');
        }

        $page = max(1, $page);
        $perPage = $perPage ?? (defined('UNSPLASH_API_PER_PAGE') ? (int)UNSPLASH_API_PER_PAGE : 24);
        $perPage = max(1, min(30, $perPage));
        $base = defined('UNSPLASH_API_BASE_URL')
            ? rtrim((string)UNSPLASH_API_BASE_URL, '/')
            : 'https://api.unsplash.com';

        $url = $base
            . '/search/photos?query=' . rawurlencode($query)
            . '&orientation=landscape'
            . '&content_filter=high'
            . '&order_by=relevant'
            . '&page=' . $page
            . '&per_page=' . $perPage;

        $request = tsPexelsHttpRequest(
            $url,
            [
                'Authorization: Client-ID ' . $apiKey,
                'Accept-Version: v1',
                'Accept: application/json',
                'Connection: close',
            ],
            null,
            defined('UNSPLASH_API_TIMEOUT') ? max(20, (int)UNSPLASH_API_TIMEOUT) : 30
        );

        $status = (int)($request['status'] ?? 0);
        $data = json_decode((string)($request['body'] ?? ''), true);
        if ($status !== 200 || !is_array($data)) {
            $message = is_array($data)
                ? trim((string)($data['errors'][0] ?? $data['error'] ?? ''))
                : '';
            throw new RuntimeException($message !== '' ? $message : 'Unsplash search failed.');
        }

        $photos = [];
        foreach (($data['results'] ?? []) as $photo) {
            if (!is_array($photo)) continue;
            $urls = is_array($photo['urls'] ?? null) ? $photo['urls'] : [];
            $links = is_array($photo['links'] ?? null) ? $photo['links'] : [];
            $user = is_array($photo['user'] ?? null) ? $photo['user'] : [];
            $userLinks = is_array($user['links'] ?? null) ? $user['links'] : [];

            $id = trim((string)($photo['id'] ?? ''));
            $preview = trim((string)($urls['small'] ?? $urls['regular'] ?? ''));
            $hotlink = trim((string)($urls['regular'] ?? $urls['full'] ?? $urls['raw'] ?? ''));
            if ($id === '' || $preview === '' || $hotlink === '') continue;

            $photos[] = [
                'provider' => 'unsplash',
                'provider_label' => 'Unsplash',
                'id' => $id,
                'preview' => $preview,
                'download' => $hotlink,
                'photo_url' => tsUnsplashUtmUrl((string)($links['html'] ?? '')),
                'photographer' => trim((string)($user['name'] ?? 'Unsplash contributor')),
                'photographer_url' => tsUnsplashUtmUrl((string)($userLinks['html'] ?? '')),
                'alt' => trim((string)($photo['alt_description'] ?? $photo['description'] ?? $query)),
                'download_location' => trim((string)($links['download_location'] ?? '')),
                'width' => (int)($photo['width'] ?? 0),
                'height' => (int)($photo['height'] ?? 0),
            ];
        }

        return [
            'photos' => $photos,
            'page' => $page,
            'per_page' => $perPage,
            'total_results' => (int)($data['total'] ?? count($photos)),
            'next_page' => $page < (int)($data['total_pages'] ?? $page),
            'prev_page' => $page > 1,
        ];
    }
}

if (!function_exists('tsInterleavePhotoProviders')) {
    function tsInterleavePhotoProviders(array $pexelsPhotos, array $unsplashPhotos): array
    {
        $photos = [];
        $max = max(count($pexelsPhotos), count($unsplashPhotos));
        for ($i = 0; $i < $max; $i++) {
            if (isset($pexelsPhotos[$i])) $photos[] = $pexelsPhotos[$i];
            if (isset($unsplashPhotos[$i])) $photos[] = $unsplashPhotos[$i];
        }
        return $photos;
    }
}

if (!function_exists('tsTrackUnsplashDownload')) {
    function tsTrackUnsplashDownload(string $downloadLocation): void
    {
        $downloadLocation = trim($downloadLocation);
        if ($downloadLocation === '' || !filter_var($downloadLocation, FILTER_VALIDATE_URL)) return;

        $host = strtolower((string)parse_url($downloadLocation, PHP_URL_HOST));
        $path = (string)parse_url($downloadLocation, PHP_URL_PATH);
        if ($host !== 'api.unsplash.com' || !str_contains($path, '/photos/') || !str_ends_with($path, '/download')) return;

        try {
            tsPexelsHttpRequest(
                $downloadLocation,
                [
                    'Authorization: Client-ID ' . tsUnsplashAccessKey(),
                    'Accept-Version: v1',
                    'Accept: application/json',
                    'Connection: close',
                ],
                null,
                20
            );
        } catch (Throwable $e) {
            error_log('Unsplash download tracking failed: ' . $e->getMessage());
        }
    }
}

if (!function_exists('tsOfficialUnsplashImageUrl')) {
    function tsOfficialUnsplashImageUrl(string $url): bool
    {
        if (!filter_var($url, FILTER_VALIDATE_URL)) return false;
        return strtolower((string)parse_url($url, PHP_URL_SCHEME)) === 'https'
            && strtolower((string)parse_url($url, PHP_URL_HOST)) === 'images.unsplash.com';
    }
}
