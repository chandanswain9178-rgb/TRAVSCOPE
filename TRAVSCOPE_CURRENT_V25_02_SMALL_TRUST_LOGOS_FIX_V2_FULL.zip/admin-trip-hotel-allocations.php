<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/hotel-allocation-functions.php';

if (empty($_SESSION['admin_id'])) {
    redirect(BASE_URL . 'admin-login.php');
}
$adminId = (int)$_SESSION['admin_id'];
$stmt=$pdo->prepare("SELECT id,name,email,role,status FROM admins WHERE id=? LIMIT 1");$stmt->execute([$adminId]);$admin=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$admin || (string)$admin['status']!=='active'){unset($_SESSION['admin_id']);redirect(BASE_URL.'admin-login.php');}

function haE($v): string { return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function haDate($v): string { $v=trim((string)$v); if($v==='')return '-';$t=strtotime($v);return $t?date('d M Y',$t):$v; }

if (empty($_SESSION['hotel_allocation_csrf'])) $_SESSION['hotel_allocation_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['hotel_allocation_csrf'];

$bookingId=max(0,(int)($_GET['booking_id'] ?? $_POST['booking_id'] ?? 0));
$tripId=max(0,(int)($_GET['trip_id'] ?? $_POST['trip_id'] ?? 0));

if($bookingId>0 && $tripId<=0 && tsHATableExists($pdo,'booking_trip_links')){
    $s=$pdo->prepare("SELECT trip_id FROM booking_trip_links WHERE booking_id=? LIMIT 1");$s->execute([$bookingId]);$tripId=(int)($s->fetchColumn()?:0);
}
if($tripId<=0){http_response_code(400);exit('Valid Trip is required.');}

$tripStmt=$pdo->prepare("\nSELECT t.*,e.name customer_name,e.email customer_email,e.mobile customer_mobile,e.destination customer_destination\nFROM trips t JOIN enquiries e ON e.id=t.enquiry_id WHERE t.id=? LIMIT 1\n");
$tripStmt->execute([$tripId]);$trip=$tripStmt->fetch(PDO::FETCH_ASSOC);
if(!$trip){http_response_code(404);exit('Trip not found.');}

$versionStmt=$pdo->prepare("SELECT id,version_number,package_title,hotel_category,travel_date,adults,children,created_at FROM crm_package_versions WHERE lead_id=? ORDER BY version_number DESC,id DESC");
$versionStmt->execute([(int)$trip['enquiry_id']]);$versions=$versionStmt->fetchAll(PDO::FETCH_ASSOC)?:[];
$versionId=max(0,(int)($_GET['version_id'] ?? $_POST['version_id'] ?? 0));
if($versionId<=0 && $bookingId>0 && tsHATableExists($pdo,'booking_trip_links')){
    $s=$pdo->prepare("SELECT quotation_version_id FROM booking_trip_links WHERE booking_id=? LIMIT 1");$s->execute([$bookingId]);$versionId=(int)($s->fetchColumn()?:0);
}
if($versionId<=0 && $versions)$versionId=(int)$versions[0]['id'];
$selectedVersion=null;foreach($versions as $v){if((int)$v['id']===$versionId){$selectedVersion=$v;break;}}
if(!$selectedVersion && $versions){$selectedVersion=$versions[0];$versionId=(int)$selectedVersion['id'];}
if(!$selectedVersion){exit('Create a quotation version first.');}

$error='';$success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        $token=(string)($_POST['csrf_token']??'');
        if($token===''||!hash_equals($csrf,$token))throw new RuntimeException('Security verification failed. Refresh and try again.');
        if(!tsHAReady($pdo))throw new RuntimeException('Step 11F SQL is not installed.');
        $action=(string)($_POST['action']??'');
        if($action==='build'){
            $result=tsHABuildForQuotation($pdo,$tripId,$versionId,$selectedVersion['hotel_category']??null,(string)($selectedVersion['travel_date']??''),null,$adminId,true);
            $success='Hotel plan rebuilt from the exact quotation itinerary. '.(int)$result['created'].' allocation segment(s) created.';
            if(!empty($result['warning']))$success.=' '.(string)$result['warning'];
        }elseif($action==='mark_requested'){
            $count=tsHAMarkRequested($pdo,$versionId,$adminId);
            $success=$count.' proposed hotel segment(s) marked Requested. This status records your supplier follow-up; it does not send a message automatically.';
        }elseif($action==='save_allocation'){
            $id=max(0,(int)($_POST['allocation_id']??0));
            tsHAUpdateAllocation($pdo,$id,[
                'hotel_choice'=>$_POST['hotel_choice']??'',
                'inventory_id'=>$_POST['inventory_id']??0,
                'hotel_id'=>$_POST['hotel_id']??0,
                'room_type'=>$_POST['room_type']??'',
                'meal_plan'=>$_POST['meal_plan']??'',
                'allocation_status'=>$_POST['allocation_status']??'proposed',
                'supplier_confirmation_ref'=>$_POST['supplier_confirmation_ref']??'',
                'supplier_note'=>$_POST['supplier_note']??'',
            ],$adminId);
            $success='Trip hotel selection updated from the location-wise Hotel Master / Supplier Inventory.';
        }
    }catch(Throwable $e){$error=$e->getMessage();}
}

$rows=tsHAForQuotation($pdo,$versionId);
if(!$rows && tsHAReady($pdo)){
    try{tsHABuildForQuotation($pdo,$tripId,$versionId,$selectedVersion['hotel_category']??null,(string)($selectedVersion['travel_date']??''),null,$adminId,false);$rows=tsHAForQuotation($pdo,$versionId);}catch(Throwable $e){if($error==='')$error=$e->getMessage();}
}
$summary=tsHASummary($rows);
$contract=tsHASelectedContractContext($pdo,$tripId);

?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Destination-wise Hotels | TRAVSCOPE Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f3f6fb;color:#14213d;font:14px Arial,sans-serif}.top{background:#07192d;color:#fff;padding:18px 26px;display:flex;justify-content:space-between;align-items:center}.top strong{font-size:20px}.top a{color:#fff;text-decoration:none}.wrap{max-width:1500px;margin:22px auto;padding:0 18px}.head{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;margin-bottom:16px}.head h1{margin:0;font-size:27px}.muted{color:#6b7890}.buttons{display:flex;gap:8px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;gap:7px;border:0;border-radius:10px;padding:10px 14px;background:#fff;border:1px solid #d5dfeb;color:#19324f;text-decoration:none;font-weight:800;cursor:pointer}.btn.primary{background:#1769e0;color:#fff;border-color:#1769e0}.btn.green{background:#0b8f65;color:#fff;border-color:#0b8f65}.notice{padding:12px 14px;border-radius:10px;margin:12px 0}.notice.ok{background:#eafaf3;color:#087451;border:1px solid #bee9d7}.notice.err{background:#fff0f0;color:#a61b1b;border:1px solid #facaca}.stats{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin:14px 0}.stat{background:#fff;border:1px solid #dce5ef;border-radius:12px;padding:14px}.stat small{display:block;color:#718096;font-weight:700}.stat strong{display:block;font-size:22px;margin-top:5px}.context{background:#fff;border:1px solid #dce5ef;border-radius:13px;padding:14px;margin-bottom:14px;display:flex;gap:20px;flex-wrap:wrap}.context span{color:#6c7890}.context strong{display:block;margin-top:3px}.card{background:#fff;border:1px solid #dce5ef;border-radius:14px;margin-bottom:14px;overflow:hidden}.card-head{padding:14px 16px;background:#f8fbff;border-bottom:1px solid #e2e8f0;display:flex;justify-content:space-between;gap:12px;align-items:center}.card-head h3{margin:0}.badge{padding:5px 9px;border-radius:20px;background:#edf3fb;font-size:11px;font-weight:900;text-transform:uppercase}.badge.confirmed{background:#e8faf2;color:#08744f}.badge.requested{background:#fff5dd;color:#8d5a00}.badge.unavailable{background:#ffecec;color:#9c1d1d}.body{padding:15px}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.field label{display:block;font-size:11px;font-weight:800;color:#506078;margin-bottom:5px}.field input,.field select,.field textarea{width:100%;padding:10px;border:1px solid #ccd8e6;border-radius:8px;background:#fff}.field textarea{min-height:74px;resize:vertical}.readonly{width:100%;padding:10px;border:1px solid #e0e7f0;border-radius:8px;background:#f7f9fc;color:#25364d;min-height:38px}.wide{grid-column:span 2}.full{grid-column:1/-1}.alternatives{padding:10px;border-radius:9px;background:#f6f9fd;border:1px dashed #cbd8e6;margin-bottom:12px}.alternatives b{display:block;margin-bottom:6px}.chips{display:flex;flex-wrap:wrap;gap:6px}.chip{font-size:11px;padding:5px 8px;border-radius:20px;background:#fff;border:1px solid #d8e2ed}.save{display:flex;justify-content:flex-end;margin-top:12px}.empty{padding:34px;text-align:center;background:#fff;border:1px dashed #c9d4e1;border-radius:14px}.version-select{padding:9px;border:1px solid #ced9e6;border-radius:8px}@media(max-width:900px){.stats{grid-template-columns:1fr 1fr}.grid{grid-template-columns:1fr 1fr}.wide{grid-column:span 2}}@media(max-width:600px){.head{display:block}.buttons{margin-top:12px}.grid{grid-template-columns:1fr}.wide,.full{grid-column:auto}.stats{grid-template-columns:1fr 1fr}}
</style>
<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
<link rel="stylesheet" href="assets/crm-laptop-workspaces-v2498.css?v=2498">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head><body>
<div class="top"><strong>TRAVSCOPE · HOTEL ALLOCATION</strong><span><?=haE($admin['name']);?></span></div>
<div class="wrap">
<div class="head"><div><h1>Destination-wise Hotel Allocation</h1><p class="muted">Use supplier hotel pools destination-by-destination, freeze them to each quotation version, then confirm the actual property after booking.</p></div><div class="buttons"><a class="btn" href="<?=haE(BASE_URL.'admin-crm.php?lead='.(int)$trip['enquiry_id']);?>"><i class="fa-solid fa-arrow-left"></i> CRM</a><?php if($bookingId>0):?><a class="btn" href="<?=haE(BASE_URL.'admin-booking-details.php?id='.$bookingId);?>"><i class="fa-solid fa-suitcase"></i> Booking</a><?php endif;?><a class="btn" href="<?=haE(BASE_URL.'admin-trip-transport-allocations.php?trip_id='.$tripId.($bookingId>0?'&booking_id='.$bookingId:'').'&version_id='.$versionId);?>"><i class="fa-solid fa-van-shuttle"></i> Transport</a></div></div>

<?php if($success!==''):?><div class="notice ok"><?=haE($success);?></div><?php endif;?>
<?php if($error!==''):?><div class="notice err"><?=haE($error);?></div><?php endif;?>

<div class="context">
<div><span>Trip</span><strong><?=haE($trip['trip_code']);?> · <?=haE($trip['trip_title']);?></strong></div>
<div><span>Customer</span><strong><?=haE($trip['customer_name']);?></strong></div>
<div><span>Quotation Version</span><strong>V<?= (int)$selectedVersion['version_number'];?> · <?=haE($selectedVersion['package_title']);?></strong></div>
<div><span>Supplier Contract</span><strong><?=haE($contract ? (($contract['supplier_name']??'Supplier').' · '.($contract['contract_code']??'Contract').' · '.($contract['supplier_category']??'')) : 'Not selected in Contract Rate Engine');?></strong></div>
<div style="margin-left:auto"><form method="get"><input type="hidden" name="trip_id" value="<?=$tripId;?>"><?php if($bookingId):?><input type="hidden" name="booking_id" value="<?=$bookingId;?>"><?php endif;?><select class="version-select" name="version_id" onchange="this.form.submit()"><?php foreach($versions as $v):?><option value="<?=(int)$v['id'];?>" <?=(int)$v['id']===$versionId?'selected':'';?>>Quotation V<?=(int)$v['version_number'];?> · <?=haE($v['package_title']);?></option><?php endforeach;?></select></form></div>
</div>

<div class="stats"><div class="stat"><small>Segments</small><strong><?=(int)$summary['total'];?></strong></div><div class="stat"><small>Total Nights</small><strong><?=(int)$summary['nights'];?></strong></div><div class="stat"><small>Confirmed</small><strong><?=(int)$summary['confirmed'];?></strong></div><div class="stat"><small>Requested</small><strong><?=(int)$summary['requested'];?></strong></div><div class="stat"><small>Need Review</small><strong><?=(int)$summary['review'];?></strong></div></div>

<div class="buttons" style="margin-bottom:14px">
<form method="post" onsubmit="return confirm('Rebuild this quotation hotel plan from its itinerary? Requested or confirmed plans cannot be rebuilt.');"><input type="hidden" name="csrf_token" value="<?=haE($csrf);?>"><input type="hidden" name="trip_id" value="<?=$tripId;?>"><input type="hidden" name="booking_id" value="<?=$bookingId;?>"><input type="hidden" name="version_id" value="<?=$versionId;?>"><input type="hidden" name="action" value="build"><button class="btn primary"><i class="fa-solid fa-wand-magic-sparkles"></i> Build / Refresh From Itinerary</button></form>
<form method="post"><input type="hidden" name="csrf_token" value="<?=haE($csrf);?>"><input type="hidden" name="trip_id" value="<?=$tripId;?>"><input type="hidden" name="booking_id" value="<?=$bookingId;?>"><input type="hidden" name="version_id" value="<?=$versionId;?>"><input type="hidden" name="action" value="mark_requested"><button class="btn green"><i class="fa-solid fa-paper-plane"></i> Mark Proposed as Requested</button></form>
<?php if(!empty($selectedVersion['id'])):?><a class="btn" target="_blank" href="<?=haE(BASE_URL.'quotation.php?lead='.(int)$trip['enquiry_id'].'&version='.(int)$selectedVersion['id']);?>" onclick="alert('Use the signed customer link from CRM for real customer access. This shortcut may require a valid signed link.');return false;"><i class="fa-solid fa-file-lines"></i> Quotation V<?=(int)$selectedVersion['version_number'];?></a><?php endif;?>
</div>

<?php if(!$rows):?><div class="empty"><i class="fa-solid fa-hotel" style="font-size:34px;color:#7f8ea3"></i><h3>No hotel plan yet</h3><p class="muted">Click <b>Build / Refresh From Itinerary</b>. TRAVSCOPE will detect each overnight destination and load matching Hotel Master Pro properties plus supplier hotel alternatives for the selected quotation category.</p></div><?php endif;?>

<?php foreach($rows as $row):
    $alts=is_array($row['alternatives']??null)?$row['alternatives']:[];
    $masterHotels=is_array($row['master_hotels']??null)?$row['master_hotels']:[];
    $selectionMode=(string)($row['selection_mode']??'');
    $selectedInventoryId=0;
    if($selectionMode!=='hotel_master'){
        foreach($alts as $alt){
            if(trim((string)($row['hotel_name_snapshot']??''))!=='' && strcasecmp(trim((string)($alt['name']??'')),trim((string)($row['hotel_name_snapshot']??'')))===0){
                $selectedInventoryId=(int)($alt['inventory_id']??0);break;
            }
        }
    }
    $selectedMasterId=0;
    if($selectionMode==='hotel_master' && (int)($row['hotel_id']??0)>0){foreach($masterHotels as $mh){if((int)($mh['id']??0)===(int)$row['hotel_id']){$selectedMasterId=(int)$row['hotel_id'];break;}}}
?>
<section class="card">
<div class="card-head">
    <h3><?=haE($row['destination_name']);?> · <?=(int)$row['nights'];?> Night<?=((int)$row['nights']===1?'':'s');?><?php if(!empty($row['hotel_category'])):?> · <?=(int)$row['hotel_category'];?>★<?php endif;?></h3>
    <span class="badge <?=haE($row['allocation_status']);?>"><?=haE($row['allocation_status']);?></span>
</div>
<div class="body">

<div class="alternatives">
    <b>Location-wise hotel sources</b>
    <span class="muted">Quotation location: <?=haE((string)($row['destination_name']??''));?><?=!empty($row['hotel_category'])?' · '.(int)$row['hotel_category'].'★':'';?></span>
    <?php if($alts):?>
        <div style="margin-top:8px;font-size:10px;font-weight:900;color:#37536e">Supplier Contract Inventory</div>
        <div class="chips" style="margin-top:6px"><?php foreach(array_slice($alts,0,12) as $alt):?><span class="chip"><?=haE($alt['name']??'');?></span><?php endforeach;?><?php if(count($alts)>12):?><span class="chip">+<?=count($alts)-12;?> more</span><?php endif;?></div>
    <?php endif;?>
    <?php if($masterHotels):?>
        <div style="margin-top:10px;font-size:10px;font-weight:900;color:#0b6b50">Hotel Master Pro</div>
        <div class="chips" style="margin-top:6px"><?php foreach(array_slice($masterHotels,0,12) as $mh):?><span class="chip"><?=haE((string)($mh['hotel_name']??''));?><?php if(!empty($mh['location_name'])||!empty($mh['city'])):?> · <?=haE((string)($mh['location_name']?:$mh['city']));?><?php endif;?></span><?php endforeach;?><?php if(count($masterHotels)>12):?><span class="chip">+<?=count($masterHotels)-12;?> more</span><?php endif;?></div>
    <?php endif;?>
    <?php if(!$alts&&!$masterHotels&&(string)$row['accommodation_type']!=='houseboat'):?>
        <div style="margin-top:9px;color:#9a3412;font-weight:700">No active hotel exists for this exact location/category.</div>
        <div style="margin-top:8px"><a class="btn" href="<?=haE(BASE_URL.'admin-hotels.php');?>"><i class="fa-solid fa-plus"></i> Add Hotel in Hotel Master Pro</a><?php if(!empty($row['source_contract_version_id'])):?><a class="btn" href="<?=haE(BASE_URL.'admin-supplier-contract-inventory.php?version_id='.(int)$row['source_contract_version_id']);?>"><i class="fa-solid fa-hotel"></i> Supplier Inventory</a><?php endif;?></div>
    <?php elseif((string)$row['accommodation_type']==='houseboat'&&!$alts&&!$masterHotels):?>
        <div class="muted" style="margin-top:8px">Houseboat night detected. Confirm through supplier houseboat/service inventory.</div>
    <?php endif;?>
</div>

<div class="grid">
    <div class="field"><label>Overnight Destination</label><div class="readonly"><?=haE($row['destination_name']);?></div></div>
    <div class="field"><label>Accommodation Type</label><div class="readonly"><?=haE(ucwords((string)$row['accommodation_type']));?></div></div>
    <div class="field"><label>Check-in</label><div class="readonly"><?=haE(haDate($row['check_in_date']??''));?></div></div>
    <div class="field"><label>Check-out</label><div class="readonly"><?=haE(haDate($row['check_out_date']??''));?></div></div>
    <div class="field"><label>Nights</label><div class="readonly"><?=(int)$row['nights'];?></div></div>
    <div class="field"><label>Hotel Category</label><div class="readonly"><?=!empty($row['hotel_category'])?(int)$row['hotel_category'].' Star':'From supplier contract';?></div></div>
</div>

<form method="post" style="margin-top:12px">
<input type="hidden" name="csrf_token" value="<?=haE($csrf);?>">
<input type="hidden" name="action" value="save_allocation">
<input type="hidden" name="trip_id" value="<?=$tripId;?>">
<input type="hidden" name="booking_id" value="<?=$bookingId;?>">
<input type="hidden" name="version_id" value="<?=$versionId;?>">
<input type="hidden" name="allocation_id" value="<?=(int)$row['id'];?>">

<div class="grid">
    <div class="field wide">
        <label>Select / Confirm Location-wise Hotel</label>
        <select name="hotel_choice" <?=($alts||$masterHotels)?'':'disabled';?>>
            <option value="none">-- No specific hotel selected yet --</option>
            <?php if($masterHotels):?><optgroup label="Hotel Master Pro — Admin / Verified Properties"><?php foreach($masterHotels as $mh):$mid=(int)($mh['id']??0);if($mid<=0)continue;$loc=(string)($mh['location_name']?:($mh['city']??''));?><option value="master:<?=$mid;?>" <?=$selectedMasterId===$mid?'selected':'';?>><?=haE(($loc!==''?$loc.' · ':'').(string)$mh['hotel_name'].(!empty($mh['is_preferred'])?' · Preferred':''));?></option><?php endforeach;?></optgroup><?php endif;?>
            <?php if($alts):?><optgroup label="Supplier Contract Inventory"><?php foreach($alts as $alt):$inventoryId=(int)($alt['inventory_id']??0);if($inventoryId<=0)continue;$an=(string)($alt['name']??'');?><option value="inv:<?=$inventoryId;?>" <?=$selectedInventoryId===$inventoryId?'selected':'';?>><?=haE($an);?></option><?php endforeach;?></optgroup><?php endif;?>
        </select>
        <?php if(!$alts&&!$masterHotels):?><small class="muted">Add a matching <?=!empty($row['hotel_category'])?(int)$row['hotel_category'].'★ ':'';?>hotel for <?=haE((string)$row['destination_name']);?> in Hotel Master Pro, or add supplier inventory.</small><?php else:?><small class="muted">Hotel Master entries are destination/location/category matched. Supplier inventory remains available when you need contract-confirmed stock.</small><?php endif;?>
    </div>

    <div class="field"><label>Room Type for This Booking</label><input name="room_type" value="<?=haE($row['room_type']??'');?>" placeholder="Use supplier-confirmed room type"></div>
    <div class="field"><label>Meal Plan for This Booking</label><input name="meal_plan" value="<?=haE($row['meal_plan']??'');?>" placeholder="MAPAI / CPAI / AP"></div>

    <div class="field">
        <label>Status</label>
        <select name="allocation_status">
            <?php foreach(['proposed'=>'Proposed','requested'=>'Requested','confirmed'=>'Confirmed','unavailable'=>'Unavailable','replaced'=>'Replaced','cancelled'=>'Cancelled'] as $k=>$v):?>
                <option value="<?=haE($k);?>" <?=(string)$row['allocation_status']===$k?'selected':'';?>><?=haE($v);?></option>
            <?php endforeach;?>
        </select>
    </div>

    <div class="field"><label>Supplier Confirmation Ref</label><input name="supplier_confirmation_ref" value="<?=haE($row['supplier_confirmation_ref']??'');?>" placeholder="Hotel confirmation / voucher no."></div>

    <?php if(!empty($row['hotel_name_snapshot'])):?>
    <div class="field wide"><label>Currently Selected / Confirmed Hotel</label><div class="readonly"><strong><?=haE((string)$row['hotel_name_snapshot']);?></strong></div></div>
    <?php endif;?>

    <div class="field full"><label>Supplier / Internal Note</label><textarea name="supplier_note"><?=haE($row['supplier_note']??'');?></textarea></div>
</div>

<div class="save"><button class="btn primary"><i class="fa-solid fa-floppy-disk"></i> Save Selection / Status</button></div>
</form>
</div>
</section>
<?php endforeach;?>

<div class="notice" style="background:#eef5ff;border:1px solid #cfe0f6;color:#32506f"><b>Architecture:</b> hotels can be maintained in <b>Hotel Master Pro</b> (admin-managed properties with photos and location data) and in <b>Supplier Contract → Location-wise Hotel Inventory</b>. This Trip page consumes either approved source. Before confirmation, the customer sees destination + nights + category + suitable alternatives followed by “or similar”. After a hotel is marked <b>Confirmed</b>, the final voucher shows that exact property. Supplier names and supplier costs remain private.</div>
</div>
<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
<script src="assets/crm-laptop-workspaces-v2498.js?v=2498" defer></script>
</body></html>
