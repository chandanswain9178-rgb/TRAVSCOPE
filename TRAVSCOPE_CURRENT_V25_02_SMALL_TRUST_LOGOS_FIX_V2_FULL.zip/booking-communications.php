<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/communication-functions.php';

requireLogin();
$user=currentUser($pdo);
if(!$user){unset($_SESSION['user_id']);redirect(BASE_URL.'login.php');}
$userId=(int)$user['id'];
$bookingId=max(0,(int)($_GET['booking'] ?? 0));
if($bookingId<=0)redirect(BASE_URL.'my-bookings.php');
if(!tsCommReady($pdo)){http_response_code(503);exit('Booking Communication Center is not installed yet.');}
$booking=tsCommBooking($pdo,$bookingId);
if((int)($booking['user_id'] ?? 0)!==$userId){http_response_code(403);exit('You do not have permission to view this Booking communication history.');}
$trip=tsCommTripContext($pdo,$bookingId);
$timeline=tsCommTimeline($pdo,$bookingId,false);

$supportEmail=defined('MAIL_REPLY_TO')?(string)MAIL_REPLY_TO:(defined('MAIL_FROM_ADDRESS')?(string)MAIL_FROM_ADDRESS:'');
$waNumber=tsCommWhatsAppNumber((string)getSetting($pdo,'whatsapp_number',''));
function bcDate(?string $v): string{if(!$v)return '-';$ts=strtotime($v);return $ts?date('d M Y, h:i A',$ts):'-';}
?><!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Booking Messages | TRAVSCOPE.COM</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><style>
*{box-sizing:border-box}body{margin:0;background:#f5f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:66px;padding:10px 5%;display:flex;justify-content:space-between;align-items:center;gap:10px;background:#fff;border-bottom:1px solid #e2e8f0}.brand{font-weight:900}.brand span{color:#2563eb}.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 11px;border:1px solid #cbd5e1;border-radius:9px;background:#fff;color:#334155;text-decoration:none;font-size:10px;font-weight:900}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.btn.wa{background:#16a34a;border-color:#16a34a;color:#fff}.wrap{max-width:900px;margin:24px auto;padding:0 13px}.hero{padding:17px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:19px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px;line-height:1.5}.support{display:flex;gap:7px;flex-wrap:wrap;margin-top:10px}.card{margin-top:11px;background:#fff;border:1px solid #dfe7f0;border-radius:13px;overflow:hidden}.head{padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff}.head h2{margin:0;font-size:12px}.head p{margin:4px 0 0;color:#64748b;font-size:8.5px}.body{padding:11px}.timeline{display:grid;gap:8px}.msg{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.msg.outbound{border-left:4px solid #2563eb}.msg.inbound{border-left:4px solid #16a34a}.msg.quote{background:#fffbeb;border-color:#fde68a}.msg-top{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.msg strong{font-size:10px}.msg small{font-size:8px;color:#64748b}.msg pre{white-space:pre-wrap;font:inherit;font-size:9px;line-height:1.55;margin:8px 0 0}.quoted{margin-top:7px}.quoted summary{cursor:pointer;color:#64748b;font-size:8px;font-weight:900}.quoted pre{padding:8px;border-radius:8px;background:#f8fafc;color:#64748b}.empty{padding:15px;text-align:center;color:#94a3b8;font-size:9px}@media(max-width:650px){.top{align-items:flex-start;flex-direction:column}.msg-top{display:block}.msg-top>small{display:block;margin-top:4px}}
</style>
<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-public-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="public"></script>
</head><body>
<header class="top"><div class="brand">TRAV<span>SCOPE</span> · BOOKING MESSAGES</div><a class="btn primary" href="<?= e(BASE_URL.'booking-details.php?id='.$bookingId.'#customer-communication-center'); ?>"><i class="fa-solid fa-arrow-left"></i> Back to Booking</a></header>
<main class="wrap"><section class="hero"><h1>Communication History</h1><p>Booking <?= e((string)$booking['booking_number']); ?><?php if(!empty($trip['trip_code'])): ?> · Trip <?= e((string)$trip['trip_code']); ?><?php endif; ?>. This timeline keeps your accepted quotation email history together with post-booking customer communications.</p><div class="support"><?php if(filter_var($supportEmail,FILTER_VALIDATE_EMAIL)): ?><a class="btn" href="mailto:<?= e($supportEmail); ?>?subject=<?= e(rawurlencode('Booking '.(string)$booking['booking_number'])); ?>"><i class="fa-solid fa-envelope"></i> Email TRAVSCOPE</a><?php endif; ?><?php if($waNumber!==''): ?><a class="btn wa" target="_blank" rel="noopener" href="https://wa.me/<?= e($waNumber); ?>?text=<?= e(rawurlencode('Hello TRAVSCOPE, I need help with Booking '.(string)$booking['booking_number'])); ?>"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a><?php endif; ?></div></section>
<section class="card"><div class="head"><h2>Customer Communication Timeline</h2><p>Internal Admin notes are never shown here. Email quoted history is collapsed for easier reading.</p></div><div class="body"><div class="timeline">
<?php if(!$timeline): ?><div class="empty">No customer communication history has been recorded yet.</div><?php endif; ?>
<?php foreach($timeline as $message): $direction=(string)($message['direction'] ?? 'outbound'); $split=tsCommSplitQuotedReply((string)($message['body_text'] ?? '')); ?>
<div class="msg <?= e($direction); ?> <?= ($message['source']??'')==='quotation'?'quote':''; ?>"><div class="msg-top"><div><strong><?php if(($message['source']??'')==='quotation'): ?>QUOTATION · <?php endif; ?><?= e(strtoupper((string)($message['channel'] ?? 'email'))); ?> · <?= $direction==='inbound'?'YOU → TRAVSCOPE':'TRAVSCOPE → YOU'; ?></strong><?php if(!empty($message['subject'])): ?><small style="display:block;margin-top:3px"><?= e((string)$message['subject']); ?></small><?php endif; ?></div><small><?= e(bcDate((string)($message['timeline_at'] ?? $message['sent_at'] ?? $message['created_at'] ?? ''))); ?></small></div><pre><?= e($split['current']!==''?$split['current']:'(No current message text)'); ?></pre><?php if($split['quoted']!==''): ?><details class="quoted"><summary>Show quoted email history</summary><pre><?= e($split['quoted']); ?></pre></details><?php endif; ?></div>
<?php endforeach; ?>
</div></div></section></main>
<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
