<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
if (is_file(__DIR__ . '/location-master-functions.php')) require_once __DIR__ . '/location-master-functions.php';
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');
if (empty($_SESSION['admin_id'])) { http_response_code(401); echo json_encode(['success'=>false,'message'=>'Admin login required.']); exit; }

function phaColumn(PDO $pdo,string $table,string $column):bool{
    if(!preg_match('/^[A-Za-z0-9_]+$/',$table)||!preg_match('/^[A-Za-z0-9_]+$/',$column))return false;
    try{$st=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?");$st->execute([$table,$column]);if((int)$st->fetchColumn()>0)return true;}catch(Throwable $e){}
    try{$pdo->query("SELECT `{$column}` FROM `{$table}` LIMIT 0");return true;}catch(Throwable $e){return false;}
}
function phaDestination(PDO $pdo,int $destinationId):array{
    try{$st=$pdo->prepare("SELECT id,name,country FROM destinations WHERE id=? LIMIT 1");$st->execute([$destinationId]);return $st->fetch(PDO::FETCH_ASSOC)?:[];}catch(Throwable $e){return [];}
}
function phaRelatedDestination(PDO $pdo,int $destinationId,string $alias='h'):array{
    $destination=phaDestination($pdo,$destinationId);
    $name=trim((string)($destination['name']??''));
    $parts=["{$alias}.destination_id=?"];$params=[$destinationId];
    if($name!==''){
        // Legacy Hotel Master rows may store the selected city only in `city`.
        $parts[]="LOWER(TRIM(COALESCE({$alias}.city,'')))=LOWER(TRIM(?))";$params[]=$name;
        // V18+ stores the smart Country -> State -> City path. This lets a state/tour-area
        // package (e.g. Meghalaya) see hotels saved under a city destination (e.g. Shillong),
        // and lets a city package see hotels that were saved under the parent state destination.
        if(phaColumn($pdo,'hotels','geo_city')){$parts[]="LOWER(TRIM(COALESCE({$alias}.geo_city,'')))=LOWER(TRIM(?))";$params[]=$name;}
        if(phaColumn($pdo,'hotels','geo_state')){$parts[]="LOWER(TRIM(COALESCE({$alias}.geo_state,'')))=LOWER(TRIM(?))";$params[]=$name;}
    }
    return ['sql'=>'('.implode(' OR ',$parts).')','params'=>$params,'destination'=>$destination];
}
function phaLocationName(PDO $pdo,int $locationId):string{
    if($locationId<=0)return '';
    try{$st=$pdo->prepare("SELECT location_name FROM destination_locations WHERE id=? LIMIT 1");$st->execute([$locationId]);return trim((string)($st->fetchColumn()?:''));}catch(Throwable $e){return '';}
}

$destinationId=max(0,(int)($_GET['destination_id']??0));
$locationId=max(0,(int)($_GET['location_id']??0));
$q=trim((string)($_GET['q']??''));
if($destinationId<=0){echo json_encode(['success'=>true,'locations'=>[],'hotels'=>['3'=>[],'4'=>[],'5'=>[]]]);exit;}
try{
    if(function_exists('tsLocationEnsureSchema'))tsLocationEnsureSchema($pdo);
    $related=phaRelatedDestination($pdo,$destinationId,'h');

    // Build one location list from both the selected destination and every related Hotel Master row.
    // The name-based filter below intentionally works even when two destination records have
    // separate location IDs for the same city.
    $locationMap=[];
    if(function_exists('tsLocationList')){
        foreach(tsLocationList($pdo,$destinationId) as $loc){
            $name=trim((string)$loc['location_name']);if($name==='')continue;
            $locationMap[strtolower($name)]=['id'=>(int)$loc['id'],'name'=>$name,'hotel_count'=>0];
        }
    }
    $locSql="SELECT h.location_id,COALESCE(NULLIF(TRIM(dl.location_name),''),NULLIF(TRIM(h.city),''),NULLIF(TRIM(".(phaColumn($pdo,'hotels','geo_city')?'h.geo_city':"''")."),'')) location_name,COUNT(*) hotel_count
             FROM hotels h LEFT JOIN destination_locations dl ON dl.id=h.location_id
             WHERE {$related['sql']} AND h.status='active'
             GROUP BY h.location_id,location_name ORDER BY location_name";
    $locStmt=$pdo->prepare($locSql);$locStmt->execute($related['params']);
    foreach($locStmt->fetchAll(PDO::FETCH_ASSOC)?:[] as $loc){
        $name=trim((string)($loc['location_name']??''));if($name==='')continue;
        $key=strtolower($name);$id=(int)($loc['location_id']??0);$count=(int)($loc['hotel_count']??0);
        if(!isset($locationMap[$key]))$locationMap[$key]=['id'=>$id,'name'=>$name,'hotel_count'=>$count];
        else{$locationMap[$key]['hotel_count']+=$count;if((int)$locationMap[$key]['id']<=0&&$id>0)$locationMap[$key]['id']=$id;}
    }
    /*
     * After tsLocationEnsureSchema() most Hotel Master cities have real child
     * location IDs. Keep only usable IDs for the selector; if a legacy text
     * city is found without an ID, repair it on the fly and reuse the new ID.
     */
    foreach($locationMap as $key=>&$locRow){
        if((int)$locRow['id']<=0 && function_exists('tsLocationUpsert')){
            try{
                $newId=tsLocationUpsert($pdo,$destinationId,(string)$locRow['name'],'package_hotel_repair',null);
                if($newId>0)$locRow['id']=$newId;
            }catch(Throwable $ignored){}
        }
    }
    unset($locRow);
    $locations=array_values(array_filter($locationMap,fn($x)=>(int)$x['id']>0));
    usort($locations,fn($a,$b)=>strcasecmp((string)$a['name'],(string)$b['name']));

    $imageExpr=phaColumn($pdo,'hotels','primary_image')?'h.primary_image':'NULL';
    $where=[$related['sql'],"h.status='active'"];$params=$related['params'];
    if($locationId>0){
        $locName=phaLocationName($pdo,$locationId);
        if($locName!==''){
            $locParts=['h.location_id=?','LOWER(TRIM(COALESCE(dl.location_name,\'\')))=LOWER(TRIM(?))','LOWER(TRIM(COALESCE(h.city,\'\')))=LOWER(TRIM(?))'];
            $locParams=[$locationId,$locName,$locName];
            if(phaColumn($pdo,'hotels','geo_city')){$locParts[]="LOWER(TRIM(COALESCE(h.geo_city,'')))=LOWER(TRIM(?))";$locParams[]=$locName;}
            $where[]='('.implode(' OR ',$locParts).')';array_push($params,...$locParams);
        }else{$where[]='h.location_id=?';$params[]=$locationId;}
    }
    if($q!==''){$where[]='(h.hotel_name LIKE ? OR h.city LIKE ?)';$like='%'.$q.'%';array_push($params,$like,$like);}
    $stmt=$pdo->prepare("SELECT h.id,h.destination_id,h.hotel_name,h.city,h.location_id,h.star_category,h.default_room_type,h.default_meal_plan,h.is_preferred,h.priority_order,h.preferred_supplier_id,{$imageExpr} primary_image,dl.location_name,s.company_name supplier_name,s.priority supplier_priority FROM hotels h LEFT JOIN destination_locations dl ON dl.id=h.location_id LEFT JOIN suppliers s ON s.id=h.preferred_supplier_id WHERE ".implode(' AND ',$where)." ORDER BY COALESCE(dl.location_name,h.city),h.star_category ASC,h.is_preferred DESC,h.priority_order ASC,h.hotel_name ASC");
    $stmt->execute($params);$out=['3'=>[],'4'=>[],'5'=>[]];
    foreach($stmt->fetchAll(PDO::FETCH_ASSOC)?:[] as $row){$star=(string)(int)$row['star_category'];if(!isset($out[$star]))continue;$out[$star][]=['id'=>(int)$row['id'],'destination_id'=>(int)($row['destination_id']??0),'name'=>(string)$row['hotel_name'],'star'=>(int)$row['star_category'],'location_id'=>(int)($row['location_id']??0),'location'=>(string)($row['location_name']?:($row['city']??'')),'city'=>(string)($row['city']??''),'room_type'=>(string)($row['default_room_type']??''),'meal_plan'=>(string)($row['default_meal_plan']??''),'preferred'=>(int)$row['is_preferred']===1,'image'=>(string)($row['primary_image']??''),'supplier_id'=>(int)($row['preferred_supplier_id']??0),'supplier'=>(string)($row['supplier_name']??''),'supplier_priority'=>(string)($row['supplier_priority']??'')];}
    echo json_encode(['success'=>true,'locations'=>$locations,'hotels'=>$out,'destination'=>(string)($related['destination']['name']??'')],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
}catch(Throwable $e){error_log('Package hotel API: '.$e->getMessage());http_response_code(500);echo json_encode(['success'=>false,'message'=>'Unable to load destination/location hotels.']);}
