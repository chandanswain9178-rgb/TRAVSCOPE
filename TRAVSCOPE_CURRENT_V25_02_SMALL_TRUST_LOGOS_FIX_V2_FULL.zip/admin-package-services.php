<?php
declare(strict_types=1);

/* TRAVSCOPE STEP 10 - PACKAGE SERVICES AUTOMATION */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/package-services-functions.php';

if (empty($_SESSION['admin_id'])) redirect(BASE_URL . 'admin-login.php');
$adminId=(int)$_SESSION['admin_id'];
$stmt=$pdo->prepare("SELECT id,name,email,role,status FROM admins WHERE id=? LIMIT 1");$stmt->execute([$adminId]);$admin=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$admin || strtolower((string)$admin['status'])!=='active'){unset($_SESSION['admin_id']);redirect(BASE_URL.'admin-login.php');}
if(empty($_SESSION['package_services_csrf'])) $_SESSION['package_services_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['package_services_csrf'];
$packageId=max(0,(int)($_GET['package_id']??$_POST['package_id']??0));
if($packageId<=0){http_response_code(400);exit('Package ID is required.');}

$stmt=$pdo->prepare("SELECT p.*,d.name destination_name,d.country destination_country FROM packages p LEFT JOIN destinations d ON d.id=p.destination_id WHERE p.id=? LIMIT 1");
$stmt->execute([$packageId]);$package=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$package){http_response_code(404);exit('Package not found.');}

$success='';$error='';
if(!tsPackageServicesTableExists($pdo,'package_services')) $error='Step 10 SQL is not installed. Import travscope-step-10-package-services-automation.sql first.';

if($_SERVER['REQUEST_METHOD']==='POST' && $error===''){
    try{
        $token=(string)($_POST['csrf_token']??'');
        if($token==='' || !hash_equals($csrf,$token)) throw new RuntimeException('Security verification failed. Refresh and try again.');
        $action=(string)($_POST['action']??'');

        if($action==='auto_build'){
            $r=tsPackageAutoBuildServices($pdo,$packageId,$adminId);
            $success=(int)$r['added'].' service(s) auto-built from Package Hotels and Inclusions. '.(int)$r['mapped'].' supplier mapping(s) applied.';
            if(!empty($r['warnings'])) $error=implode(' | ',$r['warnings']);
        } elseif($action==='auto_map'){
            $r=tsPackageAutoMapServiceSuppliers($pdo,$packageId,$adminId);
            $success=(int)$r['mapped'].' service(s) mapped to the best matching active supplier.';
            if((int)$r['unmapped']>0) $error=(int)$r['unmapped'].' service(s) still have no matching supplier. Add Supplier Service + Destination mapping in Supplier Master.';
        } elseif($action==='sync_existing_trips'){
            $q=$pdo->prepare("SELECT id FROM trips WHERE package_id=? ORDER BY id");$q->execute([$packageId]);
            $tripIds=array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN)?:[]);
            $created=0;$drafts=0;$warnings=[];
            foreach($tripIds as $tripId){
                $r=tsPackageSyncTripServicesFromPackage($pdo,$tripId,$adminId);
                $created+=(int)($r['created_requirements']??0);$drafts+=(int)($r['draft_supplier_requests']??0);
                foreach(($r['warnings']??[]) as $w)$warnings[]=$w;
            }
            $success=count($tripIds).' existing CRM trip(s) checked. '.$created.' new service requirement(s) and '.$drafts.' mapped supplier Draft request(s) prepared.';
            if($warnings)$error=implode(' | ',array_slice(array_unique($warnings),0,5));
        } elseif($action==='delete'){
            $id=max(0,(int)($_POST['service_id']??0));
            if($id>0){$d=$pdo->prepare("DELETE FROM package_services WHERE id=? AND package_id=?");$d->execute([$id,$packageId]);$success='Package service removed.';}
        } elseif($action==='toggle'){
            $id=max(0,(int)($_POST['service_id']??0));
            if($id>0){$u=$pdo->prepare("UPDATE package_services SET status=IF(status='active','inactive','active'),updated_by_admin_id=? WHERE id=? AND package_id=?");$u->execute([$adminId,$id,$packageId]);$success='Service status updated.';}
        } elseif($action==='save'){
            $id=max(0,(int)($_POST['service_id']??0));
            $types=tsPackageServiceTypes();$bases=tsPackageQuantityBases();
            $type=strtolower(trim((string)($_POST['service_type']??'')));
            $title=trim((string)($_POST['title']??''));
            if(!isset($types[$type])) throw new RuntimeException('Choose a valid service type.');
            if($title==='') $title=$types[$type];
            $dest=max(0,(int)($_POST['destination_id']??0));
            $supplier=max(0,(int)($_POST['preferred_supplier_id']??0));
            $star=max(0,(int)($_POST['hotel_star_category']??0));
            if(!in_array($star,[3,4,5],true)) $star=0;
            $dayFrom=max(0,(int)($_POST['service_day_from']??0));
            $dayTo=max(0,(int)($_POST['service_day_to']??0));
            if($dayFrom>0 && $dayTo>0 && $dayFrom>$dayTo) throw new RuntimeException('Service Day From cannot be after Day To.');
            $qty=max(0.01,(float)($_POST['quantity']??1));
            $basis=(string)($_POST['quantity_basis']??'fixed');if(!isset($bases[$basis]))$basis='fixed';
            $mode=(string)($_POST['service_mode']??'included');if(!in_array($mode,['included','optional','on_request'],true))$mode='included';
            $spec=trim((string)($_POST['specifications']??''));
            $autoCreate=!empty($_POST['auto_create_requirement'])?1:0;
            $autoRoute=!empty($_POST['auto_prepare_supplier_request'])?1:0;
            $sort=max(0,(int)($_POST['sort_order']??0));
            if($sort<=0){$q=$pdo->prepare("SELECT COALESCE(MAX(sort_order),0)+10 FROM package_services WHERE package_id=?");$q->execute([$packageId]);$sort=(int)$q->fetchColumn();}
            if($id>0){
                $u=$pdo->prepare("UPDATE package_services SET service_type=?,title=?,destination_id=?,hotel_star_category=?,preferred_supplier_id=?,service_day_from=?,service_day_to=?,quantity=?,quantity_basis=?,service_mode=?,specifications=?,auto_create_requirement=?,auto_prepare_supplier_request=?,sort_order=?,updated_by_admin_id=?,updated_at=NOW() WHERE id=? AND package_id=?");
                $u->execute([$type,$title,$dest>0?$dest:null,$star>0?$star:null,$supplier>0?$supplier:null,$dayFrom>0?$dayFrom:null,$dayTo>0?$dayTo:null,$qty,$basis,$mode,$spec!==''?$spec:null,$autoCreate,$autoRoute,$sort,$adminId,$id,$packageId]);
                $success='Package service updated.';
            }else{
                $i=$pdo->prepare("INSERT INTO package_services(package_id,service_type,title,destination_id,hotel_star_category,preferred_supplier_id,service_day_from,service_day_to,quantity,quantity_basis,service_mode,specifications,auto_create_requirement,auto_prepare_supplier_request,sort_order,status,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'active',?,?)");
                $i->execute([$packageId,$type,$title,$dest>0?$dest:null,$star>0?$star:null,$supplier>0?$supplier:null,$dayFrom>0?$dayFrom:null,$dayTo>0?$dayTo:null,$qty,$basis,$mode,$spec!==''?$spec:null,$autoCreate,$autoRoute,$sort,$adminId,$adminId]);
                $success='Package service added.';
            }
        }
    }catch(Throwable $e){$error=$e->getMessage();}
}

$services=[];$edit=null;
if($error==='' || tsPackageServicesTableExists($pdo,'package_services')){
    $q=$pdo->prepare("SELECT ps.*,d.name destination_name,s.company_name supplier_name FROM package_services ps LEFT JOIN destinations d ON d.id=ps.destination_id LEFT JOIN suppliers s ON s.id=ps.preferred_supplier_id WHERE ps.package_id=? ORDER BY ps.sort_order,ps.id");$q->execute([$packageId]);$services=$q->fetchAll(PDO::FETCH_ASSOC)?:[];
    $editId=max(0,(int)($_GET['edit_service']??0));if($editId){foreach($services as $row){if((int)$row['id']===$editId){$edit=$row;break;}}}
}
$destinations=$pdo->query("SELECT id,name,country FROM destinations WHERE status='active' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC)?:[];
$suppliers=$pdo->query("SELECT id,company_name,supplier_type,priority FROM suppliers WHERE status='active' ORDER BY CASE priority WHEN 'preferred' THEN 1 WHEN 'regular' THEN 2 ELSE 3 END,company_name")->fetchAll(PDO::FETCH_ASSOC)?:[];
$types=tsPackageServiceTypes();$bases=tsPackageQuantityBases();
$mapped=0;foreach($services as $s){if(!empty($s['preferred_supplier_id']))$mapped++;}
function psE($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Package Services | TRAVSCOPE Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,Arial,sans-serif;background:#f5f7fb;color:#152033}.top{height:70px;background:#fff;border-bottom:1px solid #e4e8f0;display:flex;align-items:center;justify-content:space-between;padding:0 28px;position:sticky;top:0;z-index:5}.brand{font-weight:800;font-size:20px}.brand span{color:#1473e6}.wrap{max-width:1420px;margin:28px auto;padding:0 20px}.head{display:flex;justify-content:space-between;gap:20px;align-items:flex-start;margin-bottom:22px}.head h1{margin:0 0 8px;font-size:28px}.muted{color:#728096;font-size:14px}.btn{border:0;border-radius:10px;padding:11px 15px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;gap:8px;align-items:center}.btn-primary{background:#1667d9;color:#fff}.btn-soft{background:#eaf2ff;color:#185db5}.btn-green{background:#e9fbf4;color:#097a56}.btn-danger{background:#fff0f0;color:#bd2c2c}.actions{display:flex;gap:8px;flex-wrap:wrap}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:20px}.stat{background:#fff;border:1px solid #e3e8f0;border-radius:14px;padding:18px}.stat strong{font-size:26px;display:block}.card{background:#fff;border:1px solid #e3e8f0;border-radius:15px;margin-bottom:20px;overflow:hidden}.card-head{padding:18px 20px;border-bottom:1px solid #e9edf3;display:flex;justify-content:space-between;align-items:center}.card-body{padding:20px}.alert{padding:13px 15px;border-radius:10px;margin-bottom:16px}.ok{background:#eaf9f1;color:#116b49}.err{background:#fff0f0;color:#a32424}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}.field label{display:block;font-size:12px;font-weight:800;color:#526077;margin-bottom:6px;text-transform:uppercase}.field input,.field select,.field textarea{width:100%;border:1px solid #dce2ea;border-radius:9px;padding:10px 11px;background:#fff}.field textarea{min-height:110px;resize:vertical}.span2{grid-column:span 2}.span4{grid-column:span 4}.checks{display:flex;gap:18px;flex-wrap:wrap}.check{display:flex;gap:7px;align-items:center;font-size:13px;font-weight:600}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;min-width:1050px}th,td{padding:13px 12px;border-bottom:1px solid #eef1f5;text-align:left;font-size:13px;vertical-align:top}th{background:#fafbfc;color:#5b677b;font-size:11px;text-transform:uppercase}.pill{display:inline-block;padding:5px 8px;border-radius:999px;background:#edf3ff;color:#315eaa;font-weight:700;font-size:11px}.pill.green{background:#eaf9f1;color:#14704e}.pill.gray{background:#f0f2f5;color:#667085}.small{font-size:12px;color:#718096;margin-top:5px}.icon{width:34px;height:34px;padding:0;justify-content:center}.empty{text-align:center;padding:38px;color:#7d8798}@media(max-width:900px){.grid{grid-template-columns:1fr 1fr}.span4{grid-column:span 2}.stats{grid-template-columns:1fr}.head{flex-direction:column}}@media(max-width:560px){.grid{grid-template-columns:1fr}.span2,.span4{grid-column:span 1}.top{padding:0 15px}}
</style>
<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head><body>
<header class="top"><div class="brand">TRAV<span>SCOPE</span> ADMIN</div><div><?=psE($admin['name'])?></div></header>
<main class="wrap">
<div class="head"><div><h1>Package Services Automation</h1><div class="muted"><strong><?=psE($package['title'])?></strong> · <?=psE($package['destination_name']??'')?> · <?= (int)$package['duration_days']?>D / <?= (int)$package['duration_nights']?>N</div></div><div class="actions"><a class="btn btn-soft" href="<?=psE(BASE_URL.'admin-packages.php?edit='.$packageId.'#package-form')?>"><i class="fa-solid fa-arrow-left"></i> Package Editor</a></div></div>
<?php if($success!==''):?><div class="alert ok"><?=psE($success)?></div><?php endif;?><?php if($error!==''):?><div class="alert err"><?=psE($error)?></div><?php endif;?>
<div class="stats"><div class="stat"><span class="muted">Service Templates</span><strong><?=count($services)?></strong></div><div class="stat"><span class="muted">Supplier Mapped</span><strong><?=$mapped?></strong></div><div class="stat"><span class="muted">Auto Route Coverage</span><strong><?=count($services)?(int)round($mapped/count($services)*100):0?>%</strong></div></div>
<div class="card"><div class="card-head"><div><strong>Automatic Builder</strong><div class="small">Build Hotel + included transport/transfers/sightseeing/activities/meals and other services from this package. It never sends a supplier request automatically.</div></div><div class="actions"><form method="post"><input type="hidden" name="csrf_token" value="<?=psE($csrf)?>"><input type="hidden" name="package_id" value="<?=$packageId?>"><input type="hidden" name="action" value="auto_build"><button class="btn btn-primary"><i class="fa-solid fa-wand-magic-sparkles"></i> Auto Build From Package</button></form><form method="post"><input type="hidden" name="csrf_token" value="<?=psE($csrf)?>"><input type="hidden" name="package_id" value="<?=$packageId?>"><input type="hidden" name="action" value="auto_map"><button class="btn btn-green"><i class="fa-solid fa-route"></i> Auto Map Suppliers</button></form><form method="post"><input type="hidden" name="csrf_token" value="<?=psE($csrf)?>"><input type="hidden" name="package_id" value="<?=$packageId?>"><input type="hidden" name="action" value="sync_existing_trips"><button class="btn btn-soft"><i class="fa-solid fa-arrows-rotate"></i> Sync Existing CRM Trips</button></form></div></div></div>
<div class="card"><div class="card-head"><strong><?= $edit?'Edit Service Template':'Add Service Template' ?></strong><?php if($edit):?><a class="btn btn-soft" href="<?=psE(BASE_URL.'admin-package-services.php?package_id='.$packageId)?>">New Service</a><?php endif;?></div><div class="card-body"><form method="post"><input type="hidden" name="csrf_token" value="<?=psE($csrf)?>"><input type="hidden" name="package_id" value="<?=$packageId?>"><input type="hidden" name="action" value="save"><input type="hidden" name="service_id" value="<?= (int)($edit['id']??0)?>"><div class="grid">
<div class="field"><label>Service Type</label><select name="service_type" required><?php foreach($types as $k=>$v):?><option value="<?=psE($k)?>" <?= (($edit['service_type']??'')===$k?'selected':'')?>><?=psE($v)?></option><?php endforeach;?></select></div>
<div class="field span2"><label>Service Title</label><input name="title" value="<?=psE($edit['title']??'')?>" placeholder="Example: Private Innova for complete tour"></div>
<div class="field"><label>Hotel Category Scope</label><select name="hotel_star_category"><option value="">Any / Not Hotel</option><?php foreach([3,4,5] as $x):?><option value="<?=$x?>" <?= ((int)($edit['hotel_star_category']??0)===$x?'selected':'')?>><?=$x?> Star</option><?php endforeach;?></select></div>
<div class="field"><label>Destination</label><select name="destination_id"><option value="">Package / Trip Destination</option><?php foreach($destinations as $d):?><option value="<?=(int)$d['id']?>" <?= ((int)($edit['destination_id']??0)===(int)$d['id']?'selected':'')?>><?=psE($d['name'].(!empty($d['country'])?' · '.$d['country']:''))?></option><?php endforeach;?></select></div>
<div class="field span2"><label>Preferred Supplier</label><select name="preferred_supplier_id"><option value="">Auto / Not Mapped</option><?php foreach($suppliers as $s):?><option value="<?=(int)$s['id']?>" <?= ((int)($edit['preferred_supplier_id']??0)===(int)$s['id']?'selected':'')?>><?=psE($s['company_name'].' · '.($s['supplier_type']??'').' · '.ucfirst((string)$s['priority']))?></option><?php endforeach;?></select></div>
<div class="field"><label>Service Mode</label><select name="service_mode"><?php foreach(['included'=>'Included','optional'=>'Optional','on_request'=>'On Request'] as $k=>$v):?><option value="<?=$k?>" <?= (($edit['service_mode']??'included')===$k?'selected':'')?>><?=$v?></option><?php endforeach;?></select></div>
<div class="field"><label>Day From</label><input type="number" min="1" max="99" name="service_day_from" value="<?=psE($edit['service_day_from']??1)?>"></div><div class="field"><label>Day To</label><input type="number" min="1" max="99" name="service_day_to" value="<?=psE($edit['service_day_to']??$package['duration_days'])?>"></div>
<div class="field"><label>Quantity</label><input type="number" min="0.01" step="0.01" name="quantity" value="<?=psE($edit['quantity']??1)?>"></div><div class="field"><label>Quantity Basis</label><select name="quantity_basis"><?php foreach($bases as $k=>$v):?><option value="<?=$k?>" <?= (($edit['quantity_basis']??'fixed')===$k?'selected':'')?>><?=psE($v)?></option><?php endforeach;?></select></div>
<div class="field span4"><label>Specifications / Supplier Requirement</label><textarea name="specifications" placeholder="Vehicle, room type, meal plan, sightseeing scope, ticket details, etc."><?=psE($edit['specifications']??'')?></textarea></div>
<div class="field"><label>Sort Order</label><input type="number" min="0" name="sort_order" value="<?=psE($edit['sort_order']??'')?>"></div><div class="field span2"><label>Automation</label><div class="checks"><label class="check"><input type="checkbox" name="auto_create_requirement" value="1" <?= !isset($edit['auto_create_requirement']) || !empty($edit['auto_create_requirement'])?'checked':''?>> Create CRM service automatically</label><label class="check"><input type="checkbox" name="auto_prepare_supplier_request" value="1" <?= !empty($edit['auto_prepare_supplier_request'])?'checked':''?>> Prepare mapped supplier Draft request</label></div></div>
<div class="field"><label>&nbsp;</label><button class="btn btn-primary" style="width:100%;justify-content:center"><i class="fa-solid fa-floppy-disk"></i> Save Service</button></div>
</div></form></div></div>
<div class="card"><div class="card-head"><div><strong>Package Service Templates</strong><div class="small">When this package becomes a CRM Trip, active auto-create rows are copied into Trip Service Requirements. Mapped suppliers get Draft sourcing requests only—nothing is emailed automatically.</div></div></div><div class="table-wrap"><table><thead><tr><th>#</th><th>Service</th><th>Days / Qty</th><th>Destination</th><th>Supplier Route</th><th>Automation</th><th>Status</th><th>Actions</th></tr></thead><tbody>
<?php if(!$services):?><tr><td colspan="8" class="empty">No service templates yet. Click <strong>Auto Build From Package</strong>.</td></tr><?php endif;?>
<?php foreach($services as $row):?><tr><td><?=(int)$row['sort_order']?></td><td><strong><?=psE($row['title'])?></strong><div class="small"><span class="pill"><?=psE(tsPackageServiceLabel((string)$row['service_type']))?></span><?php if(!empty($row['hotel_star_category'])):?> <span class="pill gray"><?=(int)$row['hotel_star_category']?>★</span><?php endif;?> · <?=psE(ucwords(str_replace('_',' ',(string)$row['service_mode'])))?></div><?php if(!empty($row['specifications'])):?><div class="small"><?=psE(mb_substr((string)$row['specifications'],0,140))?><?=mb_strlen((string)$row['specifications'])>140?'…':''?></div><?php endif;?></td><td>Day <?=psE($row['service_day_from']??'—')?> → <?=psE($row['service_day_to']??'—')?><div class="small"><?=number_format((float)$row['quantity'],2)?> × <?=psE($bases[$row['quantity_basis']]??$row['quantity_basis'])?></div></td><td><?=psE($row['destination_name']??($package['destination_name']??'Package destination'))?></td><td><?php if(!empty($row['supplier_name'])):?><span class="pill green"><i class="fa-solid fa-link"></i> <?=psE($row['supplier_name'])?></span><?php else:?><span class="pill gray">Not mapped</span><?php endif;?></td><td><?=!empty($row['auto_create_requirement'])?'CRM ✓':'CRM —'?><br><?=!empty($row['auto_prepare_supplier_request'])?'Supplier Draft ✓':'Supplier Draft —'?></td><td><span class="pill <?=($row['status']==='active'?'green':'gray')?>"><?=psE(strtoupper((string)$row['status']))?></span></td><td><div class="actions"><a class="btn btn-soft icon" title="Edit" href="<?=psE(BASE_URL.'admin-package-services.php?package_id='.$packageId.'&edit_service='.(int)$row['id'])?>"><i class="fa-solid fa-pen"></i></a><form method="post"><input type="hidden" name="csrf_token" value="<?=psE($csrf)?>"><input type="hidden" name="package_id" value="<?=$packageId?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="service_id" value="<?=(int)$row['id']?>"><button class="btn btn-soft icon" title="Toggle"><i class="fa-solid fa-power-off"></i></button></form><form method="post"><input type="hidden" name="csrf_token" value="<?=psE($csrf)?>"><input type="hidden" name="package_id" value="<?=$packageId?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="service_id" value="<?=(int)$row['id']?>"><button class="btn btn-danger icon" title="Delete"><i class="fa-solid fa-trash"></i></button></form></div></td></tr><?php endforeach;?>
</tbody></table></div></div>
</main>
<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
