TRAVSCOPE V24.95 — PREMIUM CONTENT PRESENTATION
Built from V24.94

PUBLIC PACKAGE PAGE
- About this journey redesigned as a premium Trip Overview section.
- Adds compact Duration / Destination / Travel Style facts without changing stored data.
- Main overview narrative is presented in a clean editorial panel with justified desktop text.
- Tour Highlights redesigned into numbered signature-experience cards with clearer hierarchy and tighter spacing.
- Inclusions and Exclusions redesigned into two professional coverage panels with counts, compact list rows and clear included/payable-separately distinction.
- Responsive mobile presentation stacks all premium sections cleanly without horizontal overflow.
- Existing itinerary layout, 90–100 word short-description standard, 190–200 word full-description standard and 190–200 word day-wise narrative standard remain unchanged.

QUOTATION PREVIEW / PDF
- Highlights, Inclusions and Exclusions now render as structured professional list cards instead of a plain prose block.
- Adds concise section-intro copy and clearer visual distinction for included and excluded services.
- Print/A4 rules compact the cards for cleaner page usage and avoid awkward item splitting where possible.
- Existing V24.94 editorial day-wise itinerary and A4 PDF improvements remain active.

CHANGED FILES
1. package-details.php
2. admin-crm.php

DATABASE
No SQL required.
