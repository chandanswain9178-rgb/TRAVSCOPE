<?php
/*
|--------------------------------------------------------------------------
| TRAVSCOPE V24.12 - GLOBAL ADMIN DELETE OTP GATE
|--------------------------------------------------------------------------
| Intercepts destructive Admin POST actions before page-specific delete code
| runs. The original POST request is kept in the session and is replayed only
| after the logged-in Admin verifies a one-time email OTP.
|--------------------------------------------------------------------------
*/

declare(strict_types=1);

if (!function_exists('tsAdminDeleteOtpIsAdminScript')) {
    function tsAdminDeleteOtpIsAdminScript(string $script): bool
    {
        $base = basename($script);
        return str_starts_with($base, 'admin-') && $base !== 'admin-delete-otp.php';
    }
}

if (!function_exists('tsAdminDeleteOtpLooksDestructive')) {
    function tsAdminDeleteOtpLooksDestructive(array $post): bool
    {
        foreach ($post as $key => $value) {
            $k = strtolower((string)$key);

            if (preg_match('/(^|_)(delete|remove|purge|destroy)(_|$)/', $k)) {
                return true;
            }

            if (in_array($k, ['action','bulk_action','operation','task','mode','submit_action'], true)) {
                $vals = is_array($value) ? $value : [$value];
                foreach ($vals as $v) {
                    $s = strtolower(trim((string)$v));
                    if ($s !== '' && preg_match('/(^|[_-])(delete|remove|purge|destroy)([_-]|$)/', $s)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}

if (!function_exists('tsAdminDeleteOtpPostHash')) {
    function tsAdminDeleteOtpPostHash(array $post): string
    {
        unset($post['__ts_delete_otp_token']);
        ksort($post);
        return hash('sha256', serialize($post));
    }
}

if (!function_exists('tsAdminDeleteOtpAdmin')) {
    function tsAdminDeleteOtpAdmin(PDO $pdo, int $adminId): ?array
    {
        if ($adminId <= 0) return null;
        try {
            $stmt = $pdo->prepare('SELECT id,name,email,status FROM admins WHERE id=? LIMIT 1');
            $stmt->execute([$adminId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row || strtolower((string)($row['status'] ?? '')) !== 'active') return null;
            return $row;
        } catch (Throwable $e) {
            error_log('Admin delete OTP admin lookup: '.$e->getMessage());
            return null;
        }
    }
}

if (!function_exists('tsAdminDeleteOtpTargetUri')) {
    function tsAdminDeleteOtpTargetUri(): string
    {
        $uri = (string)($_SERVER['REQUEST_URI'] ?? '');
        if ($uri === '' || !str_starts_with($uri, '/') || str_starts_with($uri, '//')) {
            $uri = '/' . ltrim((string)($_SERVER['SCRIPT_NAME'] ?? ''), '/');
        }
        return $uri;
    }
}

if (!function_exists('tsAdminDeleteOtpCleanupSession')) {
    function tsAdminDeleteOtpCleanupSession(): void
    {
        $now = time();
        foreach (['ts_admin_delete_pending','ts_admin_delete_approved'] as $bucket) {
            if (empty($_SESSION[$bucket]) || !is_array($_SESSION[$bucket])) continue;
            foreach ($_SESSION[$bucket] as $token => $row) {
                $created = (int)($row['created_at'] ?? 0);
                if ($created <= 0 || $created < ($now - 1800)) {
                    unset($_SESSION[$bucket][$token]);
                }
            }
        }
    }
}

if (!function_exists('tsAdminDeleteOtpBoot')) {
    function tsAdminDeleteOtpBoot(PDO $pdo): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) return;
        tsAdminDeleteOtpCleanupSession();

        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') return;
        if (!tsAdminDeleteOtpIsAdminScript((string)($_SERVER['SCRIPT_NAME'] ?? ''))) return;

        $adminId = (int)($_SESSION['admin_id'] ?? ($_SESSION[defined('ADMIN_SESSION_KEY') ? ADMIN_SESSION_KEY : 'admin_id'] ?? 0));
        if ($adminId <= 0) return;
        if (!tsAdminDeleteOtpLooksDestructive($_POST)) return;

        /*
        |------------------------------------------------------------------
        | V24.12 ADMIN SETTING: DELETE OTP ON / OFF
        |------------------------------------------------------------------
        | Default is ON. If the setting is explicitly turned OFF from
        | Admin > General Settings > Website Controls, destructive actions
        | continue directly to the page's existing delete handler.
        */
        try {
            $deleteOtpEnabled = function_exists('getSetting')
                ? (string)getSetting($pdo, 'admin_delete_otp_enabled', '1')
                : '1';
        } catch (Throwable $e) {
            error_log('Admin delete OTP setting lookup: '.$e->getMessage());
            $deleteOtpEnabled = '1';
        }

        if ($deleteOtpEnabled !== '1') {
            return;
        }

        $token = trim((string)($_POST['__ts_delete_otp_token'] ?? ''));
        if ($token !== '') {
            $approved = $_SESSION['ts_admin_delete_approved'][$token] ?? null;
            if (is_array($approved)
                && (int)($approved['admin_id'] ?? 0) === $adminId
                && hash_equals((string)($approved['post_hash'] ?? ''), tsAdminDeleteOtpPostHash($_POST))
                && (int)($approved['created_at'] ?? 0) >= time() - 600
            ) {
                unset($_SESSION['ts_admin_delete_approved'][$token]);
                unset($_POST['__ts_delete_otp_token']);
                return;
            }

            http_response_code(403);
            exit('Delete verification expired or invalid. Please return to the Admin Panel and try again.');
        }

        $admin = tsAdminDeleteOtpAdmin($pdo, $adminId);
        if (!$admin || !function_exists('validEmail') || !validEmail((string)$admin['email'])) {
            http_response_code(403);
            exit('Your Admin account does not have a valid active email address for delete verification.');
        }

        $token = bin2hex(random_bytes(24));
        $pending = [
            'admin_id' => $adminId,
            'admin_name' => (string)($admin['name'] ?? 'Administrator'),
            'admin_email' => (string)$admin['email'],
            'target_uri' => tsAdminDeleteOtpTargetUri(),
            'target_script' => basename((string)($_SERVER['SCRIPT_NAME'] ?? '')),
            'post' => $_POST,
            'post_hash' => tsAdminDeleteOtpPostHash($_POST),
            'created_at' => time(),
            'otp_message' => '',
        ];

        $_SESSION['ts_admin_delete_pending'][$token] = $pending;

        if (function_exists('createEmailOtp')) {
            $sent = createEmailOtp(
                $pdo,
                (string)$admin['email'],
                (string)($admin['name'] ?? 'Administrator'),
                'admin_delete'
            );
            $_SESSION['ts_admin_delete_pending'][$token]['otp_message'] = (string)($sent['message'] ?? '');
            $_SESSION['ts_admin_delete_pending'][$token]['otp_sent'] = !empty($sent['success']);
        }

        $base = defined('BASE_URL') ? (string)BASE_URL : '/';
        header('Location: '.$base.'admin-delete-otp.php?token='.rawurlencode($token));
        exit;
    }
}
