<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/import-functions.php';

requireAdmin();

$admin = currentAdmin($pdo);

if (
    !$admin
    || strtolower((string)($admin['status'] ?? '')) !== 'active'
) {
    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_role']
    );

    redirect(BASE_URL . 'login.php');
}

$adminId = (int)$admin['id'];

$canManage =
    function_exists('tsAclCan')
        ? tsAclCan($pdo, $adminId, 'manage_access')
        : true;

if (!$canManage) {
    http_response_code(403);
    exit(
        'Controlled Data Import requires Manage Permissions authority.'
    );
}

$type =
    strtolower(
        trim(
            (string)(
                $_GET['type']
                ?? $_POST['import_type']
                ?? 'customer'
            )
        )
    );

if (!in_array($type, ['customer','supplier','enquiry'], true)) {
    $type = 'customer';
}

$schema = tsImportSchema($type);

$batchId =
    max(
        0,
        (int)(
            $_GET['batch_id']
            ?? $_POST['batch_id']
            ?? 0
        )
    );

$rowStatus =
    strtolower(
        trim(
            (string)(
                $_GET['row_status']
                ?? ''
            )
        )
    );

if (
    !in_array(
        $rowStatus,
        [
            '',
            'valid',
            'warning',
            'duplicate',
            'error',
            'imported',
            'skipped',
        ],
        true
    )
) {
    $rowStatus = '';
}

if (empty($_SESSION['admin_data_import_csrf'])) {
    $_SESSION['admin_data_import_csrf'] =
        bin2hex(random_bytes(32));
}

$csrf =
    (string)$_SESSION['admin_data_import_csrf'];

$error = '';
$success = '';

if (!empty($_SESSION['admin_data_import_success'])) {
    $success =
        (string)$_SESSION['admin_data_import_success'];

    unset($_SESSION['admin_data_import_success']);
}


/*
|--------------------------------------------------------------------------
| ROW REPORT CSV
|--------------------------------------------------------------------------
*/

if (
    isset($_GET['download'])
    && $_GET['download'] === 'row_report'
    && $batchId > 0
) {
    if (!tsImportReady($pdo)) {
        http_response_code(503);
        exit('Import SQL is not installed.');
    }

    tsImportErrorCsv($pdo, $batchId);
}


/*
|--------------------------------------------------------------------------
| ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedToken =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    if (
        $postedToken === ''
        || !hash_equals($csrf, $postedToken)
    ) {
        $error =
            'Security verification failed. Refresh and try again.';

    } else {
        try {
            $action =
                (string)(
                    $_POST['action']
                    ?? ''
                );

            if ($action === 'preview') {
                if (!tsImportReady($pdo)) {
                    throw new RuntimeException(
                        'Import TRAVSCOPE_Admin_Data_Import_Controlled_Migration.sql first.'
                    );
                }

                $batchId =
                    tsImportCreateBatch(
                        $pdo,
                        $type,
                        $_FILES['csv_file']
                            ?? [],
                        $adminId
                    );

                $_SESSION['admin_data_import_success'] =
                    'CSV validated. Review every Warning / Duplicate / Error before importing.';

                redirect(
                    BASE_URL
                    . 'admin-data-import.php?type='
                    . urlencode($type)
                    . '&batch_id='
                    . $batchId
                );

            } elseif ($action === 'execute') {
                $batchId =
                    max(
                        0,
                        (int)(
                            $_POST['batch_id']
                            ?? 0
                        )
                    );

                $includeWarnings =
                    !empty(
                        $_POST['include_warnings']
                    );

                $createTrips =
                    $type === 'enquiry'
                    && !empty(
                        $_POST['create_trips']
                    );

                $result =
                    tsImportExecuteBatch(
                        $pdo,
                        $batchId,
                        $adminId,
                        $includeWarnings,
                        $createTrips
                    );

                $_SESSION['admin_data_import_success'] =
                    'Import completed: '
                    . (int)$result['imported_rows']
                    . ' imported, '
                    . (int)$result['skipped_rows']
                    . ' skipped.'
                    . (
                        $type === 'enquiry'
                            ? (
                                ' Trips created: '
                                . (int)$result['trips_created']
                                . '.'
                            )
                            : ''
                    );

                redirect(
                    BASE_URL
                    . 'admin-data-import.php?type='
                    . urlencode($type)
                    . '&batch_id='
                    . $batchId
                );

            } elseif ($action === 'cancel') {
                $batchId =
                    max(
                        0,
                        (int)(
                            $_POST['batch_id']
                            ?? 0
                        )
                    );

                tsImportCancelBatch(
                    $pdo,
                    $batchId,
                    $adminId
                );

                $_SESSION['admin_data_import_success'] =
                    'Preview batch cancelled. No business records were imported.';

                redirect(
                    BASE_URL
                    . 'admin-data-import.php?type='
                    . urlencode($type)
                    . '&batch_id='
                    . $batchId
                );

            } else {
                throw new RuntimeException(
                    'Invalid import action.'
                );
            }

        } catch (RuntimeException $e) {
            $error = $e->getMessage();

        } catch (Throwable $e) {
            error_log(
                'Controlled Data Import: '
                . $e->getMessage()
            );

            $error =
                'Unable to complete import action: '
                . $e->getMessage();
        }
    }
}


$batch =
    $batchId > 0
        ? tsImportBatch($pdo, $batchId)
        : null;

if ($batch) {
    $type =
        (string)$batch['import_type'];

    $schema =
        tsImportSchema($type);
}

$rows =
    $batch
        ? tsImportBatchRows(
            $pdo,
            (int)$batch['id'],
            $rowStatus
        )
        : [];

$recent =
    tsImportRecentBatches(
        $pdo,
        40
    );

function diEsc(?string $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function diDate(?string $value): string
{
    if (!$value) {
        return '-';
    }

    $ts = strtotime($value);

    return
        $ts
            ? date('d M Y · h:i A', $ts)
            : (string)$value;
}

function diStatusClass(string $status): string
{
    return
        match ($status) {
            'valid','imported','completed' => 'good',
            'warning','previewed','importing' => 'warn',
            'duplicate','skipped','cancelled' => 'neutral',
            'error','failed' => 'bad',
            default => 'neutral',
        };
}

function diRawSummary(array $raw, string $type): string
{
    if ($type === 'customer') {
        return
            (string)($raw['full_name'] ?? '')
            . ' · '
            . (string)($raw['email'] ?? '')
            . ' · '
            . (string)($raw['mobile'] ?? '');
    }

    if ($type === 'supplier') {
        return
            (string)($raw['company_name'] ?? '')
            . ' · '
            . (string)($raw['gstin'] ?? '')
            . ' · '
            . (string)($raw['primary_contact_email'] ?? '');
    }

    return
        (string)($raw['name'] ?? '')
        . ' · '
        . (string)($raw['destination'] ?? '')
        . ' · '
        . (string)($raw['travel_date'] ?? '');
}

$options =
    $batch
        ? tsImportDecode(
            (string)($batch['options_json'] ?? '')
        )
        : [];

$previousCompleted =
    (int)(
        $options['previous_completed_batch_id']
        ?? 0
    );

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Controlled Data Import | TRAVSCOPE Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:68px;padding:10px 4%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;border-bottom:1px solid #dfe7f0;position:sticky;top:0;z-index:20}.brand{font-weight:900}.brand span{color:#2563eb}.actions{display:flex;gap:7px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 10px;border:1px solid #cbd5e1;border-radius:9px;background:#fff;color:#334155;text-decoration:none;font-size:9px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.btn.good{background:#059669;border-color:#059669;color:#fff}.btn.warn{background:#fff7ed;border-color:#fed7aa;color:#c2410c}.btn.bad{background:#fff1f2;border-color:#fecdd3;color:#be123c}.btn:disabled{opacity:.5;cursor:not-allowed}.wrap{max-width:1450px;margin:20px auto;padding:0 13px}.hero{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;padding:17px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:20px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px;line-height:1.55}.tabs{display:flex;gap:6px;flex-wrap:wrap}.tabs a{padding:7px 10px;border:1px solid #cbd5e1;border-radius:999px;background:#fff;color:#475569;text-decoration:none;font-size:8px;font-weight:900}.tabs a.active{background:#0f172a;border-color:#0f172a;color:#fff}.notice{margin-top:10px;padding:10px 12px;border-radius:10px;font-size:10px;line-height:1.5}.notice.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#047857}.notice.err{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c}.notice.warn{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412}.grid{display:grid;grid-template-columns:1fr .38fr;gap:11px;margin-top:11px}.card{background:#fff;border:1px solid #dfe7f0;border-radius:13px;overflow:hidden}.head{padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff;display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.head h2{margin:0;font-size:12px}.head p{margin:4px 0 0;color:#64748b;font-size:8.5px;line-height:1.45}.body{padding:11px}.upload{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:end}.field label{display:block;margin-bottom:4px;font-size:8px;font-weight:900}.field input[type=file]{width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;font-size:8.5px}.templates{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.stats{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:7px;margin-top:10px}.stat{padding:9px;border:1px solid #e2e8f0;border-radius:10px;background:#fff}.stat span{display:block;font-size:7px;font-weight:900;color:#64748b;text-transform:uppercase}.stat strong{display:block;margin-top:3px;font-size:12px}.pill{display:inline-flex;align-items:center;gap:4px;padding:4px 7px;border-radius:999px;font-size:7.5px;font-weight:900;background:#f1f5f9;color:#64748b}.pill.good{background:#dcfce7;color:#166534}.pill.warn{background:#fef3c7;color:#92400e}.pill.bad{background:#fee2e2;color:#b91c1c}.pill.neutral{background:#e2e8f0;color:#475569}.filters{display:flex;gap:5px;flex-wrap:wrap;margin:10px 0}.filters a{padding:5px 8px;border:1px solid #cbd5e1;border-radius:999px;text-decoration:none;color:#475569;font-size:7.5px;font-weight:900}.filters a.active{background:#0f172a;color:#fff;border-color:#0f172a}.table-wrap{overflow:auto;border:1px solid #e2e8f0;border-radius:10px}.table{width:100%;border-collapse:collapse;min-width:960px}.table th,.table td{padding:7px 8px;border-bottom:1px solid #eef2f7;text-align:left;font-size:8px;vertical-align:top}.table th{background:#f8fafc;color:#64748b;text-transform:uppercase;font-size:7px;position:sticky;top:0}.messages{max-width:390px;line-height:1.45}.messages .e{color:#b91c1c}.messages .w{color:#92400e}.confirm{margin-top:10px;padding:10px;border:1px solid #bfdbfe;border-radius:10px;background:#eff6ff}.confirm label{font-size:8.5px;line-height:1.5}.history{padding:8px;border:1px solid #e2e8f0;border-radius:9px;margin-bottom:7px}.history a{text-decoration:none;color:#1d4ed8;font-weight:900;font-size:9px}.history small{display:block;margin-top:4px;color:#64748b;font-size:7.5px;line-height:1.45}.empty{padding:24px;text-align:center;color:#94a3b8;border:1px dashed #cbd5e1;border-radius:10px;font-size:9px}
@media(max-width:1050px){.grid{grid-template-columns:1fr}.stats{grid-template-columns:repeat(3,1fr)}}
@media(max-width:650px){.top,.hero{flex-direction:column;align-items:flex-start}.upload,.stats{grid-template-columns:1fr}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>
<body>

<header class="top">
    <div class="brand">
        TRAV<span>SCOPE</span> · CONTROLLED DATA IMPORT
    </div>

    <div class="actions">
        <a class="btn" href="<?= diEsc(BASE_URL . 'admin-dashboard.php'); ?>">
            <i class="fa-solid fa-gauge-high"></i>
            Dashboard
        </a>

        <a class="btn" href="<?= diEsc(BASE_URL . 'admin-master-data.php'); ?>">
            <i class="fa-solid fa-object-group"></i>
            Master Data
        </a>

        <a class="btn" href="<?= diEsc(BASE_URL . 'admin-system-health.php'); ?>">
            <i class="fa-solid fa-heart-pulse"></i>
            Health
        </a>
    </div>
</header>

<main class="wrap">

<section class="hero">
    <div>
        <h1>Admin Data Import + Controlled Migration Center</h1>
        <p>
            CSV upload is always previewed first. Existing Customer and Supplier masters are never
            overwritten. Strong duplicate matches are blocked. Warning rows require explicit review.
            Every row keeps its original data, normalized data, validation messages and final target ID.
        </p>
    </div>

    <div class="tabs">
        <?php foreach ([
            'customer' => 'Customers',
            'supplier' => 'Suppliers',
            'enquiry' => 'Enquiries / Leads'
        ] as $key => $label): ?>
            <a
                class="<?= $type === $key ? 'active' : ''; ?>"
                href="<?= diEsc(BASE_URL . 'admin-data-import.php?type=' . urlencode($key)); ?>"
            >
                <?= diEsc($label); ?>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<?php if ($success): ?>
    <div class="notice ok"><?= diEsc($success); ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="notice err"><?= diEsc($error); ?></div>
<?php endif; ?>

<?php if (!tsImportReady($pdo)): ?>
    <div class="notice warn">
        Import the supplied <strong>TRAVSCOPE_Admin_Data_Import_Controlled_Migration.sql</strong>
        before previewing or importing CSV files.
    </div>
<?php endif; ?>

<div class="grid">

<section>
<div class="card">
    <div class="head">
        <div>
            <h2>1. Upload + Validation Preview · <?= diEsc((string)$schema['label']); ?></h2>
            <p>
                Maximum 5 MB / 2,500 rows. Column names must match the supplied template.
                Preview creates only import-audit rows — no Customer, Supplier or Enquiry is created yet.
            </p>
        </div>
    </div>

    <div class="body">
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= diEsc($csrf); ?>">
            <input type="hidden" name="action" value="preview">
            <input type="hidden" name="import_type" value="<?= diEsc($type); ?>">

            <div class="upload">
                <div class="field">
                    <label>CSV File *</label>
                    <input
                        type="file"
                        name="csv_file"
                        accept=".csv,text/csv"
                        required
                    >
                </div>

                <button
                    class="btn primary"
                    type="submit"
                    <?= !tsImportReady($pdo) ? 'disabled' : ''; ?>
                >
                    <i class="fa-solid fa-magnifying-glass"></i>
                    Preview & Validate
                </button>
            </div>
        </form>

        <div class="templates">
            <a
                class="btn"
                href="<?= diEsc(BASE_URL . (string)$schema['template']); ?>"
                download
            >
                <i class="fa-solid fa-file-csv"></i>
                Download <?= diEsc((string)$schema['label']); ?> Template
            </a>

            <span class="pill neutral">
                Required: <?= diEsc(implode(', ', (array)$schema['required'])); ?>
            </span>
        </div>
    </div>
</div>


<?php if ($batch): ?>
<div class="card" style="margin-top:11px;">
    <div class="head">
        <div>
            <h2>
                2. Batch #<?= (int)$batch['id']; ?>
                · <?= diEsc((string)tsImportSchema((string)$batch['import_type'])['label']); ?>
            </h2>
            <p>
                <?= diEsc((string)$batch['original_filename']); ?>
                · SHA-256 <?= diEsc(substr((string)$batch['file_sha256'], 0, 16)); ?>…
                · Uploaded by <?= diEsc((string)($batch['admin_name'] ?? 'Admin')); ?>
                · <?= diEsc(diDate((string)$batch['created_at'])); ?>
            </p>
        </div>

        <span class="pill <?= diEsc(diStatusClass((string)$batch['status'])); ?>">
            <?= diEsc(strtoupper((string)$batch['status'])); ?>
        </span>
    </div>

    <div class="body">

        <?php if ($previousCompleted > 0): ?>
            <div class="notice warn" style="margin-top:0;">
                This exact file hash was already completed as Batch #<?= $previousCompleted; ?>.
                Preview is allowed for audit, but existing-master/lead duplicate checks should block repeated inserts.
            </div>
        <?php endif; ?>

        <div class="stats">
            <div class="stat">
                <span>Total Rows</span>
                <strong><?= (int)$batch['total_rows']; ?></strong>
            </div>
            <div class="stat">
                <span>Valid</span>
                <strong><?= (int)$batch['valid_rows']; ?></strong>
            </div>
            <div class="stat">
                <span>Warning</span>
                <strong><?= (int)$batch['warning_rows']; ?></strong>
            </div>
            <div class="stat">
                <span>Duplicate</span>
                <strong><?= (int)$batch['duplicate_rows']; ?></strong>
            </div>
            <div class="stat">
                <span>Error</span>
                <strong><?= (int)$batch['error_rows']; ?></strong>
            </div>
            <div class="stat">
                <span>Imported</span>
                <strong><?= (int)$batch['imported_rows']; ?></strong>
            </div>
        </div>

        <div class="filters">
            <?php foreach ([
                '' => 'All Rows',
                'valid' => 'Valid',
                'warning' => 'Warning',
                'duplicate' => 'Duplicate',
                'error' => 'Error',
                'imported' => 'Imported',
                'skipped' => 'Skipped',
            ] as $key => $label): ?>
                <a
                    class="<?= $rowStatus === $key ? 'active' : ''; ?>"
                    href="<?= diEsc(
                        BASE_URL
                        . 'admin-data-import.php?'
                        . http_build_query([
                            'type' => $type,
                            'batch_id' => (int)$batch['id'],
                            'row_status' => $key,
                        ])
                    ); ?>"
                >
                    <?= diEsc($label); ?>
                </a>
            <?php endforeach; ?>

            <a
                class="btn"
                href="<?= diEsc(
                    BASE_URL
                    . 'admin-data-import.php?'
                    . http_build_query([
                        'type' => $type,
                        'batch_id' => (int)$batch['id'],
                        'download' => 'row_report',
                    ])
                ); ?>"
            >
                <i class="fa-solid fa-download"></i>
                Row Report CSV
            </a>
        </div>

        <?php if (!$rows): ?>
            <div class="empty">No rows match this filter.</div>
        <?php else: ?>
            <div class="table-wrap">
                <table class="table">
                    <thead>
                    <tr>
                        <th>CSV Row</th>
                        <th>Status</th>
                        <th>Record</th>
                        <th>Validation / Duplicate Review</th>
                        <th>Target</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($rows as $row): ?>
                        <?php
                        $raw =
                            tsImportDecode(
                                (string)$row['raw_json']
                            );

                        $errors =
                            tsImportDecode(
                                (string)($row['errors_json'] ?? '')
                            );

                        $warnings =
                            tsImportDecode(
                                (string)($row['warnings_json'] ?? '')
                            );
                        ?>
                        <tr>
                            <td><?= (int)$row['row_number']; ?></td>
                            <td>
                                <span class="pill <?= diEsc(diStatusClass((string)$row['status'])); ?>">
                                    <?= diEsc(strtoupper((string)$row['status'])); ?>
                                </span>
                            </td>
                            <td>
                                <strong><?= diEsc(diRawSummary($raw, $type)); ?></strong>
                            </td>
                            <td class="messages">
                                <?php foreach ($errors as $message): ?>
                                    <div class="e">
                                        <i class="fa-solid fa-circle-xmark"></i>
                                        <?= diEsc((string)$message); ?>
                                    </div>
                                <?php endforeach; ?>

                                <?php foreach ($warnings as $message): ?>
                                    <div class="w">
                                        <i class="fa-solid fa-triangle-exclamation"></i>
                                        <?= diEsc((string)$message); ?>
                                    </div>
                                <?php endforeach; ?>

                                <?php if (!$errors && !$warnings): ?>
                                    <span style="color:#047857;">Ready to import.</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!empty($row['target_id'])): ?>
                                    <?= diEsc((string)$row['target_table']); ?>
                                    #<?= (int)$row['target_id']; ?>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>


        <?php if ((string)$batch['status'] === 'previewed'): ?>
            <div class="confirm">
                <form
                    method="post"
                    onsubmit="return confirm('Import this reviewed batch now? Existing Customer/Supplier masters will not be overwritten.');"
                >
                    <input type="hidden" name="csrf_token" value="<?= diEsc($csrf); ?>">
                    <input type="hidden" name="action" value="execute">
                    <input type="hidden" name="batch_id" value="<?= (int)$batch['id']; ?>">
                    <input type="hidden" name="import_type" value="<?= diEsc($type); ?>">

                    <?php if ((int)$batch['warning_rows'] > 0): ?>
                        <label style="display:block;margin-bottom:7px;">
                            <input type="checkbox" name="include_warnings" value="1">
                            <strong>Import reviewed WARNING rows too.</strong>
                            Warning rows are excluded unless you explicitly select this.
                            DUPLICATE and ERROR rows can never be imported.
                        </label>
                    <?php endif; ?>

                    <?php if ($type === 'enquiry'): ?>
                        <label style="display:block;margin-bottom:7px;">
                            <input type="checkbox" name="create_trips" value="1" checked>
                            Create the normal TRAVSCOPE Trip record after each successfully imported Enquiry.
                        </label>
                    <?php endif; ?>

                    <div style="display:flex;gap:7px;flex-wrap:wrap;">
                        <button class="btn good" type="submit">
                            <i class="fa-solid fa-file-import"></i>
                            Import Reviewed Rows
                        </button>
                    </div>
                </form>

                <form
                    method="post"
                    style="margin-top:7px;"
                    onsubmit="return confirm('Cancel this preview batch? No business records will be created.');"
                >
                    <input type="hidden" name="csrf_token" value="<?= diEsc($csrf); ?>">
                    <input type="hidden" name="action" value="cancel">
                    <input type="hidden" name="batch_id" value="<?= (int)$batch['id']; ?>">
                    <input type="hidden" name="import_type" value="<?= diEsc($type); ?>">

                    <button class="btn bad" type="submit">
                        Cancel Batch
                    </button>
                </form>
            </div>
        <?php elseif ((string)$batch['status'] === 'importing'): ?>
            <div class="notice warn">
                This batch is marked IMPORTING, which usually means a previous request was interrupted or timed out.
                Resume is safe: already imported rows are skipped and every remaining row is duplicate-checked again.
            </div>

            <form
                method="post"
                onsubmit="return confirm('Resume this interrupted import batch?');"
            >
                <input type="hidden" name="csrf_token" value="<?= diEsc($csrf); ?>">
                <input type="hidden" name="action" value="execute">
                <input type="hidden" name="batch_id" value="<?= (int)$batch['id']; ?>">
                <input type="hidden" name="import_type" value="<?= diEsc($type); ?>">

                <?php if (!empty($options['include_warning_rows'])): ?>
                    <input type="hidden" name="include_warnings" value="1">
                <?php endif; ?>

                <?php if (!empty($options['create_enquiry_trips'])): ?>
                    <input type="hidden" name="create_trips" value="1">
                <?php endif; ?>

                <button class="btn warn" type="submit">
                    <i class="fa-solid fa-rotate"></i>
                    Resume Import
                </button>
            </form>

        <?php elseif ((string)$batch['status'] === 'completed'): ?>
            <?php $result = tsImportDecode((string)($batch['result_json'] ?? '')); ?>
            <div class="notice ok">
                Completed batch.
                Imported <?= (int)($result['imported_rows'] ?? $batch['imported_rows']); ?>.
                Skipped <?= (int)($result['skipped_rows'] ?? $batch['skipped_rows']); ?>.
                <?php if ($type === 'enquiry'): ?>
                    Trips created <?= (int)($result['trips_created'] ?? 0); ?>.
                <?php endif; ?>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php endif; ?>

</section>


<aside>
<div class="card">
    <div class="head">
        <div>
            <h2>Import Safety Rules</h2>
            <p>These rules are enforced server-side.</p>
        </div>
    </div>

    <div class="body">
        <div class="notice warn" style="margin-top:0;">
            <strong>No overwrite:</strong><br>
            Customer email/mobile strong matches are DUPLICATE.<br><br>
            Supplier GSTIN/Tax ID/contact email/mobile strong matches are DUPLICATE.<br><br>
            Same Customer name + country and same Supplier company + location are WARNING only and require explicit review.<br><br>
            Enquiry duplicate signature uses email + normalized mobile + destination + travel date.<br><br>
            Every inserted row is rechecked for duplicates again at import time.
        </div>
    </div>
</div>


<div class="card" style="margin-top:11px;">
    <div class="head">
        <div>
            <h2>Recent Import Batches</h2>
            <p>Permanent preview and migration history.</p>
        </div>
    </div>

    <div class="body">
        <?php if (!$recent): ?>
            <div class="empty">No import batches yet.</div>
        <?php endif; ?>

        <?php foreach ($recent as $item): ?>
            <div class="history">
                <div style="display:flex;justify-content:space-between;gap:5px;">
                    <a
                        href="<?= diEsc(
                            BASE_URL
                            . 'admin-data-import.php?type='
                            . urlencode((string)$item['import_type'])
                            . '&batch_id='
                            . (int)$item['id']
                        ); ?>"
                    >
                        Batch #<?= (int)$item['id']; ?>
                        · <?= diEsc(ucfirst((string)$item['import_type'])); ?>
                    </a>

                    <span class="pill <?= diEsc(diStatusClass((string)$item['status'])); ?>">
                        <?= diEsc(strtoupper((string)$item['status'])); ?>
                    </span>
                </div>

                <small>
                    <?= diEsc((string)$item['original_filename']); ?><br>
                    Rows <?= (int)$item['total_rows']; ?>
                    · Valid <?= (int)$item['valid_rows']; ?>
                    · Warning <?= (int)$item['warning_rows']; ?>
                    · Duplicate <?= (int)$item['duplicate_rows']; ?>
                    · Error <?= (int)$item['error_rows']; ?>
                    · Imported <?= (int)$item['imported_rows']; ?><br>
                    <?= diEsc(diDate((string)$item['created_at'])); ?>
                    · <?= diEsc((string)($item['admin_name'] ?? 'Admin')); ?>
                </small>
            </div>
        <?php endforeach; ?>
    </div>
</div>
</aside>

</div>

</main>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
