<?php

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/cancellation-workflow-functions.php';
$crmFunctionsFile = __DIR__ . '/crm-functions.php';
if (is_file($crmFunctionsFile)) {
    require_once $crmFunctionsFile;
}

$supplierFunctionsFile = __DIR__ . '/supplier-functions.php';
if (is_file($supplierFunctionsFile)) {
    require_once $supplierFunctionsFile;
}

$operationsFunctionsFile = __DIR__ . '/operations-functions.php';
if (is_file($operationsFunctionsFile)) {
    require_once $operationsFunctionsFile;
}

$financeFunctionsFile = __DIR__ . '/finance-functions.php';
if (is_file($financeFunctionsFile)) {
    require_once $financeFunctionsFile;
}

$amendmentFunctionsFile = __DIR__ . '/amendment-functions.php';
if (is_file($amendmentFunctionsFile)) {
    require_once $amendmentFunctionsFile;
}

$executionFunctionsFile = __DIR__ . '/execution-functions.php';
if (is_file($executionFunctionsFile)) {
    require_once $executionFunctionsFile;
}

$billingFunctionsFile = __DIR__ . '/billing-functions.php';
if (is_file($billingFunctionsFile)) {
    require_once $billingFunctionsFile;
}

$documentFunctionsFile = __DIR__ . '/document-functions.php';
if (is_file($documentFunctionsFile)) {
    require_once $documentFunctionsFile;
}

$communicationFunctionsFile = __DIR__ . '/communication-functions.php';
if (is_file($communicationFunctionsFile)) {
    require_once $communicationFunctionsFile;
}

$accessControlFunctionsFile = __DIR__ . '/access-control-functions.php';
if (is_file($accessControlFunctionsFile)) {
    require_once $accessControlFunctionsFile;
}

/*
|--------------------------------------------------------------------------
| ADMIN AUTH
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_id'])) {
    redirect(BASE_URL . 'admin-login.php');
}

$adminId = (int)$_SESSION['admin_id'];

$stmt = $pdo->prepare("
    SELECT id, name, email, role, status
    FROM admins
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$adminId]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin || $admin['status'] !== 'active') {
    unset($_SESSION['admin_id']);
    redirect(BASE_URL . 'admin-login.php');
}

$aclCanViewSupplierCost = function_exists('tsAclCan')
    ? tsAclCan($pdo, $adminId, 'view_supplier_cost')
    : true;
$aclCanViewMargin = function_exists('tsAclCan')
    ? tsAclCan($pdo, $adminId, 'view_margin')
    : true;
$aclCanApproveSupplierInvoice = function_exists('tsAclCan')
    ? tsAclCan($pdo, $adminId, 'approve_supplier_invoice')
    : true;
$aclCanRecordSupplierPayment = function_exists('tsAclCan')
    ? tsAclCan($pdo, $adminId, 'record_supplier_payment')
    : true;
$aclCanManageOperations = function_exists('tsAclCan')
    ? tsAclCan($pdo, $adminId, 'manage_operations')
    : true;
$aclCanManageSupplierProcurement = function_exists('tsAclCan')
    ? tsAclCan($pdo, $adminId, 'manage_supplier_procurement')
    : true;

/*
|--------------------------------------------------------------------------
| BOOKING ID
|--------------------------------------------------------------------------
*/

$bookingId = (int)($_GET['id'] ?? $_POST['booking_id'] ?? 0);

if ($bookingId <= 0) {
    redirect(BASE_URL . 'admin-bookings.php');
}

/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_booking_details_csrf'])) {
    $_SESSION['admin_booking_details_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['admin_booking_details_csrf'];

/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function abdMoney($amount, $currency = 'INR'): string
{
    $amount = (float)$amount;
    $currency = strtoupper(trim((string)$currency));

    return $currency === 'INR'
        ? '₹' . number_format($amount, 2)
        : $currency . ' ' . number_format($amount, 2);
}

function abdDate($date, $format = 'd M Y, h:i A'): string
{
    if (empty($date)) {
        return 'Not set';
    }

    $time = strtotime((string)$date);

    return $time ? date($format, $time) : 'Not set';
}

function abdBookingClass($status): string
{
    return match ((string)$status) {
        'confirmed' => 'success',
        'completed' => 'blue',
        'cancelled' => 'danger',
        default => 'warning',
    };
}

function abdPaymentClass($status): string
{
    return match ((string)$status) {
        'paid', 'success' => 'success',
        'partial', 'pending' => 'warning',
        'refunded' => 'blue',
        'failed' => 'danger',
        default => 'danger',
    };
}

function abdInitial($name): string
{
    $name = trim((string)$name);

    if ($name === '') {
        return 'T';
    }

    return strtoupper(
        function_exists('mb_substr')
            ? mb_substr($name, 0, 1)
            : substr($name, 0, 1)
    );
}

/*
|--------------------------------------------------------------------------
| FLASH
|--------------------------------------------------------------------------
*/

$success = '';
$error = '';

if (!empty($_SESSION['admin_booking_details_success'])) {
    $success = (string)$_SESSION['admin_booking_details_success'];
    unset($_SESSION['admin_booking_details_success']);
}

if (!empty($_SESSION['admin_booking_details_error'])) {
    $error = (string)$_SESSION['admin_booking_details_error'];
    unset($_SESSION['admin_booking_details_error']);
}

$quickPaymentRequest = null;
if (!empty($_SESSION['admin_booking_payment_request']) && is_array($_SESSION['admin_booking_payment_request'])) {
    $quickPaymentRequest = $_SESSION['admin_booking_payment_request'];
    unset($_SESSION['admin_booking_payment_request']);
}

/*
|--------------------------------------------------------------------------
| UPDATE BOOKING STATUS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $postedToken = (string)($_POST['csrf_token'] ?? '');

    if (
        $postedToken === '' ||
        !hash_equals($_SESSION['admin_booking_details_csrf'] ?? '', $postedToken)
    ) {
        $error = 'Security verification failed. Please refresh and try again.';
    } else {

        $action = (string)($_POST['action'] ?? '');


        if ($action === 'create_supplier_booking_order') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_supplier_procurement','create_supplier_booking_order','booking',$bookingId);
                if (
                    !function_exists('tsSupplierBookingProcurementReady')
                    || !tsSupplierBookingProcurementReady($pdo)
                ) {
                    throw new RuntimeException(
                        'Supplier Procurement SQL is not installed yet.'
                    );
                }

                $supplierId =
                    max(
                        0,
                        (int)($_POST['supplier_id'] ?? 0)
                    );

                $serviceIds =
                    array_values(
                        array_unique(
                            array_filter(
                                array_map(
                                    'intval',
                                    (array)(
                                        $_POST['service_ids']
                                        ?? []
                                    )
                                )
                            )
                        )
                    );

                if ($supplierId <= 0 || !$serviceIds) {
                    throw new RuntimeException(
                        'Select supplier-backed Booking services first.'
                    );
                }

                $placeholders =
                    implode(
                        ',',
                        array_fill(
                            0,
                            count($serviceIds),
                            '?'
                        )
                    );

                $params =
                    array_merge(
                        [$bookingId, $supplierId],
                        $serviceIds
                    );

                $stmt = $pdo->prepare("
                    SELECT *
                    FROM booking_service_snapshots
                    WHERE booking_id = ?
                      AND source_supplier_id = ?
                      AND id IN ($placeholders)
                    ORDER BY sort_order ASC, id ASC
                ");
                $stmt->execute($params);
                $selectedServices =
                    $stmt->fetchAll(PDO::FETCH_ASSOC)
                    ?: [];

                if (
                    count($selectedServices)
                    !== count($serviceIds)
                ) {
                    throw new RuntimeException(
                        'One or more Booking services are not linked to this supplier.'
                    );
                }

                $stmt = $pdo->prepare("
                    SELECT *
                    FROM suppliers
                    WHERE id = ?
                      AND status = 'active'
                    LIMIT 1
                ");
                $stmt->execute([$supplierId]);
                $supplier =
                    $stmt->fetch(PDO::FETCH_ASSOC)
                    ?: null;

                if (!$supplier) {
                    throw new RuntimeException(
                        'The selected supplier is not active.'
                    );
                }

                $contact =
                    tsSupplierPrimaryContact(
                        $pdo,
                        $supplierId
                    );

                $stmt = $pdo->prepare("
                    SELECT
                        l.trip_id,
                        t.trip_code
                    FROM booking_trip_links l
                    JOIN trips t
                        ON t.id = l.trip_id
                    WHERE l.booking_id = ?
                    LIMIT 1
                ");
                $stmt->execute([$bookingId]);
                $tripLink =
                    $stmt->fetch(PDO::FETCH_ASSOC)
                    ?: [
                        'trip_id' => 0,
                        'trip_code' => 'WEB-' . (string)($booking['booking_number'] ?? $bookingId)
                    ];

                $stmt = $pdo->prepare("
                    SELECT *
                    FROM supplier_booking_orders
                    WHERE booking_id = ?
                      AND supplier_id = ?
                    LIMIT 1
                ");
                $stmt->execute([
                    $bookingId,
                    $supplierId
                ]);
                $order =
                    $stmt->fetch(PDO::FETCH_ASSOC)
                    ?: null;

                $pdo->beginTransaction();

                if (!$order) {
                    $orderCode =
                        tsSupplierBookingOrderCode(
                            $pdo
                        );

                    $subject =
                        'Booking Confirmation '
                        . $orderCode
                        . ' · '
                        . (string)(
                            $booking['booking_number']
                            ?? ''
                        );

                    $requestText =
                        trim(
                            (string)(
                                $_POST['confirmation_request_text']
                                ?? ''
                            )
                        );

                    $stmt = $pdo->prepare("
                        INSERT INTO supplier_booking_orders
                        (
                            order_code,
                            booking_id,
                            trip_id,
                            supplier_id,
                            supplier_contact_id,
                            subject,
                            request_text,
                            status,
                            created_by_admin_id,
                            updated_by_admin_id
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, 'draft', ?, ?)
                    ");
                    $stmt->execute([
                        $orderCode,
                        $bookingId,
                        (int)$tripLink['trip_id'],
                        $supplierId,
                        $contact
                            ? (int)$contact['id']
                            : null,
                        $subject,
                        $requestText !== ''
                            ? $requestText
                            : null,
                        $adminId,
                        $adminId
                    ]);

                    $orderId =
                        (int)$pdo->lastInsertId();

                    $stmt = $pdo->prepare("
                        SELECT *
                        FROM supplier_booking_orders
                        WHERE id = ?
                        LIMIT 1
                    ");
                    $stmt->execute([$orderId]);
                    $order =
                        $stmt->fetch(PDO::FETCH_ASSOC)
                        ?: null;
                } else {
                    $orderId =
                        (int)$order['id'];

                    if (
                        trim(
                            (string)(
                                $_POST['confirmation_request_text']
                                ?? ''
                            )
                        ) !== ''
                    ) {
                        $pdo->prepare("
                            UPDATE supplier_booking_orders
                            SET
                                request_text = ?,
                                supplier_contact_id = ?,
                                updated_by_admin_id = ?,
                                updated_at = NOW()
                            WHERE id = ?
                        ")->execute([
                            trim(
                                (string)$_POST['confirmation_request_text']
                            ),
                            $contact
                                ? (int)$contact['id']
                                : null,
                            $adminId,
                            $orderId
                        ]);

                        $order['request_text'] =
                            trim(
                                (string)$_POST['confirmation_request_text']
                            );
                    }
                }

                if (!$order) {
                    throw new RuntimeException(
                        'Unable to prepare supplier confirmation order.'
                    );
                }

                $insertItem = $pdo->prepare("
                    INSERT INTO supplier_booking_order_items
                    (
                        supplier_booking_order_id,
                        booking_service_snapshot_id,
                        service_type,
                        title,
                        service_date_from,
                        service_date_to,
                        quantity,
                        specifications,
                        agreed_supplier_cost,
                        status,
                        sort_order
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'confirmation_requested', ?)
                    ON DUPLICATE KEY UPDATE
                        service_type = VALUES(service_type),
                        title = VALUES(title),
                        service_date_from = VALUES(service_date_from),
                        service_date_to = VALUES(service_date_to),
                        quantity = VALUES(quantity),
                        specifications = VALUES(specifications),
                        agreed_supplier_cost = VALUES(agreed_supplier_cost),
                        status =
                            CASE
                                WHEN supplier_booking_order_items.status = 'confirmed'
                                THEN supplier_booking_order_items.status
                                ELSE 'confirmation_requested'
                            END,
                        updated_at = NOW()
                ");

                foreach ($selectedServices as $service) {
                    $insertItem->execute([
                        (int)$order['id'],
                        (int)$service['id'],
                        (string)$service['service_type'],
                        (string)$service['title'],
                        $service['service_date_from'] ?? null,
                        $service['service_date_to'] ?? null,
                        max(
                            0.01,
                            (float)($service['quantity'] ?? 1)
                        ),
                        $service['specifications'] ?? null,
                        max(
                            0,
                            (float)(
                                $service['internal_supplier_cost']
                                ?? 0
                            )
                        ),
                        (int)($service['sort_order'] ?? 0)
                    ]);

                    $pdo->prepare("
                        UPDATE booking_service_snapshots
                        SET
                            procurement_status = 'confirmation_requested',
                            updated_at = NOW()
                        WHERE id = ?
                          AND procurement_status <> 'confirmed'
                    ")->execute([
                        (int)$service['id']
                    ]);
                }

                $pdo->commit();

                $stmt = $pdo->prepare("
                    SELECT
                        o.*,
                        b.booking_number,
                        b.currency,
                        COALESCE(t.trip_code, CONCAT('WEB-', b.booking_number)) AS trip_code
                    FROM supplier_booking_orders o
                    JOIN bookings b
                        ON b.id = o.booking_id
                    LEFT JOIN trips t
                        ON t.id = o.trip_id
                    WHERE o.id = ?
                    LIMIT 1
                ");
                $stmt->execute([
                    (int)$order['id']
                ]);
                $mailOrder =
                    $stmt->fetch(PDO::FETCH_ASSOC)
                    ?: $order;

                $stmt = $pdo->prepare("
                    SELECT *
                    FROM supplier_booking_order_items
                    WHERE supplier_booking_order_id = ?
                    ORDER BY sort_order ASC, id ASC
                ");
                $stmt->execute([
                    (int)$order['id']
                ]);
                $mailItems =
                    $stmt->fetchAll(PDO::FETCH_ASSOC)
                    ?: [];

                $mailResult =
                    tsSupplierBookingEmail(
                        $pdo,
                        $mailOrder,
                        $supplier,
                        $contact,
                        $mailItems
                    );

                if (!empty($mailResult['ok'])) {
                    $pdo->prepare("
                        UPDATE supplier_booking_orders
                        SET
                            status = 'sent',
                            sent_at = COALESCE(sent_at, NOW()),
                            updated_by_admin_id = ?,
                            updated_at = NOW()
                        WHERE id = ?
                    ")->execute([
                        $adminId,
                        (int)$order['id']
                    ]);

                    tsSupplierBookingMessage(
                        $pdo,
                        (int)$order['id'],
                        'admin',
                        $adminId,
                        'Booking service confirmation request sent to supplier.',
                        'email'
                    );

                    $_SESSION['admin_booking_details_success'] =
                        'Supplier confirmation '
                        . (string)$mailOrder['order_code']
                        . ' sent to '
                        . (string)$supplier['company_name']
                        . '.';
                } else {
                    $_SESSION['admin_booking_details_error'] =
                        (string)(
                            $mailResult['message']
                            ?? 'Supplier confirmation was prepared but email could not be sent.'
                        );
                }

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#supplier-procurement'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                error_log(
                    'Admin supplier procurement create: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to prepare supplier confirmation: '
                    . $e->getMessage();
            }
        }

        if ($action === 'resend_supplier_booking_order') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_supplier_procurement','resend_supplier_booking_order','booking',$bookingId);
                if (
                    !function_exists('tsSupplierBookingProcurementReady')
                    || !tsSupplierBookingProcurementReady($pdo)
                ) {
                    throw new RuntimeException(
                        'Supplier Procurement SQL is not installed yet.'
                    );
                }

                $orderId =
                    max(
                        0,
                        (int)(
                            $_POST['supplier_booking_order_id']
                            ?? 0
                        )
                    );

                $stmt = $pdo->prepare("
                    SELECT
                        o.*,
                        b.booking_number,
                        b.currency,
                        COALESCE(t.trip_code, CONCAT('WEB-', b.booking_number)) AS trip_code,
                        s.company_name
                    FROM supplier_booking_orders o
                    JOIN bookings b
                        ON b.id = o.booking_id
                    LEFT JOIN trips t
                        ON t.id = o.trip_id
                    JOIN suppliers s
                        ON s.id = o.supplier_id
                    WHERE o.id = ?
                      AND o.booking_id = ?
                    LIMIT 1
                ");
                $stmt->execute([
                    $orderId,
                    $bookingId
                ]);
                $order =
                    $stmt->fetch(PDO::FETCH_ASSOC)
                    ?: null;

                if (!$order) {
                    throw new RuntimeException(
                        'Supplier confirmation order was not found.'
                    );
                }

                $stmt = $pdo->prepare("
                    SELECT *
                    FROM suppliers
                    WHERE id = ?
                    LIMIT 1
                ");
                $stmt->execute([
                    (int)$order['supplier_id']
                ]);
                $supplier =
                    $stmt->fetch(PDO::FETCH_ASSOC)
                    ?: null;

                if (!$supplier) {
                    throw new RuntimeException(
                        'Supplier was not found.'
                    );
                }

                $contact =
                    tsSupplierPrimaryContact(
                        $pdo,
                        (int)$order['supplier_id']
                    );

                $stmt = $pdo->prepare("
                    SELECT *
                    FROM supplier_booking_order_items
                    WHERE supplier_booking_order_id = ?
                    ORDER BY sort_order ASC, id ASC
                ");
                $stmt->execute([$orderId]);
                $items =
                    $stmt->fetchAll(PDO::FETCH_ASSOC)
                    ?: [];

                $mailResult =
                    tsSupplierBookingEmail(
                        $pdo,
                        $order,
                        $supplier,
                        $contact,
                        $items
                    );

                if (empty($mailResult['ok'])) {
                    throw new RuntimeException(
                        (string)(
                            $mailResult['message']
                            ?? 'Unable to send supplier confirmation email.'
                        )
                    );
                }

                $pdo->prepare("
                    UPDATE supplier_booking_orders
                    SET
                        status =
                            CASE
                                WHEN status = 'supplier_confirmed'
                                THEN status
                                ELSE 'sent'
                            END,
                        sent_at = COALESCE(sent_at, NOW()),
                        updated_by_admin_id = ?,
                        updated_at = NOW()
                    WHERE id = ?
                ")->execute([
                    $adminId,
                    $orderId
                ]);

                tsSupplierBookingMessage(
                    $pdo,
                    $orderId,
                    'admin',
                    $adminId,
                    'Supplier confirmation request resent / followed up by email.',
                    'email'
                );

                $_SESSION['admin_booking_details_success'] =
                    'Supplier confirmation follow-up sent.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#supplier-procurement'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Admin supplier procurement resend: '
                    . $e->getMessage()
                );
                $error =
                    'Unable to resend supplier confirmation.';
            }
        }

        if ($action === 'record_supplier_booking_response') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_supplier_procurement','record_supplier_booking_response','booking',$bookingId);
                if (
                    !function_exists('tsSupplierBookingProcurementReady')
                    || !tsSupplierBookingProcurementReady($pdo)
                ) {
                    throw new RuntimeException(
                        'Supplier Procurement SQL is not installed yet.'
                    );
                }

                $orderId =
                    max(
                        0,
                        (int)(
                            $_POST['supplier_booking_order_id']
                            ?? 0
                        )
                    );

                $responseStatus =
                    strtolower(
                        trim(
                            (string)(
                                $_POST['response_status']
                                ?? ''
                            )
                        )
                    );

                $allowed = [
                    'confirmed',
                    'rejected',
                    'alternative_required'
                ];

                if (!in_array($responseStatus, $allowed, true)) {
                    throw new RuntimeException(
                        'Select a valid supplier response.'
                    );
                }

                $reference =
                    trim(
                        (string)(
                            $_POST['supplier_confirmation_ref']
                            ?? ''
                        )
                    );

                $note =
                    trim(
                        (string)(
                            $_POST['supplier_confirmation_note']
                            ?? ''
                        )
                    );

                $stmt = $pdo->prepare("
                    SELECT *
                    FROM supplier_booking_orders
                    WHERE id = ?
                      AND booking_id = ?
                    LIMIT 1
                ");
                $stmt->execute([
                    $orderId,
                    $bookingId
                ]);
                $order =
                    $stmt->fetch(PDO::FETCH_ASSOC)
                    ?: null;

                if (!$order) {
                    throw new RuntimeException(
                        'Supplier confirmation order was not found.'
                    );
                }

                $pdo->beginTransaction();

                $pdo->prepare("
                    UPDATE supplier_booking_order_items
                    SET
                        status = ?,
                        supplier_confirmation_ref = ?,
                        supplier_note = ?,
                        updated_at = NOW()
                    WHERE supplier_booking_order_id = ?
                ")->execute([
                    $responseStatus,
                    $reference !== ''
                        ? $reference
                        : null,
                    $note !== ''
                        ? $note
                        : null,
                    $orderId
                ]);

                $pdo->prepare("
                    UPDATE supplier_booking_orders
                    SET
                        supplier_confirmation_ref = ?,
                        supplier_confirmation_note = ?,
                        first_response_at = COALESCE(first_response_at, NOW()),
                        last_response_at = NOW(),
                        updated_by_admin_id = ?,
                        updated_at = NOW()
                    WHERE id = ?
                ")->execute([
                    $reference !== ''
                        ? $reference
                        : null,
                    $note !== ''
                        ? $note
                        : null,
                    $adminId,
                    $orderId
                ]);

                tsSupplierBookingSyncServiceStatuses(
                    $pdo,
                    $orderId
                );

                tsSupplierBookingRefreshOrderStatus(
                    $pdo,
                    $orderId
                );

                tsSupplierBookingMessage(
                    $pdo,
                    $orderId,
                    'admin',
                    $adminId,
                    'External supplier response recorded: '
                    . ucwords(
                        str_replace(
                            '_',
                            ' ',
                            $responseStatus
                        )
                    )
                    . ($reference !== ''
                        ? ' · Ref ' . $reference
                        : '')
                    . ($note !== ''
                        ? "\n" . $note
                        : ''),
                    'manual'
                );

                $pdo->commit();

                $_SESSION['admin_booking_details_success'] =
                    'Supplier confirmation response recorded.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#supplier-procurement'
                );

            } catch (RuntimeException $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $error = $e->getMessage();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                error_log(
                    'Admin supplier procurement response: '
                    . $e->getMessage()
                );
                $error =
                    'Unable to record supplier response.';
            }
        }


        if ($action === 'save_operations_checklist') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_operations','save_operations_checklist','booking',$bookingId);
                if (
                    !function_exists('tsOpsReady')
                    || !tsOpsReady($pdo)
                ) {
                    throw new RuntimeException(
                        'Operations & Voucher SQL is not installed yet.'
                    );
                }

                tsOpsEnsureChecklist(
                    $pdo,
                    $bookingId
                );

                $complete =
                    (array)(
                        $_POST['operation_complete']
                        ?? []
                    );

                $notes =
                    (array)(
                        $_POST['operation_note']
                        ?? []
                    );

                $definitions =
                    tsOpsChecklistDefinitions();

                $stmt = $pdo->prepare("
                    UPDATE booking_operation_checks
                    SET
                        is_complete = ?,
                        note = ?,
                        completed_by_admin_id = ?,
                        completed_at = ?,
                        updated_at = NOW()
                    WHERE booking_id = ?
                      AND check_key = ?
                ");

                foreach ($definitions as $key => $label) {
                    $isComplete =
                        !empty($complete[$key])
                            ? 1
                            : 0;

                    $note =
                        trim(
                            (string)(
                                $notes[$key]
                                ?? ''
                            )
                        );

                    $stmt->execute([
                        $isComplete,
                        $note !== ''
                            ? $note
                            : null,
                        $isComplete
                            ? $adminId
                            : null,
                        $isComplete
                            ? date('Y-m-d H:i:s')
                            : null,
                        $bookingId,
                        $key
                    ]);
                }

                $_SESSION['admin_booking_details_success'] =
                    'Operations checklist updated.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#operations-readiness'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Admin operations checklist: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to update operations checklist.';
            }
        }

        if ($action === 'generate_booking_voucher') {
            try {
                if (
                    !function_exists('tsOpsCreateVoucherVersion')
                    || !tsOpsReady($pdo)
                ) {
                    throw new RuntimeException(
                        'Operations & Voucher SQL is not installed yet.'
                    );
                }

                $voucherStatus =
                    strtolower(
                        trim(
                            (string)(
                                $_POST['voucher_status']
                                ?? 'draft'
                            )
                        )
                    );

                if (
                    !in_array(
                        $voucherStatus,
                        ['draft', 'final'],
                        true
                    )
                ) {
                    $voucherStatus = 'draft';
                }

                if (
                    $voucherStatus === 'final'
                    && function_exists('tsAclRequire')
                ) {
                    tsAclRequire(
                        $pdo,
                        $adminId,
                        'issue_final_voucher',
                        'issue_final_customer_voucher',
                        'booking',
                        $bookingId
                    );
                }

                $voucher =
                    tsOpsCreateVoucherVersion(
                        $pdo,
                        $bookingId,
                        $adminId,
                        $voucherStatus
                    );

                $_SESSION['admin_booking_details_success'] =
                    (
                        $voucherStatus === 'final'
                            ? 'Final customer voucher '
                            : 'Draft voucher '
                    )
                    . (string)(
                        $voucher['voucher_code']
                        ?? ''
                    )
                    . ' created.';

                if (
                    !empty($_POST['open_voucher'])
                    && !empty($voucher['id'])
                ) {
                    redirect(
                        BASE_URL
                        . 'booking-voucher.php?voucher='
                        . (int)$voucher['id']
                    );
                }

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#operations-readiness'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Admin booking voucher generation: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to generate Booking voucher: '
                    . $e->getMessage();
            }
        }


        if ($action === 'create_supplier_invoice') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'approve_supplier_invoice','record_supplier_invoice','booking',$bookingId);
                if (
                    !function_exists('tsFinReady')
                    || !tsFinReady($pdo)
                ) {
                    throw new RuntimeException(
                        'Supplier Finance SQL is not installed yet.'
                    );
                }

                $result =
                    tsFinCreateSupplierInvoice(
                        $pdo,
                        $bookingId,
                        $adminId,
                        $_POST,
                        $_FILES['supplier_invoice_attachment']
                        ?? []
                    );

                $_SESSION['admin_booking_details_success'] =
                    'Supplier invoice '
                    . (string)$result['invoice_number']
                    . ' recorded for '
                    . (string)$result['supplier_name']
                    . ' · '
                    . number_format(
                        (float)$result['total_amount'],
                        2
                    )
                    . '.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#finance-profitability'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (PDOException $e) {
                error_log(
                    'Supplier invoice DB error: '
                    . $e->getMessage()
                );

                if (
                    (string)$e->getCode()
                    === '23000'
                ) {
                    $error =
                        'This supplier invoice number already exists for the selected supplier.';
                } else {
                    $error =
                        'Unable to record supplier invoice: '
                        . $e->getMessage();
                }
            } catch (Throwable $e) {
                error_log(
                    'Supplier invoice error: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to record supplier invoice: '
                    . $e->getMessage();
            }
        }

        if ($action === 'approve_supplier_invoice') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'approve_supplier_invoice','approve_supplier_invoice','booking',$bookingId);
                tsFinApproveInvoice(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['supplier_invoice_id']
                            ?? 0
                        )
                    ),
                    $adminId
                );

                $_SESSION['admin_booking_details_success'] =
                    'Supplier invoice approved and included in Actual Cost.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#finance-profitability'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Approve supplier invoice: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to approve supplier invoice.';
            }
        }

        if ($action === 'void_supplier_invoice') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'approve_supplier_invoice','void_supplier_invoice','booking',$bookingId);
                tsFinVoidInvoice(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['supplier_invoice_id']
                            ?? 0
                        )
                    )
                );

                $_SESSION['admin_booking_details_success'] =
                    'Supplier invoice voided.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#finance-profitability'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Void supplier invoice: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to void supplier invoice.';
            }
        }

        if ($action === 'record_supplier_payment') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'record_supplier_payment','record_supplier_payment','booking',$bookingId);
                $result =
                    tsFinRecordSupplierPayment(
                        $pdo,
                        $bookingId,
                        $adminId,
                        $_POST
                    );

                $_SESSION['admin_booking_details_success'] =
                    'Supplier payment '
                    . number_format(
                        (float)$result['amount'],
                        2
                    )
                    . ' recorded against invoice '
                    . (string)$result['invoice_number']
                    . '.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#finance-profitability'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Supplier payment error: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to record supplier payment.';
            }
        }

        if ($action === 'void_supplier_payment') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'record_supplier_payment','void_supplier_payment','booking',$bookingId);
                tsFinVoidSupplierPayment(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['supplier_payment_id']
                            ?? 0
                        )
                    )
                );

                $_SESSION['admin_booking_details_success'] =
                    'Supplier payment voided.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#finance-profitability'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Void supplier payment: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to void supplier payment.';
            }
        }

        if ($action === 'add_actual_direct_cost') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'close_profitability','record_actual_direct_cost','booking',$bookingId);
                $result =
                    tsFinAddDirectCost(
                        $pdo,
                        $bookingId,
                        $adminId,
                        $_POST,
                        $_FILES['direct_cost_attachment']
                        ?? []
                    );

                $_SESSION['admin_booking_details_success'] =
                    'Actual direct cost '
                    . (string)$result['description']
                    . ' · '
                    . number_format(
                        (float)$result['amount'],
                        2
                    )
                    . ' recorded.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#finance-profitability'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Actual direct cost error: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to record actual direct cost.';
            }
        }

        if ($action === 'void_actual_direct_cost') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'close_profitability','void_actual_direct_cost','booking',$bookingId);
                tsFinVoidDirectCost(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['actual_direct_cost_id']
                            ?? 0
                        )
                    )
                );

                $_SESSION['admin_booking_details_success'] =
                    'Actual direct cost voided.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#finance-profitability'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Void actual direct cost: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to void actual direct cost.';
            }
        }

        if ($action === 'close_booking_profitability') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'close_profitability','close_booking_profitability','booking',$bookingId);
                $closure =
                    tsFinCloseProfitability(
                        $pdo,
                        $bookingId,
                        $adminId,
                        trim(
                            (string)(
                                $_POST['profitability_closure_note']
                                ?? ''
                            )
                        )
                    );

                $_SESSION['admin_booking_details_success'] =
                    'Booking profitability financially closed. Final actual margin: '
                    . number_format(
                        (float)(
                            $closure['actual_margin']
                            ?? 0
                        ),
                        2
                    )
                    . '.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#finance-profitability'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Profitability closure error: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to close profitability: '
                    . $e->getMessage();
            }
        }


        if ($action === 'create_admin_amendment_request') {
            try {
                $amendment = tsAmendCreateRequest(
                    $pdo,
                    $bookingId,
                    'admin',
                    null,
                    $adminId,
                    trim((string)($_POST['amendment_request_text'] ?? ''))
                );

                $_SESSION['admin_booking_details_success'] =
                    'Booking Amendment V' . (int)$amendment['version_number'] . ' created.';

                redirect(BASE_URL . 'admin-booking-details.php?id=' . $bookingId . '#booking-amendments');
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Create Booking amendment: ' . $e->getMessage());
                $error = 'Unable to create Booking amendment: ' . $e->getMessage();
            }
        }

        if ($action === 'approve_booking_amendment') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'approve_amendment','approve_booking_amendment','booking',$bookingId);
                $amendment = tsAmendEvaluateAndApprove(
                    $pdo,
                    $bookingId,
                    max(0,(int)($_POST['amendment_id'] ?? 0)),
                    $adminId,
                    $_POST
                );

                $_SESSION['admin_booking_details_success'] =
                    'Booking Amendment V' . (int)$amendment['version_number'] .
                    ' approved. Revised Booking total: ' .
                    abdMoney((float)$amendment['revised_customer_price'], (string)($_POST['booking_currency'] ?? 'INR')) . '.';

                redirect(BASE_URL . 'admin-booking-details.php?id=' . $bookingId . '#booking-amendments');
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Approve Booking amendment: ' . $e->getMessage());
                $error = 'Unable to approve Booking amendment: ' . $e->getMessage();
            }
        }

        if ($action === 'reject_booking_amendment') {
            try {
                tsAmendReject(
                    $pdo,
                    $bookingId,
                    max(0,(int)($_POST['amendment_id'] ?? 0)),
                    $adminId,
                    trim((string)($_POST['customer_message'] ?? '')),
                    trim((string)($_POST['internal_note'] ?? ''))
                );

                $_SESSION['admin_booking_details_success'] = 'Booking amendment rejected.';
                redirect(BASE_URL . 'admin-booking-details.php?id=' . $bookingId . '#booking-amendments');
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Reject Booking amendment: ' . $e->getMessage());
                $error = 'Unable to reject Booking amendment.';
            }
        }


        if ($action === 'start_trip_execution') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_operations','start_trip_execution','booking',$bookingId);
                $state =
                    tsExecStart(
                        $pdo,
                        $bookingId,
                        $adminId
                    );

                $_SESSION['admin_booking_details_success'] =
                    'Trip Execution started. Live operational tracking is now active.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#travel-execution'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Start Trip Execution: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to start Trip Execution: '
                    . $e->getMessage();
            }
        }

        if ($action === 'add_execution_contact') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_operations','add_execution_contact','booking',$bookingId);
                tsExecAddContact(
                    $pdo,
                    $bookingId,
                    $adminId,
                    $_POST
                );

                $_SESSION['admin_booking_details_success'] =
                    'Operational contact added.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#travel-execution'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Execution contact error: '
                    . $e->getMessage()
                );
                $error = 'Unable to add operational contact.';
            }
        }

        if ($action === 'remove_execution_contact') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_operations','remove_execution_contact','booking',$bookingId);
                tsExecDeactivateContact(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['execution_contact_id']
                            ?? 0
                        )
                    )
                );

                $_SESSION['admin_booking_details_success'] =
                    'Operational contact removed from the active Trip view.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#travel-execution'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Remove execution contact: '
                    . $e->getMessage()
                );
                $error = 'Unable to remove operational contact.';
            }
        }

        if ($action === 'add_execution_update') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_operations','add_execution_update','booking',$bookingId);
                tsExecAddUpdate(
                    $pdo,
                    $bookingId,
                    $adminId,
                    $_POST
                );

                $_SESSION['admin_booking_details_success'] =
                    'Travel execution update recorded.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#travel-execution'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Execution update error: '
                    . $e->getMessage()
                );
                $error = 'Unable to record execution update.';
            }
        }

        if ($action === 'add_execution_incident') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_operations','add_execution_incident','booking',$bookingId);
                tsExecAddIncident(
                    $pdo,
                    $bookingId,
                    $adminId,
                    $_POST
                );

                $_SESSION['admin_booking_details_success'] =
                    'Travel incident / service issue recorded.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#travel-execution'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Execution incident error: '
                    . $e->getMessage()
                );
                $error =
                    'Unable to record incident: '
                    . $e->getMessage();
            }
        }

        if ($action === 'set_execution_incident_status') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_operations','set_execution_incident_status','booking',$bookingId);
                tsExecSetIncidentStatus(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['execution_incident_id']
                            ?? 0
                        )
                    ),
                    $adminId,
                    (string)(
                        $_POST['execution_incident_status']
                        ?? 'open'
                    ),
                    trim(
                        (string)(
                            $_POST['execution_incident_resolution']
                            ?? ''
                        )
                    )
                );

                $_SESSION['admin_booking_details_success'] =
                    'Incident status updated.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#travel-execution'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Execution incident status: '
                    . $e->getMessage()
                );
                $error = 'Unable to update incident.';
            }
        }

        if ($action === 'save_execution_checks') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_operations','save_execution_checks','booking',$bookingId);
                tsExecSaveChecks(
                    $pdo,
                    $bookingId,
                    $adminId,
                    (array)(
                        $_POST['execution_check_complete']
                        ?? []
                    ),
                    (array)(
                        $_POST['execution_check_note']
                        ?? []
                    )
                );

                $_SESSION['admin_booking_details_success'] =
                    'Trip completion checklist updated.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#travel-execution'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Execution checklist error: '
                    . $e->getMessage()
                );
                $error = 'Unable to update Trip completion checklist.';
            }
        }

        if ($action === 'add_on_tour_expense') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_operations','add_on_tour_expense','booking',$bookingId);
                if (
                    !function_exists('tsFinReady')
                    || !function_exists('tsFinAddDirectCost')
                    || !tsFinReady($pdo)
                ) {
                    throw new RuntimeException(
                        'Supplier Finance / Actual Profitability module is required for on-tour expenses.'
                    );
                }

                $expenseInput = [
                    'direct_cost_type' =>
                        (string)(
                            $_POST['on_tour_cost_type']
                            ?? 'operations'
                        ),
                    'direct_cost_description' =>
                        trim(
                            (string)(
                                $_POST['on_tour_cost_description']
                                ?? ''
                            )
                        ),
                    'direct_cost_amount' =>
                        (float)(
                            $_POST['on_tour_cost_amount']
                            ?? 0
                        ),
                    'direct_cost_date' =>
                        (string)(
                            $_POST['on_tour_cost_date']
                            ?? date('Y-m-d')
                        ),
                    'direct_cost_notes' =>
                        trim(
                            (string)(
                                $_POST['on_tour_cost_notes']
                                ?? ''
                            )
                        ),
                ];

                $result =
                    tsFinAddDirectCost(
                        $pdo,
                        $bookingId,
                        $adminId,
                        $expenseInput,
                        $_FILES['on_tour_cost_attachment']
                        ?? []
                    );

                $_SESSION['admin_booking_details_success'] =
                    'On-tour expense '
                    . abdMoney(
                        (float)$result['amount'],
                        (string)(
                            $_POST['booking_currency']
                            ?? 'INR'
                        )
                    )
                    . ' posted to Actual Profitability.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#travel-execution'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'On-tour expense error: '
                    . $e->getMessage()
                );
                $error =
                    'Unable to post on-tour expense: '
                    . $e->getMessage();
            }
        }

        if ($action === 'complete_trip_execution') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'manage_operations','complete_trip_execution','booking',$bookingId);
                $state =
                    tsExecComplete(
                        $pdo,
                        $bookingId,
                        $adminId,
                        trim(
                            (string)(
                                $_POST['execution_completion_note']
                                ?? ''
                            )
                        ),
                        trim(
                            (string)(
                                $_POST['repeat_followup_date']
                                ?? ''
                            )
                        ) ?: null,
                        trim(
                            (string)(
                                $_POST['repeat_followup_note']
                                ?? ''
                            )
                        )
                    );

                $_SESSION['admin_booking_details_success'] =
                    'Trip Execution completed. Booking is now Completed and post-trip follow-up is ready.';

                redirect(
                    BASE_URL
                    . 'admin-booking-details.php?id='
                    . $bookingId
                    . '#travel-execution'
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log(
                    'Complete Trip Execution: '
                    . $e->getMessage()
                );
                $error =
                    'Unable to complete Trip Execution: '
                    . $e->getMessage();
            }
        }

        if ($action === 'create_quick_payment_request') {
            try {
                if (!function_exists('tsBillCreateQuickPaymentRequest')) {
                    throw new RuntimeException('Quick Payment Collection is unavailable.');
                }
                $request = tsBillCreateQuickPaymentRequest(
                    $pdo,
                    $bookingId,
                    $adminId,
                    (string)($_POST['payment_request_mode'] ?? ''),
                    (float)($_POST['payment_request_custom_amount'] ?? 0),
                    (float)($_POST['payment_request_advance_percent'] ?? 25),
                    (int)($_POST['payment_link_valid_days'] ?? 7)
                );

                $freshBooking = tsBillBooking($pdo, $bookingId);
                $currency = strtoupper(trim((string)($freshBooking['currency'] ?? 'INR')) ?: 'INR');
                $amountText = $currency . ' ' . number_format((float)$request['amount'], 2);
                $message = "Dear " . trim((string)($freshBooking['customer_name'] ?? 'Traveller')) . ",\n\n"
                    . "Payment request for TRAVSCOPE Booking " . (string)($freshBooking['booking_number'] ?? ('#'.$bookingId)) . ".\n"
                    . "Request: " . (string)$request['title'] . "\n"
                    . "Amount: " . $amountText . "\n\n"
                    . "Payment link: " . (string)$request['url'] . "\n\n"
                    . "This secure link is valid for " . (int)$request['expires_in_days'] . " day(s). Please submit the payment details shown on the payment page.\n\n"
                    . "Regards,\nTRAVSCOPE";
                $subject = 'Payment Request · ' . (string)($freshBooking['booking_number'] ?? ('Booking #'.$bookingId));
                $channel = strtolower(trim((string)($_POST['send_channel'] ?? 'generate')));

                $_SESSION['admin_booking_payment_request'] = $request + ['message'=>$message,'subject'=>$subject];
                $_SESSION['admin_booking_details_success'] = (string)$request['title'] . ' link generated for ' . $amountText . '.';

                if ($channel === 'email') {
                    if (!function_exists('tsCommSendEmail')) throw new RuntimeException('Email communication service is unavailable.');
                    tsCommSendEmail($pdo, $bookingId, $subject, $message, $adminId, 'payment_due');
                    $_SESSION['admin_booking_details_success'] = 'Payment request emailed to the customer for ' . $amountText . '.';
                } elseif ($channel === 'whatsapp') {
                    if (!function_exists('tsCommRecordWhatsApp')) throw new RuntimeException('WhatsApp handoff is unavailable.');
                    $wa = tsCommRecordWhatsApp($pdo, $bookingId, $message, $adminId, 'payment_due');
                    header('Location: ' . $wa['url']);
                    exit;
                }

                redirect(BASE_URL . 'admin-booking-details.php?id=' . $bookingId . '#payment-collection');
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Quick payment collection: ' . $e->getMessage());
                $error = 'Unable to create payment request: ' . $e->getMessage();
            }
        }

        if ($action === 'create_payment_schedule') {
            try {
                $schedule = tsBillCreateSchedule($pdo, $bookingId, $adminId, $_POST);
                $_SESSION['admin_booking_details_success'] =
                    'Payment Schedule V' . (int)$schedule['version_number'] . ' created.';
                redirect(BASE_URL . 'admin-booking-details.php?id=' . $bookingId . '#customer-billing');
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Create payment schedule: ' . $e->getMessage());
                $error = 'Unable to create payment schedule: ' . $e->getMessage();
            }
        }

        if ($action === 'generate_booking_invoice') {
            try {
                $invoice = tsBillCreateInvoice(
                    $pdo,
                    $bookingId,
                    $adminId,
                    (string)($_POST['invoice_status'] ?? 'draft')
                );
                $_SESSION['admin_booking_details_success'] =
                    'Booking Invoice ' . (string)$invoice['invoice_code'] . ' created.';

                if (!empty($_POST['open_invoice'])) {
                    redirect(BASE_URL . 'booking-invoice.php?invoice=' . (int)$invoice['id']);
                }

                redirect(BASE_URL . 'admin-booking-details.php?id=' . $bookingId . '#customer-billing');
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Generate Booking invoice: ' . $e->getMessage());
                $error = 'Unable to generate Booking invoice: ' . $e->getMessage();
            }
        }

        if ($action === 'post_billing_adjustment') {
            try {
                if (function_exists('tsAclRequire')) tsAclRequire($pdo,$adminId,'post_billing_adjustment','post_billing_adjustment','booking',$bookingId);
                $adjustment = tsBillPostAdjustment(
                    $pdo,
                    $bookingId,
                    $adminId,
                    (string)($_POST['adjustment_type'] ?? ''),
                    (float)($_POST['adjustment_amount'] ?? 0),
                    (string)($_POST['adjustment_reason'] ?? ''),
                    (string)($_POST['adjustment_notes'] ?? '')
                );
                $_SESSION['admin_booking_details_success'] =
                    ucfirst((string)$adjustment['adjustment_type']) . ' Note ' .
                    (string)$adjustment['adjustment_code'] . ' posted.';
                redirect(BASE_URL . 'admin-booking-details.php?id=' . $bookingId . '#customer-billing');
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Billing adjustment: ' . $e->getMessage());
                $error = 'Unable to post billing adjustment.';
            }
        }

        if ($action === 'void_billing_adjustment') {
            try {
                tsBillVoidAdjustment(
                    $pdo,
                    $bookingId,
                    max(0, (int)($_POST['billing_adjustment_id'] ?? 0)),
                    $adminId
                );
                $_SESSION['admin_booking_details_success'] = 'Billing adjustment voided.';
                redirect(BASE_URL . 'admin-booking-details.php?id=' . $bookingId . '#customer-billing');
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Void billing adjustment: ' . $e->getMessage());
                $error = 'Unable to void billing adjustment.';
            }
        }

        if ($action === 'create_manual_customer_refund') {
            try {
                $refund = tsBillCreateManualRefund(
                    $pdo,
                    $bookingId,
                    $adminId,
                    (float)($_POST['manual_refund_amount'] ?? 0),
                    (string)($_POST['manual_refund_reason'] ?? ''),
                    (string)($_POST['manual_refund_notes'] ?? '')
                );
                $_SESSION['admin_booking_details_success'] =
                    'Customer refund ' . abdMoney((float)$refund['amount'], (string)$refund['currency']) . ' created as Pending.';
                redirect(BASE_URL . 'admin-booking-details.php?id=' . $bookingId . '#customer-billing');
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Create customer refund: ' . $e->getMessage());
                $error = 'Unable to create customer refund.';
            }
        }

        if ($action === 'mark_customer_refund_paid') {
            try {
                tsBillMarkRefundPaid(
                    $pdo,
                    $bookingId,
                    max(0, (int)($_POST['customer_refund_id'] ?? 0)),
                    $adminId,
                    (string)($_POST['refund_payment_method'] ?? 'bank_transfer'),
                    (string)($_POST['refund_reference_number'] ?? ''),
                    (string)($_POST['refund_notes'] ?? '')
                );
                $_SESSION['admin_booking_details_success'] =
                    'Customer refund marked Paid and Booking net paid amount updated.';
                redirect(BASE_URL . 'admin-booking-details.php?id=' . $bookingId . '#customer-billing');
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Mark customer refund paid: ' . $e->getMessage());
                $error = 'Unable to mark customer refund paid.';
            }
        }

        if ($action === 'send_payment_reminder') {
            try {
                $reminder = tsBillSendPaymentReminder(
                    $pdo,
                    $bookingId,
                    max(0, (int)($_POST['reminder_installment_id'] ?? 0)),
                    $adminId
                );
                $_SESSION['admin_booking_details_success'] =
                    'Payment reminder sent to ' . (string)$reminder['recipient'] . '.';
                redirect(BASE_URL . 'admin-booking-details.php?id=' . $bookingId . '#customer-billing');
            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Payment reminder: ' . $e->getMessage());
                $error = 'Unable to send payment reminder: ' . $e->getMessage();
            }
        }

        if ($action === 'change_booking_status') {

            $newStatus = strtolower(trim((string)($_POST['new_status'] ?? '')));

            $allowedTransitions = [
                'pending' => ['confirmed', 'cancelled'],
                'confirmed' => ['completed', 'cancelled'],
                'completed' => [],
                'cancelled' => []
            ];

            try {

                if (
                    $newStatus === 'confirmed'
                    && function_exists('tsAclRequire')
                ) {
                    tsAclRequire(
                        $pdo,
                        $adminId,
                        'confirm_booking',
                        'confirm_booking',
                        'booking',
                        $bookingId
                    );
                }

                $stmt = $pdo->prepare("
                    SELECT id, booking_number, booking_status
                    FROM bookings
                    WHERE id = ?
                    LIMIT 1
                ");
                $stmt->execute([$bookingId]);
                $current = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$current) {
                    throw new RuntimeException('Booking not found.');
                }

                $currentStatus = (string)$current['booking_status'];

                if (!isset($allowedTransitions[$currentStatus])) {
                    throw new RuntimeException('Unknown current booking status.');
                }

                if ($currentStatus === $newStatus) {
                    throw new RuntimeException('Booking already has this status.');
                }

                if (!in_array($newStatus, $allowedTransitions[$currentStatus], true)) {
                    throw new RuntimeException(
                        'This booking cannot be changed from ' .
                        ucfirst($currentStatus) . ' to ' . ucfirst($newStatus) . '.'
                    );
                }

                if (
                    $newStatus === 'completed'
                    && function_exists('tsExecReady')
                    && tsExecReady($pdo)
                ) {
                    throw new RuntimeException(
                        'Complete this Booking through the Travel Execution section so incidents and completion checks are verified first.'
                    );
                }

                if ($newStatus === 'cancelled') {
                    $caseId = tsCancelRecordDirect($pdo,$bookingId,$adminId,'Booking Details');
                    $_SESSION['admin_cancellation_success'] = 'Booking cancelled and registered in Finance. Review cancellation charges and any refund before payment.';
                    redirect(BASE_URL . 'admin-cancellations.php?search=' . urlencode((string)$current['booking_number']));
                }

                $stmt = $pdo->prepare("
                    UPDATE bookings
                    SET booking_status = ?
                    WHERE id = ?
                    LIMIT 1
                ");
                $stmt->execute([$newStatus, $bookingId]);

                $_SESSION['admin_booking_details_success'] =
                    'Booking ' . $current['booking_number'] .
                    ' changed to ' . ucfirst($newStatus) . '.';

                redirect(
                    BASE_URL . 'admin-booking-details.php?id=' . $bookingId
                );

            } catch (RuntimeException $e) {
                $error = $e->getMessage();
            } catch (Throwable $e) {
                error_log('Admin booking details status update: ' . $e->getMessage());
                $error = 'Unable to update booking status.';
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| FETCH BOOKING
|--------------------------------------------------------------------------
*/

$booking = null;

try {

    $stmt = $pdo->prepare("
        SELECT
            b.*,

            p.title AS package_title,
            p.slug AS package_slug,
            p.package_code,
            p.main_image AS package_image,
            p.duration_days,
            p.duration_nights,
            p.package_type,
            p.sale_price AS package_sale_price,
            p.currency AS package_currency,

            d.name AS destination_name,
            d.country AS destination_country,

            u.full_name AS user_full_name,
            u.email AS user_email,
            u.mobile AS user_mobile,
            u.profile_image AS user_profile_image,
            u.country AS user_country,
            u.email_verified AS user_email_verified,
            u.status AS user_status,
            u.created_at AS user_created_at

        FROM bookings b

        LEFT JOIN packages p
            ON p.id = b.package_id

        LEFT JOIN destinations d
            ON d.id = p.destination_id

        LEFT JOIN users u
            ON u.id = b.user_id

        WHERE b.id = ?

        LIMIT 1
    ");

    $stmt->execute([$bookingId]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    error_log('Admin booking details fetch error: ' . $e->getMessage());
}

if (!$booking) {
    http_response_code(404);
    exit('Booking not found.');
}

/*
|--------------------------------------------------------------------------
| PAYMENTS
|--------------------------------------------------------------------------
*/

$payments = [];

try {

    $stmt = $pdo->prepare("
        SELECT
            id,
            booking_id,
            transaction_id,
            payment_gateway,
            amount,
            currency,
            payment_method,
            status,
            gateway_response,
            paid_at,
            created_at
        FROM payments
        WHERE booking_id = ?
        ORDER BY id DESC
    ");

    $stmt->execute([$bookingId]);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    error_log('Admin booking payment fetch error: ' . $e->getMessage());
}

/*
|--------------------------------------------------------------------------
| FINANCE
|--------------------------------------------------------------------------
*/

$totalAmount = (float)$booking['total_amount'];
$paidAmount = (float)$booking['paid_amount'];
$balanceAmount = max(0, $totalAmount - $paidAmount);

$paidPercent = $totalAmount > 0
    ? min(100, max(0, ($paidAmount / $totalAmount) * 100))
    : 0;

$successfulPaymentTotal = 0.0;

foreach ($payments as $payment) {
    if ($payment['status'] === 'success') {
        $successfulPaymentTotal += (float)$payment['amount'];
    }
}

/*
|--------------------------------------------------------------------------
| PACKAGE IMAGE
|--------------------------------------------------------------------------
*/

$packageImage = '';

if (!empty($booking['package_image'])) {

    $rawImage = trim((string)$booking['package_image']);

    if (preg_match('~^https?://~i', $rawImage)) {
        $packageImage = $rawImage;
    } elseif (str_starts_with($rawImage, 'uploads/')) {
        $packageImage = BASE_URL . ltrim($rawImage, '/');
    } else {
        $packageImage = PACKAGE_UPLOAD_URL . basename($rawImage);
    }
}

$profileImage = '';

if (!empty($booking['user_profile_image'])) {

    $rawProfile = trim((string)$booking['user_profile_image']);

    if (preg_match('~^https?://~i', $rawProfile)) {
        $profileImage = $rawProfile;
    } elseif (str_starts_with($rawProfile, 'uploads/')) {
        $profileImage = BASE_URL . ltrim($rawProfile, '/');
    } else {
        $profileImage = PROFILE_UPLOAD_URL . basename($rawProfile);
    }
}


$bookingTripLink = null;
$bookingQuotationSnapshot = null;
$bookingServiceSnapshots = [];
$supplierBookingOrders = [];
$supplierBookingOrderItems = [];
$supplierBookingOrderMessages = [];
$operationsChecklist = [];
$operationsReadiness = null;
$bookingVoucherVersions = [];

$financeSummary = null;
$financeSuppliers = [];
$financeBookingServices = [];
$financeInvoices = [];
$financeInvoiceItems = [];
$financeSupplierPayments = [];
$financeDirectCosts = [];
$financeClosure = null;
$financeClosureReadiness = null;

$billingActiveSchedule = null;
$billingInstallments = [];
$billingSchedules = [];
$billingInvoices = [];
$billingLatestFinalInvoice = null;
$billingReceipts = [];
$billingRefunds = [];
$billingAdjustments = [];
$billingReminders = [];
$billingPendingRefundTotal = 0.0;

$bookingDocumentSummary = null;
$bookingFinalDocumentPack = null;

$bookingCommunicationSummary = null;

$bookingAmendmentBaseline = null;
$bookingAmendmentPending = null;
$bookingAmendmentHistory = [];

$executionState = null;
$executionContacts = [];
$executionUpdates = [];
$executionIncidents = [];
$executionChecks = [];
$executionCompletionReadiness = null;

if (
    function_exists('crmBookingBridgeReady')
    && crmBookingBridgeReady($pdo)
) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                l.*,
                t.trip_code,
                a.accepted_source,
                a.customer_confirmation_note,
                a.accepted_at,
                v.version_number
            FROM booking_trip_links l
            JOIN trips t
                ON t.id = l.trip_id
            JOIN quotation_acceptances a
                ON a.booking_id = l.booking_id
            JOIN crm_package_versions v
                ON v.id = l.quotation_version_id
            WHERE l.booking_id = ?
            LIMIT 1
        ");
        $stmt->execute([$bookingId]);
        $bookingTripLink =
            $stmt->fetch(PDO::FETCH_ASSOC)
            ?: null;

        $bookingQuotationSnapshot =
            crmBookingQuotationSnapshot(
                $pdo,
                $bookingId
            );

        $bookingServiceSnapshots =
            crmBookingServiceSnapshots(
                $pdo,
                $bookingId
            );

        if (
            function_exists('tsSupplierBookingProcurementReady')
            && tsSupplierBookingProcurementReady($pdo)
        ) {
            $stmt = $pdo->prepare("
                SELECT
                    o.*,
                    s.company_name,
                    c.contact_name,
                    c.email AS contact_email,
                    c.mobile AS contact_mobile,
                    c.whatsapp AS contact_whatsapp
                FROM supplier_booking_orders o
                JOIN suppliers s
                    ON s.id = o.supplier_id
                LEFT JOIN supplier_contacts c
                    ON c.id = o.supplier_contact_id
                WHERE o.booking_id = ?
                ORDER BY o.created_at ASC, o.id ASC
            ");
            $stmt->execute([$bookingId]);
            $supplierBookingOrders =
                $stmt->fetchAll(PDO::FETCH_ASSOC)
                ?: [];

            $supplierBookingOrderItems = [];
            $supplierBookingOrderMessages = [];

            foreach ($supplierBookingOrders as $supplierOrder) {
                $orderId =
                    (int)$supplierOrder['id'];

                $stmt = $pdo->prepare("
                    SELECT *
                    FROM supplier_booking_order_items
                    WHERE supplier_booking_order_id = ?
                    ORDER BY sort_order ASC, id ASC
                ");
                $stmt->execute([$orderId]);
                $supplierBookingOrderItems[$orderId] =
                    $stmt->fetchAll(PDO::FETCH_ASSOC)
                    ?: [];

                $stmt = $pdo->prepare("
                    SELECT *
                    FROM supplier_booking_order_messages
                    WHERE supplier_booking_order_id = ?
                    ORDER BY sent_at ASC, id ASC
                ");
                $stmt->execute([$orderId]);
                $supplierBookingOrderMessages[$orderId] =
                    $stmt->fetchAll(PDO::FETCH_ASSOC)
                    ?: [];
            }
        }

        if ($bookingQuotationSnapshot) {
            /*
            |--------------------------------------------------------------------------
            | ACCEPTED QUOTATION PRICE IS AUTHORITATIVE
            |--------------------------------------------------------------------------
            |
            | A CRM-created Booking must use the exact final price of the accepted
            | quotation version, not the Package Master / enquiry-time reference price.
            |
            | This also repairs older converted Bookings created before this fix.
            */

            $acceptedFinalPrice =
                max(
                    0,
                    (float)(
                        $bookingQuotationSnapshot['final_price']
                        ?? 0
                    )
                );

            $acceptedCurrency =
                strtoupper(
                    trim(
                        (string)(
                            $bookingQuotationSnapshot['currency']
                            ?? $booking['currency']
                            ?? 'INR'
                        )
                    )
                );

            if ($acceptedFinalPrice > 0) {
                $storedBookingTotal =
                    max(
                        0,
                        (float)(
                            $booking['total_amount']
                            ?? 0
                        )
                    );

                /*
                 * The accepted quotation repairs only legacy converted Bookings.
                 * Once an approved Amendment or posted Billing adjustment exists,
                 * bookings.total_amount is the revised commercial authority and
                 * must never be reset back to the original accepted quote.
                 */
                $hasRevisedCommercial = false;

                if (
                    function_exists('tsAmendTableExists')
                    && tsAmendTableExists($pdo, 'booking_amendments')
                ) {
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*)
                        FROM booking_amendments
                        WHERE booking_id = ?
                          AND status = 'approved'
                    ");
                    $stmt->execute([$bookingId]);
                    $hasRevisedCommercial =
                        (int)$stmt->fetchColumn() > 0;
                }

                if (
                    !$hasRevisedCommercial
                    && function_exists('tsBillReady')
                    && tsBillReady($pdo)
                ) {
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*)
                        FROM booking_billing_adjustments
                        WHERE booking_id = ?
                          AND status = 'posted'
                    ");
                    $stmt->execute([$bookingId]);
                    $hasRevisedCommercial =
                        (int)$stmt->fetchColumn() > 0;
                }

                if (
                    !$hasRevisedCommercial
                    && abs(
                        $storedBookingTotal
                        - $acceptedFinalPrice
                    ) > 0.009
                ) {
                    $stmt = $pdo->prepare("
                        UPDATE bookings
                        SET
                            total_amount = ?,
                            currency = ?,
                            updated_at = NOW()
                        WHERE id = ?
                    ");
                    $stmt->execute([
                        $acceptedFinalPrice,
                        $acceptedCurrency !== ''
                            ? $acceptedCurrency
                            : 'INR',
                        $bookingId
                    ]);

                    $storedBookingTotal =
                        $acceptedFinalPrice;
                }

                $booking['total_amount'] =
                    $hasRevisedCommercial
                        ? $storedBookingTotal
                        : $acceptedFinalPrice;

                if ($acceptedCurrency !== '') {
                    $booking['currency'] =
                        $acceptedCurrency;
                }

                if (
                    array_key_exists(
                        'discount_amount',
                        $bookingQuotationSnapshot
                    )
                ) {
                    $booking['discount_amount'] =
                        max(
                            0,
                            (float)$bookingQuotationSnapshot['discount_amount']
                        );
                }

                /*
                 * Finance variables were initially calculated before the CRM
                 * snapshot was loaded. Recalculate them from accepted quote.
                 */
                $totalAmount =
                    max(
                        0,
                        (float)$booking['total_amount']
                    );

                $paidAmount =
                    max(
                        0,
                        (float)(
                            $booking['paid_amount']
                            ?? 0
                        )
                    );

                $balanceAmount =
                    max(
                        0,
                        $totalAmount
                        - $paidAmount
                    );

                $paidPercent =
                    $totalAmount > 0
                        ? min(
                            100,
                            max(
                                0,
                                (
                                    $paidAmount
                                    / $totalAmount
                                )
                                * 100
                            )
                        )
                        : 0;
            }

            if (
                trim(
                    (string)(
                        $bookingQuotationSnapshot['package_title']
                        ?? ''
                    )
                ) !== ''
            ) {
                $booking['package_title'] =
                    (string)$bookingQuotationSnapshot['package_title'];
            }

            $quotationSnapshot =
                json_decode(
                    (string)(
                        $bookingQuotationSnapshot['quotation_snapshot_json']
                        ?? ''
                    ),
                    true
                );

            if (is_array($quotationSnapshot)) {
                if (!empty($quotationSnapshot['main_image'])) {
                    $booking['package_image'] =
                        $quotationSnapshot['main_image'];
                }

                if (!empty($quotationSnapshot['duration_days'])) {
                    $booking['duration_days'] =
                        (int)$quotationSnapshot['duration_days'];
                }

                if (
                    array_key_exists(
                        'duration_nights',
                        $quotationSnapshot
                    )
                ) {
                    $booking['duration_nights'] =
                        (int)$quotationSnapshot['duration_nights'];
                }
            }
        }
    } catch (Throwable $e) {
        error_log(
            'Booking CRM bridge load error: '
            . $e->getMessage()
        );
    }
}


if (
    function_exists('tsOpsReady')
    && tsOpsReady($pdo)
) {
    try {
        $operationsChecklist =
            tsOpsChecklist(
                $pdo,
                $bookingId
            );

        $operationsReadiness =
            tsOpsReadiness(
                $pdo,
                $bookingId
            );

        $bookingVoucherVersions =
            tsOpsVoucherVersions(
                $pdo,
                $bookingId
            );

    } catch (Throwable $e) {
        error_log(
            'Operations readiness load: '
            . $e->getMessage()
        );
    }
}


if (
    function_exists('tsFinReady')
    && tsFinReady($pdo)
) {
    try {
        $financeSummary =
            tsFinSummary(
                $pdo,
                $bookingId
            );

        $financeSuppliers =
            tsFinBookingSuppliers(
                $pdo,
                $bookingId
            );

        $financeBookingServices =
            tsFinBookingServices(
                $pdo,
                $bookingId
            );

        $financeInvoices =
            tsFinInvoices(
                $pdo,
                $bookingId
            );

        foreach ($financeInvoices as $financeInvoice) {
            $financeInvoiceItems[
                (int)$financeInvoice['id']
            ] =
                tsFinInvoiceItems(
                    $pdo,
                    (int)$financeInvoice['id']
                );
        }

        $financeSupplierPayments =
            tsFinSupplierPayments(
                $pdo,
                $bookingId
            );

        $financeDirectCosts =
            tsFinDirectCosts(
                $pdo,
                $bookingId
            );

        $financeClosure =
            tsFinClosure(
                $pdo,
                $bookingId
            );

        $financeClosureReadiness =
            tsFinClosureReadiness(
                $pdo,
                $bookingId
            );

    } catch (Throwable $e) {
        error_log(
            'Booking Finance load: '
            . $e->getMessage()
        );
    }
}


if (
    function_exists('tsBillReady')
    && tsBillReady($pdo)
) {
    try {
        tsBillSyncSuccessfulPayments($pdo, $bookingId, $adminId);
        tsBillSyncRefundObligations($pdo, $bookingId, $adminId);

        $billingActiveSchedule = tsBillActiveSchedule($pdo, $bookingId);
        $billingInstallments = $billingActiveSchedule
            ? tsBillInstallments($pdo, $bookingId, (int)$billingActiveSchedule['id'])
            : [];
        $billingSchedules = tsBillAllSchedules($pdo, $bookingId);
        $billingInvoices = tsBillInvoices($pdo, $bookingId);
        $billingLatestFinalInvoice = tsBillLatestFinalInvoice($pdo, $bookingId);
        $billingReceipts = tsBillReceipts($pdo, $bookingId);
        $billingRefunds = tsBillRefunds($pdo, $bookingId);
        $billingAdjustments = tsBillAdjustments($pdo, $bookingId);
        $billingReminders = tsBillReminders($pdo, $bookingId);
        $billingPendingRefundTotal = tsBillPendingRefundTotal($pdo, $bookingId);
    } catch (Throwable $e) {
        error_log('Customer Billing load error: ' . $e->getMessage());
    }
}


if (function_exists('tsAmendReady') && tsAmendReady($pdo)) {
    try {
        $bookingAmendmentBaseline = tsAmendCurrentBaseline($pdo, $bookingId);
        $bookingAmendmentPending = tsAmendPending($pdo, $bookingId);
        $bookingAmendmentHistory = tsAmendHistory($pdo, $bookingId);
    } catch (Throwable $e) {
        error_log('Booking Amendment load: ' . $e->getMessage());
    }
}


if (
    function_exists('tsExecReady')
    && tsExecReady($pdo)
) {
    try {
        $executionState =
            tsExecEnsureState(
                $pdo,
                $bookingId
            );

        $executionContacts =
            tsExecContacts(
                $pdo,
                $bookingId,
                false
            );

        $executionUpdates =
            tsExecUpdates(
                $pdo,
                $bookingId,
                false
            );

        $executionIncidents =
            tsExecIncidents(
                $pdo,
                $bookingId,
                false
            );

        $executionChecks =
            tsExecChecks(
                $pdo,
                $bookingId
            );

        $executionCompletionReadiness =
            tsExecCompletionReadiness(
                $pdo,
                $bookingId
            );

    } catch (Throwable $e) {
        error_log(
            'Travel Execution load: '
            . $e->getMessage()
        );
    }
}


if (
    function_exists('tsDocReady')
    && tsDocReady($pdo)
) {
    try {
        $bookingDocumentSummary =
            tsDocSummary(
                $pdo,
                $bookingId
            );

        $bookingFinalDocumentPack =
            $bookingDocumentSummary[
                'latest_final_pack'
            ]
            ?? null;

    } catch (Throwable $e) {
        error_log(
            'Admin Booking Document Center summary: '
            . $e->getMessage()
        );
    }
}


if (
    function_exists('tsCommReady')
    && tsCommReady($pdo)
) {
    try {
        $bookingCommunicationSummary =
            tsCommSummary(
                $pdo,
                $bookingId
            );
    } catch (Throwable $e) {
        error_log(
            'Admin Booking Communication Center summary: '
            . $e->getMessage()
        );
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?= e($booking['booking_number']); ?> | TRAVSCOPE Admin</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

:root{
    --navy:#07192d;
    --navy2:#0c2947;
    --blue:#0b74ff;
    --cyan:#00b8ff;
    --green:#07885f;
    --red:#d94355;
    --orange:#df8617;
    --bg:#f4f7fb;
    --white:#fff;
    --text:#172235;
    --muted:#7e8a9b;
    --border:#e1e8ef;
    --shadow:0 14px 40px rgba(7,25,45,.07);
}

*{box-sizing:border-box;margin:0;padding:0}

body{
    background:var(--bg);
    color:var(--text);
    font-family:'DM Sans',sans-serif;
}

a{color:inherit;text-decoration:none}
button{font:inherit}

/* HEADER */

.header{
    height:70px;
    padding:0 28px;
    position:sticky;
    top:0;
    z-index:1000;
    display:flex;
    align-items:center;
    justify-content:space-between;
    background:#fff;
    border-bottom:1px solid var(--border);
}

.logo{
    display:flex;
    align-items:center;
    gap:9px;
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:18px;
    font-weight:800;
}

.logo-icon{
    width:38px;
    height:38px;
    border-radius:11px;
    display:grid;
    place-items:center;
    color:#fff;
    background:linear-gradient(135deg,var(--blue),var(--cyan));
}

.logo span{color:var(--blue)}

.admin{
    display:flex;
    align-items:center;
    gap:9px;
}

.avatar{
    width:38px;
    height:38px;
    border-radius:10px;
    display:grid;
    place-items:center;
    background:#edf5ff;
    color:var(--blue);
    font-weight:800;
}

.admin strong{display:block;font-size:10px}
.admin small{display:block;margin-top:2px;color:#929dab;font-size:8px}

/* LAYOUT */

.layout{
    min-height:calc(100vh - 70px);
    display:grid;
    grid-template-columns:230px minmax(0,1fr);
}

.sidebar{
    padding:20px 13px;
    background:var(--navy);
    color:#fff;
}

.menu-title{
    padding:0 11px;
    margin:13px 0 7px;
    color:#71869c;
    font-size:7px;
    font-weight:800;
    text-transform:uppercase;
    letter-spacing:1px;
}

.sidebar a{
    min-height:43px;
    margin-bottom:4px;
    padding:0 12px;
    border-radius:9px;
    display:flex;
    align-items:center;
    gap:10px;
    color:#b6c5d4;
    font-size:9px;
    font-weight:700;
}

.sidebar a:hover,
.sidebar a.active{
    color:#fff;
    background:rgba(255,255,255,.1);
}

.sidebar a.active{
    background:linear-gradient(135deg,var(--blue),#0866dd);
}

.sidebar i{width:18px;text-align:center}

.main{
    min-width:0;
    padding:27px;
}

/* PAGE HEAD */

.page-head{
    margin-bottom:20px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:15px;
}

.breadcrumb{
    margin-bottom:5px;
    display:flex;
    align-items:center;
    gap:6px;
    color:#8c98a8;
    font-size:8px;
}

.breadcrumb a{color:var(--blue);font-weight:700}

.page-head h1{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:25px;
}

.page-head p{
    margin-top:5px;
    color:var(--muted);
    font-size:9px;
}

.head-actions{
    display:flex;
    gap:7px;
    flex-wrap:wrap;
}

.head-btn{
    min-height:40px;
    padding:0 13px;
    border:1px solid var(--border);
    border-radius:8px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:6px;
    background:#fff;
    color:#5f6d80;
    font-size:8px;
    font-weight:800;
}

.head-btn.primary{
    border-color:var(--blue);
    background:var(--blue);
    color:#fff;
}

/* ALERT */

.alert{
    margin-bottom:17px;
    padding:13px 15px;
    border-radius:10px;
    display:flex;
    align-items:center;
    gap:8px;
    font-size:9px;
}

.alert-success{
    border:1px solid #bce7d5;
    background:#eaf9f3;
    color:#08734f;
}

.alert-error{
    border:1px solid #f0c5cc;
    background:#fff0f2;
    color:#b43748;
}

/* HERO */

.booking-hero{
    margin-bottom:17px;
    border:1px solid var(--border);
    border-radius:16px;
    overflow:hidden;
    display:grid;
    grid-template-columns:160px 1fr auto;
    background:#fff;
    box-shadow:var(--shadow);
}

.package-photo{
    min-height:150px;
    background:linear-gradient(135deg,#dcecff,#eef6ff);
    overflow:hidden;
    display:grid;
    place-items:center;
    color:var(--blue);
    font-size:34px;
}

.package-photo img{
    width:100%;
    height:100%;
    object-fit:cover;
}

.hero-content{
    padding:19px;
}

.hero-kicker{
    display:flex;
    align-items:center;
    gap:6px;
    color:#8794a4;
    font-size:7px;
    font-weight:800;
    text-transform:uppercase;
    letter-spacing:.5px;
}

.hero-content h2{
    margin-top:6px;
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:18px;
}

.hero-meta{
    margin-top:10px;
    display:flex;
    gap:8px;
    flex-wrap:wrap;
}

.meta-pill{
    padding:6px 9px;
    border-radius:20px;
    background:#f3f6fa;
    color:#687689;
    font-size:7px;
    font-weight:700;
}

.hero-status{
    min-width:190px;
    padding:18px;
    border-left:1px solid var(--border);
    display:flex;
    flex-direction:column;
    justify-content:center;
    gap:8px;
}

.badge{
    width:max-content;
    padding:6px 9px;
    border-radius:20px;
    font-size:7px;
    font-weight:800;
    text-transform:capitalize;
}

.badge-success{background:#e8f8f1;color:var(--green)}
.badge-warning{background:#fff6e7;color:#bf7415}
.badge-danger{background:#fff0f2;color:var(--red)}
.badge-blue{background:#edf5ff;color:var(--blue)}

.hero-status small{
    color:#8b97a6;
    font-size:7px;
    line-height:1.6;
}

/* GRID / CARD */

.content-grid{
    display:grid;
    grid-template-columns:minmax(0,1.6fr) minmax(300px,.8fr);
    gap:17px;
    align-items:start;
}

.card{
    margin-bottom:17px;
    border:1px solid var(--border);
    border-radius:15px;
    overflow:hidden;
    background:#fff;
    box-shadow:var(--shadow);
}

.card-head{
    min-height:60px;
    padding:0 18px;
    border-bottom:1px solid var(--border);
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
}

.card-head h3{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:12px;
}

.card-head p{
    margin-top:3px;
    color:#929dab;
    font-size:7px;
}

.card-body{padding:18px}

.detail-grid{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:15px;
}

.detail{
    min-width:0;
    padding-bottom:12px;
    border-bottom:1px dashed #e7ebef;
}

.detail label{
    display:block;
    margin-bottom:5px;
    color:#98a3b0;
    font-size:6px;
    font-weight:800;
    text-transform:uppercase;
    letter-spacing:.5px;
}

.detail strong,
.detail a{
    display:block;
    color:#3d4b5f;
    font-size:9px;
    font-weight:700;
    word-break:break-word;
}

.detail a{color:var(--blue)}

.icon-label{
    display:flex;
    align-items:center;
    gap:6px;
}

.icon-label i{
    width:15px;
    color:#8ba1b8;
}

/* CUSTOMER */

.customer-box{
    display:flex;
    align-items:center;
    gap:12px;
    padding:13px;
    border-radius:11px;
    background:#f7f9fc;
}

.customer-photo{
    width:48px;
    height:48px;
    flex:none;
    overflow:hidden;
    border-radius:13px;
    display:grid;
    place-items:center;
    background:#eaf3ff;
    color:var(--blue);
    font-family:'Manrope',sans-serif;
    font-size:16px;
    font-weight:800;
}

.customer-photo img{
    width:100%;
    height:100%;
    object-fit:cover;
}

.customer-box h4{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:11px;
}

.customer-box p{
    margin-top:3px;
    color:#8390a0;
    font-size:7px;
}

.customer-links{
    margin-left:auto;
    display:flex;
    gap:6px;
}

.icon-btn{
    width:34px;
    height:34px;
    border-radius:8px;
    display:grid;
    place-items:center;
    background:#fff;
    border:1px solid var(--border);
    color:var(--blue);
}

/* FINANCE */

.money-grid{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:8px;
}

.money-box{
    padding:13px;
    border-radius:10px;
    background:#f7f9fc;
    text-align:center;
}

.money-box span{
    display:block;
    color:#8d99a7;
    font-size:6px;
    font-weight:800;
    text-transform:uppercase;
}

.money-box strong{
    display:block;
    margin-top:5px;
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:13px;
}

.money-box.balance strong{color:var(--orange)}

.progress{
    height:8px;
    margin-top:14px;
    overflow:hidden;
    border-radius:20px;
    background:#e7ebef;
}

.progress > div{
    height:100%;
    border-radius:20px;
    background:linear-gradient(90deg,var(--blue),var(--cyan));
}

.progress-text{
    margin-top:6px;
    display:flex;
    justify-content:space-between;
    color:#8c98a6;
    font-size:7px;
}

/* REQUEST */

.request-box{
    padding:14px;
    border-radius:10px;
    background:#fff9ed;
    border:1px solid #f4e0ad;
    color:#6f6042;
    font-size:9px;
    line-height:1.75;
    white-space:pre-wrap;
}

/* PAYMENTS */

.payment-item{
    padding:14px 0;
    border-bottom:1px solid #edf0f3;
}

.payment-item:first-child{padding-top:0}
.payment-item:last-child{padding-bottom:0;border-bottom:0}

.payment-top{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:10px;
}

.payment-title{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:10px;
    font-weight:800;
}

.payment-meta{
    margin-top:5px;
    display:flex;
    gap:6px;
    flex-wrap:wrap;
    color:#8995a4;
    font-size:7px;
}

.payment-amount{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:12px;
    font-weight:800;
    text-align:right;
}

.payment-id{
    margin-top:8px;
    padding:8px 10px;
    border-radius:7px;
    background:#f7f9fc;
    color:#647386;
    font-size:7px;
    word-break:break-all;
}

/* STATUS ACTION */

.status-actions{
    display:flex;
    gap:7px;
    flex-wrap:wrap;
}

.action-btn{
    min-height:38px;
    padding:0 11px;
    border:0;
    border-radius:8px;
    cursor:pointer;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:6px;
    font-size:8px;
    font-weight:800;
}

.confirm{background:#e9f9f2;color:var(--green)}
.complete{background:#edf5ff;color:var(--blue)}
.cancel{background:#fff0f2;color:var(--red)}

.final-note{
    padding:12px;
    border-radius:9px;
    background:#f6f8fa;
    color:#778496;
    font-size:8px;
    line-height:1.7;
}

/* QUICK LINKS */

.quick-links{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:8px;
}

.quick-link{
    min-height:42px;
    padding:0 10px;
    border:1px solid var(--border);
    border-radius:8px;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:6px;
    background:#fff;
    color:#607084;
    font-size:7px;
    font-weight:800;
}

.quick-link:hover{
    border-color:#b8d6fb;
    color:var(--blue);
}

/* RESPONSIVE */

@media(max-width:1000px){
    .layout{grid-template-columns:1fr}
    .sidebar{display:none}
    .booking-hero{grid-template-columns:130px 1fr}
    .hero-status{
        grid-column:1/-1;
        border-left:0;
        border-top:1px solid var(--border);
        flex-direction:row;
        align-items:center;
        justify-content:flex-start;
    }
    .content-grid{grid-template-columns:1fr}
}

@media(max-width:650px){
    .header{padding:0 13px}
    .admin > div:last-child{display:none}
    .main{padding:13px}
    .page-head{
        align-items:flex-start;
        flex-direction:column;
    }
    .booking-hero{grid-template-columns:1fr}
    .package-photo{height:180px}
    .hero-status{display:block}
    .hero-status .badge{margin-bottom:7px}
    .detail-grid{grid-template-columns:1fr}
    .money-grid{grid-template-columns:1fr}
    .customer-links{display:none}
    .quick-links{grid-template-columns:1fr}
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.layout{
    display:block!important;
    grid-template-columns:none!important;
    min-height:100vh!important;
}
.main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
    padding:16px 18px 20px!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}


.fin-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px;margin-bottom:13px}
.fin-box{padding:11px;border:1px solid #e2e8f0;border-radius:12px;background:#f8fafc}
.fin-box span{display:block;color:#64748b;font-size:8px;font-weight:900;text-transform:uppercase}
.fin-box strong{display:block;margin-top:4px;color:#0f172a;font-size:14px}
.fin-box.good{background:#ecfdf5;border-color:#a7f3d0}.fin-box.good strong{color:#047857}
.fin-box.bad{background:#fef2f2;border-color:#fecaca}.fin-box.bad strong{color:#b91c1c}
.fin-box.warn{background:#fff7ed;border-color:#fed7aa}.fin-box.warn strong{color:#c2410c}
.fin-compare{overflow:auto;border:1px solid #e2e8f0;border-radius:12px;margin-top:10px}
.fin-compare table{min-width:700px}
.fin-compare th,.fin-compare td{padding:8px 9px;font-size:10px}
.fin-actions{display:grid;grid-template-columns:1.35fr .9fr .9fr;gap:10px;margin-top:13px}
.fin-form{border:1px dashed #cbd5e1;border-radius:12px;background:#fbfdff}
.fin-form summary{cursor:pointer;padding:11px;font-size:10px;font-weight:900;color:#334155;list-style:none}
.fin-form summary::-webkit-details-marker{display:none}
.fin-form .inside{padding:0 11px 11px}
.fin-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}
.fin-grid .full{grid-column:1/-1}
.fin-line{display:grid;grid-template-columns:1.15fr 1.1fr 80px 110px;gap:6px;margin-bottom:6px}
.fin-line input,.fin-line select,.fin-grid input,.fin-grid select,.fin-grid textarea{width:100%;min-height:34px;padding:7px 8px;border:1px solid #cbd5e1;border-radius:8px;font-size:10px}
.fin-grid textarea{min-height:62px}
.fin-list{display:grid;gap:8px;margin-top:13px}
.fin-record{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}
.fin-record-top{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}
.fin-record strong{font-size:11px;color:#334155}
.fin-record small{display:block;margin-top:4px;color:#64748b;font-size:9px;line-height:1.45}
.fin-pill{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:8px;font-weight:900}
.fin-pill.approved,.fin-pill.paid,.fin-pill.posted{background:#dcfce7;color:#166534}
.fin-pill.received{background:#fff7ed;color:#c2410c}
.fin-pill.void{background:#f1f5f9;color:#64748b}
.fin-close{margin-top:14px;padding:12px;border:1px solid #dbeafe;border-radius:13px;background:#eff6ff}
.fin-close-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;margin-top:9px}
.fin-check{padding:8px;border-radius:9px;background:#fff;border:1px solid #dbe3ee;font-size:9px;font-weight:800}
.fin-check.ok{background:#ecfdf5;border-color:#a7f3d0;color:#047857}.fin-check.no{background:#fff7ed;border-color:#fed7aa;color:#c2410c}
@media(max-width:1050px){.fin-summary{grid-template-columns:1fr 1fr}.fin-actions{grid-template-columns:1fr}.fin-close-grid{grid-template-columns:1fr 1fr}}
@media(max-width:650px){.fin-summary{grid-template-columns:1fr}.fin-grid{grid-template-columns:1fr}.fin-grid .full{grid-column:auto}.fin-line{grid-template-columns:1fr 1fr}.fin-close-grid{grid-template-columns:1fr}}


.amend-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-bottom:12px}
.amend-kpi{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#f8fafc}
.amend-kpi span{display:block;color:#64748b;font-size:8px;font-weight:900;text-transform:uppercase}
.amend-kpi strong{display:block;margin-top:4px;color:#0f172a;font-size:13px}
.amend-pending{border:1px solid #fed7aa;border-radius:13px;background:#fffaf3;padding:12px;margin-top:10px}
.amend-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}
.amend-grid .full{grid-column:1/-1}
.amend-grid input,.amend-grid select,.amend-grid textarea{width:100%;min-height:34px;padding:7px 8px;border:1px solid #cbd5e1;border-radius:8px;font-size:10px;background:#fff}
.amend-grid textarea{min-height:64px}
.amend-history{display:grid;gap:8px;margin-top:12px}
.amend-row{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}
.amend-row-top{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}
.amend-pill{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:8px;font-weight:900}
.amend-pill.pending{background:#fff7ed;color:#c2410c}.amend-pill.approved{background:#dcfce7;color:#166534}.amend-pill.rejected{background:#f1f5f9;color:#64748b}
@media(max-width:950px){.amend-summary{grid-template-columns:1fr 1fr}.amend-grid{grid-template-columns:1fr 1fr}}
@media(max-width:620px){.amend-summary,.amend-grid{grid-template-columns:1fr}.amend-grid .full{grid-column:auto}}


.exec-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-bottom:12px}
.exec-kpi{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#f8fafc}.exec-kpi span{display:block;color:#64748b;font-size:8px;font-weight:900;text-transform:uppercase}.exec-kpi strong{display:block;margin-top:4px;color:#0f172a;font-size:12px}
.exec-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.exec-panel{border:1px solid #e2e8f0;border-radius:12px;background:#fbfdff;padding:11px}.exec-panel h4{margin:0 0 8px;font-size:11px;color:#334155}
.exec-form{display:grid;grid-template-columns:1fr 1fr;gap:6px}.exec-form .full{grid-column:1/-1}.exec-form input,.exec-form select,.exec-form textarea{width:100%;min-height:34px;padding:7px 8px;border:1px solid #cbd5e1;border-radius:8px;font-size:10px;background:#fff}.exec-form textarea{min-height:60px}
.exec-list{display:grid;gap:7px}.exec-item{padding:9px;border:1px solid #e2e8f0;border-radius:10px;background:#fff}.exec-item-top{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.exec-item strong{font-size:10px;color:#334155}.exec-item small{display:block;margin-top:3px;color:#64748b;font-size:8.5px;line-height:1.45}
.exec-pill{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:8px;font-weight:900}.exec-pill.pre_departure{background:#eff6ff;color:#1d4ed8}.exec-pill.in_progress{background:#fff7ed;color:#c2410c}.exec-pill.completed,.exec-pill.resolved{background:#dcfce7;color:#166534}.exec-pill.open,.exec-pill.critical,.exec-pill.high{background:#fef2f2;color:#b91c1c}.exec-pill.monitoring,.exec-pill.medium{background:#fff7ed;color:#c2410c}.exec-pill.low{background:#eff6ff;color:#1d4ed8}
.exec-check{display:grid;grid-template-columns:26px minmax(0,1fr) minmax(190px,.7fr);gap:7px;align-items:center;padding:8px;border:1px solid #e2e8f0;border-radius:9px;background:#fff}.exec-check input[type=checkbox]{width:17px;height:17px}.exec-check input[type=text]{width:100%;min-height:32px;padding:6px 7px;border:1px solid #cbd5e1;border-radius:7px;font-size:9px}
@media(max-width:900px){.exec-summary{grid-template-columns:1fr 1fr}.exec-grid{grid-template-columns:1fr}}
@media(max-width:620px){.exec-summary{grid-template-columns:1fr}.exec-form{grid-template-columns:1fr}.exec-form .full{grid-column:auto}.exec-check{grid-template-columns:25px 1fr}.exec-check input[type=text]{grid-column:1/-1}}


.bill-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-bottom:12px}
.bill-kpi{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#f8fafc}
.bill-kpi span{display:block;color:#64748b;font-size:8px;font-weight:900;text-transform:uppercase}.bill-kpi strong{display:block;margin-top:4px;color:#0f172a;font-size:13px}
.bill-kpi.good{background:#ecfdf5;border-color:#a7f3d0}.bill-kpi.good strong{color:#047857}.bill-kpi.warn{background:#fff7ed;border-color:#fed7aa}.bill-kpi.warn strong{color:#c2410c}
.bill-grid{display:grid;grid-template-columns:1.2fr .8fr;gap:10px}.bill-panel{border:1px solid #e2e8f0;border-radius:12px;background:#fbfdff;padding:11px}
.bill-installment{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;padding:9px;border:1px solid #e2e8f0;border-radius:9px;background:#fff;margin-top:6px}.bill-installment strong{font-size:10px}.bill-installment small{display:block;margin-top:3px;color:#64748b;font-size:8px}
.bill-pill{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:8px;font-weight:900}.bill-pill.paid{background:#dcfce7;color:#166534}.bill-pill.pending,.bill-pill.partially_paid{background:#fff7ed;color:#c2410c}.bill-pill.cancelled,.bill-pill.void{background:#f1f5f9;color:#64748b}.bill-pill.final,.bill-pill.posted{background:#dbeafe;color:#1d4ed8}.bill-pill.draft{background:#f5f3ff;color:#6d28d9}
.bill-actions{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:10px}.bill-form{border:1px dashed #cbd5e1;border-radius:10px;background:#fff}.bill-form summary{cursor:pointer;padding:9px 10px;font-size:9px;font-weight:900;color:#334155;list-style:none}.bill-form .inside{padding:0 10px 10px}.bill-form input,.bill-form select,.bill-form textarea{width:100%;min-height:33px;padding:7px 8px;border:1px solid #cbd5e1;border-radius:8px;font-size:9px}.bill-form textarea{min-height:55px}.bill-row{display:grid;grid-template-columns:1fr 130px 120px;gap:6px;margin-bottom:6px}.bill-history{display:grid;gap:7px;margin-top:10px}.bill-record{padding:9px;border:1px solid #e2e8f0;border-radius:9px;background:#fff}.bill-record-top{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}
@media(max-width:1050px){.bill-summary{grid-template-columns:1fr 1fr}.bill-grid{grid-template-columns:1fr}.bill-actions{grid-template-columns:1fr}}@media(max-width:650px){.bill-summary{grid-template-columns:1fr}.bill-row{grid-template-columns:1fr}}


.payment-collect-card{border:1px solid #c7d2fe!important;background:linear-gradient(145deg,#f8fbff,#f5f3ff)!important}.payment-collect-head{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;margin-bottom:10px}.payment-collect-badge{padding:5px 8px;border-radius:999px;background:#e0e7ff;color:#4338ca;font-size:8px;font-weight:900}.pay-choice-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.pay-choice{position:relative;display:block;padding:10px;border:1px solid #dbe4f0;border-radius:11px;background:#fff;cursor:pointer}.pay-choice input{position:absolute;opacity:0;pointer-events:none}.pay-choice strong{display:block;font-size:10px;color:#0f172a}.pay-choice small{display:block;margin-top:3px;color:#64748b;font-size:8px;line-height:1.4}.pay-choice:has(input:checked){border-color:#2563eb;background:#eff6ff;box-shadow:0 0 0 2px rgba(37,99,235,.09)}.pay-choice.advance:has(input:checked){border-color:#7c3aed;background:#f5f3ff}.pay-choice.half:has(input:checked){border-color:#f59e0b;background:#fffbeb}.pay-choice.full:has(input:checked){border-color:#059669;background:#ecfdf5}.pay-choice.custom:has(input:checked){border-color:#db2777;background:#fdf2f8}.pay-control-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:8px}.pay-control{padding:8px;border:1px solid #dbe4f0;border-radius:10px;background:rgba(255,255,255,.86)}.pay-control label{display:block;margin-bottom:4px;color:#475569;font-size:8px;font-weight:900}.pay-control input,.pay-control select{width:100%;min-height:32px;border:1px solid #cbd5e1;border-radius:8px;padding:6px 8px;background:#fff}.pay-preview{margin-top:8px;padding:10px;border-radius:10px;background:#0f172a;color:#fff}.pay-preview span{display:block;font-size:8px;color:#cbd5e1}.pay-preview strong{display:block;margin-top:3px;font-size:16px}.pay-action-row{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:8px}.pay-send{border:0;border-radius:9px;padding:9px 7px;font-size:8px;font-weight:900;cursor:pointer}.pay-send.generate{background:#2563eb;color:#fff}.pay-send.email{background:#0ea5e9;color:#fff}.pay-send.wa{background:#16a34a;color:#fff}.generated-pay-link{margin-top:10px;padding:10px;border:1px solid #a7f3d0;border-radius:11px;background:#ecfdf5}.generated-pay-link strong{display:block;color:#047857;font-size:10px}.generated-link-row{display:flex;gap:6px;margin-top:6px}.generated-link-row input{flex:1;min-width:0;border:1px solid #86efac;border-radius:8px;padding:7px;background:#fff;font-size:8px}.generated-link-row button{border:0;border-radius:8px;background:#047857;color:#fff;padding:7px 10px;font-size:8px;font-weight:900;cursor:pointer}@media(max-width:700px){.pay-choice-grid,.pay-control-grid{grid-template-columns:1fr}.pay-action-row{grid-template-columns:1fr}.generated-link-row{flex-direction:column}}

/* =========================================================
   V24.79 — INTERNATIONAL BOOKING CONTROL CENTER
   Compact operational layout; backend/business logic unchanged.
========================================================= */
.main{padding:18px 20px 28px}
.page-head{margin-bottom:12px;align-items:flex-start}
.page-head h1{font-size:22px;letter-spacing:-.35px}
.page-head p{margin-top:3px;font-size:8px}
.breadcrumb{margin-bottom:3px}
.head-actions{gap:5px;justify-content:flex-end}
.head-btn{min-height:34px;padding:0 10px;border-radius:8px;font-size:7.5px}

.booking-hero{
    margin-bottom:12px;
    grid-template-columns:112px minmax(0,1fr) 185px;
    border-radius:13px;
    box-shadow:0 8px 24px rgba(15,23,42,.055);
}
.package-photo{min-height:104px;font-size:0;position:relative;background:linear-gradient(135deg,#e7f0ff,#f8fbff)}
.package-photo img{display:block;width:100%;height:104px;object-fit:cover;font-size:0;color:transparent}
.package-photo-fallback{display:none;width:100%;height:104px;place-items:center;color:#2563eb;font-size:25px;background:linear-gradient(135deg,#dbeafe,#eff6ff)}
.package-photo-fallback.is-visible{display:grid}
.hero-content{padding:12px 15px}
.hero-kicker{font-size:6.5px}
.hero-content h2{margin-top:4px;font-size:16px;line-height:1.22}
.hero-meta{margin-top:7px;gap:5px}
.meta-pill{padding:4px 7px;font-size:6.7px;background:#f6f8fb;border:1px solid #edf1f5}
.hero-status{min-width:0;padding:11px 13px;display:grid;grid-template-columns:1fr 1fr;align-content:center;gap:6px 5px}
.hero-status .badge{padding:5px 7px;font-size:6.5px}
.hero-status small{grid-column:1/-1;font-size:6.3px;line-height:1.45}

.content-grid{grid-template-columns:minmax(0,1.72fr) minmax(300px,.78fr);gap:12px}
.card{margin-bottom:12px;border-radius:12px;box-shadow:0 7px 22px rgba(15,23,42,.045)}
.card-head{min-height:48px;padding:0 14px}
.card-head h3{font-size:11.5px}
.card-head p{margin-top:2px;font-size:6.7px}
.card-body{padding:13px 14px}
.customer-box{padding:10px;border-radius:10px}
.customer-photo{width:40px;height:40px;border-radius:10px;font-size:14px}
.customer-box h4{font-size:10.5px}
.customer-box p{font-size:6.7px}
.icon-btn{width:31px;height:31px}
.detail-grid{gap:9px 14px!important}
.detail{padding-bottom:9px}
.detail label{margin-bottom:3px;font-size:5.8px}
.detail strong,.detail a{font-size:8.5px}

.money-grid{gap:6px}
.money-box{padding:9px 6px;border:1px solid #eef2f7}
.money-box span{font-size:5.7px}
.money-box strong{margin-top:3px;font-size:11.5px}
.progress{height:6px;margin-top:10px}
.progress-text{margin-top:5px;font-size:6.5px}
.payment-item{padding:10px 0}
.payment-title{font-size:9.5px}
.payment-amount{font-size:11px}
.payment-id{margin-top:6px;padding:6px 8px}

#verified-payment-receipts .card-head{min-height:50px!important;background:linear-gradient(110deg,#f0fdf4,#eff6ff)!important}
#verified-payment-receipts .card-body{padding:11px 12px!important}
.receipt-preview-details{margin-top:8px;border:1px solid #dbe3ee;border-radius:10px;background:#f8fafc;overflow:hidden}
.receipt-preview-details summary{list-style:none;cursor:pointer;min-height:38px;padding:0 11px;display:flex;align-items:center;justify-content:space-between;gap:10px;color:#334155;font-size:8.5px;font-weight:800;background:#fff}
.receipt-preview-details summary::-webkit-details-marker{display:none}
.receipt-preview-details summary i{margin-right:5px;color:#059669}
.receipt-preview-hint{padding:4px 7px;border-radius:999px;background:#eff6ff;color:#2563eb;font-size:7px}
.receipt-preview-details[open] .receipt-preview-hint{background:#ecfdf5;color:#047857}
.receipt-preview-shell{padding:8px;border-top:1px solid #e2e8f0;background:#f8fafc}
#tsReceiptPdfFrame{display:block;width:100%;height:300px;border:0;border-radius:8px;background:#fff}
.ts-receipt-choice{padding:7px 8px!important;font-size:8.5px!important}

/* Keep long operational sections compact without hiding functionality. */
.fin-summary,.amend-summary,.exec-summary,.bill-summary{gap:6px;margin-bottom:9px}
.fin-kpi,.amend-kpi,.exec-kpi,.bill-kpi{padding:8px}
.fin-panel,.exec-panel,.bill-panel{padding:9px}

@media(max-width:1180px){
    .booking-hero{grid-template-columns:96px minmax(0,1fr) 175px}
    .package-photo,.package-photo img,.package-photo-fallback{height:96px;min-height:96px}
    .content-grid{grid-template-columns:minmax(0,1.55fr) minmax(285px,.8fr)}
}
@media(max-width:980px){
    .main{padding:15px}
    .booking-hero{grid-template-columns:92px minmax(0,1fr)}
    .hero-status{grid-column:1/-1;border-left:0;border-top:1px solid var(--border);grid-template-columns:auto auto 1fr;align-items:center}
    .hero-status small{grid-column:auto;text-align:right}
    .content-grid{grid-template-columns:1fr}
    #tsReceiptPdfFrame{height:340px}
}
@media(max-width:650px){
    .page-head{display:block}
    .head-actions{margin-top:10px;justify-content:flex-start}
    .booking-hero{grid-template-columns:1fr}
    .package-photo,.package-photo img,.package-photo-fallback{height:150px;min-height:150px}
    .hero-status{grid-template-columns:1fr 1fr}
    .hero-status small{grid-column:1/-1;text-align:left}
    .detail-grid{grid-template-columns:1fr}
    #tsReceiptPdfFrame{height:280px}
}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>

<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->






<header class="header">

<a href="<?= e(BASE_URL . 'admin-dashboard.php'); ?>" class="logo">
    <div class="logo-icon">
        <i class="fa-solid fa-plane"></i>
    </div>
    TRAV<span>SCOPE</span> ADMIN
</a>

<div class="admin">

    <div class="avatar">
        <?= e(abdInitial($admin['name'])); ?>
    </div>

    <div>
        <strong><?= e($admin['name']); ?></strong>
        <small>
            <?= e(
                ucfirst(
                    str_replace('_', ' ', $admin['role'])
                )
            ); ?>
        </small>
    </div>

</div>

</header>


<div class="layout">

<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->




<main class="main">

<div class="page-head">

    <div>

        <div class="breadcrumb">
            <a href="<?= e(BASE_URL . 'admin-bookings.php'); ?>">Bookings</a>
            <i class="fa-solid fa-chevron-right"></i>
            <?= e($booking['booking_number']); ?>
        </div>

        <h1>Booking Control Center</h1>

        <p>
            Customer, trip, operations, finance and travel documents in one booking workspace.
        </p>

    </div>

    <div class="head-actions">

        <a
            href="<?= e(BASE_URL . 'admin-bookings.php'); ?>"
            class="head-btn"
        >
            <i class="fa-solid fa-arrow-left"></i>
            Back
        </a>

        <a
            href="<?= e(BASE_URL . 'admin-trip-hotel-allocations.php?booking_id=' . $bookingId); ?>"
            class="head-btn"
            style="border-color:#c7d2fe;background:#eef2ff;color:#4338ca;"
        >
            <i class="fa-solid fa-hotel"></i>
            Hotels
        </a>

        <a
            href="<?= e(BASE_URL . 'admin-trip-transport-allocations.php?booking_id=' . $bookingId); ?>"
            class="head-btn"
            style="border-color:#bae6fd;background:#f0f9ff;color:#0369a1;"
        >
            <i class="fa-solid fa-van-shuttle"></i>
            Transport
        </a>

        <a
            href="<?= e(
                BASE_URL .
                'admin-payments.php?booking_id=' .
                $bookingId
            ); ?>"
            class="head-btn primary"
        >
            <i class="fa-solid fa-credit-card"></i>
            Payments
        </a>

        <?php if (function_exists('tsBillReady') && tsBillReady($pdo)): ?>
            <a
                href="<?= e(BASE_URL . 'admin-tax-invoice.php?id=' . $bookingId); ?>"
                class="head-btn"
                title="Create or manage GST/TCS tax invoice for this booking"
                style="border-color:#ddd6fe;background:#f5f3ff;color:#6d28d9;"
            >
                <i class="fa-solid fa-file-invoice-dollar"></i>
                Invoice
            </a>
        <?php endif; ?>

        <?php if (
            function_exists('tsDocReady')
            && tsDocReady($pdo)
        ): ?>
            <a
                href="<?= e(
                    BASE_URL
                    . 'admin-booking-documents.php?id='
                    . $bookingId
                ); ?>"
                class="head-btn"
                style="border-color:#bfdbfe;background:#eff6ff;color:#1d4ed8;"
            >
                <i class="fa-solid fa-passport"></i>
                Documents
                <?php if (
                    is_array($bookingDocumentSummary)
                    && !empty($bookingDocumentSummary['missing_requirements'])
                ): ?>
                    (<?= (int)$bookingDocumentSummary['missing_requirements']; ?>)
                <?php endif; ?>
            </a>
        <?php endif; ?>

        <?php if (
            function_exists('tsCommReady')
            && tsCommReady($pdo)
        ): ?>
            <a
                href="<?= e(
                    BASE_URL
                    . 'admin-booking-communications.php?id='
                    . $bookingId
                ); ?>"
                class="head-btn"
                style="border-color:#a7f3d0;background:#ecfdf5;color:#047857;"
            >
                <i class="fa-solid fa-comments"></i>
                Communications
                <?php if (
                    is_array($bookingCommunicationSummary)
                    && !empty($bookingCommunicationSummary['due'])
                ): ?>
                    (<?= (int)$bookingCommunicationSummary['due']; ?>)
                <?php endif; ?>
            </a>
        <?php endif; ?>

        <?php
        $topFinalVoucher =
            is_array($operationsReadiness)
                ? (
                    $operationsReadiness['latest_final_voucher']
                    ?? null
                )
                : null;

        $topLatestVoucher =
            !empty($bookingVoucherVersions)
                ? $bookingVoucherVersions[0]
                : null;

        $topVoucher =
            $topFinalVoucher
            ?: $topLatestVoucher;
        ?>

        <?php if ($topVoucher): ?>
            <a
                href="<?= e(
                    BASE_URL .
                    'booking-voucher.php?voucher=' .
                    (int)$topVoucher['id']
                ); ?>"
                class="head-btn"
                target="_blank"
                style="border-color:#059669;background:#059669;color:#fff;"
            >
                <i class="fa-solid fa-ticket"></i>
                Voucher V<?= (int)$topVoucher['version_number']; ?>
                <?= (string)$topVoucher['status'] === 'draft' ? ' Draft' : ''; ?>
            </a>
        <?php elseif (
            function_exists('tsOpsReady')
            && tsOpsReady($pdo)
        ): ?>
            <form
                method="post"
                target="_blank"
                style="margin:0;"
                onsubmit="return confirm('Create the first Draft Travel Voucher for this Booking?');"
            >
                <input
                    type="hidden"
                    name="booking_id"
                    value="<?= $bookingId; ?>"
                >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e($csrfToken); ?>"
                >
                <input
                    type="hidden"
                    name="action"
                    value="generate_booking_voucher"
                >
                <input
                    type="hidden"
                    name="voucher_status"
                    value="draft"
                >
                <input
                    type="hidden"
                    name="open_voucher"
                    value="1"
                >

                <button
                    type="submit"
                    class="head-btn"
                    style="border-color:#a7f3d0;background:#ecfdf5;color:#047857;cursor:pointer;"
                >
                    <i class="fa-solid fa-ticket"></i>
                    Create Voucher
                </button>
            </form>
        <?php endif; ?>

    </div>

</div>


<?php if ($success !== ''): ?>

<div class="alert alert-success">
    <i class="fa-solid fa-circle-check"></i>
    <?= e($success); ?>
</div>

<?php endif; ?>


<?php if ($error !== ''): ?>

<div class="alert alert-error">
    <i class="fa-solid fa-circle-exclamation"></i>
    <?= e($error); ?>
</div>

<?php endif; ?>


<section class="booking-hero">

    <div class="package-photo">

        <?php if ($packageImage !== ''): ?>

            <img
                src="<?= e($packageImage); ?>"
                alt=""
                loading="lazy"
                onerror="this.style.display='none';this.nextElementSibling.style.display='grid';"
            >
            <span class="package-photo-fallback" aria-label="Travel package image unavailable">
                <i class="fa-solid fa-plane-departure"></i>
            </span>

        <?php else: ?>

            <span class="package-photo-fallback is-visible" aria-label="Travel package image unavailable">
                <i class="fa-solid fa-plane-departure"></i>
            </span>

        <?php endif; ?>

    </div>


    <div class="hero-content">

        <div class="hero-kicker">
            <i class="fa-solid fa-hashtag"></i>
            <?= e($booking['booking_number']); ?>
        </div>

        <h2>
            <?= e($booking['package_title'] ?: 'Package unavailable'); ?>
        </h2>

        <div class="hero-meta">

            <?php if (!empty($booking['destination_name'])): ?>
                <span class="meta-pill">
                    <i class="fa-solid fa-location-dot"></i>
                    <?= e($booking['destination_name']); ?>
                    <?php if (!empty($booking['destination_country'])): ?>
                        · <?= e($booking['destination_country']); ?>
                    <?php endif; ?>
                </span>
            <?php endif; ?>

            <?php if (!empty($booking['duration_days'])): ?>
                <span class="meta-pill">
                    <i class="fa-regular fa-clock"></i>
                    <?= (int)$booking['duration_days']; ?> Days
                    <?php if ((int)$booking['duration_nights'] > 0): ?>
                        / <?= (int)$booking['duration_nights']; ?> Nights
                    <?php endif; ?>
                </span>
            <?php endif; ?>

            <span class="meta-pill">
                <i class="fa-regular fa-calendar"></i>
                Travel: <?= e(abdDate($booking['travel_date'], 'd M Y')); ?>
            </span>

            <span class="meta-pill">
                <i class="fa-solid fa-users"></i>
                <?= (int)$booking['adults']; ?> Adult<?= (int)$booking['adults'] === 1 ? '' : 's'; ?>
                <?php if ((int)$booking['children'] > 0): ?>
                    + <?= (int)$booking['children']; ?> Child<?= (int)$booking['children'] === 1 ? '' : 'ren'; ?>
                <?php endif; ?>
            </span>

        </div>

    </div>


    <div class="hero-status">

        <span class="badge badge-<?= e(abdBookingClass($booking['booking_status'])); ?>">
            <i class="fa-solid fa-calendar-check"></i>
            <?= e(ucfirst($booking['booking_status'])); ?>
        </span>

        <span class="badge badge-<?= e(abdPaymentClass($booking['payment_status'])); ?>">
            <i class="fa-solid fa-wallet"></i>
            <?= e(ucfirst($booking['payment_status'])); ?>
        </span>

        <small>
            Booked <?= e(abdDate($booking['created_at'])); ?><br>
            Last updated <?= e(abdDate($booking['updated_at'])); ?>
        </small>

    </div>

</section>


<div class="content-grid">

<div>

    <section class="card">

        <div class="card-head">
            <div>
                <h3>Customer & Booking Information</h3>
                <p>Contact details and reservation information.</p>
            </div>
        </div>

        <div class="card-body">

            <div class="customer-box">

                <div class="customer-photo">

                    <?php if ($profileImage !== ''): ?>

                        <img
                            src="<?= e($profileImage); ?>"
                            alt="<?= e($booking['customer_name']); ?>"
                        >

                    <?php else: ?>

                        <?= e(abdInitial($booking['customer_name'])); ?>

                    <?php endif; ?>

                </div>

                <div>
                    <h4><?= e($booking['customer_name']); ?></h4>
                    <p>
                        <?= !empty($booking['user_id'])
                            ? 'Registered TRAVSCOPE customer'
                            : 'Booking customer'; ?>
                    </p>
                </div>

                <div class="customer-links">

                    <a
                        href="mailto:<?= e($booking['customer_email']); ?>"
                        class="icon-btn"
                        title="Email customer"
                    >
                        <i class="fa-regular fa-envelope"></i>
                    </a>

                    <a
                        href="tel:<?= e($booking['customer_mobile']); ?>"
                        class="icon-btn"
                        title="Call customer"
                    >
                        <i class="fa-solid fa-phone"></i>
                    </a>

                </div>

            </div>


            <div class="detail-grid" style="margin-top:17px;">

                <div class="detail">
                    <label>Customer Name</label>
                    <strong class="icon-label">
                        <i class="fa-regular fa-user"></i>
                        <?= e($booking['customer_name']); ?>
                    </strong>
                </div>

                <div class="detail">
                    <label>Booking Number</label>
                    <strong class="icon-label">
                        <i class="fa-solid fa-hashtag"></i>
                        <?= e($booking['booking_number']); ?>
                    </strong>
                </div>

                <div class="detail">
                    <label>Email</label>
                    <a href="mailto:<?= e($booking['customer_email']); ?>" class="icon-label">
                        <i class="fa-regular fa-envelope"></i>
                        <?= e($booking['customer_email']); ?>
                    </a>
                </div>

                <div class="detail">
                    <label>Mobile</label>
                    <a href="tel:<?= e($booking['customer_mobile']); ?>" class="icon-label">
                        <i class="fa-solid fa-phone"></i>
                        <?= e($booking['customer_mobile']); ?>
                    </a>
                </div>

                <div class="detail">
                    <label>Travel Date</label>
                    <strong class="icon-label">
                        <i class="fa-regular fa-calendar"></i>
                        <?= e(abdDate($booking['travel_date'], 'd M Y')); ?>
                    </strong>
                </div>

                <div class="detail">
                    <label>Travellers</label>
                    <strong class="icon-label">
                        <i class="fa-solid fa-users"></i>
                        <?= (int)$booking['adults']; ?> Adult<?= (int)$booking['adults'] === 1 ? '' : 's'; ?>
                        <?php if ((int)$booking['children'] > 0): ?>
                            + <?= (int)$booking['children']; ?> Child<?= (int)$booking['children'] === 1 ? '' : 'ren'; ?>
                        <?php endif; ?>
                    </strong>
                </div>

                <div class="detail">
                    <label>Booking Created</label>
                    <strong class="icon-label">
                        <i class="fa-regular fa-clock"></i>
                        <?= e(abdDate($booking['created_at'])); ?>
                    </strong>
                </div>

                <div class="detail">
                    <label>Customer Account</label>

                    <?php if (!empty($booking['user_id'])): ?>

                        <a
                            href="<?= e(
                                BASE_URL .
                                'admin-user-details.php?id=' .
                                (int)$booking['user_id']
                            ); ?>"
                            class="icon-label"
                        >
                            <i class="fa-solid fa-user-check"></i>
                            View User #<?= (int)$booking['user_id']; ?>
                        </a>

                    <?php else: ?>

                        <strong class="icon-label">
                            <i class="fa-solid fa-user-slash"></i>
                            No linked account
                        </strong>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </section>


    <section class="card">

        <div class="card-head">
            <div>
                <h3>Trip Information</h3>
                <p>Package and destination attached to this reservation.</p>
            </div>
        </div>

        <div class="card-body">

            <div class="detail-grid">

                <div class="detail">
                    <label>Package</label>
                    <?php if (!empty($booking['package_slug'])): ?>
                        <a
                            href="<?= e(
                                BASE_URL .
                                'package-details.php?slug=' .
                                urlencode($booking['package_slug'])
                            ); ?>"
                            target="_blank"
                            class="icon-label"
                        >
                            <i class="fa-solid fa-suitcase-rolling"></i>
                            <?= e($booking['package_title']); ?>
                        </a>
                    <?php else: ?>
                        <strong><?= e($booking['package_title'] ?: 'Unavailable'); ?></strong>
                    <?php endif; ?>
                </div>

                <div class="detail">
                    <label>Package Code</label>
                    <strong>
                        <?= e($booking['package_code'] ?: 'Not set'); ?>
                    </strong>
                </div>

                <div class="detail">
                    <label>Destination</label>
                    <strong class="icon-label">
                        <i class="fa-solid fa-location-dot"></i>
                        <?= e($booking['destination_name'] ?: 'Not available'); ?>
                        <?php if (!empty($booking['destination_country'])): ?>
                            · <?= e($booking['destination_country']); ?>
                        <?php endif; ?>
                    </strong>
                </div>

                <div class="detail">
                    <label>Package Type</label>
                    <strong>
                        <?= e(
                            $booking['package_type']
                                ? ucfirst($booking['package_type'])
                                : 'Not available'
                        ); ?>
                    </strong>
                </div>

                <div class="detail">
                    <label>Duration</label>
                    <strong>
                        <?php if (!empty($booking['duration_days'])): ?>
                            <?= (int)$booking['duration_days']; ?> Days
                            <?php if ((int)$booking['duration_nights'] > 0): ?>
                                / <?= (int)$booking['duration_nights']; ?> Nights
                            <?php endif; ?>
                        <?php else: ?>
                            Not available
                        <?php endif; ?>
                    </strong>
                </div>

                <div class="detail">
                    <label>Travel Date</label>
                    <strong><?= e(abdDate($booking['travel_date'], 'l, d M Y')); ?></strong>
                </div>

            </div>

        </div>

    </section>


    <?php if ($bookingTripLink): ?>
    <section class="card">
        <div class="card-head">
            <div>
                <h3>CRM Booking Conversion</h3>
                <p>The exact accepted quotation and expected commercial baseline frozen when this Booking was created.</p>
            </div>
            <a
                class="head-btn"
                href="<?= e(BASE_URL . 'admin-crm.php?lead=' . (int)$bookingTripLink['enquiry_id'] . '&trip=' . (int)$bookingTripLink['trip_id']); ?>"
            >
                <i class="fa-solid fa-route"></i>
                Open Trip
            </a>
        </div>

        <div class="card-body">
            <div class="details-grid">
                <div class="detail">
                    <label>Trip</label>
                    <strong><?= e((string)$bookingTripLink['trip_code']); ?></strong>
                </div>

                <div class="detail">
                    <label>Accepted Quotation</label>
                    <strong>Version <?= (int)$bookingTripLink['version_number']; ?></strong>
                </div>

                <div class="detail">
                    <label>Accepted Via</label>
                    <strong><?= e(ucwords(str_replace('_', ' ', (string)$bookingTripLink['accepted_source']))); ?></strong>
                </div>

                <div class="detail">
                    <label>Accepted At</label>
                    <strong><?= e(abdDate($bookingTripLink['accepted_at'])); ?></strong>
                </div>

                <div class="detail">
                    <label>Expected Supplier Cost</label>
                    <strong><?= $aclCanViewSupplierCost ? e(abdMoney((float)$bookingTripLink['expected_supplier_cost'], (string)$booking['currency'])) : 'Restricted'; ?></strong>
                </div>

                <div class="detail">
                    <label>Other Direct Cost</label>
                    <strong><?= $aclCanViewMargin ? e(abdMoney((float)$bookingTripLink['expected_direct_cost'], (string)$booking['currency'])) : 'Restricted'; ?></strong>
                </div>

                <div class="detail">
                    <label>Expected Travscope Cost</label>
                    <strong><?= $aclCanViewMargin ? e(abdMoney((float)$bookingTripLink['expected_total_cost'], (string)$booking['currency'])) : 'Restricted'; ?></strong>
                </div>

                <div class="detail">
                    <label>Expected Margin</label>
                    <strong><?= $aclCanViewMargin ? e(abdMoney((float)$bookingTripLink['expected_margin_amount'], (string)$booking['currency'])) : 'Restricted'; ?></strong>
                </div>
            </div>

            <?php if (!empty($bookingTripLink['customer_confirmation_note'])): ?>
                <div class="request-box" style="margin-top:14px;">
                    <?= e((string)$bookingTripLink['customer_confirmation_note']); ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="card" id="travel-execution" style="scroll-margin-top:20px;">
        <div class="card-head">
            <div>
                <h3>Travel Execution & Post-Trip Closure</h3>
                <p>Live journey operations: driver/guide contacts, on-tour updates, incidents, actual expenses and completion.</p>
            </div>

            <?php if ($executionState): ?>
                <span class="exec-pill <?= e((string)$executionState['execution_status']); ?>">
                    <?= e(strtoupper(str_replace('_', ' ', (string)$executionState['execution_status']))); ?>
                </span>
            <?php endif; ?>
        </div>

        <div class="card-body">
            <?php if (!function_exists('tsExecReady') || !tsExecReady($pdo)): ?>
                <div class="request-box">
                    Import <strong>TRAVSCOPE_Travel_Execution_Post_Trip_Closure.sql</strong> and upload <strong>execution-functions.php</strong> to enable live Trip Execution.
                </div>
            <?php elseif ($executionState): ?>
                <?php
                $openIncidentCount =
                    (int)(
                        $executionCompletionReadiness['open_incidents']
                        ?? 0
                    );

                $completedExecutionChecks =
                    (int)(
                        $executionCompletionReadiness['completed_checks']
                        ?? 0
                    );

                $requiredExecutionChecks =
                    (int)(
                        $executionCompletionReadiness['required_checks']
                        ?? 0
                    );
                ?>

                <div class="exec-summary">
                    <div class="exec-kpi">
                        <span>Execution Status</span>
                        <strong><?= e(ucwords(str_replace('_', ' ', (string)$executionState['execution_status']))); ?></strong>
                    </div>
                    <div class="exec-kpi">
                        <span>Operational Contacts</span>
                        <strong><?= count($executionContacts); ?></strong>
                    </div>
                    <div class="exec-kpi">
                        <span>Open Incidents</span>
                        <strong><?= $openIncidentCount; ?></strong>
                    </div>
                    <div class="exec-kpi">
                        <span>Completion Checks</span>
                        <strong><?= $completedExecutionChecks; ?> / <?= $requiredExecutionChecks; ?></strong>
                    </div>
                </div>

                <?php if ((string)$executionState['execution_status'] === 'pre_departure'): ?>
                    <div style="padding:12px;border:1px solid #dbeafe;border-radius:12px;background:#eff6ff;display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;">
                        <div>
                            <strong style="display:block;color:#1d4ed8;">Ready to begin the live journey?</strong>
                            <small style="display:block;margin-top:4px;color:#64748b;line-height:1.5;">
                                Start Trip becomes available only for a Confirmed Booking. If Operations Readiness is installed, it must be 100% ready first.
                            </small>
                        </div>

                        <form method="post" onsubmit="return confirm('Start live Trip Execution for this Booking?');">
                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                            <input type="hidden" name="action" value="start_trip_execution">
                            <button class="action-btn confirm" type="submit">
                                <i class="fa-solid fa-play"></i>
                                Start Trip Execution
                            </button>
                        </form>
                    </div>
                <?php endif; ?>

                <div class="exec-grid" style="margin-top:11px;">
                    <div class="exec-panel">
                        <h4><i class="fa-solid fa-address-book"></i> Driver / Guide / Hotel / Local Contacts</h4>

                        <?php if ($executionContacts): ?>
                            <div class="exec-list" style="margin-bottom:9px;">
                                <?php foreach ($executionContacts as $contact): ?>
                                    <div class="exec-item">
                                        <div class="exec-item-top">
                                            <div>
                                                <strong>
                                                    <?= e(tsExecContactTypes()[(string)$contact['contact_type']] ?? ucwords(str_replace('_',' ',(string)$contact['contact_type']))); ?>
                                                    · <?= e((string)$contact['contact_name']); ?>
                                                </strong>
                                                <small>
                                                    <?php if (!empty($contact['organization'])): ?><?= e((string)$contact['organization']); ?> · <?php endif; ?>
                                                    <?= e((string)($contact['mobile'] ?: $contact['whatsapp'] ?: $contact['email'] ?: 'No contact number')); ?>
                                                    · <?= !empty($contact['customer_visible']) ? 'Customer Visible' : 'Internal Only'; ?>
                                                </small>
                                                <?php if (!empty($contact['details'])): ?><small><?= nl2br(e((string)$contact['details'])); ?></small><?php endif; ?>
                                            </div>

                                            <form method="post">
                                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                                <input type="hidden" name="action" value="remove_execution_contact">
                                                <input type="hidden" name="execution_contact_id" value="<?= (int)$contact['id']; ?>">
                                                <button class="action-btn danger" type="submit">Remove</button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <details>
                            <summary style="cursor:pointer;font-size:10px;font-weight:900;color:#1d4ed8;">+ Add Operational Contact</summary>
                            <form method="post" class="exec-form" style="margin-top:8px;">
                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                <input type="hidden" name="action" value="add_execution_contact">

                                <select name="execution_contact_type">
                                    <?php foreach (tsExecContactTypes() as $value => $label): ?>
                                        <option value="<?= e($value); ?>"><?= e($label); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <select name="execution_contact_service_id">
                                    <option value="">General Trip Contact</option>
                                    <?php foreach ($bookingServiceSnapshots as $service): ?>
                                        <option value="<?= (int)$service['id']; ?>"><?= e((string)$service['title']); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <input name="execution_contact_name" placeholder="Contact name *" required>
                                <input name="execution_contact_organization" placeholder="Hotel / transport / organization">
                                <input name="execution_contact_mobile" placeholder="Mobile">
                                <input name="execution_contact_whatsapp" placeholder="WhatsApp">
                                <input class="full" name="execution_contact_email" placeholder="Email">
                                <textarea class="full" name="execution_contact_details" placeholder="Pickup point, vehicle number, shift, meeting point or operational note"></textarea>

                                <label class="full" style="display:flex;align-items:center;gap:7px;font-size:10px;color:#475569;">
                                    <input type="checkbox" name="execution_contact_customer_visible" value="1" checked style="width:auto;min-height:0;">
                                    Show this contact to customer in Booking Details
                                </label>

                                <button class="action-btn confirm full" type="submit">Save Contact</button>
                            </form>
                        </details>
                    </div>

                    <div class="exec-panel">
                        <h4><i class="fa-solid fa-timeline"></i> Live Trip Updates</h4>

                        <details>
                            <summary style="cursor:pointer;font-size:10px;font-weight:900;color:#1d4ed8;">+ Record Update</summary>
                            <form method="post" class="exec-form" style="margin-top:8px;">
                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                <input type="hidden" name="action" value="add_execution_update">

                                <select name="execution_update_type">
                                    <?php foreach (tsExecUpdateTypes() as $value => $label): ?>
                                        <option value="<?= e($value); ?>"><?= e($label); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <select name="execution_update_service_id">
                                    <option value="">General Trip Update</option>
                                    <?php foreach ($bookingServiceSnapshots as $service): ?>
                                        <option value="<?= (int)$service['id']; ?>"><?= e((string)$service['title']); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <input class="full" name="execution_update_title" placeholder="Update title *" required>
                                <textarea class="full" name="execution_update_details" placeholder="Operational update details"></textarea>

                                <label class="full" style="display:flex;align-items:center;gap:7px;font-size:10px;color:#475569;">
                                    <input type="checkbox" name="execution_update_customer_visible" value="1" style="width:auto;min-height:0;">
                                    Show this update to customer
                                </label>

                                <button class="action-btn confirm full" type="submit">Record Update</button>
                            </form>
                        </details>

                        <?php if ($executionUpdates): ?>
                            <div class="exec-list" style="margin-top:9px;max-height:390px;overflow:auto;">
                                <?php foreach ($executionUpdates as $update): ?>
                                    <div class="exec-item">
                                        <strong><?= e((string)$update['title']); ?></strong>
                                        <small>
                                            <?= e(tsExecUpdateTypes()[(string)$update['update_type']] ?? ucwords(str_replace('_',' ',(string)$update['update_type']))); ?>
                                            · <?= e(abdDate($update['created_at'])); ?>
                                            · <?= !empty($update['customer_visible']) ? 'Customer Visible' : 'Internal'; ?>
                                        </small>
                                        <?php if (!empty($update['details'])): ?><small><?= nl2br(e((string)$update['details'])); ?></small><?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="exec-panel">
                        <h4><i class="fa-solid fa-triangle-exclamation"></i> Incidents / Service Issues</h4>

                        <details>
                            <summary style="cursor:pointer;font-size:10px;font-weight:900;color:#b91c1c;">+ Record Incident</summary>
                            <form method="post" class="exec-form" style="margin-top:8px;">
                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                <input type="hidden" name="action" value="add_execution_incident">

                                <select name="execution_incident_type">
                                    <?php foreach (tsExecIncidentTypes() as $value => $label): ?>
                                        <option value="<?= e($value); ?>"><?= e($label); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <select name="execution_incident_severity">
                                    <option value="low">Low</option>
                                    <option value="medium" selected>Medium</option>
                                    <option value="high">High</option>
                                    <option value="critical">Critical</option>
                                </select>

                                <select class="full" name="execution_incident_service_id">
                                    <option value="">General Trip Incident</option>
                                    <?php foreach ($bookingServiceSnapshots as $service): ?>
                                        <option value="<?= (int)$service['id']; ?>"><?= e((string)$service['title']); ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <input class="full" name="execution_incident_title" placeholder="Issue title *" required>
                                <textarea class="full" name="execution_incident_description" placeholder="What happened? *" required></textarea>
                                <input name="execution_incident_actual_cost" type="number" min="0" step=".01" value="0" placeholder="Actual emergency/on-tour cost">
                                <input name="execution_incident_customer_note" placeholder="Customer-safe note if visible">

                                <label class="full" style="display:flex;align-items:center;gap:7px;font-size:10px;color:#475569;">
                                    <input type="checkbox" name="execution_incident_customer_visible" value="1" style="width:auto;min-height:0;">
                                    Show incident status/note to customer
                                </label>

                                <button class="action-btn danger full" type="submit">Record Incident</button>
                            </form>
                        </details>

                        <?php if ($executionIncidents): ?>
                            <div class="exec-list" style="margin-top:9px;">
                                <?php foreach ($executionIncidents as $incident): ?>
                                    <div class="exec-item">
                                        <div class="exec-item-top">
                                            <div>
                                                <strong><?= e((string)$incident['title']); ?></strong>
                                                <small>
                                                    <?= e(ucwords(str_replace('_',' ',(string)$incident['incident_type']))); ?>
                                                    · <?= e(strtoupper((string)$incident['severity'])); ?>
                                                    · <?= e(abdDate($incident['created_at'])); ?>
                                                </small>
                                                <small><?= nl2br(e((string)$incident['description'])); ?></small>
                                                <?php if ((float)$incident['actual_cost_amount'] > 0): ?>
                                                    <small style="color:#b91c1c;font-weight:800;">Actual Cost Posted: <?= e(abdMoney((float)$incident['actual_cost_amount'], (string)$booking['currency'])); ?></small>
                                                <?php endif; ?>
                                            </div>
                                            <span class="exec-pill <?= e((string)$incident['status']); ?>"><?= e(strtoupper((string)$incident['status'])); ?></span>
                                        </div>

                                        <?php if ((string)$incident['status'] !== 'resolved'): ?>
                                            <form method="post" class="exec-form" style="margin-top:7px;">
                                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                                <input type="hidden" name="action" value="set_execution_incident_status">
                                                <input type="hidden" name="execution_incident_id" value="<?= (int)$incident['id']; ?>">
                                                <select name="execution_incident_status">
                                                    <option value="monitoring" <?= $incident['status']==='monitoring'?'selected':''; ?>>Monitoring</option>
                                                    <option value="resolved">Resolved</option>
                                                </select>
                                                <input name="execution_incident_resolution" placeholder="Resolution / action taken">
                                                <button class="action-btn confirm full" type="submit">Update Incident</button>
                                            </form>
                                        <?php elseif (!empty($incident['internal_resolution'])): ?>
                                            <small style="color:#047857;font-weight:800;">Resolution: <?= e((string)$incident['internal_resolution']); ?></small>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="exec-panel">
                        <h4><i class="fa-solid fa-receipt"></i> On-Tour Expense → Actual Profitability</h4>

                        <?php if (function_exists('tsFinReady') && tsFinReady($pdo) && !$financeClosure): ?>
                            <form method="post" enctype="multipart/form-data" class="exec-form">
                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                <input type="hidden" name="action" value="add_on_tour_expense">
                                <input type="hidden" name="booking_currency" value="<?= e((string)$booking['currency']); ?>">

                                <select name="on_tour_cost_type">
                                    <?php foreach (tsFinDirectCostTypes() as $value => $label): ?>
                                        <option value="<?= e($value); ?>"><?= e($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="number" name="on_tour_cost_amount" min=".01" step=".01" placeholder="Amount *" required>
                                <input class="full" name="on_tour_cost_description" placeholder="Expense description *" required>
                                <input type="date" name="on_tour_cost_date" value="<?= e(date('Y-m-d')); ?>" required>
                                <input type="file" name="on_tour_cost_attachment">
                                <textarea class="full" name="on_tour_cost_notes" placeholder="Operational / receipt note"></textarea>
                                <button class="action-btn confirm full" type="submit">Post Actual Expense</button>
                            </form>
                            <small style="display:block;margin-top:7px;color:#64748b;line-height:1.45;">This does not create a duplicate ledger. It posts directly to the existing Actual Direct Cost / Profitability engine.</small>
                        <?php else: ?>
                            <div class="request-box">Finance module is unavailable or this Booking is financially closed.</div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ((string)$executionState['execution_status'] === 'in_progress'): ?>
                    <div class="exec-panel" style="margin-top:11px;">
                        <h4><i class="fa-solid fa-flag-checkered"></i> Trip Completion Checklist</h4>

                        <form method="post">
                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                            <input type="hidden" name="action" value="save_execution_checks">

                            <div style="display:grid;gap:6px;">
                                <?php foreach ($executionChecks as $check): ?>
                                    <div class="exec-check">
                                        <input
                                            type="checkbox"
                                            name="execution_check_complete[<?= e((string)$check['check_key']); ?>]"
                                            value="1"
                                            <?= !empty($check['is_complete']) ? 'checked' : ''; ?>
                                        >
                                        <div>
                                            <strong style="font-size:10px;color:#334155;"><?= e((string)$check['label']); ?></strong>
                                            <?php if (!empty($check['completed_at'])): ?><small style="display:block;color:#64748b;font-size:8px;">Completed <?= e(abdDate($check['completed_at'])); ?></small><?php endif; ?>
                                        </div>
                                        <input type="text" name="execution_check_note[<?= e((string)$check['check_key']); ?>]" value="<?= e((string)($check['note'] ?? '')); ?>" placeholder="Optional note">
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <button class="action-btn confirm" type="submit" style="margin-top:8px;">Save Completion Checks</button>
                        </form>

                        <div style="margin-top:12px;padding-top:11px;border-top:1px solid #e2e8f0;">
                            <strong style="display:block;color:<?= !empty($executionCompletionReadiness['ready']) ? '#047857' : '#c2410c'; ?>;font-size:11px;">
                                <?= !empty($executionCompletionReadiness['ready']) ? 'READY TO COMPLETE TRIP' : 'TRIP COMPLETION NOT READY'; ?>
                            </strong>
                            <small style="display:block;margin-top:4px;color:#64748b;">
                                Checks <?= $completedExecutionChecks; ?>/<?= $requiredExecutionChecks; ?>
                                · Open Incidents <?= $openIncidentCount; ?>
                            </small>
                        </div>

                        <form method="post" class="exec-form" style="margin-top:9px;" onsubmit="return confirm('Complete this Trip? Booking Status will become Completed and the customer will become eligible to submit a review.');">
                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                            <input type="hidden" name="action" value="complete_trip_execution">

                            <textarea class="full" name="execution_completion_note" placeholder="Trip completion / handover note"></textarea>
                            <input type="date" name="repeat_followup_date">
                            <input name="repeat_followup_note" placeholder="Repeat-business / post-trip follow-up note">

                            <button
                                class="action-btn confirm full"
                                type="submit"
                                <?= empty($executionCompletionReadiness['ready']) ? 'disabled style="opacity:.55;cursor:not-allowed;"' : ''; ?>
                            >
                                <i class="fa-solid fa-circle-check"></i>
                                Complete Trip Execution
                            </button>
                        </form>
                    </div>
                <?php elseif ((string)$executionState['execution_status'] === 'completed'): ?>
                    <div style="margin-top:11px;padding:12px;border:1px solid #a7f3d0;border-radius:12px;background:#ecfdf5;">
                        <strong style="display:block;color:#047857;">Trip Completed</strong>
                        <small style="display:block;margin-top:4px;color:#64748b;">
                            Completed <?= e(abdDate($executionState['completed_at'])); ?>
                            <?php if (!empty($executionState['repeat_followup_date'])): ?>
                                · Repeat-business Follow-up <?= e(abdDate($executionState['repeat_followup_date'], 'd M Y')); ?>
                            <?php endif; ?>
                        </small>
                        <?php if (!empty($executionState['completion_note'])): ?><div style="margin-top:7px;font-size:10px;color:#475569;"><?= nl2br(e((string)$executionState['completion_note'])); ?></div><?php endif; ?>
                        <?php if (!empty($executionState['repeat_followup_note'])): ?><div style="margin-top:6px;font-size:10px;color:#1d4ed8;">Follow-up: <?= e((string)$executionState['repeat_followup_note']); ?></div><?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </section>


    <section class="card" id="booking-amendments" style="scroll-margin-top:20px;">
        <div class="card-head">
            <div>
                <h3>Booking Amendments & Commercial Impact</h3>
                <p>Booking changes are versioned. Service and commercial values change only after Admin approval.</p>
            </div>
            <?php if ($bookingAmendmentPending): ?>
                <span style="display:inline-flex;padding:6px 9px;border-radius:999px;background:#fff7ed;color:#c2410c;font-size:9px;font-weight:900;">
                    V<?= (int)$bookingAmendmentPending['version_number']; ?> PENDING
                </span>
            <?php endif; ?>
        </div>

        <div class="card-body">
            <?php if (!function_exists('tsAmendReady') || !tsAmendReady($pdo)): ?>
                <div class="request-box">Import <strong>TRAVSCOPE_Booking_Amendments_Cancellation_Impact.sql</strong> to enable amendments.</div>
            <?php elseif ($bookingAmendmentBaseline): ?>

                <div class="amend-summary">
                    <div class="amend-kpi"><span>Current Customer Price</span><strong><?= e(abdMoney((float)$bookingAmendmentBaseline['customer_price'], (string)$bookingAmendmentBaseline['currency'])); ?></strong></div>
                    <div class="amend-kpi"><span>Expected Supplier Cost</span><strong><?= $aclCanViewSupplierCost ? e(abdMoney((float)$bookingAmendmentBaseline['expected_supplier_cost'], (string)$bookingAmendmentBaseline['currency'])) : 'Restricted'; ?></strong></div>
                    <div class="amend-kpi"><span>Expected Total Cost</span><strong><?= $aclCanViewMargin ? e(abdMoney((float)$bookingAmendmentBaseline['expected_total_cost'], (string)$bookingAmendmentBaseline['currency'])) : 'Restricted'; ?></strong></div>
                    <div class="amend-kpi"><span>Expected Margin</span><strong><?= $aclCanViewMargin ? e(abdMoney((float)$bookingAmendmentBaseline['expected_margin'], (string)$bookingAmendmentBaseline['currency'])) : 'Restricted'; ?></strong></div>
                </div>

                <?php if (!$bookingAmendmentPending && !$financeClosure && !in_array((string)$booking['booking_status'], ['completed','cancelled'], true)): ?>
                    <details style="border:1px dashed #cbd5e1;border-radius:11px;background:#fbfdff;">
                        <summary style="cursor:pointer;padding:10px 11px;font-size:10px;font-weight:900;color:#1d4ed8;list-style:none;"><i class="fa-solid fa-plus"></i> Create Booking Change Request</summary>
                        <form method="post" style="padding:0 11px 11px;">
                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                            <input type="hidden" name="action" value="create_admin_amendment_request">
                            <textarea name="amendment_request_text" required placeholder="Example: Change Puri hotel and shift check-in by one day." style="width:100%;min-height:70px;margin-bottom:8px;"></textarea>
                            <button class="action-btn confirm" type="submit"><i class="fa-solid fa-file-circle-plus"></i> Create Pending Amendment</button>
                        </form>
                    </details>
                <?php endif; ?>

                <?php if ($bookingAmendmentPending): ?>
                    <div class="amend-pending">
                        <strong style="display:block;color:#9a3412;">Amendment V<?= (int)$bookingAmendmentPending['version_number']; ?> · <?= e(ucfirst((string)$bookingAmendmentPending['requested_by_type'])); ?> Request</strong>
                        <div style="margin-top:6px;font-size:11px;line-height:1.55;color:#475569;"><?= nl2br(e((string)$bookingAmendmentPending['request_text'])); ?></div>

                        <form method="post" style="margin-top:11px;" onsubmit="return confirm('Approve this amendment and apply the revised Booking/service/commercial values?');">
                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                            <input type="hidden" name="action" value="approve_booking_amendment">
                            <input type="hidden" name="amendment_id" value="<?= (int)$bookingAmendmentPending['id']; ?>">
                            <input type="hidden" name="booking_currency" value="<?= e((string)$booking['currency']); ?>">

                            <div class="amend-grid">
                                <div><label>Customer Price Change</label><input type="number" name="customer_price_delta" step=".01" value="0" placeholder="+5000 or -2000"></div>
                                <div><label>Supplier Cost Change</label><input type="number" name="supplier_cost_delta" step=".01" value="0" placeholder="+3000 or -1000"></div>
                                <div><label>Direct Cost Change</label><input type="number" name="direct_cost_delta" step=".01" value="0" placeholder="+500 or -250"></div>

                                <div>
                                    <label>Service Change Type</label>
                                    <select name="service_change_type">
                                        <option value="commercial_only">Commercial / Notes Only</option>
                                        <option value="modify">Modify Existing Service</option>
                                        <option value="cancel">Cancel Existing Service</option>
                                        <option value="add">Add New Service</option>
                                    </select>
                                </div>

                                <div>
                                    <label>Affected Existing Service</label>
                                    <select name="booking_service_snapshot_id">
                                        <option value="">Select for Modify / Cancel</option>
                                        <?php foreach ($bookingServiceSnapshots as $service): ?>
                                            <option value="<?= (int)$service['id']; ?>"><?= e(ucwords(str_replace('_',' ',(string)$service['service_type']))); ?> · <?= e((string)$service['title']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div>
                                    <label>New / Revised Service Type</label>
                                    <select name="proposed_service_type">
                                        <option value="">Keep current / choose for new</option>
                                        <?php foreach (['hotel','transport','transfer','activity','sightseeing','flight','visa','train','cruise','guide','insurance','meal','other'] as $serviceType): ?>
                                            <option value="<?= e($serviceType); ?>"><?= e(ucwords(str_replace('_',' ',$serviceType))); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div><label>New / Revised Title</label><input name="proposed_title" placeholder="Hotel / transport / service title"></div>
                                <div><label>Destination</label><input name="proposed_destination_name" placeholder="Destination / city"></div>
                                <div><label>Quantity</label><input type="number" name="proposed_quantity" min=".01" step=".01"></div>
                                <div><label>Start Date</label><input type="date" name="proposed_date_from"></div>
                                <div><label>End Date</label><input type="date" name="proposed_date_to"></div>
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;"><div><label>Adults</label><input type="number" name="proposed_adults" min="0"></div><div><label>Children</label><input type="number" name="proposed_children" min="0"></div></div>

                                <div class="full"><label>New / Revised Specification</label><textarea name="proposed_specifications" placeholder="Room type, meal plan, vehicle, timing, inclusion or revised details"></textarea></div>
                                <div class="full"><label>Supplier Impact / Reconfirmation Note</label><textarea name="supplier_impact_note"></textarea></div>
                                <div class="full"><label>Customer Message</label><textarea name="customer_message"></textarea></div>
                                <div class="full"><label>Internal Approval Note</label><textarea name="internal_note"></textarea></div>
                                <div class="full"><button class="action-btn confirm" type="submit"><i class="fa-solid fa-circle-check"></i> Approve & Apply Amendment</button></div>
                            </div>
                        </form>

                        <form method="post" style="margin-top:7px;" onsubmit="return confirm('Reject this Booking amendment?');">
                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                            <input type="hidden" name="action" value="reject_booking_amendment">
                            <input type="hidden" name="amendment_id" value="<?= (int)$bookingAmendmentPending['id']; ?>">
                            <input type="hidden" name="customer_message" value="The requested Booking change could not be approved in its current form.">
                            <input type="hidden" name="internal_note" value="Rejected by Admin from Booking Details.">
                            <button class="action-btn danger" type="submit"><i class="fa-solid fa-xmark"></i> Reject Amendment</button>
                        </form>
                    </div>
                <?php endif; ?>

                <?php if ($bookingAmendmentHistory): ?>
                    <div class="amend-history">
                        <strong style="color:#0f172a;">Amendment History</strong>
                        <?php foreach ($bookingAmendmentHistory as $row): ?>
                            <div class="amend-row">
                                <div class="amend-row-top">
                                    <div><strong>Amendment V<?= (int)$row['version_number']; ?> · <?= e(ucfirst((string)$row['requested_by_type'])); ?></strong><small style="display:block;margin-top:4px;color:#64748b;"><?= e(abdDate($row['created_at'])); ?> · <?= e(ucwords(str_replace('_',' ',(string)$row['change_type']))); ?></small></div>
                                    <span class="amend-pill <?= e((string)$row['status']); ?>"><?= e(strtoupper((string)$row['status'])); ?></span>
                                </div>
                                <div style="margin-top:7px;font-size:10px;line-height:1.5;color:#475569;"><?= nl2br(e((string)$row['request_text'])); ?></div>
                                <?php if ($row['status']==='approved'): ?>
                                    <small style="display:block;margin-top:7px;color:#1d4ed8;font-weight:800;">Customer Delta <?= e(abdMoney((float)$row['customer_price_delta'],(string)$booking['currency'])); ?> · Supplier Delta <?= e(abdMoney((float)$row['supplier_cost_delta'],(string)$booking['currency'])); ?> · Revised Price <?= e(abdMoney((float)$row['revised_customer_price'],(string)$booking['currency'])); ?> · Revised Margin <?= e(abdMoney((float)$row['revised_expected_margin'],(string)$booking['currency'])); ?></small>
                                    <?php if ((string)$row['customer_financial_action']!=='none'): ?><div class="request-box" style="margin-top:7px;">Customer Finance: <strong><?= e(ucwords(str_replace('_',' ',(string)$row['customer_financial_action']))); ?></strong> · <?= e(abdMoney((float)$row['customer_financial_amount'],(string)$booking['currency'])); ?></div><?php endif; ?>
                                <?php endif; ?>
                                <?php if (!empty($row['customer_message'])): ?><small style="display:block;margin-top:7px;color:#475569;">Customer Message: <?= e((string)$row['customer_message']); ?></small><?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </section>


    <section class="card" id="customer-billing" style="scroll-margin-top:20px;">
        <div class="card-head">
            <div>
                <h3>Customer Billing & Collections</h3>
                <p>Payment schedule, installments, invoices, receipts, reminders, credit/debit notes, refunds and customer statement.</p>
            </div>

            <?php if (function_exists('tsBillReady') && tsBillReady($pdo)): ?>
                <a class="head-btn" href="<?= e(BASE_URL . 'booking-statement.php?booking=' . $bookingId); ?>" target="_blank">
                    <i class="fa-solid fa-file-lines"></i> Statement
                </a>
            <?php endif; ?>
        </div>

        <div class="card-body">
            <?php if (!function_exists('tsBillReady') || !tsBillReady($pdo)): ?>
                <div class="request-box">
                    Import <strong>TRAVSCOPE_Customer_Billing_Collections.sql</strong> to enable Customer Billing & Collections.
                </div>
            <?php else: ?>
                <?php
                $billTotal = function_exists('tsBillCollectibleTotal')
                    ? tsBillCollectibleTotal($pdo, $booking)
                    : max(0, (float)($booking['total_amount'] ?? 0));
                $billPaid = max(0, (float)($booking['paid_amount'] ?? 0));
                $billBalance = function_exists('tsBillCollectibleOutstanding')
                    ? tsBillCollectibleOutstanding($pdo, $booking)
                    : tsBillOutstanding($booking);
                ?>

                <div class="bill-summary">
                    <div class="bill-kpi"><span><?= $billingLatestFinalInvoice ? 'Current Payable (GST/TCS incl.)' : 'Current Booking Total'; ?></span><strong><?= e(abdMoney($billTotal, (string)$booking['currency'])); ?></strong></div>
                    <div class="bill-kpi good"><span><?= $booking['booking_status'] === 'cancelled' ? 'Net Payment Retained' : 'Customer Paid'; ?></span><strong><?= e(abdMoney($billPaid, (string)$booking['currency'])); ?></strong></div>
                    <div class="bill-kpi <?= $booking['booking_status'] === 'cancelled' ? 'good' : ($billBalance > .01 ? 'warn' : 'good'); ?>"><span><?= $booking['booking_status'] === 'cancelled' ? 'Further Collection' : 'Customer Balance'; ?></span><strong><?= $booking['booking_status'] === 'cancelled' ? 'CLOSED' : e(abdMoney($billBalance, (string)$booking['currency'])); ?></strong></div>
                    <div class="bill-kpi <?= $billingPendingRefundTotal > .01 ? 'warn' : ''; ?>"><span>Pending Refund</span><strong><?= e(abdMoney($billingPendingRefundTotal, (string)$booking['currency'])); ?></strong></div>
                </div>

                <div class="bill-grid">
                    <div class="bill-panel">
                        <div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start;">
                            <div>
                                <strong style="display:block;color:#0f172a;font-size:11px;">Payment Schedule</strong>
                                <small style="display:block;margin-top:3px;color:#64748b;font-size:9px;">Schedule the current outstanding balance. Old versions stay preserved.</small>
                            </div>
                            <?php if ($billingActiveSchedule): ?>
                                <span class="bill-pill final">SCHEDULE V<?= (int)$billingActiveSchedule['version_number']; ?></span>
                            <?php endif; ?>
                        </div>

                        <?php if ($billingInstallments): ?>
                            <?php foreach ($billingInstallments as $installment): ?>
                                <?php
                                $installmentDue = max(0, (float)$installment['amount'] - (float)$installment['paid_amount']);
                                $overdue = !empty($installment['due_date']) && $installment['due_date'] < date('Y-m-d') && $installmentDue > .01;
                                ?>
                                <div class="bill-installment">
                                    <div>
                                        <strong><?= (int)$installment['installment_number']; ?>. <?= e((string)$installment['title']); ?></strong>
                                        <small>
                                            Amount <?= e(abdMoney((float)$installment['amount'], (string)$booking['currency'])); ?>
                                            · Paid <?= e(abdMoney((float)$installment['paid_amount'], (string)$booking['currency'])); ?>
                                            · Due <?= e(abdMoney($installmentDue, (string)$booking['currency'])); ?>
                                            <?php if (!empty($installment['due_date'])): ?>
                                                · <?= $overdue ? 'OVERDUE ' : 'Due '; ?><?= e(abdDate($installment['due_date'], 'd M Y')); ?>
                                            <?php endif; ?>
                                        </small>
                                    </div>
                                    <span class="bill-pill <?= e((string)$installment['status']); ?>"><?= e(strtoupper(str_replace('_', ' ', (string)$installment['status']))); ?></span>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="request-box" style="margin-top:8px;">No active installment schedule.</div>
                        <?php endif; ?>

                        <?php if ($billBalance > .01 && !$financeClosure && strtolower((string)$booking['booking_status']) !== 'cancelled'): ?>
                            <details class="bill-form" style="margin-top:8px;">
                                <summary><i class="fa-solid fa-calendar-plus"></i> Create / Replace Payment Schedule</summary>
                                <div class="inside">
                                    <form method="post">
                                        <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                        <input type="hidden" name="action" value="create_payment_schedule">
                                        <div style="margin-bottom:7px;color:#64748b;font-size:9px;">Installment total must equal <strong><?= e(abdMoney($billBalance, (string)$booking['currency'])); ?></strong>.</div>

                                        <?php for ($row = 0; $row < 6; $row++): ?>
                                            <div class="bill-row">
                                                <input name="installment_title[]" placeholder="<?= $row === 0 ? 'Booking Advance' : 'Installment ' . ($row + 1); ?>">
                                                <input type="date" name="installment_due_date[]">
                                                <input type="number" name="installment_amount[]" min="0" step=".01" placeholder="Amount">
                                            </div>
                                        <?php endfor; ?>

                                        <textarea name="schedule_notes" placeholder="Optional schedule note"></textarea>
                                        <button class="action-btn confirm" type="submit" style="margin-top:7px;">Save Payment Schedule</button>
                                    </form>
                                </div>
                            </details>
                        <?php endif; ?>
                    </div>

                    <div class="bill-panel">
                        <strong style="display:block;color:#0f172a;font-size:11px;">Invoice & Collection</strong>
                        <div style="display:grid;gap:7px;margin-top:8px;">
                            <a class="action-btn confirm" href="<?= e(BASE_URL . 'admin-tax-invoice.php?id=' . $bookingId); ?>" style="width:100%;display:flex;justify-content:center;text-decoration:none;"><i class="fa-solid fa-file-invoice-dollar"></i>&nbsp; GST / TCS Tax Invoice</a>
                            <div style="font-size:8px;color:#64748b;line-height:1.45;padding:0 3px;">Create a modern statutory-ready invoice with GST/TCS, place of supply, SAC, customer GSTIN and email delivery.</div>

                            <?php if ($billBalance > .01): ?>
                                <form method="post">
                                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                    <input type="hidden" name="action" value="send_payment_reminder">
                                    <select name="reminder_installment_id" style="width:100%;min-height:34px;margin-bottom:6px;">
                                        <option value="0">Full Outstanding Balance</option>
                                        <?php foreach ($billingInstallments as $installment): ?>
                                            <?php if (in_array((string)$installment['status'], ['paid','cancelled'], true)) continue; ?>
                                            <option value="<?= (int)$installment['id']; ?>"><?= e((string)$installment['title']); ?> · <?= e(abdMoney(max(0, (float)$installment['amount'] - (float)$installment['paid_amount']), (string)$booking['currency'])); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button class="action-btn" type="submit" style="width:100%;"><i class="fa-solid fa-envelope"></i> Send Payment Reminder</button>
                                </form>
                            <?php endif; ?>
                        </div>

                        <?php if ($billingLatestFinalInvoice): ?>
                            <div class="request-box" style="margin-top:8px;background:#ecfdf5;color:#047857;border-color:#a7f3d0;">
                                Current Final Invoice:
                                <a href="<?= e(BASE_URL . 'booking-invoice.php?invoice=' . (int)$billingLatestFinalInvoice['id']); ?>" target="_blank"><strong><?= e((string)$billingLatestFinalInvoice['invoice_code']); ?></strong></a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if (!$financeClosure): ?>
                    <div class="bill-actions">
                        <details class="bill-form">
                            <summary><i class="fa-solid fa-plus-minus"></i> Credit / Debit Note</summary>
                            <div class="inside">
                                <form method="post">
                                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                    <input type="hidden" name="action" value="post_billing_adjustment">
                                    <select name="adjustment_type" required>
                                        <option value="debit">Debit Note — Increase Customer Total</option>
                                        <option value="credit">Credit Note — Reduce Customer Total</option>
                                    </select>
                                    <input type="number" name="adjustment_amount" min=".01" step=".01" placeholder="Amount" required style="margin-top:6px;">
                                    <input name="adjustment_reason" placeholder="Reason" required style="margin-top:6px;">
                                    <textarea name="adjustment_notes" placeholder="Optional billing note" style="margin-top:6px;"></textarea>
                                    <button class="action-btn confirm" type="submit" style="margin-top:6px;">Post Adjustment</button>
                                </form>
                            </div>
                        </details>

                        <details class="bill-form">
                            <summary><i class="fa-solid fa-rotate-left"></i> Create Manual Refund</summary>
                            <div class="inside">
                                <form method="post">
                                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                    <input type="hidden" name="action" value="create_manual_customer_refund">
                                    <input type="number" name="manual_refund_amount" min=".01" step=".01" placeholder="Refund Amount" required>
                                    <input name="manual_refund_reason" placeholder="Refund Reason" required style="margin-top:6px;">
                                    <textarea name="manual_refund_notes" placeholder="Optional refund note" style="margin-top:6px;"></textarea>
                                    <button class="action-btn confirm" type="submit" style="margin-top:6px;">Create Pending Refund</button>
                                </form>
                            </div>
                        </details>

                        <div class="bill-panel">
                            <strong style="display:block;font-size:10px;">Customer Statement</strong>
                            <small style="display:block;margin-top:4px;color:#64748b;font-size:9px;">Booking total, verified payments, receipts, adjustments, refunds and installment schedule.</small>
                            <a class="action-btn" href="<?= e(BASE_URL . 'booking-statement.php?booking=' . $bookingId); ?>" target="_blank" style="display:inline-flex;margin-top:8px;text-decoration:none;">Open Statement</a>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($billingRefunds): ?>
                    <div class="bill-history">
                        <strong style="color:#0f172a;">Customer Refunds</strong>
                        <?php foreach ($billingRefunds as $refund): ?>
                            <div class="bill-record">
                                <div class="bill-record-top">
                                    <div>
                                        <strong style="font-size:10px;"><?= e(abdMoney((float)$refund['amount'], (string)$refund['currency'])); ?> · <?= e((string)$refund['reason']); ?></strong>
                                        <small style="display:block;margin-top:3px;color:#64748b;font-size:8px;"><?= e(ucfirst((string)$refund['source_type'])); ?> · <?= e(abdDate($refund['requested_at'])); ?><?php if (!empty($refund['reference_number'])): ?> · Ref <?= e((string)$refund['reference_number']); ?><?php endif; ?></small>
                                    </div>
                                    <span class="bill-pill <?= e((string)$refund['status']); ?>"><?= e(strtoupper((string)$refund['status'])); ?></span>
                                </div>

                                <?php if (!$financeClosure && $refund['status'] === 'pending'): ?>
                                    <form method="post" style="display:grid;grid-template-columns:140px 1fr auto;gap:6px;margin-top:7px;">
                                        <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                        <input type="hidden" name="action" value="mark_customer_refund_paid">
                                        <input type="hidden" name="customer_refund_id" value="<?= (int)$refund['id']; ?>">
                                        <select name="refund_payment_method"><option value="bank_transfer">Bank Transfer</option><option value="upi">UPI</option><option value="cash">Cash</option><option value="other">Other</option></select>
                                        <input name="refund_reference_number" placeholder="Refund UTR / reference">
                                        <button class="action-btn confirm" type="submit">Mark Paid</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($billingAdjustments): ?>
                    <div class="bill-history">
                        <strong style="color:#0f172a;">Credit / Debit Notes</strong>
                        <?php foreach ($billingAdjustments as $adjustment): ?>
                            <div class="bill-record">
                                <div class="bill-record-top">
                                    <div>
                                        <strong style="font-size:10px;"><?= e((string)$adjustment['adjustment_code']); ?> · <?= e(ucfirst((string)$adjustment['adjustment_type'])); ?> · <?= e(abdMoney((float)$adjustment['amount'], (string)$booking['currency'])); ?></strong>
                                        <small style="display:block;margin-top:3px;color:#64748b;font-size:8px;"><?= e((string)$adjustment['reason']); ?> · <?= e(abdDate($adjustment['posted_at'])); ?></small>
                                    </div>
                                    <div style="display:flex;gap:5px;align-items:center;">
                                        <span class="bill-pill <?= e((string)$adjustment['status']); ?>"><?= e(strtoupper((string)$adjustment['status'])); ?></span>
                                        <?php if (!$financeClosure && $adjustment['status'] === 'posted'): ?>
                                            <form method="post" onsubmit="return confirm('Void this adjustment and reverse its effect on Booking total?');">
                                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                                <input type="hidden" name="action" value="void_billing_adjustment">
                                                <input type="hidden" name="billing_adjustment_id" value="<?= (int)$adjustment['id']; ?>">
                                                <button class="action-btn danger" type="submit">Void</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($billingInvoices || $billingReceipts): ?>
                    <div class="bill-history">
                        <strong style="color:#0f172a;">Invoices & Receipts</strong>
                        <?php foreach ($billingInvoices as $invoice): ?>
                            <div class="bill-record">
                                <div class="bill-record-top">
                                    <div>
                                        <strong style="font-size:10px;"><?= e((string)$invoice['invoice_code']); ?> · Invoice V<?= (int)$invoice['version_number']; ?></strong>
                                        <small style="display:block;margin-top:3px;color:#64748b;font-size:8px;">Total <?= e(abdMoney((float)$invoice['booking_total'], (string)$invoice['currency'])); ?> · Balance at issue <?= e(abdMoney((float)$invoice['balance_due_at_issue'], (string)$invoice['currency'])); ?> · <?= e(abdDate($invoice['created_at'])); ?></small>
                                    </div>
                                    <div><span class="bill-pill <?= e((string)$invoice['status']); ?>"><?= e(strtoupper((string)$invoice['status'])); ?></span> <a class="action-btn" href="<?= e(BASE_URL . 'booking-invoice.php?invoice=' . (int)$invoice['id']); ?>" target="_blank" style="display:inline-flex;text-decoration:none;">Open</a></div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <?php foreach ($billingReceipts as $receipt): ?>
                            <div class="bill-record">
                                <div class="bill-record-top">
                                    <div>
                                        <strong style="font-size:10px;"><?= e((string)$receipt['receipt_code']); ?> · Receipt <?= e(abdMoney((float)$receipt['amount'], (string)$receipt['currency'])); ?></strong>
                                        <small style="display:block;margin-top:3px;color:#64748b;font-size:8px;"><?= e(abdDate($receipt['paid_at'] ?: $receipt['created_at'])); ?><?php if (!empty($receipt['transaction_id'])): ?> · UTR <?= e((string)$receipt['transaction_id']); ?><?php endif; ?><?php if (!empty($receipt['installment_summary'])): ?> · <?= e((string)$receipt['installment_summary']); ?><?php endif; ?></small>
                                    </div>
                                    <div style="display:flex;gap:5px;flex-wrap:wrap;">
                                        <a class="action-btn" href="#verified-payment-receipts" style="display:inline-flex;text-decoration:none;">Preview above</a>
                                        <a class="action-btn" href="<?= e(BASE_URL . 'payment-receipt.php?receipt=' . (int)$receipt['id'] . '&format=pdf'); ?>" target="_blank" rel="noopener" style="display:inline-flex;text-decoration:none;background:#ecfdf5;color:#047857;">View PDF</a>
                                        <a class="action-btn" href="<?= e(BASE_URL . 'payment-receipt.php?receipt=' . (int)$receipt['id'] . '&format=pdf&download=1'); ?>" style="display:inline-flex;text-decoration:none;">Download PDF</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($billingReminders): ?>
                    <details class="bill-form" style="margin-top:10px;">
                        <summary><i class="fa-solid fa-clock-rotate-left"></i> Payment Reminder History</summary>
                        <div class="inside">
                            <?php foreach ($billingReminders as $reminder): ?>
                                <div style="padding:7px;border-bottom:1px solid #eef2f7;font-size:9px;"><strong><?= e(strtoupper((string)$reminder['status'])); ?></strong> · <?= e((string)$reminder['recipient']); ?> · <?= e(abdDate($reminder['sent_at'])); ?><div style="margin-top:3px;color:#64748b;"><?= e((string)$reminder['message']); ?></div></div>
                            <?php endforeach; ?>
                        </div>
                    </details>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </section>


    <?php if ($aclCanViewMargin): ?>
    <section class="card" id="finance-profitability" style="scroll-margin-top:20px;">
        <div class="card-head">
            <div>
                <h3>Supplier Finance & Actual Profitability</h3>
                <p>Customer receivable + supplier invoices/payables + actual cost + expected vs actual margin.</p>
            </div>

            <?php if ($financeClosure): ?>
                <span style="display:inline-flex;padding:6px 9px;border-radius:999px;background:#dcfce7;color:#166534;font-size:9px;font-weight:900;">
                    FINANCIALLY CLOSED
                </span>
            <?php elseif ($financeSummary): ?>
                <span style="display:inline-flex;padding:6px 9px;border-radius:999px;background:#eff6ff;color:#1d4ed8;font-size:9px;font-weight:900;">
                    LIVE PROFITABILITY
                </span>
            <?php endif; ?>
        </div>

        <div class="card-body">
            <?php if (
                !function_exists('tsFinReady')
                || !tsFinReady($pdo)
            ): ?>
                <div class="request-box">
                    Import <strong>TRAVSCOPE_Supplier_Finance_Actual_Profitability.sql</strong> to enable supplier invoices, supplier payments and actual profitability.
                </div>
            <?php elseif ($financeSummary): ?>
                <?php
                $finCurrency =
                    (string)$financeSummary['currency'];

                $marginVariance =
                    (float)$financeSummary['margin_variance'];

                $actualMargin =
                    (float)$financeSummary['actual_margin'];
                ?>

                <div class="fin-summary">
                    <div class="fin-box">
                        <span>Accepted Selling Price</span>
                        <strong><?= e(abdMoney((float)$financeSummary['selling_price'], $finCurrency)); ?></strong>
                    </div>

                    <div class="fin-box <?= (float)$financeSummary['customer_outstanding'] <= .01 ? 'good' : 'warn'; ?>">
                        <span>Customer Collected</span>
                        <strong><?= e(abdMoney((float)$financeSummary['customer_collected'], $finCurrency)); ?></strong>
                        <small>Outstanding <?= e(abdMoney((float)$financeSummary['customer_outstanding'], $finCurrency)); ?></small>
                    </div>

                    <div class="fin-box">
                        <span>Actual Supplier Cost</span>
                        <strong><?= e(abdMoney((float)$financeSummary['actual_supplier_cost'], $finCurrency)); ?></strong>
                        <small>Approved invoices only</small>
                    </div>

                    <div class="fin-box <?= (float)$financeSummary['supplier_payable'] <= .01 ? 'good' : 'warn'; ?>">
                        <span>Supplier Payable</span>
                        <strong><?= e(abdMoney((float)$financeSummary['supplier_payable'], $finCurrency)); ?></strong>
                        <small>Paid <?= e(abdMoney((float)$financeSummary['supplier_paid'], $finCurrency)); ?></small>
                    </div>

                    <div class="fin-box">
                        <span>Actual Direct Cost</span>
                        <strong><?= e(abdMoney((float)$financeSummary['actual_direct_cost'], $finCurrency)); ?></strong>
                    </div>

                    <div class="fin-box">
                        <span>Actual Total Cost</span>
                        <strong><?= e(abdMoney((float)$financeSummary['actual_total_cost'], $finCurrency)); ?></strong>
                    </div>

                    <div class="fin-box <?= $actualMargin >= 0 ? 'good' : 'bad'; ?>">
                        <span>Actual Margin</span>
                        <strong><?= e(abdMoney($actualMargin, $finCurrency)); ?></strong>
                    </div>

                    <div class="fin-box <?= $marginVariance >= 0 ? 'good' : 'bad'; ?>">
                        <span>Margin Variance</span>
                        <strong><?= $marginVariance >= 0 ? '+' : ''; ?><?= e(abdMoney($marginVariance, $finCurrency)); ?></strong>
                        <small>Actual Margin − Expected Margin</small>
                    </div>
                </div>

                <div class="fin-compare">
                    <table>
                        <thead>
                            <tr>
                                <th>Commercial Measure</th>
                                <th>Expected</th>
                                <th>Actual</th>
                                <th>Variance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $compareRows = [
                                [
                                    'Supplier Cost',
                                    (float)$financeSummary['expected_supplier_cost'],
                                    (float)$financeSummary['actual_supplier_cost']
                                ],
                                [
                                    'Other Direct Cost',
                                    (float)$financeSummary['expected_direct_cost'],
                                    (float)$financeSummary['actual_direct_cost']
                                ],
                                [
                                    'Total Travscope Cost',
                                    (float)$financeSummary['expected_total_cost'],
                                    (float)$financeSummary['actual_total_cost']
                                ],
                                [
                                    'Margin',
                                    (float)$financeSummary['expected_margin'],
                                    (float)$financeSummary['actual_margin']
                                ],
                            ];
                            ?>

                            <?php foreach ($compareRows as $compare): ?>
                                <?php $variance = $compare[2] - $compare[1]; ?>
                                <tr>
                                    <td><strong><?= e((string)$compare[0]); ?></strong></td>
                                    <td><?= e(abdMoney((float)$compare[1], $finCurrency)); ?></td>
                                    <td><?= e(abdMoney((float)$compare[2], $finCurrency)); ?></td>
                                    <td>
                                        <?= $variance >= 0 ? '+' : ''; ?><?= e(abdMoney($variance, $finCurrency)); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ((float)$financeSummary['unapproved_supplier_invoices'] > .01): ?>
                    <div class="request-box" style="margin-top:10px;background:#fff7ed;color:#9a3412;border-color:#fed7aa;">
                        Received but not yet approved supplier invoices:
                        <strong><?= e(abdMoney((float)$financeSummary['unapproved_supplier_invoices'], $finCurrency)); ?></strong>.
                        They are not included in Actual Cost until approved.
                    </div>
                <?php endif; ?>

                <?php if (!$financeClosure): ?>
                    <div class="fin-actions">
                        <details class="fin-form">
                            <summary><i class="fa-solid fa-file-invoice-dollar"></i> Record Supplier Invoice</summary>
                            <div class="inside">
                                <?php if (!$financeSuppliers): ?>
                                    <div class="request-box">No supplier-backed Booking Service is available for supplier invoicing.</div>
                                <?php else: ?>
                                <form method="post" enctype="multipart/form-data">
                                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                    <input type="hidden" name="action" value="create_supplier_invoice">

                                    <div class="fin-grid">
                                        <div>
                                            <label>Supplier *</label>
                                            <select name="supplier_id" required>
                                                <option value="">Select supplier</option>
                                                <?php foreach ($financeSuppliers as $supplier): ?>
                                                    <option value="<?= (int)$supplier['id']; ?>">
                                                        <?= e((string)$supplier['company_name']); ?>
                                                        · Expected <?= e(abdMoney((float)$supplier['expected_service_cost'], $finCurrency)); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>

                                        <div>
                                            <label>Invoice Number *</label>
                                            <input name="invoice_number" required>
                                        </div>

                                        <div>
                                            <label>Invoice Date *</label>
                                            <input type="date" name="invoice_date" value="<?= e(date('Y-m-d')); ?>" required>
                                        </div>

                                        <div>
                                            <label>Due Date</label>
                                            <input type="date" name="due_date">
                                        </div>

                                        <div>
                                            <label>Supplier GST / Tax</label>
                                            <input type="number" name="tax_amount" min="0" step=".01" value="0">
                                        </div>

                                        <div>
                                            <label>Other / Adjustment</label>
                                            <input type="number" name="other_amount" min="0" step=".01" value="0">
                                        </div>

                                        <div>
                                            <label>Status</label>
                                            <select name="invoice_status">
                                                <option value="received">Received — Review First</option>
                                                <option value="approved">Approved — Include in Actual Cost</option>
                                            </select>
                                        </div>

                                        <div>
                                            <label>Invoice Attachment</label>
                                            <input type="file" name="supplier_invoice_attachment">
                                        </div>

                                        <div class="full">
                                            <label>Invoice Lines</label>

                                            <?php for ($line = 0; $line < 6; $line++): ?>
                                                <div class="fin-line">
                                                    <select name="line_service_id[]">
                                                        <option value="">General / No Service</option>
                                                        <?php foreach ($financeBookingServices as $service): ?>
                                                            <?php if (empty($service['source_supplier_id'])) continue; ?>
                                                            <option value="<?= (int)$service['id']; ?>">
                                                                <?= e((string)($service['supplier_name'] ?? 'Supplier')); ?>
                                                                · <?= e((string)$service['title']); ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>

                                                    <input
                                                        name="line_description[]"
                                                        placeholder="Description"
                                                    >

                                                    <input
                                                        type="number"
                                                        name="line_quantity[]"
                                                        min=".01"
                                                        step=".01"
                                                        placeholder="Qty"
                                                    >

                                                    <input
                                                        type="number"
                                                        name="line_unit_cost[]"
                                                        min="0"
                                                        step=".01"
                                                        placeholder="Unit Cost"
                                                    >
                                                </div>
                                            <?php endfor; ?>
                                        </div>

                                        <div class="full">
                                            <label>Invoice Notes</label>
                                            <textarea name="invoice_notes"></textarea>
                                        </div>

                                        <div class="full">
                                            <button class="action-btn confirm" type="submit">
                                                <i class="fa-solid fa-plus"></i>
                                                Save Supplier Invoice
                                            </button>
                                        </div>
                                    </div>
                                </form>
                                <?php endif; ?>
                            </div>
                        </details>

                        <details class="fin-form">
                            <summary><i class="fa-solid fa-money-check-dollar"></i> Record Supplier Payment</summary>
                            <div class="inside">
                                <?php
                                $payableInvoices =
                                    array_values(
                                        array_filter(
                                            $financeInvoices,
                                            static fn($invoice) =>
                                                ($invoice['status'] ?? '') === 'approved'
                                                && (float)($invoice['outstanding_amount'] ?? 0) > .01
                                        )
                                    );
                                ?>

                                <?php if (!$payableInvoices): ?>
                                    <div class="request-box">No approved supplier invoice has an outstanding payable.</div>
                                <?php else: ?>
                                <form method="post">
                                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                    <input type="hidden" name="action" value="record_supplier_payment">

                                    <div class="fin-grid">
                                        <div class="full">
                                            <label>Approved Invoice *</label>
                                            <select name="supplier_invoice_id" required>
                                                <option value="">Select invoice</option>
                                                <?php foreach ($payableInvoices as $invoice): ?>
                                                    <option value="<?= (int)$invoice['id']; ?>">
                                                        <?= e((string)$invoice['company_name']); ?>
                                                        · <?= e((string)$invoice['invoice_number']); ?>
                                                        · Due <?= e(abdMoney((float)$invoice['outstanding_amount'], $finCurrency)); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>

                                        <div>
                                            <label>Amount *</label>
                                            <input type="number" name="supplier_payment_amount" min=".01" step=".01" required>
                                        </div>

                                        <div>
                                            <label>Payment Date *</label>
                                            <input type="date" name="supplier_payment_date" value="<?= e(date('Y-m-d')); ?>" required>
                                        </div>

                                        <div>
                                            <label>Method</label>
                                            <select name="supplier_payment_method">
                                                <?php foreach (tsFinPaymentMethods() as $value => $label): ?>
                                                    <option value="<?= e($value); ?>"><?= e($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>

                                        <div>
                                            <label>Reference / UTR</label>
                                            <input name="supplier_payment_reference">
                                        </div>

                                        <div class="full">
                                            <label>Notes</label>
                                            <textarea name="supplier_payment_notes"></textarea>
                                        </div>

                                        <div class="full">
                                            <button class="action-btn confirm" type="submit">
                                                <i class="fa-solid fa-money-bill-transfer"></i>
                                                Record Supplier Payment
                                            </button>
                                        </div>
                                    </div>
                                </form>
                                <?php endif; ?>
                            </div>
                        </details>

                        <details class="fin-form">
                            <summary><i class="fa-solid fa-receipt"></i> Add Actual Direct Cost</summary>
                            <div class="inside">
                                <form method="post" enctype="multipart/form-data">
                                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                    <input type="hidden" name="action" value="add_actual_direct_cost">

                                    <div class="fin-grid">
                                        <div>
                                            <label>Cost Type</label>
                                            <select name="direct_cost_type">
                                                <?php foreach (tsFinDirectCostTypes() as $value => $label): ?>
                                                    <option value="<?= e($value); ?>"><?= e($label); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>

                                        <div>
                                            <label>Amount *</label>
                                            <input type="number" name="direct_cost_amount" min=".01" step=".01" required>
                                        </div>

                                        <div class="full">
                                            <label>Description *</label>
                                            <input name="direct_cost_description" required>
                                        </div>

                                        <div>
                                            <label>Cost Date *</label>
                                            <input type="date" name="direct_cost_date" value="<?= e(date('Y-m-d')); ?>" required>
                                        </div>

                                        <div>
                                            <label>Attachment</label>
                                            <input type="file" name="direct_cost_attachment">
                                        </div>

                                        <div class="full">
                                            <label>Notes</label>
                                            <textarea name="direct_cost_notes"></textarea>
                                        </div>

                                        <div class="full">
                                            <button class="action-btn confirm" type="submit">
                                                <i class="fa-solid fa-plus"></i>
                                                Add Actual Cost
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </details>
                    </div>
                <?php endif; ?>

                <?php if ($financeInvoices): ?>
                    <div class="fin-list">
                        <strong style="color:#0f172a;">Supplier Invoices</strong>

                        <?php foreach ($financeInvoices as $invoice): ?>
                            <div class="fin-record">
                                <div class="fin-record-top">
                                    <div>
                                        <strong>
                                            <?= e((string)$invoice['company_name']); ?>
                                            · Invoice <?= e((string)$invoice['invoice_number']); ?>
                                        </strong>

                                        <small>
                                            <?= e(abdDate($invoice['invoice_date'], 'd M Y')); ?>
                                            <?php if (!empty($invoice['due_date'])): ?>
                                                · Due <?= e(abdDate($invoice['due_date'], 'd M Y')); ?>
                                            <?php endif; ?>
                                            · Net <?= e(abdMoney((float)$invoice['net_amount'], $finCurrency)); ?>
                                            · Tax <?= e(abdMoney((float)$invoice['tax_amount'], $finCurrency)); ?>
                                            · Other <?= e(abdMoney((float)$invoice['other_amount'], $finCurrency)); ?>
                                            · Total <strong><?= e(abdMoney((float)$invoice['total_amount'], $finCurrency)); ?></strong>
                                            · Paid <?= e(abdMoney((float)$invoice['paid_amount'], $finCurrency)); ?>
                                            · Outstanding <?= e(abdMoney((float)$invoice['outstanding_amount'], $finCurrency)); ?>
                                        </small>

                                        <?php
                                        $items =
                                            $financeInvoiceItems[
                                                (int)$invoice['id']
                                            ]
                                            ?? [];
                                        ?>

                                        <?php if ($items): ?>
                                            <small>
                                                <?php
                                                $parts = [];
                                                foreach ($items as $item) {
                                                    $parts[] =
                                                        (string)$item['description']
                                                        . ' '
                                                        . number_format(
                                                            (float)$item['line_cost'],
                                                            2
                                                        );
                                                }
                                                echo e(implode(' · ', $parts));
                                                ?>
                                            </small>
                                        <?php endif; ?>

                                        <?php if (!empty($invoice['attachment_path'])): ?>
                                            <small>
                                                <a href="<?= e(BASE_URL . ltrim((string)$invoice['attachment_path'], '/')); ?>" target="_blank">
                                                    <i class="fa-solid fa-paperclip"></i>
                                                    <?= e((string)($invoice['original_filename'] ?: 'Invoice Attachment')); ?>
                                                </a>
                                            </small>
                                        <?php endif; ?>
                                    </div>

                                    <div style="display:flex;gap:5px;align-items:center;flex-wrap:wrap;justify-content:flex-end;">
                                        <span class="fin-pill <?= e((string)$invoice['status']); ?>">
                                            <?= e(strtoupper((string)$invoice['status'])); ?>
                                        </span>

                                        <?php if (!$financeClosure && $invoice['status'] === 'received'): ?>
                                            <form method="post" onsubmit="return confirm('Approve this supplier invoice and include it in Actual Cost?');">
                                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                                <input type="hidden" name="action" value="approve_supplier_invoice">
                                                <input type="hidden" name="supplier_invoice_id" value="<?= (int)$invoice['id']; ?>">
                                                <button class="action-btn confirm" type="submit">Approve</button>
                                            </form>
                                        <?php endif; ?>

                                        <?php if (!$financeClosure && $invoice['status'] !== 'void'): ?>
                                            <form method="post" onsubmit="return confirm('Void this supplier invoice?');">
                                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                                <input type="hidden" name="action" value="void_supplier_invoice">
                                                <input type="hidden" name="supplier_invoice_id" value="<?= (int)$invoice['id']; ?>">
                                                <button class="action-btn danger" type="submit">Void</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($financeSupplierPayments): ?>
                    <div class="fin-list">
                        <strong style="color:#0f172a;">Supplier Payments</strong>

                        <?php foreach ($financeSupplierPayments as $supplierPayment): ?>
                            <div class="fin-record">
                                <div class="fin-record-top">
                                    <div>
                                        <strong>
                                            <?= e((string)$supplierPayment['company_name']); ?>
                                            · <?= e((string)$supplierPayment['invoice_number']); ?>
                                            · Settled <?= e(abdMoney((float)($supplierPayment['settlement_amount'] ?? $supplierPayment['amount']), $finCurrency)); ?>
                                        </strong>

                                        <small>
                                            <?= e(abdDate($supplierPayment['payment_date'], 'd M Y')); ?>
                                            · <?= e(tsFinPaymentMethods()[(string)$supplierPayment['payment_method']] ?? ucwords(str_replace('_', ' ', (string)$supplierPayment['payment_method']))); ?>
                                            · Transferred <?= e(abdMoney((float)($supplierPayment['transfer_amount'] ?? $supplierPayment['amount']), $finCurrency)); ?>
                                            <?php if (!empty($supplierPayment['tds_amount'])): ?>
                                                · TDS <?= e(abdMoney((float)$supplierPayment['tds_amount'], $finCurrency)); ?>
                                            <?php endif; ?>
                                            <?php if (!empty($supplierPayment['reference_number'])): ?>
                                                · Ref <?= e((string)$supplierPayment['reference_number']); ?>
                                            <?php endif; ?>
                                        </small>
                                    </div>

                                    <div style="display:flex;gap:5px;align-items:center;">
                                        <span class="fin-pill <?= e((string)$supplierPayment['status']); ?>">
                                            <?= e(strtoupper((string)$supplierPayment['status'])); ?>
                                        </span>

                                        <?php if (!empty($supplierPayment['voucher']) && ($supplierPayment['voucher']['status'] ?? '') === 'issued'): ?>
                                            <a class="action-btn" target="_blank" href="supplier-payment-voucher.php?id=<?= (int)$supplierPayment['voucher']['id']; ?>">Voucher</a>
                                        <?php endif; ?>
                                        <?php if (!$financeClosure && $supplierPayment['status'] === 'paid'): ?>
                                            <form method="post" onsubmit="return confirm('Void this supplier payment record?');">
                                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                                <input type="hidden" name="action" value="void_supplier_payment">
                                                <input type="hidden" name="supplier_payment_id" value="<?= (int)$supplierPayment['id']; ?>">
                                                <button class="action-btn danger" type="submit">Void</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($financeDirectCosts): ?>
                    <div class="fin-list">
                        <strong style="color:#0f172a;">Actual Direct Costs</strong>

                        <?php foreach ($financeDirectCosts as $directCost): ?>
                            <div class="fin-record">
                                <div class="fin-record-top">
                                    <div>
                                        <strong>
                                            <?= e(tsFinDirectCostTypes()[(string)$directCost['cost_type']] ?? ucwords(str_replace('_', ' ', (string)$directCost['cost_type']))); ?>
                                            · <?= e((string)$directCost['description']); ?>
                                            · <?= e(abdMoney((float)$directCost['amount'], $finCurrency)); ?>
                                        </strong>

                                        <small>
                                            <?= e(abdDate($directCost['cost_date'], 'd M Y')); ?>
                                            <?php if (!empty($directCost['notes'])): ?>
                                                · <?= e((string)$directCost['notes']); ?>
                                            <?php endif; ?>
                                        </small>

                                        <?php if (!empty($directCost['attachment_path'])): ?>
                                            <small>
                                                <a href="<?= e(BASE_URL . ltrim((string)$directCost['attachment_path'], '/')); ?>" target="_blank">
                                                    <i class="fa-solid fa-paperclip"></i>
                                                    <?= e((string)($directCost['original_filename'] ?: 'Cost Attachment')); ?>
                                                </a>
                                            </small>
                                        <?php endif; ?>
                                    </div>

                                    <div style="display:flex;gap:5px;align-items:center;">
                                        <span class="fin-pill <?= e((string)$directCost['status']); ?>">
                                            <?= e(strtoupper((string)$directCost['status'])); ?>
                                        </span>

                                        <?php if (!$financeClosure && $directCost['status'] === 'posted'): ?>
                                            <form method="post" onsubmit="return confirm('Void this actual direct cost?');">
                                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                                <input type="hidden" name="action" value="void_actual_direct_cost">
                                                <input type="hidden" name="actual_direct_cost_id" value="<?= (int)$directCost['id']; ?>">
                                                <button class="action-btn danger" type="submit">Void</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="fin-close">
                    <?php if ($financeClosure): ?>
                        <strong style="display:block;color:#047857;">
                            <i class="fa-solid fa-lock"></i>
                            Profitability Financially Closed
                        </strong>

                        <small style="display:block;margin-top:5px;color:#64748b;">
                            Closed <?= e(abdDate($financeClosure['closed_at'])); ?>
                            · Final Margin <?= e(abdMoney((float)$financeClosure['actual_margin'], $finCurrency)); ?>
                            · Supplier Paid <?= e(abdMoney((float)$financeClosure['supplier_paid'], $finCurrency)); ?>
                            · Customer Outstanding <?= e(abdMoney((float)$financeClosure['customer_outstanding'], $finCurrency)); ?>
                        </small>

                        <?php if (!empty($financeClosure['closure_note'])): ?>
                            <div class="request-box" style="margin-top:9px;">
                                <?= nl2br(e((string)$financeClosure['closure_note'])); ?>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <strong style="display:block;color:#1d4ed8;">
                            <i class="fa-solid fa-flag-checkered"></i>
                            Financial Closure
                        </strong>

                        <small style="display:block;margin-top:5px;color:#64748b;">
                            Closure freezes the final expected-vs-actual profitability snapshot and locks this Finance section from further edits.
                        </small>

                        <?php
                        $closureChecks =
                            (array)(
                                $financeClosureReadiness['checks']
                                ?? []
                            );

                        $closureLabels = [
                            'booking_completed' => 'Booking Completed',
                            'customer_fully_collected' => 'Customer Fully Collected',
                            'supplier_invoices_approved' => 'Invoices Approved / Voided',
                            'actual_supplier_cost_captured' => 'Actual Supplier Cost Captured',
                            'supplier_payables_cleared' => 'Supplier Payables Cleared',
                            'operations_ready' => 'Operations Ready',
                            'no_pending_amendments' => 'No Pending Amendment',
                            'no_pending_cancellation' => 'No Pending Cancellation',
                            'no_pending_customer_refunds' => 'No Pending Customer Refund',
                        ];
                        ?>

                        <div class="fin-close-grid">
                            <?php foreach ($closureLabels as $key => $label): ?>
                                <?php $done = !empty($closureChecks[$key]); ?>
                                <div class="fin-check <?= $done ? 'ok' : 'no'; ?>">
                                    <i class="fa-solid <?= $done ? 'fa-circle-check' : 'fa-clock'; ?>"></i>
                                    <?= e($label); ?>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <form method="post" style="margin-top:10px;" onsubmit="return confirm('Financially close this Booking? Finance records will be locked after closure.');">
                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                            <input type="hidden" name="action" value="close_booking_profitability">

                            <textarea
                                name="profitability_closure_note"
                                placeholder="Optional closure note"
                                style="width:100%;min-height:62px;margin-bottom:8px;"
                            ></textarea>

                            <button
                                class="action-btn confirm"
                                type="submit"
                                <?= empty($financeClosureReadiness['ready']) ? 'disabled style="opacity:.55;cursor:not-allowed;"' : ''; ?>
                            >
                                <i class="fa-solid fa-lock"></i>
                                Close Profitability
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>


    <?php endif; ?>

    <section class="card" id="customer-communication-center" style="scroll-margin-top:20px;">
        <div class="card-head">
            <div>
                <h3>Customer Communication & Automation</h3>
                <p>One Trip/Booking timeline for accepted quotation emails, post-booking email replies, WhatsApp handoffs, internal notes and due customer reminders.</p>
            </div>

            <?php if (
                function_exists('tsCommReady')
                && tsCommReady($pdo)
            ): ?>
                <a
                    class="head-btn"
                    href="<?= e(
                        BASE_URL
                        . 'admin-booking-communications.php?id='
                        . $bookingId
                    ); ?>"
                    style="border-color:#059669;background:#059669;color:#fff;"
                >
                    <i class="fa-solid fa-comments"></i>
                    Open Communication Center
                </a>
            <?php endif; ?>
        </div>

        <div class="card-body">
            <?php if (
                !function_exists('tsCommReady')
                || !tsCommReady($pdo)
            ): ?>
                <div class="request-box">
                    Import <strong>TRAVSCOPE_Customer_Communication_Automation_Center.sql</strong> to enable the Booking Communication Center.
                </div>
            <?php elseif (is_array($bookingCommunicationSummary)): ?>

                <div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-bottom:10px;">
                    <div style="padding:9px;border:1px solid #fed7aa;border-radius:10px;background:#fff7ed;">
                        <span style="display:block;color:#c2410c;font-size:8px;font-weight:900;text-transform:uppercase;">Due Messages</span>
                        <strong style="display:block;margin-top:4px;font-size:12px;color:#c2410c;">
                            <?= (int)$bookingCommunicationSummary['due']; ?>
                        </strong>
                    </div>

                    <div style="padding:9px;border:1px solid #dbeafe;border-radius:10px;background:#eff6ff;">
                        <span style="display:block;color:#1d4ed8;font-size:8px;font-weight:900;text-transform:uppercase;">Upcoming</span>
                        <strong style="display:block;margin-top:4px;font-size:12px;color:#1d4ed8;">
                            <?= (int)$bookingCommunicationSummary['upcoming']; ?>
                        </strong>
                    </div>

                    <div style="padding:9px;border:1px solid #a7f3d0;border-radius:10px;background:#ecfdf5;">
                        <span style="display:block;color:#047857;font-size:8px;font-weight:900;text-transform:uppercase;">Customer Replies</span>
                        <strong style="display:block;margin-top:4px;font-size:12px;color:#047857;">
                            <?= (int)$bookingCommunicationSummary['inbound']; ?>
                        </strong>
                    </div>

                    <div style="padding:9px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc;">
                        <span style="display:block;color:#64748b;font-size:8px;font-weight:900;text-transform:uppercase;">Last Booking Contact</span>
                        <strong style="display:block;margin-top:4px;font-size:10px;color:#334155;">
                            <?php if (!empty($bookingCommunicationSummary['last']['at_time'])): ?>
                                <?= e(abdDate($bookingCommunicationSummary['last']['at_time'])); ?>
                            <?php else: ?>
                                None yet
                            <?php endif; ?>
                        </strong>
                    </div>
                </div>

                <div class="request-box" style="background:#eff6ff;color:#1d4ed8;border-color:#bfdbfe;">
                    Automation jobs are prepared from payment installments, missing traveller documents, departure countdown, Final Voucher, Final Document Pack and completed-trip review follow-up. Email automation sends only when the optional CLI cron is configured; otherwise Admin can run due messages from the Communication Center.
                </div>
            <?php endif; ?>
        </div>
    </section>


    <section class="card" id="traveller-document-center" style="scroll-margin-top:20px;">
        <div class="card-head">
            <div>
                <h3>Traveller Documents & Trip File Center</h3>
                <p>Traveller roster, Passport/Visa/ID/Ticket/Insurance verification, expiry alerts and Final Trip Document Pack.</p>
            </div>

            <?php if ($bookingFinalDocumentPack): ?>
                <a
                    class="head-btn"
                    target="_blank"
                    href="<?= e(
                        BASE_URL
                        . 'booking-document-pack.php?pack='
                        . (int)$bookingFinalDocumentPack['id']
                    ); ?>"
                    style="border-color:#059669;background:#059669;color:#fff;"
                >
                    <i class="fa-solid fa-box-archive"></i>
                    <?= e((string)$bookingFinalDocumentPack['pack_code']); ?>
                </a>
            <?php endif; ?>
        </div>

        <div class="card-body">
            <?php if (
                !function_exists('tsDocReady')
                || !tsDocReady($pdo)
            ): ?>
                <div class="request-box">
                    Import <strong>TRAVSCOPE_Document_Traveller_File_Center.sql</strong> to enable Booking traveller documents.
                </div>
            <?php elseif (is_array($bookingDocumentSummary)): ?>

                <div style="display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin-bottom:10px;">
                    <div style="padding:9px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc;">
                        <span style="display:block;color:#64748b;font-size:8px;font-weight:900;text-transform:uppercase;">Traveller Roster</span>
                        <strong style="display:block;margin-top:4px;font-size:12px;">
                            <?= (int)$bookingDocumentSummary['active_travellers']; ?>
                            /
                            <?= (int)$bookingDocumentSummary['expected_travellers']; ?>
                        </strong>
                    </div>

                    <div style="padding:9px;border:1px solid #a7f3d0;border-radius:10px;background:#ecfdf5;">
                        <span style="display:block;color:#047857;font-size:8px;font-weight:900;text-transform:uppercase;">Verified</span>
                        <strong style="display:block;margin-top:4px;font-size:12px;color:#047857;">
                            <?= (int)$bookingDocumentSummary['verified_documents']; ?>
                        </strong>
                    </div>

                    <div style="padding:9px;border:1px solid #fed7aa;border-radius:10px;background:#fff7ed;">
                        <span style="display:block;color:#c2410c;font-size:8px;font-weight:900;text-transform:uppercase;">Waiting Review</span>
                        <strong style="display:block;margin-top:4px;font-size:12px;color:#c2410c;">
                            <?= (int)$bookingDocumentSummary['pending_documents']; ?>
                        </strong>
                    </div>

                    <div style="padding:9px;border:1px solid #fecaca;border-radius:10px;background:#fef2f2;">
                        <span style="display:block;color:#b91c1c;font-size:8px;font-weight:900;text-transform:uppercase;">Required Missing</span>
                        <strong style="display:block;margin-top:4px;font-size:12px;color:#b91c1c;">
                            <?= (int)$bookingDocumentSummary['missing_requirements']; ?>
                        </strong>
                    </div>

                    <div style="padding:9px;border:1px solid #dbeafe;border-radius:10px;background:#eff6ff;">
                        <span style="display:block;color:#1d4ed8;font-size:8px;font-weight:900;text-transform:uppercase;">Validity Alerts</span>
                        <strong style="display:block;margin-top:4px;font-size:12px;color:#1d4ed8;">
                            <?= (int)$bookingDocumentSummary['validity_alerts']; ?>
                        </strong>
                    </div>
                </div>

                <?php
                $docReadiness =
                    (array)(
                        $bookingDocumentSummary['pack_readiness']
                        ?? []
                    );
                ?>

                <?php if (empty($docReadiness['ready'])): ?>
                    <div class="request-box" style="background:#fff7ed;color:#9a3412;border-color:#fed7aa;">
                        <strong>Final Document Pack not ready.</strong>
                        <?php foreach ((array)($docReadiness['reasons'] ?? []) as $reason): ?>
                            <div>• <?= e((string)$reason); ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="request-box" style="background:#ecfdf5;color:#047857;border-color:#a7f3d0;">
                        <strong>Traveller document checklist is ready for Final Trip Document Pack.</strong>
                    </div>
                <?php endif; ?>

                <div style="display:flex;gap:7px;flex-wrap:wrap;margin-top:9px;">
                    <a
                        class="action-btn confirm"
                        href="<?= e(
                            BASE_URL
                            . 'admin-booking-documents.php?id='
                            . $bookingId
                        ); ?>"
                        style="text-decoration:none;"
                    >
                        <i class="fa-solid fa-passport"></i>
                        Open Document Center
                    </a>

                    <?php if ($bookingFinalDocumentPack): ?>
                        <a
                            class="action-btn"
                            target="_blank"
                            href="<?= e(
                                BASE_URL
                                . 'booking-document-pack.php?pack='
                                . (int)$bookingFinalDocumentPack['id']
                            ); ?>"
                            style="text-decoration:none;"
                        >
                            <i class="fa-solid fa-box-open"></i>
                            Open Final Pack
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>


    <section class="card" id="operations-readiness" style="scroll-margin-top:20px;">
        <div class="card-head">
            <div>
                <h3>Operations Readiness & Customer Voucher</h3>
                <p>Final pre-departure control after Booking and supplier procurement.</p>
            </div>

            <?php if ($operationsReadiness): ?>
                <span style="display:inline-flex;padding:6px 10px;border-radius:999px;background:<?= !empty($operationsReadiness['ready']) ? '#dcfce7' : '#fff7ed'; ?>;color:<?= !empty($operationsReadiness['ready']) ? '#166534' : '#c2410c'; ?>;font-size:10px;font-weight:900;">
                    <?= !empty($operationsReadiness['ready']) ? 'READY FOR TRAVEL' : (int)$operationsReadiness['percent'] . '% READY'; ?>
                </span>
            <?php endif; ?>
        </div>

        <div class="card-body">
            <?php if (
                !function_exists('tsOpsReady')
                || !tsOpsReady($pdo)
            ): ?>
                <div class="request-box">
                    Import <strong>TRAVSCOPE_Operations_Readiness_Vouchers.sql</strong> to enable operations readiness and versioned travel vouchers.
                </div>
            <?php else: ?>

                <?php
                $supplierSummary =
                    (array)(
                        $operationsReadiness['supplier_summary']
                        ?? []
                    );

                $autoChecks = [
                    [
                        'label' => 'Booking Status Confirmed',
                        'done' => !empty($operationsReadiness['booking_confirmed']),
                        'detail' => 'Current Booking status: ' . ucfirst((string)$booking['booking_status'])
                    ],
                    [
                        'label' => 'Supplier Services Confirmed',
                        'done' => !empty($operationsReadiness['supplier_services_confirmed']),
                        'detail' =>
                            (int)($supplierSummary['confirmed_supplier_services'] ?? 0)
                            . ' / '
                            . (int)($supplierSummary['total_supplier_services'] ?? 0)
                            . ' supplier-backed services confirmed'
                    ],
                    [
                        'label' => 'Final Customer Voucher Issued',
                        'done' => !empty($operationsReadiness['voucher_finalized']),
                        'detail' =>
                            !empty($operationsReadiness['latest_final_voucher'])
                                ? (string)$operationsReadiness['latest_final_voucher']['voucher_code']
                                : 'No final voucher yet'
                    ],
                ];
                ?>

                <div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px;margin-bottom:13px;">
                    <?php foreach ($autoChecks as $check): ?>
                        <div style="padding:11px;border:1px solid <?= $check['done'] ? '#a7f3d0' : '#fed7aa'; ?>;border-radius:12px;background:<?= $check['done'] ? '#ecfdf5' : '#fff7ed'; ?>;">
                            <strong style="display:block;color:<?= $check['done'] ? '#047857' : '#c2410c'; ?>;font-size:11px;">
                                <i class="fa-solid <?= $check['done'] ? 'fa-circle-check' : 'fa-clock'; ?>"></i>
                                <?= e($check['label']); ?>
                            </strong>
                            <small style="display:block;margin-top:4px;color:#64748b;line-height:1.45;">
                                <?= e($check['detail']); ?>
                            </small>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div style="height:8px;border-radius:999px;background:#e2e8f0;overflow:hidden;margin-bottom:15px;">
                    <div style="height:100%;width:<?= (int)($operationsReadiness['percent'] ?? 0); ?>%;background:linear-gradient(90deg,#2563eb,#059669);"></div>
                </div>

                <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                    <input type="hidden" name="action" value="save_operations_checklist">

                    <div style="display:grid;gap:8px;">
                        <?php foreach ($operationsChecklist as $check): ?>
                            <div style="display:grid;grid-template-columns:28px minmax(0,1fr) minmax(220px,.8fr);gap:9px;align-items:center;padding:9px 10px;border:1px solid #e2e8f0;border-radius:11px;background:#fbfdff;">
                                <input
                                    type="checkbox"
                                    name="operation_complete[<?= e((string)$check['check_key']); ?>]"
                                    value="1"
                                    <?= !empty($check['is_complete']) ? 'checked' : ''; ?>
                                    style="width:18px;height:18px;"
                                >

                                <div>
                                    <strong style="display:block;font-size:11px;color:#334155;">
                                        <?= e((string)$check['label']); ?>
                                    </strong>

                                    <?php if (!empty($check['completed_at'])): ?>
                                        <small style="display:block;margin-top:3px;color:#64748b;">
                                            Completed <?= e(abdDate($check['completed_at'])); ?>
                                        </small>
                                    <?php endif; ?>
                                </div>

                                <input
                                    name="operation_note[<?= e((string)$check['check_key']); ?>]"
                                    value="<?= e((string)($check['note'] ?? '')); ?>"
                                    placeholder="Optional verification note"
                                >
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div style="margin-top:10px;">
                        <button class="action-btn confirm" type="submit">
                            <i class="fa-solid fa-floppy-disk"></i>
                            Save Operations Checklist
                        </button>
                    </div>
                </form>

                <div style="margin-top:16px;padding-top:14px;border-top:1px solid #e2e8f0;">
                    <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                        <div>
                            <strong style="display:block;color:#0f172a;">Versioned Customer Travel Voucher</strong>
                            <small style="display:block;margin-top:4px;color:#64748b;max-width:650px;line-height:1.5;">
                                Customer-safe snapshot only. Supplier company names, supplier costs, margin and internal notes are never included.
                            </small>
                        </div>

                        <div style="display:flex;gap:7px;flex-wrap:wrap;">
                            <form method="post">
                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                <input type="hidden" name="action" value="generate_booking_voucher">
                                <input type="hidden" name="voucher_status" value="draft">

                                <button class="action-btn" type="submit">
                                    <i class="fa-solid fa-file-lines"></i>
                                    Generate Draft
                                </button>
                            </form>

                            <form method="post" onsubmit="return confirm('Generate a FINAL customer voucher from the current confirmed Booking services?');">
                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                <input type="hidden" name="action" value="generate_booking_voucher">
                                <input type="hidden" name="voucher_status" value="final">

                                <button
                                    class="action-btn confirm"
                                    type="submit"
                                    <?= empty($operationsReadiness['supplier_services_confirmed']) ? 'disabled style="opacity:.55;cursor:not-allowed;"' : ''; ?>
                                >
                                    <i class="fa-solid fa-ticket"></i>
                                    Generate Final Voucher
                                </button>
                            </form>
                        </div>
                    </div>

                    <?php if ($bookingVoucherVersions): ?>
                        <div style="display:grid;gap:7px;margin-top:11px;">
                            <?php foreach ($bookingVoucherVersions as $voucher): ?>
                                <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;padding:9px 10px;border:1px solid #e2e8f0;border-radius:10px;background:#fff;">
                                    <div>
                                        <strong style="display:block;font-size:11px;color:#334155;">
                                            <?= e((string)$voucher['voucher_code']); ?>
                                        </strong>

                                        <small style="display:block;margin-top:3px;color:#64748b;">
                                            Version <?= (int)$voucher['version_number']; ?>
                                            · <?= e(strtoupper((string)$voucher['status'])); ?>
                                            · <?= e(abdDate($voucher['created_at'])); ?>
                                        </small>
                                    </div>

                                    <a
                                        class="action-btn"
                                        href="<?= e(BASE_URL . 'booking-voucher.php?voucher=' . (int)$voucher['id']); ?>"
                                        target="_blank"
                                    >
                                        <i class="fa-solid fa-print"></i>
                                        Open / Print
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>


    <?php if ($bookingServiceSnapshots): ?>
    <section class="card" id="supplier-procurement">
        <div class="card-head">
            <div>
                <h3>Supplier Procurement</h3>
                <p>Post-booking confirmation. This is separate from the pre-booking RFQ/quotation stage.</p>
            </div>
            <?php if (
                function_exists('tsSupplierBookingProcurementReady')
                && tsSupplierBookingProcurementReady($pdo)
            ): ?>
                <span style="display:inline-flex;padding:6px 9px;border-radius:999px;background:#ecfdf5;color:#047857;font-size:9px;font-weight:900;">
                    PROCUREMENT READY
                </span>
            <?php endif; ?>
        </div>

        <div class="card-body">
            <?php if (
                !function_exists('tsSupplierBookingProcurementReady')
                || !tsSupplierBookingProcurementReady($pdo)
            ): ?>
                <div class="request-box">
                    Import <strong>TRAVSCOPE_Post_Booking_Supplier_Procurement.sql</strong> to enable supplier booking confirmations.
                </div>
            <?php else: ?>

                <?php
                $servicesBySupplier = [];

                foreach ($bookingServiceSnapshots as $service) {
                    $supplierId =
                        max(
                            0,
                            (int)(
                                $service['source_supplier_id']
                                ?? 0
                            )
                        );

                    if ($supplierId <= 0) {
                        continue;
                    }

                    if (!isset($servicesBySupplier[$supplierId])) {
                        $servicesBySupplier[$supplierId] = [
                            'supplier_id' => $supplierId,
                            'supplier_name' =>
                                (string)(
                                    $service['source_supplier_name']
                                    ?? ('Supplier #' . $supplierId)
                                ),
                            'services' => []
                        ];
                    }

                    $servicesBySupplier[$supplierId]['services'][] =
                        $service;
                }

                $ordersBySupplier = [];

                foreach ($supplierBookingOrders as $supplierOrder) {
                    $ordersBySupplier[
                        (int)$supplierOrder['supplier_id']
                    ] = $supplierOrder;
                }
                ?>

                <?php if (!$servicesBySupplier): ?>
                    <div class="request-box">
                        No supplier-backed Booking services are available yet. Select supplier costs before quotation acceptance, or assign suppliers during operations.
                    </div>
                <?php endif; ?>

                <div style="display:grid;gap:12px;">
                    <?php foreach ($servicesBySupplier as $supplierGroup): ?>
                        <?php
                        $supplierId =
                            (int)$supplierGroup['supplier_id'];

                        $supplierOrder =
                            $ordersBySupplier[$supplierId]
                            ?? null;

                        $orderId =
                            $supplierOrder
                                ? (int)$supplierOrder['id']
                                : 0;

                        $orderItems =
                            $orderId > 0
                                ? (
                                    $supplierBookingOrderItems[$orderId]
                                    ?? []
                                )
                                : [];

                        $orderMessages =
                            $orderId > 0
                                ? (
                                    $supplierBookingOrderMessages[$orderId]
                                    ?? []
                                )
                                : [];

                        $groupCost = 0.0;

                        foreach ($supplierGroup['services'] as $service) {
                            $groupCost +=
                                max(
                                    0,
                                    (float)(
                                        $service['internal_supplier_cost']
                                        ?? 0
                                    )
                                );
                        }

                        $status =
                            $supplierOrder
                                ? (string)$supplierOrder['status']
                                : 'not_sent';

                        $statusColor =
                            $status === 'supplier_confirmed'
                                ? '#047857'
                                : (
                                    in_array(
                                        $status,
                                        [
                                            'rejected',
                                            'alternative_required'
                                        ],
                                        true
                                    )
                                        ? '#b91c1c'
                                        : '#c2410c'
                                );

                        $statusBg =
                            $status === 'supplier_confirmed'
                                ? '#ecfdf5'
                                : (
                                    in_array(
                                        $status,
                                        [
                                            'rejected',
                                            'alternative_required'
                                        ],
                                        true
                                    )
                                        ? '#fef2f2'
                                        : '#fff7ed'
                                );
                        ?>

                        <div style="border:1px solid #dbe3ee;border-radius:14px;padding:13px;background:#fbfdff;">
                            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;">
                                <div>
                                    <strong style="display:block;font-size:14px;color:#0f172a;">
                                        <?= e((string)$supplierGroup['supplier_name']); ?>
                                    </strong>

                                    <small style="display:block;margin-top:4px;color:#64748b;">
                                        <?= count($supplierGroup['services']); ?> booked service<?= count($supplierGroup['services']) === 1 ? '' : 's'; ?>
                                        · Expected Supplier Cost <?= e(abdMoney($groupCost, (string)$booking['currency'])); ?>
                                        <?php if ($supplierOrder): ?>
                                            · <?= e((string)$supplierOrder['order_code']); ?>
                                        <?php endif; ?>
                                    </small>
                                </div>

                                <span style="display:inline-flex;padding:5px 8px;border-radius:999px;background:<?= e($statusBg); ?>;color:<?= e($statusColor); ?>;font-size:9px;font-weight:900;">
                                    <?= e(strtoupper(str_replace('_', ' ', $status))); ?>
                                </span>
                            </div>

                            <div style="display:grid;gap:7px;margin-top:10px;">
                                <?php foreach ($supplierGroup['services'] as $service): ?>
                                    <div style="display:flex;justify-content:space-between;gap:10px;padding:8px 9px;border-radius:10px;background:#fff;border:1px solid #eef2f7;">
                                        <div>
                                            <strong style="display:block;font-size:11px;color:#334155;">
                                                <?= e((string)$service['title']); ?>
                                            </strong>
                                            <small style="display:block;margin-top:3px;color:#64748b;">
                                                <?= e(ucwords(str_replace('_', ' ', (string)$service['service_type']))); ?>
                                                <?php if (!empty($service['service_date_from'])): ?>
                                                    · <?= e(abdDate($service['service_date_from'], 'd M Y')); ?>
                                                <?php endif; ?>
                                            </small>
                                        </div>

                                        <span style="font-size:9px;font-weight:900;color:#475569;">
                                            <?= e(strtoupper(str_replace('_', ' ', (string)$service['procurement_status']))); ?>
                                        </span>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <?php if (!$supplierOrder): ?>
                                <details style="margin-top:10px;border:1px dashed #cbd5e1;border-radius:11px;background:#fff;">
                                    <summary style="cursor:pointer;padding:10px 11px;font-size:10px;font-weight:900;color:#1d4ed8;list-style:none;">
                                        <i class="fa-solid fa-paper-plane"></i>
                                        Send Booking Confirmation to Supplier
                                    </summary>

                                    <form method="post" style="padding:0 11px 11px;" onsubmit="return confirm('Send post-booking confirmation request to this supplier?');">
                                        <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                        <input type="hidden" name="action" value="create_supplier_booking_order">
                                        <input type="hidden" name="supplier_id" value="<?= $supplierId; ?>">

                                        <?php foreach ($supplierGroup['services'] as $service): ?>
                                            <input type="hidden" name="service_ids[]" value="<?= (int)$service['id']; ?>">
                                        <?php endforeach; ?>

                                        <textarea
                                            name="confirmation_request_text"
                                            placeholder="Optional message: Please block/confirm the services at agreed rates and share confirmation references."
                                            style="width:100%;min-height:75px;margin-bottom:8px;"
                                        ></textarea>

                                        <button class="action-btn confirm" type="submit">
                                            <i class="fa-solid fa-paper-plane"></i>
                                            Send Supplier Confirmation
                                        </button>
                                    </form>
                                </details>
                            <?php else: ?>
                                <div style="display:flex;gap:7px;flex-wrap:wrap;margin-top:10px;">
                                    <form method="post">
                                        <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                        <input type="hidden" name="action" value="resend_supplier_booking_order">
                                        <input type="hidden" name="supplier_booking_order_id" value="<?= $orderId; ?>">
                                        <button class="action-btn confirm" type="submit">
                                            <i class="fa-solid fa-envelope"></i>
                                            Email Follow-up
                                        </button>
                                    </form>

                                    <details style="flex:1;min-width:260px;border:1px dashed #cbd5e1;border-radius:10px;background:#fff;">
                                        <summary style="cursor:pointer;padding:8px 10px;font-size:10px;font-weight:900;color:#475569;list-style:none;">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                            Record External Supplier Response
                                        </summary>

                                        <form method="post" style="padding:0 10px 10px;display:grid;grid-template-columns:1fr 1fr;gap:7px;">
                                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                            <input type="hidden" name="action" value="record_supplier_booking_response">
                                            <input type="hidden" name="supplier_booking_order_id" value="<?= $orderId; ?>">

                                            <select name="response_status" style="width:100%;">
                                                <option value="confirmed">Confirmed</option>
                                                <option value="alternative_required">Alternative Required</option>
                                                <option value="rejected">Rejected / Unable</option>
                                            </select>

                                            <input
                                                name="supplier_confirmation_ref"
                                                placeholder="Confirmation reference"
                                            >

                                            <textarea
                                                name="supplier_confirmation_note"
                                                placeholder="Supplier response / notes"
                                                style="grid-column:1/-1;min-height:65px;"
                                            ></textarea>

                                            <button class="action-btn confirm" style="grid-column:1/-1;" type="submit">
                                                Save Supplier Response
                                            </button>
                                        </form>
                                    </details>
                                </div>

                                <?php if (
                                    !empty($supplierOrder['supplier_confirmation_ref'])
                                    || !empty($supplierOrder['supplier_confirmation_note'])
                                ): ?>
                                    <div class="request-box" style="margin-top:10px;">
                                        <?php if (!empty($supplierOrder['supplier_confirmation_ref'])): ?>
                                            <strong>Confirmation Ref:</strong>
                                            <?= e((string)$supplierOrder['supplier_confirmation_ref']); ?><br>
                                        <?php endif; ?>

                                        <?php if (!empty($supplierOrder['supplier_confirmation_note'])): ?>
                                            <?= nl2br(e((string)$supplierOrder['supplier_confirmation_note'])); ?>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ($orderMessages): ?>
                                    <details style="margin-top:10px;">
                                        <summary style="cursor:pointer;font-size:10px;font-weight:900;color:#475569;">
                                            Conversation & Activity (<?= count($orderMessages); ?>)
                                        </summary>

                                        <div style="display:grid;gap:7px;margin-top:8px;">
                                            <?php foreach ($orderMessages as $message): ?>
                                                <div style="padding:8px 9px;border-radius:9px;background:<?= $message['sender_type'] === 'supplier' ? '#ecfdf5' : '#eff6ff'; ?>;font-size:10px;line-height:1.5;">
                                                    <strong><?= e(ucfirst((string)$message['sender_type'])); ?></strong>
                                                    · <?= e((string)$message['channel']); ?>
                                                    · <?= e(abdDate($message['sent_at'])); ?>
                                                    <div style="margin-top:4px;">
                                                        <?= nl2br(e((string)$message['message'])); ?>
                                                    </div>

                                                    <?php if (!empty($message['attachment_path'])): ?>
                                                        <a
                                                            href="<?= e(BASE_URL . ltrim((string)$message['attachment_path'], '/')); ?>"
                                                            target="_blank"
                                                            style="display:inline-block;margin-top:5px;"
                                                        >
                                                            <i class="fa-solid fa-paperclip"></i>
                                                            <?= e((string)($message['original_filename'] ?: 'Attachment')); ?>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </details>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>


    <section class="card">
        <div class="card-head">
            <div>
                <h3>Booked Service Snapshot</h3>
                <p>Frozen from the Trip at quotation acceptance. Supplier selection is not treated as post-booking confirmation.</p>
            </div>
        </div>

        <div class="card-body">
            <div style="display:grid;gap:10px;">
                <?php foreach ($bookingServiceSnapshots as $service): ?>
                    <div style="display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;padding:12px;border:1px solid #e2e8f0;border-radius:13px;background:#fbfdff;">
                        <div>
                            <strong style="display:block;color:#0f172a;">
                                <?= e((string)$service['title']); ?>
                            </strong>
                            <small style="display:block;margin-top:4px;color:#64748b;">
                                <?= e(ucwords(str_replace('_', ' ', (string)$service['service_type']))); ?>
                                <?php if (!empty($service['destination_name'])): ?>
                                    · <?= e((string)$service['destination_name']); ?>
                                <?php endif; ?>
                                <?php if (!empty($service['service_date_from'])): ?>
                                    · <?= e(abdDate($service['service_date_from'], 'd M Y')); ?>
                                    <?php if (!empty($service['service_date_to']) && $service['service_date_to'] !== $service['service_date_from']): ?>
                                        – <?= e(abdDate($service['service_date_to'], 'd M Y')); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </small>

                            <?php if (!empty($service['specifications'])): ?>
                                <div style="margin-top:7px;color:#475569;font-size:11px;line-height:1.55;">
                                    <?= nl2br(e((string)$service['specifications'])); ?>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($service['source_supplier_name'])): ?>
                                <small style="display:block;margin-top:7px;color:#1d4ed8;font-weight:800;">
                                    Supplier: <?= e((string)$service['source_supplier_name']); ?>
                                    · Expected Cost <?= e(abdMoney((float)$service['internal_supplier_cost'], (string)$booking['currency'])); ?>
                                </small>
                            <?php endif; ?>
                        </div>

                        <div>
                            <span style="display:inline-flex;padding:5px 8px;border-radius:999px;background:<?= $service['procurement_status']==='confirmed' ? '#dcfce7' : '#fff7ed'; ?>;color:<?= $service['procurement_status']==='confirmed' ? '#166534' : '#c2410c'; ?>;font-size:9px;font-weight:900;">
                                <?= e(strtoupper(str_replace('_', ' ', (string)$service['procurement_status']))); ?>
                            </span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <?php endif; ?>


    <section class="card">

        <div class="card-head">
            <div>
                <h3>Special Request</h3>
                <p>Notes submitted by the customer during booking.</p>
            </div>
        </div>

        <div class="card-body">

            <?php if (!empty(trim((string)$booking['special_request']))): ?>

                <div class="request-box"><?= e($booking['special_request']); ?></div>

            <?php else: ?>

                <div class="final-note">
                    <i class="fa-regular fa-message"></i>
                    No special request was submitted for this booking.
                </div>

            <?php endif; ?>

        </div>

    </section>


    <section class="card">

        <div class="card-head">

            <div>
                <h3>Payment History</h3>
                <p>All payment attempts recorded against this booking.</p>
            </div>

            <a
                href="<?= e(
                    BASE_URL .
                    'admin-payments.php?booking_id=' .
                    $bookingId
                ); ?>"
                class="head-btn"
            >
                View Payments
            </a>

        </div>

        <div class="card-body">

            <?php if ($payments): ?>

                <?php foreach ($payments as $payment): ?>

                    <div class="payment-item">

                        <div class="payment-top">

                            <div>

                                <div class="payment-title">
                                    Payment #<?= (int)$payment['id']; ?>
                                </div>

                                <div class="payment-meta">

                                    <span>
                                        <i class="fa-regular fa-calendar"></i>
                                        <?= e(abdDate($payment['created_at'])); ?>
                                    </span>

                                    <?php if (!empty($payment['payment_method'])): ?>
                                        <span>
                                            <i class="fa-solid fa-wallet"></i>
                                            <?= e($payment['payment_method']); ?>
                                        </span>
                                    <?php endif; ?>

                                    <?php if (!empty($payment['payment_gateway'])): ?>
                                        <span>
                                            <i class="fa-solid fa-building-columns"></i>
                                            <?= e($payment['payment_gateway']); ?>
                                        </span>
                                    <?php endif; ?>

                                </div>

                            </div>

                            <div>

                                <div class="payment-amount">
                                    <?= e(
                                        abdMoney(
                                            $payment['amount'],
                                            $payment['currency']
                                        )
                                    ); ?>
                                </div>

                                <span
                                    class="badge badge-<?= e(
                                        abdPaymentClass(
                                            $payment['status']
                                        )
                                    ); ?>"
                                    style="margin-top:5px;margin-left:auto;"
                                >
                                    <?= e(ucfirst($payment['status'])); ?>
                                </span>

                            </div>

                        </div>

                        <?php if (!empty($payment['transaction_id'])): ?>

                            <div class="payment-id">
                                <strong>Transaction / UTR:</strong>
                                <?= e($payment['transaction_id']); ?>
                            </div>

                        <?php endif; ?>

                        <?php if (!empty($payment['paid_at'])): ?>

                            <div class="payment-id">
                                <strong>Paid At:</strong>
                                <?= e(abdDate($payment['paid_at'])); ?>
                            </div>

                        <?php endif; ?>

                    </div>

                <?php endforeach; ?>

            <?php else: ?>

                <div class="final-note">
                    <i class="fa-solid fa-circle-info"></i>
                    No payment record has been created for this booking yet.
                </div>

            <?php endif; ?>

        </div>

    </section>

</div>


<aside>

    <section class="card">

        <div class="card-head">
            <div>
                <h3>Payment Summary</h3>
                <p>Current booking balance.</p>
            </div>
        </div>

        <div class="card-body">

            <div class="money-grid">

                <div class="money-box">
                    <span>Total</span>
                    <strong>
                        <?= e(abdMoney($totalAmount, $booking['currency'])); ?>
                    </strong>
                </div>

                <div class="money-box">
                    <span><?= $booking['booking_status'] === 'cancelled' ? 'Net Retained' : 'Paid'; ?></span>
                    <strong>
                        <?= e(abdMoney($paidAmount, $booking['currency'])); ?>
                    </strong>
                </div>

                <div class="money-box balance">
                    <span><?= $booking['booking_status'] === 'cancelled' ? 'Collection' : 'Balance'; ?></span>
                    <strong>
                        <?= $booking['booking_status'] === 'cancelled' ? 'CLOSED' : e(abdMoney($balanceAmount, $booking['currency'])); ?>
                    </strong>
                </div>

            </div>

            <div class="progress">
                <div style="width:<?= number_format($paidPercent, 2, '.', ''); ?>%;"></div>
            </div>

            <div class="progress-text">
                <span><?= $booking['booking_status'] === 'cancelled' ? 'Cancelled — payment collection closed' : number_format($paidPercent, 0) . '% received'; ?></span>
                <span>
                    <?= e(ucfirst($booking['payment_status'])); ?>
                </span>
            </div>

            <?php if ($successfulPaymentTotal > 0): ?>
                <div class="final-note" style="margin-top:13px;">
                    Successful payment records total:
                    <strong><?= e(abdMoney($successfulPaymentTotal, $booking['currency'])); ?></strong>
                </div>
            <?php endif; ?>

        </div>

    </section>

    <?php if (!empty($billingReceipts)): ?>
    <?php
        $latestVerifiedReceipt = $billingReceipts[0];
        $latestPdfBase = BASE_URL . 'payment-receipt.php?receipt=' . (int)$latestVerifiedReceipt['id'] . '&format=pdf';
    ?>
    <section class="card" id="verified-payment-receipts" style="border:1px solid #bbf7d0;overflow:hidden;">
        <div class="card-head" style="background:linear-gradient(110deg,#ecfdf5,#eff6ff);">
            <div>
                <h3><i class="fa-solid fa-file-pdf" style="color:#059669;"></i> Customer Payment Receipt PDFs</h3>
                <p>Preview or download the exact PDF format emailed after a verified payment.</p>
            </div>
            <span style="font-size:10px;font-weight:800;color:#047857;background:#d1fae5;padding:6px 10px;border-radius:999px;">
                <?= count($billingReceipts); ?> VERIFIED
            </span>
        </div>
        <div class="card-body" style="padding:13px;">
            <div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:8px;margin-bottom:9px;">
                <div>
                    <strong id="tsReceiptPdfName" style="display:block;color:#0f172a;font-size:12px;">
                        <?= e((string)$latestVerifiedReceipt['receipt_code']); ?>
                    </strong>
                    <small style="display:block;margin-top:4px;font-size:10px;color:#64748b;">Only approved payments produce money receipts. Select a receipt below to preview it.</small>
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;">
                    <a id="tsReceiptPdfNewTab" href="<?= e($latestPdfBase); ?>" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:5px;padding:8px 10px;border-radius:8px;background:#eff6ff;color:#1d4ed8;text-decoration:none;font-weight:800;font-size:10px;">
                        <i class="fa-solid fa-up-right-from-square"></i> Open PDF
                    </a>
                    <a id="tsReceiptPdfDownload" href="<?= e($latestPdfBase . '&download=1'); ?>" style="display:inline-flex;align-items:center;gap:5px;padding:8px 10px;border-radius:8px;background:#059669;color:#fff;text-decoration:none;font-weight:800;font-size:10px;">
                        <i class="fa-solid fa-download"></i> Download PDF
                    </a>
                </div>
            </div>
            <details class="receipt-preview-details">
                <summary>
                    <span><i class="fa-regular fa-file-pdf"></i> Preview selected receipt</span>
                    <span class="receipt-preview-hint">Open viewer</span>
                </summary>
                <div class="receipt-preview-shell">
                    <iframe id="tsReceiptPdfFrame" title="Verified customer payment receipt PDF preview"
                        src="<?= e($latestPdfBase); ?>" loading="lazy"></iframe>
                </div>
            </details>
            <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:10px;">
                <?php foreach ($billingReceipts as $receipt): ?>
                    <?php $thisPdf = BASE_URL . 'payment-receipt.php?receipt=' . (int)$receipt['id'] . '&format=pdf'; ?>
                    <button type="button" class="ts-receipt-choice"
                        data-pdf="<?= e($thisPdf); ?>"
                        data-download="<?= e($thisPdf . '&download=1'); ?>"
                        data-receipt="<?= e((string)$receipt['receipt_code']); ?>"
                        style="cursor:pointer;border:1px solid #a7f3d0;border-radius:9px;background:#f0fdf4;color:#065f46;padding:9px 10px;text-align:left;font-size:10px;font-weight:800;">
                        <i class="fa-solid fa-receipt"></i> <?= e((string)$receipt['receipt_code']); ?><br>
                        <span style="font-weight:600;font-size:9px;"><?= e(abdMoney((float)$receipt['amount'], (string)$receipt['currency'])); ?></span>
                    </button>
                <?php endforeach; ?>
            </div>
            <small style="display:block;color:#64748b;font-size:9px;margin-top:9px;line-height:1.5;">V24.35 onward: automatic verified-payment emails attach this same PDF. Earlier verified receipts remain viewable here, but older emails were sent as View/Print links.</small>
        </div>
    </section>
    <script>
    (() => {
        const viewer = document.getElementById('tsReceiptPdfFrame');
        const label = document.getElementById('tsReceiptPdfName');
        const link = document.getElementById('tsReceiptPdfNewTab');
        const download = document.getElementById('tsReceiptPdfDownload');
        document.querySelectorAll('.ts-receipt-choice').forEach(button => {
            button.addEventListener('click', () => {
                const url = button.dataset.pdf;
                if (!url) return;
                viewer.src = url;
                label.textContent = button.dataset.receipt || 'Verified payment receipt';
                link.href = url;
                download.href = button.dataset.download || url;
                document.querySelectorAll('.ts-receipt-choice').forEach(other => {
                    other.style.background = other === button ? '#d1fae5' : '#f0fdf4';
                    other.style.borderColor = other === button ? '#059669' : '#a7f3d0';
                });
            });
        });
    })();
    </script>
    <?php endif; ?>

    <?php if ($balanceAmount > .01 && strtolower((string)$booking['booking_status']) !== 'cancelled'): ?>
    <section class="card payment-collect-card" id="payment-collection">
        <div class="card-head">
            <div>
                <h3>Collect Customer Payment</h3>
                <p>Choose how much to collect now, then generate or send a secure payment link.</p>
            </div>
            <span class="payment-collect-badge"><i class="fa-solid fa-link"></i> PAYMENT LINK</span>
        </div>
        <div class="card-body">
            <form method="post" id="quickPaymentCollectionForm">
                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                <input type="hidden" name="action" value="create_quick_payment_request">

                <div class="pay-choice-grid">
                    <label class="pay-choice advance">
                        <input type="radio" name="payment_request_mode" value="advance" checked>
                        <strong><i class="fa-solid fa-seedling"></i> Advance Payment</strong>
                        <small>Collect a chosen percentage now; keep the remaining balance scheduled.</small>
                    </label>
                    <label class="pay-choice half">
                        <input type="radio" name="payment_request_mode" value="half">
                        <strong><i class="fa-solid fa-circle-half-stroke"></i> 50% Payment</strong>
                        <small>Collect exactly 50% of the current outstanding balance.</small>
                    </label>
                    <label class="pay-choice full">
                        <input type="radio" name="payment_request_mode" value="full">
                        <strong><i class="fa-solid fa-circle-check"></i> Full Payment</strong>
                        <small>Collect the entire current outstanding balance.</small>
                    </label>
                    <label class="pay-choice custom">
                        <input type="radio" name="payment_request_mode" value="custom">
                        <strong><i class="fa-solid fa-sliders"></i> Custom Amount</strong>
                        <small>Enter an exact amount to collect now.</small>
                    </label>
                </div>

                <div class="pay-control-grid">
                    <div class="pay-control" id="advancePercentControl">
                        <label>Advance Percentage</label>
                        <input type="number" name="payment_request_advance_percent" id="paymentRequestAdvancePercent" min="1" max="99" step="1" value="25">
                    </div>
                    <div class="pay-control" id="customAmountControl" style="display:none;">
                        <label>Custom Amount</label>
                        <input type="number" name="payment_request_custom_amount" id="paymentRequestCustomAmount" min="0.01" step="0.01" placeholder="Enter amount">
                    </div>
                    <div class="pay-control">
                        <label>Secure Link Validity</label>
                        <select name="payment_link_valid_days" id="paymentLinkValidDays">
                            <option value="3">3 Days</option>
                            <option value="7" selected>7 Days</option>
                            <option value="14">14 Days</option>
                            <option value="30">30 Days</option>
                        </select>
                    </div>
                </div>

                <div class="pay-preview">
                    <span>PAYMENT TO COLLECT NOW</span>
                    <strong id="paymentRequestPreview"><?= e(abdMoney(round($balanceAmount * .25, 2), $booking['currency'])); ?></strong>
                </div>

                <div class="pay-action-row">
                    <button class="pay-send generate" type="submit" name="send_channel" value="generate"><i class="fa-solid fa-link"></i> Generate Link</button>
                    <button class="pay-send email" type="submit" name="send_channel" value="email"><i class="fa-solid fa-envelope"></i> Email Payment Link</button>
                    <button class="pay-send wa" type="submit" name="send_channel" value="whatsapp"><i class="fa-brands fa-whatsapp"></i> WhatsApp Payment Link</button>
                </div>
                <small style="display:block;margin-top:7px;color:#64748b;font-size:8px;line-height:1.45;">A new quick request becomes the active payment schedule. Any previous schedule remains preserved in Billing history. Payments still require the normal TRAVSCOPE verification process.</small>
            </form>

            <?php if ($quickPaymentRequest): ?>
                <div class="generated-pay-link">
                    <strong><?= e((string)($quickPaymentRequest['title'] ?? 'Payment Request')); ?> · <?= e(abdMoney((float)($quickPaymentRequest['amount'] ?? 0), (string)$booking['currency'])); ?></strong>
                    <div class="generated-link-row">
                        <input type="text" id="generatedPaymentLink" value="<?= e((string)($quickPaymentRequest['url'] ?? '')); ?>" readonly>
                        <button type="button" onclick="navigator.clipboard.writeText(document.getElementById('generatedPaymentLink').value).then(()=>this.textContent='Copied')"><i class="fa-regular fa-copy"></i> Copy Link</button>
                    </div>
                    <small style="display:block;margin-top:6px;color:#047857;font-size:8px;">Link valid for <?= (int)($quickPaymentRequest['expires_in_days'] ?? 7); ?> day(s). The customer can open this signed link without logging in.</small>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>


    <section class="card">

        <div class="card-head">
            <div>
                <h3>Booking Status</h3>
                <p>Move the reservation through its workflow.</p>
            </div>
        </div>

        <div class="card-body">

            <div style="margin-bottom:13px;display:flex;gap:6px;flex-wrap:wrap;">

                <span class="badge badge-<?= e(abdBookingClass($booking['booking_status'])); ?>">
                    <?= e(ucfirst($booking['booking_status'])); ?>
                </span>

                <span class="badge badge-<?= e(abdPaymentClass($booking['payment_status'])); ?>">
                    <?= e(ucfirst($booking['payment_status'])); ?> payment
                </span>

            </div>


            <?php if ($booking['booking_status'] === 'pending'): ?>

                <div class="status-actions">

                    <form method="post" onsubmit="return confirm('Confirm this booking?');">

                        <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                        <input type="hidden" name="booking_id" value="<?= $bookingId; ?>">
                        <input type="hidden" name="action" value="change_booking_status">
                        <input type="hidden" name="new_status" value="confirmed">

                        <button type="submit" class="action-btn confirm">
                            <i class="fa-solid fa-check"></i>
                            Confirm Booking
                        </button>

                    </form>

                    <form method="post" onsubmit="return confirm('Cancel this booking?');">

                        <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                        <input type="hidden" name="booking_id" value="<?= $bookingId; ?>">
                        <input type="hidden" name="action" value="change_booking_status">
                        <input type="hidden" name="new_status" value="cancelled">

                        <button type="submit" class="action-btn cancel">
                            <i class="fa-solid fa-xmark"></i>
                            Cancel
                        </button>

                    </form>

                </div>

            <?php elseif ($booking['booking_status'] === 'confirmed'): ?>

                <div class="status-actions">

                    <?php if (function_exists('tsExecReady') && tsExecReady($pdo)): ?>
                        <a class="action-btn complete" href="#travel-execution">
                            <i class="fa-solid fa-route"></i>
                            Complete in Travel Execution
                        </a>
                    <?php else: ?>
                        <form method="post" onsubmit="return confirm('Mark this trip as completed?');">

                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                            <input type="hidden" name="booking_id" value="<?= $bookingId; ?>">
                            <input type="hidden" name="action" value="change_booking_status">
                            <input type="hidden" name="new_status" value="completed">

                            <button type="submit" class="action-btn complete">
                                <i class="fa-solid fa-flag-checkered"></i>
                                Mark Completed
                            </button>

                        </form>
                    <?php endif; ?>

                    <form method="post" onsubmit="return confirm('Cancel this confirmed booking?');">

                        <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                        <input type="hidden" name="booking_id" value="<?= $bookingId; ?>">
                        <input type="hidden" name="action" value="change_booking_status">
                        <input type="hidden" name="new_status" value="cancelled">

                        <button type="submit" class="action-btn cancel">
                            <i class="fa-solid fa-ban"></i>
                            Cancel
                        </button>

                    </form>

                </div>

            <?php else: ?>

                <div class="final-note">

                    <?php if ($booking['booking_status'] === 'completed'): ?>
                        <i class="fa-solid fa-circle-check"></i>
                        This trip is completed. The booking is now in a final state.
                    <?php else: ?>
                        <i class="fa-solid fa-ban"></i>
                        This booking is cancelled. No further booking-status change is allowed.<br>
                        <a href="<?= e(BASE_URL . 'admin-cancellations.php?search=' . urlencode((string)$booking['booking_number'])); ?>" style="display:inline-flex;align-items:center;gap:7px;margin-top:10px;border-radius:9px;background:#fef3c7;color:#92400e;padding:9px 12px;font-weight:900;text-decoration:none;"><i class="fa-solid fa-scale-balanced"></i> Open Cancellation &amp; Refund Review</a>
                    <?php endif; ?>

                </div>

            <?php endif; ?>

        </div>

    </section>


    <section class="card">

        <div class="card-head">
            <div>
                <h3>Quick Actions</h3>
                <p>Useful links for this reservation.</p>
            </div>
        </div>

        <div class="card-body">

            <div class="quick-links">

                <a
                    href="<?= e(
                        BASE_URL .
                        'admin-payments.php?booking_id=' .
                        $bookingId
                    ); ?>"
                    class="quick-link"
                >
                    <i class="fa-solid fa-credit-card"></i>
                    Payments
                </a>

                <?php if (!empty($booking['user_id'])): ?>

                    <a
                        href="<?= e(
                            BASE_URL .
                            'admin-user-details.php?id=' .
                            (int)$booking['user_id']
                        ); ?>"
                        class="quick-link"
                    >
                        <i class="fa-solid fa-user"></i>
                        Customer
                    </a>

                <?php endif; ?>

                <?php if (!empty($booking['package_slug'])): ?>

                    <a
                        href="<?= e(
                            BASE_URL .
                            'package-details.php?slug=' .
                            urlencode($booking['package_slug'])
                        ); ?>"
                        target="_blank"
                        class="quick-link"
                    >
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        Package
                    </a>

                <?php endif; ?>

                <a
                    href="mailto:<?= e($booking['customer_email']); ?>"
                    class="quick-link"
                >
                    <i class="fa-regular fa-envelope"></i>
                    Email
                </a>

            </div>

        </div>

    </section>

</aside>

</div>

</main>

</div>


<script>

document.querySelectorAll('form[method="post"]').forEach(function(form){

    form.addEventListener('submit', function(){

        const button = this.querySelector('button[type="submit"]');

        if (!button) {
            return;
        }

        setTimeout(function(){
            button.disabled = true;
            button.style.opacity = '.65';
            button.style.cursor = 'not-allowed';
        }, 20);

    });

});

</script>







<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>





<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>

<script>
(function(){
    const form=document.getElementById('quickPaymentCollectionForm');
    if(!form)return;
    const outstanding=<?= json_encode((float)$balanceAmount); ?>;
    const currency=<?= json_encode((string)($booking['currency'] ?: 'INR')); ?>;
    const percent=document.getElementById('paymentRequestAdvancePercent');
    const custom=document.getElementById('paymentRequestCustomAmount');
    const pctBox=document.getElementById('advancePercentControl');
    const customBox=document.getElementById('customAmountControl');
    const preview=document.getElementById('paymentRequestPreview');
    const money=n=>currency+' '+Number(Math.max(0,n)||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
    function update(){
        const mode=form.querySelector('input[name="payment_request_mode"]:checked')?.value||'advance';
        pctBox.style.display=mode==='advance'?'':'none';
        customBox.style.display=mode==='custom'?'':'none';
        let amount=outstanding;
        if(mode==='advance')amount=outstanding*(Math.min(99,Math.max(1,parseFloat(percent.value||25)))/100);
        else if(mode==='half')amount=outstanding*.5;
        else if(mode==='custom')amount=Math.min(outstanding,Math.max(0,parseFloat(custom.value||0)));
        preview.textContent=money(amount);
    }
    form.querySelectorAll('input,select').forEach(el=>{el.addEventListener('input',update);el.addEventListener('change',update);});
    update();
})();
</script>
</body>
</html>
