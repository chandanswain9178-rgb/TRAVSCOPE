<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

requireLogin();

$user = currentUser($pdo);

if (!$user) {
    redirect(BASE_URL . 'login.php');
}

function rolePortalColumnExists(PDO $pdo, string $table, string $column): bool
{
    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = DATABASE()
              AND table_name = ?
              AND column_name = ?
        ");
        $stmt->execute([$table, $column]);
        return (int)$stmt->fetchColumn() > 0;
    } catch (Throwable $e) {
        return false;
    }
}

function rolePortalTableExists(PDO $pdo, string $table): bool
{
    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
              AND table_name = ?
        ");
        $stmt->execute([$table]);
        return (int)$stmt->fetchColumn() > 0;
    } catch (Throwable $e) {
        return false;
    }
}

function rolePortalCount(PDO $pdo, string $table, string $where = ''): int
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !rolePortalTableExists($pdo, $table)) {
        return 0;
    }

    try {
        $sql = "SELECT COUNT(*) FROM `{$table}`";
        if ($where !== '') {
            $sql .= " WHERE {$where}";
        }
        return (int)$pdo->query($sql)->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

$userRole = 'user';

if (rolePortalColumnExists($pdo, 'users', 'role')) {
    $userRole = strtolower(trim((string)($user['role'] ?? 'user')));
}

if ($userRole !== 'manager') {
    $target = match ($userRole) {
        'manager' => 'manager.php',
        'staff' => 'staff.php',
        default => 'dashboard.php',
    };
    redirect(BASE_URL . $target);
}

$_SESSION['user_role'] = $userRole;

$managerId =
    (int)$user['id'];


/*
|--------------------------------------------------------------------------
| MANAGER ENQUIRY ASSIGNMENT
|--------------------------------------------------------------------------
*/

$managerAssignmentReady = false;

try {

    foreach ([
        'assigned_user_id' => "ALTER TABLE enquiries ADD COLUMN assigned_user_id INT NULL AFTER admin_notes",
        'assigned_role' => "ALTER TABLE enquiries ADD COLUMN assigned_role VARCHAR(20) NULL AFTER assigned_user_id",
        'assigned_by_user_id' => "ALTER TABLE enquiries ADD COLUMN assigned_by_user_id INT NULL AFTER assigned_role",
        'assigned_by_type' => "ALTER TABLE enquiries ADD COLUMN assigned_by_type VARCHAR(20) NULL AFTER assigned_by_user_id",
        'assigned_at' => "ALTER TABLE enquiries ADD COLUMN assigned_at DATETIME NULL AFTER assigned_by_type"
    ] as $column => $alterSql) {

        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = DATABASE()
              AND table_name = 'enquiries'
              AND column_name = ?
        ");

        $stmt->execute([$column]);

        if ((int)$stmt->fetchColumn() === 0) {
            $pdo->exec($alterSql);
        }
    }

    $managerAssignmentReady = true;

} catch (Throwable $e) {

    error_log(
        'Manager enquiry assignment setup error: '
        . $e->getMessage()
    );
}


if (empty($_SESSION['manager_enquiry_csrf'])) {
    $_SESSION['manager_enquiry_csrf'] =
        bin2hex(random_bytes(32));
}

$managerCsrf =
    (string)$_SESSION['manager_enquiry_csrf'];

$staffMembers = [];

if ($managerAssignmentReady) {

    try {

        $stmt = $pdo->query("
            SELECT id, full_name, email
            FROM users
            WHERE role = 'staff'
              AND status = 'active'
            ORDER BY full_name ASC
        ");

        $staffMembers =
            $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {
        $staffMembers = [];
    }
}


/*
|--------------------------------------------------------------------------
| MANAGER REASSIGN TO STAFF
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    isset($_POST['manager_assign'])
) {

    $token =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    $enquiryId =
        (int)(
            $_POST['enquiry_id']
            ?? 0
        );

    $target =
        trim(
            (string)(
                $_POST['staff_target']
                ?? ''
            )
        );

    if (
        $token === ''
        ||
        !hash_equals(
            $managerCsrf,
            $token
        )
    ) {
        $_SESSION['manager_assignment_error'] =
            'Security verification failed.';

    } elseif (!$managerAssignmentReady) {

        $_SESSION['manager_assignment_error'] =
            'Assignment database is unavailable.';

    } else {

        try {

            /*
            | Manager may only reassign an enquiry currently assigned
            | specifically to them or shared with All Managers.
            */
            $stmt = $pdo->prepare("
                SELECT id
                FROM enquiries
                WHERE id = ?
                  AND assigned_role = 'manager'
                  AND (
                        assigned_user_id = ?
                        OR assigned_user_id IS NULL
                  )
                LIMIT 1
            ");

            $stmt->execute([
                $enquiryId,
                $managerId
            ]);

            if (!$stmt->fetchColumn()) {
                throw new RuntimeException(
                    'You can only assign enquiries currently assigned to you.'
                );
            }

            $staffUserId = null;
            $staffLabel = 'All Staff';

            if ($target !== 'role:staff') {

                if (
                    !preg_match(
                        '/^user:(\d+)$/',
                        $target,
                        $match
                    )
                ) {
                    throw new RuntimeException(
                        'Please select Staff or All Staff.'
                    );
                }

                $staffUserId =
                    (int)$match[1];

                $stmt = $pdo->prepare("
                    SELECT full_name
                    FROM users
                    WHERE id = ?
                      AND role = 'staff'
                      AND status = 'active'
                    LIMIT 1
                ");

                $stmt->execute([
                    $staffUserId
                ]);

                $staffLabel =
                    (string)(
                        $stmt->fetchColumn()
                        ?: ''
                    );

                if ($staffLabel === '') {
                    throw new RuntimeException(
                        'Selected Staff account is unavailable.'
                    );
                }
            }

            $stmt = $pdo->prepare("
                UPDATE enquiries
                SET
                    assigned_user_id = ?,
                    assigned_role = 'staff',
                    assigned_by_user_id = ?,
                    assigned_by_type = 'manager',
                    assigned_at = NOW()
                WHERE id = ?
                LIMIT 1
            ");

            $stmt->execute([
                $staffUserId,
                $managerId,
                $enquiryId
            ]);

            $_SESSION['manager_assignment_success'] =
                'Enquiry assigned to '
                . $staffLabel
                . '.';

        } catch (Throwable $e) {

            $_SESSION['manager_assignment_error'] =
                $e instanceof RuntimeException
                    ? $e->getMessage()
                    : 'Unable to assign enquiry.';
        }
    }

    header(
        'Location: '
        . BASE_URL
        . 'manager.php'
    );
    exit;
}


$managerAssignmentSuccess =
    (string)(
        $_SESSION['manager_assignment_success']
        ?? ''
    );

$managerAssignmentError =
    (string)(
        $_SESSION['manager_assignment_error']
        ?? ''
    );

unset(
    $_SESSION['manager_assignment_success'],
    $_SESSION['manager_assignment_error']
);


$siteName = 'TRAVSCOPE.COM';
try {
    $siteName = (string)getSetting($pdo, 'site_name', 'TRAVSCOPE.COM');
} catch (Throwable $e) {}

$totalBookings = rolePortalCount($pdo, 'bookings');
$pendingBookings = rolePortalCount($pdo, 'bookings', "booking_status='pending'");
$totalEnquiries = rolePortalCount($pdo, 'enquiries');
$newEnquiries = rolePortalCount($pdo, 'enquiries', "status='new'");

$assignedEnquiries = 0;
$assignedNewEnquiries = 0;

if ($managerAssignmentReady) {

    try {

        $stmt = $pdo->prepare("
            SELECT
                COUNT(*) AS assigned_count,
                SUM(
                    CASE
                        WHEN status = 'new'
                        THEN 1
                        ELSE 0
                    END
                ) AS new_count
            FROM enquiries
            WHERE assigned_role = 'manager'
              AND (
                    assigned_user_id = ?
                    OR assigned_user_id IS NULL
              )
        ");

        $stmt->execute([$managerId]);

        $row =
            $stmt->fetch(PDO::FETCH_ASSOC)
            ?: [];

        $assignedEnquiries =
            (int)($row['assigned_count'] ?? 0);

        $assignedNewEnquiries =
            (int)($row['new_count'] ?? 0);

    } catch (Throwable $e) {
        $assignedEnquiries = 0;
        $assignedNewEnquiries = 0;
    }
}
$totalCustomers = rolePortalCount($pdo, 'users');
$totalPackages = rolePortalCount($pdo, 'packages', "status='active'");
$totalDestinations = rolePortalCount($pdo, 'destinations', "status='active'");

$recentEnquiries = [];
if (rolePortalTableExists($pdo, 'enquiries')) {
    try {
        if ($managerAssignmentReady) {

            $stmt = $pdo->prepare("
                SELECT
                    e.id,
                    e.name,
                    e.email,
                    e.mobile,
                    e.destination,
                    e.travel_date,
                    e.status,
                    e.assigned_user_id,
                    e.assigned_role,
                    e.assigned_at,
                    e.created_at,
                    au.full_name AS assigned_user_name
                FROM enquiries e
                LEFT JOIN users au
                    ON au.id = e.assigned_user_id
                WHERE e.assigned_role = 'manager'
                  AND (
                        e.assigned_user_id = ?
                        OR e.assigned_user_id IS NULL
                  )
                ORDER BY e.id DESC
                LIMIT 20
            ");

            $stmt->execute([$managerId]);

            $recentEnquiries =
                $stmt->fetchAll(PDO::FETCH_ASSOC);

        } else {

            $recentEnquiries = [];
        }
    } catch (Throwable $e) {
        $recentEnquiries = [];
    }
}

$recentBookings = [];
if (rolePortalTableExists($pdo, 'bookings')) {
    try {
        $recentBookings = $pdo->query("
            SELECT id, booking_number, customer_name, total_amount, booking_status, payment_status, created_at
            FROM bookings
            ORDER BY id DESC
            LIMIT 5
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        $recentBookings = [];
    }
}

$initial = strtoupper(substr(trim((string)($user['full_name'] ?? 'U')), 0, 1));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#0b1930">
<title>Manager Dashboard | <?= e($siteName); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
:root{--navy:#0b1930;--blue:#2563eb;--bg:#f4f7fb;--text:#1e293b;--muted:#64748b;--border:#e2e8f0;--green:#0f9a68;--orange:#d97706;--purple:#7654c9}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh}
a{text-decoration:none;color:inherit}
.portal-top{height:68px;padding:0 22px;display:flex;align-items:center;justify-content:space-between;background:#fff;border-bottom:1px solid var(--border);position:sticky;top:0;z-index:20}
.brand{display:flex;align-items:center;gap:10px;font:800 15px 'Manrope',sans-serif;color:var(--navy)}
.brand-icon{width:36px;height:36px;display:grid;place-items:center;border-radius:10px;background:linear-gradient(135deg,#1688ff,#26b8e9);color:#fff}
.user-chip{display:flex;align-items:center;gap:9px}
.avatar{width:36px;height:36px;display:grid;place-items:center;border-radius:10px;background:#eaf3ff;color:#246fe9;font-weight:800}
.user-chip strong{display:block;font-size:11px}.user-chip span{display:block;margin-top:2px;font-size:9px;color:var(--muted)}
.page{width:min(1440px,calc(100% - 28px));margin:16px auto 28px}
.head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px}
.head h1{font:800 25px/1.15 'Manrope',sans-serif;color:var(--navy)}
.head p{margin-top:3px;color:var(--muted);font-size:11px}
.role-pill{padding:8px 11px;border-radius:999px;background:#f0e9ff;color:#704bc0;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.5px}
.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px;margin-bottom:10px}
.stat{min-height:86px;padding:12px;border:1px solid var(--border);border-radius:11px;background:#fff;position:relative;overflow:hidden}
.stat:before{content:"";position:absolute;inset:0 auto 0 0;width:4px;background:var(--accent,#2563eb)}
.stat span{font-size:9px;font-weight:800;color:var(--muted);text-transform:uppercase;letter-spacing:.4px}.stat strong{display:block;margin-top:7px;font:800 21px/1 'Manrope',sans-serif;color:var(--navy)}
.stat:nth-child(2){--accent:#0f9a68;background:linear-gradient(135deg,#fff,#f1fbf6)}
.stat:nth-child(3){--accent:#d97706;background:linear-gradient(135deg,#fff,#fff8ef)}
.stat:nth-child(4){--accent:#7654c9;background:linear-gradient(135deg,#fff,#f8f4ff)}
.grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(300px,.45fr);gap:10px}
.card{border:1px solid var(--border);border-radius:11px;background:#fff;overflow:hidden}
.card-head{min-height:46px;padding:0 12px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--border)}
.card-head h2{font:800 13px 'Manrope',sans-serif;color:var(--navy)}
.table-wrap{overflow-x:auto}table{width:100%;border-collapse:collapse;min-width:650px}th{padding:8px 10px;text-align:left;background:#f8fafc;color:#64748b;font-size:8px;text-transform:uppercase}td{padding:9px 10px;border-top:1px solid #eef2f6;font-size:10px}
.badge{display:inline-flex;padding:4px 7px;border-radius:999px;background:#eef4ff;color:#2563eb;font-size:8px;font-weight:800}
.quick{padding:10px;display:grid;grid-template-columns:1fr 1fr;gap:7px}
.quick a{min-height:58px;padding:9px;border:1px solid var(--border);border-radius:9px;background:#fbfdff;display:flex;align-items:center;gap:8px}
.quick i{width:27px;height:27px;display:grid;place-items:center;border-radius:8px;background:#eaf3ff;color:#2563eb}
.quick strong{display:block;font-size:10px}.quick span{display:block;margin-top:2px;font-size:8px;color:var(--muted)}
.logout{color:#b42318}
@media(max-width:900px){.stats{grid-template-columns:repeat(2,minmax(0,1fr))}.grid{grid-template-columns:1fr}}
@media(max-width:560px){.portal-top{padding:0 10px}.user-chip>div:last-child{display:none}.page{width:calc(100% - 14px);margin-top:10px}.head{align-items:flex-start;flex-direction:column}.stats{grid-template-columns:1fr}.quick{grid-template-columns:1fr}.head h1{font-size:22px}}


.portal-alert{margin-bottom:9px;padding:9px 11px;border-radius:9px;font-size:10px;font-weight:700}
.portal-alert.success{background:#eaf9f3;color:#087952;border:1px solid #cfeadb}
.portal-alert.error{background:#fff0f2;color:#bd4453;border:1px solid #f1ced4}
.assigned-label{width:max-content;margin-bottom:5px;padding:3px 6px;display:flex;align-items:center;gap:4px;border-radius:999px;font-size:8px;font-weight:800}
.assigned-label.manager{background:#f0e9ff;color:#704bc0}
.manager-assign-form{display:flex;gap:5px;align-items:center}
.manager-assign-form select{height:31px;min-width:120px;border:1px solid var(--border);border-radius:7px;padding:0 6px;font-size:9px;background:#fff}
.manager-assign-form button{height:31px;border:0;border-radius:7px;padding:0 8px;background:#0f9a68;color:#fff;font-size:8px;font-weight:800;cursor:pointer}
@media(max-width:700px){.manager-assign-form{flex-direction:column;align-items:stretch}.manager-assign-form select,.manager-assign-form button{width:100%;min-height:38px}}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>
<body>
<header class="portal-top">
    <a href="<?= e(BASE_URL); ?>" class="brand">
        <span class="brand-icon"><i class="fa-solid fa-plane"></i></span>
        TRAVSCOPE
    </a>
    <div class="user-chip">
        <div class="avatar"><?= e($initial); ?></div>
        <div>
            <strong><?= e((string)$user['full_name']); ?></strong>
            <span>Manager • <?= number_format($assignedEnquiries); ?> enquiries assigned</span>
        </div>
    </div>
</header>

<main class="page">
    <div class="head">
        <div>
            <h1>Manager Dashboard</h1>
            <p>Welcome back, <?= e((string)$user['full_name']); ?>. Here is the current TRAVSCOPE operations overview.</p>
        </div>
        <span class="role-pill">Manager Access</span>
    </div>

    <?php if ($managerAssignmentSuccess !== ''): ?>
        <div class="portal-alert success">
            <i class="fa-solid fa-circle-check"></i>
            <?= e($managerAssignmentSuccess); ?>
        </div>
    <?php endif; ?>

    <?php if ($managerAssignmentError !== ''): ?>
        <div class="portal-alert error">
            <i class="fa-solid fa-circle-exclamation"></i>
            <?= e($managerAssignmentError); ?>
        </div>
    <?php endif; ?>

    <section class="stats">
        
        <div class="stat"><span>Assigned New</span><strong><?= number_format($assignedNewEnquiries); ?></strong></div>
        <div class="stat"><span>Total Bookings</span><strong><?= number_format($totalBookings); ?></strong></div>
        <div class="stat"><span>Assigned Enquiries</span><strong><?= number_format($assignedEnquiries); ?></strong></div>
        <div class="stat"><span>Active Packages</span><strong><?= number_format($totalPackages); ?></strong></div>

    </section>

    <section class="grid">
        <div class="card">
            <div class="card-head"><h2>Recent Enquiries</h2><span class="badge"><?= count($recentEnquiries); ?> shown</span></div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Customer / Assigned</th><th>Destination</th><th>Travel Date</th><th>Status</th><th>Assign to Staff</th></tr></thead>
                    <tbody>
                    <?php if (!$recentEnquiries): ?>
                        <tr><td colspan="5">No enquiries are currently assigned to you.</td></tr>
                    <?php else: foreach ($recentEnquiries as $row): ?>
                        <tr>
                            <td>
                                <span class="assigned-label manager">
                                    <i class="fa-solid fa-user-tie"></i>
                                    <?= e(
                                        !empty($row['assigned_user_name'])
                                            ? (string)$row['assigned_user_name']
                                            : 'All Managers'
                                    ); ?>
                                </span>
                                <strong><?= e((string)$row['name']); ?></strong><br>
                                <small><?= e((string)($row['mobile'] ?: $row['email'])); ?></small>
                            </td>
                            <td><?= e((string)($row['destination'] ?: '—')); ?></td>
                            <td><?= !empty($row['travel_date']) ? e(date('d M Y', strtotime((string)$row['travel_date']))) : '—'; ?></td>
                            <td><span class="badge"><?= e(ucwords(str_replace('_',' ',(string)$row['status']))); ?></span></td>
                            <td>
                                <form method="post" class="manager-assign-form">
                                    <input type="hidden" name="csrf_token" value="<?= e($managerCsrf); ?>">
                                    <input type="hidden" name="enquiry_id" value="<?= (int)$row['id']; ?>">
                                    <select name="staff_target" required>
                                        <option value="">Choose Staff...</option>
                                        <option value="role:staff">All Staff</option>
                                        <?php foreach ($staffMembers as $staffMember): ?>
                                            <option value="user:<?= (int)$staffMember['id']; ?>">
                                                <?= e((string)$staffMember['full_name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" name="manager_assign" value="1">
                                        <i class="fa-solid fa-user-check"></i>
                                        Assign
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <aside class="card">
            <div class="card-head"><h2>Quick Access</h2></div>
            <div class="quick">
                
                <a href="<?= e(BASE_URL . 'manager.php'); ?>"><i class="fa-solid fa-chart-line"></i><div><strong>Operations</strong><span>Refresh manager overview</span></div></a>
                <a href="<?= e(BASE_URL . 'manager.php#bookings'); ?>"><i class="fa-solid fa-calendar-check"></i><div><strong>Bookings</strong><span><?= number_format($pendingBookings); ?> pending</span></div></a>

                <a href="<?= e(BASE_URL . 'dashboard.php'); ?>"><i class="fa-solid fa-user"></i><div><strong>My Account</strong><span>Open customer dashboard</span></div></a>
                <a href="<?= e(BASE_URL); ?>" target="_blank"><i class="fa-solid fa-globe"></i><div><strong>Website</strong><span>Open TRAVSCOPE website</span></div></a>
                <a href="<?= e(BASE_URL . 'logout.php'); ?>" class="logout"><i class="fa-solid fa-arrow-right-from-bracket"></i><div><strong>Logout</strong><span>End this session</span></div></a>
            </div>
        </aside>
    </section>

    <section class="card" style="margin-top:10px">
        <div class="card-head"><h2>Recent Bookings</h2><span class="badge"><?= count($recentBookings); ?> shown</span></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Booking</th><th>Customer</th><th>Amount</th><th>Booking Status</th><th>Payment</th></tr></thead>
                <tbody>
                <?php if (!$recentBookings): ?>
                    <tr><td colspan="5">No recent bookings.</td></tr>
                <?php else: foreach ($recentBookings as $row): ?>
                    <tr>
                        <td><strong><?= e((string)$row['booking_number']); ?></strong></td>
                        <td><?= e((string)$row['customer_name']); ?></td>
                        <td>₹<?= number_format((float)$row['total_amount'], 0); ?></td>
                        <td><span class="badge"><?= e(ucwords(str_replace('_',' ',(string)$row['booking_status']))); ?></span></td>
                        <td><span class="badge"><?= e(ucwords(str_replace('_',' ',(string)$row['payment_status']))); ?></span></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
