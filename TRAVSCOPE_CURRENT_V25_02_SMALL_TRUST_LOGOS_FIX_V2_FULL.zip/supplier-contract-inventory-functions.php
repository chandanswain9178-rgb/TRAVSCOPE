<?php
declare(strict_types=1);
if (is_file(__DIR__ . '/location-master-functions.php')) { require_once __DIR__ . '/location-master-functions.php'; }

/*
|--------------------------------------------------------------------------
| TRAVSCOPE STEP 11B - SUPPLIER CONTRACT HOTEL + VEHICLE INVENTORY
|--------------------------------------------------------------------------
| Keeps supplier tariff inventory separate from the canonical Hotel Master.
| Nothing is published to customers and no supplier is contacted here.
*/

function tsSCITableExists(PDO $pdo, string $table): bool
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
    try { $s=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?"); $s->execute([$table]); if ((int)$s->fetchColumn()>0) return true; } catch (Throwable $e) {}
    try { $pdo->query('SELECT 1 FROM `'.$table.'` LIMIT 0'); return true; } catch (Throwable $e) {}
    try { $q=$pdo->quote($table); if ($q!==false) { $s=$pdo->query('SHOW TABLES LIKE '.$q); return $s?(bool)$s->fetchColumn():false; } } catch (Throwable $e) {}
    return false;
}

function tsSCIColumnExists(PDO $pdo,string $table,string $column): bool
{
    if(!preg_match('/^[A-Za-z0-9_]+$/',$table)||!preg_match('/^[A-Za-z0-9_]+$/',$column))return false;
    try{$s=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?");$s->execute([$table,$column]);return (int)$s->fetchColumn()>0;}catch(Throwable $e){}
    try{$pdo->query('SELECT `'.$column.'` FROM `'.$table.'` LIMIT 0');return true;}catch(Throwable $e){}
    return false;
}

function tsSCIEnsureSchema(PDO $pdo): array
{
    $result = [
        'supplier_contract_hotel_inventory' => false,
        'supplier_contract_vehicle_rules' => false,
        'supplier_hotel_aliases' => false,
        'changed' => false,
    ];

    if (!tsSCITableExists($pdo, 'supplier_contract_hotel_inventory')) {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS supplier_contract_hotel_inventory (
              id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
              contract_version_id BIGINT UNSIGNED NOT NULL,
              contract_id BIGINT UNSIGNED NOT NULL,
              supplier_document_id BIGINT UNSIGNED NOT NULL,
              supplier_id BIGINT UNSIGNED NOT NULL,
              destination_id BIGINT UNSIGNED DEFAULT NULL,
              location_id BIGINT UNSIGNED DEFAULT NULL,
              city VARCHAR(120) NOT NULL,
              supplier_category VARCHAR(80) NOT NULL,
              mapped_star_category TINYINT UNSIGNED DEFAULT NULL,
              hotel_name VARCHAR(190) NOT NULL,
              hotel_name_normalized VARCHAR(190) NOT NULL,
              hotel_id BIGINT UNSIGNED DEFAULT NULL,
              room_type VARCHAR(120) DEFAULT NULL,
              meal_plan VARCHAR(120) DEFAULT NULL,
              valid_from DATE DEFAULT NULL,
              valid_to DATE DEFAULT NULL,
              mapping_status ENUM('unmatched','matched','created','ignored') NOT NULL DEFAULT 'unmatched',
              status ENUM('review','active','inactive') NOT NULL DEFAULT 'review',
              source_order INT UNSIGNED NOT NULL DEFAULT 0,
              source_excerpt VARCHAR(500) DEFAULT NULL,
              created_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
              updated_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
              created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
              updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              PRIMARY KEY (id),
              UNIQUE KEY uq_supplier_contract_hotel_inventory (contract_version_id,city,supplier_category,hotel_name_normalized),
              KEY idx_schi_version (contract_version_id,status,supplier_category,city),
              KEY idx_schi_contract (contract_id),
              KEY idx_schi_document (supplier_document_id),
              KEY idx_schi_supplier (supplier_id,status),
              KEY idx_schi_hotel (hotel_id),
              KEY idx_schi_destination (destination_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $result['changed'] = true;
    }

    if (!tsSCITableExists($pdo, 'supplier_hotel_aliases')) {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS supplier_hotel_aliases (
              id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
              supplier_id BIGINT UNSIGNED NOT NULL,
              hotel_id BIGINT UNSIGNED NOT NULL,
              city VARCHAR(120) NOT NULL DEFAULT '',
              supplier_hotel_name VARCHAR(190) NOT NULL,
              normalized_name VARCHAR(190) NOT NULL,
              supplier_category VARCHAR(80) DEFAULT NULL,
              status ENUM('active','inactive') NOT NULL DEFAULT 'active',
              created_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
              created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
              updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              PRIMARY KEY (id),
              UNIQUE KEY uq_supplier_hotel_alias (supplier_id,city,normalized_name),
              KEY idx_supplier_hotel_alias_hotel (hotel_id,status),
              KEY idx_supplier_hotel_alias_supplier (supplier_id,status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $result['changed'] = true;
    }

    if (!tsSCITableExists($pdo, 'supplier_contract_vehicle_rules')) {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS supplier_contract_vehicle_rules (
              id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
              contract_version_id BIGINT UNSIGNED NOT NULL,
              contract_id BIGINT UNSIGNED NOT NULL,
              supplier_document_id BIGINT UNSIGNED NOT NULL,
              supplier_id BIGINT UNSIGNED NOT NULL,
              destination_id BIGINT UNSIGNED DEFAULT NULL,
              location_id BIGINT UNSIGNED DEFAULT NULL,
              city VARCHAR(120) DEFAULT NULL,
              supplier_category VARCHAR(80) NOT NULL,
              pax_min INT UNSIGNED DEFAULT NULL,
              pax_max INT UNSIGNED DEFAULT NULL,
              vehicle_type VARCHAR(120) NOT NULL,
              ac_basis ENUM('ac','non_ac','unspecified') NOT NULL DEFAULT 'unspecified',
              route_scope VARCHAR(255) DEFAULT NULL,
              valid_from DATE DEFAULT NULL,
              valid_to DATE DEFAULT NULL,
              status ENUM('review','active','inactive') NOT NULL DEFAULT 'review',
              source_order INT UNSIGNED NOT NULL DEFAULT 0,
              source_rule_text TEXT DEFAULT NULL,
              created_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
              updated_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
              created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
              updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              PRIMARY KEY (id),
              UNIQUE KEY uq_supplier_contract_vehicle_rule (contract_version_id,city,supplier_category,vehicle_type),
              KEY idx_scvr_version (contract_version_id,status,supplier_category,city),
              KEY idx_scvr_contract (contract_id),
              KEY idx_scvr_document (supplier_document_id),
              KEY idx_scvr_supplier (supplier_id,status),
              KEY idx_scvr_destination (destination_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $result['changed'] = true;
    }

    // V8: vehicle inventory is location-aware. Same vehicle/category may exist in different cities.
    if(tsSCITableExists($pdo,'supplier_contract_vehicle_rules')){
        if(!tsSCIColumnExists($pdo,'supplier_contract_vehicle_rules','city')){
            try{$pdo->exec("ALTER TABLE supplier_contract_vehicle_rules ADD COLUMN city VARCHAR(120) DEFAULT NULL AFTER destination_id");$result['changed']=true;}catch(Throwable $ignored){}
        }
        if(tsSCIColumnExists($pdo,'supplier_contract_vehicle_rules','city')){
            try{
                $st=$pdo->prepare("SELECT GROUP_CONCAT(column_name ORDER BY seq_in_index SEPARATOR ',') FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='supplier_contract_vehicle_rules' AND index_name='uq_supplier_contract_vehicle_rule'");
                $st->execute();$cols=(string)($st->fetchColumn()?:'');
                if($cols!=='contract_version_id,city,supplier_category,vehicle_type'){
                    if($cols!=='')$pdo->exec("ALTER TABLE supplier_contract_vehicle_rules DROP INDEX uq_supplier_contract_vehicle_rule");
                    $pdo->exec("ALTER TABLE supplier_contract_vehicle_rules ADD UNIQUE KEY uq_supplier_contract_vehicle_rule (contract_version_id,city,supplier_category,vehicle_type)");
                    $result['changed']=true;
                }
            }catch(Throwable $ignored){}
        }
    }

    if (function_exists('tsLocationEnsureSchema')) {
        try {
            $loc=tsLocationEnsureSchema($pdo);
            if (!empty($loc['changed'])) $result['changed']=true;
        } catch (Throwable $ignored) {}
    }

    $result['supplier_contract_hotel_inventory'] = tsSCITableExists($pdo, 'supplier_contract_hotel_inventory');
    $result['supplier_contract_vehicle_rules'] = tsSCITableExists($pdo, 'supplier_contract_vehicle_rules');
    $result['supplier_hotel_aliases'] = tsSCITableExists($pdo, 'supplier_hotel_aliases');
    return $result;
}

function tsSCIReady(PDO $pdo): bool
{
    try { tsSCIEnsureSchema($pdo); } catch (Throwable $ignored) {}
    return tsSCITableExists($pdo, 'supplier_contract_hotel_inventory')
        && tsSCITableExists($pdo, 'supplier_contract_vehicle_rules')
        && tsSCITableExists($pdo, 'supplier_hotel_aliases');
}

function tsSCINormalizeName(string $value): string
{
    $value = trim($value);
    if ($value === '') return '';
    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if ($converted !== false) $value = $converted;
    }
    $value = strtolower($value);
    $value = preg_replace('/\bhotel\b/u', ' ', $value) ?? $value;
    $value = preg_replace('/[^a-z0-9]+/', ' ', $value) ?? $value;
    $value = preg_replace('/\s+/', ' ', $value) ?? $value;
    return trim($value);
}

function tsSCINormalizeCategory(string $value): string
{
    $v = strtolower(trim(preg_replace('/\s+/', ' ', $value) ?? $value));
    if ($v === '') return '';
    if (preg_match('/(?:(?:0?5)|five)\s*star.*(?:luxury|premium)/', $v)) return '5 Star Luxury';
    if (preg_match('/(?:(?:0?5)|five)\s*star/', $v)) return '5 Star';
    if (preg_match('/(?:0?4)\s*star.*luxury/', $v)) return '4 Star Luxury';
    if (preg_match('/(?:0?4)\s*star/', $v)) return '4 Star';
    if (preg_match('/(?:0?3)\s*star/', $v)) return '3 Star';
    if (preg_match('/(?:0?2)\s*star/', $v)) return '2 Star';
    if (preg_match('/\bstandard\b/', $v)) return 'Standard';
    if (preg_match('/\bbudget\b/', $v)) return 'Budget';
    return ucwords($v);
}

function tsSCIStarFromCategory(string $category): ?int
{
    $category = tsSCINormalizeCategory($category);
    if (str_starts_with($category, '5 Star')) return 5;
    if (str_starts_with($category, '4 Star')) return 4;
    if (str_starts_with($category, '3 Star')) return 3;
    return null;
}

function tsSCIGetVersion(PDO $pdo, int $versionId): ?array
{
    $stmt = $pdo->prepare("\n        SELECT v.*, c.supplier_id,c.contract_code,c.contract_name,c.status contract_status,\n               sd.document_code,sd.title document_title,sd.stored_path,sd.destination_id,\n               sd.valid_from document_valid_from,sd.valid_to document_valid_to,\n               sd.detected_meal_plan,sd.detected_transport_terms,sd.analysis_json,\n               s.company_name,s.supplier_code,d.name destination_name,d.country destination_country\n        FROM supplier_contract_versions v\n        JOIN supplier_contracts c ON c.id=v.contract_id\n        JOIN supplier_documents sd ON sd.id=v.supplier_document_id\n        JOIN suppliers s ON s.id=c.supplier_id\n        LEFT JOIN destinations d ON d.id=sd.destination_id\n        WHERE v.id=? LIMIT 1\n    ");
    $stmt->execute([$versionId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsSCIExtractLayoutText(string $sourcePath): string
{
    // V15: Supplier source documents may be PDF or DOCX. Use the shared
    // extractor first so the same inventory workflow works for both formats.
    if (function_exists('tsSupplierDocumentExtractFileText')) {
        $extracted=tsSupplierDocumentExtractFileText($sourcePath);
        $text=is_array($extracted)?(string)($extracted['text']??''):'';
        if(trim($text)!=='')return $text;
    }
    if (!is_file($sourcePath) || !function_exists('tsSupplierDocumentCommandExists') || !tsSupplierDocumentCommandExists('pdftotext')) {
        return '';
    }
    $tmp = tempnam(sys_get_temp_dir(), 'ts_sci_');
    if ($tmp === false) return '';
    @unlink($tmp);
    $tmp .= '.txt';
    try {
        tsSupplierDocumentRunCommand('pdftotext -layout -enc UTF-8 ' . escapeshellarg($sourcePath) . ' ' . escapeshellarg($tmp));
        return is_file($tmp) ? (string)@file_get_contents($tmp) : '';
    } finally {
        @unlink($tmp);
    }
}

function tsSCIHotelNamesFromCell(string $text): array
{
    $text = str_replace(["\r", "\n", "\t", '–', '—'], [' ', ' ', ' ', '-', '-'], $text);
    $text = preg_replace('/\s+/', ' ', $text) ?? $text;
    $text = trim($text, " /,;\t\n\r\0\x0B");
    if ($text === '') return [];

    // Supplier sheets usually separate alternative properties with slash.
    // Also split before a new "Hotel" token if PDF extraction swallowed a slash.
    $text = preg_replace('/\s+(?=Hotel\s+[A-Z0-9])/u', ' / ', $text) ?? $text;
    $parts = preg_split('#\s*/+\s*#u', $text) ?: [];
    $out = [];
    foreach ($parts as $part) {
        $part = trim(preg_replace('/\s+/', ' ', $part) ?? $part, " ,;:-");
        if ($part === '') continue;
        if (preg_match('/^(?:hotels?|category)$/iu', $part)) continue;
        $partLen = function_exists('mb_strlen') ? mb_strlen($part, 'UTF-8') : strlen($part);
        if ($partLen < 3 || $partLen > 190) continue;
        $norm = tsSCINormalizeName($part);
        if ($norm === '' || isset($out[$norm])) continue;
        $out[$norm] = $part;
    }
    return array_values($out);
}

function tsSCIHotelMatrixMetaKey(string $label): ?string
{
    $label = strtolower(trim(preg_replace('/\s+/', ' ', $label) ?? $label));
    if ($label === '') return null;
    if (preg_match('/\broom\b.*\b(?:category|type)\b|\b(?:category|type)\b.*\broom\b/u', $label)) return 'room_type';
    if (preg_match('/\bmeal\b.*\b(?:plan|basis|category)\b|\b(?:plan|basis|category)\b.*\bmeal\b/u', $label)) return 'meal_plan';
    return null;
}

function tsSCIHotelMatrixCleanMeta(string $value, string $key): string
{
    $value = trim(preg_replace('/\s+/', ' ', $value) ?? $value, " /,;:-\t\n\r\0\x0B");
    if ($value === '') return '';
    if ($key === 'room_type' && preg_match('/^room\s*(?:category|type)$/iu', $value)) return '';
    if ($key === 'meal_plan' && preg_match('/^meal\s*(?:plan|basis|category)$/iu', $value)) return '';
    return $value;
}

function tsSCIParseTabularHotelMatrix(string $layoutText): array
{
    $lines=preg_split('/\R/u',$layoutText)?:[];
    $rows=[];$cities=[];$warnings=[];
    $count=count($lines);
    for($i=0;$i<$count;$i++){
        $line=trim((string)$lines[$i]);
        if(!str_contains($line,"\t"))continue;
        $cells=array_map('trim',explode("\t",$line));
        if(!$cells || !preg_match('/^DESTINATION$/iu',(string)($cells[0]??'')))continue;
        $categories=[];
        for($c=1;$c<count($cells);$c++){
            $cat=tsSCINormalizeCategory((string)$cells[$c]);
            if($cat!=='')$categories[$c]=$cat;
        }
        if(!$categories)continue;
        for($j=$i+1;$j<$count;$j++){
            $rowLine=trim((string)$lines[$j]);
            if($rowLine==='')continue;
            if(preg_match('/^(?:ACTIVITY|PACKAGE\s+INCLUSIONS|PACKAGE\s+EXCLUSIONS|CHILD\s+POLICY|NOTES?|PAYMENTS?)\b/iu',$rowLine))break;
            if(!str_contains($rowLine,"\t")){
                // A region label such as ARUNACHAL may precede another DESTINATION header.
                if($j+1<$count && preg_match('/^DESTINATION\t/iu',trim((string)$lines[$j+1])))break;
                continue;
            }
            $rc=array_map('trim',explode("\t",$rowLine));
            $city=trim((string)($rc[0]??''));
            if($city==='' || preg_match('/^DESTINATION$/iu',$city))break;
            if(!in_array($city,$cities,true))$cities[]=$city;
            foreach($categories as $col=>$category){
                $cell=(string)($rc[$col]??'');
                if(trim($cell)==='')continue;
                foreach(tsSCIHotelNamesFromCell($cell) as $hotelName){
                    if(preg_match('/^similar$/iu',$hotelName))continue;
                    $rows[]=[
                        'city'=>$city,
                        'supplier_category'=>$category,
                        'mapped_star_category'=>tsSCIStarFromCategory($category),
                        'hotel_name'=>$hotelName,
                        'hotel_name_normalized'=>tsSCINormalizeName($hotelName),
                        'room_type'=>null,
                        'meal_plan'=>null,
                        'source_page'=>0,
                    ];
                }
            }
        }
    }
    if(!$rows)$warnings[]='No tabular destination/category hotel rows were detected.';
    return ['cities'=>$cities,'meta_columns'=>[],'rows'=>$rows,'warnings'=>$warnings];
}

function tsSCIParseHotelMatrix(string $layoutText): array
{
    if (trim($layoutText) === '') return ['cities'=>[], 'meta_columns'=>[], 'rows'=>[], 'warnings'=>['No layout text available.']];

    // DOCX/modern supplier grids use explicit tab-separated columns with
    // DESTINATION as rows and hotel categories as columns.
    $tabular=tsSCIParseTabularHotelMatrix($layoutText);
    if(!empty($tabular['rows']))return $tabular;

    $pages = preg_split('/\f/u', $layoutText) ?: [$layoutText];
    $headerFound = false;
    $columnDefs = [];
    $cities = [];
    $metaColumns = [];
    $dataPositions = null;
    $current = null;
    $parsedRows = [];
    $warnings = [];

    $flush = static function () use (&$current, &$parsedRows): void {
        if (!$current) return;
        $category = tsSCINormalizeCategory((string)$current['category_text']);
        if ($category !== '') {
            $current['category'] = $category;
            foreach (($current['meta_cells'] ?? []) as $key => $value) {
                $current['meta_cells'][$key] = tsSCIHotelMatrixCleanMeta((string)$value, (string)$key);
            }
            $parsedRows[] = $current;
        }
        $current = null;
    };

    foreach ($pages as $pageIndex => $page) {
        $lines = preg_split('/\R/u', $page) ?: [];
        $pagePositions = $dataPositions;

        foreach ($lines as $line) {
            if (!$headerFound) {
                if (preg_match('/^\s*Category\s{2,}(.+)$/iu', $line)) {
                    $parts = preg_split('/\s{3,}/u', rtrim($line), -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_OFFSET_CAPTURE) ?: [];
                    if (count($parts) >= 3 && strcasecmp(trim((string)$parts[0][0]), 'Category') === 0) {
                        $columnDefs = [];
                        $cities = [];
                        $metaColumns = [];
                        foreach (array_slice($parts, 1) as $part) {
                            $label = trim((string)$part[0]);
                            $metaKey = tsSCIHotelMatrixMetaKey($label);
                            if ($metaKey !== null) {
                                $columnDefs[] = ['type'=>'meta','label'=>$label,'key'=>$metaKey];
                                $metaColumns[$metaKey] = $label;
                            } else {
                                $cityIndex = count($cities);
                                $cities[] = $label;
                                $columnDefs[] = ['type'=>'city','label'=>$label,'city_index'=>$cityIndex];
                            }
                        }
                        if ($cities) {
                            $headerFound = true;
                            // Header offsets are only a fallback because centered headings may not align with body cells.
                            $dataPositions = array_map(static fn($p)=>(int)$p[1], $parts);
                            $pagePositions = $dataPositions;
                        }
                    }
                }
                continue;
            }

            if (preg_match('/^\s*(?:Note\s*:|All\s+Taxes|For\s+GST\s+Bill|\d+\)\s+The\s+transport|Cancellation\s+Policy|\d{1,2}\s+Nights?\s*(?:&|and)\s*\d{1,2}\s+Days?)/iu', $line)) {
                $flush();
                break 2;
            }

            // Infer true data-cell starts from the first populated category row when possible.
            // This is more reliable than centered header text in Word/PDF tables.
            if (preg_match('/^\s*(?:0?[2-5]\s*Star|Five\s*Star|Standard\b|Budget\b)/iu', $line)) {
                $probeParts = preg_split('/\s{3,}/u', rtrim($line), -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_OFFSET_CAPTURE) ?: [];
                $wanted = count($columnDefs) + 1; // category + all supplier columns
                if (count($probeParts) >= $wanted) {
                    $candidate = [];
                    foreach (array_slice($probeParts, 0, $wanted) as $part) $candidate[] = (int)$part[1];
                    if (count($candidate) === $wanted) {
                        $dataPositions = $candidate;
                        $pagePositions = $candidate;
                    }
                }
            }
            if ($pagePositions === null) continue;

            $cells = [];
            for ($i=0; $i<count($pagePositions); $i++) {
                $start = $pagePositions[$i];
                $end = $pagePositions[$i+1] ?? strlen($line);
                $cells[$i] = trim(substr($line, $start, max(0, $end-$start)));
            }

            $catCell = trim((string)($cells[0] ?? ''));
            $isNewCategory = $catCell !== '' && preg_match('/^(?:0?[2-5]\s*Star|Five\s*Star|Standard\b|Budget\b)/iu', $catCell);

            if ($isNewCategory) {
                $flush();
                $current = [
                    'category_text' => $catCell,
                    'category_label_complete' => false,
                    'page' => $pageIndex + 1,
                    'city_cells' => array_fill(0, count($cities), ''),
                    'meta_cells' => [],
                ];
            } elseif ($catCell !== '' && $current && empty($current['category_label_complete']) && preg_match('/^(?:Luxury|Premium|Deluxe|Hotels?)$/iu', $catCell)) {
                $current['category_text'] .= ' ' . $catCell;
                if (preg_match('/^Hotels?$/iu', $catCell)) $current['category_label_complete'] = true;
                $catCell = '';
            }

            if (!$current) continue;

            // Once the category label is complete, left-spilled text belongs to first hotel city.
            if ($catCell !== '' && !empty($current['category_label_complete']) && !$isNewCategory && $cities) {
                $cells[1] = trim($catCell . ' ' . (string)($cells[1] ?? ''));
            }

            foreach ($columnDefs as $idx => $def) {
                $cell = trim((string)($cells[$idx + 1] ?? ''));
                if ($cell === '') continue;
                if (($def['type'] ?? '') === 'city') {
                    $ci = (int)$def['city_index'];
                    $current['city_cells'][$ci] .= ($current['city_cells'][$ci] !== '' ? ' ' : '') . $cell;
                } elseif (($def['type'] ?? '') === 'meta') {
                    $key = (string)$def['key'];
                    $current['meta_cells'][$key] = trim((string)($current['meta_cells'][$key] ?? '') . ' ' . $cell);
                }
            }
        }
    }
    $flush();

    $rows = [];
    foreach ($parsedRows as $row) {
        $category = (string)$row['category'];
        $roomType = tsSCIHotelMatrixCleanMeta((string)($row['meta_cells']['room_type'] ?? ''), 'room_type');
        $mealPlan = tsSCIHotelMatrixCleanMeta((string)($row['meta_cells']['meal_plan'] ?? ''), 'meal_plan');
        foreach ($cities as $idx => $city) {
            $names = tsSCIHotelNamesFromCell((string)($row['city_cells'][$idx] ?? ''));
            foreach ($names as $name) {
                $rows[] = [
                    'city' => trim((string)$city),
                    'supplier_category' => $category,
                    'mapped_star_category' => tsSCIStarFromCategory($category),
                    'hotel_name' => $name,
                    'hotel_name_normalized' => tsSCINormalizeName($name),
                    'room_type' => $roomType !== '' ? $roomType : null,
                    'meal_plan' => $mealPlan !== '' ? $mealPlan : null,
                    'source_page' => (int)($row['page'] ?? 0),
                ];
            }
        }
    }

    if (!$rows) $warnings[] = 'No structured hotel rows could be extracted from the supplier hotel matrix.';
    return ['cities'=>$cities, 'meta_columns'=>$metaColumns, 'rows'=>$rows, 'warnings'=>$warnings];
}

function tsSCISplitVehicles(string $value): array
{
    $value = preg_replace('/\s+/', ' ', trim($value)) ?? trim($value);
    $parts = preg_split('/\s*(?:\/|,)\s*/u', $value) ?: [];
    $out = [];
    foreach ($parts as $part) {
        $part = trim($part, " .;:-");
        $part = preg_replace('/\b(?:Accordingly|However).*$/iu', '', $part) ?? $part;
        $part = trim($part);
        $partLen = function_exists('mb_strlen') ? mb_strlen($part, 'UTF-8') : strlen($part);
        if ($part === '' || $partLen > 120) continue;
        $key = strtolower(preg_replace('/[^a-z0-9]+/i', '', $part) ?? $part);
        if ($key !== '') $out[$key] = $part;
    }
    return array_values($out);
}

function tsSCIParseVehicleRules(string $text): array
{
    $clean = preg_replace('/\s+/', ' ', str_replace(["\r","\n"], ' ', $text)) ?? $text;
    $acBasis = preg_match('/\bNon\s*A\/?C\b/iu', $clean) ? 'non_ac' : (preg_match('/\bA\/?C\b/iu', $clean) ? 'ac' : 'unspecified');
    $rules = [];

    // Common package rule: Swift Dzire / Similar (2-3 PAX) & Innova/Ertiga / Similar (4-6 PAX).
    if (preg_match_all('/\b(Swift\s+D(?:e)?zire|Innova(?:\s*Crysta)?|Crysta|Etios|Tavera|Amaze|Ertiga|Tempo\s+Traveller)(?:\s*\/\s*(Innova(?:\s*Crysta)?|Crysta|Etios|Tavera|Amaze|Ertiga|Tempo\s+Traveller))?\s*(?:\/\s*Similar)?\s*\(\s*0?(\d{1,2})\s*-\s*0?(\d{1,2})\s*PAX\s*\)/iu', $clean, $vm, PREG_SET_ORDER)) {
        foreach ($vm as $m) {
            $vehicles=array_values(array_filter([trim((string)$m[1]),trim((string)($m[2]??''))]));
            foreach($vehicles as $vehicle){
                $rules[]=[
                    'supplier_category'=>'All',
                    'pax_min'=>max(1,(int)$m[3]),
                    'pax_max'=>max(1,(int)$m[4]),
                    'vehicle_type'=>$vehicle,
                    'ac_basis'=>$acBasis,
                    'route_scope'=>null,
                    'source_rule_text'=>trim((string)$m[0]),
                ];
            }
        }
    }

    $groups = [
        [
            'categories' => ['4 Star Luxury','4 Star'],
            'pattern' => '/(?:Luxury\s+and\s+0?4\s+Star\s+Hotel\s+Category).*?will\s+be\s+by\s+(.+?)(?=Accordingly\s+as\s+per\s+Pax|,\s*0?2\s+Star|\b0?2\s+Star)/iu',
        ],
        [
            'categories' => ['2 Star','3 Star'],
            'pattern' => '/0?2\s+Star\s*\/\s*0?3\s+Star\s+will\s+be\s+in\s+(.+?)(?=,?\s*Standard\s+and\s+Budget)/iu',
        ],
        [
            'categories' => ['Standard','Budget'],
            'pattern' => '/Standard\s+and\s+Budget\s+will\s+be\s+in\s+(.+?)(?=as\s+Per\s+Pax|Accordingly|,?\s*However)/iu',
        ],
    ];

    foreach ($groups as $group) {
        if ($rules) break;
        if (!preg_match($group['pattern'], $clean, $m)) continue;
        $vehicleText = trim((string)$m[1]);
        $vehicles = tsSCISplitVehicles($vehicleText);
        foreach ($group['categories'] as $category) {
            foreach ($vehicles as $vehicle) {
                $rules[] = [
                    'supplier_category' => $category,
                    'pax_min' => null,
                    'pax_max' => null,
                    'vehicle_type' => $vehicle,
                    'ac_basis' => $acBasis,
                    'route_scope' => null,
                    'source_rule_text' => trim((string)$m[0]),
                ];
            }
        }
    }

    if (!$rules) {
        $vehicles = [];
        if (preg_match_all('/\b(Innova(?:\s*Crysta)?|Crysta|Etios|Tavera|Amaze|Ertiga|Swift\s+D(?:e)?zire|Tempo\s+Traveller)\b/iu', $clean, $m)) {
            $vehicles = array_values(array_unique($m[1]));
        }
        foreach ($vehicles as $vehicle) {
            $rules[] = [
                'supplier_category' => 'All',
                'pax_min' => null,
                'pax_max' => null,
                'vehicle_type' => $vehicle,
                'ac_basis' => $acBasis,
                'route_scope' => null,
                'source_rule_text' => trim($text),
            ];
        }
    }
    return $rules;
}

function tsSCIAutoMatchHotel(PDO $pdo, int $supplierId, ?int $destinationId, string $city, ?int $star, string $hotelName): ?int
{
    if (!$destinationId || !$star || !tsSCITableExists($pdo, 'hotels')) return null;
    $normalized = tsSCINormalizeName($hotelName);
    if ($normalized === '') return null;

    // First honor a supplier-specific alias created by a prior review.
    $stmt = $pdo->prepare("SELECT hotel_id FROM supplier_hotel_aliases WHERE supplier_id=? AND city=? AND normalized_name=? AND status='active' LIMIT 1");
    $stmt->execute([$supplierId, $city, $normalized]);
    $aliasId = (int)$stmt->fetchColumn();
    if ($aliasId > 0) return $aliasId;

    $hasLocationId=tsSCIColumnExists($pdo,'hotels','location_id');
    $locationId=($destinationId && $city!=='' && function_exists('tsLocationUpsert')) ? tsLocationUpsert($pdo,(int)$destinationId,$city,'supplier',null) : 0;
    if($hasLocationId && $locationId>0){
        $stmt = $pdo->prepare("SELECT id,hotel_name FROM hotels WHERE destination_id=? AND location_id=? AND star_category=? AND status='active'");
        $stmt->execute([$destinationId,$locationId,$star]);
    }else{
        $stmt = $pdo->prepare("SELECT id,hotel_name FROM hotels WHERE destination_id=? AND LOWER(TRIM(COALESCE(city,'')))=LOWER(TRIM(?)) AND star_category=? AND status='active'");
        $stmt->execute([$destinationId,$city,$star]);
    }
    $candidates = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    foreach ($candidates as $candidate) {
        if (tsSCINormalizeName((string)$candidate['hotel_name']) === $normalized) {
            return (int)$candidate['id'];
        }
    }
    return null;
}

function tsSCIBuildInventory(PDO $pdo, int $versionId, int $adminId): array
{
    if (!tsSCIReady($pdo)) throw new RuntimeException('Step 11B SQL is not installed.');
    $version = tsSCIGetVersion($pdo, $versionId);
    if (!$version) throw new RuntimeException('Supplier contract version not found.');
    if ((string)$version['status'] === 'active') {
        throw new RuntimeException('This contract version is already active. Create a new contract version before rebuilding source inventory.');
    }

    $sourcePath = tsSupplierDocumentStoredPath((string)$version['stored_path']);
    $layout = tsSCIExtractLayoutText($sourcePath);
    if (trim($layout) === '') throw new RuntimeException('Unable to extract the supplier source document. PDF requires pdftotext; DOCX requires ZipArchive or the unzip utility.');

    $hotelParse = tsSCIParseHotelMatrix($layout);
    $transportText = trim((string)($version['transport_terms'] ?? $version['detected_transport_terms'] ?? ''));
    if ($transportText === '') {
        $plain = tsSupplierDocumentExtractFileText($sourcePath);
        $transportText = (string)($plain['text'] ?? '');
    }
    $vehicleRules = tsSCIParseVehicleRules($transportText);

    $pdo->beginTransaction();
    try {
        $pdo->prepare("DELETE FROM supplier_contract_hotel_inventory WHERE contract_version_id=? AND status='review'")->execute([$versionId]);
        $pdo->prepare("DELETE FROM supplier_contract_vehicle_rules WHERE contract_version_id=? AND status='review'")->execute([$versionId]);

        $hotelInsert = $pdo->prepare("\n            INSERT INTO supplier_contract_hotel_inventory\n            (contract_version_id,contract_id,supplier_document_id,supplier_id,destination_id,city,supplier_category,mapped_star_category,hotel_name,hotel_name_normalized,hotel_id,room_type,meal_plan,valid_from,valid_to,mapping_status,status,source_order,source_excerpt,created_by_admin_id,updated_by_admin_id)\n            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'review',?,?,?,?)\n        ");
        $hotelCount = 0;
        $matchedCount = 0;
        foreach ($hotelParse['rows'] as $index => $row) {
            $rowDestinationId = tsSCIResolveHotelDestinationId(
                $pdo,
                !empty($version['destination_id']) ? (int)$version['destination_id'] : null,
                (string)$row['city']
            );
            $hotelId = tsSCIAutoMatchHotel(
                $pdo,
                (int)$version['supplier_id'],
                $rowDestinationId,
                (string)$row['city'],
                $row['mapped_star_category'] !== null ? (int)$row['mapped_star_category'] : null,
                (string)$row['hotel_name']
            );
            if ($hotelId) $matchedCount++;
            $rowLocationId=($rowDestinationId && function_exists('tsLocationUpsert'))?tsLocationUpsert($pdo,(int)$rowDestinationId,(string)$row['city'],'supplier',$adminId):0;
            $hotelInsert->execute([
                $versionId,
                (int)$version['contract_id'],
                (int)$version['supplier_document_id'],
                (int)$version['supplier_id'],
                $rowDestinationId,
                (string)$row['city'],
                (string)$row['supplier_category'],
                $row['mapped_star_category'],
                (string)$row['hotel_name'],
                (string)$row['hotel_name_normalized'],
                $hotelId ?: null,
                !empty($row['room_type']) ? (string)$row['room_type'] : null,
                !empty($row['meal_plan']) ? (string)$row['meal_plan'] : (trim((string)($version['meal_plan'] ?? $version['detected_meal_plan'] ?? '')) ?: null),
                $version['valid_from'],
                $version['valid_to'],
                $hotelId ? 'matched' : 'unmatched',
                $index + 1,
                'PDF page ' . (int)($row['source_page'] ?? 0),
                $adminId ?: null,
                $adminId ?: null,
            ]);
            $newInventoryId=(int)$pdo->lastInsertId();
            if($newInventoryId>0 && $rowLocationId>0 && tsSCIColumnExists($pdo,'supplier_contract_hotel_inventory','location_id')){
                try{$pdo->prepare("UPDATE supplier_contract_hotel_inventory SET location_id=? WHERE id=?")->execute([$rowLocationId,$newInventoryId]);}catch(Throwable $ignored){}
            }
            $hotelCount++;
        }

        $vehicleInsert = $pdo->prepare("\n            INSERT INTO supplier_contract_vehicle_rules\n            (contract_version_id,contract_id,supplier_document_id,supplier_id,destination_id,supplier_category,pax_min,pax_max,vehicle_type,ac_basis,route_scope,valid_from,valid_to,status,source_order,source_rule_text,created_by_admin_id,updated_by_admin_id)\n            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'review',?,?,?,?)\n        ");
        $vehicleCount = 0;
        foreach ($vehicleRules as $index => $rule) {
            $vehicleInsert->execute([
                $versionId,
                (int)$version['contract_id'],
                (int)$version['supplier_document_id'],
                (int)$version['supplier_id'],
                !empty($version['destination_id']) ? (int)$version['destination_id'] : null,
                (string)$rule['supplier_category'],
                $rule['pax_min'],
                $rule['pax_max'],
                (string)$rule['vehicle_type'],
                (string)$rule['ac_basis'],
                $rule['route_scope'],
                $version['valid_from'],
                $version['valid_to'],
                $index + 1,
                (string)$rule['source_rule_text'],
                $adminId ?: null,
                $adminId ?: null,
            ]);
            $vehicleCount++;
        }

        $pdo->commit();
        return [
            'hotels' => $hotelCount,
            'matched_hotels' => $matchedCount,
            'vehicle_rules' => $vehicleCount,
            'cities' => $hotelParse['cities'],
            'warnings' => $hotelParse['warnings'],
        ];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function tsSCIAutoMatchInventory(PDO $pdo, int $versionId, int $adminId): int
{
    $version = tsSCIGetVersion($pdo, $versionId);
    if (!$version) throw new RuntimeException('Contract version not found.');
    $stmt = $pdo->prepare("SELECT * FROM supplier_contract_hotel_inventory WHERE contract_version_id=? AND status='review'");
    $stmt->execute([$versionId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $matched = 0;
    foreach ($rows as $row) {
        $hotelId = tsSCIAutoMatchHotel(
            $pdo,
            (int)$version['supplier_id'],
            !empty($row['destination_id']) ? (int)$row['destination_id'] : null,
            (string)$row['city'],
            !empty($row['mapped_star_category']) ? (int)$row['mapped_star_category'] : null,
            (string)$row['hotel_name']
        );
        if (!$hotelId) continue;
        $pdo->prepare("UPDATE supplier_contract_hotel_inventory SET hotel_id=?,mapping_status='matched',updated_by_admin_id=?,updated_at=NOW() WHERE id=?")
            ->execute([$hotelId,$adminId ?: null,(int)$row['id']]);
        $matched++;
    }
    return $matched;
}

function tsSCIManualMapHotel(PDO $pdo, int $inventoryId, int $hotelId, int $adminId): void
{
    $stmt = $pdo->prepare("SELECT * FROM supplier_contract_hotel_inventory WHERE id=? LIMIT 1");
    $stmt->execute([$inventoryId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) throw new RuntimeException('Supplier hotel inventory row not found.');
    $stmt = $pdo->prepare("SELECT id,hotel_name,star_category,destination_id FROM hotels WHERE id=? LIMIT 1");
    $stmt->execute([$hotelId]);
    $hotel = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$hotel) throw new RuntimeException('Hotel Master record not found.');
    if (!empty($row['destination_id']) && (int)$hotel['destination_id'] !== (int)$row['destination_id']) {
        throw new RuntimeException('Selected Hotel Master record belongs to a different destination.');
    }

    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE supplier_contract_hotel_inventory SET hotel_id=?,mapping_status='matched',updated_by_admin_id=?,updated_at=NOW() WHERE id=?")
            ->execute([$hotelId,$adminId ?: null,$inventoryId]);
        $alias = $pdo->prepare("\n            INSERT INTO supplier_hotel_aliases (supplier_id,hotel_id,city,supplier_hotel_name,normalized_name,supplier_category,status,created_by_admin_id)\n            VALUES (?,?,?,?,?,?,'active',?)\n            ON DUPLICATE KEY UPDATE hotel_id=VALUES(hotel_id),supplier_hotel_name=VALUES(supplier_hotel_name),supplier_category=VALUES(supplier_category),status='active',updated_at=NOW()\n        ");
        $alias->execute([
            (int)$row['supplier_id'],$hotelId,(string)$row['city'],(string)$row['hotel_name'],
            (string)$row['hotel_name_normalized'],(string)$row['supplier_category'],$adminId ?: null
        ]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}



function tsSCIResolveHotelDestinationId(PDO $pdo, ?int $fallbackDestinationId, string $city): ?int
{
    // V9: destination and operational city are separate dimensions.
    // Keep Tamil Nadu as destination_id and Chennai as city/location_id.
    return ($fallbackDestinationId ?? 0) > 0 ? (int)$fallbackDestinationId : null;
}

function tsSCIEnsureHotelMasterForInventoryRow(PDO $pdo, array $row, int $adminId): ?int
{
    if (!tsSCITableExists($pdo,'hotels')) return null;
    $star=(int)($row['mapped_star_category'] ?? 0);
    if(!in_array($star,[3,4,5],true)) return null;
    $hotelName=trim((string)($row['hotel_name'] ?? ''));
    if($hotelName==='') return null;
    $city=trim((string)($row['city'] ?? ''));
    $destinationId=tsSCIResolveHotelDestinationId($pdo, !empty($row['destination_id'])?(int)$row['destination_id']:null, $city);
    if(!$destinationId || $city==='') return null;
    $locationId=function_exists('tsLocationUpsert')?tsLocationUpsert($pdo,(int)$destinationId,$city,'supplier',$adminId):0;
    $supplierId=(int)($row['supplier_id'] ?? 0);
    $priority=100;
    try{
        $sp=$pdo->prepare("SELECT priority FROM suppliers WHERE id=? LIMIT 1");$sp->execute([$supplierId]);
        $pr=strtolower((string)$sp->fetchColumn());$priority=$pr==='preferred'?10:($pr==='regular'?50:($pr==='backup'?90:100));
    }catch(Throwable $ignored){}

    $hasLocationId=tsSCIColumnExists($pdo,'hotels','location_id');
    if($hasLocationId && $locationId>0){
        $find=$pdo->prepare("SELECT id,priority_order FROM hotels WHERE destination_id=? AND location_id=? AND LOWER(TRIM(hotel_name))=LOWER(TRIM(?)) AND star_category=? LIMIT 1");
        $find->execute([$destinationId,$locationId,$hotelName,$star]);
    }else{
        $find=$pdo->prepare("SELECT id,priority_order FROM hotels WHERE destination_id=? AND LOWER(TRIM(COALESCE(city,'')))=LOWER(TRIM(?)) AND LOWER(TRIM(hotel_name))=LOWER(TRIM(?)) AND star_category=? LIMIT 1");
        $find->execute([$destinationId,$city,$hotelName,$star]);
    }
    $existing=$find->fetch(PDO::FETCH_ASSOC);
    if($existing){
        $hotelId=(int)$existing['id'];
        if($supplierId>0 && $priority <= (int)($existing['priority_order']??100)){
            $set=$hasLocationId?'location_id=COALESCE(?,location_id),':'';
            $sql="UPDATE hotels SET {$set} city=COALESCE(NULLIF(?,''),city),default_room_type=COALESCE(NULLIF(?,''),default_room_type),default_meal_plan=COALESCE(NULLIF(?,''),default_meal_plan),preferred_supplier_id=?,priority_order=?,status='active',source='supplier_rate',notes=COALESCE(notes,?),updated_by_admin_id=? WHERE id=?";
            $vals=[];if($hasLocationId)$vals[]=$locationId?:null;array_push($vals,$city,(string)($row['room_type']??''),(string)($row['meal_plan']??''),$supplierId,$priority,'Synced automatically from supplier contract location-wise inventory.',$adminId?:null,$hotelId);
            $pdo->prepare($sql)->execute($vals);
        }
        return $hotelId;
    }

    if($hasLocationId){
        $ins=$pdo->prepare("INSERT INTO hotels(destination_id,location_id,hotel_name,city,star_category,default_room_type,default_meal_plan,preferred_supplier_id,source_rate_card_id,is_preferred,priority_order,status,source,notes,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,0,?,'active','supplier_rate',?,?,?)");
        $ins->execute([$destinationId,$locationId?:null,$hotelName,$city,$star,trim((string)($row['room_type']??''))?:null,trim((string)($row['meal_plan']??''))?:null,$supplierId?:null,null,$priority,'Synced automatically from supplier contract location-wise inventory.',$adminId?:null,$adminId?:null]);
    }else{
        $ins=$pdo->prepare("INSERT INTO hotels(destination_id,hotel_name,city,star_category,default_room_type,default_meal_plan,preferred_supplier_id,source_rate_card_id,is_preferred,priority_order,status,source,notes,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,0,?,'active','supplier_rate',?,?,?)");
        $ins->execute([$destinationId,$hotelName,$city,$star,trim((string)($row['room_type']??''))?:null,trim((string)($row['meal_plan']??''))?:null,$supplierId?:null,null,$priority,'Synced automatically from supplier contract location-wise inventory.',$adminId?:null,$adminId?:null]);
    }
    return (int)$pdo->lastInsertId();
}

function tsSCIAddSupplierHotelInventory(PDO $pdo, int $versionId, array $input, int $adminId): int
{
    if (!tsSCIReady($pdo)) {
        throw new RuntimeException('Step 11B supplier inventory is not installed.');
    }

    $version = tsSCIGetVersion($pdo, $versionId);
    if (!$version) {
        throw new RuntimeException('Supplier contract version not found.');
    }

    /*
    |--------------------------------------------------------------------------
    | Supplier-level ownership rule
    |--------------------------------------------------------------------------
    | Location-wise hotel inventory belongs to the supplier contract version.
    | Once a version is active it is immutable; add the hotel to a new version.
    */
    if ((string)($version['status'] ?? '') === 'active') {
        throw new RuntimeException(
            'This contract version is already active. Create a new supplier contract version before adding or changing its hotel inventory.'
        );
    }

    $city = trim((string)($input['city'] ?? ''));
    $hotelName = trim((string)($input['hotel_name'] ?? ''));
    $category = tsSCINormalizeCategory((string)($input['supplier_category'] ?? ''));
    $roomType = trim((string)($input['room_type'] ?? ''));
    $mealPlan = trim((string)($input['meal_plan'] ?? ''));

    $city = preg_replace('/\s+/', ' ', $city) ?? $city;
    $hotelName = preg_replace('/\s+/', ' ', $hotelName) ?? $hotelName;

    if ($city === '') {
        throw new RuntimeException('Enter the hotel location / city, for example Srinagar, Pahalgam or Gulmarg.');
    }
    if ($category === '') {
        throw new RuntimeException('Select the supplier hotel category.');
    }
    if ($hotelName === '') {
        throw new RuntimeException('Enter the supplier hotel name.');
    }

    $normalized = tsSCINormalizeName($hotelName);
    if ($normalized === '') {
        throw new RuntimeException('The hotel name is not valid.');
    }

    $star = tsSCIStarFromCategory($category);
    $destinationId = !empty($version['destination_id']) ? (int)$version['destination_id'] : null;
    $resolvedDestinationId = tsSCIResolveHotelDestinationId($pdo, $destinationId, $city);
    $locationId=($resolvedDestinationId && function_exists('tsLocationUpsert'))?tsLocationUpsert($pdo,(int)$resolvedDestinationId,$city,'supplier',$adminId):0;

    $hotelId = tsSCIAutoMatchHotel(
        $pdo,
        (int)$version['supplier_id'],
        $resolvedDestinationId,
        $city,
        $star,
        $hotelName
    );

    $dup = $pdo->prepare("
        SELECT id
        FROM supplier_contract_hotel_inventory
        WHERE contract_version_id=?
          AND LOWER(TRIM(city))=LOWER(TRIM(?))
          AND LOWER(TRIM(supplier_category))=LOWER(TRIM(?))
          AND hotel_name_normalized=?
        LIMIT 1
    ");
    $dup->execute([$versionId, $city, $category, $normalized]);
    $existingId = (int)($dup->fetchColumn() ?: 0);
    if ($existingId > 0) {
        throw new RuntimeException(
            'This supplier hotel already exists for the same location and category in this contract version.'
        );
    }

    $orderStmt = $pdo->prepare("
        SELECT COALESCE(MAX(source_order),0)
        FROM supplier_contract_hotel_inventory
        WHERE contract_version_id=?
    ");
    $orderStmt->execute([$versionId]);
    $sort = (int)$orderStmt->fetchColumn() + 1;

    $stmt = $pdo->prepare("
        INSERT INTO supplier_contract_hotel_inventory
        (
            contract_version_id,contract_id,supplier_document_id,supplier_id,destination_id,
            city,supplier_category,mapped_star_category,hotel_name,hotel_name_normalized,
            hotel_id,room_type,meal_plan,valid_from,valid_to,mapping_status,status,
            source_order,source_excerpt,created_by_admin_id,updated_by_admin_id
        )
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ");

    $stmt->execute([
        $versionId,
        (int)$version['contract_id'],
        (int)$version['supplier_document_id'],
        (int)$version['supplier_id'],
        $resolvedDestinationId,
        $city,
        $category,
        $star,
        $hotelName,
        $normalized,
        $hotelId ?: null,
        $roomType !== '' ? $roomType : null,
        $mealPlan !== ''
            ? $mealPlan
            : (trim((string)($version['meal_plan'] ?? $version['detected_meal_plan'] ?? '')) ?: null),
        $version['valid_from'] ?: null,
        $version['valid_to'] ?: null,
        $hotelId ? 'matched' : 'unmatched',
        'review',
        $sort,
        'Manual supplier-level location inventory',
        $adminId > 0 ? $adminId : null,
        $adminId > 0 ? $adminId : null,
    ]);

    $inventoryId=(int)$pdo->lastInsertId();
    if($inventoryId>0 && $locationId>0 && tsSCIColumnExists($pdo,'supplier_contract_hotel_inventory','location_id')){
        try{$pdo->prepare("UPDATE supplier_contract_hotel_inventory SET location_id=? WHERE id=?")->execute([$locationId,$inventoryId]);}catch(Throwable $ignored){}
    }
    if(!$hotelId && in_array((int)$star,[3,4,5],true)) {
        $rowForMaster=[
            'destination_id'=>$resolvedDestinationId,'city'=>$city,'mapped_star_category'=>$star,
            'hotel_name'=>$hotelName,'room_type'=>$roomType,'meal_plan'=>$mealPlan !== '' ? $mealPlan : ($version['meal_plan'] ?? null),
            'supplier_id'=>(int)$version['supplier_id']
        ];
        $masterId=tsSCIEnsureHotelMasterForInventoryRow($pdo,$rowForMaster,$adminId);
        if($masterId){
            $pdo->prepare("UPDATE supplier_contract_hotel_inventory SET hotel_id=?,mapping_status='created',updated_by_admin_id=?,updated_at=NOW() WHERE id=?")
                ->execute([$masterId,$adminId?:null,$inventoryId]);
        }
    }
    return $inventoryId;
}


function tsSCISyncEligibleHotelsToMaster(PDO $pdo, int $versionId, int $adminId): array
{
    if (!tsSCITableExists($pdo, 'hotels')) throw new RuntimeException('Hotel Master (Step 06) is not installed.');
    $version = tsSCIGetVersion($pdo, $versionId);
    if (!$version) throw new RuntimeException('Contract version not found.');

    $stmt = $pdo->prepare("SELECT * FROM supplier_contract_hotel_inventory WHERE contract_version_id=? AND mapped_star_category IN (3,4,5) ORDER BY id");
    $stmt->execute([$versionId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $created=0;$matched=0;$skipped=0;

    foreach ($rows as $row) {
        $beforeId=!empty($row['hotel_id'])?(int)$row['hotel_id']:0;
        $hotelId=$beforeId ?: tsSCIEnsureHotelMasterForInventoryRow($pdo,$row,$adminId);
        if(!$hotelId){$skipped++;continue;}
        if($beforeId>0){$matched++;}
        else{
            $exists=$pdo->prepare("SELECT mapping_status FROM supplier_contract_hotel_inventory WHERE id=? LIMIT 1");
            $exists->execute([(int)$row['id']]);
            $created++;
        }
        try{tsSCIManualMapHotel($pdo,(int)$row['id'],$hotelId,$adminId);}catch(Throwable $ignored){
            $pdo->prepare("UPDATE supplier_contract_hotel_inventory SET hotel_id=?,mapping_status=?,updated_by_admin_id=?,updated_at=NOW() WHERE id=?")
                ->execute([$hotelId,$beforeId?'matched':'created',$adminId?:null,(int)$row['id']]);
        }
        $pdo->prepare("UPDATE supplier_contract_hotel_inventory SET mapping_status=? WHERE id=?")
            ->execute([$beforeId?'matched':'created',(int)$row['id']]);
    }
    return ['created'=>$created,'matched'=>$matched,'skipped'=>$skipped];
}

function tsSCIApproveInventory(PDO $pdo, int $versionId, int $adminId): array
{
    $version = tsSCIGetVersion($pdo,$versionId);
    if(!$version) throw new RuntimeException('Contract version not found.');
    $hotelCountStmt=$pdo->prepare("SELECT COUNT(*) FROM supplier_contract_hotel_inventory WHERE contract_version_id=? AND status='review'");
    $hotelCountStmt->execute([$versionId]);
    $hotelCount=(int)$hotelCountStmt->fetchColumn();
    $vehicleCountStmt=$pdo->prepare("SELECT COUNT(*) FROM supplier_contract_vehicle_rules WHERE contract_version_id=? AND status='review'");
    $vehicleCountStmt->execute([$versionId]);
    $vehicleCount=(int)$vehicleCountStmt->fetchColumn();
    if($hotelCount===0 && $vehicleCount===0) throw new RuntimeException('Build the supplier inventory first.');

    $pdo->beginTransaction();
    try{
        $pdo->prepare("UPDATE supplier_contract_hotel_inventory SET status='active',updated_by_admin_id=?,updated_at=NOW() WHERE contract_version_id=? AND status='review'")
            ->execute([$adminId ?: null,$versionId]);
        $pdo->prepare("UPDATE supplier_contract_vehicle_rules SET status='active',updated_by_admin_id=?,updated_at=NOW() WHERE contract_version_id=? AND status='review'")
            ->execute([$adminId ?: null,$versionId]);
        $pdo->commit();
        return ['hotels'=>$hotelCount,'vehicles'=>$vehicleCount];
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}

function tsSCIInventorySummary(PDO $pdo, int $versionId): array
{
    $summary=['hotels'=>0,'mapped'=>0,'unmatched'=>0,'vehicles'=>0,'active_hotels'=>0,'active_vehicles'=>0];
    if(!tsSCIReady($pdo)) return $summary;
    $stmt=$pdo->prepare("SELECT COUNT(*) total,SUM(hotel_id IS NOT NULL) mapped,SUM(hotel_id IS NULL) unmatched,SUM(status='active') active_count FROM supplier_contract_hotel_inventory WHERE contract_version_id=?");
    $stmt->execute([$versionId]);$r=$stmt->fetch(PDO::FETCH_ASSOC)?:[];
    $summary['hotels']=(int)($r['total']??0);$summary['mapped']=(int)($r['mapped']??0);$summary['unmatched']=(int)($r['unmatched']??0);$summary['active_hotels']=(int)($r['active_count']??0);
    $stmt=$pdo->prepare("SELECT COUNT(*) total,SUM(status='active') active_count FROM supplier_contract_vehicle_rules WHERE contract_version_id=?");
    $stmt->execute([$versionId]);$r=$stmt->fetch(PDO::FETCH_ASSOC)?:[];
    $summary['vehicles']=(int)($r['total']??0);$summary['active_vehicles']=(int)($r['active_count']??0);
    return $summary;
}

/* STEP 11G - manual supplier-level vehicle rule */
function tsSCIAddSupplierVehicleRule(PDO $pdo, int $versionId, array $input, int $adminId): int
{
    if (!tsSCIReady($pdo) || !tsSCITableExists($pdo,'supplier_contract_vehicle_rules')) {
        throw new RuntimeException('Step 11B supplier vehicle inventory is not installed.');
    }
    $version=tsSCIGetVersion($pdo,$versionId);
    if(!$version) throw new RuntimeException('Supplier contract version not found.');
    if((string)($version['status']??'')==='active') {
        throw new RuntimeException('This contract version is active. Create a new version before adding or changing vehicle rules.');
    }
    $category=tsSCINormalizeCategory((string)($input['supplier_category']??''));
    $vehicle=trim(preg_replace('/\s+/u',' ',(string)($input['vehicle_type']??''))??'');
    $city=trim(preg_replace('/\s+/u',' ',(string)($input['city']??''))??'');
    $route=trim((string)($input['route_scope']??''));
    $ac=strtolower(trim((string)($input['ac_basis']??'unspecified')));
    if(!in_array($ac,['ac','non_ac','unspecified'],true))$ac='unspecified';
    $paxMin=trim((string)($input['pax_min']??''));$paxMax=trim((string)($input['pax_max']??''));
    $paxMin=$paxMin===''?null:max(1,(int)$paxMin);$paxMax=$paxMax===''?null:max(1,(int)$paxMax);
    if($paxMin!==null&&$paxMax!==null&&$paxMin>$paxMax)throw new RuntimeException('PAX minimum cannot be greater than PAX maximum.');
    if($category==='')throw new RuntimeException('Select the supplier category.');
    if($vehicle==='')throw new RuntimeException('Enter the supplier vehicle type.');
    if($city==='')throw new RuntimeException('Select or enter the vehicle Location / City.');
    $vehicleDestinationId=!empty($version['destination_id'])?(int)$version['destination_id']:0;
    $vehicleLocationId=($vehicleDestinationId>0 && function_exists('tsLocationUpsert'))?tsLocationUpsert($pdo,$vehicleDestinationId,$city,'supplier',$adminId):0;

    $hasCity=false;
    try{$s=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='supplier_contract_vehicle_rules' AND column_name='city'");$s->execute();$hasCity=(int)$s->fetchColumn()>0;}catch(Throwable $e){}
    $dupSql="SELECT id FROM supplier_contract_vehicle_rules WHERE contract_version_id=? AND LOWER(TRIM(supplier_category))=LOWER(TRIM(?)) AND LOWER(TRIM(vehicle_type))=LOWER(TRIM(?))";
    $params=[$versionId,$category,$vehicle];
    if($hasCity){$dupSql.=" AND LOWER(TRIM(COALESCE(city,'')))=LOWER(TRIM(?))";$params[]=$city;}
    $dupSql.=' LIMIT 1';$dup=$pdo->prepare($dupSql);$dup->execute($params);
    if($dup->fetchColumn())throw new RuntimeException('This supplier vehicle rule already exists for the same contract/category'.($city!==''?' and location':'').'.');
    $o=$pdo->prepare('SELECT COALESCE(MAX(source_order),0)+1 FROM supplier_contract_vehicle_rules WHERE contract_version_id=?');$o->execute([$versionId]);$sort=(int)$o->fetchColumn();
    if($hasCity){
        $sql="INSERT INTO supplier_contract_vehicle_rules(contract_version_id,contract_id,supplier_document_id,supplier_id,destination_id,city,supplier_category,pax_min,pax_max,vehicle_type,ac_basis,route_scope,valid_from,valid_to,status,source_order,source_rule_text,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,'review',?,?,?,?)";
        $vals=[$versionId,(int)$version['contract_id'],(int)$version['supplier_document_id'],(int)$version['supplier_id'],!empty($version['destination_id'])?(int)$version['destination_id']:null,$city!==''?$city:null,$category,$paxMin,$paxMax,$vehicle,$ac,$route!==''?$route:null,$version['valid_from']?:null,$version['valid_to']?:null,$sort,'Manual supplier-level vehicle rule',$adminId?:null,$adminId?:null];
    }else{
        $sql="INSERT INTO supplier_contract_vehicle_rules(contract_version_id,contract_id,supplier_document_id,supplier_id,destination_id,supplier_category,pax_min,pax_max,vehicle_type,ac_basis,route_scope,valid_from,valid_to,status,source_order,source_rule_text,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'review',?,?,?,?)";
        $vals=[$versionId,(int)$version['contract_id'],(int)$version['supplier_document_id'],(int)$version['supplier_id'],!empty($version['destination_id'])?(int)$version['destination_id']:null,$category,$paxMin,$paxMax,$vehicle,$ac,$route!==''?$route:null,$version['valid_from']?:null,$version['valid_to']?:null,$sort,'Manual supplier-level vehicle rule',$adminId?:null,$adminId?:null];
    }
    $stmt=$pdo->prepare($sql);$stmt->execute($vals);$newId=(int)$pdo->lastInsertId();if($newId>0&&$vehicleLocationId>0&&tsSCIColumnExists($pdo,'supplier_contract_vehicle_rules','location_id')){try{$pdo->prepare("UPDATE supplier_contract_vehicle_rules SET location_id=? WHERE id=?")->execute([$vehicleLocationId,$newId]);}catch(Throwable $ignored){}}return$newId;
}
