<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — SYSTEM NOTIFICATIONS + ESCALATION ENGINE
|--------------------------------------------------------------------------
|
| This module reads existing live business tables and creates one deduplicated
| Admin notification per active condition / recipient.
|
| Active conditions are automatically resolved when the source condition clears.
| Escalation is severity/time based. High/Critical email delivery is OPTIONAL
| through notification-cron.php --email.
|
*/

$notificationAclFile = __DIR__ . '/access-control-functions.php';
if (
    is_file($notificationAclFile)
    && !function_exists('tsAclProfile')
) {
    require_once $notificationAclFile;
}

$notificationSystemSettingsFile = __DIR__ . '/system-settings-functions.php';
if (
    is_file($notificationSystemSettingsFile)
    && !function_exists('tsSystemSettingInt')
) {
    require_once $notificationSystemSettingsFile;
}


function tsNotifyTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];

    $key = strtolower($table);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
              AND table_name = ?
        ");
        $stmt->execute([$table]);

        return $cache[$key] =
            ((int)$stmt->fetchColumn() > 0);

    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}


function tsNotifyReady(PDO $pdo): bool
{
    return
        tsNotifyTableExists($pdo, 'admin_notifications')
        && tsNotifyTableExists($pdo, 'system_notification_state');
}


function tsNotifyAdmins(PDO $pdo): array
{
    static $cache = null;

    if (is_array($cache)) {
        return $cache;
    }

    try {
        $stmt = $pdo->query("
            SELECT
                id,
                name,
                email,
                role,
                status
            FROM admins
            WHERE status = 'active'
            ORDER BY id ASC
        ");

        $rows =
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: [];

        foreach ($rows as &$row) {
            if (function_exists('tsAclProfile')) {
                $row['access_profile'] =
                    tsAclProfile(
                        $pdo,
                        (int)$row['id'],
                        (string)($row['role'] ?? 'admin')
                    );
            } else {
                $legacy =
                    strtolower(
                        trim(
                            (string)(
                                $row['role']
                                ?? 'admin'
                            )
                        )
                    );

                $row['access_profile'] =
                    match ($legacy) {
                        'super_admin' => 'super_admin',
                        'staff' => 'sales',
                        default => 'admin',
                    };
            }
        }
        unset($row);

        return $cache = $rows;

    } catch (Throwable $e) {
        error_log(
            'Notification admin lookup: '
            . $e->getMessage()
        );

        return $cache = [];
    }
}


function tsNotifyRecipients(
    PDO $pdo,
    ?int $ownerAdminId = null,
    array $profiles = [],
    bool $includeOwner = true
): array {
    $ids = [];

    foreach (tsNotifyAdmins($pdo) as $admin) {
        $id =
            (int)$admin['id'];

        if (
            $includeOwner
            && $ownerAdminId
            && $id === $ownerAdminId
        ) {
            $ids[$id] = true;
        }

        if (
            $profiles
            && in_array(
                (string)$admin['access_profile'],
                $profiles,
                true
            )
        ) {
            $ids[$id] = true;
        }
    }

    return
        array_map(
            'intval',
            array_keys($ids)
        );
}


function tsNotifyOwnerForBooking(
    PDO $pdo,
    int $bookingId
): ?int {
    if (
        $bookingId <= 0
        || !tsNotifyTableExists(
            $pdo,
            'booking_trip_links'
        )
        || !tsNotifyTableExists(
            $pdo,
            'trips'
        )
    ) {
        return null;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT t.owner_admin_id
            FROM booking_trip_links l
            JOIN trips t
                ON t.id = l.trip_id
            WHERE l.booking_id = ?
            LIMIT 1
        ");
        $stmt->execute([$bookingId]);

        $owner =
            (int)(
                $stmt->fetchColumn()
                ?: 0
            );

        return
            $owner > 0
                ? $owner
                : null;

    } catch (Throwable $e) {
        return null;
    }
}


function tsNotifySeverityRank(string $severity): int
{
    return
        match ($severity) {
            'critical' => 4,
            'high' => 3,
            'warning' => 2,
            default => 1,
        };
}


function tsNotifyUpsert(
    PDO $pdo,
    int $adminId,
    string $notificationKey,
    string $sourceKey,
    string $category,
    string $severity,
    int $escalationLevel,
    string $title,
    string $message,
    ?string $entityType = null,
    ?int $entityId = null,
    ?string $linkUrl = null,
    ?string $sourceTable = null,
    ?int $sourceId = null,
    ?string $dueAt = null,
    array $meta = [],
    ?string $detectedAt = null
): void {
    if (
        $adminId <= 0
        || !tsNotifyReady($pdo)
    ) {
        return;
    }

    if (
        !in_array(
            $severity,
            ['info','warning','high','critical'],
            true
        )
    ) {
        $severity = 'info';
    }

    $detectedAt ??=
        date('Y-m-d H:i:s');

    $notificationKey =
        mb_substr(
            trim($notificationKey),
            0,
            255
        );

    if ($notificationKey === '') {
        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO admin_notifications
        (
            admin_id,
            notification_key,
            source_key,
            category,
            severity,
            escalation_level,
            title,
            message,
            entity_type,
            entity_id,
            link_url,
            source_table,
            source_id,
            due_at,
            status,
            first_detected_at,
            last_detected_at,
            meta_json
        )
        VALUES
        (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            'unread', ?, ?, ?
        )
        ON DUPLICATE KEY UPDATE
            source_key = VALUES(source_key),
            category = VALUES(category),
            severity = VALUES(severity),

            read_at =
                CASE
                    WHEN status = 'resolved'
                        THEN NULL
                    WHEN status = 'dismissed'
                     AND VALUES(escalation_level) > escalation_level
                        THEN NULL
                    ELSE read_at
                END,

            dismissed_at =
                CASE
                    WHEN status = 'resolved'
                        THEN NULL
                    WHEN status = 'dismissed'
                     AND VALUES(escalation_level) > escalation_level
                        THEN NULL
                    ELSE dismissed_at
                END,

            resolved_at =
                CASE
                    WHEN status = 'resolved'
                        THEN NULL
                    ELSE resolved_at
                END,

            email_sent_at =
                CASE
                    WHEN status = 'resolved'
                        THEN NULL
                    WHEN VALUES(escalation_level) > escalation_level
                        THEN NULL
                    ELSE email_sent_at
                END,

            status =
                CASE
                    WHEN status = 'resolved'
                        THEN 'unread'
                    WHEN status = 'dismissed'
                     AND VALUES(escalation_level) > escalation_level
                        THEN 'unread'
                    ELSE status
                END,

            escalation_level = VALUES(escalation_level),
            title = VALUES(title),
            message = VALUES(message),
            entity_type = VALUES(entity_type),
            entity_id = VALUES(entity_id),
            link_url = VALUES(link_url),
            source_table = VALUES(source_table),
            source_id = VALUES(source_id),
            due_at = VALUES(due_at),
            last_detected_at = VALUES(last_detected_at),
            meta_json = VALUES(meta_json),
            updated_at = NOW()
    ");

    $stmt->execute([
        $adminId,
        $notificationKey,
        mb_substr($sourceKey, 0, 80),
        mb_substr($category, 0, 60),
        $severity,
        max(0, min(9, $escalationLevel)),
        mb_substr($title, 0, 255),
        $message !== ''
            ? $message
            : null,
        $entityType !== null
            ? mb_substr($entityType, 0, 60)
            : null,
        $entityId,
        $linkUrl !== null
            ? mb_substr($linkUrl, 0, 500)
            : null,
        $sourceTable !== null
            ? mb_substr($sourceTable, 0, 100)
            : null,
        $sourceId,
        $dueAt,
        $detectedAt,
        $detectedAt,
        $meta
            ? json_encode(
                $meta,
                JSON_UNESCAPED_UNICODE
                | JSON_UNESCAPED_SLASHES
            )
            : null,
    ]);
}


function tsNotifyResolveSource(
    PDO $pdo,
    string $sourceKey,
    string $syncStartedAt
): void {
    if (!tsNotifyReady($pdo)) {
        return;
    }

    $stmt = $pdo->prepare("
        UPDATE admin_notifications
        SET
            status = 'resolved',
            resolved_at = NOW(),
            email_sent_at = NULL,
            email_escalation_level = 0,
            updated_at = NOW()
        WHERE source_key = ?
          AND status <> 'resolved'
          AND last_detected_at < ?
    ");

    $stmt->execute([
        $sourceKey,
        $syncStartedAt
    ]);
}


function tsNotifyAgeLevel(int $daysOverdue): array
{
    if ($daysOverdue >= 7) {
        return [
            'severity' => 'critical',
            'level' => 3,
        ];
    }

    if ($daysOverdue >= 3) {
        return [
            'severity' => 'high',
            'level' => 2,
        ];
    }

    return [
        'severity' => 'warning',
        'level' => 1,
    ];
}


function tsNotifyDateDiffDays(
    ?string $from,
    ?string $to = null
): int {
    if (!$from) {
        return 0;
    }

    $a =
        strtotime($from);

    $b =
        strtotime(
            $to
            ?: date('Y-m-d H:i:s')
        );

    if (!$a || !$b) {
        return 0;
    }

    return
        (int)floor(
            ($b - $a) / 86400
        );
}


function tsNotifyStateGet(
    PDO $pdo,
    string $key
): ?string {
    if (!tsNotifyReady($pdo)) {
        return null;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT state_value
            FROM system_notification_state
            WHERE state_key = ?
            LIMIT 1
        ");
        $stmt->execute([$key]);

        $value =
            $stmt->fetchColumn();

        return
            $value !== false
                ? (string)$value
                : null;

    } catch (Throwable $e) {
        return null;
    }
}


function tsNotifyStateSet(
    PDO $pdo,
    string $key,
    string $value
): void {
    if (!tsNotifyReady($pdo)) {
        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO system_notification_state
        (
            state_key,
            state_value
        )
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE
            state_value = VALUES(state_value),
            updated_at = NOW()
    ");

    $stmt->execute([
        $key,
        $value
    ]);
}


function tsNotifyPublishToRecipients(
    PDO $pdo,
    array $recipientIds,
    string $baseKey,
    string $sourceKey,
    string $category,
    string $severity,
    int $level,
    string $title,
    string $message,
    ?string $entityType = null,
    ?int $entityId = null,
    ?string $linkUrl = null,
    ?string $sourceTable = null,
    ?int $sourceId = null,
    ?string $dueAt = null,
    array $meta = [],
    ?string $detectedAt = null
): int {
    $count = 0;

    foreach (
        array_unique(
            array_map(
                'intval',
                $recipientIds
            )
        )
        as $adminId
    ) {
        if ($adminId <= 0) {
            continue;
        }

        tsNotifyUpsert(
            $pdo,
            $adminId,
            $baseKey,
            $sourceKey,
            $category,
            $severity,
            $level,
            $title,
            $message,
            $entityType,
            $entityId,
            $linkUrl,
            $sourceTable,
            $sourceId,
            $dueAt,
            $meta,
            $detectedAt
        );

        $count++;
    }

    return $count;
}


function tsNotifySyncTripActions(
    PDO $pdo,
    string $startedAt
): int {
    $sourceKey = 'trip_next_action';
    $count = 0;

    if (!tsNotifyTableExists($pdo, 'trips')) {
        return 0;
    }

    try {
        $stmt = $pdo->query("
            SELECT
                id,
                trip_code,
                trip_title,
                owner_admin_id,
                next_action,
                next_action_date,
                DATEDIFF(
                    CURDATE(),
                    next_action_date
                ) AS overdue_days
            FROM trips
            WHERE status = 'active'
              AND next_action_date IS NOT NULL
              AND next_action_date < CURDATE()
              AND COALESCE(next_action,'') <> ''
            ORDER BY next_action_date ASC
            LIMIT 250
        ");

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $days =
                max(
                    1,
                    (int)$row['overdue_days']
                );

            $rank =
                tsNotifyAgeLevel(
                    $days
                );

            $profiles =
                $days >= 3
                    ? ['admin','super_admin']
                    : [];

            $recipients =
                tsNotifyRecipients(
                    $pdo,
                    !empty($row['owner_admin_id'])
                        ? (int)$row['owner_admin_id']
                        : null,
                    $profiles,
                    true
                );

            if (!$recipients) {
                $recipients =
                    tsNotifyRecipients(
                        $pdo,
                        null,
                        ['admin','super_admin'],
                        false
                    );
            }

            $count +=
                tsNotifyPublishToRecipients(
                    $pdo,
                    $recipients,
                    'trip-next-action:'
                        . (int)$row['id'],
                    $sourceKey,
                    'Sales / CRM',
                    (string)$rank['severity'],
                    (int)$rank['level'],
                    'Overdue Trip next action · '
                        . (string)$row['trip_code'],
                    (string)$row['next_action']
                        . ' is '
                        . $days
                        . ' day'
                        . ($days === 1 ? '' : 's')
                        . ' overdue.',
                    'trip',
                    (int)$row['id'],
                    'admin-crm.php?trip='
                        . (int)$row['id'],
                    'trips',
                    (int)$row['id'],
                    (string)$row['next_action_date']
                        . ' 23:59:59',
                    [
                        'trip_code' =>
                            (string)$row['trip_code'],
                        'overdue_days' =>
                            $days,
                    ],
                    $startedAt
                );
        }

        tsNotifyResolveSource(
            $pdo,
            $sourceKey,
            $startedAt
        );

    } catch (Throwable $e) {
        error_log(
            'Notification Trip actions: '
            . $e->getMessage()
        );
    }

    return $count;
}


function tsNotifySyncSupplierConfirmations(
    PDO $pdo,
    string $startedAt
): int {
    $sourceKey = 'supplier_confirmation';
    $count = 0;

    if (
        !tsNotifyTableExists(
            $pdo,
            'supplier_booking_orders'
        )
        || !tsNotifyTableExists(
            $pdo,
            'bookings'
        )
    ) {
        return 0;
    }

    $supplierJoin =
        tsNotifyTableExists(
            $pdo,
            'suppliers'
        )
            ? "LEFT JOIN suppliers s ON s.id = o.supplier_id"
            : '';

    $supplierSelect =
        tsNotifyTableExists(
            $pdo,
            'suppliers'
        )
            ? "COALESCE(s.company_name,'Supplier') AS supplier_name"
            : "'Supplier' AS supplier_name";

    $warningHours =
        function_exists('tsSystemSettingInt')
            ? tsSystemSettingInt(
                $pdo,
                'ops_supplier_response_warning_hours',
                24
            )
            : 24;

    $highHours =
        function_exists('tsSystemSettingInt')
            ? tsSystemSettingInt(
                $pdo,
                'ops_supplier_response_high_hours',
                72
            )
            : 72;

    try {
        $stmt = $pdo->query("
            SELECT
                o.id,
                o.order_code,
                o.booking_id,
                o.status,
                o.sent_at,
                o.first_response_at,
                o.updated_at,
                {$supplierSelect},
                b.booking_number,
                b.customer_name,
                b.travel_date
            FROM supplier_booking_orders o
            JOIN bookings b
                ON b.id = o.booking_id
            {$supplierJoin}
            WHERE b.booking_status IN (
                    'pending',
                    'confirmed'
                  )
              AND (
                    o.status IN (
                        'alternative_required',
                        'rejected',
                        'partially_confirmed'
                    )
                    OR (
                        o.status = 'sent'
                        AND o.sent_at IS NOT NULL
                        AND o.sent_at <= DATE_SUB(
                            NOW(),
                            INTERVAL "
                            . (int)$warningHours
                            . " HOUR
                        )
                    )
                  )
            ORDER BY
                b.travel_date ASC,
                o.updated_at ASC
            LIMIT 250
        ");

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $status =
                strtolower(
                    (string)$row['status']
                );

            $hours =
                max(
                    0,
                    (int)floor(
                        (
                            time()
                            - strtotime(
                                (string)(
                                    $row['sent_at']
                                    ?: $row['updated_at']
                                )
                            )
                        ) / 3600
                    )
                );

            $daysToTravel =
                $row['travel_date']
                    ? (int)floor(
                        (
                            strtotime(
                                (string)$row['travel_date']
                                . ' 00:00:00'
                            )
                            - strtotime(
                                date('Y-m-d 00:00:00')
                            )
                        ) / 86400
                    )
                    : 999;

            if (
                in_array(
                    $status,
                    ['rejected','alternative_required'],
                    true
                )
            ) {
                $severity = 'critical';
                $level = 3;

            } elseif ($status === 'partially_confirmed') {
                $severity =
                    $daysToTravel <= 7
                        ? 'critical'
                        : 'high';
                $level =
                    $daysToTravel <= 7
                        ? 3
                        : 2;

            } elseif (
                $hours >= $highHours
                || $daysToTravel <= 7
            ) {
                $severity = 'high';
                $level = 2;

            } else {
                $severity = 'warning';
                $level = 1;
            }

            $owner =
                tsNotifyOwnerForBooking(
                    $pdo,
                    (int)$row['booking_id']
                );

            $profiles = ['operations'];

            if ($level >= 3) {
                $profiles[] = 'admin';
                $profiles[] = 'super_admin';
            }

            $recipients =
                tsNotifyRecipients(
                    $pdo,
                    $owner,
                    $profiles,
                    true
                );

            $statusLabel =
                ucwords(
                    str_replace(
                        '_',
                        ' ',
                        $status
                    )
                );

            $message =
                (string)$row['supplier_name']
                . ' · '
                . $statusLabel
                . '.';

            if ($status === 'sent') {
                $message .=
                    ' No completed supplier confirmation after '
                    . $hours
                    . ' hour'
                    . ($hours === 1 ? '' : 's')
                    . '.';
            }

            if ($daysToTravel < 999) {
                if ($daysToTravel >= 0) {
                    $message .=
                        ' Departure in '
                        . $daysToTravel
                        . ' day'
                        . ($daysToTravel === 1 ? '' : 's')
                        . '.';
                } else {
                    $pastDays = abs($daysToTravel);
                    $message .=
                        ' Scheduled departure passed '
                        . $pastDays
                        . ' day'
                        . ($pastDays === 1 ? '' : 's')
                        . ' ago.';
                }
            }

            $count +=
                tsNotifyPublishToRecipients(
                    $pdo,
                    $recipients,
                    'supplier-confirmation:'
                        . (int)$row['id'],
                    $sourceKey,
                    'Supplier / Operations',
                    $severity,
                    $level,
                    'Supplier confirmation needs attention · '
                        . (string)$row['booking_number'],
                    $message,
                    'booking',
                    (int)$row['booking_id'],
                    'admin-booking-details.php?id='
                        . (int)$row['booking_id'],
                    'supplier_booking_orders',
                    (int)$row['id'],
                    $row['travel_date']
                        ? (string)$row['travel_date']
                            . ' 09:00:00'
                        : null,
                    [
                        'order_code' =>
                            (string)$row['order_code'],
                        'supplier' =>
                            (string)$row['supplier_name'],
                        'status' =>
                            $status,
                        'hours_since_sent' =>
                            $hours,
                        'days_to_travel' =>
                            $daysToTravel,
                    ],
                    $startedAt
                );
        }

        tsNotifyResolveSource(
            $pdo,
            $sourceKey,
            $startedAt
        );

    } catch (Throwable $e) {
        error_log(
            'Notification supplier confirmation: '
            . $e->getMessage()
        );
    }

    return $count;
}


function tsNotifySyncCollections(
    PDO $pdo,
    string $startedAt
): int {
    $sourceKey = 'customer_collection';
    $count = 0;

    if (
        !tsNotifyTableExists(
            $pdo,
            'booking_payment_installments'
        )
        || !tsNotifyTableExists(
            $pdo,
            'booking_payment_schedules'
        )
        || !tsNotifyTableExists(
            $pdo,
            'bookings'
        )
    ) {
        return 0;
    }

    try {
        $stmt = $pdo->query("
            SELECT
                i.booking_id,
                MIN(i.due_date) AS oldest_due_date,
                COUNT(*) AS overdue_installments,
                COALESCE(
                    SUM(
                        GREATEST(
                            i.amount - i.paid_amount,
                            0
                        )
                    ),
                    0
                ) AS outstanding_amount,
                MAX(s.currency) AS currency,
                MAX(b.booking_number) AS booking_number,
                MAX(b.customer_name) AS customer_name,
                DATEDIFF(
                    CURDATE(),
                    MIN(i.due_date)
                ) AS overdue_days
            FROM booking_payment_installments i
            JOIN booking_payment_schedules s
                ON s.id = i.schedule_id
            JOIN bookings b
                ON b.id = i.booking_id
            WHERE s.status = 'active'
              AND i.status IN (
                    'pending',
                    'partially_paid'
                  )
              AND i.due_date IS NOT NULL
              AND i.due_date < CURDATE()
              AND b.booking_status <> 'cancelled'
            GROUP BY i.booking_id
            ORDER BY oldest_due_date ASC
            LIMIT 250
        ");

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $days =
                max(
                    1,
                    (int)$row['overdue_days']
                );

            $rank =
                tsNotifyAgeLevel(
                    $days
                );

            $owner =
                tsNotifyOwnerForBooking(
                    $pdo,
                    (int)$row['booking_id']
                );

            $profiles = ['finance'];

            if ((int)$rank['level'] >= 3) {
                $profiles[] = 'admin';
                $profiles[] = 'super_admin';
            }

            $recipients =
                tsNotifyRecipients(
                    $pdo,
                    $owner,
                    $profiles,
                    true
                );

            $currency =
                strtoupper(
                    trim(
                        (string)(
                            $row['currency']
                            ?: 'INR'
                        )
                    )
                );

            $message =
                $currency
                . ' '
                . number_format(
                    (float)$row['outstanding_amount'],
                    2
                )
                . ' overdue across '
                . (int)$row['overdue_installments']
                . ' installment'
                . (
                    (int)$row['overdue_installments'] === 1
                        ? ''
                        : 's'
                )
                . ' · '
                . $days
                . ' day'
                . ($days === 1 ? '' : 's')
                . ' overdue.';

            $count +=
                tsNotifyPublishToRecipients(
                    $pdo,
                    $recipients,
                    'customer-collection:'
                        . (int)$row['booking_id'],
                    $sourceKey,
                    'Finance / Collections',
                    (string)$rank['severity'],
                    (int)$rank['level'],
                    'Customer collection overdue · '
                        . (string)$row['booking_number'],
                    $message,
                    'booking',
                    (int)$row['booking_id'],
                    'admin-booking-details.php?id='
                        . (int)$row['booking_id'],
                    'booking_payment_installments',
                    (int)$row['booking_id'],
                    (string)$row['oldest_due_date']
                        . ' 23:59:59',
                    [
                        'outstanding_amount' =>
                            (float)$row['outstanding_amount'],
                        'currency' =>
                            $currency,
                        'overdue_days' =>
                            $days,
                    ],
                    $startedAt
                );
        }

        tsNotifyResolveSource(
            $pdo,
            $sourceKey,
            $startedAt
        );

    } catch (Throwable $e) {
        error_log(
            'Notification collections: '
            . $e->getMessage()
        );
    }

    return $count;
}


function tsNotifySyncDepartureReadiness(
    PDO $pdo,
    string $startedAt
): int {
    $sourceKey = 'departure_readiness';
    $count = 0;

    if (!tsNotifyTableExists($pdo, 'bookings')) {
        return 0;
    }

    $riskWindowDays =
        function_exists('tsSystemSettingInt')
            ? tsSystemSettingInt(
                $pdo,
                'ops_departure_risk_window_days',
                14
            )
            : 14;

    $riskHighDays =
        function_exists('tsSystemSettingInt')
            ? tsSystemSettingInt(
                $pdo,
                'ops_departure_risk_high_days',
                7
            )
            : 7;

    $riskCriticalDays =
        function_exists('tsSystemSettingInt')
            ? tsSystemSettingInt(
                $pdo,
                'ops_departure_risk_critical_days',
                3
            )
            : 3;

    try {
        $stmt = $pdo->query("
            SELECT
                id,
                booking_number,
                customer_name,
                travel_date,
                total_amount,
                paid_amount,
                currency,
                booking_status
            FROM bookings
            WHERE booking_status IN ('pending','confirmed')
              AND travel_date BETWEEN CURDATE()
                  AND DATE_ADD(CURDATE(), INTERVAL " . (int)$riskWindowDays . " DAY)
            ORDER BY travel_date ASC, id ASC
            LIMIT 180
        ");

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $booking
        ) {
            $bookingId =
                (int)$booking['id'];

            $reasons = [];

            $balance =
                max(
                    0,
                    (float)$booking['total_amount']
                    - (float)$booking['paid_amount']
                );

            if ($balance > 0.01) {
                $reasons[] =
                    'Customer balance pending';
            }

            if (
                tsNotifyTableExists(
                    $pdo,
                    'booking_service_snapshots'
                )
            ) {
                $q = $pdo->prepare("
                    SELECT COUNT(*)
                    FROM booking_service_snapshots
                    WHERE booking_id = ?
                      AND source_supplier_id IS NOT NULL
                      AND procurement_status NOT IN (
                            'confirmed',
                            'cancelled'
                          )
                ");
                $q->execute([$bookingId]);

                if ((int)$q->fetchColumn() > 0) {
                    $reasons[] =
                        'Supplier services not fully confirmed';
                }
            }

            if (
                tsNotifyTableExists(
                    $pdo,
                    'booking_operation_checks'
                )
            ) {
                $q = $pdo->prepare("
                    SELECT COUNT(*)
                    FROM booking_operation_checks
                    WHERE booking_id = ?
                      AND is_required = 1
                      AND is_complete = 0
                ");
                $q->execute([$bookingId]);

                if ((int)$q->fetchColumn() > 0) {
                    $reasons[] =
                        'Operations checklist incomplete';
                }
            }

            if (
                tsNotifyTableExists(
                    $pdo,
                    'booking_voucher_versions'
                )
            ) {
                $q = $pdo->prepare("
                    SELECT COUNT(*)
                    FROM booking_voucher_versions
                    WHERE booking_id = ?
                      AND status = 'final'
                ");
                $q->execute([$bookingId]);

                if ((int)$q->fetchColumn() === 0) {
                    $reasons[] =
                        'Final Travel Voucher missing';
                }
            }

            if (
                tsNotifyTableExists(
                    $pdo,
                    'booking_document_pack_versions'
                )
            ) {
                $q = $pdo->prepare("
                    SELECT COUNT(*)
                    FROM booking_document_pack_versions
                    WHERE booking_id = ?
                      AND status = 'final'
                ");
                $q->execute([$bookingId]);

                if ((int)$q->fetchColumn() === 0) {
                    $reasons[] =
                        'Final Trip Document Pack missing';
                }
            }

            if (!$reasons) {
                continue;
            }

            $daysToTravel =
                max(
                    0,
                    (int)floor(
                        (
                            strtotime(
                                (string)$booking['travel_date']
                                . ' 00:00:00'
                            )
                            - strtotime(
                                date('Y-m-d 00:00:00')
                            )
                        ) / 86400
                    )
                );

            if ($daysToTravel <= $riskCriticalDays) {
                $severity = 'critical';
                $level = 3;
            } elseif ($daysToTravel <= $riskHighDays) {
                $severity = 'high';
                $level = 2;
            } else {
                $severity = 'warning';
                $level = 1;
            }

            $owner =
                tsNotifyOwnerForBooking(
                    $pdo,
                    $bookingId
                );

            $profiles = ['operations'];

            if ($level >= 3) {
                $profiles[] = 'admin';
                $profiles[] = 'super_admin';
            }

            $recipients =
                tsNotifyRecipients(
                    $pdo,
                    $owner,
                    $profiles,
                    true
                );

            $message =
                implode(
                    ' · ',
                    $reasons
                )
                . '. Departure in '
                . $daysToTravel
                . ' day'
                . ($daysToTravel === 1 ? '' : 's')
                . '.';

            $count +=
                tsNotifyPublishToRecipients(
                    $pdo,
                    $recipients,
                    'departure-readiness:'
                        . $bookingId,
                    $sourceKey,
                    'Operations / Departure',
                    $severity,
                    $level,
                    'Departure readiness risk · '
                        . (string)$booking['booking_number'],
                    $message,
                    'booking',
                    $bookingId,
                    'admin-booking-details.php?id='
                        . $bookingId,
                    'bookings',
                    $bookingId,
                    (string)$booking['travel_date']
                        . ' 09:00:00',
                    [
                        'days_to_travel' =>
                            $daysToTravel,
                        'reasons' =>
                            $reasons,
                        'customer_balance' =>
                            $balance,
                    ],
                    $startedAt
                );
        }

        tsNotifyResolveSource(
            $pdo,
            $sourceKey,
            $startedAt
        );

    } catch (Throwable $e) {
        error_log(
            'Notification departure readiness: '
            . $e->getMessage()
        );
    }

    return $count;
}


function tsNotifySyncDocumentReview(
    PDO $pdo,
    string $startedAt
): int {
    $sourceKey = 'document_review';
    $count = 0;

    if (
        !tsNotifyTableExists(
            $pdo,
            'booking_travel_documents'
        )
        || !tsNotifyTableExists(
            $pdo,
            'bookings'
        )
    ) {
        return 0;
    }

    $reviewWarningHours =
        function_exists('tsSystemSettingInt')
            ? tsSystemSettingInt(
                $pdo,
                'ops_document_review_warning_hours',
                48
            )
            : 48;

    $reviewHighHours =
        function_exists('tsSystemSettingInt')
            ? tsSystemSettingInt(
                $pdo,
                'ops_document_review_high_hours',
                120
            )
            : 120;

    try {
        $stmt = $pdo->query("
            SELECT
                d.booking_id,
                COUNT(*) AS pending_documents,
                MIN(d.created_at) AS oldest_upload,
                MAX(b.booking_number) AS booking_number,
                MAX(b.travel_date) AS travel_date,
                TIMESTAMPDIFF(
                    HOUR,
                    MIN(d.created_at),
                    NOW()
                ) AS waiting_hours
            FROM booking_travel_documents d
            JOIN bookings b
                ON b.id = d.booking_id
            WHERE d.verification_status = 'pending'
              AND d.created_at <= DATE_SUB(
                    NOW(),
                    INTERVAL "
                    . (int)$reviewWarningHours
                    . " HOUR
                  )
              AND b.booking_status <> 'cancelled'
            GROUP BY d.booking_id
            ORDER BY oldest_upload ASC
            LIMIT 180
        ");

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $hours =
                max(
                    48,
                    (int)$row['waiting_hours']
                );

            if ($hours >= $reviewHighHours) {
                $severity = 'high';
                $level = 2;
            } else {
                $severity = 'warning';
                $level = 1;
            }

            $owner =
                tsNotifyOwnerForBooking(
                    $pdo,
                    (int)$row['booking_id']
                );

            $recipients =
                tsNotifyRecipients(
                    $pdo,
                    $owner,
                    ['operations'],
                    true
                );

            $count +=
                tsNotifyPublishToRecipients(
                    $pdo,
                    $recipients,
                    'document-review:'
                        . (int)$row['booking_id'],
                    $sourceKey,
                    'Documents / Operations',
                    $severity,
                    $level,
                    'Traveller documents waiting for review · '
                        . (string)$row['booking_number'],
                    (int)$row['pending_documents']
                        . ' document'
                        . (
                            (int)$row['pending_documents'] === 1
                                ? ''
                                : 's'
                        )
                        . ' waiting for Admin verification for '
                        . $hours
                        . ' hour'
                        . ($hours === 1 ? '' : 's')
                        . '.',
                    'booking',
                    (int)$row['booking_id'],
                    'admin-booking-documents.php?id='
                        . (int)$row['booking_id'],
                    'booking_travel_documents',
                    (int)$row['booking_id'],
                    $row['travel_date']
                        ? (string)$row['travel_date']
                            . ' 09:00:00'
                        : null,
                    [
                        'pending_documents' =>
                            (int)$row['pending_documents'],
                        'waiting_hours' =>
                            $hours,
                    ],
                    $startedAt
                );
        }

        tsNotifyResolveSource(
            $pdo,
            $sourceKey,
            $startedAt
        );

    } catch (Throwable $e) {
        error_log(
            'Notification document review: '
            . $e->getMessage()
        );
    }

    return $count;
}


function tsNotifySyncIncidents(
    PDO $pdo,
    string $startedAt
): int {
    $sourceKey = 'execution_incident';
    $count = 0;

    if (
        !tsNotifyTableExists(
            $pdo,
            'booking_execution_incidents'
        )
        || !tsNotifyTableExists(
            $pdo,
            'bookings'
        )
    ) {
        return 0;
    }

    try {
        $stmt = $pdo->query("
            SELECT
                i.id,
                i.booking_id,
                i.severity,
                i.title,
                i.description,
                i.status,
                i.created_at,
                b.booking_number,
                b.customer_name,
                TIMESTAMPDIFF(
                    HOUR,
                    i.created_at,
                    NOW()
                ) AS open_hours
            FROM booking_execution_incidents i
            JOIN bookings b
                ON b.id = i.booking_id
            WHERE i.status IN (
                    'open',
                    'monitoring'
                  )
            ORDER BY
                CASE i.severity
                    WHEN 'critical' THEN 0
                    WHEN 'high' THEN 1
                    WHEN 'medium' THEN 2
                    ELSE 3
                END,
                i.created_at ASC
            LIMIT 200
        ");

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $incidentSeverity =
                strtolower(
                    (string)$row['severity']
                );

            $hours =
                max(
                    0,
                    (int)$row['open_hours']
                );

            if ($incidentSeverity === 'critical') {
                $severity = 'critical';
                $level = 3;
            } elseif (
                $incidentSeverity === 'high'
                || $hours >= 24
            ) {
                $severity = 'high';
                $level = 2;
            } else {
                $severity = 'warning';
                $level = 1;
            }

            $owner =
                tsNotifyOwnerForBooking(
                    $pdo,
                    (int)$row['booking_id']
                );

            $profiles = ['operations'];

            if ($level >= 3) {
                $profiles[] = 'admin';
                $profiles[] = 'super_admin';
            }

            $recipients =
                tsNotifyRecipients(
                    $pdo,
                    $owner,
                    $profiles,
                    true
                );

            $message =
                ucwords(
                    str_replace(
                        '_',
                        ' ',
                        (string)$row['status']
                    )
                )
                . ' · '
                . ucwords($incidentSeverity)
                . ' severity · open '
                . $hours
                . ' hour'
                . ($hours === 1 ? '' : 's')
                . '.';

            $count +=
                tsNotifyPublishToRecipients(
                    $pdo,
                    $recipients,
                    'execution-incident:'
                        . (int)$row['id'],
                    $sourceKey,
                    'Live Travel / Incident',
                    $severity,
                    $level,
                    'Travel incident · '
                        . (string)$row['booking_number']
                        . ' · '
                        . (string)$row['title'],
                    $message,
                    'booking',
                    (int)$row['booking_id'],
                    'admin-booking-details.php?id='
                        . (int)$row['booking_id']
                        . '#travel-execution',
                    'booking_execution_incidents',
                    (int)$row['id'],
                    null,
                    [
                        'incident_status' =>
                            (string)$row['status'],
                        'incident_severity' =>
                            $incidentSeverity,
                        'open_hours' =>
                            $hours,
                    ],
                    $startedAt
                );
        }

        tsNotifyResolveSource(
            $pdo,
            $sourceKey,
            $startedAt
        );

    } catch (Throwable $e) {
        error_log(
            'Notification execution incidents: '
            . $e->getMessage()
        );
    }

    return $count;
}


function tsNotifySyncFinanceExceptions(
    PDO $pdo,
    string $startedAt
): int {
    $count = 0;

    /*
    |--------------------------------------------------------------------------
    | Supplier invoice received but still unapproved.
    |--------------------------------------------------------------------------
    */

    $sourceKey = 'supplier_invoice_review';

    if (
        tsNotifyTableExists(
            $pdo,
            'supplier_invoices'
        )
        && tsNotifyTableExists(
            $pdo,
            'bookings'
        )
    ) {
        try {
            $stmt = $pdo->query("
                SELECT
                    i.id,
                    i.booking_id,
                    i.invoice_number,
                    i.total_amount,
                    i.currency,
                    i.created_at,
                    b.booking_number,
                    TIMESTAMPDIFF(
                        HOUR,
                        i.created_at,
                        NOW()
                    ) AS waiting_hours
                FROM supplier_invoices i
                JOIN bookings b
                    ON b.id = i.booking_id
                WHERE i.status = 'received'
                  AND i.created_at <= DATE_SUB(
                        NOW(),
                        INTERVAL 24 HOUR
                      )
                ORDER BY i.created_at ASC
                LIMIT 200
            ");

            foreach (
                $stmt->fetchAll(PDO::FETCH_ASSOC)
                ?: []
                as $row
            ) {
                $hours =
                    max(
                        24,
                        (int)$row['waiting_hours']
                    );

                if ($hours >= 96) {
                    $severity = 'high';
                    $level = 2;
                } else {
                    $severity = 'warning';
                    $level = 1;
                }

                $owner =
                    tsNotifyOwnerForBooking(
                        $pdo,
                        (int)$row['booking_id']
                    );

                $recipients =
                    tsNotifyRecipients(
                        $pdo,
                        $owner,
                        ['finance'],
                        true
                    );

                $currency =
                    strtoupper(
                        trim(
                            (string)(
                                $row['currency']
                                ?: 'INR'
                            )
                        )
                    );

                $count +=
                    tsNotifyPublishToRecipients(
                        $pdo,
                        $recipients,
                        'supplier-invoice-review:'
                            . (int)$row['id'],
                        $sourceKey,
                        'Finance / Supplier',
                        $severity,
                        $level,
                        'Supplier invoice awaiting approval · '
                            . (string)$row['booking_number'],
                        'Invoice '
                            . (string)$row['invoice_number']
                            . ' · '
                            . $currency
                            . ' '
                            . number_format(
                                (float)$row['total_amount'],
                                2
                            )
                            . ' · waiting '
                            . $hours
                            . ' hour'
                            . ($hours === 1 ? '' : 's')
                            . '.',
                        'booking',
                        (int)$row['booking_id'],
                        'admin-booking-details.php?id='
                            . (int)$row['booking_id']
                            . '#supplier-finance',
                        'supplier_invoices',
                        (int)$row['id'],
                        null,
                        [
                            'invoice_number' =>
                                (string)$row['invoice_number'],
                            'waiting_hours' =>
                                $hours,
                        ],
                        $startedAt
                    );
            }

            tsNotifyResolveSource(
                $pdo,
                $sourceKey,
                $startedAt
            );

        } catch (Throwable $e) {
            error_log(
                'Notification supplier invoice review: '
                . $e->getMessage()
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Approved supplier invoice payable due / overdue.
    |--------------------------------------------------------------------------
    */

    $sourceKey = 'supplier_payable_due';

    if (
        tsNotifyTableExists(
            $pdo,
            'supplier_invoices'
        )
        && tsNotifyTableExists(
            $pdo,
            'supplier_payments'
        )
        && tsNotifyTableExists(
            $pdo,
            'bookings'
        )
    ) {
        try {
            $stmt = $pdo->query("
                SELECT
                    i.id,
                    i.booking_id,
                    i.invoice_number,
                    i.due_date,
                    i.total_amount,
                    i.currency,
                    b.booking_number,
                    COALESCE(
                        SUM(
                            CASE
                                WHEN p.status = 'paid'
                                THEN p.amount
                                ELSE 0
                            END
                        ),
                        0
                    ) AS paid_amount
                FROM supplier_invoices i
                JOIN bookings b
                    ON b.id = i.booking_id
                LEFT JOIN supplier_payments p
                    ON p.supplier_invoice_id = i.id
                WHERE i.status = 'approved'
                  AND i.due_date IS NOT NULL
                  AND i.due_date <= DATE_ADD(
                        CURDATE(),
                        INTERVAL 3 DAY
                      )
                GROUP BY
                    i.id,
                    i.booking_id,
                    i.invoice_number,
                    i.due_date,
                    i.total_amount,
                    i.currency,
                    b.booking_number
                HAVING
                    i.total_amount - paid_amount > 0.01
                ORDER BY i.due_date ASC
                LIMIT 200
            ");

            foreach (
                $stmt->fetchAll(PDO::FETCH_ASSOC)
                ?: []
                as $row
            ) {
                $days =
                    (int)floor(
                        (
                            strtotime(
                                date('Y-m-d 00:00:00')
                            )
                            - strtotime(
                                (string)$row['due_date']
                                . ' 00:00:00'
                            )
                        ) / 86400
                    );

                if ($days >= 1) {
                    $age =
                        tsNotifyAgeLevel(
                            $days
                        );

                    $severity =
                        (string)$age['severity'];
                    $level =
                        (int)$age['level'];

                } else {
                    $severity = 'warning';
                    $level = 1;
                }

                $outstanding =
                    max(
                        0,
                        (float)$row['total_amount']
                        - (float)$row['paid_amount']
                    );

                $owner =
                    tsNotifyOwnerForBooking(
                        $pdo,
                        (int)$row['booking_id']
                    );

                $profiles = ['finance'];

                if ($level >= 3) {
                    $profiles[] = 'admin';
                    $profiles[] = 'super_admin';
                }

                $recipients =
                    tsNotifyRecipients(
                        $pdo,
                        $owner,
                        $profiles,
                        true
                    );

                $currency =
                    strtoupper(
                        trim(
                            (string)(
                                $row['currency']
                                ?: 'INR'
                            )
                        )
                    );

                $dueText =
                    $days > 0
                        ? (
                            $days
                            . ' day'
                            . ($days === 1 ? '' : 's')
                            . ' overdue'
                        )
                        : (
                            $days === 0
                                ? 'due today'
                                : (
                                    'due in '
                                    . abs($days)
                                    . ' day'
                                    . (
                                        abs($days) === 1
                                            ? ''
                                            : 's'
                                    )
                                )
                        );

                $count +=
                    tsNotifyPublishToRecipients(
                        $pdo,
                        $recipients,
                        'supplier-payable-due:'
                            . (int)$row['id'],
                        $sourceKey,
                        'Finance / Supplier',
                        $severity,
                        $level,
                        'Supplier payment '
                            . $dueText
                            . ' · '
                            . (string)$row['booking_number'],
                        'Invoice '
                            . (string)$row['invoice_number']
                            . ' · Outstanding '
                            . $currency
                            . ' '
                            . number_format(
                                $outstanding,
                                2
                            )
                            . '.',
                        'booking',
                        (int)$row['booking_id'],
                        'admin-booking-details.php?id='
                            . (int)$row['booking_id']
                            . '#supplier-finance',
                        'supplier_invoices',
                        (int)$row['id'],
                        (string)$row['due_date']
                            . ' 23:59:59',
                        [
                            'outstanding' =>
                                $outstanding,
                            'due_date' =>
                                (string)$row['due_date'],
                        ],
                        $startedAt
                    );
            }

            tsNotifyResolveSource(
                $pdo,
                $sourceKey,
                $startedAt
            );

        } catch (Throwable $e) {
            error_log(
                'Notification supplier payable: '
                . $e->getMessage()
            );
        }
    }

    return $count;
}


function tsNotifySyncCommunicationJobs(
    PDO $pdo,
    string $startedAt
): int {
    $sourceKey = 'communication_job';
    $count = 0;

    if (
        !tsNotifyTableExists(
            $pdo,
            'booking_communication_jobs'
        )
        || !tsNotifyTableExists(
            $pdo,
            'bookings'
        )
    ) {
        return 0;
    }

    try {
        $stmt = $pdo->query("
            SELECT
                j.id,
                j.booking_id,
                j.trip_id,
                j.owner_admin_id,
                j.job_type,
                j.template_key,
                j.channel,
                j.due_at,
                j.status,
                j.last_error,
                b.booking_number,
                b.customer_name,
                TIMESTAMPDIFF(
                    HOUR,
                    j.due_at,
                    NOW()
                ) AS overdue_hours
            FROM booking_communication_jobs j
            JOIN bookings b
                ON b.id = j.booking_id
            WHERE
                (
                    j.status = 'failed'
                    OR (
                        j.status = 'pending'
                        AND j.due_at IS NOT NULL
                        AND j.due_at <= DATE_SUB(
                            NOW(),
                            INTERVAL 6 HOUR
                        )
                    )
                )
              AND b.booking_status <> 'cancelled'
            ORDER BY
                CASE
                    WHEN j.status = 'failed'
                    THEN 0
                    ELSE 1
                END,
                j.due_at ASC
            LIMIT 250
        ");

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $failed =
                (string)$row['status']
                === 'failed';

            $hours =
                max(
                    0,
                    (int)$row['overdue_hours']
                );

            if ($failed) {
                $severity = 'high';
                $level = 2;
            } elseif ($hours >= 24) {
                $severity = 'high';
                $level = 2;
            } else {
                $severity = 'warning';
                $level = 1;
            }

            $owner =
                !empty($row['owner_admin_id'])
                    ? (int)$row['owner_admin_id']
                    : tsNotifyOwnerForBooking(
                        $pdo,
                        (int)$row['booking_id']
                    );

            $recipients =
                tsNotifyRecipients(
                    $pdo,
                    $owner,
                    ['sales'],
                    true
                );

            $message =
                ucwords(
                    str_replace(
                        '_',
                        ' ',
                        (string)$row['job_type']
                    )
                )
                . ' · '
                . strtoupper(
                    (string)$row['channel']
                )
                . '.';

            if ($failed) {
                $message .=
                    ' Failed'
                    . (
                        trim(
                            (string)(
                                $row['last_error']
                                ?? ''
                            )
                        ) !== ''
                            ? (
                                ': '
                                . trim(
                                    (string)$row['last_error']
                                )
                            )
                            : '.'
                    );
            } else {
                $message .=
                    ' Overdue by '
                    . $hours
                    . ' hour'
                    . ($hours === 1 ? '' : 's')
                    . '.';
            }

            $count +=
                tsNotifyPublishToRecipients(
                    $pdo,
                    $recipients,
                    'communication-job:'
                        . (int)$row['id'],
                    $sourceKey,
                    'Customer Communication',
                    $severity,
                    $level,
                    'Customer communication follow-up · '
                        . (string)$row['booking_number'],
                    $message,
                    'booking',
                    (int)$row['booking_id'],
                    'admin-booking-communications.php?booking='
                        . (int)$row['booking_id'],
                    'booking_communication_jobs',
                    (int)$row['id'],
                    $row['due_at']
                        ?: null,
                    [
                        'job_type' =>
                            (string)$row['job_type'],
                        'channel' =>
                            (string)$row['channel'],
                        'job_status' =>
                            (string)$row['status'],
                    ],
                    $startedAt
                );
        }

        tsNotifyResolveSource(
            $pdo,
            $sourceKey,
            $startedAt
        );

    } catch (Throwable $e) {
        error_log(
            'Notification communication jobs: '
            . $e->getMessage()
        );
    }

    return $count;
}


function tsNotifySyncRepeatSales(
    PDO $pdo,
    string $startedAt
): int {
    $sourceKey = 'repeat_sales_due';
    $count = 0;

    if (!tsNotifyTableExists(
        $pdo,
        'repeat_sales_opportunities'
    )) {
        return 0;
    }

    try {
        $stmt = $pdo->query("
            SELECT
                id,
                source_booking_id,
                customer_name,
                owner_admin_id,
                status,
                next_action_date,
                preferred_destination,
                DATEDIFF(
                    CURDATE(),
                    next_action_date
                ) AS overdue_days
            FROM repeat_sales_opportunities
            WHERE status IN (
                    'new',
                    'contact_due',
                    'contacted',
                    'interested',
                    'deferred'
                  )
              AND next_action_date IS NOT NULL
              AND next_action_date <= CURDATE()
            ORDER BY next_action_date ASC
            LIMIT 200
        ");

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $days =
                max(
                    0,
                    (int)$row['overdue_days']
                );

            if ($days >= 7) {
                $severity = 'high';
                $level = 2;
            } else {
                $severity = 'warning';
                $level = 1;
            }

            $recipients =
                tsNotifyRecipients(
                    $pdo,
                    !empty($row['owner_admin_id'])
                        ? (int)$row['owner_admin_id']
                        : null,
                    ['sales'],
                    true
                );

            $message =
                'Repeat-customer follow-up'
                . (
                    !empty($row['preferred_destination'])
                        ? (
                            ' · '
                            . (string)$row[
                                'preferred_destination'
                            ]
                        )
                        : ''
                )
                . (
                    $days > 0
                        ? (
                            ' · '
                            . $days
                            . ' day'
                            . ($days === 1 ? '' : 's')
                            . ' overdue.'
                        )
                        : ' · due today.'
                );

            $count +=
                tsNotifyPublishToRecipients(
                    $pdo,
                    $recipients,
                    'repeat-sales:'
                        . (int)$row['id'],
                    $sourceKey,
                    'Repeat Sales',
                    $severity,
                    $level,
                    'Repeat Sales follow-up · '
                        . (string)$row['customer_name'],
                    $message,
                    'repeat_sales_opportunity',
                    (int)$row['id'],
                    'admin-business-analytics.php?repeat=due#repeat-sales',
                    'repeat_sales_opportunities',
                    (int)$row['id'],
                    (string)$row['next_action_date']
                        . ' 23:59:59',
                    [
                        'source_booking_id' =>
                            (int)$row['source_booking_id'],
                        'status' =>
                            (string)$row['status'],
                    ],
                    $startedAt
                );
        }

        tsNotifyResolveSource(
            $pdo,
            $sourceKey,
            $startedAt
        );

    } catch (Throwable $e) {
        error_log(
            'Notification repeat sales: '
            . $e->getMessage()
        );
    }

    return $count;
}


function tsNotifySyncNewEnquiries(
    PDO $pdo,
    string $startedAt
): int {
    $sourceKey = 'new_enquiry';
    $count = 0;

    if (!tsNotifyTableExists($pdo, 'enquiries')) {
        return 0;
    }

    $hasMeta =
        tsNotifyTableExists(
            $pdo,
            'crm_lead_meta'
        );

    try {
        if ($hasMeta) {
            $stmt = $pdo->query("
                SELECT
                    e.id,
                    e.name,
                    e.destination,
                    e.created_at,
                    m.assigned_admin_id,
                    TIMESTAMPDIFF(
                        HOUR,
                        e.created_at,
                        NOW()
                    ) AS waiting_hours
                FROM enquiries e
                LEFT JOIN crm_lead_meta m
                    ON m.enquiry_id = e.id
                WHERE e.status = 'new'
                  AND e.created_at <= DATE_SUB(
                        NOW(),
                        INTERVAL 2 HOUR
                      )
                  AND (
                        m.enquiry_id IS NULL
                        OR m.assigned_admin_id IS NULL
                        OR m.assigned_admin_id = 0
                      )
                ORDER BY e.created_at ASC
                LIMIT 200
            ");
        } else {
            $stmt = $pdo->query("
                SELECT
                    e.id,
                    e.name,
                    e.destination,
                    e.created_at,
                    NULL AS assigned_admin_id,
                    TIMESTAMPDIFF(
                        HOUR,
                        e.created_at,
                        NOW()
                    ) AS waiting_hours
                FROM enquiries e
                WHERE e.status = 'new'
                  AND e.created_at <= DATE_SUB(
                        NOW(),
                        INTERVAL 2 HOUR
                      )
                ORDER BY e.created_at ASC
                LIMIT 200
            ");
        }

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $hours =
                max(
                    2,
                    (int)$row['waiting_hours']
                );

            if ($hours >= 24) {
                $severity = 'high';
                $level = 2;
            } else {
                $severity = 'warning';
                $level = 1;
            }

            $recipients =
                tsNotifyRecipients(
                    $pdo,
                    null,
                    ['sales','admin','super_admin'],
                    false
                );

            $message =
                (string)$row['name']
                . (
                    trim(
                        (string)(
                            $row['destination']
                            ?? ''
                        )
                    ) !== ''
                        ? (
                            ' · '
                            . (string)$row['destination']
                        )
                        : ''
                )
                . ' · waiting '
                . $hours
                . ' hour'
                . ($hours === 1 ? '' : 's')
                . ' for CRM ownership.';

            $count +=
                tsNotifyPublishToRecipients(
                    $pdo,
                    $recipients,
                    'new-enquiry:'
                        . (int)$row['id'],
                    $sourceKey,
                    'Sales / CRM',
                    $severity,
                    $level,
                    'New enquiry needs owner',
                    $message,
                    'enquiry',
                    (int)$row['id'],
                    'admin-crm.php?lead='
                        . (int)$row['id'],
                    'enquiries',
                    (int)$row['id'],
                    null,
                    [
                        'waiting_hours' =>
                            $hours,
                    ],
                    $startedAt
                );
        }

        tsNotifyResolveSource(
            $pdo,
            $sourceKey,
            $startedAt
        );

    } catch (Throwable $e) {
        error_log(
            'Notification new enquiries: '
            . $e->getMessage()
        );
    }

    return $count;
}


function tsNotifySyncCancellations(
    PDO $pdo,
    string $startedAt
): int {
    $sourceKey = 'pending_cancellation';
    $count = 0;

    if (
        !tsNotifyTableExists(
            $pdo,
            'booking_cancellations'
        )
        || !tsNotifyTableExists(
            $pdo,
            'bookings'
        )
    ) {
        return 0;
    }

    try {
        $stmt = $pdo->query("
            SELECT
                c.id,
                c.booking_id,
                c.created_at,
                b.booking_number,
                b.customer_name,
                b.travel_date,
                TIMESTAMPDIFF(
                    HOUR,
                    c.created_at,
                    NOW()
                ) AS waiting_hours
            FROM booking_cancellations c
            JOIN bookings b
                ON b.id = c.booking_id
            WHERE c.status = 'pending'
              AND c.created_at <= DATE_SUB(
                    NOW(),
                    INTERVAL 6 HOUR
                  )
            ORDER BY c.created_at ASC
            LIMIT 150
        ");

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $hours =
                max(
                    6,
                    (int)$row['waiting_hours']
                );

            $daysToTravel =
                $row['travel_date']
                    ? (int)floor(
                        (
                            strtotime(
                                (string)$row['travel_date']
                                . ' 00:00:00'
                            )
                            - strtotime(
                                date('Y-m-d 00:00:00')
                            )
                        ) / 86400
                    )
                    : 999;

            if (
                $daysToTravel <= 7
                || $hours >= 48
            ) {
                $severity = 'high';
                $level = 2;
            } else {
                $severity = 'warning';
                $level = 1;
            }

            $owner =
                tsNotifyOwnerForBooking(
                    $pdo,
                    (int)$row['booking_id']
                );

            $recipients =
                tsNotifyRecipients(
                    $pdo,
                    $owner,
                    ['operations','admin','super_admin'],
                    true
                );

            $count +=
                tsNotifyPublishToRecipients(
                    $pdo,
                    $recipients,
                    'pending-cancellation:'
                        . (int)$row['id'],
                    $sourceKey,
                    'Booking / Cancellation',
                    $severity,
                    $level,
                    'Cancellation request pending · '
                        . (string)$row['booking_number'],
                    (string)$row['customer_name']
                        . ' · waiting '
                        . $hours
                        . ' hour'
                        . ($hours === 1 ? '' : 's')
                        . ' for decision.',
                    'booking',
                    (int)$row['booking_id'],
                    'admin-cancellations.php?status=pending',
                    'booking_cancellations',
                    (int)$row['id'],
                    null,
                    [
                        'waiting_hours' =>
                            $hours,
                        'days_to_travel' =>
                            $daysToTravel,
                    ],
                    $startedAt
                );
        }

        tsNotifyResolveSource(
            $pdo,
            $sourceKey,
            $startedAt
        );

    } catch (Throwable $e) {
        error_log(
            'Notification cancellations: '
            . $e->getMessage()
        );
    }

    return $count;
}


function tsNotifySync(
    PDO $pdo
): array {
    if (!tsNotifyReady($pdo)) {
        return [
            'ready' => false,
            'created_or_updated' => 0,
            'sources' => [],
        ];
    }

    $startedAt =
        date('Y-m-d H:i:s');

    $sources = [];

    $sources['trip_next_action'] =
        tsNotifySyncTripActions(
            $pdo,
            $startedAt
        );

    $sources['new_enquiry'] =
        tsNotifySyncNewEnquiries(
            $pdo,
            $startedAt
        );

    $sources['supplier_confirmation'] =
        tsNotifySyncSupplierConfirmations(
            $pdo,
            $startedAt
        );

    $sources['customer_collection'] =
        tsNotifySyncCollections(
            $pdo,
            $startedAt
        );

    $sources['departure_readiness'] =
        tsNotifySyncDepartureReadiness(
            $pdo,
            $startedAt
        );

    $sources['document_review'] =
        tsNotifySyncDocumentReview(
            $pdo,
            $startedAt
        );

    $sources['execution_incident'] =
        tsNotifySyncIncidents(
            $pdo,
            $startedAt
        );

    $sources['finance_exceptions'] =
        tsNotifySyncFinanceExceptions(
            $pdo,
            $startedAt
        );

    $sources['communication_job'] =
        tsNotifySyncCommunicationJobs(
            $pdo,
            $startedAt
        );

    $sources['repeat_sales_due'] =
        tsNotifySyncRepeatSales(
            $pdo,
            $startedAt
        );

    $sources['pending_cancellation'] =
        tsNotifySyncCancellations(
            $pdo,
            $startedAt
        );

    tsNotifyStateSet(
        $pdo,
        'last_sync_at',
        date('Y-m-d H:i:s')
    );

    return [
        'ready' => true,
        'created_or_updated' =>
            array_sum($sources),
        'sources' => $sources,
    ];
}


function tsNotifyMaybeSync(
    PDO $pdo,
    int $minimumSeconds = 300
): bool {
    if (!tsNotifyReady($pdo)) {
        return false;
    }

    $last =
        tsNotifyStateGet(
            $pdo,
            'last_sync_at'
        );

    if ($last) {
        $lastTs =
            strtotime($last);

        if (
            $lastTs
            && (
                time() - $lastTs
            ) < max(
                60,
                $minimumSeconds
            )
        ) {
            return false;
        }
    }

    /*
    | Write a throttle marker before the scan so simultaneous page loads do not
    | all perform the full notification scan.
    */
    tsNotifyStateSet(
        $pdo,
        'last_sync_at',
        date('Y-m-d H:i:s')
    );

    tsNotifySync($pdo);

    return true;
}


function tsNotifySummary(
    PDO $pdo,
    int $adminId
): array {
    $empty = [
        'unread' => 0,
        'critical' => 0,
        'high' => 0,
        'warning' => 0,
        'due' => 0,
    ];

    if (
        $adminId <= 0
        || !tsNotifyReady($pdo)
    ) {
        return $empty;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT
                SUM(
                    CASE
                        WHEN status = 'unread'
                        THEN 1
                        ELSE 0
                    END
                ) AS unread_count,
                SUM(
                    CASE
                        WHEN status IN ('unread','read')
                         AND severity = 'critical'
                        THEN 1
                        ELSE 0
                    END
                ) AS critical_count,
                SUM(
                    CASE
                        WHEN status IN ('unread','read')
                         AND severity = 'high'
                        THEN 1
                        ELSE 0
                    END
                ) AS high_count,
                SUM(
                    CASE
                        WHEN status IN ('unread','read')
                         AND severity = 'warning'
                        THEN 1
                        ELSE 0
                    END
                ) AS warning_count,
                SUM(
                    CASE
                        WHEN status IN ('unread','read')
                         AND due_at IS NOT NULL
                         AND due_at <= NOW()
                        THEN 1
                        ELSE 0
                    END
                ) AS due_count
            FROM admin_notifications
            WHERE admin_id = ?
        ");
        $stmt->execute([$adminId]);

        $row =
            $stmt->fetch(PDO::FETCH_ASSOC)
            ?: [];

        return [
            'unread' =>
                (int)($row['unread_count'] ?? 0),
            'critical' =>
                (int)($row['critical_count'] ?? 0),
            'high' =>
                (int)($row['high_count'] ?? 0),
            'warning' =>
                (int)($row['warning_count'] ?? 0),
            'due' =>
                (int)($row['due_count'] ?? 0),
        ];

    } catch (Throwable $e) {
        return $empty;
    }
}


function tsNotifyRows(
    PDO $pdo,
    int $adminId,
    string $statusFilter = 'active',
    string $severityFilter = '',
    string $categoryFilter = ''
): array {
    if (
        $adminId <= 0
        || !tsNotifyReady($pdo)
    ) {
        return [];
    }

    $where = [
        'admin_id = ?',
    ];

    $params = [
        $adminId,
    ];

    if ($statusFilter === 'unread') {
        $where[] =
            "status = 'unread'";

    } elseif ($statusFilter === 'dismissed') {
        $where[] =
            "status = 'dismissed'";

    } elseif ($statusFilter === 'resolved') {
        $where[] =
            "status = 'resolved'";

    } elseif ($statusFilter === 'all') {
        // No status condition.

    } else {
        $where[] =
            "status IN ('unread','read')";
    }

    if (
        in_array(
            $severityFilter,
            ['info','warning','high','critical'],
            true
        )
    ) {
        $where[] =
            'severity = ?';

        $params[] =
            $severityFilter;
    }

    if ($categoryFilter !== '') {
        $where[] =
            'category = ?';

        $params[] =
            $categoryFilter;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT *
            FROM admin_notifications
            WHERE "
            . implode(
                ' AND ',
                $where
            )
            . "
            ORDER BY
                CASE severity
                    WHEN 'critical' THEN 0
                    WHEN 'high' THEN 1
                    WHEN 'warning' THEN 2
                    ELSE 3
                END,
                CASE
                    WHEN status = 'unread'
                    THEN 0
                    ELSE 1
                END,
                COALESCE(
                    due_at,
                    '9999-12-31 23:59:59'
                ) ASC,
                last_detected_at DESC
            LIMIT 250
        ");

        $stmt->execute($params);

        return
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: [];

    } catch (Throwable $e) {
        error_log(
            'Notification inbox fetch: '
            . $e->getMessage()
        );

        return [];
    }
}


function tsNotifyCategories(
    PDO $pdo,
    int $adminId
): array {
    if (
        $adminId <= 0
        || !tsNotifyReady($pdo)
    ) {
        return [];
    }

    try {
        $stmt = $pdo->prepare("
            SELECT DISTINCT category
            FROM admin_notifications
            WHERE admin_id = ?
            ORDER BY category ASC
        ");
        $stmt->execute([$adminId]);

        return
            $stmt->fetchAll(PDO::FETCH_COLUMN)
            ?: [];

    } catch (Throwable $e) {
        return [];
    }
}


function tsNotifySetStatus(
    PDO $pdo,
    int $adminId,
    int $notificationId,
    string $status
): void {
    if (
        $adminId <= 0
        || $notificationId <= 0
        || !tsNotifyReady($pdo)
    ) {
        throw new RuntimeException(
            'Notification was not found.'
        );
    }

    if (
        !in_array(
            $status,
            ['unread','read','dismissed'],
            true
        )
    ) {
        throw new RuntimeException(
            'Invalid notification action.'
        );
    }

    $stmt = $pdo->prepare("
        UPDATE admin_notifications
        SET
            status = ?,
            read_at =
                CASE
                    WHEN ? = 'read'
                    THEN NOW()
                    WHEN ? = 'unread'
                    THEN NULL
                    ELSE read_at
                END,
            dismissed_at =
                CASE
                    WHEN ? = 'dismissed'
                    THEN NOW()
                    WHEN ? <> 'dismissed'
                    THEN NULL
                    ELSE dismissed_at
                END,
            updated_at = NOW()
        WHERE id = ?
          AND admin_id = ?
          AND status <> 'resolved'
    ");

    $stmt->execute([
        $status,
        $status,
        $status,
        $status,
        $status,
        $notificationId,
        $adminId,
    ]);
}


function tsNotifyMarkAllRead(
    PDO $pdo,
    int $adminId
): int {
    if (
        $adminId <= 0
        || !tsNotifyReady($pdo)
    ) {
        return 0;
    }

    $stmt = $pdo->prepare("
        UPDATE admin_notifications
        SET
            status = 'read',
            read_at = NOW(),
            updated_at = NOW()
        WHERE admin_id = ?
          AND status = 'unread'
    ");

    $stmt->execute([$adminId]);

    return
        $stmt->rowCount();
}


function tsNotifyAbsoluteUrl(?string $linkUrl): string
{
    $linkUrl =
        trim(
            (string)$linkUrl
        );

    if ($linkUrl === '') {
        return
            defined('BASE_URL')
                ? rtrim(
                    (string)BASE_URL,
                    '/'
                )
                : '';
    }

    if (
        preg_match(
            '#^https?://#i',
            $linkUrl
        )
    ) {
        return $linkUrl;
    }

    return
        (
            defined('BASE_URL')
                ? rtrim(
                    (string)BASE_URL,
                    '/'
                )
                : ''
        )
        . '/'
        . ltrim(
            $linkUrl,
            '/'
        );
}


function tsNotifySendAdminEmail(
    array $notification,
    array $admin
): array {
    $email =
        trim(
            (string)(
                $admin['email']
                ?? ''
            )
        );

    if (
        !filter_var(
            $email,
            FILTER_VALIDATE_EMAIL
        )
    ) {
        return [
            'ok' => false,
            'message' =>
                'Admin email is unavailable.',
        ];
    }

    if (
        !class_exists(
            '\PHPMailer\PHPMailer\PHPMailer'
        )
    ) {
        return [
            'ok' => false,
            'message' =>
                'PHPMailer is unavailable.',
        ];
    }

    try {
        $mail =
            new \PHPMailer\PHPMailer\PHPMailer(
                true
            );

        if (
            defined('SMTP_ENABLED')
            && SMTP_ENABLED
        ) {
            $mail->isSMTP();

            $mail->Host =
                defined('SMTP_HOST')
                    ? (string)SMTP_HOST
                    : 'smtp.gmail.com';

            $mail->SMTPAuth =
                defined('SMTP_AUTH')
                    ? (bool)SMTP_AUTH
                    : true;

            $mail->Username =
                defined('SMTP_USERNAME')
                    ? (string)SMTP_USERNAME
                    : '';

            $mail->Password =
                defined('SMTP_PASSWORD')
                    ? (string)SMTP_PASSWORD
                    : '';

            $mail->SMTPSecure =
                defined('SMTP_ENCRYPTION')
                    ? (string)SMTP_ENCRYPTION
                    : 'tls';

            $mail->Port =
                defined('SMTP_PORT')
                    ? (int)SMTP_PORT
                    : 587;
        }

        $from =
            defined('MAIL_FROM_ADDRESS')
                ? trim(
                    (string)MAIL_FROM_ADDRESS
                )
                : (
                    defined('SMTP_USERNAME')
                        ? trim(
                            (string)SMTP_USERNAME
                        )
                        : ''
                );

        if (
            !filter_var(
                $from,
                FILTER_VALIDATE_EMAIL
            )
        ) {
            throw new RuntimeException(
                'Mail From address is not configured.'
            );
        }

        $fromName =
            defined('MAIL_FROM_NAME')
                ? trim(
                    (string)MAIL_FROM_NAME
                )
                : 'TRAVSCOPE.COM';

        $mail->setFrom(
            $from,
            $fromName !== ''
                ? $fromName
                : 'TRAVSCOPE.COM'
        );

        $mail->addAddress(
            $email,
            (string)(
                $admin['name']
                ?? ''
            )
        );

        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';

        $severity =
            strtoupper(
                (string)(
                    $notification['severity']
                    ?? 'ALERT'
                )
            );

        $mail->Subject =
            '[TRAVSCOPE '
            . $severity
            . '] '
            . (string)$notification['title'];

        $url =
            tsNotifyAbsoluteUrl(
                (string)(
                    $notification['link_url']
                    ?? ''
                )
            );

        $safeTitle =
            htmlspecialchars(
                (string)$notification['title'],
                ENT_QUOTES,
                'UTF-8'
            );

        $safeMessage =
            nl2br(
                htmlspecialchars(
                    (string)(
                        $notification['message']
                        ?? ''
                    ),
                    ENT_QUOTES,
                    'UTF-8'
                )
            );

        $safeUrl =
            htmlspecialchars(
                $url,
                ENT_QUOTES,
                'UTF-8'
            );

        $mail->Body =
            '<div style="font-family:Arial,sans-serif;color:#172033;line-height:1.6">'
            . '<div style="font-size:11px;font-weight:800;color:#64748b">'
            . 'TRAVSCOPE SYSTEM ALERT · '
            . htmlspecialchars(
                $severity,
                ENT_QUOTES,
                'UTF-8'
            )
            . '</div>'
            . '<h2 style="font-size:18px;margin:7px 0 8px">'
            . $safeTitle
            . '</h2>'
            . '<div style="font-size:14px">'
            . $safeMessage
            . '</div>'
            . (
                $url !== ''
                    ? (
                        '<p style="margin-top:18px">'
                        . '<a href="'
                        . $safeUrl
                        . '" style="display:inline-block;padding:10px 14px;border-radius:8px;background:#2563eb;color:#fff;text-decoration:none;font-weight:700">'
                        . 'Open in TRAVSCOPE'
                        . '</a></p>'
                    )
                    : ''
            )
            . '<p style="margin-top:18px;color:#64748b;font-size:11px">'
            . 'This email was generated by the TRAVSCOPE System Notifications & Escalation Engine.'
            . '</p></div>';

        $mail->AltBody =
            $severity
            . ' | '
            . (string)$notification['title']
            . "\n\n"
            . (string)(
                $notification['message']
                ?? ''
            )
            . (
                $url !== ''
                    ? "\n\nOpen: " . $url
                    : ''
            );

        $mail->send();

        return [
            'ok' => true,
            'message' => 'Sent',
        ];

    } catch (Throwable $e) {
        error_log(
            'Notification email: '
            . $e->getMessage()
        );

        return [
            'ok' => false,
            'message' =>
                $e->getMessage(),
        ];
    }
}


function tsNotifySendEscalationEmails(
    PDO $pdo,
    int $limit = 50
): array {
    $result = [
        'eligible' => 0,
        'sent' => 0,
        'failed' => 0,
        'messages' => [],
    ];

    if (!tsNotifyReady($pdo)) {
        $result['messages'][] =
            'Notification SQL is not installed.';

        return $result;
    }

    $adminsById = [];

    foreach (tsNotifyAdmins($pdo) as $admin) {
        $adminsById[(int)$admin['id']] =
            $admin;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT *
            FROM admin_notifications
            WHERE status = 'unread'
              AND severity IN (
                    'high',
                    'critical'
                  )
              AND escalation_level > email_escalation_level
            ORDER BY
                CASE severity
                    WHEN 'critical' THEN 0
                    ELSE 1
                END,
                last_detected_at ASC
            LIMIT "
            . max(
                1,
                min(
                    200,
                    $limit
                )
            )
        );

        $stmt->execute();

        $rows =
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: [];

        $result['eligible'] =
            count($rows);

        $mark =
            $pdo->prepare("
                UPDATE admin_notifications
                SET
                    email_sent_at = NOW(),
                    email_escalation_level = escalation_level,
                    updated_at = NOW()
                WHERE id = ?
            ");

        foreach ($rows as $notification) {
            $admin =
                $adminsById[
                    (int)$notification['admin_id']
                ]
                ?? null;

            if (!$admin) {
                $result['failed']++;
                $result['messages'][] =
                    'Admin missing for notification #'
                    . (int)$notification['id'];
                continue;
            }

            $sent =
                tsNotifySendAdminEmail(
                    $notification,
                    $admin
                );

            if (!empty($sent['ok'])) {
                $mark->execute([
                    (int)$notification['id']
                ]);

                $result['sent']++;

            } else {
                $result['failed']++;

                $result['messages'][] =
                    'Notification #'
                    . (int)$notification['id']
                    . ': '
                    . (string)$sent['message'];
            }
        }

    } catch (Throwable $e) {
        $result['messages'][] =
            $e->getMessage();
    }

    return $result;
}
