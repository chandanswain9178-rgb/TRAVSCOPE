<?php
declare(strict_types=1);

if (is_file(__DIR__ . '/supplier-payables-functions.php')) { require_once __DIR__ . '/supplier-payables-functions.php'; }

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — SUPPLIER FINANCE + ACTUAL PROFITABILITY
|--------------------------------------------------------------------------
|
| Expected cost remains frozen at quotation acceptance in booking_trip_links.
| Actual supplier cost comes ONLY from APPROVED supplier invoices.
| Supplier payments affect payable/cash, not profitability.
| Actual direct cost comes from POSTED direct-cost records.
|
*/

function tsFinTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];

    $key = strtolower($table);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
              AND table_name = ?
        ");
        $stmt->execute([$table]);

        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}


function tsFinReady(PDO $pdo): bool
{
    return
        tsFinTableExists($pdo, 'supplier_invoices')
        && tsFinTableExists($pdo, 'supplier_invoice_items')
        && tsFinTableExists($pdo, 'supplier_payments')
        && tsFinTableExists($pdo, 'booking_actual_direct_costs')
        && tsFinTableExists($pdo, 'booking_profitability_closures')
        && tsFinTableExists($pdo, 'bookings');
}


function tsFinPaymentMethods(): array
{
    return [
        'bank_transfer' => 'Bank Transfer',
        'upi' => 'UPI',
        'card' => 'Card',
        'cash' => 'Cash',
        'cheque' => 'Cheque',
        'wallet' => 'Wallet',
        'other' => 'Other',
    ];
}


function tsFinDirectCostTypes(): array
{
    return [
        'operations' => 'Operations Cost',
        'bank_fee' => 'Bank / Gateway Fee',
        'courier' => 'Courier / Delivery',
        'staff_expense' => 'Staff / Tour Expense',
        'emergency' => 'Emergency / On-Tour Expense',
        'refund_adjustment' => 'Refund / Adjustment Cost',
        'other' => 'Other Direct Cost',
    ];
}


function tsFinBookingRow(PDO $pdo, int $bookingId): array
{
    $stmt = $pdo->prepare("
        SELECT *
        FROM bookings
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$bookingId]);

    $booking = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$booking) {
        throw new RuntimeException('Booking was not found.');
    }

    return $booking;
}


function tsFinTripLink(PDO $pdo, int $bookingId): ?array
{
    if (
        $bookingId <= 0
        || !tsFinTableExists($pdo, 'booking_trip_links')
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT
            l.*,
            t.trip_code
        FROM booking_trip_links l
        LEFT JOIN trips t
            ON t.id = l.trip_id
        WHERE l.booking_id = ?
        LIMIT 1
    ");
    $stmt->execute([$bookingId]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function tsFinClosure(PDO $pdo, int $bookingId): ?array
{
    if (
        $bookingId <= 0
        || !tsFinReady($pdo)
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_profitability_closures
        WHERE booking_id = ?
        LIMIT 1
    ");
    $stmt->execute([$bookingId]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function tsFinAssertOpen(PDO $pdo, int $bookingId): void
{
    if (tsFinClosure($pdo, $bookingId)) {
        throw new RuntimeException(
            'Profitability is already financially closed for this Booking.'
        );
    }
}


function tsFinUpload(array $file, string $prefix = 'finance'): array
{
    if (
        empty($file)
        || !isset($file['error'])
        || $file['error'] === UPLOAD_ERR_NO_FILE
    ) {
        return [
            'path' => null,
            'name' => null
        ];
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException(
            'Finance attachment upload failed.'
        );
    }

    if ((int)$file['size'] > 12 * 1024 * 1024) {
        throw new RuntimeException(
            'Finance attachment must be smaller than 12 MB.'
        );
    }

    if (!is_uploaded_file((string)$file['tmp_name'])) {
        throw new RuntimeException(
            'Invalid finance attachment.'
        );
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime =
        (string)$finfo->file(
            (string)$file['tmp_name']
        );

    $allowed = [
        'application/pdf' => 'pdf',
        'application/vnd.ms-excel' => 'xls',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
        'application/msword' => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($allowed[$mime])) {
        throw new RuntimeException(
            'Allowed finance attachments: PDF, Excel, Word, JPG, PNG or WEBP.'
        );
    }

    $dir =
        __DIR__
        . '/uploads/booking-finance/';

    if (
        !is_dir($dir)
        && !mkdir($dir, 0755, true)
        && !is_dir($dir)
    ) {
        throw new RuntimeException(
            'Unable to create Booking finance upload directory.'
        );
    }

    $original =
        basename(
            (string)(
                $file['name']
                ?? 'finance-document'
            )
        );

    $base =
        preg_replace(
            '/[^A-Za-z0-9._-]+/',
            '-',
            pathinfo(
                $original,
                PATHINFO_FILENAME
            )
        );

    $base =
        trim(
            (string)$base,
            '-_.'
        ) ?: 'finance-document';

    $name =
        substr($base, 0, 80)
        . '-'
        . $prefix
        . '-'
        . date('YmdHis')
        . '-'
        . bin2hex(random_bytes(4))
        . '.'
        . $allowed[$mime];

    if (
        !move_uploaded_file(
            (string)$file['tmp_name'],
            $dir . $name
        )
    ) {
        throw new RuntimeException(
            'Unable to save finance attachment.'
        );
    }

    return [
        'path' =>
            'uploads/booking-finance/'
            . $name,
        'name' => $original
    ];
}


function tsFinBookingSuppliers(PDO $pdo, int $bookingId): array
{
    if (
        $bookingId <= 0
        || !tsFinTableExists($pdo, 'booking_service_snapshots')
    ) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT
            s.id,
            s.company_name,
            COUNT(bs.id) AS service_count,
            COALESCE(
                SUM(bs.internal_supplier_cost),
                0
            ) AS expected_service_cost
        FROM booking_service_snapshots bs
        JOIN suppliers s
            ON s.id = bs.source_supplier_id
        WHERE bs.booking_id = ?
          AND bs.source_supplier_id IS NOT NULL
        GROUP BY s.id, s.company_name
        ORDER BY s.company_name ASC
    ");
    $stmt->execute([$bookingId]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsFinBookingServices(PDO $pdo, int $bookingId): array
{
    if (
        $bookingId <= 0
        || !tsFinTableExists($pdo, 'booking_service_snapshots')
    ) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT
            bs.*,
            s.company_name AS supplier_name
        FROM booking_service_snapshots bs
        LEFT JOIN suppliers s
            ON s.id = bs.source_supplier_id
        WHERE bs.booking_id = ?
        ORDER BY bs.sort_order ASC, bs.id ASC
    ");
    $stmt->execute([$bookingId]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsFinInvoices(PDO $pdo, int $bookingId): array
{
    if (
        $bookingId <= 0
        || !tsFinReady($pdo)
    ) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT
            i.*,
            s.company_name,
            COALESCE(
                (
                    SELECT SUM(p.amount)
                    FROM supplier_payments p
                    WHERE p.supplier_invoice_id = i.id
                      AND p.status = 'paid'
                ),
                0
            ) AS paid_amount
        FROM supplier_invoices i
        JOIN suppliers s
            ON s.id = i.supplier_id
        WHERE i.booking_id = ?
        ORDER BY i.invoice_date DESC, i.id DESC
    ");
    $stmt->execute([$bookingId]);

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    foreach ($rows as &$row) {
        if (function_exists('spaReady') && spaReady($pdo)) {
            $row['approved_payable_amount'] = spaEffectiveInvoiceTotal($pdo, $row);
            $row['advance_allocated'] = spaInvoiceAdvanceAllocated($pdo, (int)$row['id']);
            $row['adjustment_net'] = spaInvoiceAdjustmentsNet($pdo, (int)$row['id']);
            $row['outstanding_amount'] = spaInvoiceOutstanding($pdo, $row);
            $row['control'] = spaInvoiceControl($pdo, (int)$row['id']);
        } else {
            $row['outstanding_amount'] =
                max(
                    0,
                    (float)$row['total_amount']
                    - (float)$row['paid_amount']
                );
        }
    }
    unset($row);

    return $rows;
}


function tsFinInvoiceItems(PDO $pdo, int $invoiceId): array
{
    if ($invoiceId <= 0 || !tsFinReady($pdo)) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT
            ii.*,
            bs.title AS service_title,
            bs.service_type
        FROM supplier_invoice_items ii
        LEFT JOIN booking_service_snapshots bs
            ON bs.id = ii.booking_service_snapshot_id
        WHERE ii.supplier_invoice_id = ?
        ORDER BY ii.sort_order ASC, ii.id ASC
    ");
    $stmt->execute([$invoiceId]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsFinSupplierPayments(PDO $pdo, int $bookingId): array
{
    if (
        $bookingId <= 0
        || !tsFinReady($pdo)
    ) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT
            p.*,
            i.invoice_number,
            s.company_name
        FROM supplier_payments p
        JOIN supplier_invoices i
            ON i.id = p.supplier_invoice_id
        JOIN suppliers s
            ON s.id = p.supplier_id
        WHERE p.booking_id = ?
        ORDER BY p.payment_date DESC, p.id DESC
    ");
    $stmt->execute([$bookingId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    if (function_exists('spaReady') && spaReady($pdo)) {
        foreach ($rows as &$row) {
            try {
                $c=$pdo->prepare("SELECT * FROM supplier_payment_controls WHERE supplier_payment_id=? LIMIT 1");
                $c->execute([(int)$row['id']]);
                $pc=$c->fetch(PDO::FETCH_ASSOC)?:[];
                $row['settlement_amount']=(float)($pc['settlement_amount']??$row['amount']);
                $row['transfer_amount']=(float)($pc['transfer_amount']??$row['amount']);
                $row['tds_amount']=(float)($pc['tds_amount']??0);
                $row['other_deduction']=(float)($pc['other_deduction']??0);
                $v=$pdo->prepare("SELECT id,voucher_number,status FROM supplier_payment_vouchers WHERE supplier_payment_id=? LIMIT 1");
                $v->execute([(int)$row['id']]);
                $row['voucher']=$v->fetch(PDO::FETCH_ASSOC)?:null;
            } catch (Throwable $e) {}
        }
        unset($row);
    }
    return $rows;
}


function tsFinDirectCosts(PDO $pdo, int $bookingId): array
{
    if (
        $bookingId <= 0
        || !tsFinReady($pdo)
    ) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_actual_direct_costs
        WHERE booking_id = ?
        ORDER BY cost_date DESC, id DESC
    ");
    $stmt->execute([$bookingId]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsFinSummary(PDO $pdo, int $bookingId): array
{
    $booking =
        tsFinBookingRow(
            $pdo,
            $bookingId
        );

    $tripLink =
        tsFinTripLink(
            $pdo,
            $bookingId
        );

    $currency =
        strtoupper(
            trim(
                (string)(
                    $booking['currency']
                    ?? 'INR'
                )
            )
        );

    if ($currency === '') {
        $currency = 'INR';
    }

    $selling =
        max(
            0,
            (float)(
                $booking['total_amount']
                ?? 0
            )
        );

    $collected =
        max(
            0,
            (float)(
                $booking['paid_amount']
                ?? 0
            )
        );

    $expectedSupplier =
        max(
            0,
            (float)(
                $tripLink['expected_supplier_cost']
                ?? 0
            )
        );

    $expectedDirect =
        max(
            0,
            (float)(
                $tripLink['expected_direct_cost']
                ?? 0
            )
        );

    $expectedTotal =
        max(
            0,
            (float)(
                $tripLink['expected_total_cost']
                ?? (
                    $expectedSupplier
                    + $expectedDirect
                )
            )
        );

    $expectedMargin =
        isset($tripLink['expected_margin_amount'])
            ? (float)$tripLink['expected_margin_amount']
            : (
                $selling
                - $expectedTotal
            );

    if (tsFinTableExists($pdo, 'booking_amendments')) {
        try {
            $stmt = $pdo->prepare("SELECT revised_expected_supplier_cost,revised_expected_direct_cost,revised_expected_total_cost,revised_expected_margin FROM booking_amendments WHERE booking_id=? AND status='approved' ORDER BY version_number DESC,id DESC LIMIT 1");
            $stmt->execute([$bookingId]);
            $latestAmendment = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
            if ($latestAmendment) {
                $expectedSupplier = max(0,(float)$latestAmendment['revised_expected_supplier_cost']);
                $expectedDirect = max(0,(float)$latestAmendment['revised_expected_direct_cost']);
                $expectedTotal = max(0,(float)$latestAmendment['revised_expected_total_cost']);
                $expectedMargin = (float)$latestAmendment['revised_expected_margin'];
            }
        } catch (Throwable $e) {
            error_log('Finance amendment baseline error: '.$e->getMessage());
        }
    }

    /* Current Booking selling price also reflects posted Billing Debit/Credit Notes. */
    $expectedMargin =
        $selling
        - $expectedTotal;

    $actualSupplier = 0.0;
    $unapprovedSupplier = 0.0;
    if (function_exists('spaReady') && spaReady($pdo)) {
        $stmt = $pdo->prepare("SELECT * FROM supplier_invoices WHERE booking_id=?");
        $stmt->execute([$bookingId]);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $invoiceRow) {
            $status = strtolower((string)($invoiceRow['status'] ?? ''));
            if ($status === 'approved') {
                $actualSupplier += spaEffectiveInvoiceTotal($pdo, $invoiceRow) + spaInvoiceAdjustmentsNet($pdo, (int)$invoiceRow['id']);
            } elseif ($status === 'received') {
                $unapprovedSupplier += max(0, (float)$invoiceRow['total_amount']);
            }
        }
        $actualSupplier = max(0, round($actualSupplier, 2));
        $unapprovedSupplier = max(0, round($unapprovedSupplier, 2));
    } else {
        $stmt = $pdo->prepare("
            SELECT
                COALESCE(SUM(CASE WHEN status='approved' THEN total_amount ELSE 0 END),0) AS approved_total,
                COALESCE(SUM(CASE WHEN status='received' THEN total_amount ELSE 0 END),0) AS received_total
            FROM supplier_invoices WHERE booking_id=?
        " );
        $stmt->execute([$bookingId]);
        $invoiceTotals = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $actualSupplier = max(0,(float)($invoiceTotals['approved_total']??0));
        $unapprovedSupplier = max(0,(float)($invoiceTotals['received_total']??0));
    }

    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(amount),0)
        FROM booking_actual_direct_costs
        WHERE booking_id = ?
          AND status = 'posted'
    ");
    $stmt->execute([$bookingId]);
    $actualDirect =
        max(
            0,
            (float)$stmt->fetchColumn()
        );

    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(amount),0)
        FROM supplier_payments
        WHERE booking_id = ?
          AND status = 'paid'
    ");
    $stmt->execute([$bookingId]);
    $supplierPaid =
        max(
            0,
            (float)$stmt->fetchColumn()
        );

    $actualTotal =
        $actualSupplier
        + $actualDirect;

    $actualMargin =
        $selling
        - $actualTotal;

    $supplierAdvanceAllocated = 0.0;
    if (function_exists('spaReady') && spaReady($pdo) && spaTable($pdo,'supplier_advance_allocations')) {
        try {
            $st=$pdo->prepare("SELECT COALESCE(SUM(a.amount),0) FROM supplier_advance_allocations a JOIN supplier_invoices i ON i.id=a.supplier_invoice_id WHERE i.booking_id=? AND a.status='posted'");
            $st->execute([$bookingId]);
            $supplierAdvanceAllocated=max(0,(float)$st->fetchColumn());
        } catch (Throwable $e) {}
    }
    $supplierPayable =
        max(
            0,
            $actualSupplier
            - $supplierPaid
            - $supplierAdvanceAllocated
        );

    return [
        'currency' => $currency,
        'selling_price' => $selling,
        'customer_collected' => $collected,
        'customer_outstanding' =>
            max(
                0,
                $selling - $collected
            ),

        'expected_supplier_cost' => $expectedSupplier,
        'actual_supplier_cost' => $actualSupplier,
        'unapproved_supplier_invoices' => $unapprovedSupplier,

        'expected_direct_cost' => $expectedDirect,
        'actual_direct_cost' => $actualDirect,

        'expected_total_cost' => $expectedTotal,
        'actual_total_cost' => $actualTotal,

        'expected_margin' => $expectedMargin,
        'actual_margin' => $actualMargin,
        'margin_variance' =>
            $actualMargin
            - $expectedMargin,

        'supplier_invoiced' => $actualSupplier,
        'supplier_paid' => $supplierPaid,
        'supplier_advance_allocated' => $supplierAdvanceAllocated,
        'supplier_payable' => $supplierPayable,

        'booking_status' =>
            (string)(
                $booking['booking_status']
                ?? ''
            ),
        'payment_status' =>
            (string)(
                $booking['payment_status']
                ?? ''
            ),
        'trip_id' =>
            !empty($tripLink['trip_id'])
                ? (int)$tripLink['trip_id']
                : null,
        'trip_code' =>
            (string)(
                $tripLink['trip_code']
                ?? ''
            ),
    ];
}


function tsFinCreateSupplierInvoice(
    PDO $pdo,
    int $bookingId,
    int $adminId,
    array $input,
    array $file = []
): array {
    if (!tsFinReady($pdo)) {
        throw new RuntimeException(
            'Supplier Finance SQL is not installed yet.'
        );
    }

    tsFinAssertOpen($pdo, $bookingId);

    $booking =
        tsFinBookingRow(
            $pdo,
            $bookingId
        );

    $tripLink =
        tsFinTripLink(
            $pdo,
            $bookingId
        );

    $supplierId =
        max(
            0,
            (int)(
                $input['supplier_id']
                ?? 0
            )
        );

    if ($supplierId <= 0) {
        throw new RuntimeException(
            'Select a supplier.'
        );
    }

    $stmt = $pdo->prepare("
        SELECT id, company_name
        FROM suppliers
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$supplierId]);
    $supplier =
        $stmt->fetch(PDO::FETCH_ASSOC)
        ?: null;

    if (!$supplier) {
        throw new RuntimeException(
            'Supplier was not found.'
        );
    }

    $invoiceNumber =
        trim(
            (string)(
                $input['invoice_number']
                ?? ''
            )
        );

    $invoiceDate =
        trim(
            (string)(
                $input['invoice_date']
                ?? ''
            )
        );

    $dueDate =
        trim(
            (string)(
                $input['due_date']
                ?? ''
            )
        );

    if ($invoiceNumber === '') {
        throw new RuntimeException(
            'Supplier invoice number is required.'
        );
    }

    if ($invoiceDate === '') {
        throw new RuntimeException(
            'Supplier invoice date is required.'
        );
    }

    if (
        $dueDate !== ''
        && $dueDate < $invoiceDate
    ) {
        throw new RuntimeException(
            'Supplier invoice due date cannot be before invoice date.'
        );
    }

    $status =
        strtolower(
            trim(
                (string)(
                    $input['invoice_status']
                    ?? 'received'
                )
            )
        );

    if (
        !in_array(
            $status,
            ['received', 'approved'],
            true
        )
    ) {
        $status = 'received';
    }

    $currency =
        strtoupper(
            trim(
                (string)(
                    $booking['currency']
                    ?? 'INR'
                )
            )
        );

    $taxAmount =
        max(
            0,
            (float)(
                $input['tax_amount']
                ?? 0
            )
        );

    $otherAmount =
        max(
            0,
            (float)(
                $input['other_amount']
                ?? 0
            )
        );

    $serviceIds =
        (array)(
            $input['line_service_id']
            ?? []
        );

    $descriptions =
        (array)(
            $input['line_description']
            ?? []
        );

    $quantities =
        (array)(
            $input['line_quantity']
            ?? []
        );

    $unitCosts =
        (array)(
            $input['line_unit_cost']
            ?? []
        );

    $lines = [];

    $maxRows =
        max(
            count($serviceIds),
            count($descriptions),
            count($quantities),
            count($unitCosts)
        );

    for ($i = 0; $i < $maxRows; $i++) {
        $serviceId =
            max(
                0,
                (int)(
                    $serviceIds[$i]
                    ?? 0
                )
            );

        $description =
            trim(
                (string)(
                    $descriptions[$i]
                    ?? ''
                )
            );

        $quantity =
            max(
                0,
                (float)(
                    $quantities[$i]
                    ?? 0
                )
            );

        $unitCost =
            max(
                0,
                (float)(
                    $unitCosts[$i]
                    ?? 0
                )
            );

        if (
            $serviceId <= 0
            && $description === ''
            && $quantity <= 0
            && $unitCost <= 0
        ) {
            continue;
        }

        if ($serviceId > 0) {
            $stmt = $pdo->prepare("
                SELECT
                    id,
                    title,
                    source_supplier_id
                FROM booking_service_snapshots
                WHERE id = ?
                  AND booking_id = ?
                LIMIT 1
            ");
            $stmt->execute([
                $serviceId,
                $bookingId
            ]);
            $service =
                $stmt->fetch(PDO::FETCH_ASSOC)
                ?: null;

            if (!$service) {
                throw new RuntimeException(
                    'One supplier invoice line is linked to an invalid Booking service.'
                );
            }

            if (
                (int)(
                    $service['source_supplier_id']
                    ?? 0
                ) !== $supplierId
            ) {
                throw new RuntimeException(
                    'Supplier invoice service does not belong to the selected supplier.'
                );
            }

            if ($description === '') {
                $description =
                    (string)$service['title'];
            }
        }

        if ($description === '') {
            throw new RuntimeException(
                'Enter a description for every supplier invoice line.'
            );
        }

        if ($quantity <= 0) {
            throw new RuntimeException(
                'Supplier invoice line quantity must be greater than zero.'
            );
        }

        if ($unitCost < 0) {
            throw new RuntimeException(
                'Supplier invoice unit cost cannot be negative.'
            );
        }

        $lineCost =
            round(
                $quantity
                * $unitCost,
                2
            );

        $lines[] = [
            'service_id' =>
                $serviceId > 0
                    ? $serviceId
                    : null,
            'description' => $description,
            'quantity' => $quantity,
            'unit_cost' => $unitCost,
            'line_cost' => $lineCost,
        ];
    }

    if (!$lines) {
        throw new RuntimeException(
            'Add at least one supplier invoice line.'
        );
    }

    $netAmount =
        round(
            array_sum(
                array_column(
                    $lines,
                    'line_cost'
                )
            ),
            2
        );

    $totalAmount =
        round(
            $netAmount
            + $taxAmount
            + $otherAmount,
            2
        );

    if ($totalAmount <= 0) {
        throw new RuntimeException(
            'Supplier invoice total must be greater than zero.'
        );
    }

    $upload =
        tsFinUpload(
            $file,
            'supplier-invoice'
        );

    $supplierOrderId = null;

    if (tsFinTableExists($pdo, 'supplier_booking_orders')) {
        $stmt = $pdo->prepare("
            SELECT id
            FROM supplier_booking_orders
            WHERE booking_id = ?
              AND supplier_id = ?
            LIMIT 1
        ");
        $stmt->execute([
            $bookingId,
            $supplierId
        ]);

        $value =
            (int)(
                $stmt->fetchColumn()
                ?: 0
            );

        if ($value > 0) {
            $supplierOrderId = $value;
        }
    }

    $pdo->beginTransaction();

    try {
        $stmt = $pdo->prepare("
            INSERT INTO supplier_invoices
            (
                booking_id,
                trip_id,
                supplier_id,
                supplier_booking_order_id,
                invoice_number,
                invoice_date,
                due_date,
                currency,
                net_amount,
                tax_amount,
                other_amount,
                total_amount,
                status,
                notes,
                attachment_path,
                original_filename,
                created_by_admin_id,
                approved_by_admin_id,
                approved_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $bookingId,
            $tripLink
                ? (int)$tripLink['trip_id']
                : null,
            $supplierId,
            $supplierOrderId,
            $invoiceNumber,
            $invoiceDate,
            $dueDate !== ''
                ? $dueDate
                : null,
            $currency,
            $netAmount,
            $taxAmount,
            $otherAmount,
            $totalAmount,
            $status,
            trim(
                (string)(
                    $input['invoice_notes']
                    ?? ''
                )
            ) ?: null,
            $upload['path'],
            $upload['name'],
            $adminId > 0
                ? $adminId
                : null,
            $status === 'approved'
                ? (
                    $adminId > 0
                        ? $adminId
                        : null
                )
                : null,
            $status === 'approved'
                ? date('Y-m-d H:i:s')
                : null
        ]);

        $invoiceId =
            (int)$pdo->lastInsertId();

        $insertLine = $pdo->prepare("
            INSERT INTO supplier_invoice_items
            (
                supplier_invoice_id,
                booking_service_snapshot_id,
                description,
                quantity,
                unit_cost,
                line_cost,
                sort_order
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        foreach ($lines as $index => $line) {
            $insertLine->execute([
                $invoiceId,
                $line['service_id'],
                $line['description'],
                $line['quantity'],
                $line['unit_cost'],
                $line['line_cost'],
                ($index + 1) * 10
            ]);
        }

        $pdo->commit();

        return [
            'invoice_id' => $invoiceId,
            'supplier_name' =>
                (string)$supplier['company_name'],
            'invoice_number' => $invoiceNumber,
            'total_amount' => $totalAmount,
            'status' => $status,
        ];

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $e;
    }
}


function tsFinApproveInvoice(
    PDO $pdo,
    int $bookingId,
    int $invoiceId,
    int $adminId
): void {
    tsFinAssertOpen($pdo, $bookingId);

    $stmt = $pdo->prepare("
        UPDATE supplier_invoices
        SET
            status = 'approved',
            approved_by_admin_id = ?,
            approved_at = NOW(),
            updated_at = NOW()
        WHERE id = ?
          AND booking_id = ?
          AND status = 'received'
    ");
    $stmt->execute([
        $adminId > 0
            ? $adminId
            : null,
        $invoiceId,
        $bookingId
    ]);

    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException(
            'Supplier invoice could not be approved.'
        );
    }
}


function tsFinVoidInvoice(
    PDO $pdo,
    int $bookingId,
    int $invoiceId
): void {
    tsFinAssertOpen($pdo, $bookingId);

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM supplier_payments
        WHERE supplier_invoice_id = ?
          AND status = 'paid'
    ");
    $stmt->execute([$invoiceId]);

    if ((int)$stmt->fetchColumn() > 0) {
        throw new RuntimeException(
            'Void the supplier payment(s) before voiding this invoice.'
        );
    }

    $stmt = $pdo->prepare("
        UPDATE supplier_invoices
        SET
            status = 'void',
            updated_at = NOW()
        WHERE id = ?
          AND booking_id = ?
          AND status <> 'void'
    ");
    $stmt->execute([
        $invoiceId,
        $bookingId
    ]);

    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException(
            'Supplier invoice could not be voided.'
        );
    }
}


function tsFinRecordSupplierPayment(
    PDO $pdo,
    int $bookingId,
    int $adminId,
    array $input
): array {
    tsFinAssertOpen($pdo, $bookingId);

    $invoiceId =
        max(
            0,
            (int)(
                $input['supplier_invoice_id']
                ?? 0
            )
        );

    $amount =
        round(
            max(
                0,
                (float)(
                    $input['supplier_payment_amount']
                    ?? 0
                )
            ),
            2
        );

    $paymentDate =
        trim(
            (string)(
                $input['supplier_payment_date']
                ?? ''
            )
        );

    if ($invoiceId <= 0) {
        throw new RuntimeException(
            'Select an approved supplier invoice.'
        );
    }

    if ($amount <= 0) {
        throw new RuntimeException(
            'Supplier payment amount must be greater than zero.'
        );
    }

    if ($paymentDate === '') {
        throw new RuntimeException(
            'Supplier payment date is required.'
        );
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM supplier_invoices
        WHERE id = ?
          AND booking_id = ?
          AND status = 'approved'
        LIMIT 1
    ");
    $stmt->execute([
        $invoiceId,
        $bookingId
    ]);
    $invoice =
        $stmt->fetch(PDO::FETCH_ASSOC)
        ?: null;

    if (!$invoice) {
        throw new RuntimeException(
            'Approved supplier invoice was not found.'
        );
    }

    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(amount),0)
        FROM supplier_payments
        WHERE supplier_invoice_id = ?
          AND status = 'paid'
    ");
    $stmt->execute([$invoiceId]);
    $alreadyPaid =
        max(
            0,
            (float)$stmt->fetchColumn()
        );

    if (function_exists('spaReady') && spaReady($pdo)) {
        $outstanding = spaInvoiceOutstanding($pdo, $invoice);
    } else {
        $outstanding =
            max(
                0,
                (float)$invoice['total_amount']
                - $alreadyPaid
            );
    }

    if ($amount > $outstanding + 0.01) {
        throw new RuntimeException(
            'Supplier payment exceeds invoice outstanding amount.'
        );
    }

    $method =
        strtolower(
            trim(
                (string)(
                    $input['supplier_payment_method']
                    ?? 'bank_transfer'
                )
            )
        );

    if (!array_key_exists($method, tsFinPaymentMethods())) {
        $method = 'other';
    }

    $stmt = $pdo->prepare("
        INSERT INTO supplier_payments
        (
            supplier_invoice_id,
            booking_id,
            supplier_id,
            amount,
            currency,
            payment_date,
            payment_method,
            reference_number,
            status,
            notes,
            created_by_admin_id
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'paid', ?, ?)
    ");
    $stmt->execute([
        $invoiceId,
        $bookingId,
        (int)$invoice['supplier_id'],
        $amount,
        (string)$invoice['currency'],
        $paymentDate,
        $method,
        trim(
            (string)(
                $input['supplier_payment_reference']
                ?? ''
            )
        ) ?: null,
        trim(
            (string)(
                $input['supplier_payment_notes']
                ?? ''
            )
        ) ?: null,
        $adminId > 0
            ? $adminId
            : null
    ]);

    return [
        'payment_id' =>
            (int)$pdo->lastInsertId(),
        'amount' => $amount,
        'invoice_number' =>
            (string)$invoice['invoice_number'],
    ];
}


function tsFinVoidSupplierPayment(
    PDO $pdo,
    int $bookingId,
    int $paymentId
): void {
    tsFinAssertOpen($pdo, $bookingId);

    $stmt = $pdo->prepare("
        UPDATE supplier_payments
        SET
            status = 'void',
            updated_at = NOW()
        WHERE id = ?
          AND booking_id = ?
          AND status = 'paid'
    ");
    $stmt->execute([
        $paymentId,
        $bookingId
    ]);

    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException(
            'Supplier payment could not be voided.'
        );
    }
}


function tsFinAddDirectCost(
    PDO $pdo,
    int $bookingId,
    int $adminId,
    array $input,
    array $file = []
): array {
    tsFinAssertOpen($pdo, $bookingId);

    $booking =
        tsFinBookingRow(
            $pdo,
            $bookingId
        );

    $tripLink =
        tsFinTripLink(
            $pdo,
            $bookingId
        );

    $type =
        strtolower(
            trim(
                (string)(
                    $input['direct_cost_type']
                    ?? 'other'
                )
            )
        );

    if (!array_key_exists($type, tsFinDirectCostTypes())) {
        $type = 'other';
    }

    $description =
        trim(
            (string)(
                $input['direct_cost_description']
                ?? ''
            )
        );

    $amount =
        round(
            max(
                0,
                (float)(
                    $input['direct_cost_amount']
                    ?? 0
                )
            ),
            2
        );

    $costDate =
        trim(
            (string)(
                $input['direct_cost_date']
                ?? ''
            )
        );

    if ($description === '') {
        throw new RuntimeException(
            'Direct cost description is required.'
        );
    }

    if ($amount <= 0) {
        throw new RuntimeException(
            'Direct cost amount must be greater than zero.'
        );
    }

    if ($costDate === '') {
        throw new RuntimeException(
            'Direct cost date is required.'
        );
    }

    $upload =
        tsFinUpload(
            $file,
            'direct-cost'
        );

    $stmt = $pdo->prepare("
        INSERT INTO booking_actual_direct_costs
        (
            booking_id,
            trip_id,
            cost_type,
            description,
            amount,
            currency,
            cost_date,
            status,
            notes,
            attachment_path,
            original_filename,
            created_by_admin_id
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, 'posted', ?, ?, ?, ?)
    ");
    $stmt->execute([
        $bookingId,
        $tripLink
            ? (int)$tripLink['trip_id']
            : null,
        $type,
        $description,
        $amount,
        strtoupper(
            trim(
                (string)(
                    $booking['currency']
                    ?? 'INR'
                )
            )
        ),
        $costDate,
        trim(
            (string)(
                $input['direct_cost_notes']
                ?? ''
            )
        ) ?: null,
        $upload['path'],
        $upload['name'],
        $adminId > 0
            ? $adminId
            : null
    ]);

    return [
        'cost_id' =>
            (int)$pdo->lastInsertId(),
        'amount' => $amount,
        'description' => $description,
    ];
}


function tsFinVoidDirectCost(
    PDO $pdo,
    int $bookingId,
    int $costId
): void {
    tsFinAssertOpen($pdo, $bookingId);

    $stmt = $pdo->prepare("
        UPDATE booking_actual_direct_costs
        SET
            status = 'void',
            updated_at = NOW()
        WHERE id = ?
          AND booking_id = ?
          AND status = 'posted'
    ");
    $stmt->execute([
        $costId,
        $bookingId
    ]);

    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException(
            'Direct cost could not be voided.'
        );
    }
}


function tsFinClosureReadiness(
    PDO $pdo,
    int $bookingId
): array {
    $summary =
        tsFinSummary(
            $pdo,
            $bookingId
        );

    $operationsReady = true;

    if (
        function_exists('tsOpsReady')
        && function_exists('tsOpsReadiness')
        && tsOpsReady($pdo)
    ) {
        $ops =
            tsOpsReadiness(
                $pdo,
                $bookingId
            );

        $operationsReady =
            !empty($ops['ready']);
    }

    $noUnapprovedInvoices =
        (float)$summary['unapproved_supplier_invoices']
        <= 0.01;

    $actualSupplierCaptured =
        (
            (float)$summary['expected_supplier_cost']
            <= 0.01
        )
        || (
            (float)$summary['actual_supplier_cost']
            > 0.01
        );

    $noPendingAmendments = true;
    if (tsFinTableExists($pdo, 'booking_amendments')) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM booking_amendments WHERE booking_id=? AND status='pending'");
        $stmt->execute([$bookingId]);
        $noPendingAmendments = (int)$stmt->fetchColumn() === 0;
    }

    $noPendingCancellation = true;
    if (tsFinTableExists($pdo, 'booking_cancellations')) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM booking_cancellations WHERE booking_id=? AND status='pending'");
        $stmt->execute([$bookingId]);
        $noPendingCancellation = (int)$stmt->fetchColumn() === 0;
    }

    $noPendingCustomerRefunds = true;

    if (
        tsFinTableExists(
            $pdo,
            'booking_customer_refunds'
        )
    ) {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM booking_customer_refunds
            WHERE booking_id = ?
              AND status = 'pending'
        ");
        $stmt->execute([$bookingId]);

        $noPendingCustomerRefunds =
            (int)$stmt->fetchColumn() === 0;
    }

    $checks = [
        'booking_completed' => (string)$summary['booking_status'] === 'completed',
        'customer_fully_collected' => (float)$summary['customer_outstanding'] <= 0.01,
        'supplier_invoices_approved' => $noUnapprovedInvoices,
        'actual_supplier_cost_captured' => $actualSupplierCaptured,
        'supplier_payables_cleared' => (float)$summary['supplier_payable'] <= 0.01,
        'operations_ready' => $operationsReady,
        'no_pending_amendments' => $noPendingAmendments,
        'no_pending_cancellation' => $noPendingCancellation,
        'no_pending_customer_refunds' => $noPendingCustomerRefunds,
    ];

    return [
        'checks' => $checks,
        'ready' =>
            !in_array(
                false,
                $checks,
                true
            ),
        'summary' => $summary,
    ];
}


function tsFinCloseProfitability(
    PDO $pdo,
    int $bookingId,
    int $adminId,
    string $note = ''
): array {
    if (!tsFinReady($pdo)) {
        throw new RuntimeException(
            'Supplier Finance SQL is not installed yet.'
        );
    }

    $existing =
        tsFinClosure(
            $pdo,
            $bookingId
        );

    if ($existing) {
        return $existing;
    }

    $readiness =
        tsFinClosureReadiness(
            $pdo,
            $bookingId
        );

    if (empty($readiness['ready'])) {
        $labels = [
            'booking_completed' => 'Booking status must be Completed',
            'customer_fully_collected' => 'Customer outstanding must be zero',
            'supplier_invoices_approved' => 'All received supplier invoices must be Approved or Void',
            'actual_supplier_cost_captured' => 'Actual supplier cost must be captured',
            'supplier_payables_cleared' => 'Supplier payable must be zero',
            'operations_ready' => 'Operations Readiness must be complete',
            'no_pending_amendments' => 'Pending Booking amendment must be processed',
            'no_pending_cancellation' => 'Pending cancellation request must be processed',
            'no_pending_customer_refunds' => 'Pending customer refund must be paid or resolved',
        ];

        $missing = [];

        foreach (
            (array)$readiness['checks']
            as $key => $done
        ) {
            if (!$done) {
                $missing[] =
                    $labels[$key]
                    ?? $key;
            }
        }

        throw new RuntimeException(
            'Cannot financially close: '
            . implode(
                '; ',
                $missing
            )
            . '.'
        );
    }

    $summary =
        (array)$readiness['summary'];

    $tripId =
        !empty($summary['trip_id'])
            ? (int)$summary['trip_id']
            : null;

    $snapshot = [
        'schema' => 1,
        'booking_id' => $bookingId,
        'trip_id' => $tripId,
        'closed_at' => date('c'),
        'summary' => $summary,
        'invoices' =>
            tsFinInvoices(
                $pdo,
                $bookingId
            ),
        'supplier_payments' =>
            tsFinSupplierPayments(
                $pdo,
                $bookingId
            ),
        'direct_costs' =>
            tsFinDirectCosts(
                $pdo,
                $bookingId
            ),
    ];

    $stmt = $pdo->prepare("
        INSERT INTO booking_profitability_closures
        (
            booking_id,
            trip_id,
            currency,
            expected_selling_price,
            actual_customer_revenue,
            customer_collected,
            customer_outstanding,
            expected_supplier_cost,
            actual_supplier_cost,
            expected_direct_cost,
            actual_direct_cost,
            expected_total_cost,
            actual_total_cost,
            expected_margin,
            actual_margin,
            margin_variance,
            supplier_invoiced,
            supplier_paid,
            supplier_payable,
            closure_note,
            snapshot_json,
            closed_by_admin_id,
            closed_at
        )
        VALUES
        (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([
        $bookingId,
        $tripId,
        (string)$summary['currency'],
        (float)$summary['selling_price'],
        (float)$summary['selling_price'],
        (float)$summary['customer_collected'],
        (float)$summary['customer_outstanding'],
        (float)$summary['expected_supplier_cost'],
        (float)$summary['actual_supplier_cost'],
        (float)$summary['expected_direct_cost'],
        (float)$summary['actual_direct_cost'],
        (float)$summary['expected_total_cost'],
        (float)$summary['actual_total_cost'],
        (float)$summary['expected_margin'],
        (float)$summary['actual_margin'],
        (float)$summary['margin_variance'],
        (float)$summary['supplier_invoiced'],
        (float)$summary['supplier_paid'],
        (float)$summary['supplier_payable'],
        trim($note) !== ''
            ? trim($note)
            : null,
        json_encode(
            $snapshot,
            JSON_UNESCAPED_UNICODE
            | JSON_UNESCAPED_SLASHES
        ),
        $adminId > 0
            ? $adminId
            : null
    ]);

    if (
        $tripId
        && tsFinTableExists($pdo, 'trips')
    ) {
        $pdo->prepare("
            UPDATE trips
            SET
                next_action = 'Financially closed',
                next_action_date = NULL,
                updated_at = NOW()
            WHERE id = ?
        ")->execute([$tripId]);
    }

    return
        tsFinClosure(
            $pdo,
            $bookingId
        )
        ?: [];
}
