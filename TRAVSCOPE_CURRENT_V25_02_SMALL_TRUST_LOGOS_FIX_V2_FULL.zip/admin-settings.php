<?php
/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM - ADMIN SETTINGS
|--------------------------------------------------------------------------
| Uses existing settings table:
| id, setting_key, setting_value, updated_at
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/credential-display.php';
// The existing settings table supports more logos without a database migration.
$credentialMaxSlots = TS_CREDENTIAL_MAX_SLOTS;

requireAdmin();

$admin = currentAdmin($pdo);

if (!$admin) {
    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_mobile'],
        $_SESSION['admin_role']
    );

    redirect(BASE_URL . 'login.php');
}


/*
|--------------------------------------------------------------------------
| USER ROLE MANAGEMENT
|--------------------------------------------------------------------------
| Existing customer accounts remain in `users`.
| Supported roles:
|   user    -> dashboard.php
|   staff   -> staff.php
|   manager -> manager.php
|--------------------------------------------------------------------------
*/

$userRoleOptions = [
    'user' => 'User',
    'staff' => 'Staff',
    'manager' => 'Manager',
];

$userRoleColumnReady = false;

try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.columns
        WHERE table_schema = DATABASE()
          AND table_name = 'users'
          AND column_name = 'role'
    ");
    $stmt->execute();

    $userRoleColumnReady = (int)$stmt->fetchColumn() > 0;

    if (!$userRoleColumnReady) {
        $pdo->exec("
            ALTER TABLE users
            ADD COLUMN role VARCHAR(20) NOT NULL DEFAULT 'user'
            AFTER email_verified
        ");
        $userRoleColumnReady = true;
    }

    if ($userRoleColumnReady) {
        $pdo->exec("
            UPDATE users
            SET role = 'user'
            WHERE role IS NULL
               OR TRIM(role) = ''
               OR role NOT IN ('user','staff','manager')
        ");
    }
} catch (Throwable $e) {
    error_log('TRAVSCOPE user role setup error: ' . $e->getMessage());
    $userRoleColumnReady = false;
}

$roleManagedUsers = [];

if ($userRoleColumnReady) {
    try {
        $stmt = $pdo->query("
            SELECT
                id,
                full_name,
                email,
                mobile,
                role,
                status,
                email_verified,
                created_at
            FROM users
            ORDER BY
                CASE role
                    WHEN 'manager' THEN 1
                    WHEN 'staff' THEN 2
                    ELSE 3
                END,
                id DESC
        ");

        $roleManagedUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log('TRAVSCOPE role user list error: ' . $e->getMessage());
        $roleManagedUsers = [];
    }
}

/*
|--------------------------------------------------------------------------
| SETTINGS DEFINITION
|--------------------------------------------------------------------------
*/

$settingGroups = [

    'general' => [
        'title' => 'General Settings',
        'icon'  => 'fa-solid fa-globe',
        'description' => 'Basic website identity and display settings.',
        'fields' => [
            'site_name' => [
                'label' => 'Website Name',
                'type' => 'text',
                'default' => 'TRAVSCOPE.COM',
                'maxlength' => 150,
                'placeholder' => 'TRAVSCOPE.COM'
            ],
            'site_tagline' => [
                'label' => 'Website Tagline',
                'type' => 'text',
                'default' => 'Explore More. Travel Better.',
                'maxlength' => 255,
                'placeholder' => 'Explore More. Travel Better.'
            ],
            'currency_symbol' => [
                'label' => 'Currency Symbol',
                'type' => 'text',
                'default' => '₹',
                'maxlength' => 10,
                'placeholder' => '₹'
            ],
            'currency_code' => [
                'label' => 'Currency Code',
                'type' => 'text',
                'default' => 'INR',
                'maxlength' => 10,
                'placeholder' => 'INR'
            ],
        ],
    ],

    'contact' => [
        'title' => 'Contact Information',
        'icon'  => 'fa-solid fa-address-book',
        'description' => 'Customer support and office contact details.',
        'fields' => [
            'support_email' => [
                'label' => 'Support Email',
                'type' => 'email',
                'default' => '',
                'maxlength' => 190,
                'placeholder' => 'support@example.com'
            ],
            'support_mobile' => [
                'label' => 'Support Mobile',
                'type' => 'text',
                'default' => '',
                'maxlength' => 30,
                'placeholder' => '+91 98765 43210'
            ],
            'whatsapp_number' => [
                'label' => 'WhatsApp Number',
                'type' => 'text',
                'default' => '',
                'maxlength' => 30,
                'placeholder' => '919876543210',
                'help' => 'Prefer country code + number without spaces for WhatsApp links.'
            ],
            'office_address' => [
                'label' => 'Office Address',
                'type' => 'textarea',
                'default' => '',
                'maxlength' => 1000,
                'placeholder' => 'Enter your travel office address'
            ],
            'business_hours' => [
                'label' => 'Business Hours',
                'type' => 'text',
                'default' => '',
                'maxlength' => 150,
                'placeholder' => 'Mon - Sat, 9:00 AM - 7:00 PM'
            ],
        ],
    ],

    'quotation_credentials' => [
        'title' => 'Quotation Trust & Credentials',
        'icon'  => 'fa-solid fa-award',
        'description' => 'Optional recognition, registration or association marks shown on quotations. Add only marks you are authorised to display.',
        'fields' => [
            'quotation_credentials_heading' => [
                'label' => 'Section Heading', 'type' => 'text',
                'default' => 'Recognitions & Associations', 'maxlength' => 120,
                'placeholder' => 'Recognitions & Associations'
            ],
            // V25.02: credential rows are rendered on demand below, not a fixed four-field list.
            // Existing quotation_credential_*_1..4 settings are fully retained.

        ],
    ],

    'payment' => [
        'title' => 'Payment Settings',
        'icon'  => 'fa-solid fa-credit-card',
        'description' => 'Public/manual payment information. Never store banking passwords here.',
        'fields' => [
            'upi_id' => [
                'label' => 'UPI ID',
                'type' => 'text',
                'default' => '',
                'maxlength' => 150,
                'placeholder' => 'travscope@upi'
            ],
            'payment_receiver_name' => [
                'label' => 'Payment Receiver Name',
                'type' => 'text',
                'default' => '',
                'maxlength' => 150,
                'placeholder' => 'TRAVSCOPE'
            ],
            'payment_qr_image' => [
                'label' => 'Payment QR Image Path / URL',
                'type' => 'text',
                'default' => '',
                'maxlength' => 500,
                'placeholder' => 'uploads/payment-qr.png',
                'help' => 'Enter the image path already used by your payment page. This page does not upload the QR file.'
            ],
            'payment_instructions' => [
                'label' => 'Payment Instructions',
                'type' => 'textarea',
                'default' => 'Pay using the displayed UPI/QR and submit your UTR/reference number for verification.',
                'maxlength' => 2000,
                'placeholder' => 'Instructions shown to customers'
            ],
        ],
    ],

    'billing' => [
        'title' => 'Invoice & Billing Profile',
        'icon'  => 'fa-solid fa-file-invoice-dollar',
        'description' => 'One-time seller, GST, banking and UPI details used automatically on invoices, receipts and finance documents.',
        'fields' => [
            'invoice_legal_name' => [
                'label' => 'Legal Business Name', 'type' => 'text',
                'default' => 'MEMORABLE HOSPITALITY PRIVATE LIMITED', 'maxlength' => 190,
                'placeholder' => 'Legal registered business name'
            ],
            'invoice_trade_name' => [
                'label' => 'Trade Name', 'type' => 'text', 'default' => 'Travscope',
                'maxlength' => 150, 'placeholder' => 'Travscope'
            ],
            'invoice_gstin' => [
                'label' => 'GSTIN', 'type' => 'text', 'default' => '21AALCM7012J1ZM',
                'maxlength' => 15, 'placeholder' => '15-character GSTIN'
            ],
            'invoice_pan' => [
                'label' => 'PAN', 'type' => 'text', 'default' => 'AALCM7012J',
                'maxlength' => 10, 'placeholder' => 'PAN'
            ],
            'invoice_address' => [
                'label' => 'Registered Address', 'type' => 'textarea',
                'default' => 'PLOT NO - 1215/1416, KHANDAGIRI BARI, KHANDAGIRI, BHUBANESWAR, Khordha, Odisha, 751030',
                'maxlength' => 1000, 'placeholder' => 'Registered business address'
            ],
            'invoice_state' => [
                'label' => 'State', 'type' => 'text', 'default' => 'Odisha',
                'maxlength' => 100, 'placeholder' => 'Odisha'
            ],
            'invoice_state_code' => [
                'label' => 'State Code', 'type' => 'text', 'default' => '21',
                'maxlength' => 5, 'placeholder' => '21'
            ],
            'invoice_email' => [
                'label' => 'Billing Email', 'type' => 'email', 'default' => '',
                'maxlength' => 190, 'placeholder' => 'accounts@travscope.com'
            ],
            'invoice_phone' => [
                'label' => 'Billing Phone', 'type' => 'text', 'default' => '',
                'maxlength' => 30, 'placeholder' => '+91 ...'
            ],
            'invoice_bank_name' => [
                'label' => 'Bank Name', 'type' => 'text', 'default' => '',
                'maxlength' => 190, 'placeholder' => 'Bank name'
            ],
            'invoice_bank_account' => [
                'label' => 'Bank Account Number', 'type' => 'text', 'default' => '',
                'maxlength' => 80, 'placeholder' => 'Account number'
            ],
            'invoice_bank_ifsc' => [
                'label' => 'IFSC', 'type' => 'text', 'default' => '',
                'maxlength' => 20, 'placeholder' => 'IFSC code'
            ],
            'invoice_upi' => [
                'label' => 'Invoice UPI ID', 'type' => 'text', 'default' => '',
                'maxlength' => 150, 'placeholder' => 'travscope@upi',
                'help' => 'Used to generate an amount-specific UPI QR on invoices. If blank, Payment Settings -> UPI ID is used.'
            ],
            'invoice_sac' => [
                'label' => 'Default SAC', 'type' => 'text', 'default' => '998555',
                'maxlength' => 20, 'placeholder' => '998555'
            ],
            'invoice_default_gst_rate' => [
                'label' => 'Default GST Rate %', 'type' => 'text', 'default' => '5',
                'maxlength' => 10, 'placeholder' => '5'
            ],
            'invoice_default_tcs_rate' => [
                'label' => 'Default TCS Rate %', 'type' => 'text', 'default' => '2',
                'maxlength' => 10, 'placeholder' => '2'
            ],
        ],
    ],

    'booking' => [
        'title' => 'Booking Settings',
        'icon'  => 'fa-solid fa-calendar-check',
        'description' => 'General controls and customer-facing booking messages.',
        'fields' => [
            'booking_enabled' => [
                'label' => 'Allow New Bookings',
                'type' => 'select',
                'default' => '1',
                'options' => [
                    '1' => 'Enabled',
                    '0' => 'Disabled'
                ]
            ],
            'enquiry_enabled' => [
                'label' => 'Allow New Enquiries',
                'type' => 'select',
                'default' => '1',
                'options' => [
                    '1' => 'Enabled',
                    '0' => 'Disabled'
                ]
            ],
            'booking_notice' => [
                'label' => 'Booking Notice',
                'type' => 'textarea',
                'default' => '',
                'maxlength' => 1000,
                'placeholder' => 'Optional notice shown around the booking process'
            ],
            'cancellation_policy' => [
                'label' => 'Cancellation Policy',
                'type' => 'textarea',
                'default' => '',
                'maxlength' => 4000,
                'placeholder' => 'Enter your cancellation policy'
            ],
        ],
    ],

    'social' => [
        'title' => 'Social Media',
        'icon'  => 'fa-solid fa-share-nodes',
        'description' => 'Links displayed on your public website when supported by the page.',
        'fields' => [
            'whatsapp_url' => [
                'label' => 'WhatsApp URL',
                'type' => 'url',
                'default' => '',
                'maxlength' => 500,
                'placeholder' => 'https://wa.me/919876543210',
                'help' => 'Use your complete WhatsApp link, for example: https://wa.me/919876543210'
            ],
            'facebook_url' => [
                'label' => 'Facebook URL',
                'type' => 'url',
                'default' => '',
                'maxlength' => 500,
                'placeholder' => 'https://facebook.com/...'
            ],
            'instagram_url' => [
                'label' => 'Instagram URL',
                'type' => 'url',
                'default' => '',
                'maxlength' => 500,
                'placeholder' => 'https://instagram.com/...'
            ],
            'youtube_url' => [
                'label' => 'YouTube URL',
                'type' => 'url',
                'default' => '',
                'maxlength' => 500,
                'placeholder' => 'https://youtube.com/...'
            ],
            'x_url' => [
                'label' => 'X / Twitter URL',
                'type' => 'url',
                'default' => '',
                'maxlength' => 500,
                'placeholder' => 'https://x.com/...'
            ],
        ],
    ],

    'system' => [
        'title' => 'Website Controls',
        'icon'  => 'fa-solid fa-sliders',
        'description' => 'Control public website availability. Admin access remains available during maintenance mode.',
        'fields' => [
            'maintenance_mode' => [
                'label' => 'Maintenance Mode',
                'type' => 'select',
                'default' => '0',
                'options' => [
                    '0' => 'Off',
                    '1' => 'On'
                ]
            ],
            'maintenance_message' => [
                'label' => 'Maintenance Message',
                'type' => 'textarea',
                'default' => 'We are updating our website. Please check back shortly.',
                'maxlength' => 1000,
                'placeholder' => 'Maintenance message'
            ],
            'admin_delete_otp_enabled' => [
                'label' => 'Delete OTP Verification',
                'type' => 'select',
                'default' => '1',
                'options' => [
                    '0' => 'Off — Delete without OTP',
                    '1' => 'On — Require Admin OTP before delete'
                ],
                'help' => 'When On, protected Admin Delete/Remove actions require a 6-digit OTP sent to the logged-in Admin email. When Off, delete actions run without OTP verification.'
            ],

        ],
    ],
];

/*
|--------------------------------------------------------------------------
| LOAD / SAVE
|--------------------------------------------------------------------------
*/

$success = '';
$error = '';

if (!empty($_SESSION['admin_settings_success'])) {
    $success = (string)$_SESSION['admin_settings_success'];
    unset($_SESSION['admin_settings_success']);
}

if (!empty($_SESSION['admin_settings_error'])) {
    $error = (string)$_SESSION['admin_settings_error'];
    unset($_SESSION['admin_settings_error']);
}


/*
|--------------------------------------------------------------------------
| HOMEPAGE SLIDER MANAGER
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && in_array(
        (string)($_POST['form_action'] ?? ''),
        ['add_slide', 'update_slide', 'delete_slide', 'toggle_slide'],
        true
    )
) {
    $csrf = (string)($_POST['csrf_token'] ?? '');

    if (!verifyCsrf($csrf)) {
        $_SESSION['admin_settings_error'] = 'Security validation failed.';
        redirect(BASE_URL . 'admin-settings.php#homepage-slider');
    }

    $action = (string)$_POST['form_action'];

    try {
        if ($action === 'delete_slide') {
            $slideId = (int)($_POST['slide_id'] ?? 0);
            if ($slideId < 1) throw new RuntimeException('Invalid slide.');

            $stmt = $pdo->prepare("SELECT desktop_image, mobile_image FROM homepage_slides WHERE id=? LIMIT 1");
            $stmt->execute([$slideId]);
            $old = $stmt->fetch(PDO::FETCH_ASSOC);

            $pdo->prepare("DELETE FROM homepage_slides WHERE id=?")->execute([$slideId]);

            if ($old) {
                foreach (['desktop_image','mobile_image'] as $k) {
                    $rel = trim((string)($old[$k] ?? ''));
                    if ($rel !== '' && !preg_match('#^https?://#i', $rel)) {
                        $full = __DIR__ . '/' . ltrim($rel, '/');
                        if (is_file($full)) @unlink($full);
                    }
                }
            }

            $_SESSION['admin_settings_success'] = 'Homepage slide deleted successfully.';
            redirect(BASE_URL . 'admin-settings.php#homepage-slider');
        }

        if ($action === 'toggle_slide') {
            $slideId = (int)($_POST['slide_id'] ?? 0);
            if ($slideId < 1) throw new RuntimeException('Invalid slide.');

            $pdo->prepare("
                UPDATE homepage_slides
                SET status = IF(status='active','inactive','active')
                WHERE id=?
            ")->execute([$slideId]);

            $_SESSION['admin_settings_success'] = 'Homepage slide status updated.';
            redirect(BASE_URL . 'admin-settings.php#homepage-slider');
        }

        $slideId = (int)($_POST['slide_id'] ?? 0);
        $badge = trim((string)($_POST['slide_badge'] ?? ''));
        $heading = trim((string)($_POST['slide_heading'] ?? ''));
        $highlight = trim((string)($_POST['slide_highlight'] ?? ''));
        $description = trim((string)($_POST['slide_description'] ?? ''));
        $primaryText = trim((string)($_POST['slide_primary_text'] ?? ''));
        $primaryUrl = trim((string)($_POST['slide_primary_url'] ?? ''));
        $secondaryText = trim((string)($_POST['slide_secondary_text'] ?? ''));
        $secondaryUrl = trim((string)($_POST['slide_secondary_url'] ?? ''));
        $sortOrder = max(0, (int)($_POST['slide_sort_order'] ?? 0));
        $status = ($_POST['slide_status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';

        if ($heading === '') throw new RuntimeException('Slide heading is required.');

        $uploadDir = __DIR__ . '/uploads/homepage-slides/';
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
            throw new RuntimeException('Unable to create homepage slide upload folder.');
        }

        $saveImage = static function (string $field, bool $required = false) use ($uploadDir): ?string {
            if (empty($_FILES[$field]) || (int)$_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
                if ($required) throw new RuntimeException('Desktop slide image is required.');
                return null;
            }

            $file = $_FILES[$field];
            if ((int)$file['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Image upload failed.');
            if ((int)$file['size'] > 8 * 1024 * 1024) throw new RuntimeException('Each slide image must be 8 MB or smaller.');

            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
            $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
            if (!isset($allowed[$mime])) throw new RuntimeException('Only JPG, PNG and WEBP slide images are allowed.');

            $name = 'slide_' . bin2hex(random_bytes(10)) . '.' . $allowed[$mime];
            if (!move_uploaded_file($file['tmp_name'], $uploadDir . $name)) {
                throw new RuntimeException('Unable to save uploaded slide image.');
            }
            return 'uploads/homepage-slides/' . $name;
        };

        if ($action === 'update_slide') {
            if ($slideId < 1) throw new RuntimeException('Invalid slide.');

            $stmt = $pdo->prepare("SELECT * FROM homepage_slides WHERE id=? LIMIT 1");
            $stmt->execute([$slideId]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$existing) throw new RuntimeException('Slide was not found.');

            $desktopImage = $saveImage('slide_desktop_image', false) ?: $existing['desktop_image'];
            $mobileImage = $saveImage('slide_mobile_image', false) ?: $existing['mobile_image'];

            $stmt = $pdo->prepare("
                UPDATE homepage_slides SET
                    badge_text=?, heading=?, highlight_text=?, description=?,
                    desktop_image=?, mobile_image=?,
                    primary_button_text=?, primary_button_url=?,
                    secondary_button_text=?, secondary_button_url=?,
                    sort_order=?, status=?
                WHERE id=?
            ");
            $stmt->execute([
                $badge ?: null, $heading, $highlight ?: null, $description ?: null,
                $desktopImage, $mobileImage,
                $primaryText ?: null, $primaryUrl ?: null,
                $secondaryText ?: null, $secondaryUrl ?: null,
                $sortOrder, $status, $slideId
            ]);

            $_SESSION['admin_settings_success'] = 'Homepage slide updated successfully.';
            redirect(BASE_URL . 'admin-settings.php#homepage-slider');
        }

        $desktopImage = $saveImage('slide_desktop_image', true);
        $mobileImage = $saveImage('slide_mobile_image', false);

        $stmt = $pdo->prepare("
            INSERT INTO homepage_slides
            (badge_text, heading, highlight_text, description, desktop_image, mobile_image,
             primary_button_text, primary_button_url, secondary_button_text, secondary_button_url,
             sort_order, status)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
        ");
        $stmt->execute([
            $badge ?: null, $heading, $highlight ?: null, $description ?: null,
            $desktopImage, $mobileImage,
            $primaryText ?: null, $primaryUrl ?: null,
            $secondaryText ?: null, $secondaryUrl ?: null,
            $sortOrder, $status
        ]);

        $_SESSION['admin_settings_success'] = 'Homepage slide added successfully.';
        redirect(BASE_URL . 'admin-settings.php#homepage-slider');

    } catch (Throwable $e) {
        error_log('TRAVSCOPE homepage slider error: ' . $e->getMessage());
        $_SESSION['admin_settings_error'] =
            $e instanceof RuntimeException ? $e->getMessage() : 'Unable to update homepage slider.';
        redirect(BASE_URL . 'admin-settings.php#homepage-slider');
    }
}


if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && ($_POST['form_action'] ?? '') === 'update_user_role'
) {
    $csrf = (string)($_POST['csrf_token'] ?? '');

    if (!verifyCsrf($csrf)) {
        $_SESSION['admin_settings_error'] =
            'Security validation failed. Please refresh the page and try again.';
        redirect(BASE_URL . 'admin-settings.php#user-roles');
    }

    try {
        if (!$userRoleColumnReady) {
            throw new RuntimeException(
                'User role column is not available. Please check database ALTER permission.'
            );
        }

        $targetUserId = (int)($_POST['target_user_id'] ?? 0);
        $newRole = strtolower(trim((string)($_POST['new_user_role'] ?? 'user')));

        if ($targetUserId <= 0) {
            throw new RuntimeException('Invalid user account.');
        }

        if (!array_key_exists($newRole, $userRoleOptions)) {
            throw new RuntimeException('Invalid user role selected.');
        }

        $stmt = $pdo->prepare("
            SELECT id, full_name, role
            FROM users
            WHERE id = ?
            LIMIT 1
        ");
        $stmt->execute([$targetUserId]);
        $targetUser = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$targetUser) {
            throw new RuntimeException('The selected user account was not found.');
        }

        $stmt = $pdo->prepare("
            UPDATE users
            SET role = ?
            WHERE id = ?
            LIMIT 1
        ");
        $stmt->execute([$newRole, $targetUserId]);

        $_SESSION['admin_settings_success'] =
            (string)$targetUser['full_name']
            . ' is now assigned as '
            . $userRoleOptions[$newRole]
            . '.';

    } catch (Throwable $e) {
        error_log('TRAVSCOPE update user role error: ' . $e->getMessage());

        $_SESSION['admin_settings_error'] =
            $e instanceof RuntimeException
                ? $e->getMessage()
                : 'Unable to update the user role right now.';
    }

    redirect(BASE_URL . 'admin-settings.php#user-roles');
}

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && ($_POST['form_action'] ?? '') === 'add_customer'
) {
    $csrf = (string)($_POST['csrf_token'] ?? '');

    if (!verifyCsrf($csrf)) {
        $_SESSION['admin_settings_error'] =
            'Security validation failed. Please refresh the page and try again.';
        redirect(BASE_URL . 'admin-settings.php#add-user');
    }

    $fullName = trim((string)($_POST['customer_full_name'] ?? ''));
    $email = strtolower(trim((string)($_POST['customer_email'] ?? '')));
    $mobile = trim((string)($_POST['customer_mobile'] ?? ''));
    $password = (string)($_POST['customer_password'] ?? '');
    $country = trim((string)($_POST['customer_country'] ?? ''));
    $status = strtolower(trim((string)($_POST['customer_status'] ?? 'active')));
    $role = strtolower(trim((string)($_POST['customer_role'] ?? 'user')));

    try {
        if ($fullName === '' || mb_strlen($fullName) > 150) {
            throw new RuntimeException('Please enter a valid customer full name.');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) {
            throw new RuntimeException('Please enter a valid customer email address.');
        }

        if ($mobile !== '' && mb_strlen($mobile) > 20) {
            throw new RuntimeException('Customer mobile number is too long.');
        }

        if (strlen($password) < 8) {
            throw new RuntimeException('Customer password must be at least 8 characters.');
        }

        if (mb_strlen($country) > 100) {
            throw new RuntimeException('Country name is too long.');
        }

        if (!in_array($status, ['active', 'inactive', 'blocked'], true)) {
            $status = 'active';
        }

        if (!array_key_exists($role, $userRoleOptions)) {
            $role = 'user';
        }

        if (!$userRoleColumnReady) {
            throw new RuntimeException(
                'User role management is not available because the database role column could not be prepared.'
            );
        }

        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);

        if ($stmt->fetchColumn()) {
            throw new RuntimeException('A customer with this email already exists.');
        }

        if ($mobile !== '') {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE mobile = ? LIMIT 1");
            $stmt->execute([$mobile]);

            if ($stmt->fetchColumn()) {
                throw new RuntimeException('A customer with this mobile number already exists.');
            }
        }

        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        if ($passwordHash === false) {
            throw new RuntimeException('Unable to secure the customer password.');
        }

        $stmt = $pdo->prepare("
            INSERT INTO users
                (full_name, email, mobile, password, country, email_verified, role, status)
            VALUES
                (?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $fullName,
            $email,
            $mobile !== '' ? $mobile : null,
            $passwordHash,
            $country !== '' ? $country : null,
            1,
            $role,
            $status
        ]);

        $_SESSION['admin_settings_success'] =
            'Customer account created successfully.';

        redirect(BASE_URL . 'admin-settings.php#add-user');

    } catch (Throwable $e) {
        error_log('TRAVSCOPE add customer error: ' . $e->getMessage());

        $_SESSION['admin_settings_error'] =
            $e instanceof RuntimeException
                ? $e->getMessage()
                : 'Unable to create the customer account right now.';

        redirect(BASE_URL . 'admin-settings.php#add-user');
    }
}

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && ($_POST['form_action'] ?? '') === 'save_settings'
) {

    $csrf = (string)($_POST['csrf_token'] ?? '');

    if (!verifyCsrf($csrf)) {
        $_SESSION['admin_settings_error'] =
            'Security validation failed. Please refresh the page and try again.';

        redirect(BASE_URL . 'admin-settings.php');
    }

    $newLogoRelative = null;
    $newLogoAbsolute = null;
    $oldLogoRelative = trim((string)getSetting($pdo, 'site_logo', ''));

    $newDocumentLogoRelative = null;
    $newDocumentLogoAbsolute = null;
    $newDocumentPdfLogoRelative = null;
    $newDocumentPdfLogoAbsolute = null;
    $newCredentialLogoPaths = [];
    $newCredentialFiles = [];
    $oldDocumentLogoRelative = trim((string)getSetting($pdo, 'document_logo', ''));
    $oldDocumentPdfLogoRelative = trim((string)getSetting($pdo, 'document_logo_pdf', ''));

    try {

        /*
        |------------------------------------------------------------------
        | WEBSITE LOGO UPLOAD
        |------------------------------------------------------------------
        | General Settings owns the single logo used by the visible TRAVSCOPE
        | brand areas across the public site, customer/manager portals and admin UI.
        | SVG is intentionally excluded because uploaded SVG can contain
        | active script/content.
        */
        if (
            isset($_FILES['site_logo_file'])
            && is_array($_FILES['site_logo_file'])
            && (int)($_FILES['site_logo_file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE
        ) {
            $logoFile = $_FILES['site_logo_file'];
            $logoError = (int)($logoFile['error'] ?? UPLOAD_ERR_NO_FILE);

            if ($logoError !== UPLOAD_ERR_OK) {
                throw new RuntimeException('Website logo upload failed. Please choose the image again.');
            }

            $logoSize = (int)($logoFile['size'] ?? 0);
            if ($logoSize < 1 || $logoSize > 4 * 1024 * 1024) {
                throw new RuntimeException('Website logo must be smaller than 4 MB.');
            }

            $logoTmp = (string)($logoFile['tmp_name'] ?? '');
            $imageInfo = $logoTmp !== '' ? @getimagesize($logoTmp) : false;
            $mime = is_array($imageInfo) ? strtolower((string)($imageInfo['mime'] ?? '')) : '';

            $allowedLogoTypes = [
                'image/png' => 'png',
                'image/jpeg' => 'jpg',
                'image/webp' => 'webp',
            ];

            if (!isset($allowedLogoTypes[$mime])) {
                throw new RuntimeException('Website logo must be a PNG, JPG/JPEG or WebP image.');
            }

            $logoWidth = is_array($imageInfo) ? (int)($imageInfo[0] ?? 0) : 0;
            $logoHeight = is_array($imageInfo) ? (int)($imageInfo[1] ?? 0) : 0;
            if ($logoWidth < 40 || $logoHeight < 20 || $logoWidth > 5000 || $logoHeight > 5000) {
                throw new RuntimeException('Website logo dimensions are not valid. Use an image up to 5000 × 5000 px.');
            }

            $logoDirectory = __DIR__ . '/uploads/settings/branding/';
            if (!is_dir($logoDirectory) && !@mkdir($logoDirectory, 0755, true) && !is_dir($logoDirectory)) {
                throw new RuntimeException('Unable to create the website logo upload folder.');
            }

            $extension = $allowedLogoTypes[$mime];
            $logoName = 'site-logo-' . date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.' . $extension;
            $newLogoAbsolute = $logoDirectory . $logoName;
            $newLogoRelative = 'uploads/settings/branding/' . $logoName;

            if (!move_uploaded_file($logoTmp, $newLogoAbsolute)) {
                $newLogoAbsolute = null;
                $newLogoRelative = null;
                throw new RuntimeException('Unable to save the uploaded website logo.');
            }
        }


        /*
        |------------------------------------------------------------------
        | DOCUMENT LOGO UPLOAD
        |------------------------------------------------------------------
        | Separate from the Website Logo. Used only on customer documents:
        | invoices, money receipts, quotations, vouchers and PDF itineraries.
        |
        | A JPEG companion is generated for the low-level quotation PDF
        | renderer so the same uploaded artwork is used consistently.
        */
        if (
            isset($_FILES['document_logo_file'])
            && is_array($_FILES['document_logo_file'])
            && (int)($_FILES['document_logo_file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE
        ) {
            $documentLogoFile = $_FILES['document_logo_file'];
            $documentLogoError = (int)($documentLogoFile['error'] ?? UPLOAD_ERR_NO_FILE);

            if ($documentLogoError !== UPLOAD_ERR_OK) {
                throw new RuntimeException('Document logo upload failed. Please choose the image again.');
            }

            $documentLogoSize = (int)($documentLogoFile['size'] ?? 0);
            if ($documentLogoSize < 1 || $documentLogoSize > 6 * 1024 * 1024) {
                throw new RuntimeException('Document logo must be smaller than 6 MB.');
            }

            $documentLogoTmp = (string)($documentLogoFile['tmp_name'] ?? '');
            $documentImageInfo = $documentLogoTmp !== '' ? @getimagesize($documentLogoTmp) : false;
            $documentMime = is_array($documentImageInfo)
                ? strtolower((string)($documentImageInfo['mime'] ?? ''))
                : '';

            $allowedDocumentLogoTypes = [
                'image/png' => 'png',
                'image/jpeg' => 'jpg',
            ];

            if (!isset($allowedDocumentLogoTypes[$documentMime])) {
                throw new RuntimeException('Document logo must be a PNG or JPG/JPEG image.');
            }

            $documentLogoWidth = is_array($documentImageInfo) ? (int)($documentImageInfo[0] ?? 0) : 0;
            $documentLogoHeight = is_array($documentImageInfo) ? (int)($documentImageInfo[1] ?? 0) : 0;
            if (
                $documentLogoWidth < 200
                || $documentLogoHeight < 50
                || $documentLogoWidth > 8000
                || $documentLogoHeight > 8000
            ) {
                throw new RuntimeException('Document logo dimensions are not valid. Use an image between 200 × 50 and 8000 × 8000 px.');
            }

            $documentLogoDirectory = __DIR__ . '/uploads/settings/branding/';
            if (
                !is_dir($documentLogoDirectory)
                && !@mkdir($documentLogoDirectory, 0755, true)
                && !is_dir($documentLogoDirectory)
            ) {
                throw new RuntimeException('Unable to create the document logo upload folder.');
            }

            $documentExtension = $allowedDocumentLogoTypes[$documentMime];
            $documentToken = date('Ymd-His') . '-' . bin2hex(random_bytes(4));
            $documentLogoName = 'document-logo-' . $documentToken . '.' . $documentExtension;
            $newDocumentLogoAbsolute = $documentLogoDirectory . $documentLogoName;
            $newDocumentLogoRelative = 'uploads/settings/branding/' . $documentLogoName;

            if (!move_uploaded_file($documentLogoTmp, $newDocumentLogoAbsolute)) {
                $newDocumentLogoAbsolute = null;
                $newDocumentLogoRelative = null;
                throw new RuntimeException('Unable to save the uploaded document logo.');
            }

            /*
            | Quotation and receipt PDF renderers support PNG/JPEG directly,
            | so the same uploaded file is used for every document format.
            */
            $newDocumentPdfLogoAbsolute = $newDocumentLogoAbsolute;
            $newDocumentPdfLogoRelative = $newDocumentLogoRelative;
        }


        /* V25.01: secure credential-logo image uploads. All are optional. */
        for ($slot = 1; $slot <= $credentialMaxSlots; $slot++) {
            if (!array_key_exists('quotation_credential_label_' . $slot, $_POST)) continue;
            $field = 'credential_logo_file_' . $slot;
            if (!isset($_FILES[$field]) || (int)($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) continue;
            $file = $_FILES[$field];
            if (!is_array($file) || (int)$file['error'] !== UPLOAD_ERR_OK) {
                throw new RuntimeException('Credential ' . $slot . ' image could not be uploaded.');
            }
            $size = (int)($file['size'] ?? 0);
            if ($size < 1 || $size > 3 * 1024 * 1024) {
                throw new RuntimeException('Credential ' . $slot . ' logo must be 3 MB or less.');
            }
            $tmp = (string)($file['tmp_name'] ?? '');
            $info = $tmp !== '' ? @getimagesize($tmp) : false;
            $mime = is_array($info) ? (string)($info['mime'] ?? '') : '';
            $allowed = ['image/png'=>'png','image/jpeg'=>'jpg'];
            if (!isset($allowed[$mime]) || !in_array((int)($info[2] ?? -1), [IMAGETYPE_PNG,IMAGETYPE_JPEG], true)) {
                throw new RuntimeException('Credential logo must be PNG or JPG/JPEG; SVG and WebP are not permitted for PDF compatibility.');
            }
            $w = (int)($info[0] ?? 0); $h = (int)($info[1] ?? 0);
            if ($w < 24 || $h < 24 || $w > 5000 || $h > 5000 || $w * $h > 12000000) {
                throw new RuntimeException('Credential logo dimensions must be between 24px and 5000px and under 12 megapixels.');
            }
            $directory = __DIR__ . '/uploads/settings/branding/';
            if (!is_dir($directory) && !@mkdir($directory, 0755, true) && !is_dir($directory)) {
                throw new RuntimeException('Unable to create credential image folder.');
            }
            $filename = 'credential-' . $slot . '-' . bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
            $absolute = $directory . $filename;
            if (!move_uploaded_file($tmp, $absolute)) throw new RuntimeException('Unable to store credential ' . $slot . ' image.');
            $newCredentialFiles[] = $absolute;
            $newCredentialLogoPaths[$slot] = 'uploads/settings/branding/' . $filename;
        }

        /* Validate approved marks even when using a manually entered HTTPS image URL. */
        for ($slot = 1; $slot <= $credentialMaxSlots; $slot++) {
            if (!array_key_exists('quotation_credential_label_' . $slot, $_POST)) continue;
            $label = trim((string)($_POST['quotation_credential_label_' . $slot] ?? ''));
            if (mb_strlen($label) > 120) throw new RuntimeException('Credential ' . $slot . ' label is too long.');
            $approval = (string)($_POST['quotation_credential_verified_' . $slot] ?? '0');
            if ($approval !== '0' && $approval !== '1') throw new RuntimeException('Invalid approval for credential ' . $slot . '.');
            $currentLogo = trim((string)($_POST['quotation_credential_logo_' . $slot] ?? ''));
            $finalLogo = $newCredentialLogoPaths[$slot] ?? $currentLogo;
            if (strlen($finalLogo) > 500) throw new RuntimeException('Credential ' . $slot . ' logo path is too long.');
            if ($finalLogo !== '' && tsCredSafeLogo($finalLogo) === '') {
                throw new RuntimeException('Credential ' . $slot . ' logo must be a safe local PNG/JPG path or HTTPS image URL. For identical emailed PDF output, use a locally uploaded logo.');
            }
            if ((string)($_POST['quotation_credential_verified_' . $slot] ?? '0') === '1') {
                if (trim((string)($_POST['quotation_credential_label_' . $slot] ?? '')) === '' || $finalLogo === '') {
                    throw new RuntimeException('Credential ' . $slot . ': enter a label and logo before enabling publication.');
                }
            }
        }

        $pdo->beginTransaction();

        foreach ($settingGroups as $group) {

            foreach ($group['fields'] as $key => $field) {

                $value = trim((string)($_POST[$key] ?? ''));

                $maxLength = isset($field['maxlength'])
                    ? (int)$field['maxlength']
                    : 10000;

                if (mb_strlen($value) > $maxLength) {
                    throw new RuntimeException(
                        $field['label'] . ' is too long.'
                    );
                }

                if (
                    $field['type'] === 'email'
                    && $value !== ''
                    && !filter_var($value, FILTER_VALIDATE_EMAIL)
                ) {
                    throw new RuntimeException(
                        'Please enter a valid ' . $field['label'] . '.'
                    );
                }

                if (
                    $field['type'] === 'url'
                    && $value !== ''
                    && !filter_var($value, FILTER_VALIDATE_URL)
                ) {
                    throw new RuntimeException(
                        'Please enter a complete valid URL for ' . $field['label'] . '.'
                    );
                }

                if (
                    $field['type'] === 'select'
                    && !array_key_exists($value, $field['options'])
                ) {
                    $value = (string)$field['default'];
                }

                if ($key === 'currency_code') {
                    $value = strtoupper($value);
                }

                if ($key === 'site_name' && $value === '') {
                    throw new RuntimeException(
                        'Website Name cannot be empty.'
                    );
                }

                if (str_starts_with($key, 'text_size_')) {
                    if ($value === '' || !ctype_digit($value)) {
                        throw new RuntimeException($field['label'] . ' must be a whole number.');
                    }

                    $size = (int)$value;
                    $min = isset($field['min']) ? (int)$field['min'] : 6;
                    $max = isset($field['max']) ? (int)$field['max'] : 100;

                    if ($size < $min || $size > $max) {
                        throw new RuntimeException(
                            $field['label'] . ' must be between ' . $min . 'px and ' . $max . 'px.'
                        );
                    }

                    $value = (string)$size;
                }

                if (!setSetting($pdo, $key, $value)) {
                    throw new RuntimeException(
                        'Unable to save ' . $field['label'] . '.'
                    );
                }
            }
        }

        // V25.02: persist only the slots actually shown/edited. Hidden unopened slots
        // do not clear existing credentials. A removed card posts blank values to clear it.
        for ($slot = 1; $slot <= $credentialMaxSlots; $slot++) {
            if (!array_key_exists('quotation_credential_label_' . $slot, $_POST)) continue;
            foreach (['label' => 120, 'verified' => 1, 'logo' => 500] as $part => $limit) {
                $value = trim((string)($_POST['quotation_credential_' . $part . '_' . $slot] ?? ''));
                if ($part === 'verified' && $value !== '1') $value = '0';
                if ($part === 'label' && mb_strlen($value) > $limit) throw new RuntimeException('Credential ' . $slot . ' label is too long.');
                if ($part === 'logo' && strlen($value) > $limit) throw new RuntimeException('Credential ' . $slot . ' logo path is too long.');
                if (!setSetting($pdo, 'quotation_credential_' . $part . '_' . $slot, $value)) {
                    throw new RuntimeException('Unable to save credential ' . $slot . '.');
                }
            }
        }

        foreach ($newCredentialLogoPaths as $slot => $path) {
            if (!setSetting($pdo, 'quotation_credential_logo_' . $slot, $path)) {
                throw new RuntimeException('Unable to save credential ' . $slot . ' logo.');
            }
        }

        if ($newLogoRelative !== null) {
            if (!setSetting($pdo, 'site_logo', $newLogoRelative)) {
                throw new RuntimeException('Unable to save the Website Logo setting.');
            }
        }

        if ($newDocumentLogoRelative !== null) {
            if (!setSetting($pdo, 'document_logo', $newDocumentLogoRelative)) {
                throw new RuntimeException('Unable to save the Document Logo setting.');
            }

            if (!setSetting(
                $pdo,
                'document_logo_pdf',
                $newDocumentPdfLogoRelative !== null
                    ? $newDocumentPdfLogoRelative
                    : $newDocumentLogoRelative
            )) {
                throw new RuntimeException('Unable to save the Document Logo PDF setting.');
            }
        }

        $pdo->commit();

        /* Remove only older branding files created by these uploaders. */
        if (
            $newLogoRelative !== null
            && $oldLogoRelative !== ''
            && str_starts_with($oldLogoRelative, 'uploads/settings/branding/')
            && $oldLogoRelative !== $newLogoRelative
        ) {
            $oldLogoAbsolute = __DIR__ . '/' . ltrim($oldLogoRelative, '/');
            if (is_file($oldLogoAbsolute)) {
                @unlink($oldLogoAbsolute);
            }
        }

        if ($newDocumentLogoRelative !== null) {
            $oldDocumentFiles = array_unique(array_filter([
                $oldDocumentLogoRelative,
                $oldDocumentPdfLogoRelative,
            ]));

            foreach ($oldDocumentFiles as $oldDocumentRelative) {
                if (
                    str_starts_with($oldDocumentRelative, 'uploads/settings/branding/')
                    && $oldDocumentRelative !== $newDocumentLogoRelative
                    && $oldDocumentRelative !== $newDocumentPdfLogoRelative
                ) {
                    $oldDocumentAbsolute = __DIR__ . '/' . ltrim($oldDocumentRelative, '/');
                    if (is_file($oldDocumentAbsolute)) {
                        @unlink($oldDocumentAbsolute);
                    }
                }
            }
        }

        $savedLogoLabels = [];
        if ($newLogoRelative !== null) $savedLogoLabels[] = 'Website Logo';
        if ($newDocumentLogoRelative !== null) $savedLogoLabels[] = 'Document Logo';
        if ($newCredentialLogoPaths) $savedLogoLabels[] = count($newCredentialLogoPaths) . ' Credential Logo(s)';

        $_SESSION['admin_settings_success'] = $savedLogoLabels
            ? 'Website settings saved successfully. Updated: ' . implode(' + ', $savedLogoLabels) . '.'
            : 'Website settings saved successfully.';

        redirect(BASE_URL . 'admin-settings.php');

    } catch (Throwable $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        foreach ($newCredentialFiles as $file) { if (is_file($file)) @unlink($file); }

        if ($newLogoAbsolute !== null && is_file($newLogoAbsolute)) {
            @unlink($newLogoAbsolute);
        }

        if ($newDocumentLogoAbsolute !== null && is_file($newDocumentLogoAbsolute)) {
            @unlink($newDocumentLogoAbsolute);
        }

        if (
            $newDocumentPdfLogoAbsolute !== null
            && $newDocumentPdfLogoAbsolute !== $newDocumentLogoAbsolute
            && is_file($newDocumentPdfLogoAbsolute)
        ) {
            @unlink($newDocumentPdfLogoAbsolute);
        }

        error_log(
            'TRAVSCOPE admin settings save error: '
            . $e->getMessage()
        );

        $_SESSION['admin_settings_error'] =
            $e instanceof RuntimeException
            ? $e->getMessage()
            : 'Unable to save settings right now.';

        redirect(BASE_URL . 'admin-settings.php');
    }
}

$values = [];

foreach ($settingGroups as $group) {
    foreach ($group['fields'] as $key => $field) {
        $values[$key] = (string)getSetting(
            $pdo,
            $key,
            $field['default']
        );
    }
}

$siteLogoValue = trim((string)getSetting($pdo, 'site_logo', ''));
$siteLogoPreviewUrl = '';
if ($siteLogoValue !== '') {
    $siteLogoPreviewUrl = preg_match('#^https?://#i', $siteLogoValue)
        ? $siteLogoValue
        : rtrim((string)BASE_URL, '/') . '/' . ltrim($siteLogoValue, '/');
}

$documentLogoValue = trim((string)getSetting(
    $pdo,
    'document_logo',
    'assets/travscope-document-logo-wide.png'
));
if ($documentLogoValue === '') {
    $documentLogoValue = 'assets/travscope-document-logo-wide.png';
}
$documentLogoPreviewUrl = preg_match('#^https?://#i', $documentLogoValue)
    ? $documentLogoValue
    : rtrim((string)BASE_URL, '/') . '/' . ltrim($documentLogoValue, '/');

$homepageSlides = [];
try {
    $homepageSlides = $pdo->query("
        SELECT *
        FROM homepage_slides
        ORDER BY sort_order ASC, id DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('Homepage slides load error: ' . $e->getMessage());
}

$siteName = $values['site_name'] ?: 'TRAVSCOPE.COM';
$adminInitial = strtoupper(substr((string)$admin['name'], 0, 1));
$csrfToken = csrfToken();

?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex,nofollow">

<title>Settings | <?= e($siteName); ?></title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>

:root{
    --navy:#07192d;
    --blue:#0b74ff;
    --bg:#f5f7fb;
    --white:#fff;
    --text:#172033;
    --muted:#778294;
    --border:#e5e9ef;
    --green:#0b9b63;
    --red:#d94457;
    --shadow:0 10px 30px rgba(23,32,51,.06);
}

*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{
    margin:0;
    background:var(--bg);
    color:var(--text);
    font-family:'DM Sans',sans-serif;
}
a{text-decoration:none;color:inherit}
button,input,select,textarea{font:inherit}
button{cursor:pointer}

.sidebar{
    position:fixed;
    inset:0 auto 0 0;
    width:265px;
    background:var(--navy);
    color:#fff;
    overflow-y:auto;
    z-index:1000;
    transition:.25s ease;
}
.sidebar-logo{
    height:80px;
    padding:0 22px;
    display:flex;
    align-items:center;
    gap:10px;
    border-bottom:1px solid rgba(255,255,255,.08);
    font-family:'Manrope',sans-serif;
    font-size:20px;
    font-weight:800;
}
.logo-icon{
    width:42px;height:42px;
    display:grid;place-items:center;
    border-radius:12px;
    background:var(--blue);
}
.sidebar-logo span{color:#65b7ff}
.sidebar-menu{padding:17px 13px 30px}
.menu-title{
    padding:15px 13px 7px;
    color:#657b92;
    font-size:10px;
    font-weight:800;
    letter-spacing:1px;
}
.menu-link{
    min-height:44px;
    padding:0 13px;
    margin:3px 0;
    border-radius:9px;
    display:flex;
    align-items:center;
    gap:11px;
    color:#9fb0c2;
    font-size:12px;
    font-weight:600;
}
.menu-link:hover,.menu-link.active{
    background:var(--blue);
    color:#fff;
}
.menu-link i{width:19px;text-align:center}

.main{margin-left:265px;min-height:100vh}
.topbar{
    height:80px;
    padding:0 30px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    background:#fff;
    border-bottom:1px solid var(--border);
    position:sticky;
    top:0;
    z-index:800;
}
.topbar-left,.top-actions,.admin-profile{
    display:flex;
    align-items:center;
    gap:11px;
}
.mobile-menu{
    display:none;
    width:39px;height:39px;
    border:1px solid var(--border);
    border-radius:9px;
    background:#fff;
}
.topbar-title{
    font-family:'Manrope',sans-serif;
    font-size:14px;
    font-weight:800;
}
.view-site{
    min-height:37px;
    padding:0 12px;
    display:flex;
    align-items:center;
    gap:7px;
    border:1px solid var(--border);
    border-radius:8px;
    color:#5f6b7c;
    font-size:11px;
    font-weight:700;
}
.admin-profile{
    padding-left:13px;
    border-left:1px solid var(--border);
}
.admin-avatar{
    width:39px;height:39px;
    display:grid;place-items:center;
    border-radius:10px;
    background:var(--blue);
    color:#fff;
    font-weight:800;
}
.admin-info strong{display:block;font-size:12px}
.admin-info span{
    display:block;
    margin-top:3px;
    color:var(--muted);
    font-size:10px;
}

.content{
    width:min(1250px,100%);
    margin:auto;
    padding:30px;
}
.page-heading{
    margin-bottom:22px;
    display:flex;
    justify-content:space-between;
    align-items:flex-end;
    gap:15px;
}
.page-heading h1{
    margin:0;
    font-family:'Manrope',sans-serif;
    font-size:28px;
}
.page-heading p{
    margin:6px 0 0;
    color:var(--muted);
    font-size:12px;
}
.save-top{
    min-height:40px;
    padding:0 15px;
    border:0;
    border-radius:8px;
    background:var(--blue);
    color:#fff;
    display:inline-flex;
    align-items:center;
    gap:7px;
    font-size:11px;
    font-weight:800;
}

.alert{
    margin-bottom:18px;
    padding:13px 15px;
    border-radius:9px;
    font-size:12px;
    line-height:1.5;
}
.alert.success{
    background:#eaf9f2;
    border:1px solid #bfe8d5;
    color:#08794f;
}
.alert.error{
    background:#fff0f2;
    border:1px solid #f0c3ca;
    color:#a92d3f;
}

.settings-layout{
    display:grid;
    grid-template-columns:230px minmax(0,1fr);
    gap:20px;
    align-items:start;
}
.settings-nav{
    position:sticky;
    top:100px;
    padding:10px;
    background:#fff;
    border:1px solid var(--border);
    border-radius:12px;
    box-shadow:var(--shadow);
}
.settings-nav a{
    min-height:42px;
    padding:0 11px;
    display:flex;
    align-items:center;
    gap:9px;
    border-radius:8px;
    color:#687487;
    font-size:11px;
    font-weight:700;
}
.settings-nav a:hover{
    background:#f2f7ff;
    color:var(--blue);
}
.settings-nav i{width:17px;text-align:center}

.settings-content{
    display:grid;
    gap:17px;
}
.card{
    background:#fff;
    border:1px solid var(--border);
    border-radius:12px;
    box-shadow:var(--shadow);
    overflow:hidden;
    scroll-margin-top:100px;
}
.card-head{
    padding:17px 19px;
    display:flex;
    align-items:center;
    gap:12px;
    border-bottom:1px solid var(--border);
}
.card-icon{
    width:39px;height:39px;
    display:grid;place-items:center;
    border-radius:10px;
    background:#edf5ff;
    color:var(--blue);
}
.card-head h2{
    margin:0;
    font-family:'Manrope',sans-serif;
    font-size:15px;
}
.card-head p{
    margin:4px 0 0;
    color:var(--muted);
    font-size:11px;
}
.card-body{padding:19px}
.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:15px;
}
.form-group.full{grid-column:1/-1}
.form-group label{
    display:block;
    margin-bottom:6px;
    color:#5e6b7d;
    font-size:10px;
    font-weight:800;
    letter-spacing:.45px;
    text-transform:uppercase;
}
.form-control{
    width:100%;
    min-height:42px;
    padding:0 11px;
    border:1px solid var(--border);
    border-radius:8px;
    outline:none;
    background:#fff;
    color:var(--text);
    font-size:12px;
}
textarea.form-control{
    min-height:90px;
    padding:11px;
    resize:vertical;
    line-height:1.55;
}
.form-control:focus{
    border-color:#7db4ff;
    box-shadow:0 0 0 3px rgba(11,116,255,.06);
}
.help{
    margin-top:5px;
    color:#929baa;
    font-size:10px;
    line-height:1.5;
}
.security-note{
    margin-top:15px;
    padding:12px;
    border:1px solid #f1ddb9;
    border-radius:9px;
    background:#fff9ee;
    color:#7a623d;
    font-size:11px;
    line-height:1.6;
}
.form-footer{
    padding:18px 19px;
    display:flex;
    justify-content:flex-end;
    gap:8px;
    background:#fafbfd;
    border:1px solid var(--border);
    border-radius:12px;
}
.btn{
    min-height:40px;
    padding:0 14px;
    border:1px solid var(--border);
    border-radius:8px;
    background:#fff;
    color:#5f6b7c;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:7px;
    font-size:11px;
    font-weight:800;
}
.btn-primary{
    border-color:var(--blue);
    background:var(--blue);
    color:#fff;
}

.sidebar-overlay{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.42);
    z-index:900;
    display:none;
}
.sidebar-overlay.show{display:block}

@media(max-width:1000px){
    .settings-layout{grid-template-columns:1fr}
    .settings-nav{
        position:static;
        display:flex;
        overflow:auto;
        white-space:nowrap;
    }
    .settings-nav a{flex:0 0 auto}
}
@media(max-width:850px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main{margin-left:0}
    .mobile-menu{display:grid;place-items:center}
    .content{padding:20px}
}

#homepage-slider{width:100%}
#homepage-slider .card-body{width:100%}
#homepage-slider img{max-width:100%;display:block}
@media(max-width:760px){
    #homepage-slider [style*="grid-template-columns:minmax(240px,34%)"]{
        grid-template-columns:1fr !important;
    }
}

@media(max-width:600px){
    .topbar{height:68px;padding:0 13px}
    .topbar-title,.admin-info,.view-site span{display:none}
    .admin-profile{padding-left:0;border:0}
    .content{padding:16px 12px 40px}
    .page-heading{align-items:flex-start;flex-direction:column}
    .page-heading h1{font-size:23px}
    .save-top{width:100%;justify-content:center}
    .form-grid{grid-template-columns:1fr}
    .form-group.full{grid-column:auto}
    .form-footer{flex-direction:column}
    .btn{width:100%}
}


/* Homepage slider manager normal/default readable text */
#homepage-slider .status-badge{font-size:11px}
#homepage-slider h3{line-height:1.35}



/* ============================================================
   ONE-SCREEN ADMIN SETTINGS WORKSPACE
   Layout/display only. Existing PHP logic and forms unchanged.
============================================================ */

body{
    overflow:hidden;
}

/* Keep application chrome compact */
.sidebar{
    width:235px;
}

.sidebar-logo{
    height:66px;
    padding:0 17px;
    font-size:18px;
}

.logo-icon{
    width:36px;
    height:36px;
    border-radius:10px;
}

.sidebar-menu{
    padding:10px 10px 18px;
}

.menu-title{
    padding:11px 10px 5px;
    font-size:9px;
}

.menu-link{
    min-height:38px;
    padding:0 10px;
    gap:9px;
    font-size:11px;
}

.main{
    margin-left:235px;
    height:100vh;
    min-height:0;
    overflow:hidden;
}

.topbar{
    height:64px;
    padding:0 20px;
}

.content{
    width:100%;
    max-width:none;
    height:calc(100vh - 64px);
    margin:0;
    padding:14px 18px 16px;
    overflow:hidden;
    display:flex;
    flex-direction:column;
}

.page-heading{
    flex:0 0 auto;
    margin-bottom:10px;
    align-items:center;
}

.page-heading h1{
    font-size:23px;
}

.page-heading p{
    margin-top:3px;
    font-size:11px;
}

.save-top{
    min-height:36px;
    padding:0 12px;
}

/* Alerts stay above the workspace without forcing a long page */
.alert{
    flex:0 0 auto;
    margin-bottom:9px;
    padding:9px 12px;
}

/* One-screen settings workspace */
#settingsForm{
    flex:1 1 auto;
    min-height:0;
    overflow:hidden;
}

.settings-layout{
    height:100%;
    min-height:0;
    display:grid;
    grid-template-columns:195px minmax(0,1fr);
    gap:12px;
    align-items:stretch;
}

.settings-nav{
    position:static;
    top:auto;
    height:100%;
    min-height:0;
    padding:8px;
    overflow:auto;
    border-radius:10px;
    box-shadow:none;
}

.settings-nav a{
    min-height:37px;
    padding:0 9px;
    font-size:10px;
}

.settings-nav a.settings-tab-link.active{
    background:var(--blue);
    color:#fff;
}

.settings-content{
    height:100%;
    min-height:0;
    display:block;
    overflow:hidden;
}

/* Hide all sections except the active one */
.settings-tab-panel{
    display:none !important;
    width:100%;
    height:100%;
    min-height:0;
    margin:0;
    overflow:hidden;
}

.settings-tab-panel.is-active{
    display:flex !important;
    flex-direction:column;
}

.settings-tab-panel > .card-head{
    flex:0 0 auto;
    padding:13px 15px;
}

.settings-tab-panel > .card-body{
    flex:1 1 auto;
    min-height:0;
    padding:14px 15px;
    overflow:auto;
}

.card{
    border-radius:10px;
    box-shadow:none;
    scroll-margin-top:0;
}

.card-head h2{
    font-size:14px;
}

.card-head p{
    font-size:10px;
}

.card-icon{
    width:34px;
    height:34px;
    border-radius:8px;
}

.form-grid{
    gap:11px 13px;
}

.form-group label{
    margin-bottom:5px;
    font-size:10px;
}

.form-control{
    min-height:39px;
    font-size:12px;
}

textarea.form-control{
    min-height:76px;
    padding:9px 10px;
}

.help{
    font-size:10px;
}

.security-note{
    margin-top:11px;
    padding:10px;
    font-size:10px;
}

.form-footer{
    padding:12px 14px;
    border-radius:10px;
}

/* Slider manager: retain all tools but fit them inside active workspace */
#homepage-slider .card-body{
    overflow:auto;
}

/* Existing inline large slider controls are normalized for this workspace only */
#homepage-slider h3{
    font-size:14px !important;
}

#homepage-slider p{
    font-size:12px !important;
}

#homepage-slider button{
    font-size:11px !important;
}

#homepage-slider [style*="font-size:14px"]{
    font-size:11px !important;
}

#homepage-slider [style*="font-size:11px"]{
    font-size:10px !important;
}

/* Tablet */
@media(max-width:1000px){
    body{
        overflow:auto;
    }

    .main{
        height:auto;
        overflow:visible;
    }

    .content{
        height:auto;
        min-height:calc(100vh - 64px);
        overflow:visible;
    }

    #settingsForm{
        overflow:visible;
    }

    .settings-layout{
        height:auto;
        grid-template-columns:1fr;
    }

    .settings-nav{
        height:auto;
        display:flex;
        overflow-x:auto;
        overflow-y:hidden;
        white-space:nowrap;
    }

    .settings-nav a{
        flex:0 0 auto;
    }

    .settings-content{
        height:auto;
        overflow:visible;
    }

    .settings-tab-panel.is-active{
        height:auto;
        overflow:visible;
    }

    .settings-tab-panel > .card-body{
        overflow:visible;
    }
}

/* Mobile */
@media(max-width:850px){
    .main{
        margin-left:0;
    }

    .content{
        padding:12px;
    }
}

@media(max-width:600px){
    .topbar{
        height:58px;
    }

    .content{
        min-height:calc(100vh - 58px);
        padding:10px 9px 16px;
    }

    .page-heading{
        margin-bottom:8px;
    }

    .page-heading h1{
        font-size:20px;
    }

    .page-heading p{
        display:none;
    }

    .settings-nav{
        padding:6px;
        gap:4px;
    }

    .settings-nav a{
        min-height:34px;
        padding:0 8px;
        font-size:10px;
    }

    .settings-tab-panel > .card-head{
        padding:11px 12px;
    }

    .settings-tab-panel > .card-body{
        padding:12px;
    }

    .card-head p{
        display:none;
    }

    .form-grid{
        grid-template-columns:1fr;
    }

    .form-group.full{
        grid-column:auto;
    }
}



/* ============================================================
   READABLE DEFAULT TEXT SIZES
   Keeps one-screen layout but removes tiny text.
============================================================ */

body{
    font-size:14px;
}

.menu-title{
    font-size:11px;
}

.menu-link{
    font-size:13px;
}

.topbar-title{
    font-size:14px;
}

.view-site{
    font-size:12px;
}

.admin-info strong{
    font-size:13px;
}

.admin-info span{
    font-size:11px;
}

.page-heading h1{
    font-size:24px;
}

.page-heading p{
    font-size:13px;
}

.save-top{
    font-size:12px;
}

.alert{
    font-size:13px;
}

.settings-nav a{
    font-size:12px;
}

.card-head h2{
    font-size:16px;
}

.card-head p{
    font-size:12px;
}

.form-group label{
    font-size:12px;
    letter-spacing:.2px;
}

.form-control{
    font-size:13px;
}

.help{
    font-size:11px;
}

.security-note{
    font-size:12px;
}

.btn{
    font-size:12px;
}

/* Homepage slider manager: readable, not oversized */
#homepage-slider h3{
    font-size:15px !important;
}

#homepage-slider p{
    font-size:12px !important;
}

#homepage-slider button{
    font-size:12px !important;
}

#homepage-slider [style*="font-size:11px"]{
    font-size:11px !important;
}

#homepage-slider [style*="font-size:14px"]{
    font-size:12px !important;
}

/* Mobile keeps readable text */
@media(max-width:600px){
    .menu-link{font-size:13px}
    .settings-nav a{font-size:12px}
    .form-group label{font-size:12px}
    .form-control{font-size:13px}
    .btn,.save-top{font-size:12px}
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
}
.main > .content,
.main .content:first-child{
    width:auto!important;
    max-width:none!important;
    margin:0!important;
    padding:16px 18px 20px!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}



/* ============================================================
   USER & ROLE MANAGEMENT
============================================================ */

.role-summary-grid{
    display:grid;
    grid-template-columns:repeat(3,minmax(0,1fr));
    gap:10px;
    margin-bottom:14px;
}
.role-summary{
    min-height:74px;
    padding:12px;
    display:flex;
    align-items:center;
    gap:10px;
    border:1px solid var(--border);
    border-radius:10px;
    background:#fff;
}
.role-summary>i{
    width:36px;
    height:36px;
    flex:0 0 36px;
    display:grid;
    place-items:center;
    border-radius:9px;
}
.role-summary strong{
    display:block;
    font:800 18px/1 'Manrope','DM Sans',sans-serif;
}
.role-summary span{
    display:block;
    margin-top:4px;
    font-size:10px;
    font-weight:700;
}
.role-summary-user{background:linear-gradient(135deg,#f5f8ff,#fff);border-color:#dce7f7}
.role-summary-user>i{background:#e8f1ff;color:#2563eb}
.role-summary-staff{background:linear-gradient(135deg,#effbf6,#fff);border-color:#d7efe4}
.role-summary-staff>i{background:#daf5e8;color:#0f9a68}
.role-summary-manager{background:linear-gradient(135deg,#f7f2ff,#fff);border-color:#e7dcf8}
.role-summary-manager>i{background:#eadfff;color:#7654c9}

.role-user-list{
    display:grid;
    gap:8px;
}
.role-user-card{
    display:grid;
    grid-template-columns:40px minmax(0,1fr) minmax(280px,auto);
    align-items:center;
    gap:11px;
    padding:10px 12px;
    border:1px solid #e2e8f0;
    border-radius:10px;
    background:#fff;
}
.role-user-avatar{
    width:40px;
    height:40px;
    display:grid;
    place-items:center;
    border-radius:10px;
    background:linear-gradient(135deg,#eaf3ff,#f4f8ff);
    color:#246fe9;
    font-weight:800;
}
.role-user-main{min-width:0}
.role-user-name-row{
    display:flex;
    align-items:center;
    gap:7px;
    flex-wrap:wrap;
}
.role-user-main strong{font-size:12px;color:#142238}
.role-user-main>span{
    display:block;
    margin-top:2px;
    color:#64748b;
    font-size:10px;
    overflow-wrap:anywhere;
}
.role-user-main small{
    display:block;
    margin-top:3px;
    color:#8a97a8;
    font-size:9px;
}
.role-badge{
    min-height:21px;
    padding:0 7px;
    display:inline-flex;
    align-items:center;
    border-radius:999px;
    font-size:8px;
    font-weight:800;
    text-transform:uppercase;
    letter-spacing:.35px;
}
.role-badge-user{background:#eaf2ff;color:#2467c7}
.role-badge-staff{background:#e7f8f0;color:#087c59}
.role-badge-manager{background:#f0e9ff;color:#704bc0}

.role-change-form{
    display:flex;
    align-items:center;
    gap:6px;
}
.role-select{
    height:34px;
    min-width:112px;
    padding:0 8px;
    border:1px solid #cfd9e5;
    border-radius:7px;
    background:#fff;
    color:#334155;
    font-size:10px;
    font-weight:700;
}
.role-update-btn{
    min-height:34px;
    padding:0 10px;
    border:0;
    border-radius:7px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:5px;
    background:linear-gradient(135deg,#2563eb,#3b82f6);
    color:#fff;
    font-size:9px;
    font-weight:800;
    cursor:pointer;
}
.role-setup-error{
    padding:12px;
    display:flex;
    gap:10px;
    align-items:flex-start;
    border:1px solid #fecaca;
    border-radius:10px;
    background:#fff5f5;
    color:#991b1b;
}
.role-setup-error strong{display:block;font-size:11px}
.role-setup-error span{display:block;margin-top:3px;font-size:10px}

@media(max-width:900px){
    .role-user-card{
        grid-template-columns:40px minmax(0,1fr);
    }
    .role-change-form{
        grid-column:1/-1;
        padding-left:51px;
    }
}
@media(max-width:650px){
    .role-summary-grid{grid-template-columns:1fr}
    .role-user-card{
        grid-template-columns:36px minmax(0,1fr);
        padding:9px;
    }
    .role-user-avatar{width:36px;height:36px}
    .role-change-form{
        padding-left:0;
        flex-direction:column;
        align-items:stretch;
    }
    .role-select,.role-update-btn{width:100%;min-height:39px}
}


.brand-logo-setting{
    margin-top:16px;
    padding:16px;
    border:1px solid #d8e4f2;
    border-radius:14px;
    background:linear-gradient(135deg,#f8fbff,#f1f7ff);
    display:grid;
    grid-template-columns:minmax(180px,260px) 1fr;
    gap:18px;
    align-items:center;
}
.brand-logo-preview{
    min-height:92px;
    padding:12px;
    border:1px dashed #b9cbe0;
    border-radius:12px;
    background:#fff;
    display:flex;
    align-items:center;
    justify-content:center;
}
.brand-logo-preview img{
    display:block;
    max-width:220px;
    max-height:72px;
    width:auto;
    height:auto;
    object-fit:contain;
}
.brand-logo-fallback{
    display:flex;
    align-items:center;
    gap:10px;
    color:#0a2747;
    font-weight:800;
    letter-spacing:.3px;
}
.brand-logo-fallback i{
    width:40px;
    height:40px;
    display:grid;
    place-items:center;
    border-radius:11px;
    color:#fff;
    background:linear-gradient(135deg,#0b74ff,#00b7ff);
}
.brand-logo-upload label{display:block;margin-bottom:7px;font-weight:800;color:#0b2747}
.brand-logo-file{padding:8px!important;height:auto!important;min-height:44px!important;background:#fff!important}
.document-logo-setting{
    background:linear-gradient(135deg,#fffdf7,#f7fbff);
    border-color:#cfdced;
}
.document-logo-preview{
    min-height:118px;
}
.document-logo-preview img{
    max-width:260px;
    max-height:104px;
}
.document-logo-scope{
    display:flex;
    flex-wrap:wrap;
    gap:7px;
    margin-top:10px;
}
.document-logo-scope span{
    display:inline-flex;
    align-items:center;
    gap:6px;
    padding:6px 9px;
    border:1px solid #d9e5f2;
    border-radius:999px;
    background:#fff;
    color:#38536f;
    font-size:11px;
    font-weight:800;
}
.document-logo-scope i{color:#0b74ff}
@media(max-width:720px){.brand-logo-setting{grid-template-columns:1fr}.brand-logo-preview{min-height:78px}}

.credential-uploader-intro{margin-top:20px;padding:18px;border:1px solid #dce7f6;border-radius:12px;background:#f7fbff;color:#18324f}
.credential-uploader-intro>p{margin:6px 0 15px;font-size:13px;line-height:1.6;color:#5f7186}
.credential-uploader-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}
.credential-upload-card{background:#fff;padding:12px;border:1px solid #dfe7f0;border-radius:11px;min-width:0}
.credential-upload-name{font-size:13px;font-weight:800;margin-bottom:9px}
.credential-upload-preview{height:83px;display:flex;align-items:center;justify-content:center;background:#f5f8fc;border:1px dashed #cbd8e8;border-radius:9px;margin-bottom:10px;color:#728198;font-size:12px}
.credential-upload-preview img{max-width:94%;max-height:74px;object-fit:contain}
.credential-upload-card label{display:block;font-size:12px;font-weight:800;margin-bottom:7px}
.credential-upload-card input[type=file]{width:100%;padding:6px;font-size:12px}
@media(max-width:1180px){.credential-uploader-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:640px){.credential-uploader-grid{grid-template-columns:1fr}}
/* V25.02 expandable card library – comfortable on laptops and mobiles. */
.credential-uploader-grid{grid-template-columns:repeat(3,minmax(0,1fr))}
.credential-upload-card[hidden]{display:none!important}
.credential-library-heading{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:12px}
.credential-library-heading p{margin:5px 0 0;color:#64748b;font-size:13px;line-height:1.5}
.credential-count{white-space:nowrap;color:#31537a;background:#e6f1ff;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:800}
.credential-upload-title{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px}
.credential-upload-card label{margin:11px 0 5px}
.credential-upload-card input,.credential-upload-card select{width:100%;font-size:14px;min-width:0}
.credential-upload-card input[type=file]{font-size:12px}
.credential-upload-card .help{margin-top:8px;font-size:12px;line-height:1.4}
.credential-remove{border:1px solid #e3eaf2;background:white;color:#52667f;padding:5px 10px;border-radius:7px;font-size:12px;cursor:pointer}
.credential-remove:hover{color:#a62d3c;border-color:#e9adb4;background:#fff4f5}
.credential-actions{display:flex;align-items:center;flex-wrap:wrap;gap:12px;margin:16px 0}
.credential-add{border:0;border-radius:9px;padding:11px 15px;background:#075fe3;color:white;font-size:14px;font-weight:800;cursor:pointer}
.credential-add:disabled{background:#94a3b8;cursor:not-allowed}
@media(max-width:1260px){.credential-uploader-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:690px){.credential-uploader-grid{grid-template-columns:1fr}.credential-library-heading{flex-wrap:wrap}}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>

<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Leads & Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>

        <a href="admin-crm.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-crm.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-user-tie"></i><span>CRM Workspace</span>
        </a>

        <div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->








<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->



<main class="main">

<header class="topbar">

    <div class="topbar-left">

        

        <div class="topbar-title">
            TRAVSCOPE Administration
        </div>

    </div>

    <div class="top-actions">

        <a
            href="<?= e(BASE_URL); ?>"
            target="_blank"
            class="view-site"
        >
            <i class="fa-solid fa-arrow-up-right-from-square"></i>
            <span>View Website</span>
        </a>

        <div class="admin-profile">

            <div class="admin-avatar">
                <?= e($adminInitial); ?>
            </div>

            <div class="admin-info">
                <strong><?= e($admin['name']); ?></strong>
                <span>
                    <?= e(
                        ucwords(
                            str_replace(
                                '_',
                                ' ',
                                (string)$admin['role']
                            )
                        )
                    ); ?>
                </span>
            </div>

        </div>

    </div>

</header>

<div class="content">

    <div class="page-heading">

        <div>
            <h1>Website Settings</h1>
            <p>
                Manage your TRAVSCOPE website, contact, payment and booking settings.
            </p>
        </div>

        <button
            type="submit"
            form="settingsForm"
            class="save-top"
        >
            <i class="fa-solid fa-floppy-disk"></i>
            Save Settings
        </button>

    </div>

    <?php if ($success !== ''): ?>
        <div class="alert success">
            <i class="fa-solid fa-circle-check"></i>
            <?= e($success); ?>
        </div>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
        <div class="alert error">
            <i class="fa-solid fa-triangle-exclamation"></i>
            <?= e($error); ?>
        </div>
    <?php endif; ?>

    <form
        method="post"
        id="settingsForm"
        enctype="multipart/form-data"
        autocomplete="off"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e($csrfToken); ?>"
        >

        <input
            type="hidden"
            name="form_action"
            value="save_settings"
        >

        <div class="settings-layout">

            <aside class="settings-nav">

                <?php foreach ($settingGroups as $groupKey => $group): ?>

                    <a href="#settings-<?= e($groupKey); ?>" class="settings-tab-link" data-settings-tab="settings-<?= e($groupKey); ?>">
                        <i class="<?= e($group['icon']); ?>"></i>
                        <?= e($group['title']); ?>
                    </a>
                    <?php if ($groupKey === 'system'): ?>
                        <a href="#homepage-slider" class="settings-tab-link" data-settings-tab="homepage-slider">
                            <i class="fa-solid fa-images"></i>
                            Homepage Slider
                        </a>
                    <?php endif; ?>
                    <?php if ($groupKey === 'general'): ?>
                        <a href="#add-user" class="settings-tab-link" data-settings-tab="add-user">
                            <i class="fa-solid fa-user-plus"></i>
                            Add User
                        </a>

                        <a href="#user-roles" class="settings-tab-link" data-settings-tab="user-roles">
                            <i class="fa-solid fa-user-shield"></i>
                            User Roles
                        </a>
                    <?php endif; ?>

                <?php endforeach; ?>

            </aside>

            <div class="settings-content">

                <?php foreach ($settingGroups as $groupKey => $group): ?>

                    <section
                        class="card settings-tab-panel"
                        id="settings-<?= e($groupKey); ?>"
                    >

                        <div class="card-head">

                            <div class="card-icon">
                                <i class="<?= e($group['icon']); ?>"></i>
                            </div>

                            <div>
                                <h2><?= e($group['title']); ?></h2>
                                <p><?= e($group['description']); ?></p>
                            </div>

                        </div>

                        <div class="card-body">

                            <div class="form-grid">

                                <?php foreach ($group['fields'] as $key => $field): ?>

                                    <?php
                                    $isFull =
                                        $field['type'] === 'textarea'
                                        || in_array(
                                            $key,
                                            [
                                                'office_address',
                                                'payment_instructions',
                                                'booking_notice',
                                                'cancellation_policy',
                                                'maintenance_message'
                                            ],
                                            true
                                        );
                                    ?>

                                    <div class="form-group <?= $isFull ? 'full' : ''; ?>">

                                        <label for="<?= e($key); ?>">
                                            <?= e($field['label']); ?>
                                        </label>

                                        <?php if ($field['type'] === 'textarea'): ?>

                                            <textarea
                                                class="form-control"
                                                name="<?= e($key); ?>"
                                                id="<?= e($key); ?>"
                                                maxlength="<?= (int)$field['maxlength']; ?>"
                                                placeholder="<?= e($field['placeholder'] ?? ''); ?>"
                                            ><?= e($values[$key]); ?></textarea>

                                        <?php elseif ($field['type'] === 'select'): ?>

                                            <select
                                                class="form-control"
                                                name="<?= e($key); ?>"
                                                id="<?= e($key); ?>"
                                            >

                                                <?php foreach ($field['options'] as $optionValue => $optionLabel): ?>

                                                    <option
                                                        value="<?= e($optionValue); ?>"
                                                        <?= $values[$key] === (string)$optionValue
                                                            ? 'selected'
                                                            : ''; ?>
                                                    >
                                                        <?= e($optionLabel); ?>
                                                    </option>

                                                <?php endforeach; ?>

                                            </select>

                                        <?php else: ?>

                                            <input
                                                class="form-control"
                                                type="<?= e($field['type']); ?>"
                                                name="<?= e($key); ?>"
                                                id="<?= e($key); ?>"
                                                maxlength="<?= (int)$field['maxlength']; ?>"
                                                <?= isset($field['min']) ? 'min="' . (int)$field['min'] . '"' : ''; ?>
                                                <?= isset($field['max']) ? 'max="' . (int)$field['max'] . '"' : ''; ?>
                                                <?= isset($field['step']) ? 'step="' . (int)$field['step'] . '"' : ''; ?>
                                                placeholder="<?= e($field['placeholder'] ?? ''); ?>"
                                                value="<?= e($values[$key]); ?>"
                                            >

                                        <?php endif; ?>

                                        <?php if (!empty($field['help'])): ?>
                                            <div class="help">
                                                <?= e($field['help']); ?>
                                            </div>
                                        <?php endif; ?>

                                    </div>

                                <?php endforeach; ?>

                            </div>

                            <?php if ($groupKey === 'quotation_credentials'): ?>
                                <div class="credential-uploader-intro" id="credentialManager">
                                    <div class="credential-library-heading">
                                        <div><strong>Credential & Association Logo Library</strong>
                                            <p>Add up to <?= (int)$credentialMaxSlots; ?> registration and association marks. Only items you individually approve for publication will appear on the website and customer documents.</p>
                                        </div>
                                        <span class="credential-count" id="credentialCount" aria-live="polite"></span>
                                    </div>
                                    <div class="credential-uploader-grid" id="credentialCards">
                                    <?php for ($slot=1; $slot<=$credentialMaxSlots; $slot++):
                                        $labelValue = tsCredSetting($pdo, 'quotation_credential_label_' . $slot);
                                        $logoValue = tsCredSetting($pdo, 'quotation_credential_logo_' . $slot);
                                        $approvedValue = tsCredSetting($pdo, 'quotation_credential_verified_' . $slot, '0');
                                        $safeLogo = tsCredSafeLogo($logoValue);
                                        $previewUrl = $safeLogo !== '' ? tsCredentialImageUrl($safeLogo) : '';
                                        $activeSlot = $slot <= 4 || $labelValue !== '' || $logoValue !== '' || $approvedValue === '1';
                                    ?>
                                        <div class="credential-upload-card" data-credential-card="<?= (int)$slot; ?>" <?= !$activeSlot ? 'hidden' : ''; ?>>
                                            <div class="credential-upload-title"><strong>Logo <?= (int)$slot; ?></strong><button type="button" class="credential-remove" data-remove-credential="<?= (int)$slot; ?>" aria-label="Clear credential <?= (int)$slot; ?>">Clear</button></div>
                                            <div class="credential-upload-preview"><img id="credentialLogoPreview<?= (int)$slot; ?>" src="<?= e($previewUrl); ?>" alt="Credential <?= (int)$slot; ?> preview" <?= $previewUrl === '' ? 'hidden' : ''; ?>><span id="credentialLogoEmpty<?= (int)$slot; ?>" <?= $previewUrl !== '' ? 'hidden' : ''; ?>>No logo selected</span></div>
                                            <label for="quotation_credential_label_<?= (int)$slot; ?>">Credential / organisation name</label>
                                            <input class="form-control" type="text" id="quotation_credential_label_<?= (int)$slot; ?>" name="quotation_credential_label_<?= (int)$slot; ?>" maxlength="120" placeholder="Official registration or association name" value="<?= e($labelValue); ?>" <?= !$activeSlot ? 'disabled' : ''; ?>>
                                            <label for="credential_logo_file_<?= (int)$slot; ?>">Browse logo image</label>
                                            <input type="file" class="form-control" id="credential_logo_file_<?= (int)$slot; ?>" name="credential_logo_file_<?= (int)$slot; ?>" accept="image/png,image/jpeg" data-credential-preview="<?= (int)$slot; ?>" <?= !$activeSlot ? 'disabled' : ''; ?>>
                                            <label for="quotation_credential_logo_<?= (int)$slot; ?>">Or use existing image path / HTTPS URL</label>
                                            <input class="form-control" type="text" id="quotation_credential_logo_<?= (int)$slot; ?>" name="quotation_credential_logo_<?= (int)$slot; ?>" maxlength="500" placeholder="uploads/settings/branding/example.png" value="<?= e($logoValue); ?>" <?= !$activeSlot ? 'disabled' : ''; ?>>
                                            <label for="quotation_credential_verified_<?= (int)$slot; ?>">Publication approval</label>
                                            <select class="form-control" id="quotation_credential_verified_<?= (int)$slot; ?>" name="quotation_credential_verified_<?= (int)$slot; ?>" <?= !$activeSlot ? 'disabled' : ''; ?>>
                                                <option value="0" <?= $approvedValue !== '1' ? 'selected' : ''; ?>>Hidden – Not approved</option>
                                                <option value="1" <?= $approvedValue === '1' ? 'selected' : ''; ?>>Display – Authorised to use</option>
                                            </select>
                                            <div class="help">PNG/JPG · max 3 MB · approval is required before publication.</div>
                                        </div>
                                    <?php endfor; ?>
                                    </div>
                                    <div class="credential-actions">
                                        <button type="button" id="addCredentialLogo" class="credential-add"><i class="fa-solid fa-plus"></i> Add Another Logo</button>
                                        <span id="credentialLimitMessage" class="help" role="status"></span>
                                    </div>
                                    <div class="help">Click <b>Save Settings</b> after adding, editing or clearing logos. Clearing a card changes only its saved settings; the previous file is not deleted from server storage. Existing Website Logo and Customer Document Logo settings remain separate.</div>
                                </div>
                            <?php endif; ?>

                            <?php if ($groupKey === 'general'): ?>
                                <div class="brand-logo-setting">
                                    <div class="brand-logo-preview">
                                        <?php if ($siteLogoPreviewUrl !== ''): ?>
                                            <img
                                                src="<?= e($siteLogoPreviewUrl); ?>"
                                                alt="Current website logo"
                                                id="siteLogoPreview"
                                            >
                                        <?php else: ?>
                                            <div class="brand-logo-fallback" id="siteLogoFallback">
                                                <i class="fa-solid fa-plane"></i>
                                                <span>TRAVSCOPE</span>
                                            </div>
                                            <img
                                                src=""
                                                alt="Website logo preview"
                                                id="siteLogoPreview"
                                                hidden
                                            >
                                        <?php endif; ?>
                                    </div>

                                    <div class="brand-logo-upload">
                                        <label for="site_logo_file">Website Logo</label>
                                        <input
                                            class="form-control brand-logo-file"
                                            type="file"
                                            name="site_logo_file"
                                            id="site_logo_file"
                                            accept="image/png,image/jpeg"
                                        >
                                        <div class="help">
                                            Upload PNG, JPG/JPEG or WebP (max 4 MB). This is the global website logo: it is used across public pages, customer/manager/staff portals, Login/Register pages and the Admin sidebar/topbar. If no logo is uploaded, the existing TRAVSCOPE branding remains.
                                        </div>
                                    </div>
                                </div>

                                <div class="brand-logo-setting document-logo-setting">
                                    <div class="brand-logo-preview document-logo-preview">
                                        <img
                                            src="<?= e($documentLogoPreviewUrl); ?>"
                                            alt="Current document logo"
                                            id="documentLogoPreview"
                                        >
                                    </div>

                                    <div class="brand-logo-upload">
                                        <label for="document_logo_file">Customer Document Logo</label>
                                        <input
                                            class="form-control brand-logo-file"
                                            type="file"
                                            name="document_logo_file"
                                            id="document_logo_file"
                                            accept="image/png,image/jpeg,image/webp"
                                        >
                                        <div class="help">
                                            Separate from the Website Logo. This artwork is used only on customer-facing documents: Tax/Booking Invoices, Money Receipts, Quotations and quotation PDFs, Travel Vouchers, and printable/PDF itineraries. Recommended: a wide horizontal logo, approximately 3-inch document width. PNG or JPG/JPEG; max 6 MB.
                                        </div>
                                        <div class="document-logo-scope">
                                            <span><i class="fa-solid fa-file-invoice"></i> Invoice</span>
                                            <span><i class="fa-solid fa-receipt"></i> Money Receipt</span>
                                            <span><i class="fa-solid fa-file-signature"></i> Quotation</span>
                                            <span><i class="fa-solid fa-ticket"></i> Voucher</span>
                                            <span><i class="fa-solid fa-route"></i> PDF Itinerary</span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if ($groupKey === 'payment'): ?>

                                <div class="security-note">
                                    <i class="fa-solid fa-shield-halved"></i>
                                    Keep database passwords, Gmail App Passwords, API secrets and payment-gateway secret keys in <strong>config.php</strong> or secure environment configuration. Do not save secret credentials in this settings table.
                                </div>

                            <?php endif; ?>

                            <?php if ($groupKey === 'system'): ?>

                                <div class="security-note">
                                    <i class="fa-solid fa-circle-info"></i>
                                    When Maintenance Mode is On, public/customer pages are blocked with a maintenance message while administrator access remains available. Booking and enquiry switches continue to use their existing controls.
                                </div>

                            <?php endif; ?>

                        </div>

                    </section>

<?php if ($groupKey === 'system'): ?>
                    <section class="card settings-tab-panel" id="homepage-slider">
                        <div class="card-head">
                            <div class="card-icon"><i class="fa-solid fa-images"></i></div>
                            <div>
                                <h2>Homepage Slider Manager</h2>
                                <p>Upload professional desktop/mobile hero images and control the scrolling homepage banner.</p>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label>Badge Text</label>
                                    <input class="form-control" name="slide_badge" form="slideAddForm" maxlength="150" placeholder="Explore More. Travel Better.">
                                </div>
                                <div class="form-group">
                                    <label>Heading</label>
                                    <input class="form-control" name="slide_heading" form="slideAddForm" maxlength="255" placeholder="Find your next unforgettable journey." required>
                                </div>
                                <div class="form-group">
                                    <label>Highlight Text</label>
                                    <input class="form-control" name="slide_highlight" form="slideAddForm" maxlength="150" placeholder="unforgettable journey.">
                                </div>
                                <div class="form-group full">
                                    <label>Description</label>
                                    <textarea class="form-control" name="slide_description" form="slideAddForm" maxlength="700" placeholder="Short banner description"></textarea>
                                </div>
                                <div class="form-group">
                                    <label>Desktop Image</label>
                                    <input class="form-control" type="file" name="slide_desktop_image" form="slideAddForm" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" required>
                                    <div class="help">Recommended wide image, e.g. 1920×900. Maximum 8 MB.</div>
                                </div>
                                <div class="form-group">
                                    <label>Mobile Image</label>
                                    <input class="form-control" type="file" name="slide_mobile_image" form="slideAddForm" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp">
                                    <div class="help">Optional portrait/mobile image.</div>
                                </div>
                                <div class="form-group">
                                    <label>Primary Button Text</label>
                                    <input class="form-control" name="slide_primary_text" form="slideAddForm" maxlength="100" placeholder="Explore Packages">
                                </div>
                                <div class="form-group">
                                    <label>Primary Button URL</label>
                                    <input class="form-control" name="slide_primary_url" form="slideAddForm" maxlength="500" placeholder="#packages or packages.php">
                                </div>
                                <div class="form-group">
                                    <label>Secondary Button Text</label>
                                    <input class="form-control" name="slide_secondary_text" form="slideAddForm" maxlength="100" placeholder="Talk to Travel Expert">
                                </div>
                                <div class="form-group">
                                    <label>Secondary Button URL</label>
                                    <input class="form-control" name="slide_secondary_url" form="slideAddForm" maxlength="500" placeholder="contact.php">
                                </div>
                                <div class="form-group">
                                    <label>Display Order</label>
                                    <input class="form-control" type="number" min="0" name="slide_sort_order" form="slideAddForm" value="0">
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <select class="form-control" name="slide_status" form="slideAddForm">
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                            </div>
                            <div style="margin-top:18px;display:flex;justify-content:flex-end">
                                <button class="btn btn-primary" type="submit" form="slideAddForm">
                                    <i class="fa-solid fa-cloud-arrow-up"></i> Add Slide
                                </button>
                            </div>

                            <div style="margin-top:28px;padding-top:22px;border-top:2px solid #e4eaf1">
                                <h3 style="font-size:14px;color:#07192d;margin:0">
                                    <i class="fa-solid fa-sliders"></i> Manage Existing Slides
                                </h3>
                                <p style="font-size:14px;color:#718096;margin-top:4px">
                                    <?= count($homepageSlides); ?> slide(s) found. Modify, enable/disable or permanently delete any slide below.
                                </p>
                            </div>

                            <?php if ($homepageSlides): ?>
                            <div style="display:grid;gap:18px;margin-top:12px">
                                <?php foreach ($homepageSlides as $slide): ?>
                                <div style="border:1px solid var(--border);border-radius:14px;overflow:hidden;background:#fff">
                                    <div style="display:grid;grid-template-columns:minmax(240px,34%) 1fr;gap:0">
                                        <div style="background:#eef3f8;min-height:210px">
                                            <img src="<?= e(BASE_URL . ltrim((string)$slide['desktop_image'],'/')); ?>"
                                                 alt="<?= e($slide['heading']); ?>"
                                                 style="width:100%;height:100%;min-height:210px;object-fit:cover">
                                        </div>
                                        <div style="padding:18px">
                                            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
                                                <div>
                                                    <div style="font-size:11px;font-weight:800;color:#0b74ff;text-transform:uppercase">
                                                        <?= e($slide['badge_text'] ?: 'No badge'); ?>
                                                    </div>
                                                    <h3 style="font-size:14px;margin-top:5px"><?= e($slide['heading']); ?></h3>
                                                    <?php if(!empty($slide['highlight_text'])): ?>
                                                        <div class="help">Highlight: <?= e($slide['highlight_text']); ?></div>
                                                    <?php endif; ?>
                                                </div>
                                                <span class="status-badge <?= $slide['status']==='active'?'status-active':'status-inactive'; ?>">
                                                    <?= e(ucfirst($slide['status'])); ?>
                                                </span>
                                            </div>

                                            <?php if(!empty($slide['description'])): ?>
                                                <p style="font-size:14px;color:#64748b;margin-top:10px;line-height:1.6"><?= e($slide['description']); ?></p>
                                            <?php endif; ?>

                                            <div style="display:flex;gap:14px;flex-wrap:wrap;margin-top:12px;font-size:11px;color:#64748b">
                                                <span><strong>Order:</strong> <?= (int)$slide['sort_order']; ?></span>
                                                <span><strong>Primary:</strong> <?= e($slide['primary_button_text'] ?: '—'); ?></span>
                                                <span><strong>Secondary:</strong> <?= e($slide['secondary_button_text'] ?: '—'); ?></span>
                                                <span><strong>Mobile image:</strong> <?= !empty($slide['mobile_image']) ? 'Yes' : 'No'; ?></span>
                                            </div>

                                            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px">
                                                <button type="button"
                                                        onclick="document.getElementById('slideEdit<?= (int)$slide['id']; ?>').style.display='block'"
                                                        style="border:0;border-radius:8px;padding:10px 14px;background:#0b74ff;color:#fff;font-size:14px;font-weight:800;cursor:pointer">
                                                    <i class="fa-solid fa-pen-to-square"></i> Modify Slide
                                                </button>
                                                <button type="submit" form="slideToggle<?= (int)$slide['id']; ?>"
                                                        style="border:1px solid #d8e1eb;border-radius:8px;padding:10px 14px;background:#fff;color:#334155;font-size:14px;font-weight:800;cursor:pointer">
                                                    <i class="fa-solid fa-power-off"></i>
                                                    <?= $slide['status']==='active' ? 'Disable Slide' : 'Enable Slide'; ?>
                                                </button>
                                                <button type="submit" form="slideDelete<?= (int)$slide['id']; ?>"

                                                        style="border:0;border-radius:8px;padding:10px 14px;background:#dc2626;color:#fff;font-size:14px;font-weight:800;cursor:pointer">
                                                    <i class="fa-solid fa-trash-can"></i> Delete Slide
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="slideEdit<?= (int)$slide['id']; ?>" style="display:none;padding:18px;border-top:1px solid var(--border);background:#f8fafc">
                                        <h3 style="font-size:14px;margin-bottom:14px">Modify Slide #<?= (int)$slide['id']; ?></h3>
                                        <div class="form-grid">
                                            <div class="form-group"><label>Badge Text</label><input class="form-control" name="slide_badge" form="slideUpdate<?= (int)$slide['id']; ?>" value="<?= e($slide['badge_text']); ?>"></div>
                                            <div class="form-group"><label>Heading</label><input class="form-control" name="slide_heading" form="slideUpdate<?= (int)$slide['id']; ?>" value="<?= e($slide['heading']); ?>" required></div>
                                            <div class="form-group"><label>Highlight Text</label><input class="form-control" name="slide_highlight" form="slideUpdate<?= (int)$slide['id']; ?>" value="<?= e($slide['highlight_text']); ?>"></div>
                                            <div class="form-group full"><label>Description</label><textarea class="form-control" name="slide_description" form="slideUpdate<?= (int)$slide['id']; ?>"><?= e($slide['description']); ?></textarea></div>
                                            <div class="form-group"><label>Replace Desktop Image</label><input class="form-control" type="file" name="slide_desktop_image" form="slideUpdate<?= (int)$slide['id']; ?>" accept=".jpg,.jpeg,.png,.webp"><div class="help">Leave empty to keep current image.</div></div>
                                            <div class="form-group"><label>Replace Mobile Image</label><input class="form-control" type="file" name="slide_mobile_image" form="slideUpdate<?= (int)$slide['id']; ?>" accept=".jpg,.jpeg,.png,.webp"><div class="help">Leave empty to keep current image.</div></div>
                                            <div class="form-group"><label>Primary Button Text</label><input class="form-control" name="slide_primary_text" form="slideUpdate<?= (int)$slide['id']; ?>" value="<?= e($slide['primary_button_text']); ?>"></div>
                                            <div class="form-group"><label>Primary Button URL</label><input class="form-control" name="slide_primary_url" form="slideUpdate<?= (int)$slide['id']; ?>" value="<?= e($slide['primary_button_url']); ?>"></div>
                                            <div class="form-group"><label>Secondary Button Text</label><input class="form-control" name="slide_secondary_text" form="slideUpdate<?= (int)$slide['id']; ?>" value="<?= e($slide['secondary_button_text']); ?>"></div>
                                            <div class="form-group"><label>Secondary Button URL</label><input class="form-control" name="slide_secondary_url" form="slideUpdate<?= (int)$slide['id']; ?>" value="<?= e($slide['secondary_button_url']); ?>"></div>
                                            <div class="form-group"><label>Display Order</label><input class="form-control" type="number" min="0" name="slide_sort_order" form="slideUpdate<?= (int)$slide['id']; ?>" value="<?= (int)$slide['sort_order']; ?>"></div>
                                            <div class="form-group"><label>Status</label><select class="form-control" name="slide_status" form="slideUpdate<?= (int)$slide['id']; ?>"><option value="active" <?= $slide['status']==='active'?'selected':''; ?>>Active</option><option value="inactive" <?= $slide['status']==='inactive'?'selected':''; ?>>Inactive</option></select></div>
                                        </div>
                                        <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
                                            <button type="button" class="btn" onclick="document.getElementById('slideEdit<?= (int)$slide['id']; ?>').style.display='none'">Cancel</button>
                                            <button type="submit" class="btn btn-primary" form="slideUpdate<?= (int)$slide['id']; ?>"><i class="fa-solid fa-floppy-disk"></i> Save Changes</button>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php else: ?>
                                <div class="empty" style="margin-top:20px">
                                    <i class="fa-regular fa-images"></i>
                                    <strong>No homepage slides yet</strong>
                                    <p>Add your first slide using the form above.</p>
                                </div>
                            <?php endif; ?>

                        </div>
                    </section>
                    <?php endif; ?>

                    <?php if ($groupKey === 'general'): ?>

                        <section class="card settings-tab-panel" id="add-user">

                            <div class="card-head">
                                <div class="card-icon">
                                    <i class="fa-solid fa-user-plus"></i>
                                </div>
                                <div>
                                    <h2>Add New User</h2>
                                    <p>Create a User, Staff or Manager account directly from the admin panel.</p>
                                </div>
                            </div>

                            <div class="card-body">
                                <div class="form-grid">

                                    <div class="form-group">
                                        <label for="customer_full_name">Full Name</label>
                                        <input class="form-control" type="text"
                                            name="customer_full_name" id="customer_full_name"
                                            maxlength="150" form="addCustomerForm"
                                            placeholder="Customer full name" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="customer_email">Email</label>
                                        <input class="form-control" type="email"
                                            name="customer_email" id="customer_email"
                                            maxlength="190" form="addCustomerForm"
                                            placeholder="customer@example.com" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="customer_mobile">Mobile</label>
                                        <input class="form-control" type="text"
                                            name="customer_mobile" id="customer_mobile"
                                            maxlength="20" form="addCustomerForm"
                                            placeholder="Customer mobile number">
                                    </div>

                                    <div class="form-group">
                                        <label for="customer_country">Country</label>
                                        <input class="form-control" type="text"
                                            name="customer_country" id="customer_country"
                                            maxlength="100" form="addCustomerForm"
                                            placeholder="India">
                                    </div>

                                    <div class="form-group">
                                        <label for="customer_password">Password</label>
                                        <input class="form-control" type="password"
                                            name="customer_password" id="customer_password"
                                            minlength="8" maxlength="255" form="addCustomerForm"
                                            autocomplete="new-password"
                                            placeholder="Minimum 8 characters" required>
                                        <div class="help">Password is stored using PHP secure password hashing.</div>
                                    </div>

                                    <div class="form-group">
                                        <label for="customer_status">Status</label>
                                        <select class="form-control"
                                            name="customer_status" id="customer_status"
                                            form="addCustomerForm">
                                            <option value="active">Active</option>
                                            <option value="inactive">Inactive</option>
                                            <option value="blocked">Blocked</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="customer_role">User Role</label>
                                        <select class="form-control"
                                            name="customer_role" id="customer_role"
                                            form="addCustomerForm">
                                            <option value="user">User — Customer Dashboard</option>
                                            <option value="staff">Staff — Staff Dashboard</option>
                                            <option value="manager">Manager — Manager Dashboard</option>
                                        </select>
                                        <div class="help">
                                            Admin can change this role any time from User &amp; Role Management below.
                                        </div>
                                    </div>

                                </div>

                                <div style="margin-top:18px;display:flex;justify-content:flex-end;">
                                    <button type="submit" form="addCustomerForm"
                                        class="btn btn-primary">
                                        <i class="fa-solid fa-user-plus"></i>
                                        Create User
                                    </button>
                                </div>
                            </div>

                        </section>

                        <section class="card settings-tab-panel" id="user-roles">

                            <div class="card-head">
                                <div class="card-icon">
                                    <i class="fa-solid fa-user-shield"></i>
                                </div>
                                <div>
                                    <h2>User &amp; Role Management</h2>
                                    <p>Promote or change any account between User, Staff and Manager at any time.</p>
                                </div>
                            </div>

                            <div class="card-body">

                                <?php if (!$userRoleColumnReady): ?>
                                    <div class="role-setup-error">
                                        <i class="fa-solid fa-triangle-exclamation"></i>
                                        <div>
                                            <strong>Role management database setup is unavailable.</strong>
                                            <span>Please allow ALTER permission for the website database user, then reload this page.</span>
                                        </div>
                                    </div>
                                <?php elseif (!$roleManagedUsers): ?>
                                    <div class="empty">
                                        <i class="fa-solid fa-users"></i>
                                        <strong>No users found</strong>
                                        <p>Create your first user using the Add New User section.</p>
                                    </div>
                                <?php else: ?>

                                    <div class="role-summary-grid">
                                        <?php
                                        $roleCounts = ['user' => 0, 'staff' => 0, 'manager' => 0];
                                        foreach ($roleManagedUsers as $roleUser) {
                                            $roleKey = strtolower((string)($roleUser['role'] ?? 'user'));
                                            if (isset($roleCounts[$roleKey])) {
                                                $roleCounts[$roleKey]++;
                                            }
                                        }
                                        ?>
                                        <div class="role-summary role-summary-user">
                                            <i class="fa-solid fa-user"></i>
                                            <div><strong><?= (int)$roleCounts['user']; ?></strong><span>Users</span></div>
                                        </div>
                                        <div class="role-summary role-summary-staff">
                                            <i class="fa-solid fa-headset"></i>
                                            <div><strong><?= (int)$roleCounts['staff']; ?></strong><span>Staff</span></div>
                                        </div>
                                        <div class="role-summary role-summary-manager">
                                            <i class="fa-solid fa-user-tie"></i>
                                            <div><strong><?= (int)$roleCounts['manager']; ?></strong><span>Managers</span></div>
                                        </div>
                                    </div>

                                    <div class="role-user-list">
                                        <?php foreach ($roleManagedUsers as $roleUser): ?>
                                            <?php
                                            $roleKey = strtolower((string)($roleUser['role'] ?? 'user'));
                                            if (!isset($userRoleOptions[$roleKey])) {
                                                $roleKey = 'user';
                                            }
                                            $roleBadgeClass = 'role-badge-' . $roleKey;
                                            ?>
                                            <article class="role-user-card">

                                                <div class="role-user-avatar">
                                                    <?= e(strtoupper(substr((string)$roleUser['full_name'], 0, 1))); ?>
                                                </div>

                                                <div class="role-user-main">
                                                    <div class="role-user-name-row">
                                                        <strong><?= e((string)$roleUser['full_name']); ?></strong>
                                                        <span class="role-badge <?= e($roleBadgeClass); ?>">
                                                            <?= e($userRoleOptions[$roleKey]); ?>
                                                        </span>
                                                    </div>
                                                    <span><?= e((string)$roleUser['email']); ?></span>
                                                    <small>
                                                        #<?= (int)$roleUser['id']; ?>
                                                        <?php if (!empty($roleUser['mobile'])): ?>
                                                            • <?= e((string)$roleUser['mobile']); ?>
                                                        <?php endif; ?>
                                                        • <?= (int)$roleUser['email_verified'] === 1 ? 'Verified' : 'Unverified'; ?>
                                                        • <?= e(ucfirst((string)$roleUser['status'])); ?>
                                                    </small>
                                                </div>

                                                <div class="role-change-form">

                                                    <select
                                                        class="role-select"
                                                        name="new_user_role"
                                                        form="roleChangeForm<?= (int)$roleUser['id']; ?>"
                                                        aria-label="Select role for <?= e((string)$roleUser['full_name']); ?>"
                                                    >
                                                        <?php foreach ($userRoleOptions as $value => $label): ?>
                                                            <option value="<?= e($value); ?>" <?= $roleKey === $value ? 'selected' : ''; ?>>
                                                                <?= e($label); ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>

                                                    <button
                                                        type="submit"
                                                        class="role-update-btn"
                                                        form="roleChangeForm<?= (int)$roleUser['id']; ?>"
                                                    >
                                                        <i class="fa-solid fa-arrows-rotate"></i>
                                                        Update Role
                                                    </button>

                                                </div>

                                            </article>
                                        <?php endforeach; ?>
                                    </div>

                                <?php endif; ?>

                            </div>

                        </section>

                    <?php endif; ?>

                <?php endforeach; ?>

                <div class="form-footer">

                    <a
                        href="admin-dashboard.php"
                        class="btn"
                    >
                        <i class="fa-solid fa-arrow-left"></i>
                        Back to Dashboard
                    </a>

                    <button
                        type="submit"
                        form="settingsForm"
                        class="btn btn-primary"
                    >
                        <i class="fa-solid fa-floppy-disk"></i>
                        Save All Settings
                    </button>

                </div>

            </div>

        </div>

    </form>

    <form method="post" enctype="multipart/form-data" id="slideAddForm">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
        <input type="hidden" name="form_action" value="add_slide">
    </form>

    <?php foreach ($homepageSlides as $slide): ?>
    <form method="post" enctype="multipart/form-data" id="slideUpdate<?= (int)$slide['id']; ?>">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
        <input type="hidden" name="form_action" value="update_slide">
        <input type="hidden" name="slide_id" value="<?= (int)$slide['id']; ?>">
    </form>
    <form method="post" id="slideToggle<?= (int)$slide['id']; ?>">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
        <input type="hidden" name="form_action" value="toggle_slide">
        <input type="hidden" name="slide_id" value="<?= (int)$slide['id']; ?>">
    </form>
    <form method="post" id="slideDelete<?= (int)$slide['id']; ?>">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
        <input type="hidden" name="form_action" value="delete_slide">
        <input type="hidden" name="slide_id" value="<?= (int)$slide['id']; ?>">
    </form>
    <?php endforeach; ?>

    <form method="post" id="addCustomerForm" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
        <input type="hidden" name="form_action" value="add_customer">
    </form>

    <?php foreach ($roleManagedUsers as $roleFormUser): ?>
        <form
            method="post"
            id="roleChangeForm<?= (int)$roleFormUser['id']; ?>"
            autocomplete="off"
        >
            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
            <input type="hidden" name="form_action" value="update_user_role">
            <input type="hidden" name="target_user_id" value="<?= (int)$roleFormUser['id']; ?>">
        </form>
    <?php endforeach; ?>

</div>

</main>

<script>

const sidebar =
    document.getElementById('sidebar');

const overlay =
    document.getElementById('sidebarOverlay');

const mobileMenu =
    document.getElementById('mobileMenu');

if (mobileMenu) {
    mobileMenu.addEventListener('click', function () {
        sidebar.classList.toggle('open');
        overlay.classList.toggle('show');
    });
}

if (overlay) {
    overlay.addEventListener('click', function () {
        sidebar.classList.remove('open');
        overlay.classList.remove('show');
    });
}

const currencyCode =
    document.getElementById('currency_code');

if (currencyCode) {
    currencyCode.addEventListener('input', function () {
        this.value = this.value.toUpperCase();
    });
}

</script>








<script>
(function () {
    const links = Array.from(
        document.querySelectorAll('.settings-tab-link[data-settings-tab]')
    ).filter(function (link) {
        const href = link.getAttribute('href') || '';
        return href.startsWith('#');
    });

    const panels = Array.from(
        document.querySelectorAll('.settings-tab-panel')
    );

    if (!links.length || !panels.length) {
        return;
    }

    function openSettingsTab(tabId, updateHash) {
        const panel = document.getElementById(tabId);

        if (!panel || !panel.classList.contains('settings-tab-panel')) {
            return;
        }

        panels.forEach(function (item) {
            item.classList.remove('is-active');
        });

        links.forEach(function (link) {
            link.classList.toggle(
                'active',
                link.getAttribute('data-settings-tab') === tabId
            );
        });

        panel.classList.add('is-active');

        if (updateHash) {
            history.replaceState(null, '', '#' + tabId);
        }

        const body = panel.querySelector('.card-body');
        if (body) {
            body.scrollTop = 0;
        }
    }

    links.forEach(function (link) {
        link.addEventListener('click', function (event) {
            const href = this.getAttribute('href') || '';
            const tabId = this.getAttribute('data-settings-tab');

            /* Only #section links are handled as settings tabs.
               Normal links such as admin-pages.php navigate normally. */
            if (!href.startsWith('#') || !tabId) {
                return;
            }

            event.preventDefault();
            openSettingsTab(tabId, true);
        });
    });

    const requested = window.location.hash.replace('#', '');
    const requestedIsValid = panels.some(function (panel) {
        return panel.id === requested;
    });

    const defaultPanel = document.getElementById('settings-general')
        ? 'settings-general'
        : panels[0].id;

    openSettingsTab(
        requestedIsValid ? requested : defaultPanel,
        false
    );

    window.addEventListener('hashchange', function () {
        const tabId = window.location.hash.replace('#', '');
        if (tabId) {
            openSettingsTab(tabId, false);
        }
    });
})();
</script>







<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
<script>
(function(){
    const input = document.getElementById('site_logo_file');
    const preview = document.getElementById('siteLogoPreview');
    const fallback = document.getElementById('siteLogoFallback');
    if (!input || !preview) return;

    input.addEventListener('change', function(){
        const file = this.files && this.files[0] ? this.files[0] : null;
        if (!file || !file.type.startsWith('image/')) return;
        const url = URL.createObjectURL(file);
        preview.src = url;
        preview.hidden = false;
        if (fallback) fallback.hidden = true;
        preview.onload = function(){ URL.revokeObjectURL(url); };
    });
})();

(function(){
    const input = document.getElementById('document_logo_file');
    const preview = document.getElementById('documentLogoPreview');
    if (!input || !preview) return;

    input.addEventListener('change', function(){
        const file = this.files && this.files[0] ? this.files[0] : null;
        if (!file || !file.type.startsWith('image/')) return;
        const url = URL.createObjectURL(file);
        preview.src = url;
        preview.hidden = false;
        preview.onload = function(){ URL.revokeObjectURL(url); };
    });
})();
</script>

<script src="assets/credentials-manager-v2502.js?v=2502" defer></script>
</body>
</html>
