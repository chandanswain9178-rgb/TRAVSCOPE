<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — DOCUMENT & TRAVELLER FILE CENTER
|--------------------------------------------------------------------------
|
| Existing customer profile document vault is preserved.
| Profile documents are COPIED into the Booking file center when selected,
| so later profile cleanup cannot break an immutable Booking document pack.
|
*/

$tsDocSystemSettingsFile = __DIR__ . '/system-settings-functions.php';
if (
    is_file($tsDocSystemSettingsFile)
    && !function_exists('tsSystemSettingInt')
) {
    require_once $tsDocSystemSettingsFile;
}

function tsDocTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];

    $key = strtolower($table);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
              AND table_name = ?
        ");
        $stmt->execute([$table]);

        return $cache[$key] =
            ((int)$stmt->fetchColumn() > 0);

    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}


function tsDocReady(PDO $pdo): bool
{
    return
        tsDocTableExists($pdo, 'booking_travellers')
        && tsDocTableExists($pdo, 'booking_travel_documents')
        && tsDocTableExists($pdo, 'booking_document_requirements')
        && tsDocTableExists($pdo, 'booking_document_pack_versions')
        && tsDocTableExists($pdo, 'bookings');
}


function tsDocTypes(): array
{
    return [
        'identity' => [
            'Aadhaar Card',
            'PAN Card',
            'Voter ID',
            'Driving Licence',
            'National ID',
            'Birth Certificate',
        ],
        'travel' => [
            'Passport',
            'Visa',
            'Travel Insurance',
            'Flight Ticket',
            'Train Ticket',
            'Cruise Ticket',
            'Hotel Voucher',
            'Tourist Permit',
            'Vaccination Certificate',
            'Other Travel Document',
        ],
    ];
}


function tsDocRequirementTypes(): array
{
    return array_merge(
        ['Primary Travel ID'],
        tsDocTypes()['identity'],
        tsDocTypes()['travel']
    );
}


function tsDocCategory(string $type): string
{
    foreach (tsDocTypes() as $category => $types) {
        if (in_array($type, $types, true)) {
            return $category;
        }
    }

    return 'travel';
}


function tsDocMaskNumber(?string $value): string
{
    $value = trim((string)$value);

    if ($value === '') {
        return 'Not entered';
    }

    $clean =
        preg_replace(
            '/\s+/',
            '',
            $value
        );

    if (!is_string($clean) || $clean === '') {
        return 'Entered';
    }

    $len = strlen($clean);

    if ($len <= 4) {
        return str_repeat('•', $len);
    }

    return
        str_repeat(
            '•',
            max(
                4,
                $len - 4
            )
        )
        . substr($clean, -4);
}


function tsDocBooking(PDO $pdo, int $bookingId): array
{
    $stmt = $pdo->prepare("
        SELECT
            b.*,
            p.title AS package_title,
            d.name AS destination_name
        FROM bookings b
        LEFT JOIN packages p
            ON p.id = b.package_id
        LEFT JOIN destinations d
            ON d.id = p.destination_id
        WHERE b.id = ?
        LIMIT 1
    ");
    $stmt->execute([$bookingId]);

    $booking =
        $stmt->fetch(PDO::FETCH_ASSOC)
        ?: null;

    if (!$booking) {
        throw new RuntimeException(
            'Booking was not found.'
        );
    }

    return $booking;
}


function tsDocTripCode(PDO $pdo, int $bookingId): string
{
    if (
        !tsDocTableExists(
            $pdo,
            'booking_trip_links'
        )
        || !tsDocTableExists(
            $pdo,
            'trips'
        )
    ) {
        return '';
    }

    $stmt = $pdo->prepare("
        SELECT t.trip_code
        FROM booking_trip_links l
        JOIN trips t
            ON t.id = l.trip_id
        WHERE l.booking_id = ?
        LIMIT 1
    ");
    $stmt->execute([$bookingId]);

    return
        trim(
            (string)(
                $stmt->fetchColumn()
                ?: ''
            )
        );
}


function tsDocExpectedTravellerCount(array $booking): int
{
    $count =
        max(
            0,
            (int)($booking['adults'] ?? 0)
        )
        +
        max(
            0,
            (int)($booking['children'] ?? 0)
        );

    return
        max(
            1,
            $count
        );
}


function tsDocAssertEditable(PDO $pdo, int $bookingId): void
{
    if (!tsDocReady($pdo)) {
        throw new RuntimeException(
            'Document & Traveller File Center SQL is not installed yet.'
        );
    }

    $booking =
        tsDocBooking(
            $pdo,
            $bookingId
        );

    $status =
        strtolower(
            trim(
                (string)(
                    $booking['booking_status']
                    ?? ''
                )
            )
        );

    if (
        in_array(
            $status,
            ['cancelled','completed'],
            true
        )
    ) {
        throw new RuntimeException(
            'Cancelled or completed Bookings cannot change traveller documents.'
        );
    }

    if (
        tsDocTableExists(
            $pdo,
            'booking_profitability_closures'
        )
    ) {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM booking_profitability_closures
            WHERE booking_id = ?
        ");
        $stmt->execute([$bookingId]);

        if ((int)$stmt->fetchColumn() > 0) {
            throw new RuntimeException(
                'Traveller documents are locked because this Booking is financially closed.'
            );
        }
    }
}


function tsDocTravellerCode(
    int $bookingId
): string {
    return
        'TRV-B'
        . $bookingId
        . '-'
        . strtoupper(
            substr(
                bin2hex(
                    random_bytes(6)
                ),
                0,
                10
            )
        );
}


function tsDocEnsurePrimaryRequirement(
    PDO $pdo,
    int $bookingId,
    int $travellerId,
    ?int $adminId = null
): void {
    if (
        !tsDocReady($pdo)
        || $bookingId <= 0
        || $travellerId <= 0
    ) {
        return;
    }

    $stmt = $pdo->prepare("
        INSERT IGNORE INTO booking_document_requirements
        (
            booking_id,
            traveller_id,
            document_type,
            is_required,
            status,
            sort_order,
            created_by_admin_id
        )
        VALUES (?, ?, 'Primary Travel ID', 1, 'required', 10, ?)
    ");
    $stmt->execute([
        $bookingId,
        $travellerId,
        $adminId
            ? $adminId
            : null
    ]);
}


function tsDocEnsureLeadTraveller(
    PDO $pdo,
    int $bookingId
): ?array {
    if (
        !tsDocReady($pdo)
        || $bookingId <= 0
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_travellers
        WHERE booking_id = ?
          AND status = 'active'
        ORDER BY
            CASE
                WHEN traveller_type = 'lead'
                THEN 0
                ELSE 1
            END,
            id ASC
        LIMIT 1
    ");
    $stmt->execute([$bookingId]);

    $existing =
        $stmt->fetch(PDO::FETCH_ASSOC)
        ?: null;

    if ($existing) {
        tsDocEnsurePrimaryRequirement(
            $pdo,
            $bookingId,
            (int)$existing['id']
        );

        return $existing;
    }

    $booking =
        tsDocBooking(
            $pdo,
            $bookingId
        );

    $name =
        trim(
            (string)(
                $booking['customer_name']
                ?? ''
            )
        );

    if ($name === '') {
        $name = 'Lead Traveller';
    }

    $sourceUserId =
        max(
            0,
            (int)(
                $booking['user_id']
                ?? 0
            )
        );

    $dateOfBirth = null;

    if (
        $sourceUserId > 0
        && tsDocTableExists(
            $pdo,
            'user_travel_profiles'
        )
    ) {
        $stmt = $pdo->prepare("
            SELECT date_of_birth
            FROM user_travel_profiles
            WHERE user_id = ?
            LIMIT 1
        ");
        $stmt->execute([$sourceUserId]);

        $dateOfBirth =
            $stmt->fetchColumn()
            ?: null;
    }

    $stmt = $pdo->prepare("
        INSERT INTO booking_travellers
        (
            booking_id,
            source_user_id,
            source_family_member_id,
            traveller_code,
            traveller_type,
            full_name,
            relationship,
            date_of_birth,
            nationality,
            status,
            created_by_type
        )
        VALUES (?, ?, NULL, ?, 'lead', ?, 'Lead Traveller', ?, ?, 'active', 'system')
    ");

    $stmt->execute([
        $bookingId,
        $sourceUserId > 0
            ? $sourceUserId
            : null,
        tsDocTravellerCode($bookingId),
        $name,
        $dateOfBirth,
        trim(
            (string)(
                $booking['customer_country']
                ?? ''
            )
        ) ?: null
    ]);

    $travellerId =
        (int)$pdo->lastInsertId();

    tsDocEnsurePrimaryRequirement(
        $pdo,
        $bookingId,
        $travellerId
    );

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_travellers
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$travellerId]);

    return
        $stmt->fetch(PDO::FETCH_ASSOC)
        ?: null;
}


function tsDocTravellers(
    PDO $pdo,
    int $bookingId,
    bool $includeCancelled = false
): array {
    if (
        !tsDocReady($pdo)
        || $bookingId <= 0
    ) {
        return [];
    }

    tsDocEnsureLeadTraveller(
        $pdo,
        $bookingId
    );

    $sql = "
        SELECT *
        FROM booking_travellers
        WHERE booking_id = ?
    ";

    if (!$includeCancelled) {
        $sql .= "
          AND status = 'active'
        ";
    }

    $sql .= "
        ORDER BY
            CASE traveller_type
                WHEN 'lead' THEN 0
                WHEN 'adult' THEN 1
                WHEN 'child' THEN 2
                ELSE 3
            END,
            id ASC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$bookingId]);

    return
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        ?: [];
}


function tsDocHouseholdChoices(
    PDO $pdo,
    int $ownerUserId
): array {
    $choices = [];

    if ($ownerUserId <= 0) {
        return $choices;
    }

    if (tsDocTableExists($pdo, 'users')) {
        $stmt = $pdo->prepare("
            SELECT id, full_name, email, mobile
            FROM users
            WHERE id = ?
            LIMIT 1
        ");
        $stmt->execute([$ownerUserId]);

        if ($owner = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $choices['user:' . (int)$owner['id']] = [
                'key' =>
                    'user:'
                    . (int)$owner['id'],
                'source_user_id' =>
                    (int)$owner['id'],
                'source_family_member_id' => null,
                'full_name' =>
                    (string)$owner['full_name'],
                'relationship' =>
                    'Lead Traveller',
                'date_of_birth' => null,
                'label' =>
                    (string)$owner['full_name']
                    . ' · Account Holder',
            ];
        }
    }

    if (
        tsDocTableExists(
            $pdo,
            'user_family_links'
        )
        && tsDocTableExists(
            $pdo,
            'users'
        )
    ) {
        $stmt = $pdo->prepare("
            SELECT
                l.id,
                l.user_id,
                l.linked_user_id,
                l.relationship,
                u.id AS family_user_id,
                u.full_name,
                u.email,
                u.mobile
            FROM user_family_links l
            JOIN users u
                ON u.id =
                    CASE
                        WHEN l.user_id = ?
                        THEN l.linked_user_id
                        ELSE l.user_id
                    END
            WHERE l.user_id = ?
               OR l.linked_user_id = ?
            ORDER BY u.full_name ASC
        ");
        $stmt->execute([
            $ownerUserId,
            $ownerUserId,
            $ownerUserId
        ]);

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $relationship =
                trim(
                    (string)(
                        $row['relationship']
                        ?? 'Family'
                    )
                );

            if ((int)$row['user_id'] !== $ownerUserId) {
                $relationship =
                    match ($relationship) {
                        'Child' => 'Parent',
                        'Parent' => 'Child',
                        'Grandparent' => 'Grandchild',
                        'Grandchild' => 'Grandparent',
                        default => $relationship,
                    };
            }

            $dob = null;

            if (
                tsDocTableExists(
                    $pdo,
                    'user_travel_profiles'
                )
            ) {
                $s = $pdo->prepare("
                    SELECT date_of_birth
                    FROM user_travel_profiles
                    WHERE user_id = ?
                    LIMIT 1
                ");
                $s->execute([
                    (int)$row['family_user_id']
                ]);
                $dob =
                    $s->fetchColumn()
                    ?: null;
            }

            $key =
                'user:'
                . (int)$row['family_user_id'];

            $choices[$key] = [
                'key' => $key,
                'source_user_id' =>
                    (int)$row['family_user_id'],
                'source_family_member_id' => null,
                'full_name' =>
                    (string)$row['full_name'],
                'relationship' =>
                    $relationship,
                'date_of_birth' =>
                    $dob,
                'label' =>
                    (string)$row['full_name']
                    . ' · '
                    . (
                        $relationship !== ''
                            ? $relationship
                            : 'Family'
                    ),
            ];
        }
    }

    if (
        tsDocTableExists(
            $pdo,
            'user_family_members'
        )
    ) {
        $stmt = $pdo->prepare("
            SELECT *
            FROM user_family_members
            WHERE owner_user_id = ?
              AND status = 'active'
            ORDER BY first_name ASC, last_name ASC, id ASC
        ");
        $stmt->execute([$ownerUserId]);

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $name =
                trim(
                    (string)$row['first_name']
                    . ' '
                    . (string)(
                        $row['last_name']
                        ?? ''
                    )
                );

            $key =
                'member:'
                . (int)$row['id'];

            $choices[$key] = [
                'key' => $key,
                'source_user_id' => null,
                'source_family_member_id' =>
                    (int)$row['id'],
                'full_name' =>
                    $name !== ''
                        ? $name
                        : 'Family Traveller',
                'relationship' =>
                    (string)(
                        $row['relationship']
                        ?? 'Family'
                    ),
                'date_of_birth' =>
                    $row['date_of_birth']
                    ?? null,
                'label' =>
                    (
                        $name !== ''
                            ? $name
                            : 'Family Traveller'
                    )
                    . ' · '
                    . (string)(
                        $row['relationship']
                        ?? 'Family'
                    ),
            ];
        }
    }

    return $choices;
}


function tsDocInvalidateFinalPack(
    PDO $pdo,
    int $bookingId
): void {
    if (
        !tsDocReady($pdo)
        || $bookingId <= 0
    ) {
        return;
    }

    $pdo->prepare("
        UPDATE booking_document_pack_versions
        SET status = 'void'
        WHERE booking_id = ?
          AND status = 'final'
    ")->execute([$bookingId]);

    if (
        tsDocTableExists(
            $pdo,
            'booking_operation_checks'
        )
    ) {
        $pdo->prepare("
            UPDATE booking_operation_checks
            SET
                is_complete = 0,
                note = NULL,
                completed_by_admin_id = NULL,
                completed_at = NULL,
                updated_at = NOW()
            WHERE booking_id = ?
              AND check_key = 'traveller_documents_verified'
        ")->execute([$bookingId]);
    }
}


function tsDocAddTraveller(
    PDO $pdo,
    int $bookingId,
    int $ownerUserId,
    string $createdByType,
    ?int $createdByUserId,
    ?int $createdByAdminId,
    array $input
): array {
    tsDocAssertEditable(
        $pdo,
        $bookingId
    );

    $sourceKey =
        trim(
            (string)(
                $input['source_key']
                ?? ''
            )
        );

    $fullName =
        trim(
            (string)(
                $input['full_name']
                ?? ''
            )
        );

    $relationship =
        trim(
            (string)(
                $input['relationship']
                ?? ''
            )
        );

    $dateOfBirth =
        trim(
            (string)(
                $input['date_of_birth']
                ?? ''
            )
        );

    $nationality =
        trim(
            (string)(
                $input['nationality']
                ?? ''
            )
        );

    $travellerType =
        strtolower(
            trim(
                (string)(
                    $input['traveller_type']
                    ?? 'adult'
                )
            )
        );

    if (
        !in_array(
            $travellerType,
            ['adult','child','infant'],
            true
        )
    ) {
        $travellerType = 'adult';
    }

    $sourceUserId = null;
    $sourceFamilyMemberId = null;

    if ($sourceKey !== '') {
        $choices =
            tsDocHouseholdChoices(
                $pdo,
                $ownerUserId
            );

        if (!isset($choices[$sourceKey])) {
            throw new RuntimeException(
                'Selected customer/family traveller is not available.'
            );
        }

        $source =
            $choices[$sourceKey];

        $sourceUserId =
            $source['source_user_id']
                ?? null;

        $sourceFamilyMemberId =
            $source['source_family_member_id']
                ?? null;

        $fullName =
            (string)$source['full_name'];

        $relationship =
            (string)$source['relationship'];

        if ($dateOfBirth === '') {
            $dateOfBirth =
                (string)(
                    $source['date_of_birth']
                    ?? ''
                );
        }

        if ($sourceUserId) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM booking_travellers
                WHERE booking_id = ?
                  AND source_user_id = ?
                  AND status = 'active'
            ");
            $stmt->execute([
                $bookingId,
                (int)$sourceUserId
            ]);

            if ((int)$stmt->fetchColumn() > 0) {
                throw new RuntimeException(
                    'This customer/family traveller is already on the Booking roster.'
                );
            }
        }

        if ($sourceFamilyMemberId) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM booking_travellers
                WHERE booking_id = ?
                  AND source_family_member_id = ?
                  AND status = 'active'
            ");
            $stmt->execute([
                $bookingId,
                (int)$sourceFamilyMemberId
            ]);

            if ((int)$stmt->fetchColumn() > 0) {
                throw new RuntimeException(
                    'This family traveller is already on the Booking roster.'
                );
            }
        }
    }

    if (mb_strlen($fullName) < 2) {
        throw new RuntimeException(
            'Traveller full name is required.'
        );
    }

    if (
        $dateOfBirth !== ''
        && !preg_match(
            '/^\d{4}-\d{2}-\d{2}$/',
            $dateOfBirth
        )
    ) {
        throw new RuntimeException(
            'Traveller date of birth is invalid.'
        );
    }

    $stmt = $pdo->prepare("
        INSERT INTO booking_travellers
        (
            booking_id,
            source_user_id,
            source_family_member_id,
            traveller_code,
            traveller_type,
            full_name,
            relationship,
            date_of_birth,
            nationality,
            status,
            created_by_type,
            created_by_user_id,
            created_by_admin_id
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?)
    ");

    $stmt->execute([
        $bookingId,
        $sourceUserId
            ? (int)$sourceUserId
            : null,
        $sourceFamilyMemberId
            ? (int)$sourceFamilyMemberId
            : null,
        tsDocTravellerCode(
            $bookingId
        ),
        $travellerType,
        mb_substr(
            $fullName,
            0,
            190
        ),
        $relationship !== ''
            ? mb_substr(
                $relationship,
                0,
                80
            )
            : null,
        $dateOfBirth !== ''
            ? $dateOfBirth
            : null,
        $nationality !== ''
            ? mb_substr(
                $nationality,
                0,
                100
            )
            : null,
        in_array(
            $createdByType,
            ['system','customer','admin'],
            true
        )
            ? $createdByType
            : 'admin',
        $createdByUserId
            ? $createdByUserId
            : null,
        $createdByAdminId
            ? $createdByAdminId
            : null
    ]);

    $travellerId =
        (int)$pdo->lastInsertId();

    tsDocEnsurePrimaryRequirement(
        $pdo,
        $bookingId,
        $travellerId,
        $createdByAdminId
    );

    tsDocInvalidateFinalPack(
        $pdo,
        $bookingId
    );

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_travellers
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$travellerId]);

    return
        $stmt->fetch(PDO::FETCH_ASSOC)
        ?: [];
}



function tsDocCancelTraveller(
    PDO $pdo,
    int $bookingId,
    int $travellerId
): void {
    tsDocAssertEditable(
        $pdo,
        $bookingId
    );

    $traveller =
        tsDocTraveller(
            $pdo,
            $bookingId,
            $travellerId
        );

    if (!$traveller) {
        throw new RuntimeException(
            'Booking traveller was not found.'
        );
    }

    if (
        (string)$traveller['traveller_type']
        === 'lead'
    ) {
        throw new RuntimeException(
            'Lead Traveller cannot be removed from the Booking roster.'
        );
    }

    $pdo->prepare("
        UPDATE booking_travellers
        SET
            status = 'cancelled',
            updated_at = NOW()
        WHERE id = ?
          AND booking_id = ?
    ")->execute([
        $travellerId,
        $bookingId
    ]);

    $pdo->prepare("
        UPDATE booking_document_requirements
        SET
            is_required = 0,
            status = 'waived',
            note =
                CASE
                    WHEN COALESCE(note,'') = ''
                    THEN 'Traveller removed from active Booking roster.'
                    ELSE note
                END,
            updated_at = NOW()
        WHERE booking_id = ?
          AND traveller_id = ?
    ")->execute([
        $bookingId,
        $travellerId
    ]);

    tsDocInvalidateFinalPack(
        $pdo,
        $bookingId
    );
}


function tsDocTraveller(
    PDO $pdo,
    int $bookingId,
    int $travellerId
): ?array {
    if (
        !tsDocReady($pdo)
        || $travellerId <= 0
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_travellers
        WHERE id = ?
          AND booking_id = ?
        LIMIT 1
    ");
    $stmt->execute([
        $travellerId,
        $bookingId
    ]);

    $row =
        $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function tsDocStorageDirectory(
    int $bookingId
): string {
    $base =
        __DIR__
        . '/uploads/booking-documents/';

    $dir =
        $base
        . 'booking_'
        . $bookingId
        . '/';

    if (
        !is_dir($dir)
        && !mkdir(
            $dir,
            0755,
            true
        )
        && !is_dir($dir)
    ) {
        throw new RuntimeException(
            'Unable to create Booking document storage.'
        );
    }

    /*
     * Apache protection. Documents are served only through
     * booking-document-file.php after authorization.
     */
    $htaccess =
        $base
        . '.htaccess';

    if (!is_file($htaccess)) {
        @file_put_contents(
            $htaccess,
            "Options -Indexes\n"
            . "<IfModule mod_authz_core.c>\n"
            . "Require all denied\n"
            . "</IfModule>\n"
            . "<IfModule !mod_authz_core.c>\n"
            . "Deny from all\n"
            . "</IfModule>\n"
        );
    }

    if (!is_file($base . 'index.html')) {
        @file_put_contents(
            $base . 'index.html',
            ''
        );
    }

    return $dir;
}


function tsDocSaveUpload(
    array $file,
    int $bookingId
): array {
    if (
        ($file['error'] ?? UPLOAD_ERR_NO_FILE)
        === UPLOAD_ERR_NO_FILE
    ) {
        throw new RuntimeException(
            'Please choose a document file.'
        );
    }

    if (
        ($file['error'] ?? UPLOAD_ERR_NO_FILE)
        !== UPLOAD_ERR_OK
    ) {
        throw new RuntimeException(
            'Document upload failed.'
        );
    }

    $size =
        (int)(
            $file['size']
            ?? 0
        );

    if (
        $size <= 0
        || $size > 8 * 1024 * 1024
    ) {
        throw new RuntimeException(
            'Document file must be 8 MB or smaller.'
        );
    }

    if (
        !is_uploaded_file(
            (string)$file['tmp_name']
        )
    ) {
        throw new RuntimeException(
            'Invalid document upload.'
        );
    }

    $finfo =
        new finfo(
            FILEINFO_MIME_TYPE
        );

    $mime =
        (string)$finfo->file(
            (string)$file['tmp_name']
        );

    $allowed = [
        'application/pdf' => 'pdf',
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];

    if (!isset($allowed[$mime])) {
        throw new RuntimeException(
            'Only PDF, JPG, PNG and WEBP document files are allowed.'
        );
    }

    $dir =
        tsDocStorageDirectory(
            $bookingId
        );

    $extension =
        $allowed[$mime];

    $fileName =
        'booking_'
        . $bookingId
        . '_'
        . bin2hex(
            random_bytes(16)
        )
        . '.'
        . $extension;

    $destination =
        $dir
        . $fileName;

    if (
        !move_uploaded_file(
            (string)$file['tmp_name'],
            $destination
        )
    ) {
        throw new RuntimeException(
            'Unable to save Booking document.'
        );
    }

    return [
        'path' =>
            'uploads/booking-documents/booking_'
            . $bookingId
            . '/'
            . $fileName,
        'original_name' =>
            mb_substr(
                basename(
                    (string)(
                        $file['name']
                        ?? ('document.' . $extension)
                    )
                ),
                0,
                255
            ),
        'mime_type' => $mime,
        'file_size' => $size,
    ];
}


function tsDocSafeExistingPath(
    string $relativePath,
    string $requiredPrefix
): ?string {
    $relativePath =
        ltrim(
            trim($relativePath),
            '/'
        );

    $requiredPrefix =
        trim(
            $requiredPrefix,
            '/'
        )
        . '/';

    if (
        $relativePath === ''
        || !str_starts_with(
            $relativePath,
            $requiredPrefix
        )
        || str_contains(
            $relativePath,
            '..'
        )
    ) {
        return null;
    }

    $full =
        realpath(
            __DIR__
            . '/'
            . $relativePath
        );

    $base =
        realpath(
            __DIR__
            . '/'
            . rtrim(
                $requiredPrefix,
                '/'
            )
        );

    if (
        !$full
        || !$base
        || !is_file($full)
    ) {
        return null;
    }

    $basePrefix =
        rtrim(
            $base,
            DIRECTORY_SEPARATOR
        )
        . DIRECTORY_SEPARATOR;

    if (
        !str_starts_with(
            $full,
            $basePrefix
        )
    ) {
        return null;
    }

    return $full;
}


function tsDocCopyProfileVaultFile(
    array $profileDocument,
    int $bookingId
): array {
    $sourceUserId =
        max(
            0,
            (int)(
                $profileDocument['user_id']
                ?? 0
            )
        );

    $sourcePath =
        tsDocSafeExistingPath(
            (string)(
                $profileDocument['file_path']
                ?? ''
            ),
            'uploads/traveller-documents/user_'
            . $sourceUserId
            . '/'
        );

    if (!$sourcePath) {
        throw new RuntimeException(
            'The selected profile document file is no longer available.'
        );
    }

    $mime =
        trim(
            (string)(
                $profileDocument['mime_type']
                ?? ''
            )
        );

    $extension =
        match ($mime) {
            'application/pdf' => 'pdf',
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            default =>
                strtolower(
                    pathinfo(
                        $sourcePath,
                        PATHINFO_EXTENSION
                    )
                ),
        };

    if (
        !in_array(
            $extension,
            ['pdf','jpg','jpeg','png','webp'],
            true
        )
    ) {
        throw new RuntimeException(
            'Profile document format is not supported by Booking Document Center.'
        );
    }

    if ($extension === 'jpeg') {
        $extension = 'jpg';
    }

    $dir =
        tsDocStorageDirectory(
            $bookingId
        );

    $fileName =
        'vault_'
        . $bookingId
        . '_'
        . bin2hex(
            random_bytes(16)
        )
        . '.'
        . $extension;

    $destination =
        $dir
        . $fileName;

    if (
        !copy(
            $sourcePath,
            $destination
        )
    ) {
        throw new RuntimeException(
            'Unable to copy profile document into this Booking.'
        );
    }

    return [
        'path' =>
            'uploads/booking-documents/booking_'
            . $bookingId
            . '/'
            . $fileName,
        'original_name' =>
            mb_substr(
                (string)(
                    $profileDocument['original_name']
                    ?? ('document.' . $extension)
                ),
                0,
                255
            ),
        'mime_type' =>
            $mime !== ''
                ? $mime
                : null,
        'file_size' =>
            (int)(
                @filesize(
                    $destination
                )
                ?: (
                    $profileDocument['file_size']
                    ?? 0
                )
            ),
    ];
}


function tsDocDateOrNull(string $value): ?string
{
    $value =
        trim($value);

    if ($value === '') {
        return null;
    }

    $date =
        DateTime::createFromFormat(
            'Y-m-d',
            $value
        );

    if (
        !$date
        || $date->format('Y-m-d') !== $value
    ) {
        return null;
    }

    return $value;
}


function tsDocAddUploadedDocument(
    PDO $pdo,
    int $bookingId,
    string $sourceType,
    ?int $createdByUserId,
    ?int $createdByAdminId,
    array $input,
    array $file
): array {
    tsDocAssertEditable(
        $pdo,
        $bookingId
    );

    $travellerId =
        max(
            0,
            (int)(
                $input['traveller_id']
                ?? 0
            )
        );

    if (
        $travellerId > 0
        && !tsDocTraveller(
            $pdo,
            $bookingId,
            $travellerId
        )
    ) {
        throw new RuntimeException(
            'Selected Booking traveller was not found.'
        );
    }

    $documentType =
        trim(
            (string)(
                $input['document_type']
                ?? ''
            )
        );

    $allTypes =
        array_merge(
            tsDocTypes()['identity'],
            tsDocTypes()['travel']
        );

    if (
        !in_array(
            $documentType,
            $allTypes,
            true
        )
    ) {
        throw new RuntimeException(
            'Select a valid document type.'
        );
    }

    $documentNumber =
        trim(
            (string)(
                $input['document_number']
                ?? ''
            )
        );

    $issuingCountry =
        trim(
            (string)(
                $input['issuing_country']
                ?? ''
            )
        );

    $issueRaw =
        trim(
            (string)(
                $input['issue_date']
                ?? ''
            )
        );

    $expiryRaw =
        trim(
            (string)(
                $input['expiry_date']
                ?? ''
            )
        );

    $issueDate =
        tsDocDateOrNull(
            $issueRaw
        );

    $expiryDate =
        tsDocDateOrNull(
            $expiryRaw
        );

    if (
        $issueRaw !== ''
        && $issueDate === null
    ) {
        throw new RuntimeException(
            'Document issue date is invalid.'
        );
    }

    if (
        $expiryRaw !== ''
        && $expiryDate === null
    ) {
        throw new RuntimeException(
            'Document expiry date is invalid.'
        );
    }

    if (
        $issueDate
        && $expiryDate
        && $expiryDate < $issueDate
    ) {
        throw new RuntimeException(
            'Document expiry date cannot be before issue date.'
        );
    }

    $notes =
        trim(
            (string)(
                $input['notes']
                ?? ''
            )
        );

    if (
        mb_strlen($documentNumber) > 150
        || mb_strlen($issuingCountry) > 100
        || mb_strlen($notes) > 1000
    ) {
        throw new RuntimeException(
            'One or more document details are too long.'
        );
    }

    $upload =
        tsDocSaveUpload(
            $file,
            $bookingId
        );

    $sourceType =
        in_array(
            $sourceType,
            ['customer_upload','admin_upload'],
            true
        )
            ? $sourceType
            : 'admin_upload';

    $customerVisible =
        !empty(
            $input['customer_visible']
        )
        || $sourceType === 'customer_upload'
            ? 1
            : 0;

    $stmt = $pdo->prepare("
        INSERT INTO booking_travel_documents
        (
            booking_id,
            traveller_id,
            source_user_document_id,
            document_category,
            document_type,
            document_number,
            issuing_country,
            issue_date,
            expiry_date,
            file_path,
            original_name,
            mime_type,
            file_size,
            source_type,
            verification_status,
            customer_visible,
            created_by_user_id,
            created_by_admin_id
        )
        VALUES
        (?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)
    ");

    $stmt->execute([
        $bookingId,
        $travellerId,
        tsDocCategory(
            $documentType
        ),
        $documentType,
        $documentNumber !== ''
            ? $documentNumber
            : null,
        $issuingCountry !== ''
            ? $issuingCountry
            : null,
        $issueDate,
        $expiryDate,
        $upload['path'],
        $upload['original_name'],
        $upload['mime_type'],
        $upload['file_size'],
        $sourceType,
        $customerVisible,
        $createdByUserId
            ? $createdByUserId
            : null,
        $createdByAdminId
            ? $createdByAdminId
            : null
    ]);

    $id =
        (int)$pdo->lastInsertId();

    tsDocRefreshRequirements(
        $pdo,
        $bookingId
    );

    tsDocInvalidateFinalPack(
        $pdo,
        $bookingId
    );

    return
        tsDocDocument(
            $pdo,
            $bookingId,
            $id
        )
        ?: [];
}


function tsDocVaultDocuments(
    PDO $pdo,
    int $sourceUserId
): array {
    if (
        $sourceUserId <= 0
        || !tsDocTableExists(
            $pdo,
            'user_travel_documents'
        )
    ) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM user_travel_documents
        WHERE user_id = ?
        ORDER BY
            CASE
                WHEN document_category = 'identity'
                THEN 0
                ELSE 1
            END,
            document_type ASC,
            created_at DESC
    ");
    $stmt->execute([$sourceUserId]);

    return
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        ?: [];
}


function tsDocImportVaultDocument(
    PDO $pdo,
    int $bookingId,
    int $travellerId,
    int $profileDocumentId,
    ?int $createdByUserId,
    ?int $createdByAdminId
): array {
    tsDocAssertEditable(
        $pdo,
        $bookingId
    );

    $traveller =
        tsDocTraveller(
            $pdo,
            $bookingId,
            $travellerId
        );

    if (!$traveller) {
        throw new RuntimeException(
            'Booking traveller was not found.'
        );
    }

    $sourceUserId =
        max(
            0,
            (int)(
                $traveller['source_user_id']
                ?? 0
            )
        );

    if (
        $sourceUserId <= 0
        || !tsDocTableExists(
            $pdo,
            'user_travel_documents'
        )
    ) {
        throw new RuntimeException(
            'This traveller is not linked to a customer profile document vault.'
        );
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM user_travel_documents
        WHERE id = ?
          AND user_id = ?
        LIMIT 1
    ");
    $stmt->execute([
        $profileDocumentId,
        $sourceUserId
    ]);

    $profileDocument =
        $stmt->fetch(PDO::FETCH_ASSOC)
        ?: null;

    if (!$profileDocument) {
        throw new RuntimeException(
            'Profile document was not found.'
        );
    }

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM booking_travel_documents
        WHERE booking_id = ?
          AND traveller_id = ?
          AND source_user_document_id = ?
          AND verification_status <> 'archived'
    ");
    $stmt->execute([
        $bookingId,
        $travellerId,
        $profileDocumentId
    ]);

    if ((int)$stmt->fetchColumn() > 0) {
        throw new RuntimeException(
            'This profile document is already in the Booking file center.'
        );
    }

    $copy =
        tsDocCopyProfileVaultFile(
            $profileDocument,
            $bookingId
        );

    $stmt = $pdo->prepare("
        INSERT INTO booking_travel_documents
        (
            booking_id,
            traveller_id,
            source_user_document_id,
            document_category,
            document_type,
            document_number,
            issuing_country,
            issue_date,
            expiry_date,
            file_path,
            original_name,
            mime_type,
            file_size,
            source_type,
            verification_status,
            customer_visible,
            created_by_user_id,
            created_by_admin_id
        )
        VALUES
        (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'profile_vault', 'pending', 1, ?, ?)
    ");

    $stmt->execute([
        $bookingId,
        $travellerId,
        $profileDocumentId,
        (string)(
            $profileDocument['document_category']
            ?: tsDocCategory(
                (string)$profileDocument['document_type']
            )
        ),
        (string)$profileDocument['document_type'],
        $profileDocument['document_number']
            ?: null,
        $profileDocument['issuing_country']
            ?: null,
        $profileDocument['issue_date']
            ?: null,
        $profileDocument['expiry_date']
            ?: null,
        $copy['path'],
        $copy['original_name'],
        $copy['mime_type'],
        $copy['file_size'],
        $createdByUserId
            ? $createdByUserId
            : null,
        $createdByAdminId
            ? $createdByAdminId
            : null
    ]);

    $id =
        (int)$pdo->lastInsertId();

    tsDocRefreshRequirements(
        $pdo,
        $bookingId
    );

    tsDocInvalidateFinalPack(
        $pdo,
        $bookingId
    );

    return
        tsDocDocument(
            $pdo,
            $bookingId,
            $id
        )
        ?: [];
}


function tsDocDocument(
    PDO $pdo,
    int $bookingId,
    int $documentId
): ?array {
    if (
        !tsDocReady($pdo)
        || $documentId <= 0
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT
            d.*,
            t.full_name AS traveller_name,
            t.traveller_type
        FROM booking_travel_documents d
        LEFT JOIN booking_travellers t
            ON t.id = d.traveller_id
        WHERE d.id = ?
          AND d.booking_id = ?
        LIMIT 1
    ");
    $stmt->execute([
        $documentId,
        $bookingId
    ]);

    $row =
        $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function tsDocDocuments(
    PDO $pdo,
    int $bookingId,
    bool $includeArchived = false
): array {
    if (
        !tsDocReady($pdo)
        || $bookingId <= 0
    ) {
        return [];
    }

    $sql = "
        SELECT
            d.*,
            t.full_name AS traveller_name,
            t.traveller_type
        FROM booking_travel_documents d
        LEFT JOIN booking_travellers t
            ON t.id = d.traveller_id
        WHERE d.booking_id = ?
    ";

    if (!$includeArchived) {
        $sql .= "
          AND d.verification_status <> 'archived'
        ";
    }

    $sql .= "
        ORDER BY
            CASE
                WHEN d.traveller_id = 0
                THEN 1
                ELSE 0
            END,
            t.full_name ASC,
            d.document_type ASC,
            d.created_at DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$bookingId]);

    return
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        ?: [];
}


function tsDocRequirementMatches(
    string $requirementType,
    string $documentType
): bool {
    if (
        $requirementType
        === 'Primary Travel ID'
    ) {
        return
            in_array(
                $documentType,
                [
                    'Passport',
                    'Aadhaar Card',
                    'Voter ID',
                    'Driving Licence',
                    'National ID',
                ],
                true
            );
    }

    return
        strcasecmp(
            $requirementType,
            $documentType
        ) === 0;
}


function tsDocValidity(
    array $document,
    array $booking
): array {
    $expiry =
        trim(
            (string)(
                $document['expiry_date']
                ?? ''
            )
        );

    if ($expiry === '') {
        if (
            (string)(
                $document['document_type']
                ?? ''
            ) === 'Passport'
        ) {
            return [
                'state' => 'passport_expiry_missing',
                'blocking' => true,
                'warning' => false,
                'message' =>
                    'Passport expiry date is required before verification.',
            ];
        }

        return [
            'state' => 'no_expiry',
            'blocking' => false,
            'warning' => false,
            'message' => 'No expiry date recorded.',
        ];
    }

    $expiryTs =
        strtotime($expiry);

    if (!$expiryTs) {
        return [
            'state' => 'invalid_date',
            'blocking' => true,
            'warning' => false,
            'message' => 'Expiry date is invalid.',
        ];
    }

    $today =
        strtotime(
            date('Y-m-d')
        );

    if ($expiryTs < $today) {
        return [
            'state' => 'expired',
            'blocking' => true,
            'warning' => false,
            'message' =>
                'Document expired on '
                . date(
                    'd M Y',
                    $expiryTs
                )
                . '.',
        ];
    }

    $travelDate =
        trim(
            (string)(
                $booking['travel_date']
                ?? ''
            )
        );

    $travelTs =
        $travelDate !== ''
            ? strtotime($travelDate)
            : false;

    if (
        $travelTs
        && $expiryTs < $travelTs
    ) {
        return [
            'state' => 'expires_before_travel',
            'blocking' => true,
            'warning' => false,
            'message' =>
                'Document expires before departure ('
                . date(
                    'd M Y',
                    $expiryTs
                )
                . ').',
        ];
    }

    if (
        $travelTs
        && (string)(
            $document['document_type']
            ?? ''
        ) === 'Passport'
    ) {
        $settingsPdo =
            $GLOBALS['pdo']
            ?? null;

        $passportValidityMonths =
            (
                $settingsPdo instanceof PDO
                && function_exists('tsSystemSettingInt')
            )
                ? tsSystemSettingInt(
                    $settingsPdo,
                    'ops_passport_validity_months',
                    6
                )
                : 6;

        $requiredValidity =
            strtotime(
                '+'
                . $passportValidityMonths
                . ' months',
                $travelTs
            );

        if (
            $passportValidityMonths > 0
            && $requiredValidity
            && $expiryTs < $requiredValidity
        ) {
            return [
                'state' => 'passport_validity_warning',
                'blocking' => false,
                'warning' => true,
                'message' =>
                    'Passport has less than '
                    . $passportValidityMonths
                    . ' month'
                    . ($passportValidityMonths === 1 ? '' : 's')
                    . ' validity after departure. Destination rules vary; Admin must verify the applicable rule.',
            ];
        }
    }

    return [
        'state' => 'valid',
        'blocking' => false,
        'warning' => false,
        'message' =>
            'Valid until '
            . date(
                'd M Y',
                $expiryTs
            )
            . '.',
    ];
}


function tsDocDocumentCanSatisfyRequirement(
    array $document,
    array $booking,
    string $requirementType
): bool {
    if (
        (string)(
            $document['verification_status']
            ?? ''
        ) !== 'verified'
    ) {
        return false;
    }

    if (
        !tsDocRequirementMatches(
            $requirementType,
            (string)(
                $document['document_type']
                ?? ''
            )
        )
    ) {
        return false;
    }

    $validity =
        tsDocValidity(
            $document,
            $booking
        );

    return
        empty(
            $validity['blocking']
        );
}


function tsDocRequirements(
    PDO $pdo,
    int $bookingId
): array {
    if (
        !tsDocReady($pdo)
        || $bookingId <= 0
    ) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT
            r.*,
            t.full_name AS traveller_name,
            t.traveller_type
        FROM booking_document_requirements r
        LEFT JOIN booking_travellers t
            ON t.id = r.traveller_id
        WHERE r.booking_id = ?
        ORDER BY
            CASE
                WHEN r.traveller_id = 0
                THEN 1
                ELSE 0
            END,
            t.full_name ASC,
            r.sort_order ASC,
            r.id ASC
    ");
    $stmt->execute([$bookingId]);

    return
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        ?: [];
}


function tsDocRefreshRequirements(
    PDO $pdo,
    int $bookingId
): void {
    if (
        !tsDocReady($pdo)
        || $bookingId <= 0
    ) {
        return;
    }

    $booking =
        tsDocBooking(
            $pdo,
            $bookingId
        );

    $documents =
        tsDocDocuments(
            $pdo,
            $bookingId
        );

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_document_requirements
        WHERE booking_id = ?
        ORDER BY id ASC
    ");
    $stmt->execute([$bookingId]);

    $requirements =
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        ?: [];

    $update = $pdo->prepare("
        UPDATE booking_document_requirements
        SET
            status = ?,
            updated_at = NOW()
        WHERE id = ?
    ");

    foreach ($requirements as $requirement) {
        if (
            (string)$requirement['status']
            === 'waived'
        ) {
            continue;
        }

        $matching = [];

        foreach ($documents as $document) {
            if (
                (int)$document['traveller_id']
                !== (int)$requirement['traveller_id']
            ) {
                continue;
            }

            if (
                tsDocRequirementMatches(
                    (string)$requirement['document_type'],
                    (string)$document['document_type']
                )
            ) {
                $matching[] =
                    $document;
            }
        }

        $status = 'required';

        foreach ($matching as $document) {
            if (
                tsDocDocumentCanSatisfyRequirement(
                    $document,
                    $booking,
                    (string)$requirement['document_type']
                )
            ) {
                $status = 'verified';
                break;
            }
        }

        if ($status !== 'verified') {
            foreach ($matching as $document) {
                if (
                    (string)$document['verification_status']
                    === 'pending'
                ) {
                    $status = 'uploaded';
                    break;
                }
            }
        }

        if (
            $status === 'required'
            && $matching
        ) {
            $allRejected = true;

            foreach ($matching as $document) {
                if (
                    !in_array(
                        (string)$document['verification_status'],
                        ['rejected','archived'],
                        true
                    )
                ) {
                    $allRejected = false;
                    break;
                }
            }

            if ($allRejected) {
                $status = 'rejected';
            }
        }

        if (
            $status
            !== (string)$requirement['status']
        ) {
            $update->execute([
                $status,
                (int)$requirement['id']
            ]);
        }
    }
}


function tsDocAddRequirement(
    PDO $pdo,
    int $bookingId,
    int $travellerId,
    string $documentType,
    string $note,
    int $adminId
): void {
    tsDocAssertEditable(
        $pdo,
        $bookingId
    );

    if (
        $travellerId > 0
        && !tsDocTraveller(
            $pdo,
            $bookingId,
            $travellerId
        )
    ) {
        throw new RuntimeException(
            'Selected traveller was not found.'
        );
    }

    if (
        !in_array(
            $documentType,
            tsDocRequirementTypes(),
            true
        )
    ) {
        throw new RuntimeException(
            'Select a valid document requirement.'
        );
    }

    $stmt = $pdo->prepare("
        INSERT INTO booking_document_requirements
        (
            booking_id,
            traveller_id,
            document_type,
            is_required,
            status,
            note,
            sort_order,
            created_by_admin_id
        )
        VALUES (?, ?, ?, 1, 'required', ?, 50, ?)
        ON DUPLICATE KEY UPDATE
            is_required = 1,
            note = VALUES(note),
            status =
                CASE
                    WHEN status = 'waived'
                    THEN 'required'
                    ELSE status
                END,
            waived_by_admin_id = NULL,
            waived_at = NULL,
            updated_at = NOW()
    ");

    $stmt->execute([
        $bookingId,
        $travellerId,
        $documentType,
        trim($note) !== ''
            ? mb_substr(
                trim($note),
                0,
                1000
            )
            : null,
        $adminId > 0
            ? $adminId
            : null
    ]);

    tsDocRefreshRequirements(
        $pdo,
        $bookingId
    );

    tsDocInvalidateFinalPack(
        $pdo,
        $bookingId
    );
}


function tsDocWaiveRequirement(
    PDO $pdo,
    int $bookingId,
    int $requirementId,
    int $adminId,
    string $note
): void {
    tsDocAssertEditable(
        $pdo,
        $bookingId
    );

    $note =
        trim($note);

    if ($note === '') {
        throw new RuntimeException(
            'Enter a waiver reason.'
        );
    }

    $stmt = $pdo->prepare("
        UPDATE booking_document_requirements
        SET
            status = 'waived',
            note = ?,
            waived_by_admin_id = ?,
            waived_at = NOW(),
            updated_at = NOW()
        WHERE id = ?
          AND booking_id = ?
    ");

    $stmt->execute([
        mb_substr(
            $note,
            0,
            1000
        ),
        $adminId > 0
            ? $adminId
            : null,
        $requirementId,
        $bookingId
    ]);

    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException(
            'Document requirement could not be waived.'
        );
    }

    tsDocInvalidateFinalPack(
        $pdo,
        $bookingId
    );
}


function tsDocRestoreRequirement(
    PDO $pdo,
    int $bookingId,
    int $requirementId
): void {
    tsDocAssertEditable(
        $pdo,
        $bookingId
    );

    $stmt = $pdo->prepare("
        UPDATE booking_document_requirements
        SET
            status = 'required',
            waived_by_admin_id = NULL,
            waived_at = NULL,
            updated_at = NOW()
        WHERE id = ?
          AND booking_id = ?
          AND status = 'waived'
    ");

    $stmt->execute([
        $requirementId,
        $bookingId
    ]);

    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException(
            'Document requirement could not be restored.'
        );
    }

    tsDocRefreshRequirements(
        $pdo,
        $bookingId
    );

    tsDocInvalidateFinalPack(
        $pdo,
        $bookingId
    );
}


function tsDocVerifyDocument(
    PDO $pdo,
    int $bookingId,
    int $documentId,
    int $adminId,
    string $note = ''
): void {
    tsDocAssertEditable(
        $pdo,
        $bookingId
    );

    $document =
        tsDocDocument(
            $pdo,
            $bookingId,
            $documentId
        );

    if (
        !$document
        || (string)$document['verification_status']
            === 'archived'
    ) {
        throw new RuntimeException(
            'Document was not found.'
        );
    }

    $booking =
        tsDocBooking(
            $pdo,
            $bookingId
        );

    $validity =
        tsDocValidity(
            $document,
            $booking
        );

    if (!empty($validity['blocking'])) {
        throw new RuntimeException(
            (string)$validity['message']
            . ' Upload a valid replacement before verification.'
        );
    }

    $note =
        trim($note);

    if (
        !empty($validity['warning'])
        && $note === ''
    ) {
        throw new RuntimeException(
            (string)$validity['message']
            . ' Add a verification note confirming the destination-specific validity rule was checked.'
        );
    }

    $stmt = $pdo->prepare("
        UPDATE booking_travel_documents
        SET
            verification_status = 'verified',
            verification_note = ?,
            verified_by_admin_id = ?,
            verified_at = NOW(),
            updated_at = NOW()
        WHERE id = ?
          AND booking_id = ?
          AND verification_status <> 'archived'
    ");

    $stmt->execute([
        $note !== ''
            ? mb_substr(
                $note,
                0,
                1000
            )
            : null,
        $adminId > 0
            ? $adminId
            : null,
        $documentId,
        $bookingId
    ]);

    tsDocRefreshRequirements(
        $pdo,
        $bookingId
    );

    tsDocInvalidateFinalPack(
        $pdo,
        $bookingId
    );
}


function tsDocRejectDocument(
    PDO $pdo,
    int $bookingId,
    int $documentId,
    int $adminId,
    string $note
): void {
    tsDocAssertEditable(
        $pdo,
        $bookingId
    );

    $note =
        trim($note);

    if ($note === '') {
        throw new RuntimeException(
            'Enter a customer-safe rejection reason.'
        );
    }

    $stmt = $pdo->prepare("
        UPDATE booking_travel_documents
        SET
            verification_status = 'rejected',
            verification_note = ?,
            verified_by_admin_id = ?,
            verified_at = NOW(),
            updated_at = NOW()
        WHERE id = ?
          AND booking_id = ?
          AND verification_status <> 'archived'
    ");

    $stmt->execute([
        mb_substr(
            $note,
            0,
            1000
        ),
        $adminId > 0
            ? $adminId
            : null,
        $documentId,
        $bookingId
    ]);

    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException(
            'Document could not be rejected.'
        );
    }

    tsDocRefreshRequirements(
        $pdo,
        $bookingId
    );

    tsDocInvalidateFinalPack(
        $pdo,
        $bookingId
    );
}


function tsDocArchiveDocument(
    PDO $pdo,
    int $bookingId,
    int $documentId,
    ?int $customerUserId = null
): void {
    tsDocAssertEditable(
        $pdo,
        $bookingId
    );

    $document =
        tsDocDocument(
            $pdo,
            $bookingId,
            $documentId
        );

    if (!$document) {
        throw new RuntimeException(
            'Document was not found.'
        );
    }

    if ($customerUserId) {
        if (
            (int)(
                $document['created_by_user_id']
                ?? 0
            ) !== $customerUserId
        ) {
            throw new RuntimeException(
                'You can remove only documents you uploaded to this Booking.'
            );
        }

        if (
            (string)$document['verification_status']
            === 'verified'
        ) {
            throw new RuntimeException(
                'A verified document cannot be removed by the customer. Contact TRAVSCOPE if it needs replacement.'
            );
        }
    }

    $pdo->prepare("
        UPDATE booking_travel_documents
        SET
            verification_status = 'archived',
            updated_at = NOW()
        WHERE id = ?
          AND booking_id = ?
    ")->execute([
        $documentId,
        $bookingId
    ]);

    tsDocRefreshRequirements(
        $pdo,
        $bookingId
    );

    tsDocInvalidateFinalPack(
        $pdo,
        $bookingId
    );
}


function tsDocLatestFinalVoucher(
    PDO $pdo,
    int $bookingId
): ?array {
    if (
        !tsDocTableExists(
            $pdo,
            'booking_voucher_versions'
        )
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT
            id,
            version_number,
            voucher_code,
            finalized_at,
            created_at
        FROM booking_voucher_versions
        WHERE booking_id = ?
          AND status = 'final'
        ORDER BY version_number DESC, id DESC
        LIMIT 1
    ");
    $stmt->execute([$bookingId]);

    $row =
        $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function tsDocLatestFinalInvoice(
    PDO $pdo,
    int $bookingId,
    float $currentTotal
): ?array {
    if (
        !tsDocTableExists(
            $pdo,
            'booking_invoice_versions'
        )
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT
            id,
            version_number,
            invoice_code,
            booking_total,
            finalized_at,
            created_at
        FROM booking_invoice_versions
        WHERE booking_id = ?
          AND status = 'final'
          AND ABS(booking_total - ?) <= 0.01
        ORDER BY version_number DESC, id DESC
        LIMIT 1
    ");
    $stmt->execute([
        $bookingId,
        $currentTotal
    ]);

    $row =
        $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function tsDocCurrentFingerprint(
    PDO $pdo,
    int $bookingId
): string {
    if (!tsDocReady($pdo)) {
        return '';
    }

    tsDocRefreshRequirements(
        $pdo,
        $bookingId
    );

    $booking =
        tsDocBooking(
            $pdo,
            $bookingId
        );

    $travellers =
        tsDocTravellers(
            $pdo,
            $bookingId
        );

    $documents =
        array_values(
            array_filter(
                tsDocDocuments(
                    $pdo,
                    $bookingId
                ),
                static fn($document) =>
                    (string)(
                        $document['verification_status']
                        ?? ''
                    ) === 'verified'
                    && !empty(
                        $document['customer_visible']
                    )
            )
        );

    $requirements =
        tsDocRequirements(
            $pdo,
            $bookingId
        );

    $voucher =
        tsDocLatestFinalVoucher(
            $pdo,
            $bookingId
        );

    $payload = [
        'travel_date' =>
            $booking['travel_date']
            ?? null,
        'travellers' =>
            array_map(
                static fn($row) => [
                    'id' =>
                        (int)$row['id'],
                    'type' =>
                        (string)$row['traveller_type'],
                    'name' =>
                        (string)$row['full_name'],
                    'dob' =>
                        $row['date_of_birth']
                        ?? null,
                    'nationality' =>
                        $row['nationality']
                        ?? null,
                ],
                $travellers
            ),
        'documents' =>
            array_map(
                static fn($row) => [
                    'id' =>
                        (int)$row['id'],
                    'traveller_id' =>
                        (int)$row['traveller_id'],
                    'type' =>
                        (string)$row['document_type'],
                    'expiry' =>
                        $row['expiry_date']
                        ?? null,
                    'file_size' =>
                        (int)$row['file_size'],
                    'updated_at' =>
                        (string)$row['updated_at'],
                ],
                $documents
            ),
        'requirements' =>
            array_map(
                static fn($row) => [
                    'id' =>
                        (int)$row['id'],
                    'traveller_id' =>
                        (int)$row['traveller_id'],
                    'type' =>
                        (string)$row['document_type'],
                    'required' =>
                        (int)$row['is_required'],
                    'status' =>
                        (string)$row['status'],
                ],
                $requirements
            ),
        'voucher_id' =>
            $voucher
                ? (int)$voucher['id']
                : null,
    ];

    return
        hash(
            'sha256',
            json_encode(
                $payload,
                JSON_UNESCAPED_UNICODE
                | JSON_UNESCAPED_SLASHES
            )
        );
}


function tsDocPackReadiness(
    PDO $pdo,
    int $bookingId
): array {
    if (!tsDocReady($pdo)) {
        return [
            'ready' => false,
            'reasons' => [
                'Document Center SQL is not installed.',
            ],
        ];
    }

    tsDocRefreshRequirements(
        $pdo,
        $bookingId
    );

    $booking =
        tsDocBooking(
            $pdo,
            $bookingId
        );

    $travellers =
        tsDocTravellers(
            $pdo,
            $bookingId
        );

    $requirements =
        tsDocRequirements(
            $pdo,
            $bookingId
        );

    $documents =
        tsDocDocuments(
            $pdo,
            $bookingId
        );

    $expected =
        tsDocExpectedTravellerCount(
            $booking
        );

    $activeCount =
        count($travellers);

    $missingRequirements =
        array_values(
            array_filter(
                $requirements,
                static fn($row) =>
                    !empty(
                        $row['is_required']
                    )
                    && !in_array(
                        (string)$row['status'],
                        ['verified','waived'],
                        true
                    )
            )
        );

    $voucher = null;
    $voucherRequired =
        tsDocTableExists(
            $pdo,
            'booking_voucher_versions'
        );

    if ($voucherRequired) {
        $voucher =
            tsDocLatestFinalVoucher(
                $pdo,
                $bookingId
            );
    }

    $validityAlerts = [];

    foreach ($documents as $document) {
        if (
            (string)$document['verification_status']
            !== 'verified'
        ) {
            continue;
        }

        $validity =
            tsDocValidity(
                $document,
                $booking
            );

        if (
            !empty($validity['blocking'])
            || !empty($validity['warning'])
        ) {
            $validityAlerts[] = [
                'document' =>
                    $document,
                'validity' =>
                    $validity,
            ];
        }
    }

    $reasons = [];

    if (
        strtolower(
            (string)(
                $booking['booking_status']
                ?? ''
            )
        ) === 'cancelled'
    ) {
        $reasons[] =
            'Cancelled Booking cannot issue a Final Trip Document Pack.';
    }

    if ($activeCount < $expected) {
        $reasons[] =
            'Traveller roster is incomplete: '
            . $activeCount
            . ' of '
            . $expected
            . ' travellers named.';
    }

    if ($missingRequirements) {
        $reasons[] =
            count($missingRequirements)
            . ' required document item'
            . (
                count($missingRequirements) === 1
                    ? ' is'
                    : 's are'
            )
            . ' not verified/waived.';
    }

    if (
        $voucherRequired
        && !$voucher
    ) {
        $reasons[] =
            'Final customer Travel Voucher is not issued yet.';
    }

    return [
        'ready' =>
            !$reasons,
        'reasons' =>
            $reasons,
        'booking' =>
            $booking,
        'expected_travellers' =>
            $expected,
        'active_travellers' =>
            $activeCount,
        'requirements_total' =>
            count($requirements),
        'requirements_pending' =>
            count($missingRequirements),
        'validity_alerts' =>
            $validityAlerts,
        'voucher' =>
            $voucher,
        'fingerprint' =>
            tsDocCurrentFingerprint(
                $pdo,
                $bookingId
            ),
    ];
}


function tsDocPackCode(
    array $booking,
    int $version
): string {
    $safe =
        preg_replace(
            '/[^A-Za-z0-9-]+/',
            '',
            (string)(
                $booking['booking_number']
                ?? ''
            )
        );

    if (!is_string($safe) || $safe === '') {
        $safe =
            'BOOKING'
            . (int)$booking['id'];
    }

    return
        'TP-'
        . strtoupper($safe)
        . '-V'
        . $version;
}


function tsDocCreatePack(
    PDO $pdo,
    int $bookingId,
    int $adminId,
    string $status = 'draft'
): array {
    if (!tsDocReady($pdo)) {
        throw new RuntimeException(
            'Document & Traveller File Center SQL is not installed yet.'
        );
    }

    $status =
        strtolower(
            trim($status)
        );

    if (
        !in_array(
            $status,
            ['draft','final'],
            true
        )
    ) {
        $status = 'draft';
    }

    $readiness =
        tsDocPackReadiness(
            $pdo,
            $bookingId
        );

    if (
        $status === 'final'
        && empty(
            $readiness['ready']
        )
    ) {
        throw new RuntimeException(
            'Final Trip Document Pack cannot be issued: '
            . implode(
                ' ',
                (array)(
                    $readiness['reasons']
                    ?? []
                )
            )
        );
    }

    $booking =
        (array)$readiness['booking'];

    $travellers =
        tsDocTravellers(
            $pdo,
            $bookingId
        );

    $requirements =
        tsDocRequirements(
            $pdo,
            $bookingId
        );

    $documents =
        array_values(
            array_filter(
                tsDocDocuments(
                    $pdo,
                    $bookingId
                ),
                static fn($document) =>
                    (string)(
                        $document['verification_status']
                        ?? ''
                    ) === 'verified'
                    && !empty(
                        $document['customer_visible']
                    )
            )
        );

    $invoice =
        tsDocLatestFinalInvoice(
            $pdo,
            $bookingId,
            max(
                0,
                (float)(
                    $booking['total_amount']
                    ?? 0
                )
            )
        );

    $stmt = $pdo->prepare("
        SELECT COALESCE(MAX(version_number),0)+1
        FROM booking_document_pack_versions
        WHERE booking_id = ?
    ");
    $stmt->execute([$bookingId]);

    $version =
        max(
            1,
            (int)$stmt->fetchColumn()
        );

    $snapshot = [
        'schema' => 1,
        'booking' => [
            'id' => $bookingId,
            'booking_number' =>
                (string)(
                    $booking['booking_number']
                    ?? ''
                ),
            'trip_code' =>
                tsDocTripCode(
                    $pdo,
                    $bookingId
                ),
            'customer_name' =>
                (string)(
                    $booking['customer_name']
                    ?? ''
                ),
            'destination' =>
                (string)(
                    $booking['destination_name']
                    ?? ''
                ),
            'package_title' =>
                (string)(
                    $booking['package_title']
                    ?? 'Travel Booking'
                ),
            'travel_date' =>
                $booking['travel_date']
                ?? null,
            'adults' =>
                (int)(
                    $booking['adults']
                    ?? 0
                ),
            'children' =>
                (int)(
                    $booking['children']
                    ?? 0
                ),
        ],
        'travellers' =>
            array_map(
                static fn($row) => [
                    'id' =>
                        (int)$row['id'],
                    'traveller_code' =>
                        (string)$row['traveller_code'],
                    'traveller_type' =>
                        (string)$row['traveller_type'],
                    'full_name' =>
                        (string)$row['full_name'],
                    'relationship' =>
                        (string)(
                            $row['relationship']
                            ?? ''
                        ),
                    'date_of_birth' =>
                        $row['date_of_birth']
                        ?? null,
                    'nationality' =>
                        (string)(
                            $row['nationality']
                            ?? ''
                        ),
                ],
                $travellers
            ),
        'documents' =>
            array_map(
                static fn($row) => [
                    'id' =>
                        (int)$row['id'],
                    'traveller_id' =>
                        (int)$row['traveller_id'],
                    'traveller_name' =>
                        (string)(
                            $row['traveller_name']
                            ?? ''
                        ),
                    'document_category' =>
                        (string)$row['document_category'],
                    'document_type' =>
                        (string)$row['document_type'],
                    'document_number_masked' =>
                        tsDocMaskNumber(
                            (string)(
                                $row['document_number']
                                ?? ''
                            )
                        ),
                    'issuing_country' =>
                        (string)(
                            $row['issuing_country']
                            ?? ''
                        ),
                    'issue_date' =>
                        $row['issue_date']
                        ?? null,
                    'expiry_date' =>
                        $row['expiry_date']
                        ?? null,
                    'original_name' =>
                        (string)$row['original_name'],
                ],
                $documents
            ),
        'requirements' =>
            array_map(
                static fn($row) => [
                    'traveller_id' =>
                        (int)$row['traveller_id'],
                    'traveller_name' =>
                        (string)(
                            $row['traveller_name']
                            ?? ''
                        ),
                    'document_type' =>
                        (string)$row['document_type'],
                    'status' =>
                        (string)$row['status'],
                ],
                $requirements
            ),
        'voucher' =>
            !empty(
                $readiness['voucher']
            )
                ? [
                    'id' =>
                        (int)$readiness['voucher']['id'],
                    'version_number' =>
                        (int)$readiness['voucher']['version_number'],
                    'voucher_code' =>
                        (string)$readiness['voucher']['voucher_code'],
                ]
                : null,
        'invoice' =>
            $invoice
                ? [
                    'id' =>
                        (int)$invoice['id'],
                    'version_number' =>
                        (int)$invoice['version_number'],
                    'invoice_code' =>
                        (string)$invoice['invoice_code'],
                ]
                : null,
        'fingerprint' =>
            (string)$readiness['fingerprint'],
        'issued_at' =>
            date('c'),
    ];

    if ($status === 'final') {
        $pdo->prepare("
            UPDATE booking_document_pack_versions
            SET status = 'void'
            WHERE booking_id = ?
              AND status = 'final'
        ")->execute([$bookingId]);
    }

    $code =
        tsDocPackCode(
            $booking,
            $version
        );

    $stmt = $pdo->prepare("
        INSERT INTO booking_document_pack_versions
        (
            booking_id,
            version_number,
            pack_code,
            status,
            snapshot_json,
            created_by_admin_id,
            finalized_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $bookingId,
        $version,
        $code,
        $status,
        json_encode(
            $snapshot,
            JSON_UNESCAPED_UNICODE
            | JSON_UNESCAPED_SLASHES
        ),
        $adminId > 0
            ? $adminId
            : null,
        $status === 'final'
            ? date('Y-m-d H:i:s')
            : null
    ]);

    $packId =
        (int)$pdo->lastInsertId();

    if (
        $status === 'final'
        && tsDocTableExists(
            $pdo,
            'booking_operation_checks'
        )
    ) {
        $pdo->prepare("
            INSERT IGNORE INTO booking_operation_checks
            (
                booking_id,
                check_key,
                label,
                is_required,
                is_complete
            )
            VALUES
            (
                ?,
                'traveller_documents_verified',
                'Traveller Documents Verified',
                1,
                0
            )
        ")->execute([$bookingId]);

        $pdo->prepare("
            UPDATE booking_operation_checks
            SET
                is_complete = 1,
                note = ?,
                completed_by_admin_id = ?,
                completed_at = NOW(),
                updated_at = NOW()
            WHERE booking_id = ?
              AND check_key = 'traveller_documents_verified'
        ")->execute([
            'Verified through Final Trip Document Pack '
                . $code,
            $adminId > 0
                ? $adminId
                : null,
            $bookingId
        ]);
    }

    return
        tsDocPackById(
            $pdo,
            $packId
        )
        ?: [];
}


function tsDocPackById(
    PDO $pdo,
    int $packId
): ?array {
    if (
        !tsDocReady($pdo)
        || $packId <= 0
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT
            p.*,
            b.user_id,
            b.booking_number,
            b.customer_name,
            b.travel_date
        FROM booking_document_pack_versions p
        JOIN bookings b
            ON b.id = p.booking_id
        WHERE p.id = ?
        LIMIT 1
    ");
    $stmt->execute([$packId]);

    $row =
        $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function tsDocPacks(
    PDO $pdo,
    int $bookingId
): array {
    if (
        !tsDocReady($pdo)
        || $bookingId <= 0
    ) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_document_pack_versions
        WHERE booking_id = ?
        ORDER BY version_number DESC, id DESC
    ");
    $stmt->execute([$bookingId]);

    return
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        ?: [];
}


function tsDocPackIsCurrent(
    PDO $pdo,
    array $pack
): bool {
    if (
        (string)(
            $pack['status']
            ?? ''
        ) !== 'final'
    ) {
        return false;
    }

    $snapshot =
        json_decode(
            (string)(
                $pack['snapshot_json']
                ?? ''
            ),
            true
        );

    if (!is_array($snapshot)) {
        return false;
    }

    $stored =
        (string)(
            $snapshot['fingerprint']
            ?? ''
        );

    if ($stored === '') {
        return false;
    }

    return
        hash_equals(
            $stored,
            tsDocCurrentFingerprint(
                $pdo,
                (int)$pack['booking_id']
            )
        );
}


function tsDocLatestCurrentFinalPack(
    PDO $pdo,
    int $bookingId
): ?array {
    foreach (
        tsDocPacks(
            $pdo,
            $bookingId
        )
        as $pack
    ) {
        if (
            tsDocPackIsCurrent(
                $pdo,
                $pack
            )
        ) {
            return $pack;
        }
    }

    return null;
}


function tsDocSummary(
    PDO $pdo,
    int $bookingId
): array {
    if (!tsDocReady($pdo)) {
        return [
            'ready' => false,
        ];
    }

    tsDocEnsureLeadTraveller(
        $pdo,
        $bookingId
    );

    tsDocRefreshRequirements(
        $pdo,
        $bookingId
    );

    $booking =
        tsDocBooking(
            $pdo,
            $bookingId
        );

    $travellers =
        tsDocTravellers(
            $pdo,
            $bookingId
        );

    $documents =
        tsDocDocuments(
            $pdo,
            $bookingId
        );

    $requirements =
        tsDocRequirements(
            $pdo,
            $bookingId
        );

    $verified = 0;
    $pending = 0;
    $rejected = 0;
    $alerts = 0;

    foreach ($documents as $document) {
        $status =
            (string)$document['verification_status'];

        if ($status === 'verified') {
            $verified++;
        } elseif ($status === 'pending') {
            $pending++;
        } elseif ($status === 'rejected') {
            $rejected++;
        }

        if (
            !in_array(
                $status,
                ['archived','rejected'],
                true
            )
        ) {
            $validity =
                tsDocValidity(
                    $document,
                    $booking
                );

            if (
                !empty($validity['blocking'])
                || !empty($validity['warning'])
            ) {
                $alerts++;
            }
        }
    }

    $missing =
        count(
            array_filter(
                $requirements,
                static fn($row) =>
                    !empty(
                        $row['is_required']
                    )
                    && !in_array(
                        (string)$row['status'],
                        ['verified','waived'],
                        true
                    )
            )
        );

    $pack =
        tsDocLatestCurrentFinalPack(
            $pdo,
            $bookingId
        );

    return [
        'ready' => true,
        'expected_travellers' =>
            tsDocExpectedTravellerCount(
                $booking
            ),
        'active_travellers' =>
            count($travellers),
        'verified_documents' =>
            $verified,
        'pending_documents' =>
            $pending,
        'rejected_documents' =>
            $rejected,
        'missing_requirements' =>
            $missing,
        'validity_alerts' =>
            $alerts,
        'latest_final_pack' =>
            $pack,
        'pack_readiness' =>
            tsDocPackReadiness(
                $pdo,
                $bookingId
            ),
    ];
}
