TRAVSCOPE V24.92 — PROFESSIONAL DAY-WISE ITINERARY
===================================================
Base: V24.91 — Unified Supplier Package + Hotel Import

PUBLIC PACKAGE DETAILS UPDATE
-----------------------------
1. Day-wise itinerary cards now use a clean two-column editorial layout:
   - Day badge on the timeline
   - Full uncropped itinerary photo on the left
   - Day eyebrow, title and narrative on the right
   - Route facts (Start / Via / End / Distance / Travel Time) span the full card below
2. Day narrative text is justified for a more professional brochure-style appearance.
3. Mobile view collapses cleanly to one column while preserving justified copy.
4. Inline route metadata such as [Start: ... | Via/Sightseeing: ... | End: ...]
   is extracted from the narrative and shown only once in the route strip.
5. Duplicate identical metadata blocks are removed automatically.
6. Existing 200-word public day narrative guard remains active.
7. Existing full-photo/no-crop behavior remains active.

CHANGED FILES
-------------
- package-details.php
- README_V24_92_PROFESSIONAL_DAYWISE_ITINERARY.txt

DATABASE
--------
No SQL required.
