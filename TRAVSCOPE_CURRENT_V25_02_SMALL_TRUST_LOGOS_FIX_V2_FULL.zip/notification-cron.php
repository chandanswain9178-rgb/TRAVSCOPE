<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);

    exit(
        "TRAVSCOPE Notification Cron is CLI-only.\n"
    );
}

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/notification-functions.php';

$jobFunctions =
    __DIR__
    . '/job-functions.php';

if (is_file($jobFunctions)) {
    require_once
        $jobFunctions;
}

$args =
    $_SERVER['argv']
    ?? [];

$sendEmail =
    in_array(
        '--email',
        $args,
        true
    );

$job =
    function_exists('tsJobBegin')
        ? tsJobBegin(
            $pdo,
            'notification_sync',
            [
                'send_email' =>
                    $sendEmail,
            ]
        )
        : [
            'tracked' => false,
            'acquired' => true,
            'disabled' => false,
            'job_key' =>
                'notification_sync',
            'started_at' =>
                microtime(true),
        ];

if (!empty($job['disabled'])) {
    echo
        "Notification sync is disabled in System Jobs Control Center.\n";

    exit(0);
}

if (empty($job['acquired'])) {
    fwrite(
        STDERR,
        "Overlap prevented: another Notification cron is still running.\n"
    );

    exit(4);
}

if (!tsNotifyReady($pdo)) {
    if (function_exists('tsJobFinish')) {
        tsJobFinish(
            $pdo,
            $job,
            'failure',
            2,
            'Notification SQL is not installed.'
        );
    }

    fwrite(
        STDERR,
        "Notification SQL is not installed.\n"
    );

    exit(2);
}

try {
    $sync =
        tsNotifySync($pdo);

    echo
        '['
        . date('Y-m-d H:i:s')
        . '] Notification sync complete. Recipient alert records refreshed: '
        . (int)$sync['created_or_updated']
        . PHP_EOL;

    foreach (
        (array)$sync['sources']
        as $source => $count
    ) {
        echo
            ' - '
            . $source
            . ': '
            . (int)$count
            . PHP_EOL;
    }

    /*
    | Refresh System Job alerts before escalation email sending so a stale
    | Communication/Health job can be included in this same Notification run.
    */
    if (
        function_exists(
            'tsJobSyncAlerts'
        )
    ) {
        tsJobSyncAlerts(
            $pdo
        );
    }

    $mail = [
        'sent' => 0,
        'failed' => 0,
        'eligible' => 0,
        'messages' => [],
    ];

    if ($sendEmail) {
        $mail =
            tsNotifySendEscalationEmails(
                $pdo,
                100
            );

        echo
            'High/Critical email escalation: '
            . (int)$mail['sent']
            . ' sent, '
            . (int)$mail['failed']
            . ' failed, '
            . (int)$mail['eligible']
            . ' eligible.'
            . PHP_EOL;

        foreach (
            (array)$mail['messages']
            as $message
        ) {
            echo
                ' ! '
                . $message
                . PHP_EOL;
        }

    } else {
        echo
            "Email escalation not requested. "
            . "Add --email to send new High/Critical escalations.\n";
    }

    $status =
        (int)$mail['failed'] > 0
            ? 'warning'
            : 'success';

    $summary =
        'Alerts refreshed '
        . (int)$sync[
            'created_or_updated'
        ]
        . '. Email sent '
        . (int)$mail['sent']
        . ', failed '
        . (int)$mail['failed']
        . '.';

    if (function_exists('tsJobFinish')) {
        tsJobFinish(
            $pdo,
            $job,
            $status,
            0,
            $summary,
            [
                'sync' => $sync,
                'email' => $mail,
            ]
        );
    }

    /*
    | Preserve the existing Notification cron exit behavior:
    | email delivery problems are reported as a tracked WARNING,
    | while an actual thrown cron failure exits non-zero.
    */
    exit(0);

} catch (Throwable $e) {
    if (function_exists('tsJobFinish')) {
        tsJobFinish(
            $pdo,
            $job,
            'failure',
            1,
            'Notification cron failed: '
                . $e->getMessage()
        );
    }

    fwrite(
        STDERR,
        '['
        . date('Y-m-d H:i:s')
        . '] Notification cron failed: '
        . $e->getMessage()
        . PHP_EOL
    );

    exit(1);
}
