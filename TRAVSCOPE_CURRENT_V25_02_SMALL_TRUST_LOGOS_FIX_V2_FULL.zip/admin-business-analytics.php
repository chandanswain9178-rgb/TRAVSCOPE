<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/analytics-functions.php';
if (is_file(__DIR__ . '/crm-functions.php')) require_once __DIR__ . '/crm-functions.php';

requireAdmin();
$admin=currentAdmin($pdo);
if(!$admin || strtolower((string)($admin['status']??''))!=='active'){
    unset($_SESSION['admin_id'],$_SESSION['admin_name'],$_SESSION['admin_email'],$_SESSION['admin_role']);
    redirect(BASE_URL.'admin-login.php');
}

$adminId=(int)$admin['id'];
$days=tsAnDays($_GET['days']??$_POST['days']??90);
$repeat=(string)($_GET['repeat']??'active');
if(!in_array($repeat,['active','due','won','closed'],true))$repeat='active';

if(empty($_SESSION['admin_analytics_csrf']))$_SESSION['admin_analytics_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['admin_analytics_csrf'];
$error=''; $success='';

if(!empty($_SESSION['admin_analytics_success'])){
    $success=(string)$_SESSION['admin_analytics_success'];
    unset($_SESSION['admin_analytics_success']);
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!hash_equals($csrf,(string)($_POST['csrf_token']??''))){
        $error='Security verification failed. Refresh and try again.';
    }else{
        try{
            $action=(string)($_POST['action']??'');
            if($action==='sync_repeat'){
                if(!tsAnRepeatReady($pdo))throw new RuntimeException('Import TRAVSCOPE_Business_Analytics_Repeat_Sales.sql first.');
                $n=tsAnSyncRepeat($pdo,$adminId);
                $_SESSION['admin_analytics_success']=$n>0?"{$n} new Repeat Sales opportunity(s) created.":'Repeat Sales pipeline synchronized.';
            }elseif($action==='update_repeat'){
                tsAnUpdateRepeat($pdo,max(0,(int)($_POST['opportunity_id']??0)),$_POST);
                $_SESSION['admin_analytics_success']='Repeat Sales opportunity updated.';
            }elseif($action==='create_repeat_enquiry'){
                $eid=tsAnCreateRepeatEnquiry($pdo,max(0,(int)($_POST['opportunity_id']??0)),$adminId);
                $_SESSION['admin_analytics_success']='CRM Enquiry #'.$eid.' created from Repeat Sales.';
                redirect(BASE_URL.'admin-crm.php?lead='.$eid);
            }else{
                throw new RuntimeException('Invalid analytics action.');
            }
            redirect(BASE_URL.'admin-business-analytics.php?days='.$days.'&repeat='.urlencode($repeat));
        }catch(RuntimeException $e){$error=$e->getMessage();}
        catch(Throwable $e){error_log('Analytics action: '.$e->getMessage());$error='Unable to complete analytics action: '.$e->getMessage();}
    }
}

if(tsAnRepeatReady($pdo))tsAnSyncRepeat($pdo,$adminId);

$ov=tsAnOverview($pdo,$days);
$sources=tsAnLeadSources($pdo,$days);
$dests=tsAnDestinations($pdo,$days);
$aging=tsAnCollectionAging($pdo);
$suppliers=tsAnSuppliers($pdo,$days);
$trend=tsAnMarginTrend($pdo);
$risks=tsAnDepartureRisks($pdo,30);
$customers=tsAnCustomers($pdo);
$owners=tsAnOwners($pdo,$days);
$repeatRows=tsAnRepeatRows($pdo,$repeat);
$admins=tsAnAdmins($pdo);

function anE($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function anM($v,$c='INR'):string{return strtoupper(trim((string)$c)).' '.number_format((float)$v,2);}
function anDate($v):string{$t=strtotime((string)$v);return $t?date('d M Y',$t):'-';}

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Business Analytics & Repeat Sales | TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:66px;padding:10px 4%;display:flex;justify-content:space-between;align-items:center;gap:10px;background:#fff;border-bottom:1px solid #dfe7f0;position:sticky;top:0;z-index:20}.brand{font-weight:900}.brand span{color:#2563eb}.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 10px;border:1px solid #cbd5e1;border-radius:9px;background:#fff;color:#334155;text-decoration:none;font-size:9px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.btn.good{background:#059669;border-color:#059669;color:#fff}.wrap{max-width:1450px;margin:20px auto;padding:0 13px}.hero{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;padding:16px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:20px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px}.filters{display:flex;gap:6px;flex-wrap:wrap}.filters a{padding:6px 9px;border:1px solid #cbd5e1;border-radius:999px;background:#fff;color:#475569;text-decoration:none;font-size:8px;font-weight:900}.filters a.active{background:#0f172a;color:#fff;border-color:#0f172a}.notice{margin-top:10px;padding:10px 12px;border-radius:10px;font-size:10px}.notice.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#047857}.notice.err{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c}.kpis{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;margin-top:11px}.kpi{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.kpi span{display:block;color:#64748b;font-size:7.5px;font-weight:900;text-transform:uppercase}.kpi strong{display:block;margin-top:4px;font-size:13px}.kpi small{display:block;margin-top:3px;color:#94a3b8;font-size:8px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:11px;margin-top:11px}.card{background:#fff;border:1px solid #dfe7f0;border-radius:13px;overflow:hidden}.card.full{grid-column:1/-1}.head{padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff;display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.head h2{margin:0;font-size:12px}.head p{margin:4px 0 0;color:#64748b;font-size:8.5px}.body{padding:11px}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse}th,td{padding:7px 8px;border-bottom:1px solid #eef2f7;text-align:left;font-size:8.5px;white-space:nowrap}th{background:#f8fafc;color:#64748b;font-size:7.5px;text-transform:uppercase}.right{text-align:right}.aging{display:grid;grid-template-columns:repeat(5,1fr);gap:7px}.age{padding:9px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc}.age span{display:block;color:#64748b;font-size:7.5px;font-weight:900;text-transform:uppercase}.age strong{display:block;margin-top:4px;font-size:11px}.age small{display:block;margin-top:3px;color:#94a3b8;font-size:8px}.risk{display:flex;gap:5px;flex-wrap:wrap}.risk span{padding:3px 6px;border-radius:999px;background:#fff1f2;color:#be123c;font-size:7.5px;font-weight:900}.pill{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:7.5px;font-weight:900}.pill.new,.pill.contact_due{background:#fff7ed;color:#c2410c}.pill.contacted,.pill.deferred{background:#eff6ff;color:#1d4ed8}.pill.interested,.pill.enquiry_created,.pill.booked{background:#ecfdf5;color:#047857}.pill.not_interested{background:#f1f5f9;color:#64748b}.repeat{padding:10px;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:8px}.repeat-top{display:flex;justify-content:space-between;gap:8px}.repeat-top strong{font-size:10px}.repeat-top small{display:block;margin-top:3px;color:#64748b;font-size:8px}.repeat-form{display:grid;grid-template-columns:120px 130px 1fr 130px 130px;gap:6px;margin-top:8px}.repeat-form input,.repeat-form select,.repeat-form textarea{width:100%;min-height:31px;padding:6px 7px;border:1px solid #cbd5e1;border-radius:8px;font-size:8.5px}.repeat-form textarea{resize:vertical}.actions{display:flex;gap:5px;flex-wrap:wrap;margin-top:7px}.empty{padding:14px;text-align:center;color:#94a3b8;font-size:9px}
@media(max-width:1100px){.kpis{grid-template-columns:repeat(3,1fr)}.aging{grid-template-columns:repeat(3,1fr)}.repeat-form{grid-template-columns:1fr 1fr 1fr}}
@media(max-width:850px){.grid{grid-template-columns:1fr}.card.full{grid-column:auto}.kpis{grid-template-columns:1fr 1fr}.repeat-form{grid-template-columns:1fr 1fr}}
@media(max-width:600px){.top,.hero{flex-direction:column;align-items:flex-start}.kpis,.aging,.repeat-form{grid-template-columns:1fr}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>
<body>
<header class="top">
  <div class="brand">TRAV<span>SCOPE</span> · BUSINESS ANALYTICS</div>
  <div style="display:flex;gap:7px;flex-wrap:wrap;">
    <a class="btn" href="<?=anE(BASE_URL.'admin-dashboard.php')?>"><i class="fa-solid fa-gauge-high"></i> Dashboard</a>
    <a class="btn" href="<?=anE(BASE_URL.'admin-crm.php')?>"><i class="fa-solid fa-route"></i> CRM</a>
    <a class="btn primary" href="#repeat-sales"><i class="fa-solid fa-rotate"></i> Repeat Sales</a>
  </div>
</header>

<main class="wrap">
<section class="hero">
  <div><h1>Business Analytics & Repeat Sales Engine</h1><p>Conversion, revenue, collections, supplier performance, profitability, readiness risk, staff performance and repeat-customer follow-up.</p></div>
  <div class="filters">
    <?php foreach([30,90,180,365,1095] as $d): ?>
      <a class="<?=$days===$d?'active':''?>" href="<?=anE(BASE_URL.'admin-business-analytics.php?days='.$d.'&repeat='.$repeat)?>"><?=$d===1095?'3 Years':$d.' Days'?></a>
    <?php endforeach; ?>
  </div>
</section>

<?php if($success):?><div class="notice ok"><?=anE($success)?></div><?php endif;?>
<?php if($error):?><div class="notice err"><?=anE($error)?></div><?php endif;?>

<div class="kpis">
  <div class="kpi"><span>Leads</span><strong><?=number_format($ov['leads'])?></strong><small><?=number_format($ov['quoted'])?> quoted</small></div>
  <div class="kpi"><span>Lead → Booking</span><strong><?=number_format($ov['lead_booking'],1)?>%</strong><small><?=number_format($ov['bookings'])?> Bookings</small></div>
  <div class="kpi"><span>Quote Acceptance</span><strong><?=number_format($ov['quote_acceptance'],1)?>%</strong><small><?=number_format($ov['accepted'])?> accepted</small></div>
  <div class="kpi"><span>Booked Sales</span><strong><?=anE(anM($ov['sales']))?></strong><small><?=number_format($ov['collection'],1)?>% collected</small></div>
  <div class="kpi"><span>Outstanding</span><strong><?=anE(anM($ov['outstanding']))?></strong><small>Live customer balance</small></div>
  <div class="kpi"><span>Repeat Sales Due</span><strong><?=number_format($ov['repeat_due'])?></strong><small>Follow-ups due now</small></div>
</div>

<div class="grid">
<section class="card"><div class="head"><div><h2>Lead Source Conversion</h2><p>Which channels create bookings.</p></div></div><div class="body table-wrap">
<?php if(!$sources):?><div class="empty">No source data.</div><?php else:?><table><thead><tr><th>Source</th><th class="right">Leads</th><th class="right">Booked</th><th class="right">Conversion</th><th class="right">Booked Value</th></tr></thead><tbody>
<?php foreach($sources as $r):?><tr><td><?=anE(ucwords(str_replace('_',' ',$r['source_name'])))?></td><td class="right"><?=(int)$r['leads']?></td><td class="right"><?=(int)$r['converted']?></td><td class="right"><?=number_format($r['conversion'],1)?>%</td><td class="right"><?=anE(anM($r['booked_value']))?></td></tr><?php endforeach;?>
</tbody></table><?php endif;?></div></section>

<section class="card"><div class="head"><div><h2>Destination Conversion</h2><p>Enquiries → bookings by destination.</p></div></div><div class="body table-wrap">
<?php if(!$dests):?><div class="empty">No destination data.</div><?php else:?><table><thead><tr><th>Destination</th><th class="right">Leads</th><th class="right">Booked</th><th class="right">Conversion</th><th class="right">Booked Value</th></tr></thead><tbody>
<?php foreach($dests as $r):?><tr><td><?=anE($r['destination_name'])?></td><td class="right"><?=(int)$r['leads']?></td><td class="right"><?=(int)$r['converted']?></td><td class="right"><?=number_format($r['conversion'],1)?>%</td><td class="right"><?=anE(anM($r['booked_value']))?></td></tr><?php endforeach;?>
</tbody></table><?php endif;?></div></section>

<section class="card full"><div class="head"><div><h2>Customer Collection Aging</h2><p>Current active installment schedule by urgency.</p></div></div><div class="body"><div class="aging">
<?php foreach(['overdue'=>'Overdue','due7'=>'Due 7 Days','due30'=>'Due 30 Days','later'=>'Later','unscheduled'=>'Unscheduled'] as $k=>$label):?>
<div class="age"><span><?=anE($label)?></span><strong><?=anE(anM($aging[$k][1]))?></strong><small><?=$aging[$k][0]?> item(s)</small></div>
<?php endforeach;?>
</div></div></section>

<section class="card"><div class="head"><div><h2>Supplier Performance</h2><p>Confirmation reliability and response speed.</p></div></div><div class="body table-wrap">
<?php if(!$suppliers):?><div class="empty">No supplier confirmation data.</div><?php else:?><table><thead><tr><th>Supplier</th><th class="right">Orders</th><th class="right">Confirmed</th><th class="right">Problems</th><th class="right">Confirm %</th><th class="right">Response</th></tr></thead><tbody>
<?php foreach($suppliers as $r):?><tr><td><a href="<?=anE(BASE_URL.'admin-supplier-details.php?id='.(int)$r['supplier_id'])?>"><?=anE($r['company_name'])?></a></td><td class="right"><?=(int)$r['orders']?></td><td class="right"><?=(int)$r['confirmed']?></td><td class="right"><?=(int)$r['problems']?></td><td class="right"><?=number_format($r['rate'],1)?>%</td><td class="right"><?=$r['response_hours']!==null?number_format($r['response_hours'],1).'h':'-'?></td></tr><?php endforeach;?>
</tbody></table><?php endif;?></div></section>

<section class="card"><div class="head"><div><h2>Expected vs Actual Margin</h2><p>Financially closed bookings by month.</p></div></div><div class="body table-wrap">
<?php if(!$trend):?><div class="empty">No closed profitability history.</div><?php else:?><table><thead><tr><th>Month</th><th class="right">Trips</th><th class="right">Expected</th><th class="right">Actual</th><th class="right">Variance</th></tr></thead><tbody>
<?php foreach($trend as $r):?><tr><td><?=anE($r['month_label'])?></td><td class="right"><?=(int)$r['trips']?></td><td class="right"><?=anE(anM($r['expected_margin']))?></td><td class="right"><?=anE(anM($r['actual_margin']))?></td><td class="right"><?=anE(anM((float)$r['actual_margin']-(float)$r['expected_margin']))?></td></tr><?php endforeach;?>
</tbody></table><?php endif;?></div></section>

<section class="card full"><div class="head"><div><h2>Departure Risk — Next 30 Days</h2><p>Payment, supplier, voucher, document and communication gaps.</p></div></div><div class="body table-wrap">
<?php if(!$risks):?><div class="empty">No departure risks detected.</div><?php else:?><table><thead><tr><th>Departure</th><th>Booking</th><th>Customer</th><th>Risk</th><th class="right">Balance</th><th></th></tr></thead><tbody>
<?php foreach($risks as $r):?><tr><td><?=anE(anDate($r['travel_date']))?></td><td><?=anE($r['booking_number'])?></td><td><?=anE($r['customer_name'])?></td><td><div class="risk"><?php foreach($r['reasons'] as $x):?><span><?=anE($x)?></span><?php endforeach;?></div></td><td class="right"><?=anE(anM($r['balance'],$r['currency']))?></td><td><a class="btn" href="<?=anE(BASE_URL.'admin-booking-details.php?id='.(int)$r['id'])?>">Open</a></td></tr><?php endforeach;?>
</tbody></table><?php endif;?></div></section>

<section class="card"><div class="head"><div><h2>Customer Lifetime Value</h2><p>Top customers by cumulative sales.</p></div></div><div class="body table-wrap">
<?php if(!$customers):?><div class="empty">No customer history.</div><?php else:?><table><thead><tr><th>Customer</th><th class="right">Bookings</th><th class="right">Lifetime Sales</th><th class="right">Actual Margin</th><th>Last Travel</th></tr></thead><tbody>
<?php foreach($customers as $r):?><tr><td><?=anE($r['customer_name'])?></td><td class="right"><?=(int)$r['bookings']?></td><td class="right"><?=anE(anM($r['lifetime_sales']))?></td><td class="right"><?=anE(anM($r['actual_margin']))?></td><td><?=anE(anDate($r['last_travel_date']))?></td></tr><?php endforeach;?>
</tbody></table><?php endif;?></div></section>

<section class="card"><div class="head"><div><h2>CRM Owner Performance</h2><p>Leads, conversion, booked value and overdue follow-ups.</p></div></div><div class="body table-wrap">
<?php if(!$owners):?><div class="empty">No owner data.</div><?php else:?><table><thead><tr><th>Owner</th><th class="right">Leads</th><th class="right">Booked</th><th class="right">Conversion</th><th class="right">Booked Value</th><th class="right">Overdue</th></tr></thead><tbody>
<?php foreach($owners as $r):?><tr><td><?=anE($r['admin_name'])?></td><td class="right"><?=(int)$r['leads']?></td><td class="right"><?=(int)$r['converted']?></td><td class="right"><?=number_format($r['conversion'],1)?>%</td><td class="right"><?=anE(anM($r['booked_value']))?></td><td class="right"><?=(int)$r['overdue']?></td></tr><?php endforeach;?>
</tbody></table><?php endif;?></div></section>

<section class="card full" id="repeat-sales"><div class="head"><div><h2>Repeat Sales Pipeline</h2><p>Completed trips become new follow-up opportunities without changing original booking history.</p></div>
<?php if(tsAnRepeatReady($pdo)):?><form method="post"><input type="hidden" name="csrf_token" value="<?=anE($csrf)?>"><input type="hidden" name="action" value="sync_repeat"><button class="btn primary" type="submit"><i class="fa-solid fa-rotate"></i> Sync Completed Trips</button></form><?php endif;?>
</div><div class="body">
<?php if(!tsAnRepeatReady($pdo)):?><div class="notice err" style="margin-top:0">Import <strong>TRAVSCOPE_Business_Analytics_Repeat_Sales.sql</strong> to enable Repeat Sales.</div>
<?php else:?>
<div class="filters" style="margin-bottom:9px"><?php foreach(['active'=>'Active','due'=>'Due Now','won'=>'Enquiry / Booked','closed'=>'Closed'] as $k=>$label):?><a class="<?=$repeat===$k?'active':''?>" href="<?=anE(BASE_URL.'admin-business-analytics.php?days='.$days.'&repeat='.$k.'#repeat-sales')?>"><?=anE($label)?></a><?php endforeach;?></div>
<?php if(!$repeatRows):?><div class="empty">No Repeat Sales opportunities in this view.</div><?php endif;?>
<?php foreach($repeatRows as $r):?>
<div class="repeat">
  <div class="repeat-top"><div><strong><?=anE($r['customer_name'])?> · Source Booking #<?=(int)$r['source_booking_id']?></strong><small>Travel <?=anE(anDate($r['source_travel_date']))?> · Completed <?=anE(anDate($r['completion_date']))?> · Owner <?=anE($r['owner_name']?:'Unassigned')?><?php if($r['linked_enquiry_id']):?> · Enquiry #<?=(int)$r['linked_enquiry_id']?><?php endif;?></small></div><span class="pill <?=anE($r['status'])?>"><?=anE(strtoupper(str_replace('_',' ',$r['status'])))?></span></div>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?=anE($csrf)?>"><input type="hidden" name="action" value="update_repeat"><input type="hidden" name="opportunity_id" value="<?=(int)$r['id']?>">
    <div class="repeat-form">
      <select name="status"><?php foreach(['new'=>'New','contact_due'=>'Contact Due','contacted'=>'Contacted','interested'=>'Interested','enquiry_created'=>'Enquiry Created','booked'=>'Booked','not_interested'=>'Not Interested','deferred'=>'Deferred'] as $k=>$label):?><option value="<?=anE($k)?>" <?=$r['status']===$k?'selected':''?>><?=anE($label)?></option><?php endforeach;?></select>
      <select name="owner_admin_id"><option value="0">Unassigned</option><?php foreach($admins as $a):?><option value="<?=(int)$a['id']?>" <?=(int)$r['owner_admin_id']===(int)$a['id']?'selected':''?>><?=anE($a['name'])?></option><?php endforeach;?></select>
      <input name="preferred_destination" value="<?=anE($r['preferred_destination']??'')?>" placeholder="Preferred destination">
      <input type="date" name="preferred_travel_date" value="<?=anE($r['preferred_travel_date']??'')?>">
      <input type="date" name="next_action_date" value="<?=anE($r['next_action_date']??'')?>">
      <input type="number" step=".01" min="0" name="estimated_value" value="<?=anE($r['estimated_value'])?>" placeholder="Estimated value">
      <textarea name="notes" placeholder="Repeat-sales notes"><?=anE($r['notes']??'')?></textarea>
      <button class="btn" type="submit">Save</button>
    </div>
  </form>
  <div class="actions">
    <a class="btn" href="<?=anE(BASE_URL.'admin-booking-details.php?id='.(int)$r['source_booking_id'])?>">Source Booking</a>
    <?php if($r['linked_enquiry_id']):?><a class="btn primary" href="<?=anE(BASE_URL.'admin-crm.php?lead='.(int)$r['linked_enquiry_id'])?>">Open CRM Enquiry</a>
    <?php else:?><form method="post" onsubmit="return confirm('Create a NEW CRM Enquiry from this repeat opportunity?');"><input type="hidden" name="csrf_token" value="<?=anE($csrf)?>"><input type="hidden" name="action" value="create_repeat_enquiry"><input type="hidden" name="opportunity_id" value="<?=(int)$r['id']?>"><button class="btn good" type="submit"><i class="fa-solid fa-circle-plus"></i> Create CRM Enquiry</button></form><?php endif;?>
  </div>
</div>
<?php endforeach;?>
<?php endif;?>
</div></section>
</div>
</main>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
