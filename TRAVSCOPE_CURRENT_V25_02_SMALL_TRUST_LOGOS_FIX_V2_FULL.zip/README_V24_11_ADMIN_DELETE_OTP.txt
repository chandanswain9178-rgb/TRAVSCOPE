TRAVSCOPE V24.11 - GLOBAL ADMIN DELETE OTP SECURITY
===================================================

PURPOSE
-------
Every destructive Delete/Remove/Purge/Destroy POST action in the Admin Panel is
intercepted before its existing delete code runs.

FLOW
----
1. Admin clicks Delete / Remove.
2. The original POST request is stored safely in the Admin session.
3. A 6-digit OTP is emailed to the currently logged-in Admin email address.
4. Admin enters the OTP on admin-delete-otp.php.
5. After successful OTP verification, the exact original POST request is replayed.
6. The existing page-specific delete handler then runs normally.

SECURITY
--------
- OTP is tied to the logged-in Admin session.
- OTP expires using the existing TRAVSCOPE OTP expiry setting.
- Existing OTP attempt limits and resend limits remain active.
- The verified approval is one-time and tied to the exact POST payload.
- Existing page CSRF tokens are preserved and replayed unchanged.
- Existing delete safety rules / foreign-key protections still apply.
- Archive/activate/approve/status actions are not treated as permanent deletes.

DATABASE
--------
REQUIRED: import TRAVSCOPE_V24_11_ADMIN_DELETE_OTP.sql once.
It adds `admin_delete` to the existing email_otps.purpose ENUM.

FILES
-----
Core:
- config.php
- includes/functions.php
- admin-delete-otp-functions.php
- admin-delete-otp.php

Several Admin PHP pages were also updated only to remove their old browser confirm()
prompts for persistent Delete/Remove buttons, so OTP becomes the single confirmation step.

DEPLOYMENT
----------
1. Back up website files and database.
2. Upload the V24.11 patch files or use the full V24.11 website ZIP.
3. Import TRAVSCOPE_V24_11_ADMIN_DELETE_OTP.sql in phpMyAdmin.
4. Log out/in if needed, then Ctrl+F5.
5. Test one harmless/unused record first.

IMPORTANT
---------
The Admin account must have a valid active email address and SMTP must be working.
