<?php
require_once __DIR__ . '/config.php';
if (function_exists('requireAdmin')) {
    requireAdmin();
} elseif (empty($_SESSION['admin_id'])) {
    header('Location: ' . (defined('BASE_URL') ? BASE_URL : '') . 'login.php');
    exit;
}
$admin = function_exists('currentAdmin') ? currentAdmin($pdo) : null;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Transport | TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
:root{--navy:#07192d;--blue:#1378ee;--green:#0b9469;--amber:#dc8a12;--violet:#7650dc;--text:#132a44;--muted:#738398;--border:#dde7f1;--bg:#f4f8fc}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,sans-serif;color:var(--text)}.main{min-height:100vh}.content{padding:18px}.transport-head{border:1px solid var(--border);border-left:4px solid #1683ff;border-radius:14px;background:linear-gradient(115deg,#fff,#f5faff);padding:16px 18px;display:flex;align-items:center;justify-content:space-between;gap:16px;box-shadow:0 8px 24px rgba(16,49,83,.05)}.eyebrow{font-size:9px;letter-spacing:.12em;font-weight:800;color:#1683ff;margin-bottom:4px}.transport-head h1{margin:0;font-size:25px}.transport-head p{margin:5px 0 0;color:var(--muted);font-size:11px}.workflow-pill{white-space:nowrap;padding:7px 10px;border-radius:999px;background:#edf6ff;color:#166fce;font-size:9px;font-weight:800}.transport-workspace{margin-top:12px;border:1px solid var(--border);border-radius:14px;background:#fff;overflow:hidden;box-shadow:0 8px 24px rgba(16,49,83,.05)}.workspace-head{padding:11px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:12px;background:#fbfdff}.workspace-head h2{margin:0;font-size:13px}.workspace-head p{margin:3px 0 0;color:var(--muted);font-size:9px}.route-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0}.route-card{padding:16px;border-right:1px solid var(--border);display:grid;grid-template-columns:40px 1fr auto;gap:11px;align-items:center;min-height:112px}.route-card:last-child{border-right:0}.route-icon{width:40px;height:40px;border-radius:11px;display:grid;place-items:center;font-size:16px;background:#eaf4ff;color:var(--blue)}.route-card:nth-child(2) .route-icon{background:#e9faf3;color:var(--green)}.route-card:nth-child(3) .route-icon{background:#f3edff;color:var(--violet)}.route-copy h3{margin:0 0 4px;font-size:13px}.route-copy p{margin:0;color:var(--muted);font-size:9px;line-height:1.45}.route-card a{height:34px;padding:0 11px;border:1px solid #cfe0f2;border-radius:8px;display:inline-flex;align-items:center;gap:6px;text-decoration:none;color:#0f66c6;background:#f7fbff;font-size:9px;font-weight:800;white-space:nowrap}.route-card a:hover{background:#eaf4ff}.process-strip{border-top:1px solid var(--border);padding:10px 13px;display:flex;align-items:center;gap:7px;flex-wrap:wrap;background:#f8fbfe}.process-strip strong{font-size:9px;color:#314f6d}.step{display:inline-flex;align-items:center;gap:5px;color:#66809b;font-size:8px}.step i{font-size:6px;color:#9ab1c6}.hint{margin-left:auto;color:#7e8fa2;font-size:8px}@media(max-width:960px){.route-grid{grid-template-columns:1fr}.route-card{border-right:0;border-bottom:1px solid var(--border)}.route-card:last-child{border-bottom:0}}@media(max-width:650px){.content{padding:10px}.transport-head{align-items:flex-start;flex-direction:column}.workflow-pill{white-space:normal}.route-card{grid-template-columns:38px 1fr}.route-card a{grid-column:1/-1;justify-content:center}.hint{width:100%;margin-left:0}}
</style>
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>
<body>
<main class="main"><div class="content">
<section class="transport-head">
  <div><div class="eyebrow">OPERATIONS / TRANSPORT CONTROL</div><h1>Transport Operations</h1><p>Move from traveller demand to supplier vehicle allocation and final booking confirmation without losing trip context.</p></div>
  <span class="workflow-pill"><i class="fa-solid fa-shield-halved"></i> Contract-driven vehicle workflow</span>
</section>
<section class="transport-workspace">
  <div class="workspace-head"><div><h2>Transport Workspace</h2><p>Choose the stage you need. Existing CRM, supplier and booking records remain the source of truth.</p></div></div>
  <div class="route-grid">
    <article class="route-card"><span class="route-icon"><i class="fa-solid fa-route"></i></span><div class="route-copy"><h3>1. Customer Trip</h3><p>Start from the CRM trip so traveller count, date and quotation version stay attached to the transport plan.</p></div><a href="admin-crm.php">Open CRM <i class="fa-solid fa-arrow-right"></i></a></article>
    <article class="route-card"><span class="route-icon"><i class="fa-solid fa-van-shuttle"></i></span><div class="route-copy"><h3>2. Supplier Vehicle Inventory</h3><p>Review destination, route, usage and PAX rules from the supplier contract vehicle inventory.</p></div><a href="admin-supplier-vehicles.php">Vehicle Inventory <i class="fa-solid fa-arrow-right"></i></a></article>
    <article class="route-card"><span class="route-icon"><i class="fa-solid fa-calendar-check"></i></span><div class="route-copy"><h3>3. Booking & Fulfilment</h3><p>Manage confirmed vehicle, driver, pickup timing, vehicle number and final booking/voucher details.</p></div><a href="admin-bookings.php">Open Bookings <i class="fa-solid fa-arrow-right"></i></a></article>
  </div>
  <div class="process-strip"><strong>Operational flow</strong><span class="step">Supplier Inventory <i class="fa-solid fa-chevron-right"></i></span><span class="step">CRM Trip <i class="fa-solid fa-chevron-right"></i></span><span class="step">Quotation Plan <i class="fa-solid fa-chevron-right"></i></span><span class="step">Supplier Confirmation <i class="fa-solid fa-chevron-right"></i></span><span class="step">Booking <i class="fa-solid fa-chevron-right"></i></span><span class="step">Final Voucher</span><span class="hint">No duplicate transport pricing is created on this launcher page.</span></div>
</section>
</div></main>
<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
