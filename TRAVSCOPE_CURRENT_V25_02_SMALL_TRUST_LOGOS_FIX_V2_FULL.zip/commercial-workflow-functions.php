<?php
/*
|--------------------------------------------------------------------------
| TRAVSCOPE STEP 11D - COMMERCIAL WORKFLOW + COMMUNICATION CONTROL
|--------------------------------------------------------------------------
| Additive helper layer. It does not replace CRM/supplier/booking records.
| It records commercial state, structured customer change requests and a
| unified timeline across the existing communication tables.
*/

if (!function_exists('tsCWTableExists')) {
function tsCWTableExists(PDO $pdo, string $table): bool
{
    try {
        $stmt = $pdo->prepare('SHOW TABLES LIKE ?');
        $stmt->execute([$table]);
        return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}
}

function tsCWReady(PDO $pdo): bool
{
    return tsCWTableExists($pdo, 'crm_commercial_state')
        && tsCWTableExists($pdo, 'crm_change_requests')
        && tsCWTableExists($pdo, 'crm_commercial_events');
}

function tsCWClassifyChangeRequest(string $text): string
{
    $v = mb_strtolower(trim($text));
    $rules = [
        'dates' => ['date','travel date','departure','arrival','postpone','prepone','reschedule'],
        'hotel' => ['hotel','resort','room','star','3 star','4 star','5 star','accommodation','houseboat'],
        'pax' => ['adult','child','pax','person','traveller','traveler','guest','people'],
        'vehicle' => ['vehicle','car','cab','innova','crysta','tempo','traveller','transfer','pickup','drop'],
        'itinerary' => ['itinerary','day','sightseeing','route','night','stay'],
        'activity' => ['activity','ticket','ride','gondola','shikara','cruise','excursion'],
        'meal' => ['meal','breakfast','dinner','lunch','mapai','cpai','food'],
        'price' => ['price','rate','cost','discount','budget','expensive','cheaper','amount'],
        'documents' => ['passport','visa','document','aadhaar','aadhar'],
    ];
    foreach ($rules as $type => $words) {
        foreach ($words as $word) {
            if ($word !== '' && mb_strpos($v, $word) !== false) return $type;
        }
    }
    return 'other';
}

function tsCWLatestQuotation(PDO $pdo, int $leadId): ?array
{
    if ($leadId <= 0 || !tsCWTableExists($pdo, 'crm_package_versions')) return null;
    $stmt = $pdo->prepare("SELECT * FROM crm_package_versions WHERE lead_id=? ORDER BY version_number DESC,id DESC LIMIT 1");
    $stmt->execute([$leadId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsCWTrip(PDO $pdo, int $tripId): ?array
{
    if ($tripId <= 0 || !tsCWTableExists($pdo, 'trips')) return null;
    $stmt = $pdo->prepare("SELECT t.*,e.name customer_name,e.email customer_email,e.mobile customer_mobile,e.destination enquiry_destination,e.travel_date enquiry_travel_date FROM trips t JOIN enquiries e ON e.id=t.enquiry_id WHERE t.id=? LIMIT 1");
    $stmt->execute([$tripId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsCWEvent(
    PDO $pdo,
    int $tripId,
    int $leadId,
    string $eventType,
    string $summary,
    string $details = '',
    string $actorType = 'system',
    ?int $actorId = null,
    string $channel = 'system',
    ?int $quotationVersionId = null,
    ?int $supplierRequestId = null,
    ?int $changeRequestId = null,
    ?int $bookingId = null,
    array $meta = []
): void {
    if (!tsCWTableExists($pdo, 'crm_commercial_events')) return;
    $stmt = $pdo->prepare("INSERT INTO crm_commercial_events (trip_id,lead_id,booking_id,quotation_version_id,supplier_request_id,change_request_id,event_type,actor_type,actor_id,channel,summary,details,meta_json,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())");
    $stmt->execute([
        $tripId > 0 ? $tripId : null,
        $leadId > 0 ? $leadId : null,
        $bookingId ?: null,
        $quotationVersionId ?: null,
        $supplierRequestId ?: null,
        $changeRequestId ?: null,
        mb_substr(trim($eventType), 0, 80),
        in_array($actorType, ['admin','customer','supplier','system'], true) ? $actorType : 'system',
        $actorId ?: null,
        in_array($channel, ['portal','email','whatsapp','phone','internal','system'], true) ? $channel : 'system',
        mb_substr(trim($summary), 0, 255),
        trim($details) !== '' ? trim($details) : null,
        $meta ? json_encode($meta, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : null,
    ]);
}

function tsCWSetState(PDO $pdo, int $tripId, int $leadId, string $status, string $reason = '', array $extra = []): void
{
    if ($tripId <= 0 || !tsCWTableExists($pdo, 'crm_commercial_state')) return;
    $allowed = [
        'clean','supplier_cost_changed','requote_required','requote_prepared',
        'awaiting_customer','customer_change_requested','customer_accepted','customer_rejected'
    ];
    if (!in_array($status, $allowed, true)) $status = 'clean';

    $latest = tsCWLatestQuotation($pdo, $leadId);
    $versionId = isset($extra['quotation_version_id']) ? (int)$extra['quotation_version_id'] : (int)($latest['id'] ?? 0);
    $changeRequestId = isset($extra['change_request_id']) ? (int)$extra['change_request_id'] : 0;
    $supplierRequestId = isset($extra['supplier_request_id']) ? (int)$extra['supplier_request_id'] : 0;

    $stmt = $pdo->prepare("INSERT INTO crm_commercial_state (trip_id,lead_id,status,current_quotation_version_id,last_customer_request_id,last_supplier_request_id,last_cost_change_at,last_quotation_at,last_customer_action_at,last_supplier_action_at,reason_text,created_at,updated_at) VALUES (?,?,?,?,?,?,?, ?,?,?,?,NOW(),NOW()) ON DUPLICATE KEY UPDATE lead_id=VALUES(lead_id),status=VALUES(status),current_quotation_version_id=CASE WHEN VALUES(current_quotation_version_id) IS NOT NULL THEN VALUES(current_quotation_version_id) ELSE current_quotation_version_id END,last_customer_request_id=CASE WHEN VALUES(last_customer_request_id) IS NOT NULL THEN VALUES(last_customer_request_id) ELSE last_customer_request_id END,last_supplier_request_id=CASE WHEN VALUES(last_supplier_request_id) IS NOT NULL THEN VALUES(last_supplier_request_id) ELSE last_supplier_request_id END,last_cost_change_at=CASE WHEN VALUES(last_cost_change_at) IS NOT NULL THEN VALUES(last_cost_change_at) ELSE last_cost_change_at END,last_quotation_at=CASE WHEN VALUES(last_quotation_at) IS NOT NULL THEN VALUES(last_quotation_at) ELSE last_quotation_at END,last_customer_action_at=CASE WHEN VALUES(last_customer_action_at) IS NOT NULL THEN VALUES(last_customer_action_at) ELSE last_customer_action_at END,last_supplier_action_at=CASE WHEN VALUES(last_supplier_action_at) IS NOT NULL THEN VALUES(last_supplier_action_at) ELSE last_supplier_action_at END,reason_text=VALUES(reason_text),updated_at=NOW()");

    $now = date('Y-m-d H:i:s');
    $costAt = in_array($status, ['supplier_cost_changed','requote_required'], true) ? $now : null;
    $quoteAt = in_array($status, ['requote_prepared','awaiting_customer'], true) ? $now : null;
    $customerAt = str_starts_with($status, 'customer_') ? $now : null;
    $supplierAt = isset($extra['supplier_action']) && $extra['supplier_action'] ? $now : null;

    $stmt->execute([
        $tripId,$leadId,$status,$versionId ?: null,$changeRequestId ?: null,$supplierRequestId ?: null,
        $costAt,$quoteAt,$customerAt,$supplierAt,mb_substr(trim($reason),0,1000)
    ]);
}

function tsCWCreateChangeRequest(PDO $pdo, array $input): int
{
    if (!tsCWTableExists($pdo, 'crm_change_requests')) return 0;
    $leadId = max(0, (int)($input['lead_id'] ?? 0));
    $tripId = max(0, (int)($input['trip_id'] ?? 0));
    $text = trim((string)($input['request_text'] ?? ''));
    if ($leadId <= 0 || $text === '') return 0;
    $type = trim((string)($input['request_type'] ?? ''));
    if ($type === '' || $type === 'auto') $type = tsCWClassifyChangeRequest($text);
    $allowedTypes = ['dates','hotel','pax','vehicle','itinerary','activity','meal','price','documents','other'];
    if (!in_array($type, $allowedTypes, true)) $type = 'other';
    $source = (string)($input['source'] ?? 'admin');
    if (!in_array($source, ['customer_portal','email','whatsapp','phone','admin','supplier'], true)) $source = 'admin';
    $priority = (string)($input['priority'] ?? 'normal');
    if (!in_array($priority, ['normal','high','urgent'], true)) $priority = 'normal';

    $quoteId = ((int)($input['quotation_version_id'] ?? 0)) ?: null;
    if ($quoteId && in_array($source, ['customer_portal','email','whatsapp'], true)) {
        $dupe=$pdo->prepare("SELECT id FROM crm_change_requests WHERE lead_id=? AND quotation_version_id=? AND source=? AND request_text=? AND status NOT IN ('resolved','rejected') ORDER BY id DESC LIMIT 1");
        $dupe->execute([$leadId,$quoteId,$source,$text]);
        $existing=(int)($dupe->fetchColumn()?:0);
        if($existing>0) return $existing;
    }

    $stmt = $pdo->prepare("INSERT INTO crm_change_requests (lead_id,trip_id,quotation_version_id,booking_id,source,request_type,request_text,status,priority,requested_by_name,requested_by_email,assigned_admin_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())");
    $stmt->execute([
        $leadId,$tripId ?: null,$quoteId,((int)($input['booking_id'] ?? 0)) ?: null,
        $source,$type,$text,'open',$priority,
        trim((string)($input['requested_by_name'] ?? '')) ?: null,
        trim((string)($input['requested_by_email'] ?? '')) ?: null,
        ((int)($input['assigned_admin_id'] ?? 0)) ?: null,
    ]);
    $id = (int)$pdo->lastInsertId();
    if ($tripId > 0) {
        tsCWSetState($pdo,$tripId,$leadId,'customer_change_requested','Customer change request requires a revised quotation.',[
            'quotation_version_id'=>(int)($input['quotation_version_id'] ?? 0),
            'change_request_id'=>$id,
        ]);
    }
    tsCWEvent($pdo,$tripId,$leadId,'customer_change_request','Change request received',$text,
        $source === 'customer_portal' ? 'customer' : ($source === 'supplier' ? 'supplier' : 'admin'),
        ((int)($input['actor_id'] ?? 0)) ?: null,
        $source === 'customer_portal' ? 'portal' : ($source === 'admin' ? 'internal' : $source),
        ((int)($input['quotation_version_id'] ?? 0)) ?: null,null,$id,((int)($input['booking_id'] ?? 0)) ?: null,
        ['request_type'=>$type,'priority'=>$priority]
    );
    return $id;
}

function tsCWMarkSupplierCostChanged(PDO $pdo, int $tripId, int $leadId, string $reason, ?int $supplierRequestId = null, array $meta = []): void
{
    if ($tripId <= 0) return;
    $latest = tsCWLatestQuotation($pdo,$leadId);
    $status = $latest ? 'requote_required' : 'supplier_cost_changed';
    tsCWSetState($pdo,$tripId,$leadId,$status,$reason,[
        'quotation_version_id'=>(int)($latest['id'] ?? 0),
        'supplier_request_id'=>$supplierRequestId ?: 0,
        'supplier_action'=>true,
    ]);
    tsCWEvent($pdo,$tripId,$leadId,'supplier_cost_changed','Supplier cost changed',$reason,'admin',null,'internal',(int)($latest['id'] ?? 0),$supplierRequestId,null,null,$meta);
}

function tsCWMarkQuotationPrepared(PDO $pdo, int $tripId, int $leadId, int $versionId, int $adminId = 0): void
{
    if ($tripId > 0 && tsCWTableExists($pdo,'crm_change_requests')) {
        $stmt=$pdo->prepare("UPDATE crm_change_requests SET status='requote_prepared',updated_at=NOW() WHERE trip_id=? AND status IN ('open','in_review')");
        $stmt->execute([$tripId]);
    }
    tsCWSetState($pdo,$tripId,$leadId,'requote_prepared','New quotation version prepared.',[
        'quotation_version_id'=>$versionId
    ]);
    tsCWEvent($pdo,$tripId,$leadId,'quotation_prepared','Revised quotation prepared','Quotation Version ID '.$versionId,'admin',$adminId ?: null,'internal',$versionId);
}

function tsCWMarkQuotationSent(PDO $pdo, int $tripId, int $leadId, int $versionId, int $adminId = 0, string $channel='email'): void
{
    tsCWSetState($pdo,$tripId,$leadId,'awaiting_customer','Quotation sent; awaiting customer decision.',[
        'quotation_version_id'=>$versionId
    ]);
    tsCWEvent($pdo,$tripId,$leadId,'quotation_sent','Quotation sent to customer','Awaiting customer response.','admin',$adminId ?: null,$channel,$versionId);
}

function tsCWMarkCustomerDecision(PDO $pdo, int $tripId, int $leadId, int $versionId, string $decision, string $note=''): void
{
    $status = match($decision) {
        'accepted' => 'customer_accepted',
        'change_requested' => 'customer_change_requested',
        'rejected' => 'customer_rejected',
        default => 'awaiting_customer',
    };
    tsCWSetState($pdo,$tripId,$leadId,$status,$note !== '' ? $note : str_replace('_',' ',$decision),[
        'quotation_version_id'=>$versionId
    ]);
    tsCWEvent($pdo,$tripId,$leadId,'customer_'.$decision,'Customer '.str_replace('_',' ',$decision),$note,'customer',null,'portal',$versionId);
}

function tsCWState(PDO $pdo, int $tripId): ?array
{
    if ($tripId<=0 || !tsCWTableExists($pdo,'crm_commercial_state')) return null;
    $stmt=$pdo->prepare("SELECT * FROM crm_commercial_state WHERE trip_id=? LIMIT 1");
    $stmt->execute([$tripId]);
    $r=$stmt->fetch(PDO::FETCH_ASSOC);
    return $r?:null;
}

function tsCWChangeRequests(PDO $pdo, int $tripId): array
{
    if (!tsCWTableExists($pdo,'crm_change_requests')) return [];
    $stmt=$pdo->prepare("SELECT * FROM crm_change_requests WHERE trip_id=? ORDER BY FIELD(status,'open','in_review','requote_prepared','responded','resolved','rejected'),created_at DESC,id DESC");
    $stmt->execute([$tripId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function tsCWTimeline(PDO $pdo, int $tripId, int $leadId, int $limit=120): array
{
    $items=[];
    if (tsCWTableExists($pdo,'crm_commercial_events')) {
        $stmt=$pdo->prepare("SELECT created_at ts,actor_type actor,channel,event_type kind,summary,details FROM crm_commercial_events WHERE trip_id=? OR (trip_id IS NULL AND lead_id=?) ORDER BY created_at DESC LIMIT 100");
        $stmt->execute([$tripId,$leadId]);
        foreach($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $r) $items[]=$r;
    }
    if (tsCWTableExists($pdo,'crm_quotation_messages')) {
        $stmt=$pdo->prepare("SELECT m.sent_at ts,CASE WHEN m.direction='inbound' THEN 'customer' ELSE 'admin' END actor,'email' channel,CONCAT('quotation_',m.direction) kind,COALESCE(m.subject,'Quotation message') summary,m.body_text details FROM crm_quotation_messages m WHERE m.lead_id=? ORDER BY m.sent_at DESC LIMIT 80");
        $stmt->execute([$leadId]);
        foreach($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $r) $items[]=$r;
    }
    if (tsCWTableExists($pdo,'supplier_request_messages') && tsCWTableExists($pdo,'supplier_requests')) {
        $stmt=$pdo->prepare("SELECT COALESCE(m.sent_at,m.created_at) ts,CASE WHEN m.sender_type='supplier' THEN 'supplier' ELSE 'admin' END actor,COALESCE(m.channel,'internal') channel,'supplier_message' kind,CONCAT('Supplier ',m.sender_type,' message') summary,m.message details FROM supplier_request_messages m JOIN supplier_requests r ON r.id=m.supplier_request_id WHERE r.trip_id=? ORDER BY COALESCE(m.sent_at,m.created_at) DESC LIMIT 80");
        $stmt->execute([$tripId]);
        foreach($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $r) $items[]=$r;
    }
    if (tsCWTableExists($pdo,'crm_activities')) {
        $stmt=$pdo->prepare("SELECT created_at ts,'admin' actor,'internal' channel,activity_type kind,subject summary,details FROM crm_activities WHERE lead_id=? ORDER BY created_at DESC LIMIT 80");
        $stmt->execute([$leadId]);
        foreach($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $r) $items[]=$r;
    }
    if (tsCWTableExists($pdo,'booking_communications')) {
        $stmt=$pdo->prepare("SELECT COALESCE(sent_at,created_at) ts,CASE WHEN direction='inbound' THEN 'customer' WHEN direction='internal' THEN 'admin' ELSE 'system' END actor,channel,CONCAT('booking_',direction) kind,COALESCE(subject,'Booking communication') summary,body_text details FROM booking_communications WHERE trip_id=? ORDER BY COALESCE(sent_at,created_at) DESC LIMIT 80");
        $stmt->execute([$tripId]);
        foreach($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $r) $items[]=$r;
    }
    usort($items, static fn($a,$b)=>strcmp((string)($b['ts']??''),(string)($a['ts']??'')));
    return array_slice($items,0,max(10,$limit));
}

function tsCWBookingForTrip(PDO $pdo, int $tripId): ?array
{
    if (!tsCWTableExists($pdo,'booking_trip_links') || !tsCWTableExists($pdo,'bookings')) return null;
    $stmt=$pdo->prepare("SELECT b.*,l.quotation_version_id,l.expected_total_cost,l.expected_selling_price,l.expected_margin_amount FROM booking_trip_links l JOIN bookings b ON b.id=l.booking_id WHERE l.trip_id=? LIMIT 1");
    $stmt->execute([$tripId]);
    $r=$stmt->fetch(PDO::FETCH_ASSOC);
    return $r?:null;
}
