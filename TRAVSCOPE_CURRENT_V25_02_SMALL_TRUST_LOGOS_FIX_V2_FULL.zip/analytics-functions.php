<?php
declare(strict_types=1);

$tsAnalyticsSystemSettingsFile = __DIR__ . '/system-settings-functions.php';
if (
    is_file($tsAnalyticsSystemSettingsFile)
    && !function_exists('tsSystemSettingInt')
) {
    require_once $tsAnalyticsSystemSettingsFile;
}

function tsAnTableExists(PDO $pdo, string $table): bool {
    static $cache=[];
    $k=strtolower($table);
    if(array_key_exists($k,$cache)) return $cache[$k];
    if(!preg_match('/^[A-Za-z0-9_]+$/',$table)) return false;
    try{
        $s=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
        $s->execute([$table]);
        return $cache[$k]=((int)$s->fetchColumn()>0);
    }catch(Throwable $e){ return $cache[$k]=false; }
}

function tsAnRepeatReady(PDO $pdo): bool {
    return tsAnTableExists($pdo,'repeat_sales_opportunities');
}

function tsAnDays($v): int {
    $d=(int)$v;
    return in_array($d,[30,90,180,365,1095],true)?$d:90;
}

function tsAnStart(int $days): string {
    return date('Y-m-d 00:00:00',strtotime('-'.max(1,$days-1).' days'));
}

function tsAnPct(float $a,float $b): float {
    return $b>0?round(($a/$b)*100,1):0.0;
}

function tsAnScalar(PDO $pdo,string $sql,array $params=[]): float {
    try{
        $s=$pdo->prepare($sql); $s->execute($params);
        return (float)($s->fetchColumn()?:0);
    }catch(Throwable $e){
        error_log('Analytics scalar: '.$e->getMessage());
        return 0.0;
    }
}

function tsAnOverview(PDO $pdo,int $days): array {
    $start=tsAnStart($days);
    $leads=tsAnTableExists($pdo,'enquiries')?tsAnScalar($pdo,"SELECT COUNT(*) FROM enquiries WHERE created_at>=?",[$start]):0;
    $quoted=tsAnTableExists($pdo,'crm_package_versions')?tsAnScalar($pdo,"SELECT COUNT(DISTINCT lead_id) FROM crm_package_versions WHERE created_at>=?",[$start]):0;
    $accepted=tsAnTableExists($pdo,'quotation_acceptances')?tsAnScalar($pdo,"SELECT COUNT(*) FROM quotation_acceptances WHERE accepted_at>=?",[$start]):0;
    $bookings=$sales=$collected=$outstanding=0;
    if(tsAnTableExists($pdo,'bookings')){
        $bookings=tsAnScalar($pdo,"SELECT COUNT(*) FROM bookings WHERE created_at>=? AND booking_status<>'cancelled'",[$start]);
        $sales=tsAnScalar($pdo,"SELECT COALESCE(SUM(total_amount),0) FROM bookings WHERE created_at>=? AND booking_status<>'cancelled'",[$start]);
        $collected=tsAnScalar($pdo,"SELECT COALESCE(SUM(paid_amount),0) FROM bookings WHERE created_at>=? AND booking_status<>'cancelled'",[$start]);
        $outstanding=tsAnScalar($pdo,"SELECT COALESCE(SUM(GREATEST(total_amount-paid_amount,0)),0) FROM bookings WHERE booking_status<>'cancelled'");
    }
    $expected=$actual=0;
    if(tsAnTableExists($pdo,'booking_profitability_closures')){
        $expected=tsAnScalar($pdo,"SELECT COALESCE(SUM(expected_margin),0) FROM booking_profitability_closures WHERE closed_at>=?",[$start]);
        $actual=tsAnScalar($pdo,"SELECT COALESCE(SUM(actual_margin),0) FROM booking_profitability_closures WHERE closed_at>=?",[$start]);
    }
    $repeat=tsAnRepeatReady($pdo)?tsAnScalar($pdo,"SELECT COUNT(*) FROM repeat_sales_opportunities WHERE status IN('new','contact_due','contacted','interested','deferred') AND (next_action_date IS NULL OR next_action_date<=CURDATE())"):0;
    return [
        'leads'=>$leads,'quoted'=>$quoted,'accepted'=>$accepted,'bookings'=>$bookings,
        'sales'=>$sales,'collected'=>$collected,'outstanding'=>$outstanding,
        'expected_margin'=>$expected,'actual_margin'=>$actual,'repeat_due'=>$repeat,
        'lead_booking'=>tsAnPct($bookings,$leads),
        'quote_acceptance'=>tsAnPct($accepted,$quoted),
        'collection'=>tsAnPct($collected,$sales),
    ];
}

function tsAnLeadSources(PDO $pdo,int $days): array {
    if(!tsAnTableExists($pdo,'enquiries')) return [];
    $start=tsAnStart($days);
    $meta=tsAnTableExists($pdo,'crm_lead_meta');
    $links=tsAnTableExists($pdo,'booking_trip_links')&&tsAnTableExists($pdo,'bookings');
    $source=$meta?"COALESCE(NULLIF(m.lead_source,''),'website')":"'website'";
    $mjoin=$meta?"LEFT JOIN crm_lead_meta m ON m.enquiry_id=e.id":"";
    $bjoin=$links?"LEFT JOIN booking_trip_links l ON l.enquiry_id=e.id LEFT JOIN bookings b ON b.id=l.booking_id AND b.booking_status<>'cancelled'":"";
    $conv=$links?"COUNT(DISTINCT CASE WHEN b.id IS NOT NULL THEN e.id END)":"SUM(CASE WHEN e.status='converted' THEN 1 ELSE 0 END)";
    $value=$links?"COALESCE(SUM(CASE WHEN b.id IS NOT NULL THEN b.total_amount ELSE 0 END),0)":"0";
    try{
        $s=$pdo->prepare("SELECT {$source} source_name,COUNT(DISTINCT e.id) leads,{$conv} converted,{$value} booked_value FROM enquiries e {$mjoin} {$bjoin} WHERE e.created_at>=? GROUP BY source_name ORDER BY converted DESC,leads DESC");
        $s->execute([$start]); $rows=$s->fetchAll(PDO::FETCH_ASSOC)?:[];
        foreach($rows as &$r){$r['conversion']=tsAnPct((float)$r['converted'],(float)$r['leads']);} unset($r);
        return $rows;
    }catch(Throwable $e){ error_log('Analytics sources: '.$e->getMessage()); return []; }
}

function tsAnDestinations(PDO $pdo,int $days): array {
    if(!tsAnTableExists($pdo,'enquiries')) return [];
    $start=tsAnStart($days);
    $links=tsAnTableExists($pdo,'booking_trip_links')&&tsAnTableExists($pdo,'bookings');
    $bjoin=$links?"LEFT JOIN booking_trip_links l ON l.enquiry_id=e.id LEFT JOIN bookings b ON b.id=l.booking_id AND b.booking_status<>'cancelled'":"";
    $conv=$links?"COUNT(DISTINCT CASE WHEN b.id IS NOT NULL THEN e.id END)":"SUM(CASE WHEN e.status='converted' THEN 1 ELSE 0 END)";
    $value=$links?"COALESCE(SUM(CASE WHEN b.id IS NOT NULL THEN b.total_amount ELSE 0 END),0)":"0";
    try{
        $s=$pdo->prepare("SELECT COALESCE(NULLIF(e.destination,''),'Unspecified') destination_name,COUNT(DISTINCT e.id) leads,{$conv} converted,{$value} booked_value FROM enquiries e {$bjoin} WHERE e.created_at>=? GROUP BY destination_name ORDER BY converted DESC,leads DESC LIMIT 20");
        $s->execute([$start]); $rows=$s->fetchAll(PDO::FETCH_ASSOC)?:[];
        foreach($rows as &$r){$r['conversion']=tsAnPct((float)$r['converted'],(float)$r['leads']);} unset($r);
        return $rows;
    }catch(Throwable $e){ error_log('Analytics destinations: '.$e->getMessage()); return []; }
}

function tsAnCollectionAging(PDO $pdo): array {
    $out=['overdue'=>[0,0.0],'due7'=>[0,0.0],'due30'=>[0,0.0],'later'=>[0,0.0],'unscheduled'=>[0,0.0]];
    if(tsAnTableExists($pdo,'booking_payment_installments')&&tsAnTableExists($pdo,'booking_payment_schedules')){
        try{
            $q=$pdo->query("SELECT CASE WHEN i.due_date IS NULL THEN 'unscheduled' WHEN i.due_date<CURDATE() THEN 'overdue' WHEN i.due_date<=DATE_ADD(CURDATE(),INTERVAL 7 DAY) THEN 'due7' WHEN i.due_date<=DATE_ADD(CURDATE(),INTERVAL 30 DAY) THEN 'due30' ELSE 'later' END bucket,COUNT(*) c,COALESCE(SUM(GREATEST(i.amount-i.paid_amount,0)),0) a FROM booking_payment_installments i JOIN booking_payment_schedules s ON s.id=i.schedule_id WHERE s.status='active' AND i.status IN('pending','partially_paid') GROUP BY bucket");
            foreach($q->fetchAll(PDO::FETCH_ASSOC)?:[] as $r){$out[$r['bucket']]=[(int)$r['c'],(float)$r['a']];}
            return $out;
        }catch(Throwable $e){}
    }
    if(tsAnTableExists($pdo,'bookings')){
        $out['unscheduled']=[(int)tsAnScalar($pdo,"SELECT COUNT(*) FROM bookings WHERE booking_status<>'cancelled' AND total_amount>paid_amount"),tsAnScalar($pdo,"SELECT COALESCE(SUM(GREATEST(total_amount-paid_amount,0)),0) FROM bookings WHERE booking_status<>'cancelled'")];
    }
    return $out;
}


function tsAnSuppliers(PDO $pdo,int $days): array {
    if(!tsAnTableExists($pdo,'supplier_booking_orders')||!tsAnTableExists($pdo,'suppliers')) return [];
    $start=tsAnStart($days);
    try{
        $s=$pdo->prepare("SELECT s.id supplier_id,s.company_name,s.priority,s.internal_rating,COUNT(o.id) orders,SUM(CASE WHEN o.status='supplier_confirmed' THEN 1 ELSE 0 END) confirmed,SUM(CASE WHEN o.status IN('rejected','alternative_required','partially_confirmed') THEN 1 ELSE 0 END) problems,AVG(CASE WHEN o.sent_at IS NOT NULL AND o.first_response_at IS NOT NULL THEN TIMESTAMPDIFF(MINUTE,o.sent_at,o.first_response_at)/60 ELSE NULL END) response_hours FROM suppliers s JOIN supplier_booking_orders o ON o.supplier_id=s.id WHERE o.created_at>=? GROUP BY s.id,s.company_name,s.priority,s.internal_rating ORDER BY confirmed DESC,problems ASC,orders DESC LIMIT 20");
        $s->execute([$start]); $rows=$s->fetchAll(PDO::FETCH_ASSOC)?:[];
        foreach($rows as &$r){$r['rate']=tsAnPct((float)$r['confirmed'],(float)$r['orders']); if($r['response_hours']!==null)$r['response_hours']=round((float)$r['response_hours'],1);} unset($r);
        return $rows;
    }catch(Throwable $e){error_log('Analytics suppliers: '.$e->getMessage());return [];}
}

function tsAnMarginTrend(PDO $pdo): array {
    if(!tsAnTableExists($pdo,'booking_profitability_closures')) return [];
    try{
        $q=$pdo->query("SELECT DATE_FORMAT(closed_at,'%Y-%m') month_key,DATE_FORMAT(closed_at,'%b %Y') month_label,COUNT(*) trips,COALESCE(SUM(expected_margin),0) expected_margin,COALESCE(SUM(actual_margin),0) actual_margin FROM booking_profitability_closures WHERE closed_at>=DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 11 MONTH),'%Y-%m-01') GROUP BY month_key,month_label ORDER BY month_key");
        return $q->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $e){return [];}
}

function tsAnDepartureRisks(PDO $pdo,int $days=30): array {
    if(!tsAnTableExists($pdo,'bookings')) return [];
    try{
        $s=$pdo->prepare("SELECT id,booking_number,customer_name,travel_date,total_amount,paid_amount,currency FROM bookings WHERE booking_status IN('pending','confirmed') AND travel_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL ? DAY) ORDER BY travel_date LIMIT 80");
        $s->execute([$days]); $out=[];
        foreach($s->fetchAll(PDO::FETCH_ASSOC)?:[] as $b){
            $id=(int)$b['id']; $reasons=[]; $balance=max(0,(float)$b['total_amount']-(float)$b['paid_amount']);
            if($balance>.01)$reasons[]='Customer balance';
            if(tsAnTableExists($pdo,'booking_service_snapshots')){
                $q=$pdo->prepare("SELECT COUNT(*) FROM booking_service_snapshots WHERE booking_id=? AND source_supplier_id IS NOT NULL AND procurement_status NOT IN('confirmed','cancelled')");
                $q->execute([$id]); if((int)$q->fetchColumn()>0)$reasons[]='Supplier confirmation';
            }
            if(tsAnTableExists($pdo,'booking_voucher_versions')){
                $q=$pdo->prepare("SELECT COUNT(*) FROM booking_voucher_versions WHERE booking_id=? AND status='final'");
                $q->execute([$id]); if((int)$q->fetchColumn()===0)$reasons[]='Final voucher';
            }
            if(tsAnTableExists($pdo,'booking_document_pack_versions')){
                $q=$pdo->prepare("SELECT COUNT(*) FROM booking_document_pack_versions WHERE booking_id=? AND status='final'");
                $q->execute([$id]); if((int)$q->fetchColumn()===0)$reasons[]='Document pack';
            }
            if(tsAnTableExists($pdo,'booking_communication_jobs')){
                $q=$pdo->prepare("SELECT COUNT(*) FROM booking_communication_jobs WHERE booking_id=? AND status IN('pending','failed') AND due_at<=NOW()");
                $q->execute([$id]); if((int)$q->fetchColumn()>0)$reasons[]='Communication follow-up';
            }
            if($reasons){$b['balance']=$balance;$b['reasons']=$reasons;$out[]=$b;}
        }
        return array_slice($out,0,30);
    }catch(Throwable $e){error_log('Analytics departures: '.$e->getMessage());return [];}
}

function tsAnCustomers(PDO $pdo): array {
    if(!tsAnTableExists($pdo,'bookings')) return [];
    $margin=tsAnTableExists($pdo,'booking_profitability_closures');
    $join=$margin?"LEFT JOIN booking_profitability_closures pc ON pc.booking_id=b.id":"";
    $mexpr=$margin?"COALESCE(SUM(pc.actual_margin),0)":"0";
    try{
        $q=$pdo->query("SELECT COALESCE(NULLIF(b.customer_email,''),CONCAT('USER#',COALESCE(b.user_id,0))) customer_key,MAX(b.customer_name) customer_name,COUNT(*) bookings,COALESCE(SUM(CASE WHEN b.booking_status<>'cancelled' THEN b.total_amount ELSE 0 END),0) lifetime_sales,{$mexpr} actual_margin,MAX(b.travel_date) last_travel_date FROM bookings b {$join} GROUP BY customer_key ORDER BY lifetime_sales DESC,bookings DESC LIMIT 25");
        return $q->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $e){return [];}
}

function tsAnOwners(PDO $pdo,int $days): array {
    if(!tsAnTableExists($pdo,'crm_lead_meta')||!tsAnTableExists($pdo,'enquiries')||!tsAnTableExists($pdo,'admins'))return [];
    $start=tsAnStart($days); $links=tsAnTableExists($pdo,'booking_trip_links')&&tsAnTableExists($pdo,'bookings');
    $join=$links?"LEFT JOIN booking_trip_links l ON l.enquiry_id=e.id LEFT JOIN bookings b ON b.id=l.booking_id AND b.booking_status<>'cancelled'":"";
    $conv=$links?"COUNT(DISTINCT CASE WHEN b.id IS NOT NULL THEN e.id END)":"SUM(CASE WHEN e.status='converted' THEN 1 ELSE 0 END)";
    $value=$links?"COALESCE(SUM(CASE WHEN b.id IS NOT NULL THEN b.total_amount ELSE 0 END),0)":"0";
    try{
        $s=$pdo->prepare("SELECT COALESCE(a.name,'Unassigned') admin_name,COUNT(DISTINCT e.id) leads,{$conv} converted,{$value} booked_value,SUM(CASE WHEN m.next_follow_up_at IS NOT NULL AND m.next_follow_up_at<NOW() AND e.status NOT IN('converted','closed') THEN 1 ELSE 0 END) overdue FROM crm_lead_meta m JOIN enquiries e ON e.id=m.enquiry_id LEFT JOIN admins a ON a.id=m.assigned_admin_id {$join} WHERE e.created_at>=? GROUP BY a.id,a.name ORDER BY converted DESC,booked_value DESC");
        $s->execute([$start]);$rows=$s->fetchAll(PDO::FETCH_ASSOC)?:[];
        foreach($rows as &$r){$r['conversion']=tsAnPct((float)$r['converted'],(float)$r['leads']);}unset($r);return $rows;
    }catch(Throwable $e){return [];}
}

function tsAnAdmins(PDO $pdo): array {
    if(!tsAnTableExists($pdo,'admins'))return [];
    try{return $pdo->query("SELECT id,name,role FROM admins WHERE status='active' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC)?:[];}catch(Throwable $e){return [];}
}

function tsAnSyncRepeat(PDO $pdo,int $adminId=0): int {
    if(!tsAnRepeatReady($pdo)||!tsAnTableExists($pdo,'bookings'))return 0;
    $hasExec=tsAnTableExists($pdo,'booking_execution_states');
    $hasTrips=tsAnTableExists($pdo,'booking_trip_links')&&tsAnTableExists($pdo,'trips');
    $execJoin=$hasExec?"LEFT JOIN booking_execution_states ex ON ex.booking_id=b.id":"";
    $tripJoin=$hasTrips?"LEFT JOIN booking_trip_links l ON l.booking_id=b.id LEFT JOIN trips t ON t.id=l.trip_id":"";
    $tripSel=$hasTrips?"t.id source_trip_id,t.owner_admin_id,t.destination_id source_destination_id":"NULL source_trip_id,NULL owner_admin_id,NULL source_destination_id";
    $completed=$hasExec?"(b.booking_status='completed' OR ex.execution_status='completed')":"b.booking_status='completed'";
    $completion=$hasExec?"DATE(COALESCE(ex.completed_at,b.updated_at))":"DATE(b.updated_at)";
    $repeatFollowupDays =
        function_exists('tsSystemSettingInt')
            ? tsSystemSettingInt(
                $pdo,
                'ops_repeat_sales_followup_days',
                30
            )
            : 30;
    $next=$hasExec
        ?"COALESCE(ex.repeat_followup_date,DATE_ADD(DATE(COALESCE(ex.completed_at,b.updated_at)),INTERVAL ".(int)$repeatFollowupDays." DAY))"
        :"DATE_ADD(DATE(b.updated_at),INTERVAL ".(int)$repeatFollowupDays." DAY)";
    try{
        $q=$pdo->query("SELECT b.id source_booking_id,{$tripSel},b.user_id,b.customer_name,b.customer_email,b.customer_mobile,b.travel_date,{$completion} completion_date,{$next} next_action_date FROM bookings b {$execJoin} {$tripJoin} WHERE {$completed}");
        $ins=$pdo->prepare("INSERT IGNORE INTO repeat_sales_opportunities(source_booking_id,source_trip_id,customer_user_id,customer_name,customer_email,customer_mobile,source_destination_id,source_travel_date,completion_date,status,owner_admin_id,next_action_date,created_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,'new',?,?,?)");
        $n=0;
        foreach($q->fetchAll(PDO::FETCH_ASSOC)?:[] as $r){
            $ins->execute([(int)$r['source_booking_id'],$r['source_trip_id']?(int)$r['source_trip_id']:null,$r['user_id']?(int)$r['user_id']:null,(string)$r['customer_name'],trim((string)$r['customer_email'])?:null,trim((string)$r['customer_mobile'])?:null,$r['source_destination_id']?(int)$r['source_destination_id']:null,$r['travel_date']?:null,$r['completion_date']?:null,$r['owner_admin_id']?(int)$r['owner_admin_id']:null,$r['next_action_date']?:date('Y-m-d',strtotime('+'.$repeatFollowupDays.' days')),$adminId?:null]);
            $n+=$ins->rowCount();
        }
        $pdo->exec("UPDATE repeat_sales_opportunities SET status='contact_due' WHERE status IN('new','deferred') AND next_action_date IS NOT NULL AND next_action_date<=CURDATE()");
        if(tsAnTableExists($pdo,'booking_trip_links')){
            $pdo->exec("UPDATE repeat_sales_opportunities r JOIN booking_trip_links l ON l.enquiry_id=r.linked_enquiry_id JOIN bookings b ON b.id=l.booking_id SET r.status='booked',r.linked_booking_id=b.id,r.linked_trip_id=l.trip_id,r.updated_at=NOW() WHERE r.linked_enquiry_id IS NOT NULL AND b.booking_status<>'cancelled'");
        }
        return $n;
    }catch(Throwable $e){error_log('Repeat sync: '.$e->getMessage());return 0;}
}

function tsAnRepeatRows(PDO $pdo,string $filter='active'): array {
    if(!tsAnRepeatReady($pdo))return [];
    $where=match($filter){
        'due'=>"WHERE r.status IN('new','contact_due','contacted','interested','deferred') AND (r.next_action_date IS NULL OR r.next_action_date<=CURDATE())",
        'won'=>"WHERE r.status IN('enquiry_created','booked')",
        'closed'=>"WHERE r.status IN('booked','not_interested')",
        default=>"WHERE r.status NOT IN('booked','not_interested')",
    };
    $ajoin=tsAnTableExists($pdo,'admins')?"LEFT JOIN admins a ON a.id=r.owner_admin_id":"";
    $asel=tsAnTableExists($pdo,'admins')?"a.name owner_name":"NULL owner_name";
    try{return $pdo->query("SELECT r.*,{$asel} FROM repeat_sales_opportunities r {$ajoin} {$where} ORDER BY CASE WHEN r.next_action_date IS NULL THEN 1 ELSE 0 END,r.next_action_date,r.updated_at DESC LIMIT 120")->fetchAll(PDO::FETCH_ASSOC)?:[];}catch(Throwable $e){return [];}
}

function tsAnUpdateRepeat(PDO $pdo,int $id,array $in): void {
    if(!tsAnRepeatReady($pdo)||$id<=0)throw new RuntimeException('Repeat Sales SQL is not installed.');
    $status=(string)($in['status']??'new');
    $allowed=['new','contact_due','contacted','interested','enquiry_created','booked','not_interested','deferred'];
    if(!in_array($status,$allowed,true))throw new RuntimeException('Invalid Repeat Sales status.');
    $owner=max(0,(int)($in['owner_admin_id']??0));
    $s=$pdo->prepare("UPDATE repeat_sales_opportunities SET status=?,owner_admin_id=?,next_action_date=?,preferred_destination=?,preferred_travel_date=?,estimated_value=?,notes=?,last_contact_at=CASE WHEN ? IN('contacted','interested') THEN NOW() ELSE last_contact_at END,updated_at=NOW() WHERE id=?");
    $s->execute([$status,$owner?:null,trim((string)($in['next_action_date']??''))?:null,trim((string)($in['preferred_destination']??''))?:null,trim((string)($in['preferred_travel_date']??''))?:null,max(0,(float)($in['estimated_value']??0)),trim((string)($in['notes']??''))?:null,$status,$id]);
}

function tsAnCreateRepeatEnquiry(PDO $pdo,int $id,int $adminId): int {
    if(!tsAnRepeatReady($pdo)||!tsAnTableExists($pdo,'enquiries'))throw new RuntimeException('Repeat Sales / Enquiry system is not ready.');

    $pdo->beginTransaction();
    try{
        $s=$pdo->prepare("SELECT * FROM repeat_sales_opportunities WHERE id=? FOR UPDATE");
        $s->execute([$id]);
        $r=$s->fetch(PDO::FETCH_ASSOC);

        if(!$r)throw new RuntimeException('Repeat Sales opportunity not found.');
        if(!empty($r['linked_enquiry_id']))throw new RuntimeException('CRM Enquiry already exists.');

        $mobile=trim((string)$r['customer_mobile']);
        if($mobile==='')throw new RuntimeException('Customer mobile is required before creating CRM Enquiry.');

        $dest=trim((string)($r['preferred_destination']??''));
        $travel=trim((string)($r['preferred_travel_date']??''));
        $msg='Repeat Sales opportunity from Booking #'.(int)$r['source_booking_id'].'.'.(!empty($r['notes'])?"\n\n".$r['notes']:'');

        $s=$pdo->prepare("INSERT INTO enquiries(name,email,mobile,destination,travel_date,adults,children,budget,message,status,created_at,updated_at) VALUES(?,?,?,?,?,1,0,?,?,'new',NOW(),NOW())");
        $s->execute([
            (string)$r['customer_name'],
            trim((string)$r['customer_email'])?:null,
            $mobile,
            $dest?:null,
            $travel?:null,
            (float)$r['estimated_value']>0?(float)$r['estimated_value']:null,
            $msg
        ]);

        $eid=(int)$pdo->lastInsertId();

        if(tsAnTableExists($pdo,'crm_lead_meta')){
            $m=$pdo->prepare("INSERT INTO crm_lead_meta(enquiry_id,assigned_admin_id,priority,lead_source,campaign_name,lead_score,estimated_value,next_follow_up_at,tags,created_at,updated_at) VALUES(?,?,'high','other','Repeat Sales',80,?,NOW(),?,NOW(),NOW())");
            $m->execute([
                $eid,
                $r['owner_admin_id']?(int)$r['owner_admin_id']:($adminId?:null),
                (float)$r['estimated_value']>0?(float)$r['estimated_value']:null,
                'repeat_customer,source_booking_'.(int)$r['source_booking_id']
            ]);
        }

        $u=$pdo->prepare("UPDATE repeat_sales_opportunities SET status='enquiry_created',linked_enquiry_id=?,last_contact_at=NOW(),next_action_date=CURDATE(),updated_at=NOW() WHERE id=?");
        $u->execute([$eid,$id]);

        $pdo->commit();

    }catch(Throwable $e){
        if($pdo->inTransaction())$pdo->rollBack();
        throw $e;
    }

    /*
     * crmCreateTripForEnquiry manages its own transaction, so call it only
     * AFTER committing the Repeat Sales -> Enquiry transaction.
     */
    if(function_exists('crmCreateTripForEnquiry')){
        try{
            $trip=crmCreateTripForEnquiry($pdo,$eid,$adminId);
            if(!empty($trip['id'])){
                $u=$pdo->prepare("UPDATE repeat_sales_opportunities SET linked_trip_id=?,updated_at=NOW() WHERE id=? AND linked_enquiry_id=?");
                $u->execute([(int)$trip['id'],$id,$eid]);
            }
        }catch(Throwable $e){
            error_log('Repeat Sales Trip create warning: '.$e->getMessage());
        }
    }

    return $eid;
}
