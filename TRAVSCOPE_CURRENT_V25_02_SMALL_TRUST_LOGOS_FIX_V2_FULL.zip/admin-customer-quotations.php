<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/crm-functions.php';
$commercialWorkflowFile = __DIR__ . '/commercial-workflow-functions.php';
if (is_file($commercialWorkflowFile)) require_once $commercialWorkflowFile;

if (function_exists('requireAdmin')) requireAdmin();
elseif (empty($_SESSION['admin_id'])) { header('Location: '.(defined('BASE_URL')?BASE_URL:'').'admin-login.php'); exit; }

function tqx($v): string { return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function tqt(PDO $pdo,string $table): bool {
    if(!preg_match('/^[A-Za-z0-9_]+$/',$table)) return false;
    try{$pdo->query('SELECT 1 FROM `'.$table.'` LIMIT 0');return true;}catch(Throwable $e){return false;}
}
function tqState(PDO $pdo,int $versionId): array {
    $s=['key'=>'prepared','label'=>'Prepared','class'=>'info','response'=>null,'booking'=>null];
    try{
        if(tqt($pdo,'quotation_acceptances') && tqt($pdo,'bookings')){
            $st=$pdo->prepare("SELECT b.id,b.booking_number,b.booking_status,b.payment_status FROM quotation_acceptances a INNER JOIN bookings b ON b.id=a.booking_id WHERE a.quotation_version_id=? ORDER BY a.id DESC LIMIT 1");
            $st->execute([$versionId]); $b=$st->fetch(PDO::FETCH_ASSOC)?:null;
            if($b){$s=['key'=>'converted','label'=>'Booking Created','class'=>'success','response'=>null,'booking'=>$b];return $s;}
        }
    }catch(Throwable $e){}
    try{
        if(tqt($pdo,'quotation_customer_responses')){
            $st=$pdo->prepare("SELECT id,decision,booking_id,customer_note,created_at FROM quotation_customer_responses WHERE quotation_version_id=? ORDER BY id DESC LIMIT 1");
            $st->execute([$versionId]); $r=$st->fetch(PDO::FETCH_ASSOC)?:null;
            if($r){
                $s['response']=$r;
                if(($r['decision']??'')==='accepted'){$s['key']='accepted';$s['label']='Accepted · Review';$s['class']='success';}
                elseif(($r['decision']??'')==='change_requested'){$s['key']='change_requested';$s['label']='Changes Requested';$s['class']='warning';}
                elseif(($r['decision']??'')==='rejected'){$s['key']='rejected';$s['label']='Rejected';$s['class']='danger';}
            }
        }
    }catch(Throwable $e){}
    return $s;
}

$leadFilter=max(0,(int)($_GET['lead']??0));
$rows=[];$total=0;$sent=0;$accepted=0;$converted=0;
try{
    if(tqt($pdo,'crm_package_versions')){
        // Summary numbers reflect this page's bounded, optionally enquiry-filtered record set.
        $sql="SELECT v.id,v.lead_id,v.version_number,v.package_id,v.package_title,v.hotel_category,v.travel_date,v.adults,v.children,v.final_price,v.created_at,v.email_sent_at,e.name customer_name,e.email customer_email,e.mobile customer_mobile,e.destination FROM crm_package_versions v LEFT JOIN enquiries e ON e.id=v.lead_id";
        $args=[];
        if($leadFilter>0){$sql.=' WHERE v.lead_id=?';$args[]=$leadFilter;}
        $sql.=' ORDER BY v.id DESC LIMIT 150';
        $st=$pdo->prepare($sql);$st->execute($args);$rows=$st->fetchAll(PDO::FETCH_ASSOC)?:[];
        foreach($rows as &$r){$r['_state']=tqState($pdo,(int)$r['id']);if(!empty($r['email_sent_at']))$sent++;if($r['_state']['key']==='accepted')$accepted++;if($r['_state']['key']==='converted')$converted++;}unset($r);$total=count($rows);
    }
}catch(Throwable $e){error_log('Quotation desk: '.$e->getMessage());$rows=[];}
// Build safe unique customer options by enquiry ID, not just customer name.
$customerOptions = [];
foreach ($rows as $row) {
    $lead = (int)($row['lead_id'] ?? 0);
    $label = trim((string)($row['customer_name'] ?? ''));
    $customerOptions[(string)$lead] = ($label !== '' ? $label : 'Customer') . ($lead > 0 ? ' · Enquiry #' . $lead : ' · Unlinked');
}
natcasesort($customerOptions);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Customer Quotation Desk | TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260926-v241">
<style>
/* TRAVSCOPE V24.57: all design rules are scoped to this module. */
.tq-page{--tq-ink:#162e4b;--tq-muted:#71859f;--tq-line:#dce6f2;--tq-blue:#156be6;color:var(--tq-ink);width:100%;max-width:none;padding:14px 17px 28px;box-sizing:border-box}
.tq-page *{box-sizing:border-box}
.tq-page h1,.tq-page h2,.tq-page p{margin:0}
.tq-page .tq-hero{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;padding:13px 16px;margin-bottom:12px;border:1px solid #d7e6f5;border-left:4px solid #10a6d2;border-radius:13px;background:linear-gradient(108deg,#fff 49%,#f0f7ff 100%);box-shadow:0 6px 19px rgba(21,49,86,.04)}
.tq-page .tq-title{flex:1 1 315px;min-width:0}
.tq-page .tq-kicker{font-size:9px;letter-spacing:.11em;color:#187bc1;font-weight:850;text-transform:uppercase;margin-bottom:3px}
.tq-page h1{font-size:clamp(20px,2vw,26px);line-height:1.18;letter-spacing:-.035em;font-weight:850;color:#142b47}
.tq-page .tq-title p{font-size:11px;color:var(--tq-muted);margin-top:5px;line-height:1.45}
.tq-page .tq-head-side{display:flex;align-items:center;justify-content:flex-end;gap:7px;flex-wrap:wrap;flex:2 1 480px}
.tq-page .tq-counter{display:flex;align-items:center;gap:8px;padding:7px 10px;background:#fff;border:1px solid #e0e9f5;border-radius:10px;min-width:92px;min-height:47px}
.tq-page .tq-counter i{display:grid;place-items:center;width:27px;height:27px;border-radius:8px;font-size:11px;flex:0 0 27px}
.tq-page .tq-counter b{display:block;font-size:16px;line-height:1.05;color:#1a375b;font-weight:900;font-variant-numeric:tabular-nums}
.tq-page .tq-counter small{display:block;font-size:9px;font-weight:750;white-space:nowrap;color:#7789a0;margin-top:3px}
.tq-page .tq-counter.blue i{color:#1469df;background:#e7efff}.tq-page .tq-counter.green i{color:#07895b;background:#e1f8ed}.tq-page .tq-counter.amber i{color:#af7108;background:#fff1db}.tq-page .tq-counter.purple i{color:#7654d8;background:#eee9ff}
.tq-page .tq-back{display:inline-flex;align-items:center;gap:6px;white-space:nowrap;text-decoration:none!important;color:#245990!important;border:1px solid #d4e3f3;border-radius:9px;background:#fff;padding:9px 11px;font-size:11px;font-weight:800}
.tq-page .tq-back:hover{background:#edf5ff}
.tq-page .tq-directory{background:#fff;border:1px solid var(--tq-line);border-radius:13px;overflow:hidden;box-shadow:0 8px 24px rgba(18,46,78,.045)}
.tq-page .tq-dir-header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;padding:12px 15px;background:linear-gradient(104deg,#f4f9ff,#fff)}
.tq-page .tq-dir-left{display:flex;align-items:center;gap:9px;min-width:0}
.tq-page .tq-dir-icon{display:grid;place-items:center;width:33px;height:33px;flex:0 0 33px;border-radius:10px;background:#e6efff;color:#1767d8;font-size:14px}
.tq-page .tq-dir-header h2{font-size:15px;font-weight:850;color:#1c395b;letter-spacing:-.025em}
.tq-page .tq-dir-header p{font-size:10px;color:var(--tq-muted);margin-top:3px}
.tq-page .tq-dir-meta{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.tq-page .tq-chip{font-size:10px;font-weight:800;color:#2769ad;background:#eaf4ff;border:1px solid #d4e7ff;border-radius:999px;padding:6px 9px;text-decoration:none!important}
.tq-page a.tq-chip:hover{background:#deedff}
.tq-page .tq-filters{display:grid;grid-template-columns:minmax(170px,1.5fr) minmax(130px,1fr) minmax(155px,1.5fr) minmax(120px,1fr) minmax(135px,1fr) auto;gap:8px;align-items:end;padding:10px 15px;border-top:1px solid #e9eff6;border-bottom:1px solid #dee8f4;background:#fff}
.tq-page .tq-field{display:flex;flex-direction:column;gap:4px;min-width:0}
.tq-page .tq-field>span{font-size:10px;color:#59718c;font-weight:800;white-space:nowrap}
.tq-page .tq-field.tq-trip>span{color:#2468d1}
.tq-page .tq-input{font:inherit;min-width:0;width:100%;height:35px;padding:0 9px;border:1px solid #d6e3f0;border-radius:8px;font-size:11px;color:#2c4867;background:#fff;outline:none}
.tq-page .tq-input:focus{border-color:#3580df;box-shadow:0 0 0 3px rgba(28,105,220,.1)}
.tq-page .tq-input:disabled{color:#9cabbc;background:#f2f6fa;cursor:not-allowed}
.tq-page .tq-reset{height:35px;border:1px solid #d4e2f2;color:#2b62a1;background:#f4f8ff;border-radius:8px;font-size:11px;font-weight:850;padding:0 12px;cursor:pointer;white-space:nowrap}
.tq-page .tq-reset:hover{background:#e8f2ff}
.tq-page .tq-resultline{display:flex;justify-content:space-between;gap:9px;flex-wrap:wrap;padding:7px 15px;font-size:10px;color:#7b8da3;background:#fbfdff}
.tq-page .tq-resultline strong{color:#1661b2}
.tq-page .tq-table-wrap{overflow-x:auto;width:100%;scrollbar-color:#c4d5e9 transparent}
.tq-page .tq-table{border-collapse:collapse;width:100%;min-width:1100px;table-layout:fixed}
.tq-page .tq-table th{text-align:left;text-transform:uppercase;letter-spacing:.045em;font-size:9px;color:#526e8a;padding:10px 10px;background:#edf3fa;border-top:1px solid #e1eaf4;border-bottom:1px solid #d7e3f0;font-weight:850}
.tq-page .tq-table td{padding:9px 10px;border-bottom:1px solid #e9eff6;vertical-align:middle;font-size:11px;line-height:1.35;color:#395370;overflow-wrap:anywhere}
.tq-page .tq-table tbody tr:nth-child(even){background:#fafcff}.tq-page .tq-table tbody tr:hover{background:#eff6ff}
.tq-page .tq-table tbody tr[hidden]{display:none!important}
.tq-page .tq-table tbody tr:last-child td{border-bottom:0}
.tq-page .tq-name{display:flex;align-items:center;gap:8px;min-width:0}
.tq-page .tq-avatar{display:grid;place-items:center;flex:0 0 29px;width:29px;height:29px;border-radius:9px;font-size:11px;font-weight:900;color:#2561c0;background:#e6efff}
.tq-page .tq-name strong,.tq-page .tq-tripname{font-size:11px;color:#173854;font-weight:850;line-height:1.3;display:block}
.tq-page .tq-sub{display:block;font-size:9px;color:#8595a9;margin-top:3px;line-height:1.3}
.tq-page .tq-version{display:inline-flex;align-items:center;background:#eaf1ff;color:#2168c8;border:1px solid #d5e4ff;border-radius:7px;padding:4px 7px;font-size:10px;font-weight:900;white-space:nowrap}
.tq-page .tq-version.v2{background:#f1ebff;color:#7851c5;border-color:#e5d8ff}.tq-page .tq-version.v3{background:#fff2df;color:#a96509;border-color:#ffdfaf}.tq-page .tq-version.v4{background:#e3f6f4;color:#087d79;border-color:#bfece6}
.tq-page .tq-status{display:inline-flex;align-items:center;gap:5px;white-space:nowrap;font-size:9px;font-weight:850;padding:5px 7px;border-radius:999px;margin-top:5px}
.tq-page .tq-status.info{background:#eaf2ff;color:#1d67c7}.tq-page .tq-status.success{background:#e2f7ed;color:#098254}.tq-page .tq-status.warning{background:#fff1da;color:#a56a00}.tq-page .tq-status.danger{background:#fff0ef;color:#b52326}
.tq-page .tq-status i{font-size:5px}
.tq-page .tq-travel{color:#1d609d;font-weight:750;margin-top:4px;font-size:10px;display:block}
.tq-page .tq-value{color:#0c6d55;font-size:12px;font-weight:900;white-space:nowrap;font-variant-numeric:tabular-nums}
.tq-page .tq-email.sent{color:#07835c;font-weight:800}.tq-page .tq-email.pending{color:#a87926}
.tq-page .tq-decision{font-size:10px;font-weight:800;color:#456581}.tq-page .tq-note{font-size:9px;color:#7e8fa4;margin-top:4px;line-height:1.4}
.tq-page .tq-actions{display:flex;gap:5px;flex-wrap:wrap;align-items:center}
.tq-page .tq-action{display:inline-flex;justify-content:center;align-items:center;gap:5px;text-decoration:none!important;font-size:10px;font-weight:850;white-space:nowrap;border:1px solid #d8e3f1;border-radius:7px;padding:6px 8px;background:#fff;color:#2e587d!important}
.tq-page .tq-action.primary{background:#1569e4;border-color:#1569e4;color:#fff!important}.tq-page .tq-action.success{background:#e4f8ee;border-color:#bce9d0;color:#06774e!important}
.tq-page .tq-action:hover{filter:brightness(.96)}
.tq-page .tq-empty{padding:28px 15px;text-align:center;color:#7c8ea5;font-size:12px}.tq-page .tq-empty i{display:block;font-size:23px;color:#a9c5e4;margin-bottom:8px}
.tq-page .tq-empty[hidden]{display:none!important}
.tq-page .tq-foot{border-top:1px solid #e6edf6;background:#fbfdff;padding:8px 15px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:7px;font-size:10px;color:#8492a5}
@media(max-width:1300px){.tq-page .tq-filters{grid-template-columns:repeat(3,minmax(0,1fr))}.tq-page .tq-reset{justify-self:start}}
@media(max-width:700px){.tq-page{padding:10px 9px 20px}.tq-page .tq-hero{align-items:stretch}.tq-page .tq-head-side{justify-content:flex-start;flex:1 1 100%}.tq-page .tq-counter{flex:1 1 42%;min-width:110px}.tq-page .tq-filters{grid-template-columns:repeat(2,minmax(0,1fr))}.tq-page .tq-field:first-child{grid-column:1/-1}}
@media(max-width:420px){.tq-page .tq-filters{grid-template-columns:1fr}.tq-page .tq-field:first-child{grid-column:auto}.tq-page .tq-dir-header{align-items:flex-start}}
</style>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>
<body>
<main class="tq-page">
  <header class="tq-hero">
    <div class="tq-title"><div class="tq-kicker">Customer Relationship / Commercial</div><h1>Customer Quotation Desk</h1><p>Review quotation versions, customer decisions and booking progress in one workspace.</p></div>
    <div class="tq-head-side">
      <div class="tq-counter blue"><i class="fa-solid fa-file-invoice"></i><span><b><?=number_format($total)?></b><small>Loaded versions</small></span></div>
      <div class="tq-counter green"><i class="fa-solid fa-envelope-circle-check"></i><span><b><?=number_format($sent)?></b><small>Email sent</small></span></div>
      <div class="tq-counter amber"><i class="fa-solid fa-clipboard-check"></i><span><b><?=number_format($accepted)?></b><small>Accepted / review</small></span></div>
      <div class="tq-counter purple"><i class="fa-solid fa-suitcase-rolling"></i><span><b><?=number_format($converted)?></b><small>Converted</small></span></div>
      <a class="tq-back" href="<?=tqx(defined('BASE_URL')?BASE_URL:'')?>admin-enquiries.php"><i class="fa-solid fa-arrow-left"></i> Enquiries</a>
    </div>
  </header>
  <section class="tq-directory" aria-label="Customer quotation directory">
    <div class="tq-dir-header">
      <div class="tq-dir-left"><span class="tq-dir-icon"><i class="fa-solid fa-file-contract"></i></span><div><h2><?=$leadFilter>0?'Quotation History · Enquiry #'.(int)$leadFilter:'Quotation Directory'?></h2><p>Filter by customer, specific package and travel date to compare the right versions.</p></div></div>
      <div class="tq-dir-meta"><span class="tq-chip"><i class="fa-solid fa-database"></i> Latest 150 maximum</span><?php if($leadFilter>0):?><a class="tq-chip" href="admin-enquiry-details.php?id=<?=(int)$leadFilter?>"><i class="fa-solid fa-arrow-up-right-from-square"></i> Back to Enquiry</a><a class="tq-chip" href="admin-customer-quotations.php">All enquiries</a><?php endif;?></div>
    </div>
    <?php if($rows): ?>
    <div class="tq-filters" aria-label="Quotation filters">
      <label class="tq-field"><span>Search quotation</span><input class="tq-input" id="tqSearch" type="search" autocomplete="off" placeholder="Customer, package, phone, destination…"></label>
      <label class="tq-field"><span>1 · Customer / enquiry</span><select class="tq-input" id="tqCustomer"><option value="">All customers</option><?php foreach($customerOptions as $customerId=>$customerLabel):?><option value="<?=tqx($customerId)?>"><?=tqx($customerLabel)?></option><?php endforeach;?></select></label>
      <label class="tq-field tq-trip"><span>2 · Specific package</span><select class="tq-input" id="tqPackage" disabled><option value="">Choose customer first</option></select></label>
      <label class="tq-field tq-trip"><span>3 · Travel date</span><select class="tq-input" id="tqTravel" disabled><option value="">Choose package first</option></select></label>
      <label class="tq-field"><span>Quotation stage</span><select class="tq-input" id="tqStage"><option value="">All stages</option><option value="prepared">Prepared</option><option value="accepted">Accepted / review</option><option value="change_requested">Changes requested</option><option value="rejected">Rejected</option><option value="converted">Booking created</option></select></label>
      <button class="tq-reset" id="tqReset" type="button"><i class="fa-solid fa-rotate-left"></i> Reset</button>
    </div>
    <div class="tq-resultline"><strong id="tqCount">Showing <?=number_format(count($rows))?> versions</strong><span id="tqHint">Choose customer → package → travel date to isolate one trip. Prices are quotation snapshots.</span></div>
    <div class="tq-table-wrap"><table class="tq-table"><colgroup><col style="width:13%"><col style="width:12%"><col style="width:23%"><col style="width:10%"><col style="width:10%"><col style="width:11%"><col style="width:10%"><col style="width:11%"></colgroup>
      <thead><tr><th>Customer</th><th>Version / status</th><th>Package / travel</th><th>Travellers / hotel</th><th>Selling price</th><th>Created / emailed</th><th>Decision</th><th>Actions</th></tr></thead>
      <tbody id="tqRows">
      <?php foreach($rows as $r):
        $st=$r['_state'];
        $version=max(1,(int)($r['version_number']??1));
        $lead=(int)($r['lead_id']??0);
        $packageTitle=trim((string)($r['package_title']??''));
        if($packageTitle==='')$packageTitle='Custom Package';
        $packageId=(int)($r['package_id']??0);
        $packageKey=$packageId>0?'id:'.$packageId:'title:'.$packageTitle;
        $travelRaw=trim((string)($r['travel_date']??''));
        $travelKey=preg_match('/^\d{4}-\d{2}-\d{2}/',$travelRaw,$m)?$m[0]:'__undated__';
        $travelDisplay=$travelKey==='__undated__'?'Travel date pending':date('d M Y',strtotime($travelKey));
        $customer=trim((string)($r['customer_name']??''));if($customer==='')$customer='Customer';
        $searchText=implode(' ',[$customer,$r['customer_email']??'',$r['customer_mobile']??'',$packageTitle,$r['destination']??'',$travelDisplay]);
      ?>
      <tr data-id="<?=(int)$r['id']?>" data-customer="<?=$lead?>" data-package="<?=tqx($packageKey)?>" data-package-name="<?=tqx($packageTitle)?>" data-travel="<?=tqx($travelKey)?>" data-stage="<?=tqx($st['key'])?>" data-search="<?=tqx($searchText)?>">
        <td><div class="tq-name"><span class="tq-avatar" aria-hidden="true"><?=tqx(strtoupper(substr($customer,0,1)))?></span><span><strong><?=tqx($customer)?></strong><span class="tq-sub"><?=tqx($r['customer_mobile']?:$r['customer_email']?:'Enquiry #'.$lead)?></span></span></div></td>
        <td><span class="tq-version v<?=min(4,$version)?>">V<?=$version?></span><br><span class="tq-status <?=tqx($st['class'])?>"><i class="fa-solid fa-circle"></i> <?=tqx($st['label'])?></span></td>
        <td><span class="tq-tripname" title="<?=tqx($packageTitle)?>"><?=tqx($packageTitle)?></span><span class="tq-sub"><i class="fa-solid fa-location-dot"></i> <?=tqx($r['destination']?:'—')?></span><span class="tq-travel"><i class="fa-regular fa-calendar"></i> <?=tqx($travelDisplay)?></span></td>
        <td><strong><?=max(0,(int)$r['adults'])?>A + <?=max(0,(int)$r['children'])?>C</strong><span class="tq-sub">Hotel: <?=tqx($r['hotel_category']?:'—')?></span></td>
        <td><span class="tq-value">₹<?=number_format((float)$r['final_price'],2)?></span><span class="tq-sub">Saved quotation</span></td>
        <td><span class="tq-sub" style="margin-top:0;color:#465f7d"><?=tqx($r['created_at']?:'—')?></span><span class="tq-sub tq-email <?=!empty($r['email_sent_at'])?'sent':'pending'?>"><?=!empty($r['email_sent_at'])?'<i class="fa-solid fa-check"></i> Sent: '.tqx($r['email_sent_at']):'Not emailed yet'?></span></td>
        <td><?php if(!empty($st['response'])):?><span class="tq-decision"><?=tqx(ucwords(str_replace('_',' ',$st['response']['decision']??'')))?></span><?php if(!empty($st['response']['customer_note'])):?><div class="tq-note"><?=tqx($st['response']['customer_note'])?></div><?php endif;?><?php else:?><span class="tq-sub">Awaiting customer action</span><?php endif;?></td>
        <td><div class="tq-actions"><a class="tq-action primary" href="admin-crm.php?lead=<?=$lead?>&quote_version=<?=(int)$r['id']?>#quotationVersion-<?=(int)$r['id']?>"><i class="fa-solid fa-pen-to-square"></i> Open</a><a class="tq-action" target="_blank" rel="noopener" href="admin-crm.php?quotation_preview=1&lead=<?=$lead?>&version=<?=(int)$r['id']?>"><i class="fa-regular fa-eye"></i> Preview</a><?php if($st['key']==='accepted'):?><a class="tq-action success" href="admin-crm.php?lead=<?=$lead?>&quote_version=<?=(int)$r['id']?>#quotationVersion-<?=(int)$r['id']?>"><i class="fa-solid fa-clipboard-check"></i> Review</a><?php elseif(!empty($st['booking'])):?><a class="tq-action success" href="admin-booking-details.php?id=<?=(int)$st['booking']['id']?>" title="Open linked booking"><i class="fa-solid fa-suitcase"></i> <?=tqx($st['booking']['booking_number'])?></a><?php endif;?></div></td>
      </tr>
      <?php endforeach; ?>
      </tbody></table></div>
    <div class="tq-empty" id="tqEmpty" hidden><i class="fa-solid fa-filter-circle-xmark"></i><span id="tqEmptyText">No matching quotation versions.</span></div>
    <div class="tq-foot"><span>Search and filters apply to the most recent <?=count($rows)?> loaded record<?=count($rows)===1?'':'s'?><?php if($leadFilter>0):?> for this enquiry<?php endif;?>.</span><span>Each version is a saved quotation snapshot—not confirmed revenue.</span></div>
    <?php else: ?><div class="tq-empty"><i class="fa-regular fa-file-lines"></i><p>No quotation version found.</p></div><?php endif; ?>
  </section>
</main>
<?php if($rows):?>
<script>
(function () {
 'use strict';
 var search=document.getElementById('tqSearch'), customer=document.getElementById('tqCustomer'), pkg=document.getElementById('tqPackage'), travel=document.getElementById('tqTravel'), stage=document.getElementById('tqStage'), reset=document.getElementById('tqReset'), tbody=document.getElementById('tqRows'), count=document.getElementById('tqCount'), hint=document.getElementById('tqHint'), empty=document.getElementById('tqEmpty'), emptyText=document.getElementById('tqEmptyText');
 if(!search||!customer||!pkg||!travel||!stage||!reset||!tbody||!count||!hint||!empty||!emptyText)return;
 var rows=Array.prototype.slice.call(tbody.querySelectorAll('tr[data-id]'));
 var months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
 function dateLabel(v){if(v==='__undated__')return 'Travel date not set';var parts=v.split('-');return parts.length===3?(parts[2]+' '+(months[Number(parts[1])-1]||parts[1])+' '+parts[0]):v;}
 function setOptions(el,placeholder,entries){while(el.firstChild)el.removeChild(el.firstChild);var first=document.createElement('option');first.value='';first.textContent=placeholder;el.appendChild(first);entries.forEach(function(x){var option=document.createElement('option');option.value=x.value;option.textContent=x.label;el.appendChild(option);});el.value='';}
 function resetTravel(){setOptions(travel,'Choose package first',[]);travel.disabled=true;}
 function refreshPackages(){resetTravel();if(!customer.value){setOptions(pkg,'Choose customer first',[]);pkg.disabled=true;return;}
   var known=new Map();rows.forEach(function(row){if(row.dataset.customer===customer.value&&!known.has(row.dataset.package))known.set(row.dataset.package,row.dataset.packageName||'Custom Package');});
   var entries=Array.from(known,function(pair){return {value:pair[0],label:pair[1]};});entries.sort(function(a,b){return a.label.localeCompare(b.label,undefined,{numeric:true,sensitivity:'base'});});
   var names={};entries.forEach(function(x){names[x.label]=(names[x.label]||0)+1;});entries.forEach(function(x){if(names[x.label]>1)x.label+=' ('+x.value.replace(/^id:/,'Package #')+')';});
   setOptions(pkg,'Select specific package ('+entries.length+')',entries);pkg.disabled=!entries.length;}
 function refreshTravel(){if(!customer.value||!pkg.value){resetTravel();return;}
   var dates=new Set();rows.forEach(function(row){if(row.dataset.customer===customer.value&&row.dataset.package===pkg.value)dates.add(row.dataset.travel);});
   var entries=Array.from(dates).sort(function(a,b){if(a==='__undated__')return 1;if(b==='__undated__')return -1;return b.localeCompare(a);}).map(function(v){return {value:v,label:dateLabel(v)};});
   setOptions(travel,'Select travel date ('+entries.length+')',entries);travel.disabled=!entries.length;}
 function applyFilters(){var c=customer.value,p=pkg.value,d=travel.value,q=search.value.trim().toLocaleLowerCase(),s=stage.value,needPackage=!!c&&!p,needTravel=!!c&&!!p&&!d,shown=0;
   rows.forEach(function(row){var matches=!needPackage&&!needTravel&&(!c||(row.dataset.customer===c&&row.dataset.package===p&&row.dataset.travel===d))&&(!s||row.dataset.stage===s)&&(!q||(row.dataset.search||'').toLocaleLowerCase().indexOf(q)!==-1);row.hidden=!matches;if(matches)shown++;});
   if(needPackage){count.textContent='Select a package for this customer';hint.textContent='Step 2: select the specific package';emptyText.textContent='Choose a package to see its available travel dates.';}
   else if(needTravel){count.textContent='Select a travel date';hint.textContent='Step 3: select the trip date to show only its quotation versions';emptyText.textContent='Choose a travel date to see the correct versions.';}
   else{count.textContent='Showing '+shown+' of '+rows.length+' loaded quotation versions';hint.textContent=c?('Versions for this trip · '+dateLabel(d)+' · Saved quotation prices'):'Choose customer → package → travel date to isolate an individual trip';emptyText.textContent='No matching quotations. Try changing the filters.';}
   empty.hidden=shown!==0;
 }
 search.addEventListener('input',applyFilters);
 customer.addEventListener('change',function(){refreshPackages();applyFilters();});
 pkg.addEventListener('change',function(){refreshTravel();applyFilters();});
 travel.addEventListener('change',applyFilters);
 stage.addEventListener('change',applyFilters);
 reset.addEventListener('click',function(){search.value='';customer.value='';stage.value='';refreshPackages();applyFilters();search.focus();});
 refreshPackages();applyFilters();
})();
</script>
<?php endif; ?>
<script src="assets/travscope-pro-admin.js?v=20260926-v241" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
