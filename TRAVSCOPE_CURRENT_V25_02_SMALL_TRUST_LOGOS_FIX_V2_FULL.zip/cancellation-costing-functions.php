<?php
/**
 * TRAVSCOPE V24.37 — cancellation assessment, based on current booking/finance
 * amounts. Never trust refund totals submitted by a browser.
 */
declare(strict_types=1);

function tsCancelCents(float $value): int
{
    return (int)round($value * 100, 0, PHP_ROUND_HALF_UP);
}
function tsCancelCheckedNumber($raw, string $label, float $maximum = 1000000000.0): float
{
    if (!is_scalar($raw) || trim((string)$raw) === '' || !is_numeric($raw)) {
        throw new RuntimeException($label . ' must be a valid number.');
    }
    $value = (float)$raw;
    if (!is_finite($value) || $value < 0 || $value > $maximum) {
        throw new RuntimeException($label . ' must be between 0 and ' . number_format($maximum, 2) . '.');
    }
    return $value;
}

/** Only funds actually paid to a supplier are a basis for projecting a supplier refund. */
function tsCancelSupplierPaid(PDO $pdo, int $bookingId): array
{
    try {
        $query = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM supplier_payments WHERE booking_id = ? AND status = 'paid'");
        $query->execute([$bookingId]);
        return [round(max(0, (float)$query->fetchColumn()), 2), true];
    } catch (Throwable $e) {
        error_log('Cancellation supplier paid lookup: ' . $e->getMessage());
        return [0.0, false];
    }
}

/** Recompute every amount with database-sourced total, retained and supplier-paid values. */
function tsCancelComputeAssessment(float $bookingTotal, float $retained, float $supplierPaid, array $input): array
{
    $total = tsCancelCents(max(0, $bookingTotal));
    $held = tsCancelCents(max(0, $retained));
    $paidSupplier = tsCancelCents(max(0, $supplierPaid));
    $mode = strtolower(trim((string)($input['customer_charge_mode'] ?? '')));
    if (!in_array($mode, ['fixed', 'percentage'], true)) {
        throw new RuntimeException('Select Fixed Amount or Percentage for customer cancellation charge.');
    }
    $value = tsCancelCheckedNumber($input['customer_charge_value'] ?? null, 'Customer cancellation charge', $mode === 'percentage' ? 100 : 1000000000);
    // Fixed amount is rupees. Percentage is always of the BOOKING TOTAL (not supplier expense).
    $policyCharge = $mode === 'percentage'
        ? (int)round($total * $value / 100, 0, PHP_ROUND_HALF_UP)
        : tsCancelCents($value);
    // Do not create an extra debtor or consume unreceived customer funds implicitly.
    $charge = min($held, $policyCharge);
    $refund = $held - $charge;
    if ($charge < 0 || $refund < 0 || $charge + $refund !== $held) {
        throw new RuntimeException('Customer funds could not be reconciled.');
    }

    $supplierMode = strtolower(trim((string)($input['supplier_penalty_mode'] ?? 'fixed')));
    if (!in_array($supplierMode, ['fixed', 'percentage'], true)) {
        throw new RuntimeException('Select a valid supplier penalty method.');
    }
    $supplierValue = tsCancelCheckedNumber($input['supplier_penalty_value'] ?? 0, 'Supplier penalty', $supplierMode === 'percentage' ? 100 : 1000000000);
    // A percentage supplier penalty is based solely on ledger-confirmed amounts PAID to supplier.
    $penalty = $supplierMode === 'percentage'
        ? (int)round($paidSupplier * $supplierValue / 100, 0, PHP_ROUND_HALF_UP)
        : tsCancelCents($supplierValue);
    $supplierProjection = ($input['supplier_refund_projection'] ?? 'no') === 'yes';
    if ($supplierProjection && $penalty > $paidSupplier) {
        throw new RuntimeException('Supplier penalty is greater than actual supplier funds paid. Disable supplier refund projection or correct the penalty.');
    }
    // Projection is OFF by default; a supplier refund should not be invented from a booking cost quote.
    $supplierRefund = $supplierProjection ? max(0, $paidSupplier - $penalty) : 0;
    if ($supplierProjection && $supplierRefund > 0 && trim((string)($input['supplier_finance_note'] ?? '')) === '') {
        throw new RuntimeException('Record the supplier agreement/policy basis before proposing a supplier refund.');
    }

    $note = ($mode === 'percentage'
        ? 'Customer policy: ' . number_format($value, 2) . '% of booking total INR ' . number_format($total / 100, 2)
        : 'Customer policy: fixed INR ' . number_format($value, 2))
        . '; policy charge INR ' . number_format($policyCharge / 100, 2)
        . '; charge retained INR ' . number_format($charge / 100, 2)
        . '; proposed customer refund INR ' . number_format($refund / 100, 2) . '.';
    if ($policyCharge > $held) {
        $note .= ' Policy excess INR ' . number_format(($policyCharge - $held) / 100, 2)
            . ' is NOT collected, billed or deducted from the refund in this assessment.';
    }
    $supplierNote = 'Supplier paid (ledger): INR ' . number_format($paidSupplier / 100, 2)
        . '; penalty policy ' . ($supplierMode === 'percentage' ? number_format($supplierValue, 2) . '% of supplier paid' : 'fixed INR ' . number_format($supplierValue, 2))
        . '; penalty INR ' . number_format($penalty / 100, 2)
        . '; supplier refund projection ' . ($supplierProjection ? 'enabled' : 'not confirmed') . '.';

    return [
        'customer_cancellation_charge' => $charge / 100,
        'customer_refund_amount' => $refund / 100,
        'supplier_penalty_amount' => $penalty / 100,
        'supplier_refund_expected' => $supplierRefund / 100,
        'customer_finance_note' => $note . "\n" . trim((string)($input['customer_finance_note'] ?? '')),
        'supplier_finance_note' => $supplierNote . "\n" . trim((string)($input['supplier_finance_note'] ?? '')),
    ];
}

/** Consistent form for pending customer-initiated and already-approved direct cancellations. */
function tsCancelRenderAssessment(array $row, float $supplierPaid, bool $supplierKnown, string $currencySymbol='₹'): void
{
    $total = round(max(0, (float)($row['total_amount'] ?? 0)), 2);
    $retained = round(max(0, (float)($row['paid_amount'] ?? 0)), 2);
    $unpaid = max(0, $total - $retained);
    $sym = htmlspecialchars($currencySymbol, ENT_QUOTES, 'UTF-8');
    $fmt = static function(float $amount) use ($sym): string { return $sym . number_format($amount, 2); };
    ?>
    <div class="ts-cancel-assessment" data-total="<?= htmlspecialchars(number_format($total, 2, '.', ''), ENT_QUOTES); ?>"
         data-retained="<?= htmlspecialchars(number_format($retained, 2, '.', ''), ENT_QUOTES); ?>"
         data-supplier-paid="<?= htmlspecialchars(number_format($supplierPaid, 2, '.', ''), ENT_QUOTES); ?>">
      <h4><i class="fa-solid fa-calculator"></i> Automatic Cancellation & Refund Calculation</h4>
      <div class="ts-ca-metrics">
        <div><small>Booking total</small><strong><?= $fmt($total); ?></strong></div>
        <div><small>Customer funds retained</small><strong><?= $fmt($retained); ?></strong></div>
        <div><small>Unpaid booking portion</small><strong><?= $fmt($unpaid); ?></strong></div>
        <div><small>Supplier payments recorded</small><strong><?= $supplierKnown ? $fmt($supplierPaid) : 'Not available'; ?></strong></div>
      </div>
      <div class="ts-ca-row">
        <div><label for="ca_mode_<?= (int)($row['cancellation_id'] ?? 0); ?>">Customer cancellation charge method</label>
          <select id="ca_mode_<?= (int)($row['cancellation_id'] ?? 0); ?>" name="customer_charge_mode" data-ca-mode required>
            <option value="fixed">Fixed amount (₹)</option><option value="percentage">Percentage of booking total (%)</option>
          </select>
          <small class="ts-ca-help">Choose the method in your confirmed cancellation policy.</small>
        </div>
        <div><label>Charge value</label><input data-ca-value name="customer_charge_value" type="number" min="0" step="0.01" value="0" required>
          <small class="ts-ca-help" data-ca-value-help>Enter the amount to retain from customer funds.</small>
        </div>
      </div>
      <div class="ts-ca-result">
        <div><small>Policy charge</small><strong data-ca-policy><?= $fmt(0); ?></strong></div>
        <div><small>Cancellation amount retained</small><strong data-ca-charge><?= $fmt(0); ?></strong></div>
        <div class="ts-ca-highlight"><small>Proposed customer refund</small><strong data-ca-refund><?= $fmt($retained); ?></strong></div>
      </div>
      <p class="ts-ca-warning" data-ca-warning hidden></p>
      <p class="ts-ca-equation">Customer funds retained = cancellation charge + proposed refund. Booking amounts are re-fetched on save. Saving does not transfer money.</p>
      <details class="ts-ca-supplier"><summary><i class="fa-solid fa-building-circle-check"></i> Supplier penalties & expected recovery (separate from customer refund)</summary>
        <p>Supplier-paid amount comes from <strong>paid</strong> supplier ledger entries only. An expected supplier refund is <strong>not assumed</strong> unless you explicitly enable a projection based on the supplier agreement.</p>
        <div class="ts-ca-row">
          <div><label>Supplier penalty method</label><select name="supplier_penalty_mode" data-ca-supplier-mode>
            <option value="fixed">Fixed amount (₹)</option><option value="percentage" <?= !$supplierKnown ? 'disabled' : ''; ?>>% of actual supplier payments</option></select></div>
          <div><label>Supplier penalty value</label><input type="number" name="supplier_penalty_value" data-ca-supplier-value value="0" min="0" step="0.01" required></div>
        </div>
        <label class="ts-ca-check"><input type="checkbox" name="supplier_refund_projection" value="yes" data-ca-supplier-projection <?= $supplierKnown && $supplierPaid > 0 ? '' : 'disabled'; ?>> Calculate projected supplier refund only after supplier terms have been checked</label>
        <div class="ts-ca-result"><div><small>Supplier penalty</small><strong data-ca-supplier-penalty><?= $fmt(0); ?></strong></div><div><small>Expected supplier recovery</small><strong data-ca-supplier-refund><?= $fmt(0); ?></strong></div></div>
        <label>Supplier cancellation policy / confirmation note</label><textarea name="supplier_finance_note" placeholder="Supplier terms or confirmation for any expected recovery..."></textarea>
      </details>
      <label>Customer policy basis / internal finance note</label>
      <textarea name="customer_finance_note" placeholder="Mention applicable cancellation terms or any exception..."></textarea>
    </div>
    <?php
}
