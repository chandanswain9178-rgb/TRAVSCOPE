<?php
require_once __DIR__ . '/config.php';

if (isLoggedIn()) redirect(BASE_URL . 'dashboard.php');
if (isset($_GET['restart'])) { unset($_SESSION['password_reset_email'],$_SESSION['password_reset_user_id'],$_SESSION['password_reset_verified'],$_SESSION['password_reset_verified_at']); redirect(BASE_URL.'forgot-password.php'); }

$error=''; $success=''; $step='email';
$email = normalizeEmail((string)($_SESSION['password_reset_email'] ?? ''));
$cooldown = 0;

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action=(string)($_POST['action'] ?? '');

    if ($action==='send' || $action==='resend') {
        $submitted = normalizeEmail((string)($_POST['email'] ?? $email));
        if (!validEmail($submitted)) {
            $error='Please enter a valid registered email address.';
        } else {
            $stmt=$pdo->prepare("SELECT id,full_name,email,status FROM users WHERE email=? LIMIT 1");
            $stmt->execute([$submitted]);
            $account=$stmt->fetch();

            if (!$account || strtolower((string)$account['status'])==='blocked') {
                $error='No active TRAVSCOPE account was found with this email address.';
            } else {
                $result=createEmailOtp($pdo,$submitted,(string)$account['full_name'],'password_reset');
                if (!empty($result['success'])) {
                    $_SESSION['password_reset_email']=$submitted;
                    $_SESSION['password_reset_user_id']=(int)$account['id'];
                    $email=$submitted; $step='otp'; $success='OTP sent successfully. Please check your email.';
                    $cooldown=60;
                } else {
                    $error=(string)($result['message'] ?? 'Unable to send OTP.');
                    $cooldown=(int)($result['retry_after'] ?? 0);
                    if ($email!=='') $step='otp';
                }
            }
        }
    }

    if ($action==='verify') {
        $email=normalizeEmail((string)($_SESSION['password_reset_email'] ?? ''));
        $otp=preg_replace('/\D/','',(string)($_POST['otp'] ?? ''));
        if ($email==='') {
            $error='Your password reset session has expired. Please start again.';
        } else {
            $result=verifyEmailOtp($pdo,$email,$otp,'password_reset');
            if (!empty($result['success'])) {

                $verifiedUserId=(int)($_SESSION['password_reset_user_id'] ?? 0);

                if ($verifiedUserId>0) {
                    $stmt=$pdo->prepare("
                        UPDATE users
                        SET email_verified=1
                        WHERE id=?
                          AND email=?
                        LIMIT 1
                    ");
                    $stmt->execute([$verifiedUserId,$email]);
                }

                $_SESSION['password_reset_verified']=true;
                $_SESSION['password_reset_verified_at']=time();
                redirect(BASE_URL.'reset-password.php');
            }
            $error=(string)($result['message'] ?? 'Invalid OTP.');
            $step='otp';
        }
    }
}
if ($email!=='') $step='otp';
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Forgot Password | TRAVSCOPE.COM</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;font-family:Arial,sans-serif;background:linear-gradient(135deg,#061525,#0a3b68);display:grid;place-items:center;padding:24px;color:#172033}
.card{width:min(100%,470px);background:#fff;border-radius:22px;padding:32px;box-shadow:0 25px 70px rgba(0,0,0,.25)}
.logo{display:flex;align-items:center;gap:10px;font-size:21px;font-weight:800;color:#07192d;margin-bottom:28px}.logo b{color:#0b74ff}.icon{width:46px;height:46px;border-radius:13px;display:grid;place-items:center;background:#eaf4ff;color:#0b74ff;font-size:20px}
h1{margin:0;color:#07192d;font-size:27px}p{color:#778294;font-size:13px;line-height:1.65}
label{display:block;margin:18px 0 7px;font-size:12px;font-weight:700}.input{width:100%;height:50px;border:1px solid #dfe6ee;border-radius:11px;padding:0 14px;font-size:14px;outline:none}.input:focus{border-color:#0b74ff;box-shadow:0 0 0 3px rgba(11,116,255,.1)}
.btn{width:100%;height:50px;border:0;border-radius:11px;background:#0b74ff;color:#fff;font-weight:800;cursor:pointer;margin-top:18px}.btn:disabled{opacity:.55;cursor:not-allowed}
.alert{padding:12px 14px;border-radius:10px;margin:15px 0;font-size:12px}.error{background:#fff0f2;color:#bd3044}.success{background:#e9faf2;color:#087b4d}
.back{text-align:center;margin-top:20px;font-size:12px}.back a{color:#0b74ff;text-decoration:none;font-weight:700}
.otp-row{display:flex;gap:9px}.otp-row .input{flex:1;text-align:center;font-size:20px;letter-spacing:7px;font-weight:700}.resend{border:0;background:transparent;color:#0b74ff;font-weight:700;cursor:pointer;padding:8px 0;margin-top:10px}.resend:disabled{color:#9aa5b2}
.note{padding:11px 13px;border-radius:10px;background:#f5f8fc;color:#667386;font-size:11px;margin-top:14px}
.password-wrap{position:relative}.password-wrap .input{padding-right:48px}.eye{position:absolute;right:10px;top:7px;width:36px;height:36px;border:0;background:transparent;cursor:pointer;color:#657386}


/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-public-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="public"></script>
</head><body>
<div class="card">
<div class="logo"><span class="icon">✈</span>TRAV<b>SCOPE</b></div>
<h1><?= $step==='otp'?'Verify your email':'Forgot password?' ?></h1>
<p><?= $step==='otp'?'Enter the 6-digit OTP sent to your registered email address.':'Enter your registered email address and we will send you a secure verification code.' ?></p>
<?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif;?>
<?php if($success):?><div class="alert success"><?=e($success)?></div><?php endif;?>

<?php if($step==='email'):?>
<form method="post">
<input type="hidden" name="action" value="send">
<label>Registered Email Address</label>
<input class="input" type="email" name="email" autocomplete="email" required placeholder="you@example.com">
<button class="btn" type="submit">Send OTP</button>
</form>
<?php else:?>
<div class="note">OTP sent to <strong><?=e($email)?></strong>. The code is valid for <?=defined('OTP_EXPIRY_MINUTES')?(int)OTP_EXPIRY_MINUTES:10?> minutes.</div>
<form method="post">
<input type="hidden" name="action" value="verify">
<label>Verification Code</label>
<div class="otp-row"><input class="input" type="text" name="otp" inputmode="numeric" maxlength="6" pattern="[0-9]{6}" autocomplete="one-time-code" required placeholder="000000"></div>
<button class="btn" type="submit">Verify OTP & Continue</button>
</form>
<form method="post" id="resendForm">
<input type="hidden" name="action" value="resend"><input type="hidden" name="email" value="<?=e($email)?>">
<button class="resend" id="resendBtn" type="submit" <?= $cooldown>0?'disabled':'' ?>>Resend OTP <span id="timer"></span></button>
</form>
<div class="back"><a href="forgot-password.php?restart=1">Use another email</a></div>
<?php endif;?>
<div class="back"><a href="login.php">← Back to Login</a></div>
</div>
<?php if($step==='otp'):?><script>
let left=<?=max(0,$cooldown ?: (int)(defined('OTP_RESEND_SECONDS')?OTP_RESEND_SECONDS:60))?>;
const b=document.getElementById('resendBtn'),t=document.getElementById('timer');
function tick(){if(left>0){b.disabled=true;t.textContent='('+left+'s)';left--;setTimeout(tick,1000)}else{b.disabled=false;t.textContent='';}}
tick();
</script><?php endif;?>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>