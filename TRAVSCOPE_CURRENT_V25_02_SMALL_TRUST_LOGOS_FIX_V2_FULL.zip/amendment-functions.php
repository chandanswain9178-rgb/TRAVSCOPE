<?php
declare(strict_types=1);

function tsAmendTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];
    $key = strtolower($table);
    if (array_key_exists($key, $cache)) return $cache[$key];
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
        $stmt->execute([$table]);
        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}

function tsAmendReady(PDO $pdo): bool
{
    return tsAmendTableExists($pdo, 'booking_amendments')
        && tsAmendTableExists($pdo, 'bookings');
}

function tsAmendCancellationFinanceReady(PDO $pdo): bool
{
    return tsAmendTableExists($pdo, 'booking_cancellation_financials')
        && tsAmendTableExists($pdo, 'booking_cancellations');
}

function tsAmendTripLink(PDO $pdo, int $bookingId): ?array
{
    if ($bookingId <= 0 || !tsAmendTableExists($pdo, 'booking_trip_links')) return null;
    $stmt = $pdo->prepare("SELECT l.*, t.trip_code FROM booking_trip_links l LEFT JOIN trips t ON t.id=l.trip_id WHERE l.booking_id=? LIMIT 1");
    $stmt->execute([$bookingId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsAmendLatestApproved(PDO $pdo, int $bookingId): ?array
{
    if ($bookingId <= 0 || !tsAmendReady($pdo)) return null;
    $stmt = $pdo->prepare("SELECT * FROM booking_amendments WHERE booking_id=? AND status='approved' ORDER BY version_number DESC,id DESC LIMIT 1");
    $stmt->execute([$bookingId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsAmendPending(PDO $pdo, int $bookingId): ?array
{
    if ($bookingId <= 0 || !tsAmendReady($pdo)) return null;
    $stmt = $pdo->prepare("SELECT * FROM booking_amendments WHERE booking_id=? AND status='pending' ORDER BY version_number DESC,id DESC LIMIT 1");
    $stmt->execute([$bookingId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsAmendHistory(PDO $pdo, int $bookingId): array
{
    if ($bookingId <= 0 || !tsAmendReady($pdo)) return [];
    $stmt = $pdo->prepare("SELECT * FROM booking_amendments WHERE booking_id=? ORDER BY version_number DESC,id DESC");
    $stmt->execute([$bookingId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function tsAmendCurrentBaseline(PDO $pdo, int $bookingId): array
{
    $stmt = $pdo->prepare("SELECT id,total_amount,paid_amount,currency,booking_status,payment_status FROM bookings WHERE id=? LIMIT 1");
    $stmt->execute([$bookingId]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$booking) throw new RuntimeException('Booking was not found.');

    $link = tsAmendTripLink($pdo, $bookingId);
    $latest = tsAmendLatestApproved($pdo, $bookingId);

    $supplier = $latest
        ? (float)$latest['revised_expected_supplier_cost']
        : max(0, (float)($link['expected_supplier_cost'] ?? 0));
    $direct = $latest
        ? (float)$latest['revised_expected_direct_cost']
        : max(0, (float)($link['expected_direct_cost'] ?? 0));
    $selling = max(0, (float)($booking['total_amount'] ?? 0));

    return [
        'booking_id' => $bookingId,
        'trip_id' => !empty($link['trip_id']) ? (int)$link['trip_id'] : null,
        'trip_code' => (string)($link['trip_code'] ?? ''),
        'currency' => strtoupper(trim((string)($booking['currency'] ?? 'INR'))) ?: 'INR',
        'customer_price' => $selling,
        'paid_amount' => max(0, (float)($booking['paid_amount'] ?? 0)),
        'expected_supplier_cost' => $supplier,
        'expected_direct_cost' => $direct,
        'expected_total_cost' => $supplier + $direct,
        'expected_margin' => $selling - $supplier - $direct,
        'booking_status' => (string)($booking['booking_status'] ?? ''),
        'payment_status' => (string)($booking['payment_status'] ?? ''),
    ];
}

function tsAmendAssertEditable(PDO $pdo, int $bookingId): void
{
    if (!tsAmendReady($pdo)) throw new RuntimeException('Booking Amendment SQL is not installed yet.');

    if (tsAmendTableExists($pdo, 'booking_profitability_closures')) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM booking_profitability_closures WHERE booking_id=?");
        $stmt->execute([$bookingId]);
        if ((int)$stmt->fetchColumn() > 0) {
            throw new RuntimeException('This Booking is financially closed and cannot be amended.');
        }
    }

    $stmt = $pdo->prepare("SELECT booking_status FROM bookings WHERE id=? LIMIT 1");
    $stmt->execute([$bookingId]);
    $status = strtolower((string)($stmt->fetchColumn() ?: ''));
    if ($status === '') throw new RuntimeException('Booking was not found.');
    if (in_array($status, ['cancelled','completed'], true)) {
        throw new RuntimeException('Cancelled or completed Bookings cannot accept a new amendment.');
    }
}

function tsAmendCreateRequest(PDO $pdo, int $bookingId, string $requestedByType, ?int $userId, ?int $adminId, string $requestText): array
{
    tsAmendAssertEditable($pdo, $bookingId);
    $requestText = trim($requestText);
    if (mb_strlen($requestText) < 10) throw new RuntimeException('Booking change request must be at least 10 characters.');
    if (mb_strlen($requestText) > 5000) throw new RuntimeException('Booking change request is too long.');
    if (tsAmendPending($pdo, $bookingId)) throw new RuntimeException('A Booking amendment is already pending. Complete or reject it first.');

    $requestedByType = in_array($requestedByType, ['customer','admin'], true) ? $requestedByType : 'admin';
    $baseline = tsAmendCurrentBaseline($pdo, $bookingId);

    $stmt = $pdo->prepare("SELECT COALESCE(MAX(version_number),0)+1 FROM booking_amendments WHERE booking_id=?");
    $stmt->execute([$bookingId]);
    $version = max(1, (int)$stmt->fetchColumn());

    $snapshot = json_encode([
        'schema'=>1,
        'event'=>'amendment_request',
        'requested_at'=>date('c'),
        'baseline'=>$baseline,
        'request_text'=>$requestText,
    ], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

    $stmt = $pdo->prepare("INSERT INTO booking_amendments
        (booking_id,trip_id,version_number,requested_by_type,requested_by_user_id,requested_by_admin_id,request_text,status,
         current_customer_price,revised_customer_price,current_expected_supplier_cost,revised_expected_supplier_cost,
         current_expected_direct_cost,revised_expected_direct_cost,revised_expected_total_cost,revised_expected_margin,snapshot_json)
        VALUES (?,?,?,?,?,?,?,'pending',?,?,?,?,?,?,?,?,?)");
    $stmt->execute([
        $bookingId,$baseline['trip_id'],$version,$requestedByType,
        $requestedByType==='customer' ? ($userId ?: null) : null,
        $requestedByType==='admin' ? ($adminId ?: null) : null,
        $requestText,
        $baseline['customer_price'],$baseline['customer_price'],
        $baseline['expected_supplier_cost'],$baseline['expected_supplier_cost'],
        $baseline['expected_direct_cost'],$baseline['expected_direct_cost'],
        $baseline['expected_total_cost'],$baseline['expected_margin'],$snapshot
    ]);

    $id = (int)$pdo->lastInsertId();
    $stmt = $pdo->prepare("SELECT * FROM booking_amendments WHERE id=? LIMIT 1");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
}

function tsAmendEvaluateAndApprove(PDO $pdo, int $bookingId, int $amendmentId, int $adminId, array $input): array
{
    tsAmendAssertEditable($pdo, $bookingId);
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT * FROM booking_amendments WHERE id=? AND booking_id=? LIMIT 1 FOR UPDATE");
        $stmt->execute([$amendmentId,$bookingId]);
        $am = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$am) throw new RuntimeException('Booking amendment was not found.');
        if ((string)$am['status'] !== 'pending') throw new RuntimeException('This Booking amendment has already been processed.');

        $stmt = $pdo->prepare("SELECT * FROM bookings WHERE id=? LIMIT 1 FOR UPDATE");
        $stmt->execute([$bookingId]);
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$booking) throw new RuntimeException('Booking was not found.');

        $customerDelta = round((float)($input['customer_price_delta'] ?? 0),2);
        $supplierDelta = round((float)($input['supplier_cost_delta'] ?? 0),2);
        $directDelta = round((float)($input['direct_cost_delta'] ?? 0),2);

        $currentCustomer = (float)$am['current_customer_price'];
        $currentSupplier = (float)$am['current_expected_supplier_cost'];
        $currentDirect = (float)$am['current_expected_direct_cost'];
        $revisedCustomer = round($currentCustomer + $customerDelta,2);
        $revisedSupplier = round($currentSupplier + $supplierDelta,2);
        $revisedDirect = round($currentDirect + $directDelta,2);
        if ($revisedCustomer < 0 || $revisedSupplier < 0 || $revisedDirect < 0) {
            throw new RuntimeException('Revised customer/supplier/direct values cannot be negative.');
        }
        $revisedTotal = round($revisedSupplier + $revisedDirect,2);
        $revisedMargin = round($revisedCustomer - $revisedTotal,2);

        $paid = max(0,(float)($booking['paid_amount'] ?? 0));
        $financialAction = 'none';
        $financialAmount = 0.0;
        if ($paid > $revisedCustomer + .009) {
            $financialAction = 'refund';
            $financialAmount = round($paid - $revisedCustomer,2);
        } elseif ($customerDelta > .009) {
            $financialAction = 'additional_payment';
            $financialAmount = $customerDelta;
        }

        $changeType = strtolower(trim((string)($input['service_change_type'] ?? 'commercial_only')));
        if (!in_array($changeType,['commercial_only','modify','cancel','add'],true)) $changeType='commercial_only';
        $serviceId = max(0,(int)($input['booking_service_snapshot_id'] ?? 0));
        $beforeService = null;
        $appliedServiceId = null;

        if (in_array($changeType,['modify','cancel'],true)) {
            if ($serviceId <= 0) throw new RuntimeException('Select the affected Booking service.');
            $stmt=$pdo->prepare("SELECT * FROM booking_service_snapshots WHERE id=? AND booking_id=? LIMIT 1 FOR UPDATE");
            $stmt->execute([$serviceId,$bookingId]);
            $beforeService=$stmt->fetch(PDO::FETCH_ASSOC);
            if (!$beforeService) throw new RuntimeException('Affected Booking service was not found.');
        }

        $pType=trim((string)($input['proposed_service_type'] ?? ''));
        $pTitle=trim((string)($input['proposed_title'] ?? ''));
        $pDest=trim((string)($input['proposed_destination_name'] ?? ''));
        $pFrom=trim((string)($input['proposed_date_from'] ?? ''));
        $pTo=trim((string)($input['proposed_date_to'] ?? ''));
        $pQtyRaw=trim((string)($input['proposed_quantity'] ?? ''));
        $pQty=$pQtyRaw!=='' ? max(.01,(float)$pQtyRaw) : null;
        $pAdultsRaw=trim((string)($input['proposed_adults'] ?? ''));
        $pAdults=$pAdultsRaw!=='' ? max(0,(int)$pAdultsRaw) : null;
        $pChildrenRaw=trim((string)($input['proposed_children'] ?? ''));
        $pChildren=$pChildrenRaw!=='' ? max(0,(int)$pChildrenRaw) : null;
        $pSpec=trim((string)($input['proposed_specifications'] ?? ''));
        if ($pFrom!=='' && $pTo!=='' && $pTo<$pFrom) throw new RuntimeException('Revised service end date cannot be before start date.');

        if ($changeType==='modify') {
            $newStatus = (!empty($beforeService['source_supplier_id']) || (float)($beforeService['internal_supplier_cost'] ?? 0)>0)
                ? 'confirmation_required' : 'pending';
            $stmt=$pdo->prepare("UPDATE booking_service_snapshots SET service_type=?,title=?,destination_name=?,service_date_from=?,service_date_to=?,quantity=?,adults=?,children=?,specifications=?,internal_supplier_cost=GREATEST(0,internal_supplier_cost+?),procurement_status=?,supplier_confirmation_ref=NULL,updated_at=NOW() WHERE id=? AND booking_id=?");
            $stmt->execute([
                $pType!==''?$pType:$beforeService['service_type'],
                $pTitle!==''?$pTitle:$beforeService['title'],
                $pDest!==''?$pDest:($beforeService['destination_name']??null),
                $pFrom!==''?$pFrom:($beforeService['service_date_from']??null),
                $pTo!==''?$pTo:($beforeService['service_date_to']??null),
                $pQty!==null?$pQty:(float)$beforeService['quantity'],
                $pAdults!==null?$pAdults:(int)$beforeService['adults'],
                $pChildren!==null?$pChildren:(int)$beforeService['children'],
                $pSpec!==''?$pSpec:($beforeService['specifications']??null),
                $supplierDelta,$newStatus,$serviceId,$bookingId
            ]);
            $appliedServiceId=$serviceId;
        } elseif ($changeType==='cancel') {
            $pdo->prepare("UPDATE booking_service_snapshots SET procurement_status='cancelled',supplier_confirmation_ref=NULL,updated_at=NOW() WHERE id=? AND booking_id=?")
                ->execute([$serviceId,$bookingId]);
            $appliedServiceId=$serviceId;
        } elseif ($changeType==='add') {
            if ($pTitle==='') throw new RuntimeException('New service title is required.');
            if ($pType==='') $pType='other';
            $link=tsAmendTripLink($pdo,$bookingId);
            if (!$link || empty($link['trip_id'])) throw new RuntimeException('Booking is not linked to a Trip.');
            $stmt=$pdo->prepare("SELECT COALESCE(MAX(sort_order),0)+10 FROM booking_service_snapshots WHERE booking_id=?");
            $stmt->execute([$bookingId]);
            $sort=(int)$stmt->fetchColumn();
            $stmt=$pdo->prepare("INSERT INTO booking_service_snapshots (booking_id,trip_id,source_service_requirement_id,sort_order,service_type,title,destination_id,destination_name,service_date_from,service_date_to,quantity,adults,children,specifications,source_supplier_id,source_supplier_name,internal_supplier_cost,procurement_status) VALUES (?,?,NULL,?,?,?,NULL,?,?,?,?,?,?,?,NULL,NULL,?,'pending')");
            $stmt->execute([$bookingId,(int)$link['trip_id'],$sort,$pType,$pTitle,$pDest?:null,$pFrom?:null,$pTo?:null,$pQty??1,$pAdults??0,$pChildren??0,$pSpec?:null,max(0,$supplierDelta)]);
            $appliedServiceId=(int)$pdo->lastInsertId();
        }

        if ($appliedServiceId && tsAmendTableExists($pdo,'supplier_booking_order_items')) {
            $orderStatus = $changeType==='cancel' ? 'rejected' : 'alternative_required';
            $pdo->prepare("UPDATE supplier_booking_order_items SET status=?,supplier_confirmation_ref=NULL,supplier_note=CONCAT(COALESCE(supplier_note,''),CASE WHEN COALESCE(supplier_note,'')='' THEN '' ELSE '\n' END,'Booking amendment requires supplier review.'),updated_at=NOW() WHERE booking_service_snapshot_id=? AND status<>'rejected'")
                ->execute([$orderStatus,$appliedServiceId]);
        }

        $paymentStatus = $paid<=.009 ? 'unpaid' : ($paid+.009<$revisedCustomer ? 'partial' : 'paid');
        $pdo->prepare("UPDATE bookings SET total_amount=?,payment_status=?,updated_at=NOW() WHERE id=?")
            ->execute([$revisedCustomer,$paymentStatus,$bookingId]);

        if (tsAmendTableExists($pdo,'booking_invoice_versions')) {
            $pdo->prepare("UPDATE booking_invoice_versions SET status='void' WHERE booking_id=? AND status='final'")->execute([$bookingId]);
        }
        if (tsAmendTableExists($pdo,'booking_payment_schedules')) {
            $pdo->prepare("UPDATE booking_payment_schedules SET status='superseded',updated_at=NOW() WHERE booking_id=? AND status='active'")->execute([$bookingId]);
        }
        if (tsAmendTableExists($pdo,'booking_voucher_versions')) {
            $pdo->prepare("UPDATE booking_voucher_versions SET status='void' WHERE booking_id=? AND status='final'")->execute([$bookingId]);
        }
        if (tsAmendTableExists($pdo,'booking_operation_checks')) {
            $pdo->prepare("UPDATE booking_operation_checks SET is_complete=0,completed_by_admin_id=NULL,completed_at=NULL,updated_at=NOW() WHERE booking_id=? AND check_key IN ('final_itinerary_verified','special_requests_verified','final_supplier_reconfirmation')")
                ->execute([$bookingId]);
        }

        $supplierImpact=trim((string)($input['supplier_impact_note'] ?? ''));
        $customerMessage=trim((string)($input['customer_message'] ?? ''));
        $internalNote=trim((string)($input['internal_note'] ?? ''));
        $snapshot=json_encode([
            'schema'=>1,'event'=>'amendment_approved','approved_at'=>date('c'),
            'request_text'=>$am['request_text'],
            'commercial'=>[
                'customer_before'=>$currentCustomer,'customer_delta'=>$customerDelta,'customer_after'=>$revisedCustomer,
                'supplier_before'=>$currentSupplier,'supplier_delta'=>$supplierDelta,'supplier_after'=>$revisedSupplier,
                'direct_before'=>$currentDirect,'direct_delta'=>$directDelta,'direct_after'=>$revisedDirect,
                'total_cost_after'=>$revisedTotal,'margin_after'=>$revisedMargin,
                'customer_financial_action'=>$financialAction,'customer_financial_amount'=>$financialAmount,
            ],
            'service_change'=>['type'=>$changeType,'source_service_id'=>$serviceId ?: null,'applied_service_id'=>$appliedServiceId,'before'=>$beforeService],
            'supplier_impact_note'=>$supplierImpact,'customer_message'=>$customerMessage,'internal_note'=>$internalNote,
        ], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

        $stmt=$pdo->prepare("UPDATE booking_amendments SET status='approved',change_type=?,booking_service_snapshot_id=?,applied_service_snapshot_id=?,service_before_json=?,proposed_service_type=?,proposed_title=?,proposed_destination_name=?,proposed_date_from=?,proposed_date_to=?,proposed_quantity=?,proposed_adults=?,proposed_children=?,proposed_specifications=?,customer_price_delta=?,revised_customer_price=?,supplier_cost_delta=?,revised_expected_supplier_cost=?,direct_cost_delta=?,revised_expected_direct_cost=?,revised_expected_total_cost=?,revised_expected_margin=?,customer_financial_action=?,customer_financial_amount=?,supplier_impact_note=?,customer_message=?,internal_note=?,snapshot_json=?,approved_by_admin_id=?,approved_at=NOW(),updated_at=NOW() WHERE id=? AND booking_id=? AND status='pending'");
        $stmt->execute([
            $changeType,$serviceId?:null,$appliedServiceId,$beforeService?json_encode($beforeService,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):null,
            $pType?:null,$pTitle?:null,$pDest?:null,$pFrom?:null,$pTo?:null,$pQty,$pAdults,$pChildren,$pSpec?:null,
            $customerDelta,$revisedCustomer,$supplierDelta,$revisedSupplier,$directDelta,$revisedDirect,$revisedTotal,$revisedMargin,
            $financialAction,$financialAmount,$supplierImpact?:null,$customerMessage?:null,$internalNote?:null,$snapshot,$adminId?:null,$amendmentId,$bookingId
        ]);

        $pdo->commit();
        $stmt=$pdo->prepare("SELECT * FROM booking_amendments WHERE id=? LIMIT 1");
        $stmt->execute([$amendmentId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function tsAmendReject(PDO $pdo, int $bookingId, int $amendmentId, int $adminId, string $customerMessage='', string $internalNote=''): void
{
    tsAmendAssertEditable($pdo,$bookingId);
    $stmt=$pdo->prepare("UPDATE booking_amendments SET status='rejected',customer_message=?,internal_note=?,rejected_by_admin_id=?,rejected_at=NOW(),updated_at=NOW() WHERE id=? AND booking_id=? AND status='pending'");
    $stmt->execute([trim($customerMessage)?:null,trim($internalNote)?:null,$adminId?:null,$amendmentId,$bookingId]);
    if ($stmt->rowCount()!==1) throw new RuntimeException('Booking amendment could not be rejected.');
}

function tsAmendCancellationFinancial(PDO $pdo, int $cancellationId): ?array
{
    if ($cancellationId<=0 || !tsAmendCancellationFinanceReady($pdo)) return null;
    $stmt=$pdo->prepare("SELECT * FROM booking_cancellation_financials WHERE booking_cancellation_id=? LIMIT 1");
    $stmt->execute([$cancellationId]);
    $row=$stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsAmendSaveCancellationFinancial(PDO $pdo, int $cancellationId, int $bookingId, int $adminId, float $paidAmount, array $input): array
{
    if (!tsAmendCancellationFinanceReady($pdo)) throw new RuntimeException('Cancellation Commercial Impact SQL is not installed yet.');
    $charge=round(max(0,(float)($input['customer_cancellation_charge']??0)),2);
    $refund=round(max(0,(float)($input['customer_refund_amount']??0)),2);
    $penalty=round(max(0,(float)($input['supplier_penalty_amount']??0)),2);
    $supplierRefund=round(max(0,(float)($input['supplier_refund_expected']??0)),2);
    if ($refund>$paidAmount+.01) throw new RuntimeException('Customer refund cannot exceed the amount currently paid.');
    if ($paidAmount>0 && $charge+$refund>$paidAmount+.01) throw new RuntimeException('Cancellation charge + refund cannot exceed customer amount already paid.');
    $netImpact=round($charge-$penalty,2);

    $stmt=$pdo->prepare("INSERT INTO booking_cancellation_financials
        (booking_cancellation_id,booking_id,customer_paid_at_cancellation,customer_cancellation_charge,customer_refund_amount,customer_refund_status,supplier_penalty_amount,supplier_refund_expected,supplier_refund_status,net_margin_impact,customer_finance_note,supplier_finance_note,processed_by_admin_id)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE customer_paid_at_cancellation=VALUES(customer_paid_at_cancellation),customer_cancellation_charge=VALUES(customer_cancellation_charge),customer_refund_amount=VALUES(customer_refund_amount),customer_refund_status=VALUES(customer_refund_status),supplier_penalty_amount=VALUES(supplier_penalty_amount),supplier_refund_expected=VALUES(supplier_refund_expected),supplier_refund_status=VALUES(supplier_refund_status),net_margin_impact=VALUES(net_margin_impact),customer_finance_note=VALUES(customer_finance_note),supplier_finance_note=VALUES(supplier_finance_note),processed_by_admin_id=VALUES(processed_by_admin_id),updated_at=NOW()");
    $stmt->execute([
        $cancellationId,$bookingId,max(0,round($paidAmount,2)),$charge,$refund,$refund>.009?'pending':'none',
        $penalty,$supplierRefund,$supplierRefund>.009?'pending':'none',$netImpact,
        trim((string)($input['customer_finance_note']??''))?:null,trim((string)($input['supplier_finance_note']??''))?:null,$adminId?:null
    ]);
    return tsAmendCancellationFinancial($pdo,$cancellationId) ?: [];
}
