<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| MY BOOKINGS
| HOTEL CATEGORY + PER-PERSON PRICE VERSION: 2026-08-04-R1
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';

requireLogin();

$user = currentUser($pdo);

if (!$user) {
    unset($_SESSION['user_id']);
    redirect(BASE_URL . 'login.php');
}

$userId = (int)$user['id'];


/*
|--------------------------------------------------------------------------
| RECOVER OLD CONVERTED BOOKINGS
|--------------------------------------------------------------------------
|
| Older enquiry conversions may have created a valid booking/package link
| but left bookings.user_id as NULL. Recover ONLY orphan bookings that match
| this logged-in customer's email or normalized mobile number, then attach
| them permanently to this user account.
|
*/

try {

    $userEmail = mb_strtolower(
        trim(
            (string)($user['email'] ?? '')
        )
    );

    $userMobile = preg_replace(
        '/[^0-9]/',
        '',
        (string)($user['mobile'] ?? '')
    );

    $userMobileLast10 =
        strlen($userMobile) >= 10
            ? substr($userMobile, -10)
            : $userMobile;

    $matchParts = [];
    $matchParams = [
        $userId
    ];

    if ($userEmail !== '') {

        $matchParts[] =
            "LOWER(TRIM(customer_email)) = ?";

        $matchParams[] =
            $userEmail;
    }

    if ($userMobileLast10 !== '') {

        $matchParts[] = "
            RIGHT(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    TRIM(COALESCE(customer_mobile, '')),
                                    ' ',
                                    ''
                                ),
                                '-',
                                ''
                            ),
                            '(',
                            ''
                        ),
                        ')',
                        ''
                    ),
                    '+',
                    ''
                ),
                10
            ) = ?
        ";

        $matchParams[] =
            $userMobileLast10;
    }

    if ($matchParts) {

        $recoverSql = "
            UPDATE bookings

            SET user_id = ?

            WHERE user_id IS NULL

              AND (
                    "
                    . implode(
                        ' OR ',
                        $matchParts
                    )
                    . "
                  )
        ";

        $stmt =
            $pdo->prepare(
                $recoverSql
            );

        $stmt->execute(
            $matchParams
        );
    }

} catch (Throwable $e) {

    error_log(
        'Old booking recovery error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| SETTINGS
|--------------------------------------------------------------------------
*/

$siteName = 'TRAVSCOPE.COM';
$currencySymbol = '₹';

try {

    $siteName = getSetting(
        $pdo,
        'site_name',
        'TRAVSCOPE.COM'
    );

    $currencySymbol = getSetting(
        $pdo,
        'currency_symbol',
        '₹'
    );

} catch (Throwable $e) {

    error_log(
        'My bookings settings error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| FILTER
|--------------------------------------------------------------------------
*/

$statusFilter = strtolower(
    trim(
        (string)(
            $_GET['status']
            ?? 'all'
        )
    )
);

$allowedFilters = [
    'all',
    'pending',
    'confirmed',
    'completed',
    'cancelled'
];

if (
    !in_array(
        $statusFilter,
        $allowedFilters,
        true
    )
) {
    $statusFilter = 'all';
}


/*
|--------------------------------------------------------------------------
| SEARCH
|--------------------------------------------------------------------------
*/

$search = trim(
    (string)(
        $_GET['search']
        ?? ''
    )
);


/*
|--------------------------------------------------------------------------
| BOOKING COUNTS
|--------------------------------------------------------------------------
*/

$counts = [
    'all'       => 0,
    'pending'   => 0,
    'confirmed' => 0,
    'completed' => 0,
    'cancelled' => 0
];

try {

    $stmt = $pdo->prepare("
        SELECT
            booking_status,
            COUNT(*) AS total

        FROM bookings

        WHERE user_id = ?

        GROUP BY booking_status
    ");

    $stmt->execute([
        $userId
    ]);

    $statusRows = $stmt->fetchAll();

    foreach ($statusRows as $row) {

        $status = strtolower(
            (string)$row['booking_status']
        );

        $total = (int)$row['total'];

        $counts['all'] += $total;

        if (
            array_key_exists(
                $status,
                $counts
            )
        ) {
            $counts[$status] = $total;
        }
    }

} catch (Throwable $e) {

    error_log(
        'Booking count error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| FETCH BOOKINGS
|--------------------------------------------------------------------------
|
| Latest payment is fetched with a correlated subquery.
| This avoids duplicate booking rows if one booking has multiple payments.
|--------------------------------------------------------------------------
*/

$bookings = [];

try {

    $where = [
        'b.user_id = ?'
    ];

    $params = [
        $userId
    ];


    if ($statusFilter !== 'all') {

        $where[] =
            'b.booking_status = ?';

        $params[] =
            $statusFilter;
    }


    if ($search !== '') {

        $where[] = "
            (
                b.booking_number LIKE ?
                OR p.title LIKE ?
                OR d.name LIKE ?
                OR d.country LIKE ?
            )
        ";

        $searchTerm =
            '%' . $search . '%';

        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }


    $whereSql =
        implode(
            ' AND ',
            $where
        );


    $sql = "
        SELECT

            b.id,
            b.booking_number,
            b.package_id,
            b.hotel_category,
            b.hotel_price,
            b.customer_name,
            b.customer_email,
            b.customer_mobile,
            b.travel_date,
            b.adults,
            b.children,
            b.total_amount,
            b.paid_amount,
            b.currency,
            b.booking_status,
            b.payment_status,
            b.special_request,
            b.created_at,
            b.updated_at,

            p.title AS package_title,
            p.slug AS package_slug,
            p.package_code,
            p.main_image,
            p.duration_days,
            p.duration_nights,
            p.package_type,

            d.name AS destination_name,
            d.country AS destination_country,

            (
                SELECT pay.status
                FROM payments pay
                WHERE pay.booking_id = b.id
                ORDER BY pay.id DESC
                LIMIT 1
            ) AS latest_payment_status,

            (
                SELECT pay.transaction_id
                FROM payments pay
                WHERE pay.booking_id = b.id
                ORDER BY pay.id DESC
                LIMIT 1
            ) AS latest_transaction_id,

            (
                SELECT pay.created_at
                FROM payments pay
                WHERE pay.booking_id = b.id
                ORDER BY pay.id DESC
                LIMIT 1
            ) AS latest_payment_date,

            (
                SELECT bc.status
                FROM booking_cancellations bc
                WHERE bc.booking_id = b.id
                  AND bc.user_id = b.user_id
                ORDER BY bc.id DESC
                LIMIT 1
            ) AS latest_cancellation_status

        FROM bookings b

        LEFT JOIN packages p
            ON p.id = b.package_id

        LEFT JOIN destinations d
            ON d.id = p.destination_id

        WHERE {$whereSql}

        ORDER BY
            CASE b.booking_status
                WHEN 'pending' THEN 1
                WHEN 'confirmed' THEN 2
                WHEN 'completed' THEN 3
                WHEN 'cancelled' THEN 4
                ELSE 5
            END,
            b.id DESC
    ";


    $stmt = $pdo->prepare($sql);

    $stmt->execute($params);

    $bookings = $stmt->fetchAll();

} catch (Throwable $e) {

    error_log(
        'My bookings fetch error: '
        . $e->getMessage()
    );

    $bookings = [];
}


/*
|--------------------------------------------------------------------------
| USER DETAILS
|--------------------------------------------------------------------------
*/

$fullName = trim(
    (string)(
        $user['full_name']
        ?? 'Traveller'
    )
);

if ($fullName === '') {
    $fullName = 'Traveller';
}

$nameParts = preg_split(
    '/\s+/',
    $fullName
);

$firstName =
    $nameParts[0]
    ?? 'Traveller';

$userInitial = strtoupper(
    substr(
        $fullName,
        0,
        1
    )
);


/*
|--------------------------------------------------------------------------
| IMAGE FUNCTION
|--------------------------------------------------------------------------
*/

function bookingImageUrl($image)
{
    $image = trim(
        (string)$image
    );

    if ($image === '') {
        return '';
    }

    if (
        preg_match(
            '#^https?://#i',
            $image
        )
    ) {
        return $image;
    }

    return
        BASE_URL
        . ltrim(
            $image,
            '/'
        );
}



function myBookingHotelCategoryLabel(?string $category): string
{
    $category = strtolower(trim((string)$category));

    return match ($category) {
        '3_star', '3' => '3 Star Hotel',
        '4_star', '4' => '4 Star Hotel',
        '5_star', '5' => '5 Star Hotel',
        default => 'Not specified'
    };
}


/*
|--------------------------------------------------------------------------
| STATUS CLASS
|--------------------------------------------------------------------------
*/

function bookingStatusClass($status)
{
    $status = strtolower(
        (string)$status
    );

    switch ($status) {

        case 'confirmed':
            return 'green';

        case 'completed':
            return 'blue';

        case 'cancelled':
            return 'red';

        default:
            return 'orange';
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#07192d"
>

<title>
My Bookings | <?= e($siteName); ?>
</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>

:root {

    --navy:#07192d;
    --navy-light:#102c4a;

    --blue:#0b74ff;
    --blue-dark:#075fd2;

    --green:#07966a;
    --orange:#dc8618;
    --red:#dc4356;

    --background:#f5f7fb;
    --white:#ffffff;

    --text:#172235;
    --muted:#788496;

    --border:#e4e9ef;

    --shadow:
        0 10px 35px
        rgba(7,25,45,.06);
}

* {
    margin:0;
    padding:0;
    box-sizing:border-box;
}

html {
    scroll-behavior:smooth;
}

body {

    min-height:100vh;

    background:var(--background);

    color:var(--text);

    font-family:
        'DM Sans',
        sans-serif;
}

a {
    color:inherit;
    text-decoration:none;
}

button,
input {
    font-family:inherit;
}


/* =========================================================
   HEADER
========================================================= */

.header {

    height:74px;

    padding:0 5%;

    position:sticky;

    top:0;

    z-index:1000;

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:25px;

    background:
        rgba(255,255,255,.97);

    border-bottom:
        1px solid
        var(--border);

    backdrop-filter:blur(10px);
}

.logo {

    display:flex;
    align-items:center;

    gap:10px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:20px;
    font-weight:800;
}

.logo-icon {

    width:40px;
    height:40px;

    border-radius:12px;

    display:grid;
    place-items:center;

    color:white;

    background:
        linear-gradient(
            135deg,
            #0b74ff,
            #00b8ff
        );
}

.logo span {
    color:var(--blue);
}


/* NAV */

.nav {

    display:flex;
    align-items:center;

    gap:7px;
}

.nav a {

    padding:9px 11px;

    border-radius:7px;

    color:#667487;

    font-size:10px;
    font-weight:700;

    transition:.2s;
}

.nav a:hover {
    background:#f2f6fb;
    color:var(--blue);
}

.nav a.active {
    background:#edf5ff;
    color:var(--blue);
}


/* USER */

.user-menu {

    display:flex;
    align-items:center;

    gap:9px;
}

.avatar {

    width:39px;
    height:39px;

    border-radius:11px;

    display:grid;
    place-items:center;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            #00a9ff
        );

    color:white;

    font-weight:800;
}

.user-info strong {

    display:block;

    color:var(--navy);

    font-size:10px;
}

.user-info span {

    display:block;

    margin-top:2px;

    color:#8b95a3;

    font-size:8px;
}


/* =========================================================
   HERO
========================================================= */

.hero {

    padding:
        46px 5%
        72px;

    color:white;

    background:
        radial-gradient(
            circle at 80% 10%,
            rgba(11,116,255,.35),
            transparent 32%
        ),
        linear-gradient(
            135deg,
            #07192d,
            #0b2948
        );
}

.hero-inner {

    max-width:1200px;

    margin:auto;
}

.breadcrumb {

    margin-bottom:12px;

    display:flex;
    align-items:center;

    gap:7px;

    color:#a9bdd2;

    font-size:9px;
}

.breadcrumb a:hover {
    color:white;
}

.hero h1 {

    font-family:
        'Manrope',
        sans-serif;

    font-size:34px;

    line-height:1.25;
}

.hero p {

    max-width:550px;

    margin-top:8px;

    color:#aebfd0;

    font-size:11px;

    line-height:1.7;
}


/* =========================================================
   CONTAINER
========================================================= */

.container {

    max-width:1200px;

    margin:
        -35px auto
        0;

    padding:
        0 20px
        70px;

    position:relative;

    z-index:2;
}


/* =========================================================
   SUMMARY
========================================================= */

.summary-grid {

    display:grid;

    grid-template-columns:
        repeat(4,1fr);

    gap:14px;
}

.summary-card {

    min-height:100px;

    padding:17px;

    border:
        1px solid
        var(--border);

    border-radius:13px;

    display:flex;
    align-items:center;

    gap:13px;

    background:white;

    box-shadow:var(--shadow);
}

.summary-icon {

    width:43px;
    height:43px;

    flex:0 0 43px;

    border-radius:11px;

    display:grid;
    place-items:center;

    background:#edf5ff;

    color:var(--blue);
}

.summary-card:nth-child(2)
.summary-icon {

    background:#fff4e6;
    color:var(--orange);
}

.summary-card:nth-child(3)
.summary-icon {

    background:#eaf9f3;
    color:var(--green);
}

.summary-card:nth-child(4)
.summary-icon {

    background:#f1edff;
    color:#7457cf;
}

.summary-info span {

    display:block;

    color:#8792a1;

    font-size:8px;
    font-weight:800;

    text-transform:uppercase;

    letter-spacing:.5px;
}

.summary-info strong {

    display:block;

    margin-top:5px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:20px;
}


/* =========================================================
   TOOLBAR
========================================================= */

.toolbar {

    margin-top:23px;

    padding:15px;

    border:
        1px solid
        var(--border);

    border-radius:12px;

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:15px;

    background:white;

    box-shadow:var(--shadow);
}

.filters {

    display:flex;

    gap:6px;

    flex-wrap:wrap;
}

.filter {

    min-height:34px;

    padding:0 11px;

    border:
        1px solid
        var(--border);

    border-radius:7px;

    display:inline-flex;
    align-items:center;

    gap:6px;

    color:#69768a;

    background:white;

    font-size:9px;
    font-weight:800;
}

.filter:hover {
    border-color:#b9d5f8;
    color:var(--blue);
}

.filter.active {

    border-color:var(--blue);

    background:#edf5ff;

    color:var(--blue);
}

.filter-count {

    min-width:18px;
    height:18px;

    padding:0 5px;

    border-radius:20px;

    display:grid;
    place-items:center;

    background:#edf0f4;

    font-size:8px;
}

.filter.active
.filter-count {

    background:var(--blue);

    color:white;
}


/* SEARCH */

.search-form {

    display:flex;

    gap:6px;
}

.search-input {

    width:230px;
    height:35px;

    padding:0 11px;

    border:
        1px solid
        var(--border);

    border-radius:7px;

    outline:none;

    color:var(--text);

    font-size:9px;
}

.search-input:focus {

    border-color:#8bbfff;

    box-shadow:
        0 0 0 3px
        rgba(11,116,255,.06);
}

.search-btn {

    width:37px;
    height:35px;

    border:0;

    border-radius:7px;

    display:grid;
    place-items:center;

    background:var(--blue);

    color:white;

    cursor:pointer;
}


/* =========================================================
   BOOKINGS
========================================================= */

.bookings {

    margin-top:20px;

    display:flex;
    flex-direction:column;

    gap:15px;
}

.booking-card {

    border:
        1px solid
        var(--border);

    border-radius:15px;

    background:white;

    box-shadow:var(--shadow);

    overflow:hidden;

    transition:.2s;
}

.booking-card:hover {

    transform:translateY(-2px);

    box-shadow:
        0 15px 40px
        rgba(7,25,45,.09);
}

.booking-top {

    min-height:47px;

    padding:0 17px;

    border-bottom:
        1px solid
        var(--border);

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:15px;

    background:#fbfcfd;
}

.booking-reference {

    display:flex;
    align-items:center;

    gap:7px;

    color:#778496;

    font-size:8px;
}

.booking-reference strong {

    color:var(--navy);

    font-size:10px;
}

.status {

    min-height:25px;

    padding:0 9px;

    border-radius:20px;

    display:inline-flex;
    align-items:center;

    gap:5px;

    font-size:8px;
    font-weight:800;

    text-transform:uppercase;
}

.status.orange {

    background:#fff3e3;

    color:#ad680c;
}

.status.green {

    background:#e8f8f1;

    color:#087d55;
}

.status.blue {

    background:#eaf3ff;

    color:#0967d4;
}

.status.red {

    background:#ffedef;

    color:#bd3447;
}


/* BOOKING BODY */

.booking-body {

    padding:18px;

    display:grid;

    grid-template-columns:
        170px
        minmax(0,1fr)
        220px;

    gap:20px;
}

.package-image {

    width:170px;
    height:130px;

    border-radius:11px;

    overflow:hidden;

    display:grid;
    place-items:center;

    background:
        linear-gradient(
            135deg,
            #0d2947,
            #0b74ff
        );

    color:white;

    font-size:28px;
}

.package-image img {

    width:100%;
    height:100%;

    object-fit:cover;
}

.package-details h2 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:17px;

    line-height:1.4;
}

.destination {

    margin-top:5px;

    color:#7d8998;

    font-size:9px;
}

.destination i {

    margin-right:4px;

    color:var(--blue);
}

.trip-info {

    margin-top:14px;

    display:grid;

    grid-template-columns:
        repeat(3,minmax(90px,1fr));

    gap:10px;
}

.trip-item {

    padding:10px;

    border-radius:8px;

    background:#f7f9fb;
}

.trip-item span {

    display:block;

    color:#8c97a5;

    font-size:7px;

    text-transform:uppercase;

    font-weight:800;
}

.trip-item strong {

    display:block;

    margin-top:4px;

    color:#445166;

    font-size:9px;
}


/* PRICE SIDE */

.booking-payment {

    padding-left:18px;

    border-left:
        1px solid
        var(--border);
}

.payment-label {

    color:#8b96a5;

    font-size:8px;
    font-weight:800;

    text-transform:uppercase;
}

.total-price {

    margin-top:4px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:21px;
    font-weight:800;
}

.payment-info {

    margin-top:11px;

    padding:9px;

    border-radius:7px;

    background:#f7f9fb;
}

.payment-line {

    padding:4px 0;

    display:flex;
    justify-content:space-between;

    gap:10px;

    font-size:8px;
}

.payment-line span {
    color:#8490a0;
}

.payment-line strong {
    color:#455267;
}

.payment-paid {
    color:var(--green) !important;
}

.payment-pending {
    color:var(--orange) !important;
}


/* =========================================================
   ACTIONS
========================================================= */

.booking-actions {

    margin-top:13px;

    display:flex;

    gap:6px;

    flex-wrap:wrap;
}

.btn {

    min-height:34px;

    padding:0 11px;

    border-radius:7px;

    display:inline-flex;
    align-items:center;
    justify-content:center;

    gap:5px;

    font-size:8px;
    font-weight:800;

    transition:.2s;
}

.btn-primary {

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--blue-dark)
        );

    color:white;
}

.btn-secondary {

    border:
        1px solid
        var(--border);

    background:white;

    color:#637084;
}

.btn-warning {

    background:#fff3e2;

    color:#ad680c;
}

.btn-success {

    background:#e8f8f1;

    color:#087d55;
}

.btn-danger {
    background:#ffedef;
    color:#bd3447;
}

.btn-cancel-pending {
    background:#fff3e3;
    color:#ad680c;
}

.btn:hover {
    transform:translateY(-1px);
}


/* =========================================================
   EMPTY
========================================================= */

.empty {

    margin-top:20px;

    padding:
        65px 20px;

    border:
        1px solid
        var(--border);

    border-radius:15px;

    background:white;

    box-shadow:var(--shadow);

    text-align:center;
}

.empty-icon {

    width:70px;
    height:70px;

    margin:
        0 auto
        15px;

    border-radius:50%;

    display:grid;
    place-items:center;

    background:#edf5ff;

    color:var(--blue);

    font-size:25px;
}

.empty h2 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:19px;
}

.empty p {

    max-width:450px;

    margin:
        7px auto
        18px;

    color:#8490a0;

    font-size:10px;

    line-height:1.6;
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:1000px) {

    .booking-body {

        grid-template-columns:
            150px
            minmax(0,1fr);
    }

    .package-image {

        width:150px;
    }

    .booking-payment {

        grid-column:
            1 / -1;

        padding:
            15px 0 0;

        border-left:0;

        border-top:
            1px solid
            var(--border);
    }

    .summary-grid {
        grid-template-columns:repeat(2,1fr);
    }
}


@media(max-width:800px) {

    .nav {
        display:none;
    }

    .toolbar {

        align-items:stretch;

        flex-direction:column;
    }

    .search-form {
        width:100%;
    }

    .search-input {
        flex:1;
        width:auto;
    }
}


@media(max-width:600px) {

    .header {

        height:65px;

        padding:0 13px;
    }

    .logo {
        font-size:17px;
    }

    .user-info {
        display:none;
    }

    .hero {

        padding:
            32px 15px
            62px;
    }

    .hero h1 {
        font-size:27px;
    }

    .container {

        padding:
            0 12px
            50px;
    }

    .summary-grid {
        grid-template-columns:1fr 1fr;
        gap:9px;
    }

    .summary-card {

        min-height:90px;

        padding:12px;
    }

    .summary-icon {

        width:36px;
        height:36px;

        flex-basis:36px;
    }

    .summary-info strong {
        font-size:17px;
    }

    .booking-top {

        padding:
            10px 13px;

        align-items:flex-start;

        flex-direction:column;
    }

    .booking-body {

        padding:13px;

        grid-template-columns:1fr;
    }

    .package-image {

        width:100%;
        height:180px;
    }

    .trip-info {

        grid-template-columns:
            repeat(2,1fr);
    }

    .booking-payment {

        grid-column:auto;
    }

    .booking-actions {

        flex-direction:column;
    }

    .btn {
        width:100%;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-public-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="public"></script>
</head>

<body>


<!-- =========================================================
     HEADER
========================================================= -->

<header class="header">

<a
    href="<?= e(BASE_URL); ?>"
    class="logo"
>

    <div class="logo-icon">
        <i class="fa-solid fa-plane"></i>
    </div>

    TRAV<span>SCOPE</span>

</a>


<nav class="nav">

    <a href="<?= e(BASE_URL); ?>">
        Home
    </a>

    <a href="<?= e(BASE_URL . 'packages.php'); ?>">
        Packages
    </a>

    <a
        href="<?= e(BASE_URL . 'my-bookings.php'); ?>"
        class="active"
    >
        My Bookings
    </a>

    <a href="<?= e(BASE_URL . 'dashboard.php'); ?>">
        Dashboard
    </a>

</nav>


<div class="user-menu">

    <div class="avatar">
        <?= e($userInitial); ?>
    </div>

    <div class="user-info">

        <strong>
            <?= e($fullName); ?>
        </strong>

        <span>
            Traveller
        </span>

    </div>

</div>

</header>


<!-- =========================================================
     HERO
========================================================= -->

<section class="hero">

<div class="hero-inner">

    <div class="breadcrumb">

        <a href="<?= e(BASE_URL); ?>">
            Home
        </a>

        <i class="fa-solid fa-chevron-right"></i>

        My Bookings

    </div>

    <h1>
        My Trips
    </h1>

    <p>
        Welcome back, <?= e($firstName); ?>.
        Manage your upcoming journeys, track payment verification
        and view your confirmed TRAVSCOPE bookings.
    </p>

</div>

</section>


<!-- =========================================================
     CONTENT
========================================================= -->

<main class="container">


<!-- SUMMARY -->

<section class="summary-grid">


    <div class="summary-card">

        <div class="summary-icon">
            <i class="fa-solid fa-suitcase"></i>
        </div>

        <div class="summary-info">

            <span>
                Total Trips
            </span>

            <strong>
                <?= number_format(
                    $counts['all']
                ); ?>
            </strong>

        </div>

    </div>


    <div class="summary-card">

        <div class="summary-icon">
            <i class="fa-regular fa-clock"></i>
        </div>

        <div class="summary-info">

            <span>
                Pending
            </span>

            <strong>
                <?= number_format(
                    $counts['pending']
                ); ?>
            </strong>

        </div>

    </div>


    <div class="summary-card">

        <div class="summary-icon">
            <i class="fa-solid fa-circle-check"></i>
        </div>

        <div class="summary-info">

            <span>
                Confirmed
            </span>

            <strong>
                <?= number_format(
                    $counts['confirmed']
                ); ?>
            </strong>

        </div>

    </div>


    <div class="summary-card">

        <div class="summary-icon">
            <i class="fa-solid fa-flag-checkered"></i>
        </div>

        <div class="summary-info">

            <span>
                Completed
            </span>

            <strong>
                <?= number_format(
                    $counts['completed']
                ); ?>
            </strong>

        </div>

    </div>


</section>


<!-- =========================================================
     FILTER
========================================================= -->

<section class="toolbar">


<div class="filters">

<?php

$filterLabels = [
    'all'       => 'All',
    'pending'   => 'Pending',
    'confirmed' => 'Confirmed',
    'completed' => 'Completed',
    'cancelled' => 'Cancelled'
];

?>

<?php foreach (
    $filterLabels
    as $key => $label
): ?>

    <a
        href="<?= e(
            BASE_URL
            . 'my-bookings.php?status='
            . urlencode($key)
        ); ?>"
        class="filter <?= $statusFilter === $key ? 'active' : ''; ?>"
    >

        <?= e($label); ?>

        <span class="filter-count">
            <?= number_format(
                $counts[$key]
            ); ?>
        </span>

    </a>

<?php endforeach; ?>

</div>


<form
    method="get"
    class="search-form"
>

    <?php if (
        $statusFilter !== 'all'
    ): ?>

        <input
            type="hidden"
            name="status"
            value="<?= e($statusFilter); ?>"
        >

    <?php endif; ?>


    <input
        type="text"
        name="search"
        value="<?= e($search); ?>"
        class="search-input"
        placeholder="Booking number or destination..."
    >

    <button
        type="submit"
        class="search-btn"
        aria-label="Search bookings"
    >
        <i class="fa-solid fa-magnifying-glass"></i>
    </button>

</form>


</section>


<!-- =========================================================
     BOOKINGS
========================================================= -->

<?php if (!$bookings): ?>


<section class="empty">

    <div class="empty-icon">
        <i class="fa-solid fa-plane-departure"></i>
    </div>

    <h2>
        No bookings found
    </h2>

    <p>

        <?php if ($search !== ''): ?>

            We couldn't find a booking matching your search.

        <?php elseif ($statusFilter !== 'all'): ?>

            You don't currently have any
            <?= e($statusFilter); ?> bookings.

        <?php else: ?>

            Your next adventure is waiting.
            Explore our travel packages and make your first booking.

        <?php endif; ?>

    </p>

    <a
        href="<?= e(BASE_URL . 'packages.php'); ?>"
        class="btn btn-primary"
    >

        <i class="fa-solid fa-compass"></i>

        Explore Packages

    </a>

</section>


<?php else: ?>


<section class="bookings">


<?php foreach ($bookings as $booking): ?>


<?php

$bookingId =
    (int)$booking['id'];

$bookingStatus =
    strtolower(
        (string)$booking['booking_status']
    );

$paymentStatus =
    strtolower(
        (string)$booking['payment_status']
    );

$latestPaymentStatus =
    strtolower(
        (string)(
            $booking['latest_payment_status']
            ?? ''
        )
    );

$latestCancellationStatus =
    strtolower(
        (string)(
            $booking['latest_cancellation_status']
            ?? ''
        )
    );

$totalAmount =
    max(
        0,
        (float)$booking['total_amount']
    );

$paidAmount =
    max(
        0,
        (float)$booking['paid_amount']
    );

$remaining =
    max(
        0,
        $totalAmount - $paidAmount
    );

$hotelCategoryLabel =
    myBookingHotelCategoryLabel(
        $booking['hotel_category']
        ?? ''
    );

$hotelPricePerAdult =
    max(
        0,
        (float)(
            $booking['hotel_price']
            ?? 0
        )
    );

$adultCount =
    max(
        1,
        (int)(
            $booking['adults']
            ?? 1
        )
    );

$adultPackageSubtotal =
    round(
        $hotelPricePerAdult
        * $adultCount,
        2
    );

$imageUrl =
    bookingImageUrl(
        $booking['main_image']
        ?? ''
    );

$statusClass =
    bookingStatusClass(
        $bookingStatus
    );

?>


<article class="booking-card">


<!-- TOP -->

<div class="booking-top">

    <div class="booking-reference">

        <i class="fa-solid fa-ticket"></i>

        Booking

        <strong>
            <?= e(
                $booking['booking_number']
            ); ?>
        </strong>

        <span>
            •
        </span>

        <?= date(
            'd M Y',
            strtotime(
                $booking['created_at']
            )
        ); ?>

    </div>


    <span
        class="status <?= e($statusClass); ?>"
    >

        <?php if (
            $bookingStatus === 'confirmed'
        ): ?>

            <i class="fa-solid fa-check"></i>

        <?php elseif (
            $bookingStatus === 'pending'
        ): ?>

            <i class="fa-regular fa-clock"></i>

        <?php elseif (
            $bookingStatus === 'completed'
        ): ?>

            <i class="fa-solid fa-flag-checkered"></i>

        <?php else: ?>

            <i class="fa-solid fa-xmark"></i>

        <?php endif; ?>

        <?= e(
            ucfirst(
                $bookingStatus
            )
        ); ?>

    </span>

</div>


<!-- BODY -->

<div class="booking-body">


<!-- IMAGE -->

<div class="package-image">

    <?php if ($imageUrl !== ''): ?>

        <img
            src="<?= e($imageUrl); ?>"
            alt="<?= e(
                $booking['package_title']
                ?: 'Travel Package'
            ); ?>"
            loading="lazy"
        >

    <?php else: ?>

        <i class="fa-solid fa-mountain-sun"></i>

    <?php endif; ?>

</div>


<!-- DETAILS -->

<div class="package-details">


    <h2>
        <?= e(
            $booking['package_title']
            ?: 'Travel Package'
        ); ?>
    </h2>


    <div class="destination">

        <i class="fa-solid fa-location-dot"></i>

        <?= e(
            $booking['destination_name']
            ?: 'Destination'
        ); ?>

        <?php if (
            !empty(
                $booking['destination_country']
            )
        ): ?>

            ,
            <?= e(
                $booking['destination_country']
            ); ?>

        <?php endif; ?>

    </div>


    <div class="trip-info">


        <div class="trip-item">

            <span>
                Travel Date
            </span>

            <strong>

                <?php if (
                    !empty(
                        $booking['travel_date']
                    )
                ): ?>

                    <?= e(
                        date(
                            'd M Y',
                            strtotime(
                                $booking['travel_date']
                            )
                        )
                    ); ?>

                <?php else: ?>

                    Not Set

                <?php endif; ?>

            </strong>

        </div>


        <div class="trip-item">

            <span>
                Hotel Category
            </span>

            <strong>
                <?= e($hotelCategoryLabel); ?>
            </strong>

        </div>


        <div class="trip-item">

            <span>
                Price Per Adult
            </span>

            <strong>

                <?php if ($hotelPricePerAdult > 0): ?>

                    <?= e($currencySymbol); ?>
                    <?= number_format(
                        $hotelPricePerAdult,
                        2
                    ); ?>

                <?php else: ?>

                    Not available

                <?php endif; ?>

            </strong>

        </div>


        <div class="trip-item">

            <span>
                Duration
            </span>

            <strong>

                <?= (int)$booking['duration_days']; ?>
                Days /

                <?= (int)$booking['duration_nights']; ?>
                Nights

            </strong>

        </div>


        <div class="trip-item">

            <span>
                Travellers
            </span>

            <strong>

                <?= (int)$booking['adults']; ?>
                Adult<?= (int)$booking['adults'] !== 1 ? 's' : ''; ?>

                <?php if (
                    (int)$booking['children'] > 0
                ): ?>

                    +
                    <?= (int)$booking['children']; ?>
                    Child<?= (int)$booking['children'] !== 1 ? 'ren' : ''; ?>

                <?php endif; ?>

            </strong>

        </div>


        <?php if (
            !empty(
                $booking['package_code']
            )
        ): ?>

            <div class="trip-item">

                <span>
                    Package Code
                </span>

                <strong>
                    <?= e(
                        $booking['package_code']
                    ); ?>
                </strong>

            </div>

        <?php endif; ?>


    </div>


</div>


<!-- PAYMENT -->

<div class="booking-payment">


    <div class="payment-label">
        Final Booking Total
    </div>

    <div class="total-price">

        <?= e($currencySymbol); ?>

        <?= number_format(
            $totalAmount,
            2
        ); ?>

    </div>


    <div class="payment-info">


        <div class="payment-line">

            <span>
                Adult Package
            </span>

            <strong>

                <?= e($currencySymbol); ?>

                <?= number_format(
                    $adultPackageSubtotal,
                    2
                ); ?>

            </strong>

        </div>


        <div class="payment-line">

            <span>
                Paid
            </span>

            <strong class="payment-paid">

                <?= e($currencySymbol); ?>

                <?= number_format(
                    $paidAmount,
                    2
                ); ?>

            </strong>

        </div>


        <div class="payment-line">

            <span>
                Remaining
            </span>

            <strong>

                <?= e($currencySymbol); ?>

                <?= number_format(
                    $remaining,
                    2
                ); ?>

            </strong>

        </div>


        <div class="payment-line">

            <span>
                Payment
            </span>

            <strong
                class="<?= $paymentStatus === 'paid'
                    ? 'payment-paid'
                    : 'payment-pending'; ?>"
            >

                <?= e(
                    ucfirst(
                        $paymentStatus
                    )
                ); ?>

            </strong>

        </div>


    </div>


    <!-- ACTION BUTTONS -->

    <div class="booking-actions">


        <?php
        /*
        |--------------------------------------------------------------------------
        | PENDING PAYMENT VERIFICATION
        |--------------------------------------------------------------------------
        */
        if (
            $latestPaymentStatus === 'pending'
        ):
        ?>

            <a
                href="<?= e(
                    BASE_URL
                    . 'payment-pending.php?booking='
                    . $bookingId
                ); ?>"
                class="btn btn-warning"
            >

                <i class="fa-regular fa-clock"></i>

                Verification Status

            </a>


        <?php
        /*
        |--------------------------------------------------------------------------
        | FAILED PAYMENT
        |--------------------------------------------------------------------------
        */
        elseif (
            $latestPaymentStatus === 'failed'
            &&
            $paymentStatus !== 'paid'
        ):
        ?>

            <a
                href="<?= e(
                    BASE_URL
                    . 'payment.php?booking='
                    . $bookingId
                ); ?>"
                class="btn btn-primary"
            >

                <i class="fa-solid fa-rotate-right"></i>

                Retry Payment

            </a>


        <?php
        /*
        |--------------------------------------------------------------------------
        | PAID BOOKING
        |--------------------------------------------------------------------------
        */
        elseif (
            $paymentStatus === 'paid'
        ):
        ?>

            <a
                href="<?= e(
                    BASE_URL
                    . 'booking-details.php?booking='
                    . $bookingId
                ); ?>"
                class="btn btn-success"
            >

                <i class="fa-solid fa-eye"></i>

                View Booking

            </a>


            <a
                href="<?= e(
                    BASE_URL
                    . 'booking-success.php?booking='
                    . $bookingId
                ); ?>"
                class="btn btn-secondary"
            >

                <i class="fa-solid fa-receipt"></i>

                Confirmation

            </a>


        <?php
        /*
        |--------------------------------------------------------------------------
        | UNPAID BOOKING
        |--------------------------------------------------------------------------
        */
        elseif (
            $bookingStatus !== 'cancelled'
        ):
        ?>

            <a
                href="<?= e(
                    BASE_URL
                    . 'payment.php?booking='
                    . $bookingId
                ); ?>"
                class="btn btn-primary"
            >

                <i class="fa-solid fa-credit-card"></i>

                Pay Now

            </a>


        <?php endif; ?>


        <?php if (
            !in_array(
                $bookingStatus,
                ['cancelled', 'completed'],
                true
            )
        ): ?>

            <?php if ($latestCancellationStatus === 'pending'): ?>

                <a
                    href="<?= e(
                        BASE_URL
                        . 'cancel-booking.php?booking='
                        . $bookingId
                    ); ?>"
                    class="btn btn-cancel-pending"
                >
                    <i class="fa-regular fa-clock"></i>
                    Cancellation Pending
                </a>

            <?php else: ?>

                <a
                    href="<?= e(
                        BASE_URL
                        . 'cancel-booking.php?booking='
                        . $bookingId
                    ); ?>"
                    class="btn btn-danger"
                >
                    <i class="fa-solid fa-ban"></i>
                    Cancel Booking
                </a>

            <?php endif; ?>

        <?php endif; ?>


        <a
            href="<?= e(
                BASE_URL
                . 'booking-details.php?booking='
                . $bookingId
            ); ?>"
            class="btn btn-secondary"
        >

            <i class="fa-solid fa-circle-info"></i>

            Details

        </a>


    </div>


</div>


</div>


</article>


<?php endforeach; ?>


</section>


<?php endif; ?>


</main>



<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>