TRAVSCOPE V24.1 — CLEAR ENQUIRY + QUOTATION WORKSPACE PATCH
Date: 26 September 2026
Base: TRAVSCOPE V24.0

PURPOSE
Make the enquiry-to-quotation workflow easy to understand and remove the confusing duplicate direct enquiry-to-booking path.

FILES TO UPLOAD
1. admin-enquiry-details.php
2. admin-customer-quotations.php

UPLOAD LOCATION
Upload both files to the same public_html folder, replacing the existing files.
Back up the current files first.

DATABASE / SQL
NO SQL IMPORT IS REQUIRED for this patch.
No tables or columns are created, deleted, or altered.

WHAT CHANGED — ADMIN ENQUIRY DETAILS
- Removed the old manual "Convert Enquiry to Booking" form.
- Old POST attempts to direct-convert an enquiry are blocked server-side.
- Added one clear Enquiry -> Quotation Workspace.
- Added 6 visible workflow steps:
  1. Enquiry
  2. Quotation
  3. Send
  4. Customer Decision
  5. Admin Review
  6. Booking
- Shows customer/trip summary, PAX, budget and latest selling price.
- Shows latest quotation version, package, hotel category and creation date.
- Clear actions:
  Create Quotation
  Open / Edit Quotation
  Preview Customer View
  Quotation Versions
  Review Accepted Quotation
  Create Revised Version
  Open Booking
- Shows a clear "Next action" message depending on workflow state.

WHAT CHANGED — CUSTOMER QUOTATION DESK
- Replaced the hard-to-read quotation table with a clearer quotation desk.
- Shows customer, quotation version/status, trip, PAX, hotel, selling price, created/sent time, customer decision and actions.
- Added Enquiry-specific filtering using ?lead=ENQUIRY_ID.
- Status is visible as Prepared / Accepted Review / Changes Requested / Rejected / Booking Created.
- Customer note is visible when present.
- Accepted quotation shows Admin Review action.
- Converted quotation shows linked booking number/action.

IMPORTANT WORKFLOW RULE
Customer acceptance does NOT directly create a booking.
The intended flow remains:
Enquiry -> Quotation -> Customer Decision -> Admin Review -> Supplier/Availability Review -> Convert to Booking -> Operations.

SAFETY / COMPATIBILITY
- Existing quotation versions are reused.
- Existing quotation_customer_responses and quotation_acceptances are reused when available.
- Queries are guarded so the page does not fail on older schema variants.
- Existing CRM quotation editor remains the source for editing quotation contents.
- Existing bookings are not modified by this patch.

VALIDATION COMPLETED
- PHP lint: admin-enquiry-details.php — PASS
- PHP lint: admin-customer-quotations.php — PASS
- Direct INSERT INTO bookings removed from admin-enquiry-details.php — VERIFIED
- Direct convert_booking form removed — VERIFIED
