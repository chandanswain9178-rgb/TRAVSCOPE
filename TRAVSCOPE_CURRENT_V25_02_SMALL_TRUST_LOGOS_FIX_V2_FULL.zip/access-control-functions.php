<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — PERMISSIONS + APPROVAL CONTROL MATRIX
|--------------------------------------------------------------------------
|
| IMPORTANT BACKWARD COMPATIBILITY
| If the ACL SQL has not yet been imported, existing active admins retain
| the same access they had before this phase. This prevents accidental
| lockout during deployment. Once the SQL exists, profile + override rules
| become authoritative for protected actions.
|
*/

function tsAclTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];
    $key = strtolower($table);
    if (array_key_exists($key, $cache)) return $cache[$key];
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;

    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
        $stmt->execute([$table]);
        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}

function tsAclReady(PDO $pdo): bool
{
    return tsAclTableExists($pdo, 'admin_access_assignments')
        && tsAclTableExists($pdo, 'admin_permission_overrides')
        && tsAclTableExists($pdo, 'protected_action_audit');
}

function tsAclPermissionCatalog(): array
{
    return [
        'commercial' => [
            'view_supplier_cost' => 'View Supplier Cost',
            'view_margin' => 'View Margin / Profitability',
            'edit_markup' => 'Create / Edit Quotation Markup',
            'approve_discount' => 'Approve Customer Discount',
            'send_quotation' => 'Send Customer Quotation',
        ],
        'supplier' => [
            'select_supplier' => 'Select Supplier Quote',
            'manage_supplier_procurement' => 'Manage Supplier Procurement',
            'approve_supplier_invoice' => 'Approve Supplier Invoice',
            'record_supplier_payment' => 'Record Supplier Payment',
        ],
        'customer_finance' => [
            'record_customer_payment' => 'Approve / Reject Customer Payment',
            'post_billing_adjustment' => 'Post Credit / Debit Adjustment',
        ],
        'booking_operations' => [
            'confirm_booking' => 'Confirm Booking',
            'approve_amendment' => 'Approve Booking Amendment',
            'manage_operations' => 'Manage Travel Operations / Completion',
            'issue_final_voucher' => 'Issue Final Customer Voucher',
            'issue_final_document_pack' => 'Issue Final Trip Document Pack',
            'close_profitability' => 'Financially Close Profitability',
        ],
        'administration' => [
            'manage_access' => 'Manage Permissions',
            'view_audit' => 'View Protected Action Audit',
        ],
    ];
}

function tsAclAllPermissionKeys(): array
{
    $keys = [];
    foreach (tsAclPermissionCatalog() as $group) {
        foreach ($group as $key => $label) $keys[] = $key;
    }
    return $keys;
}

function tsAclProfiles(): array
{
    $all = array_fill_keys(tsAclAllPermissionKeys(), true);

    return [
        'super_admin' => $all,
        'admin' => $all,
        'sales' => array_merge(array_fill_keys(tsAclAllPermissionKeys(), false), [
            'view_supplier_cost' => true,
            'view_margin' => false,
            'edit_markup' => true,
            'send_quotation' => true,
        ]),
        'operations' => array_merge(array_fill_keys(tsAclAllPermissionKeys(), false), [
            'view_supplier_cost' => true,
            'select_supplier' => true,
            'manage_supplier_procurement' => true,
            'confirm_booking' => true,
            'approve_amendment' => true,
            'manage_operations' => true,
            'issue_final_voucher' => true,
            'issue_final_document_pack' => true,
        ]),
        'finance' => array_merge(array_fill_keys(tsAclAllPermissionKeys(), false), [
            'view_supplier_cost' => true,
            'view_margin' => true,
            'edit_markup' => true,
            'approve_discount' => true,
            'approve_supplier_invoice' => true,
            'record_supplier_payment' => true,
            'record_customer_payment' => true,
            'post_billing_adjustment' => true,
            'approve_amendment' => true,
            'close_profitability' => true,
        ]),
    ];
}

function tsAclLegacyProfile(string $legacyRole): string
{
    return match (strtolower(trim($legacyRole))) {
        'super_admin' => 'super_admin',
        'staff' => 'sales',
        default => 'admin',
    };
}

function tsAclAdminRow(PDO $pdo, int $adminId): ?array
{
    if ($adminId <= 0) return null;
    try {
        $stmt = $pdo->prepare("SELECT id,name,email,role,status FROM admins WHERE id=? LIMIT 1");
        $stmt->execute([$adminId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

function tsAclProfile(PDO $pdo, int $adminId, ?string $legacyRole = null): string
{
    $legacyRole ??= (string)(tsAclAdminRow($pdo, $adminId)['role'] ?? 'admin');
    $fallback = tsAclLegacyProfile($legacyRole);
    if (!tsAclReady($pdo)) return $fallback;

    try {
        $stmt = $pdo->prepare("SELECT access_profile FROM admin_access_assignments WHERE admin_id=? LIMIT 1");
        $stmt->execute([$adminId]);
        $profile = trim((string)($stmt->fetchColumn() ?: ''));
        return array_key_exists($profile, tsAclProfiles()) ? $profile : $fallback;
    } catch (Throwable $e) {
        return $fallback;
    }
}

function tsAclEffective(PDO $pdo, int $adminId, ?string $legacyRole = null): array
{
    $profile = tsAclProfile($pdo, $adminId, $legacyRole);
    $profiles = tsAclProfiles();
    $effective = $profiles[$profile] ?? $profiles['admin'];

    if (!tsAclReady($pdo)) return $effective;

    try {
        $stmt = $pdo->prepare("SELECT permission_key,effect FROM admin_permission_overrides WHERE admin_id=?");
        $stmt->execute([$adminId]);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
            $key = (string)$row['permission_key'];
            if (array_key_exists($key, $effective)) {
                $effective[$key] = ((string)$row['effect'] === 'allow');
            }
        }
    } catch (Throwable $e) {
        error_log('ACL overrides: ' . $e->getMessage());
    }

    return $effective;
}

function tsAclCan(PDO $pdo, int $adminId, string $permission, ?string $legacyRole = null): bool
{
    if ($adminId <= 0) return false;
    $admin = tsAclAdminRow($pdo, $adminId);
    if (!$admin || (string)$admin['status'] !== 'active') return false;

    /* Deployment compatibility: before SQL, preserve previous access. */
    if (!tsAclReady($pdo)) return true;

    $effective = tsAclEffective($pdo, $adminId, $legacyRole ?? (string)$admin['role']);
    return !empty($effective[$permission]);
}

function tsAclAudit(
    PDO $pdo,
    int $adminId,
    string $permission,
    string $actionKey,
    string $result,
    ?string $entityType = null,
    ?int $entityId = null,
    array $details = []
): void {
    if (!tsAclReady($pdo)) return;
    if (!in_array($result, ['authorized','denied'], true)) return;

    try {
        $profile = tsAclProfile($pdo, $adminId);
        $stmt = $pdo->prepare("INSERT INTO protected_action_audit(admin_id,permission_key,action_key,entity_type,entity_id,result,access_profile,request_method,ip_address,user_agent,details_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([
            $adminId > 0 ? $adminId : null,
            mb_substr($permission, 0, 80),
            mb_substr($actionKey, 0, 100),
            $entityType !== null ? mb_substr($entityType, 0, 60) : null,
            $entityId && $entityId > 0 ? $entityId : null,
            $result,
            $profile,
            mb_substr((string)($_SERVER['REQUEST_METHOD'] ?? ''), 0, 12),
            mb_substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64),
            mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
            $details ? json_encode($details, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : null,
        ]);
    } catch (Throwable $e) {
        error_log('ACL audit: ' . $e->getMessage());
    }
}

function tsAclRequire(
    PDO $pdo,
    int $adminId,
    string $permission,
    string $actionKey,
    ?string $entityType = null,
    ?int $entityId = null,
    array $details = []
): void {
    $allowed = tsAclCan($pdo, $adminId, $permission);
    tsAclAudit($pdo, $adminId, $permission, $actionKey, $allowed ? 'authorized' : 'denied', $entityType, $entityId, $details);

    if (!$allowed) {
        $label = $permission;
        foreach (tsAclPermissionCatalog() as $group) {
            if (isset($group[$permission])) { $label = $group[$permission]; break; }
        }
        throw new RuntimeException('Permission denied: ' . $label . '. Contact an Admin/Super Admin to change your access profile.');
    }
}

function tsAclSaveAdminAccess(PDO $pdo, int $actorAdminId, int $targetAdminId, string $profile, array $overrideInput): void
{
    if (!tsAclReady($pdo)) throw new RuntimeException('Import the Permissions SQL first.');
    tsAclRequire($pdo, $actorAdminId, 'manage_access', 'save_admin_access', 'admin', $targetAdminId, ['profile'=>$profile]);

    $profiles = tsAclProfiles();
    if (!isset($profiles[$profile])) throw new RuntimeException('Invalid access profile.');
    $target = tsAclAdminRow($pdo, $targetAdminId);
    if (!$target) throw new RuntimeException('Admin account not found.');

    /* Prevent the last access manager from locking themselves out. */
    $futureManageAccess = !empty($profiles[$profile]['manage_access']);
    $manageOverride = (string)($overrideInput['manage_access'] ?? 'inherit');
    if ($manageOverride === 'allow') $futureManageAccess = true;
    if ($manageOverride === 'deny') $futureManageAccess = false;

    if ($targetAdminId === $actorAdminId && !$futureManageAccess) {
        $stmt = $pdo->prepare("SELECT id FROM admins WHERE status='active' AND id<>? ORDER BY id ASC");
        $stmt->execute([$actorAdminId]);
        $otherManager = false;
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) ?: [] as $otherAdminId) {
            if (tsAclCan($pdo, (int)$otherAdminId, 'manage_access')) {
                $otherManager = true;
                break;
            }
        }
        if (!$otherManager) {
            throw new RuntimeException('Cannot remove your Manage Permissions access because no other active Admin can manage Access Control.');
        }
    }

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("INSERT INTO admin_access_assignments(admin_id,access_profile,updated_by_admin_id) VALUES(?,?,?) ON DUPLICATE KEY UPDATE access_profile=VALUES(access_profile),updated_by_admin_id=VALUES(updated_by_admin_id),updated_at=NOW()");
        $stmt->execute([$targetAdminId,$profile,$actorAdminId]);

        $pdo->prepare("DELETE FROM admin_permission_overrides WHERE admin_id=?")->execute([$targetAdminId]);
        $insert = $pdo->prepare("INSERT INTO admin_permission_overrides(admin_id,permission_key,effect,updated_by_admin_id) VALUES(?,?,?,?)");

        foreach (tsAclAllPermissionKeys() as $key) {
            $effect = (string)($overrideInput[$key] ?? 'inherit');
            if (!in_array($effect, ['allow','deny'], true)) continue;
            $insert->execute([$targetAdminId,$key,$effect,$actorAdminId]);
        }

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function tsAclOverrides(PDO $pdo, int $adminId): array
{
    if (!tsAclReady($pdo)) return [];
    try {
        $stmt = $pdo->prepare("SELECT permission_key,effect FROM admin_permission_overrides WHERE admin_id=?");
        $stmt->execute([$adminId]);
        $out=[];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $r) $out[(string)$r['permission_key']] = (string)$r['effect'];
        return $out;
    } catch (Throwable $e) { return []; }
}

function tsAclAuditRows(PDO $pdo, int $limit = 200): array
{
    if (!tsAclReady($pdo)) return [];
    $limit = max(1, min(500, $limit));
    try {
        $sql = "SELECT a.*,ad.name admin_name FROM protected_action_audit a LEFT JOIN admins ad ON ad.id=a.admin_id ORDER BY a.id DESC LIMIT " . $limit;
        return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) { return []; }
}
