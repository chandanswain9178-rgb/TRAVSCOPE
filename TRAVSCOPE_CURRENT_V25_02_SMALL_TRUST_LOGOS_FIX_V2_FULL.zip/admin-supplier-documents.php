<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/supplier-functions.php';
require_once __DIR__ . '/supplier-document-functions.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . BASE_URL . 'login.php'); exit;
}
$adminId = (int)$_SESSION['admin_id'];
$stmt = $pdo->prepare("SELECT id,name,email,role,status FROM admins WHERE id=? LIMIT 1");
$stmt->execute([$adminId]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$admin || ($admin['status'] ?? '') !== 'active') {
    unset($_SESSION['admin_id']);
    header('Location: ' . BASE_URL . 'login.php'); exit;
}

function sdocE(?string $v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function sdocTypeLabel(string $v): string { return ucwords(str_replace('_',' ', $v)); }

$schemaNotice = '';
try {
    $schemaResult = tsSupplierDocumentEnsureSchema($pdo);
    if (!empty($schemaResult['changed'])) $schemaNotice = 'Step 11A document/version tables were installed automatically.';
} catch (Throwable $schemaException) {
    $schemaNotice = 'Step 11A automatic setup could not complete: ' . $schemaException->getMessage();
}

if (empty($_SESSION['supplier_document_csrf'])) {
    $_SESSION['supplier_document_csrf'] = bin2hex(random_bytes(32));
}
$csrf = (string)$_SESSION['supplier_document_csrf'];
$success = (string)($_SESSION['supplier_document_success'] ?? '');
$error = (string)($_SESSION['supplier_document_error'] ?? '');
unset($_SESSION['supplier_document_success'], $_SESSION['supplier_document_error']);

$ready = tsSupplierDocumentCenterReady($pdo);
$suppliers = $pdo->query("SELECT id,supplier_code,company_name,default_currency,status FROM suppliers ORDER BY company_name")
    ->fetchAll(PDO::FETCH_ASSOC) ?: [];
$destinations = $pdo->query("SELECT id,name,country,status FROM destinations ORDER BY country,name")
    ->fetchAll(PDO::FETCH_ASSOC) ?: [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) {
            throw new RuntimeException('Security verification failed.');
        }
        if (!$ready) {
            throw new RuntimeException('Step 11A document/version tables are unavailable. Import travscope-step-11a-milesweb-safe.sql if automatic setup is blocked by hosting permissions.');
        }

        $action = trim((string)($_POST['action'] ?? ''));
        if ($action === 'upload_document') {
            if (!isset($_FILES['supplier_pdf'])) throw new RuntimeException('Choose a supplier PDF or DOCX rate-sheet document.');

            $supplierId = max(0, (int)($_POST['supplier_id'] ?? 0));
            $destinationId = max(0, (int)($_POST['destination_id'] ?? 0));
            $documentId = tsSupplierDocumentUpload(
                $pdo,
                $_FILES['supplier_pdf'],
                $supplierId,
                $destinationId ?: null,
                $adminId,
                [
                    'document_type' => trim((string)($_POST['document_type'] ?? 'auto')),
                    'title' => trim((string)($_POST['title'] ?? '')),
                    'source_channel' => trim((string)($_POST['source_channel'] ?? 'manual_upload')),
                    'source_email' => trim((string)($_POST['source_email'] ?? '')),
                    'received_at' => trim((string)($_POST['received_at'] ?? '')),
                    'valid_from' => trim((string)($_POST['valid_from'] ?? '')),
                    'valid_to' => trim((string)($_POST['valid_to'] ?? '')),
                    'currency' => trim((string)($_POST['currency'] ?? 'INR')),
                    'notes' => trim((string)($_POST['notes'] ?? '')),
                ]
            );

            $_SESSION['supplier_document_success'] = 'Supplier source document saved and analyzed. Review the detected contract data before activation.';
            header('Location: admin-supplier-document.php?id=' . $documentId); exit;
        }

        throw new RuntimeException('Invalid Supplier Document action.');
    } catch (Throwable $e) {
        $_SESSION['supplier_document_error'] = $e->getMessage();
        header('Location: admin-supplier-documents.php'); exit;
    }
}

$q = trim((string)($_GET['q'] ?? ''));
$supplierFilter = max(0, (int)($_GET['supplier_id'] ?? 0));
$typeFilter = trim((string)($_GET['document_type'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));

$documents = [];
$stats = ['total'=>0,'review'=>0,'linked'=>0,'failed'=>0];
if ($ready) {
    $stats = $pdo->query("\n        SELECT COUNT(*) total,\n               SUM(status='review') review,\n               SUM(status='linked') linked,\n               SUM(status='failed') failed\n        FROM supplier_documents\n    ")->fetch(PDO::FETCH_ASSOC) ?: $stats;

    $where = ['1=1']; $params = [];
    if ($q !== '') {
        $where[] = '(sd.document_code LIKE ? OR sd.title LIKE ? OR sd.original_filename LIKE ? OR s.company_name LIKE ?)';
        $like = '%' . $q . '%';
        array_push($params, $like, $like, $like, $like);
    }
    if ($supplierFilter > 0) { $where[] = 'sd.supplier_id=?'; $params[] = $supplierFilter; }
    if ($typeFilter !== '') { $where[] = 'sd.document_type=?'; $params[] = $typeFilter; }
    if ($statusFilter !== '') { $where[] = 'sd.status=?'; $params[] = $statusFilter; }

    $sql = "\n        SELECT sd.*,s.company_name,s.supplier_code,d.name destination_name,\n               (SELECT COUNT(*) FROM supplier_contract_versions v WHERE v.supplier_document_id=sd.id) version_count,\n               (SELECT c.contract_code FROM supplier_contract_versions v JOIN supplier_contracts c ON c.id=v.contract_id WHERE v.supplier_document_id=sd.id ORDER BY v.id DESC LIMIT 1) contract_code\n        FROM supplier_documents sd\n        JOIN suppliers s ON s.id=sd.supplier_id\n        LEFT JOIN destinations d ON d.id=sd.destination_id\n        WHERE " . implode(' AND ', $where) . "\n        ORDER BY sd.received_at DESC,sd.id DESC\n        LIMIT 250\n    ";
    $stmt = $pdo->prepare($sql); $stmt->execute($params);
    $documents = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


$contracts = [];
try {
    $contractWhere = $supplierFilter > 0 ? 'WHERE c.supplier_id=?' : '';
    $contractParams = $supplierFilter > 0 ? [$supplierFilter] : [];
    $sqlContracts = "
        SELECT c.*, s.company_name, s.supplier_code,
               (SELECT COUNT(*) FROM supplier_rate_cards rc WHERE rc.contract_id=c.id) AS predefined_rate_count,
               (SELECT COUNT(*) FROM supplier_contract_versions cv WHERE cv.contract_id=c.id) AS document_version_count
        FROM supplier_contracts c
        JOIN suppliers s ON s.id=c.supplier_id
        {$contractWhere}
        ORDER BY CASE c.status WHEN 'active' THEN 1 WHEN 'draft' THEN 2 ELSE 3 END, c.id DESC
        LIMIT 150
    ";
    $stc=$pdo->prepare($sqlContracts); $stc->execute($contractParams); $contracts=$stc->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $ignored) { $contracts=[]; }

$current = basename($_SERVER['PHP_SELF']);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Supplier Document Center | TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f5f7fb;color:#172033;font-family:Arial,sans-serif}.sidebar{position:fixed;inset:0 auto 0 0;width:260px;background:#07192d;color:#fff;padding:22px 14px;overflow:auto}.brand{display:flex;gap:12px;align-items:center;color:#fff;text-decoration:none;padding:7px 10px 20px}.brand strong{display:block}.brand small{color:#9fb0c6}.menu-title{font-size:10px;letter-spacing:.12em;color:#70849d;padding:19px 12px 7px;font-weight:800}.menu-link{display:flex;gap:11px;align-items:center;color:#c8d2df;text-decoration:none;padding:11px 12px;border-radius:10px;font-size:14px}.menu-link:hover,.menu-link.active{background:#122b47;color:#fff}.menu-link i{width:18px}.main{margin-left:260px}.topbar{height:72px;background:#fff;border-bottom:1px solid #e4e8ef;display:flex;align-items:center;justify-content:space-between;padding:0 26px}.page{padding:26px}.heading{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;margin-bottom:18px}.heading h1{margin:0;font-size:27px}.heading p{margin:6px 0;color:#718096}.btn{border:0;border-radius:10px;padding:10px 14px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;gap:7px;align-items:center}.primary{background:#0b74ff;color:#fff}.soft{background:#edf4ff;color:#145fb7}.dark{background:#172033;color:#fff}.panel{background:#fff;border:1px solid #e5e9f0;border-radius:16px;padding:19px;margin-bottom:17px;box-shadow:0 6px 24px rgba(7,25,45,.04)}.cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:17px}.card{background:#fff;border:1px solid #e5e9f0;border-radius:14px;padding:16px}.card small{color:#738196;font-weight:700}.card strong{display:block;font-size:25px;margin-top:7px}.alert{padding:12px 14px;border-radius:10px;margin-bottom:15px}.ok{background:#e9f8ef;color:#17663e}.err{background:#fff0f0;color:#a23030}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:11px}.full{grid-column:1/-1}.label{display:block;font-size:11px;font-weight:800;margin-bottom:6px}.input,select,textarea{width:100%;border:1px solid #d8e0ea;border-radius:10px;padding:10px;font:inherit;background:#fff}textarea{min-height:75px}.filters{display:grid;grid-template-columns:2fr 1fr 1fr 1fr auto;gap:9px}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;min-width:1050px}th,td{text-align:left;padding:12px 10px;border-bottom:1px solid #edf1f5;font-size:12px;vertical-align:top}th{font-size:10px;text-transform:uppercase;color:#69778a}.badge{display:inline-flex;padding:5px 8px;border-radius:999px;font-size:9px;font-weight:900;background:#eef4fb;color:#335a87}.badge.review{background:#fff7ed;color:#c2410c}.badge.linked{background:#ecfdf5;color:#047857}.badge.failed{background:#fef2f2;color:#b91c1c}.score{font-weight:900;color:#0f766e}.muted{color:#778494}.upload-help{font-size:12px;color:#6b7789;line-height:1.55}.empty{text-align:center;padding:28px;color:#7b8797}@media(max-width:900px){.sidebar{position:static;width:auto}.main{margin-left:0}.cards,.grid,.filters{grid-template-columns:1fr}.full{grid-column:auto}.topbar{padding:0 15px}.page{padding:15px}}

/* V24.70 International Supplier Document Center */
.page{padding:18px 20px}.heading{position:relative;overflow:hidden;border:1px solid #dbe6f2;border-radius:16px;background:linear-gradient(135deg,#fff 0%,#f7fbff 70%,#eef8ff 100%);padding:14px 16px;margin-bottom:10px;box-shadow:0 8px 24px rgba(15,42,76,.055);align-items:center}.heading:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:linear-gradient(180deg,#0b74ff,#18b7b0)}.heading h1{font-size:22px;color:#102a4f}.heading p{font-size:11px;margin:4px 0 0;max-width:980px}.doc-eyebrow{font-size:8px;font-weight:950;letter-spacing:.12em;text-transform:uppercase;color:#0b74ff;margin-bottom:4px}.doc-metrics{display:flex;gap:6px;flex-wrap:wrap;margin-top:9px}.doc-metric{display:inline-flex;align-items:center;gap:6px;background:#fff;border:1px solid #dbe6f2;border-radius:999px;padding:5px 8px}.doc-metric span{font-size:7px;font-weight:900;text-transform:uppercase;letter-spacing:.04em;color:#64748b}.doc-metric b{font-size:12px;color:#102a4f}.heading .btn{padding:8px 10px;font-size:10px}.cards{display:none!important}.panel{border-radius:13px;padding:12px;margin-bottom:10px;box-shadow:0 5px 18px rgba(15,42,76,.04)}.panel h2{font-size:15px;color:#102a4f}.contracts-panel{padding:0;overflow:hidden}.contracts-head,.directory-head{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:10px 12px;border-bottom:1px solid #edf2f7}.contracts-head h2,.directory-head h2{margin:0;font-size:14px}.contracts-head p,.directory-head p{margin:3px 0 0;font-size:9px;color:#718096}.count-pill{display:inline-flex;align-items:center;padding:5px 8px;border-radius:999px;background:#edf5ff;color:#145fb7;font-size:9px;font-weight:900}.contracts-panel .table-wrap{padding:0}.upload-panel{padding:0;overflow:hidden}.upload-panel>summary{list-style:none;cursor:pointer;padding:10px 12px;display:flex;align-items:center;gap:9px;font-weight:900;color:#153f67}.upload-panel>summary::-webkit-details-marker{display:none}.upload-panel>summary:after{content:"+";margin-left:auto;color:#0b74ff;font-size:16px}.upload-panel[open]>summary:after{content:"−"}.upload-panel[open]>summary{background:#f8fbff;border-bottom:1px solid #edf2f7}.upload-summary-icon{width:28px;height:28px;border-radius:8px;display:grid;place-items:center;background:#eaf3ff;color:#0b74ff}.upload-summary-text small{display:block;color:#718096;font-size:9px;font-weight:500;margin-top:2px}.upload-body{padding:12px}.upload-body .upload-help{font-size:10px;margin-top:0}.grid{gap:8px}.label{font-size:9px;margin-bottom:4px}.input,select,textarea{padding:8px 9px;font-size:11px}.filters{grid-template-columns:minmax(250px,1.7fr) repeat(3,minmax(150px,.7fr)) auto;gap:7px;padding:10px 12px;border-bottom:1px solid #edf2f7}.filters .input,.filters select{height:35px}.directory-panel{padding:0;overflow:hidden}.directory-panel .table-wrap{max-height:58vh;overflow:auto}.directory-panel thead th{position:sticky;top:0;background:#edf5ff;z-index:1}.table-wrap table{min-width:1050px}.table-wrap th{font-size:9px;padding:9px 8px}.table-wrap td{font-size:10px;padding:9px 8px}.table-wrap tbody tr:nth-child(even){background:#fbfdff}.table-wrap tbody tr:hover{background:#f3f8ff}.btn{padding:8px 10px;font-size:10px}.badge{padding:4px 7px;font-size:8px}.upload-help{font-size:10px}.alert{padding:9px 11px;font-size:10px;margin-bottom:10px}@media(max-width:900px){.page{padding:12px}.heading{display:block}.heading>div:last-child{margin-top:10px}.doc-metrics{display:grid;grid-template-columns:1fr 1fr}.doc-metric{justify-content:space-between}.filters{grid-template-columns:1fr}.contracts-head,.directory-head{align-items:flex-start;flex-direction:column}}

</style>
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v6">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>
<body>
<aside class="sidebar">
<a class="brand" href="admin-dashboard.php"><i class="fa-solid fa-plane-departure"></i><span><strong>TRAVSCOPE</strong><small>Travel Business System</small></span></a>
<div class="menu-title">OVERVIEW</div><a class="menu-link" href="admin-dashboard.php"><i class="fa-solid fa-chart-pie"></i>Dashboard</a>
<div class="menu-title">SALES & CRM</div><a class="menu-link" href="admin-enquiries.php"><i class="fa-regular fa-message"></i>Enquiries</a><a class="menu-link" href="admin-customers.php"><i class="fa-solid fa-users"></i>Customers</a>
<div class="menu-title">TRAVEL PRODUCTS</div><a class="menu-link" href="admin-destinations.php"><i class="fa-solid fa-earth-americas"></i>Destinations</a><a class="menu-link" href="admin-packages.php"><i class="fa-solid fa-suitcase-rolling"></i>Packages</a>
<div class="menu-title">SUPPLIERS</div><a class="menu-link" href="admin-suppliers.php"><i class="fa-solid fa-handshake"></i>Suppliers</a><a class="menu-link active" href="admin-supplier-documents.php"><i class="fa-solid fa-file-contract"></i>Supplier Documents</a><a class="menu-link" href="admin-supplier-rate-books.php"><i class="fa-solid fa-book-open"></i>Rate Books</a><a class="menu-link" href="admin-supplier-requests.php"><i class="fa-solid fa-paper-plane"></i>Supplier Requests</a>
<div class="menu-title">OPERATIONS</div><a class="menu-link" href="admin-bookings.php"><i class="fa-solid fa-calendar-check"></i>Bookings</a>
<div class="menu-title">ADMINISTRATION</div><a class="menu-link" href="admin-settings.php"><i class="fa-solid fa-gear"></i>Settings</a><a class="menu-link" href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i>Logout</a>
</aside>
<main class="main">
<header class="topbar"><strong>TRAVSCOPE Administration</strong><span><?=sdocE((string)$admin['name'])?></span></header>
<div class="page">
<?php if($success):?><div class="alert ok"><?=sdocE($success)?></div><?php endif;?>
<?php if($error):?><div class="alert err"><?=sdocE($error)?></div><?php endif;?>
<?php if($schemaNotice):?><div class="alert <?= $ready?'ok':'err' ?>"><strong><?=sdocE($schemaNotice)?></strong><?php if(!$ready):?><br>Fallback: import <code>travscope-core-schema-auto-repair.sql</code> once, then reload.<?php endif;?></div><?php endif;?>

<div class="heading"><div><div class="doc-eyebrow">SUPPLIER CONTROL / CONTRACT INTELLIGENCE</div><h1>Supplier Document Center</h1><p>Save supplier tariffs/contracts first. TRAVSCOPE analyzes source validity, itinerary groups, hotel categories, PAX rates, meal plan, transport and cancellation rules without creating website packages.</p><div class="doc-metrics"><span class="doc-metric"><span>Documents</span><b><?=number_format((int)($stats['total']??0))?></b></span><span class="doc-metric"><span>Needs Review</span><b><?=number_format((int)($stats['review']??0))?></b></span><span class="doc-metric"><span>Linked</span><b><?=number_format((int)($stats['linked']??0))?></b></span><span class="doc-metric"><span>Failed</span><b><?=number_format((int)($stats['failed']??0))?></b></span><span class="doc-metric"><span>Contracts</span><b><?=number_format(count($contracts))?></b></span></div></div><div style="display:flex;gap:7px;flex-wrap:wrap"><a class="btn primary" href="admin-supplier-rate-books.php"><i class="fa-solid fa-book-open"></i> Rate Books</a><a class="btn soft" href="admin-suppliers.php"><i class="fa-solid fa-handshake"></i> Suppliers</a><a class="btn soft" href="admin-supplier-requests.php"><i class="fa-solid fa-paper-plane"></i> RFQs</a></div></div>
<div class="card"><small>Needs Review</small><strong><?=number_format((int)($stats['review']??0))?></strong></div>
<div class="card"><small>Linked to Contract</small><strong><?=number_format((int)($stats['linked']??0))?></strong></div>
<div class="card"><small>Extraction Failed</small><strong><?=number_format((int)($stats['failed']??0))?></strong></div>
</div>

<div class="panel contracts-panel"><div class="contracts-head"><div><h2><i class="fa-solid fa-file-signature"></i> Existing Supplier Contracts</h2><p>Contracts remain valid before a source document is uploaded. Add source files only when you need history, extraction or tariff intelligence.</p></div><span class="count-pill"><i class="fa-solid fa-layer-group"></i>&nbsp; <?=number_format(count($contracts))?> contracts</span></div>
<div class="table-wrap"><table><thead><tr><th>Supplier</th><th>Contract</th><th>Validity</th><th>Predefined Rates</th><th>Document Versions</th><th>Status</th><th>Actions</th></tr></thead><tbody>
<?php if(!$contracts):?><tr><td colspan="7" class="empty">No supplier contracts found for this filter.</td></tr><?php endif;?>
<?php foreach($contracts as $c):?><tr>
<td><strong><?=sdocE((string)$c['company_name'])?></strong><br><span class="muted"><?=sdocE((string)$c['supplier_code'])?></span></td>
<td><strong><?=sdocE((string)$c['contract_code'])?></strong><br><span class="muted"><?=sdocE((string)$c['contract_name'])?></span></td>
<td><?=sdocE((string)($c['valid_from']??'—'))?> → <?=sdocE((string)($c['valid_to']??'—'))?></td>
<td><strong><?=number_format((int)$c['predefined_rate_count'])?></strong></td>
<td><strong><?=number_format((int)$c['document_version_count'])?></strong></td>
<td><span class="badge <?=sdocE((string)$c['status'])?>"><?=sdocE(ucfirst((string)$c['status']))?></span></td>
<td><a class="btn soft" href="admin-supplier-details.php?id=<?=(int)$c['supplier_id']?>#contracts-rates"><i class="fa-solid fa-building"></i> Supplier 360</a></td>
</tr><?php endforeach;?></tbody></table></div>
</div>

<details class="panel upload-panel"><summary><span class="upload-summary-icon"><i class="fa-solid fa-cloud-arrow-up"></i></span><span class="upload-summary-text">Upload & Analyze Supplier Document<small>PDF/DOCX tariff, rate sheet, quotation or contract source</small></span></summary><div class="upload-body"><p class="upload-help">Select the supplier yourself for the first version. This prevents a supplier letterhead/OCR mistake from attaching rates to the wrong vendor. TRAVSCOPE then analyzes the PDF/DOCX and stores it in private storage outside <code>public_html</code>. Nothing is activated automatically.</p><form method="post" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="<?=sdocE($csrf)?>"><input type="hidden" name="action" value="upload_document">
<div class="grid">
<div><label class="label">Supplier *</label><select name="supplier_id" required><option value="">Select Supplier</option><?php foreach($suppliers as $s):?><option value="<?=(int)$s['id']?>"><?=sdocE((string)$s['company_name'])?> · <?=sdocE((string)$s['supplier_code'])?></option><?php endforeach;?></select></div>
<div><label class="label">Destination (optional)</label><select name="destination_id"><option value="">Auto / Not assigned</option><?php foreach($destinations as $d):?><option value="<?=(int)$d['id']?>"><?=sdocE((string)$d['name'])?><?=!empty($d['country'])?' · '.sdocE((string)$d['country']):''?></option><?php endforeach;?></select></div>
<div><label class="label">Document Type</label><select name="document_type"><option value="auto">Auto Detect</option><option value="package_tariff">Package Tariff</option><option value="rate_sheet">Rate Sheet</option><option value="hotel_rate_sheet">Hotel Rate Sheet</option><option value="transport_tariff">Transport Tariff</option><option value="quotation">Quotation</option><option value="booking_confirmation">Booking Confirmation</option><option value="invoice">Invoice</option><option value="other">Other</option></select></div>
<div><label class="label">Source Channel</label><select name="source_channel"><option value="manual_upload">Manual Upload</option><option value="email">Email</option><option value="whatsapp">WhatsApp</option><option value="api">API</option><option value="other">Other</option></select></div>
<div><label class="label">Supplier Sender Email</label><input class="input" type="email" name="source_email" placeholder="supplier@example.com"></div>
<div><label class="label">Received At</label><input class="input" type="datetime-local" name="received_at" value="<?=date('Y-m-d\TH:i')?>"></div>
<div><label class="label">Validity From (optional override)</label><input class="input" type="date" name="valid_from"></div>
<div><label class="label">Validity To (optional override)</label><input class="input" type="date" name="valid_to"></div>
<div><label class="label">Currency</label><input class="input" name="currency" value="INR" maxlength="10"></div>
<div class="full"><label class="label">Document Title (optional)</label><input class="input" name="title" placeholder="Leave blank to generate from supplier + detected document type + validity"></div>
<div class="full"><label class="label">Supplier PDF / DOCX *</label><input class="input" type="file" name="supplier_pdf" accept="application/pdf,.pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,.docx" required><div class="upload-help">Use the supplier's original rate sheet. DOCX tables such as Package Code × PAX × Deluxe/Super Deluxe/Superior/Premium are supported.</div></div>
<div class="full"><label class="label">Internal Notes</label><textarea name="notes" placeholder="Where this tariff came from, negotiation notes, etc."></textarea></div>
<div class="full"><button class="btn primary" <?=$ready?'':'disabled'?>> <i class="fa-solid fa-wand-magic-sparkles"></i> Save & Analyze Supplier Document</button></div>
</div></form></div></details>
<div class="panel directory-panel"><div class="directory-head"><div><h2><i class="fa-solid fa-folder-open"></i> Supplier Document Directory</h2><p>Search, review extraction quality and open the linked contract/document record.</p></div><span class="count-pill"><?=number_format(count($documents))?> loaded</span></div><form class="filters" method="get">
<input class="input" name="q" value="<?=sdocE($q)?>" placeholder="Search document, filename, supplier...">
<select name="supplier_id"><option value="">All Suppliers</option><?php foreach($suppliers as $s):?><option value="<?=(int)$s['id']?>" <?=$supplierFilter===(int)$s['id']?'selected':''?>><?=sdocE((string)$s['company_name'])?></option><?php endforeach;?></select>
<select name="document_type"><option value="">All Types</option><?php foreach(['package_tariff','rate_sheet','hotel_rate_sheet','transport_tariff','quotation','booking_confirmation','invoice','other'] as $v):?><option value="<?=$v?>" <?=$typeFilter===$v?'selected':''?>><?=sdocE(sdocTypeLabel($v))?></option><?php endforeach;?></select>
<select name="status"><option value="">All Status</option><?php foreach(['review','linked','archived','failed'] as $v):?><option value="<?=$v?>" <?=$statusFilter===$v?'selected':''?>><?=sdocE(ucfirst($v))?></option><?php endforeach;?></select>
<button class="btn dark"><i class="fa-solid fa-filter"></i> Filter</button>
</form><div class="table-wrap"><table><thead><tr><th>Document</th><th>Supplier</th><th>Type</th><th>Validity</th><th>Analysis</th><th>Source Coverage</th><th>Contract</th><th>Status</th><th></th></tr></thead><tbody>
<?php if(!$documents):?><tr><td colspan="9" class="empty">No supplier documents found.</td></tr><?php endif;?>
<?php foreach($documents as $doc):?>
<tr>
<td><strong><?=sdocE((string)$doc['title'])?></strong><br><span class="muted"><?=sdocE((string)$doc['document_code'])?> · <?=sdocE((string)$doc['original_filename'])?></span><br><span class="muted"><?=sdocE(date('d M Y H:i',strtotime((string)$doc['received_at'])))?></span></td>
<td><strong><?=sdocE((string)$doc['company_name'])?></strong><br><span class="muted"><?=sdocE((string)$doc['supplier_code'])?></span></td>
<td><?=sdocE(sdocTypeLabel((string)$doc['document_type']))?></td>
<td><?=!empty($doc['valid_from'])?sdocE((string)$doc['valid_from']).' → '.sdocE((string)$doc['valid_to']):'<span class="muted">Review needed</span>'?></td>
<td><?=number_format((int)$doc['detected_itinerary_count'])?> itinerary<br><?=number_format((int)$doc['detected_hotel_category_count'])?> categories<br><?=number_format((int)$doc['detected_rate_group_count'])?> rate groups</td>
<td><span class="score"><?=number_format((float)$doc['source_coverage'],0)?>%</span><br><span class="muted"><?=sdocE((string)$doc['extraction_method'])?></span></td>
<td><?=!empty($doc['contract_code'])?'<strong>'.sdocE((string)$doc['contract_code']).'</strong><br><span class="muted">'.(int)$doc['version_count'].' version link(s)</span>':'<span class="muted">Not linked</span>'?></td>
<td><span class="badge <?=sdocE((string)$doc['status'])?>"><?=sdocE(ucfirst((string)$doc['status']))?></span></td>
<td><a class="btn soft" href="admin-supplier-document.php?id=<?=(int)$doc['id']?>"><i class="fa-solid fa-eye"></i> Review</a></td>
</tr>
<?php endforeach;?>
</tbody></table></div>
</div>
</div></main>
<script src="assets/travscope-pro-admin.js?v=20260916-v6" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
