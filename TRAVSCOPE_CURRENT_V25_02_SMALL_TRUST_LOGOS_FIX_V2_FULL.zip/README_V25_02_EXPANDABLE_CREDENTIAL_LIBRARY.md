# TRAVSCOPE V25.02 — Expandable Credential & Association Logo Library

Development base: V25.01. Database schema is unchanged. **No SQL required.**

## Features
- Admin → General Settings → Quotation Trust & Credentials: existing four slots remain; click **Add Another Logo** to reveal additional credential cards up to **30 total**.
- Every logo has its own organisation label, PNG/JPG browser upload (max 3 MB), optional existing safe image path / HTTPS URL, explicit publication approval, preview, and Clear button.
- New cards are hidden and disabled until added; existing configured additional cards appear when returning to the settings screen.
- The library uses the existing `settings` table with numbered keys; no migration is needed and existing four records are retained without changing their values.
- Only entries with **Display – Authorised to use**, a valid label and safe logo path are displayed. Hidden/blank credentials never appear in shared website footer, quotation, invoice, HTML receipt, vouchers or other customer documents.
- Shared credential loader now reads numbered entries up to 30 and retrieves settings with a single query when supported.
- Quotation print/PDF marks wrap rather than forcing all logos onto one row.
- Verified money receipt PDF shows up to six marks on page 1; further **locally stored** approved logos continue on additional A4 credential pages (up to 20 per extra page). Remote URLs are not downloaded into this PDF.

## Deployment
1. Back up the current V25.01 website and settings table before updating the development installation.
2. Upload **V25.02 PATCH ZIP** to your MilesWeb website root, preserving folder paths; don't delete `uploads/settings/branding`.
3. Hard-refresh the browser (Ctrl+Shift+R).
4. Visit `admin-settings.php#settings-quotation_credentials` and click **Add Another Logo**, fill label, browse PNG/JPG, select publication approval only when authorised, and **Save Settings**.
5. Refresh settings to confirm data persists; check public footer, quotation PDF, invoice, money receipt (including emailed PDF), and vouchers.
6. Test with a few sample logos before adding larger collections. PHP hosting upload limits may require uploading large batches separately.

## Notes
- **30 slots is the current UI limit**, selected to keep the settings page and printed documents manageable; the user may ask to raise it later.
- Clearing a logo and clicking Save removes its settings; it does not automatically delete the old image file from server storage.
- Do not display official tourism, government, association or accreditation marks unless the operator has actual permission to use them. A logo by itself is not evidence of endorsement.
- Logos used on previously generated document snapshots are not frozen; currently approved branding appears when the document is rendered anew.
- Core CRM, bookings, payment calculations and tax logic are unchanged.
- Live MilesWeb database/write/permission checks are not executable in this isolated QA environment.

## Files changed
`admin-settings.php`, `credential-display.php`, `admin-crm.php`, `receipt-pdf-functions.php`, `assets/credentials-v2501.css`, and new `assets/credentials-manager-v2502.js`.
