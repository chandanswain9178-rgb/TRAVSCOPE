<?php
declare(strict_types=1);
if (is_file(__DIR__.'/location-master-functions.php')) require_once __DIR__.'/location-master-functions.php';

/*
|--------------------------------------------------------------------------
| TRAVSCOPE V21 - Supplier Hotel Options (NO HOTEL PRICE)
|--------------------------------------------------------------------------
| A supplier hotel option only says which hotel/property may be used for a
| supplier's package category in a city. Supplier money remains in the
| seasonal package rate matrix (supplier_contract_rate_groups + pax rates).
*/

function tsSHOTable(PDO $pdo,string $table):bool{
    if(!preg_match('/^[A-Za-z0-9_]+$/',$table)) return false;
    try{$pdo->query("SELECT 1 FROM `{$table}` LIMIT 0");return true;}catch(Throwable $e){}
    try{$q=$pdo->quote($table);$s=$pdo->query('SHOW TABLES LIKE '.$q);return $s?(bool)$s->fetchColumn():false;}catch(Throwable $e){}
    return false;
}
function tsSHOColumn(PDO $pdo,string $table,string $column):bool{
    if(!preg_match('/^[A-Za-z0-9_]+$/',$table)||!preg_match('/^[A-Za-z0-9_]+$/',$column))return false;
    try{$pdo->query("SELECT `{$column}` FROM `{$table}` LIMIT 0");return true;}catch(Throwable $e){}
    return false;
}
function tsSHONormalize(string $value):string{
    $value=trim($value);
    if($value==='')return '';
    if(function_exists('iconv')){$v=@iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$value);if($v!==false)$value=$v;}
    $value=strtolower($value);
    $value=preg_replace('/\b(?:hotel|resort)\b/',' ',$value)??$value;
    $value=preg_replace('/[^a-z0-9]+/',' ',$value)??$value;
    return trim(preg_replace('/\s+/',' ',$value)??$value);
}
function tsSHOCategoryStar(string $value):int{
    $v=strtolower(trim($value));
    if(preg_match('/(?:^|\D)5\s*(?:star|★|\*)?/u',$v))return 5;
    if(preg_match('/(?:^|\D)4\s*(?:star|★|\*)?/u',$v))return 4;
    if(preg_match('/(?:^|\D)3\s*(?:star|★|\*)?/u',$v))return 3;
    return 0;
}
function tsSHOCategoryLabel(string $value,int $star=0):string{
    $value=trim($value);
    if($value!=='')return $value;
    return $star>0?$star.' Star':'Unmapped';
}
function tsSHOReady(PDO $pdo):bool{return tsSHOTable($pdo,'supplier_hotel_options');}
function tsSHOSupplier(PDO $pdo,int $supplierId):?array{
    if($supplierId<=0||!tsSHOTable($pdo,'suppliers'))return null;
    $s=$pdo->prepare("SELECT * FROM suppliers WHERE id=? LIMIT 1");$s->execute([$supplierId]);return $s->fetch(PDO::FETCH_ASSOC)?:null;
}
function tsSHOSuppliers(PDO $pdo):array{
    if(!tsSHOTable($pdo,'suppliers'))return [];
    try{
        $cols=['id','supplier_code','company_name'];
        foreach(['supplier_type','priority','status'] as $c)if(tsSHOColumn($pdo,'suppliers',$c))$cols[]=$c;
        $sql='SELECT '.implode(',', $cols).' FROM suppliers';
        if(tsSHOColumn($pdo,'suppliers','status'))$sql.=" WHERE status='active'";
        $sql.=tsSHOColumn($pdo,'suppliers','priority')?" ORDER BY CASE priority WHEN 'preferred' THEN 1 WHEN 'regular' THEN 2 ELSE 3 END,company_name":" ORDER BY company_name";
        return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $e){return [];}
}
function tsSHODestinations(PDO $pdo):array{
    if(!tsSHOTable($pdo,'destinations'))return [];
    try{
        $hasStatus=tsSHOColumn($pdo,'destinations','status');
        $hasCountry=tsSHOColumn($pdo,'destinations','country');
        $sql='SELECT id,name,'.($hasCountry?'country':"'' country").($hasStatus?',status':"") .' FROM destinations'.($hasStatus?" WHERE status='active'":'').' ORDER BY '.($hasCountry?'country,':'').'name';
        return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $e){return [];}
}
function tsSHOLocations(PDO $pdo):array{
    if(function_exists('tsLocationEnsureSchema')){try{tsLocationEnsureSchema($pdo);}catch(Throwable $ignored){}}
    if(!tsSHOTable($pdo,'destination_locations'))return [];
    try{
        $order=tsSHOColumn($pdo,'destination_locations','sort_order')?'destination_id,sort_order,location_name':'destination_id,location_name';
        $status=tsSHOColumn($pdo,'destination_locations','status')?" WHERE status='active'":'';
        return $pdo->query("SELECT id,destination_id,location_name FROM destination_locations{$status} ORDER BY {$order}")->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $e){return [];}
}
function tsSHOHotels(PDO $pdo):array{
    if(!tsSHOTable($pdo,'hotels')||!tsSHOTable($pdo,'destinations'))return [];
    try{
        $hasLocation=tsSHOColumn($pdo,'hotels','location_id')&&tsSHOTable($pdo,'destination_locations');
        $hasCity=tsSHOColumn($pdo,'hotels','city');
        $hasStatus=tsSHOColumn($pdo,'hotels','status');
        $hasStar=tsSHOColumn($pdo,'hotels','star_category');
        $select=["h.id","h.destination_id",$hasLocation?'h.location_id':'NULL location_id',"h.hotel_name",$hasStar?'h.star_category':'0 star_category',$hasCity?'h.city':"'' city",$hasStatus?'h.status':"'active' status","d.name destination_name"];
        if($hasLocation)$select[]="dl.location_name";
        $sql="SELECT ".implode(',', $select)." FROM hotels h JOIN destinations d ON d.id=h.destination_id ".($hasLocation?"LEFT JOIN destination_locations dl ON dl.id=h.location_id ":"");
        if($hasStatus)$sql.="WHERE h.status='active' ";
        $sql.="ORDER BY d.name,".($hasLocation?'dl.location_name,':'').($hasStar?'h.star_category,':'')."h.hotel_name";
        return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $e){return [];}
}
function tsSHOAutoMatchHotel(PDO $pdo,int $destinationId,int $locationId,string $city,string $hotelName,int $star):int{
    if(!tsSHOTable($pdo,'hotels')||$hotelName==='')return 0;
    $hasLocation=tsSHOColumn($pdo,'hotels','location_id');
    $where=["h.status='active'"];$params=[];
    if($destinationId>0){$where[]='h.destination_id=?';$params[]=$destinationId;}
    if($hasLocation&&$locationId>0){$where[]='h.location_id=?';$params[]=$locationId;}
    elseif($city!==''){$where[]='LOWER(TRIM(COALESCE(h.city,\'\')))=LOWER(TRIM(?))';$params[]=$city;}
    if($star>0){$where[]='h.star_category=?';$params[]=$star;}
    $s=$pdo->prepare('SELECT h.id,h.hotel_name FROM hotels h WHERE '.implode(' AND ',$where).' ORDER BY h.is_preferred DESC,h.priority_order,h.id LIMIT 200');$s->execute($params);
    $target=tsSHONormalize($hotelName);
    foreach($s->fetchAll(PDO::FETCH_ASSOC)?:[] as $r){if(tsSHONormalize((string)$r['hotel_name'])===$target)return (int)$r['id'];}
    return 0;
}
function tsSHOSave(PDO $pdo,array $in,int $adminId):int{
    if(!tsSHOReady($pdo))throw new RuntimeException('Import the V21 Supplier Hotel Options SQL first.');
    $supplierId=max(0,(int)($in['supplier_id']??0));if(!tsSHOSupplier($pdo,$supplierId))throw new RuntimeException('Choose a valid supplier.');
    $destinationId=max(0,(int)($in['destination_id']??0));
    $locationId=max(0,(int)($in['location_id']??0));
    $city=trim((string)($in['city']??''));
    if($destinationId<=0)throw new RuntimeException('Choose a destination/state.');
    if($locationId<=0&&$city!==''&&function_exists('tsLocationUpsert')){$locationId=tsLocationUpsert($pdo,$destinationId,$city,'supplier_hotel_option',$adminId?:null);}
    if($locationId>0&&tsSHOTable($pdo,'destination_locations')){$q=$pdo->prepare('SELECT location_name FROM destination_locations WHERE id=? AND destination_id=? LIMIT 1');$q->execute([$locationId,$destinationId]);$ln=trim((string)($q->fetchColumn()?:''));if($ln!=='')$city=$ln;}
    if($city==='')throw new RuntimeException('Choose or enter the hotel city/location.');
    $supplierCategory=trim((string)($in['supplier_category']??''));if($supplierCategory==='')throw new RuntimeException('Enter the supplier package category (example: Deluxe / Super Deluxe / Premium).');
    $travCategory=trim((string)($in['travscope_category']??''));$star=max(0,min(5,(int)($in['mapped_star_category']??0)));if($star<=0)$star=tsSHOCategoryStar($travCategory);
    $hotelId=max(0,(int)($in['hotel_id']??0));$hotelName=trim((string)($in['hotel_name']??''));
    if($hotelId>0&&tsSHOTable($pdo,'hotels')){$q=$pdo->prepare("SELECT hotel_name,star_category FROM hotels WHERE id=? AND status='active' LIMIT 1");$q->execute([$hotelId]);$h=$q->fetch(PDO::FETCH_ASSOC);if(!$h)throw new RuntimeException('Selected Hotel Master property is not active.');$hotelName=(string)$h['hotel_name'];if($star<=0)$star=(int)$h['star_category'];}
    if($hotelName==='')throw new RuntimeException('Choose a Hotel Master property or enter the supplier hotel name.');
    if($hotelId<=0)$hotelId=tsSHOAutoMatchHotel($pdo,$destinationId,$locationId,$city,$hotelName,$star);
    if($travCategory==='')$travCategory=$star>0?$star.' Star':'Unmapped';
    $norm=tsSHONormalize($hotelName);$room=trim((string)($in['room_type']??''));$meal=trim((string)($in['meal_plan']??''));$notes=trim((string)($in['notes']??''));$status=(string)($in['status']??'active');if(!in_array($status,['active','inactive'],true))$status='active';
    $id=max(0,(int)($in['option_id']??0));
    if($id>0){
        $s=$pdo->prepare("UPDATE supplier_hotel_options SET supplier_id=?,destination_id=?,location_id=?,city=?,supplier_category=?,travscope_category=?,mapped_star_category=?,hotel_id=?,hotel_name=?,hotel_name_normalized=?,room_type=?,meal_plan=?,notes=?,status=?,updated_by_admin_id=?,updated_at=NOW() WHERE id=?");
        $s->execute([$supplierId,$destinationId,$locationId?:null,$city,$supplierCategory,$travCategory,$star?:null,$hotelId?:null,$hotelName,$norm,$room?:null,$meal?:null,$notes?:null,$status,$adminId?:null,$id]);
    }else{
        $s=$pdo->prepare("INSERT INTO supplier_hotel_options(supplier_id,destination_id,location_id,city,supplier_category,travscope_category,mapped_star_category,hotel_id,hotel_name,hotel_name_normalized,room_type,meal_plan,notes,status,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'active',?,?) ON DUPLICATE KEY UPDATE destination_id=VALUES(destination_id),location_id=VALUES(location_id),travscope_category=VALUES(travscope_category),mapped_star_category=VALUES(mapped_star_category),hotel_id=COALESCE(VALUES(hotel_id),hotel_id),room_type=VALUES(room_type),meal_plan=VALUES(meal_plan),notes=VALUES(notes),status='active',updated_by_admin_id=VALUES(updated_by_admin_id),updated_at=NOW()");
        $s->execute([$supplierId,$destinationId,$locationId?:null,$city,$supplierCategory,$travCategory,$star?:null,$hotelId?:null,$hotelName,$norm,$room?:null,$meal?:null,$notes?:null,$adminId?:null,$adminId?:null]);$id=(int)$pdo->lastInsertId();
        if($id<=0){$q=$pdo->prepare("SELECT id FROM supplier_hotel_options WHERE supplier_id=? AND LOWER(TRIM(city))=LOWER(TRIM(?)) AND LOWER(TRIM(supplier_category))=LOWER(TRIM(?)) AND hotel_name_normalized=? LIMIT 1");$q->execute([$supplierId,$city,$supplierCategory,$norm]);$id=(int)($q->fetchColumn()?:0);}
    }
    if(tsSHOTable($pdo,'supplier_destinations')){try{$pdo->prepare('INSERT IGNORE INTO supplier_destinations(supplier_id,destination_id) VALUES(?,?)')->execute([$supplierId,$destinationId]);}catch(Throwable $ignored){}}
    return $id;
}
function tsSHODelete(PDO $pdo,int $id,int $supplierId=0):void{
    if(!tsSHOReady($pdo)||$id<=0)return;
    $sql='DELETE FROM supplier_hotel_options WHERE id=?';$p=[$id];if($supplierId>0){$sql.=' AND supplier_id=?';$p[]=$supplierId;}$pdo->prepare($sql)->execute($p);
}
function tsSHOList(PDO $pdo,int $supplierId=0):array{
    if(!tsSHOReady($pdo))return [];
    $sql="SELECT o.*,s.company_name,s.supplier_code,d.name destination_name,d.country destination_country,dl.location_name,h.hotel_name master_hotel_name,h.star_category master_star_category FROM supplier_hotel_options o JOIN suppliers s ON s.id=o.supplier_id LEFT JOIN destinations d ON d.id=o.destination_id LEFT JOIN destination_locations dl ON dl.id=o.location_id LEFT JOIN hotels h ON h.id=o.hotel_id WHERE 1=1";$p=[];
    if($supplierId>0){$sql.=' AND o.supplier_id=?';$p[]=$supplierId;}
    $sql.=" ORDER BY s.company_name,d.name,COALESCE(dl.location_name,o.city),o.mapped_star_category,o.supplier_category,o.hotel_name";
    $st=$pdo->prepare($sql);$st->execute($p);return $st->fetchAll(PDO::FETCH_ASSOC)?:[];
}
function tsSHOCount(PDO $pdo,int $supplierId):int{
    if(!tsSHOReady($pdo)||$supplierId<=0)return 0;$s=$pdo->prepare("SELECT COUNT(*) FROM supplier_hotel_options WHERE supplier_id=? AND status='active'");$s->execute([$supplierId]);return (int)$s->fetchColumn();
}
