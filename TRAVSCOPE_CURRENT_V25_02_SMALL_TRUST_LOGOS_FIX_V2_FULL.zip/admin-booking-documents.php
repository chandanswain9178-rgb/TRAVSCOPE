<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/document-functions.php';

$accessControlFunctionsFile = __DIR__ . '/access-control-functions.php';
if (is_file($accessControlFunctionsFile)) {
    require_once $accessControlFunctionsFile;
}

if (empty($_SESSION['admin_id'])) {
    redirect(BASE_URL . 'admin-login.php');
}

$adminId =
    (int)$_SESSION['admin_id'];

$stmt = $pdo->prepare("
    SELECT id, name, email, role, status
    FROM admins
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$adminId]);

$admin =
    $stmt->fetch(PDO::FETCH_ASSOC)
    ?: null;

if (
    !$admin
    || (string)$admin['status'] !== 'active'
) {
    unset($_SESSION['admin_id']);
    redirect(BASE_URL . 'admin-login.php');
}

$bookingId =
    max(
        0,
        (int)(
            $_GET['id']
            ?? $_POST['booking_id']
            ?? 0
        )
    );

if ($bookingId <= 0) {
    redirect(
        BASE_URL . 'admin-bookings.php'
    );
}

if (!tsDocReady($pdo)) {
    http_response_code(503);
    exit(
        'Document & Traveller File Center SQL is not installed yet.'
    );
}

$booking =
    tsDocBooking(
        $pdo,
        $bookingId
    );

if (empty($_SESSION['admin_booking_documents_csrf'])) {
    $_SESSION['admin_booking_documents_csrf'] =
        bin2hex(
            random_bytes(32)
        );
}

$csrfToken =
    (string)$_SESSION['admin_booking_documents_csrf'];

$error = '';
$success = '';

if (!empty($_SESSION['admin_booking_documents_success'])) {
    $success =
        (string)$_SESSION['admin_booking_documents_success'];

    unset(
        $_SESSION['admin_booking_documents_success']
    );
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $posted =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    if (
        $posted === ''
        || !hash_equals(
            $csrfToken,
            $posted
        )
    ) {
        $error =
            'Security verification failed. Refresh and try again.';

    } else {
        $action =
            (string)(
                $_POST['action']
                ?? ''
            );

        try {
            if ($action === 'add_traveller') {
                $traveller =
                    tsDocAddTraveller(
                        $pdo,
                        $bookingId,
                        max(
                            0,
                            (int)(
                                $booking['user_id']
                                ?? 0
                            )
                        ),
                        'admin',
                        null,
                        $adminId,
                        $_POST
                    );

                $_SESSION['admin_booking_documents_success'] =
                    (string)$traveller['full_name']
                    . ' added to the Booking traveller roster.';

            } elseif ($action === 'cancel_traveller') {
                tsDocCancelTraveller(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['traveller_id']
                            ?? 0
                        )
                    )
                );

                $_SESSION['admin_booking_documents_success'] =
                    'Traveller removed from the active Booking roster.';

            } elseif ($action === 'add_requirement') {
                tsDocAddRequirement(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['traveller_id']
                            ?? 0
                        )
                    ),
                    (string)(
                        $_POST['document_type']
                        ?? ''
                    ),
                    (string)(
                        $_POST['requirement_note']
                        ?? ''
                    ),
                    $adminId
                );

                $_SESSION['admin_booking_documents_success'] =
                    'Document requirement added.';

            } elseif ($action === 'waive_requirement') {
                tsDocWaiveRequirement(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['requirement_id']
                            ?? 0
                        )
                    ),
                    $adminId,
                    (string)(
                        $_POST['waiver_note']
                        ?? ''
                    )
                );

                $_SESSION['admin_booking_documents_success'] =
                    'Document requirement waived with audit note.';

            } elseif ($action === 'restore_requirement') {
                tsDocRestoreRequirement(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['requirement_id']
                            ?? 0
                        )
                    )
                );

                $_SESSION['admin_booking_documents_success'] =
                    'Document requirement restored.';

            } elseif ($action === 'upload_document') {
                $document =
                    tsDocAddUploadedDocument(
                        $pdo,
                        $bookingId,
                        'admin_upload',
                        null,
                        $adminId,
                        $_POST,
                        $_FILES['document_file']
                        ?? []
                    );

                $_SESSION['admin_booking_documents_success'] =
                    (string)$document['document_type']
                    . ' uploaded and waiting for verification.';

            } elseif ($action === 'import_vault_document') {
                $document =
                    tsDocImportVaultDocument(
                        $pdo,
                        $bookingId,
                        max(
                            0,
                            (int)(
                                $_POST['traveller_id']
                                ?? 0
                            )
                        ),
                        max(
                            0,
                            (int)(
                                $_POST['profile_document_id']
                                ?? 0
                            )
                        ),
                        null,
                        $adminId
                    );

                $_SESSION['admin_booking_documents_success'] =
                    (string)$document['document_type']
                    . ' copied from Customer Profile Vault.';

            } elseif ($action === 'verify_document') {
                tsDocVerifyDocument(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['document_id']
                            ?? 0
                        )
                    ),
                    $adminId,
                    (string)(
                        $_POST['verification_note']
                        ?? ''
                    )
                );

                $_SESSION['admin_booking_documents_success'] =
                    'Traveller document verified.';

            } elseif ($action === 'reject_document') {
                tsDocRejectDocument(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['document_id']
                            ?? 0
                        )
                    ),
                    $adminId,
                    (string)(
                        $_POST['rejection_note']
                        ?? ''
                    )
                );

                $_SESSION['admin_booking_documents_success'] =
                    'Traveller document rejected with customer-visible reason.';

            } elseif ($action === 'archive_document') {
                tsDocArchiveDocument(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['document_id']
                            ?? 0
                        )
                    )
                );

                $_SESSION['admin_booking_documents_success'] =
                    'Document archived from the active Booking file center.';

            } elseif ($action === 'generate_pack') {
                $requestedPackStatus =
                    strtolower(
                        trim(
                            (string)(
                                $_POST['pack_status']
                                ?? 'draft'
                            )
                        )
                    );

                if (
                    $requestedPackStatus === 'final'
                    && function_exists('tsAclRequire')
                ) {
                    tsAclRequire(
                        $pdo,
                        $adminId,
                        'issue_final_document_pack',
                        'issue_final_trip_document_pack',
                        'booking',
                        $bookingId
                    );
                }

                $pack =
                    tsDocCreatePack(
                        $pdo,
                        $bookingId,
                        $adminId,
                        $requestedPackStatus
                    );

                $_SESSION['admin_booking_documents_success'] =
                    (
                        (string)$pack['status']
                        === 'final'
                            ? 'Final Trip Document Pack '
                            : 'Draft Trip Document Pack '
                    )
                    . (string)$pack['pack_code']
                    . ' created.';

                if (!empty($_POST['open_pack'])) {
                    redirect(
                        BASE_URL
                        . 'booking-document-pack.php?pack='
                        . (int)$pack['id']
                    );
                }

            } else {
                throw new RuntimeException(
                    'Invalid Document Center action.'
                );
            }

            redirect(
                BASE_URL
                . 'admin-booking-documents.php?id='
                . $bookingId
            );

        } catch (RuntimeException $e) {
            $error =
                $e->getMessage();

        } catch (Throwable $e) {
            error_log(
                'Admin Booking Document Center: '
                . $e->getMessage()
            );

            $error =
                'Unable to complete Document Center action: '
                . $e->getMessage();
        }
    }
}

tsDocEnsureLeadTraveller(
    $pdo,
    $bookingId
);

tsDocRefreshRequirements(
    $pdo,
    $bookingId
);

$travellers =
    tsDocTravellers(
        $pdo,
        $bookingId
    );

$documents =
    tsDocDocuments(
        $pdo,
        $bookingId
    );

$requirements =
    tsDocRequirements(
        $pdo,
        $bookingId
    );

$readiness =
    tsDocPackReadiness(
        $pdo,
        $bookingId
    );

$packs =
    tsDocPacks(
        $pdo,
        $bookingId
    );

$currentPack =
    tsDocLatestCurrentFinalPack(
        $pdo,
        $bookingId
    );

$ownerUserId =
    max(
        0,
        (int)(
            $booking['user_id']
            ?? 0
        )
    );

$household =
    tsDocHouseholdChoices(
        $pdo,
        $ownerUserId
    );

$vaultByTraveller = [];

foreach ($travellers as $traveller) {
    $sourceUserId =
        max(
            0,
            (int)(
                $traveller['source_user_id']
                ?? 0
            )
        );

    if ($sourceUserId > 0) {
        $vaultByTraveller[
            (int)$traveller['id']
        ] =
            tsDocVaultDocuments(
                $pdo,
                $sourceUserId
            );
    }
}

$currency =
    strtoupper(
        trim(
            (string)(
                $booking['currency']
                ?? 'INR'
            )
        )
    );

function abdDocDate(?string $value): string
{
    if (!$value) {
        return 'Not set';
    }

    $ts = strtotime($value);

    return
        $ts
            ? date('d M Y', $ts)
            : 'Not set';
}

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Traveller Document Center | TRAVSCOPE Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:68px;padding:10px 4%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;border-bottom:1px solid #dfe7f0;position:sticky;top:0;z-index:20}.brand{font-weight:900;color:#0f172a}.brand span{color:#2563eb}.top-actions{display:flex;gap:7px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;gap:6px;border:1px solid #cbd5e1;border-radius:9px;padding:8px 10px;background:#fff;color:#334155;text-decoration:none;font-size:9px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.btn.good{background:#059669;border-color:#059669;color:#fff}.btn.danger{background:#fff1f2;border-color:#fecdd3;color:#be123c}.btn.warn{background:#fff7ed;border-color:#fed7aa;color:#c2410c}.wrap{max-width:1280px;margin:20px auto;padding:0 13px}.hero{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;padding:17px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:20px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px;line-height:1.5}.notice{margin-top:10px;padding:10px 12px;border-radius:10px;font-size:10px}.notice.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#047857}.notice.err{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c}.stats{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;margin-top:12px}.stat{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.stat span{display:block;color:#64748b;font-size:7.5px;font-weight:900;text-transform:uppercase}.stat strong{display:block;margin-top:4px;font-size:13px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:11px;margin-top:11px}.card{background:#fff;border:1px solid #dfe7f0;border-radius:13px;overflow:hidden}.card.full{grid-column:1/-1}.head{padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff;display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.head h2{margin:0;font-size:12px}.head p{margin:4px 0 0;color:#64748b;font-size:8.5px;line-height:1.45}.body{padding:11px}.form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.form-grid .full{grid-column:1/-1}label{display:block;margin-bottom:4px;color:#475569;font-size:8px;font-weight:900}input,select,textarea{width:100%;min-height:34px;padding:7px 8px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;font-size:9px}textarea{min-height:60px}.row{padding:9px;border:1px solid #e2e8f0;border-radius:10px;background:#fff;margin-bottom:7px}.row:last-child{margin-bottom:0}.row-top{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.row strong{font-size:10px}.row small{display:block;margin-top:3px;color:#64748b;font-size:8px;line-height:1.45}.pill{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:7.5px;font-weight:900}.pill.verified,.pill.final{background:#dcfce7;color:#166534}.pill.pending,.pill.uploaded,.pill.required{background:#fff7ed;color:#c2410c}.pill.rejected,.pill.void{background:#fef2f2;color:#b91c1c}.pill.waived,.pill.draft{background:#f1f5f9;color:#64748b}.validity{margin-top:5px;padding:5px 7px;border-radius:7px;background:#f8fafc;color:#64748b;font-size:8px}.validity.bad{background:#fef2f2;color:#b91c1c}.validity.warn{background:#fff7ed;color:#c2410c}.actions{display:flex;gap:5px;flex-wrap:wrap;margin-top:7px}.mini-form{display:flex;gap:5px;align-items:center;flex-wrap:wrap}.mini-form input{width:230px;min-height:30px}.ready{padding:10px;border-radius:10px;background:#ecfdf5;border:1px solid #a7f3d0;color:#047857;font-size:9px;line-height:1.5}.not-ready{padding:10px;border-radius:10px;background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;font-size:9px;line-height:1.5}.vault{margin-top:8px;padding-top:8px;border-top:1px dashed #d8e0ea}.empty{padding:13px;text-align:center;color:#94a3b8;font-size:9px}
@media(max-width:1050px){.stats{grid-template-columns:repeat(3,1fr)}.grid{grid-template-columns:1fr}.card.full{grid-column:auto}}
@media(max-width:650px){.top,.hero{align-items:flex-start;flex-direction:column}.stats{grid-template-columns:1fr 1fr}.form-grid{grid-template-columns:1fr}.form-grid .full{grid-column:auto}.mini-form input{width:100%}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head>
<body>

<header class="top">
    <div class="brand">TRAV<span>SCOPE</span> · DOCUMENT CENTER</div>

    <div class="top-actions">
        <?php if ($ownerUserId > 0): ?>
            <a class="btn" href="<?= e(BASE_URL . 'admin-customers.php?profile_id=' . $ownerUserId . '#identity-documents'); ?>">
                <i class="fa-solid fa-address-card"></i>
                Customer Profile Vault
            </a>
        <?php endif; ?>

        <a class="btn primary" href="<?= e(BASE_URL . 'admin-booking-details.php?id=' . $bookingId . '#traveller-document-center'); ?>">
            <i class="fa-solid fa-arrow-left"></i>
            Back to Booking
        </a>
    </div>
</header>

<main class="wrap">

<section class="hero">
    <div>
        <h1>Traveller Documents & Trip File Center</h1>
        <p>
            Booking <?= e((string)$booking['booking_number']); ?>
            · <?= e((string)($booking['customer_name'] ?: 'Customer')); ?>
            <?php if (!empty($booking['destination_name'])): ?>
                · <?= e((string)$booking['destination_name']); ?>
            <?php endif; ?>
            <?php if (!empty($booking['travel_date'])): ?>
                · Depart <?= e(abdDocDate((string)$booking['travel_date'])); ?>
            <?php endif; ?>
        </p>
    </div>

    <?php if ($currentPack): ?>
        <a class="btn good" target="_blank" href="<?= e(BASE_URL . 'booking-document-pack.php?pack=' . (int)$currentPack['id']); ?>">
            <i class="fa-solid fa-box-archive"></i>
            <?= e((string)$currentPack['pack_code']); ?>
        </a>
    <?php endif; ?>
</section>

<?php if ($success): ?>
    <div class="notice ok"><?= e($success); ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="notice err"><?= e($error); ?></div>
<?php endif; ?>

<?php
$verifiedCount = count(array_filter($documents, static fn($d) => ($d['verification_status'] ?? '') === 'verified'));
$pendingCount = count(array_filter($documents, static fn($d) => ($d['verification_status'] ?? '') === 'pending'));
$missingCount = (int)($readiness['requirements_pending'] ?? 0);
$alertCount = count((array)($readiness['validity_alerts'] ?? []));
?>

<div class="stats">
    <div class="stat"><span>Traveller Roster</span><strong><?= count($travellers); ?> / <?= (int)$readiness['expected_travellers']; ?></strong></div>
    <div class="stat"><span>Verified Docs</span><strong><?= $verifiedCount; ?></strong></div>
    <div class="stat"><span>Pending Review</span><strong><?= $pendingCount; ?></strong></div>
    <div class="stat"><span>Required Missing</span><strong><?= $missingCount; ?></strong></div>
    <div class="stat"><span>Validity Alerts</span><strong><?= $alertCount; ?></strong></div>
    <div class="stat"><span>Final Pack</span><strong><?= $currentPack ? 'READY' : 'NOT READY'; ?></strong></div>
</div>

<div class="grid">

<section class="card">
    <div class="head">
        <div>
            <h2>Traveller Roster</h2>
            <p>Name each traveller. Every active traveller automatically gets a Primary Travel ID requirement.</p>
        </div>
    </div>

    <div class="body">
        <?php foreach ($travellers as $traveller): ?>
            <div class="row">
                <div class="row-top">
                    <div>
                        <strong><?= e((string)$traveller['full_name']); ?></strong>
                        <small>
                            <?= e(ucfirst((string)$traveller['traveller_type'])); ?>
                            <?php if (!empty($traveller['relationship'])): ?> · <?= e((string)$traveller['relationship']); ?><?php endif; ?>
                            <?php if (!empty($traveller['date_of_birth'])): ?> · DOB <?= e(abdDocDate((string)$traveller['date_of_birth'])); ?><?php endif; ?>
                            <?php if (!empty($traveller['nationality'])): ?> · <?= e((string)$traveller['nationality']); ?><?php endif; ?>
                        </small>
                    </div>

                    <?php if ((string)$traveller['traveller_type'] !== 'lead'): ?>
                        <form method="post">
                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                            <input type="hidden" name="action" value="cancel_traveller">
                            <input type="hidden" name="traveller_id" value="<?= (int)$traveller['id']; ?>">
                            <button class="btn danger" type="submit">Remove</button>
                        </form>
                    <?php endif; ?>
                </div>

                <?php if (!empty($vaultByTraveller[(int)$traveller['id']])): ?>
                    <div class="vault">
                        <small><strong>Profile Vault:</strong> copy an existing profile document into this Booking without changing the original.</small>
                        <div class="actions">
                            <?php foreach ($vaultByTraveller[(int)$traveller['id']] as $vaultDoc): ?>
                                <form method="post">
                                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                    <input type="hidden" name="action" value="import_vault_document">
                                    <input type="hidden" name="traveller_id" value="<?= (int)$traveller['id']; ?>">
                                    <input type="hidden" name="profile_document_id" value="<?= (int)$vaultDoc['id']; ?>">
                                    <button class="btn" type="submit">
                                        <i class="fa-solid fa-copy"></i>
                                        <?= e((string)$vaultDoc['document_type']); ?>
                                    </button>
                                </form>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

        <details style="margin-top:8px;">
            <summary class="btn" style="list-style:none;width:max-content;">
                <i class="fa-solid fa-user-plus"></i>
                Add Traveller
            </summary>

            <form method="post" style="margin-top:8px;">
                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                <input type="hidden" name="action" value="add_traveller">

                <div class="form-grid">
                    <?php if ($household): ?>
                        <div class="full">
                            <label>Add from Customer / Family Profile</label>
                            <select name="source_key">
                                <option value="">Manual traveller instead</option>
                                <?php foreach ($household as $choice): ?>
                                    <option value="<?= e((string)$choice['key']); ?>">
                                        <?= e((string)$choice['label']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <div>
                        <label>Manual Full Name</label>
                        <input name="full_name">
                    </div>

                    <div>
                        <label>Traveller Type</label>
                        <select name="traveller_type">
                            <option value="adult">Adult</option>
                            <option value="child">Child</option>
                            <option value="infant">Infant</option>
                        </select>
                    </div>

                    <div>
                        <label>Relationship</label>
                        <input name="relationship" placeholder="Spouse, Child, Friend">
                    </div>

                    <div>
                        <label>Date of Birth</label>
                        <input type="date" name="date_of_birth">
                    </div>

                    <div class="full">
                        <label>Nationality</label>
                        <input name="nationality" placeholder="India">
                    </div>
                </div>

                <button class="btn primary" type="submit" style="margin-top:7px;">
                    Add to Booking Roster
                </button>
            </form>
        </details>
    </div>
</section>


<section class="card">
    <div class="head">
        <div>
            <h2>Required Document Checklist</h2>
            <p>Primary Travel ID is automatic. Add Passport, Visa, Insurance, Ticket or other requirements as needed.</p>
        </div>
    </div>

    <div class="body">
        <?php foreach ($requirements as $requirement): ?>
            <div class="row">
                <div class="row-top">
                    <div>
                        <strong><?= e((string)$requirement['document_type']); ?></strong>
                        <small>
                            <?= (int)$requirement['traveller_id'] > 0
                                ? e((string)($requirement['traveller_name'] ?: 'Traveller'))
                                : 'Booking / Group'; ?>
                            <?php if (!empty($requirement['note'])): ?>
                                · <?= e((string)$requirement['note']); ?>
                            <?php endif; ?>
                        </small>
                    </div>

                    <span class="pill <?= e((string)$requirement['status']); ?>">
                        <?= e(strtoupper((string)$requirement['status'])); ?>
                    </span>
                </div>

                <div class="actions">
                    <?php if ((string)$requirement['status'] !== 'waived'): ?>
                        <form method="post" class="mini-form">
                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                            <input type="hidden" name="action" value="waive_requirement">
                            <input type="hidden" name="requirement_id" value="<?= (int)$requirement['id']; ?>">
                            <input name="waiver_note" placeholder="Waiver reason" required>
                            <button class="btn warn" type="submit">Waive</button>
                        </form>
                    <?php else: ?>
                        <form method="post">
                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                            <input type="hidden" name="action" value="restore_requirement">
                            <input type="hidden" name="requirement_id" value="<?= (int)$requirement['id']; ?>">
                            <button class="btn" type="submit">Restore</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <details style="margin-top:8px;">
            <summary class="btn" style="list-style:none;width:max-content;">
                <i class="fa-solid fa-list-check"></i>
                Add Requirement
            </summary>

            <form method="post" style="margin-top:8px;">
                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                <input type="hidden" name="action" value="add_requirement">

                <div class="form-grid">
                    <div>
                        <label>Traveller / Group</label>
                        <select name="traveller_id">
                            <option value="0">Booking / Group Document</option>
                            <?php foreach ($travellers as $traveller): ?>
                                <option value="<?= (int)$traveller['id']; ?>">
                                    <?= e((string)$traveller['full_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label>Required Document</label>
                        <select name="document_type" required>
                            <?php foreach (tsDocRequirementTypes() as $type): ?>
                                <option value="<?= e($type); ?>"><?= e($type); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="full">
                        <label>Requirement Note</label>
                        <input name="requirement_note" placeholder="e.g. Required for visa filing / airline / destination permit">
                    </div>
                </div>

                <button class="btn primary" type="submit" style="margin-top:7px;">Add Requirement</button>
            </form>
        </details>
    </div>
</section>


<section class="card full">
    <div class="head">
        <div>
            <h2>Booking Document Files</h2>
            <p>Admin/customer uploads are Pending until verified. Expired files cannot be verified. Passport six-month validity is a human VERIFY warning because destination rules vary.</p>
        </div>

        <span class="pill pending"><?= count($documents); ?> FILE<?= count($documents) === 1 ? '' : 'S'; ?></span>
    </div>

    <div class="body">
        <details>
            <summary class="btn primary" style="list-style:none;width:max-content;">
                <i class="fa-solid fa-cloud-arrow-up"></i>
                Upload Booking Document
            </summary>

            <form method="post" enctype="multipart/form-data" style="margin-top:9px;">
                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                <input type="hidden" name="action" value="upload_document">

                <div class="form-grid">
                    <div>
                        <label>Traveller / Group</label>
                        <select name="traveller_id">
                            <option value="0">Booking / Group Document</option>
                            <?php foreach ($travellers as $traveller): ?>
                                <option value="<?= (int)$traveller['id']; ?>">
                                    <?= e((string)$traveller['full_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label>Document Type *</label>
                        <select name="document_type" required>
                            <?php foreach (tsDocTypes() as $category => $types): ?>
                                <optgroup label="<?= e(ucfirst($category)); ?>">
                                    <?php foreach ($types as $type): ?>
                                        <option value="<?= e($type); ?>"><?= e($type); ?></option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label>Document Number / Reference</label>
                        <input name="document_number">
                    </div>

                    <div>
                        <label>Issuing Country</label>
                        <input name="issuing_country">
                    </div>

                    <div>
                        <label>Issue Date</label>
                        <input type="date" name="issue_date">
                    </div>

                    <div>
                        <label>Expiry / Valid Until</label>
                        <input type="date" name="expiry_date">
                    </div>

                    <div class="full">
                        <label>Document File *</label>
                        <input
                            type="file"
                            name="document_file"
                            accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp"
                            required
                        >
                    </div>

                    <div class="full">
                        <label>Notes</label>
                        <textarea name="notes" placeholder="Optional traveller / ticket / visa / policy note"></textarea>
                    </div>

                    <div class="full">
                        <label>
                            <input type="checkbox" name="customer_visible" value="1" checked style="width:auto;min-height:auto;">
                            Customer can see this document
                        </label>
                    </div>
                </div>

                <button class="btn primary" type="submit" style="margin-top:7px;">Upload Document</button>
            </form>
        </details>

        <div style="margin-top:10px;">
            <?php if (!$documents): ?>
                <div class="empty">No Booking documents uploaded yet.</div>
            <?php endif; ?>

            <?php foreach ($documents as $document): ?>
                <?php
                $validity = tsDocValidity($document, $booking);
                ?>
                <div class="row">
                    <div class="row-top">
                        <div>
                            <strong>
                                <?= e((string)$document['document_type']); ?>
                                · <?= (int)$document['traveller_id'] > 0
                                    ? e((string)($document['traveller_name'] ?: 'Traveller'))
                                    : 'Booking / Group'; ?>
                            </strong>

                            <small>
                                Number <?= e(tsDocMaskNumber((string)($document['document_number'] ?? ''))); ?>
                                <?php if (!empty($document['issuing_country'])): ?> · <?= e((string)$document['issuing_country']); ?><?php endif; ?>
                                <?php if (!empty($document['expiry_date'])): ?> · Expiry <?= e(abdDocDate((string)$document['expiry_date'])); ?><?php endif; ?>
                                · <?= e((string)$document['original_name']); ?>
                                · <?= e(ucwords(str_replace('_', ' ', (string)$document['source_type']))); ?>
                            </small>
                        </div>

                        <span class="pill <?= e((string)$document['verification_status']); ?>">
                            <?= e(strtoupper((string)$document['verification_status'])); ?>
                        </span>
                    </div>

                    <?php if (!empty($validity['blocking']) || !empty($validity['warning'])): ?>
                        <div class="validity <?= !empty($validity['blocking']) ? 'bad' : 'warn'; ?>">
                            <?= e((string)$validity['message']); ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($document['verification_note'])): ?>
                        <div class="validity">
                            Verification Note: <?= e((string)$document['verification_note']); ?>
                        </div>
                    <?php endif; ?>

                    <div class="actions">
                        <a class="btn" target="_blank" href="<?= e(BASE_URL . 'booking-document-file.php?document=' . (int)$document['id']); ?>">
                            <i class="fa-regular fa-eye"></i>
                            Open
                        </a>

                        <?php if ((string)$document['verification_status'] !== 'verified'): ?>
                            <form method="post" class="mini-form">
                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                <input type="hidden" name="action" value="verify_document">
                                <input type="hidden" name="document_id" value="<?= (int)$document['id']; ?>">
                                <input name="verification_note" placeholder="<?= !empty($validity['warning']) ? 'Required: validity rule verified' : 'Optional verification note'; ?>">
                                <button class="btn good" type="submit">Verify</button>
                            </form>
                        <?php endif; ?>

                        <?php if ((string)$document['verification_status'] !== 'rejected'): ?>
                            <form method="post" class="mini-form">
                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                <input type="hidden" name="action" value="reject_document">
                                <input type="hidden" name="document_id" value="<?= (int)$document['id']; ?>">
                                <input name="rejection_note" placeholder="Customer-safe rejection reason" required>
                                <button class="btn warn" type="submit">Reject</button>
                            </form>
                        <?php endif; ?>

                        <form method="post" onsubmit="return confirm('Archive this document from the active Booking file center? File history is retained.');">
                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                            <input type="hidden" name="action" value="archive_document">
                            <input type="hidden" name="document_id" value="<?= (int)$document['id']; ?>">
                            <button class="btn danger" type="submit">Archive</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>


<section class="card full">
    <div class="head">
        <div>
            <h2>Final Trip Document Pack</h2>
            <p>Immutable versioned pack of verified customer-visible traveller files plus the latest Final Travel Voucher and current Final Invoice link when available.</p>
        </div>
    </div>

    <div class="body">
        <?php if (!empty($readiness['ready'])): ?>
            <div class="ready">
                <strong>Ready for Final Pack.</strong>
                Traveller roster and required documents are complete, and the Final Travel Voucher is available.
            </div>
        <?php else: ?>
            <div class="not-ready">
                <strong>Not ready for Final Pack.</strong>
                <?php foreach ((array)($readiness['reasons'] ?? []) as $reason): ?>
                    <div>• <?= e((string)$reason); ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($readiness['validity_alerts'])): ?>
            <div class="not-ready" style="margin-top:7px;">
                <strong>Validity Warnings:</strong>
                <?php foreach ((array)$readiness['validity_alerts'] as $alert): ?>
                    <div>
                        • <?= e((string)$alert['document']['document_type']); ?>
                        <?= !empty($alert['document']['traveller_name']) ? ' · ' . e((string)$alert['document']['traveller_name']) : ''; ?>
                        — <?= e((string)$alert['validity']['message']); ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="actions" style="margin-top:9px;">
            <form method="post" target="_blank">
                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                <input type="hidden" name="action" value="generate_pack">
                <input type="hidden" name="pack_status" value="draft">
                <input type="hidden" name="open_pack" value="1">
                <button class="btn" type="submit">
                    Generate Draft Pack
                </button>
            </form>

            <form method="post" target="_blank" onsubmit="return confirm('Issue the FINAL Trip Document Pack? This also marks Traveller Documents Verified in Operations Readiness.');">
                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                <input type="hidden" name="action" value="generate_pack">
                <input type="hidden" name="pack_status" value="final">
                <input type="hidden" name="open_pack" value="1">
                <?php $aclCanIssueFinalPack = !function_exists('tsAclCan') || tsAclCan($pdo, $adminId, 'issue_final_document_pack'); ?>
                <button class="btn good" type="submit" <?= (empty($readiness['ready']) || !$aclCanIssueFinalPack) ? 'disabled style="opacity:.55;cursor:not-allowed;"' : ''; ?> title="<?= $aclCanIssueFinalPack ? 'Generate Final Pack' : 'Permission required: Issue Final Trip Document Pack'; ?>">
                    Generate Final Pack
                </button>
            </form>
        </div>

        <?php if ($packs): ?>
            <div style="margin-top:10px;">
                <?php foreach ($packs as $pack): ?>
                    <?php $isCurrent = tsDocPackIsCurrent($pdo, $pack); ?>
                    <div class="row">
                        <div class="row-top">
                            <div>
                                <strong><?= e((string)$pack['pack_code']); ?></strong>
                                <small>
                                    Version <?= (int)$pack['version_number']; ?>
                                    · <?= e(abdDocDate((string)$pack['created_at'])); ?>
                                    <?php if ((string)$pack['status'] === 'final' && !$isCurrent): ?>
                                        · STALE / superseded by document or voucher change
                                    <?php endif; ?>
                                </small>
                            </div>

                            <span class="pill <?= e((string)$pack['status']); ?>">
                                <?= e(strtoupper((string)$pack['status'])); ?>
                            </span>
                        </div>

                        <div class="actions">
                            <a class="btn" target="_blank" href="<?= e(BASE_URL . 'booking-document-pack.php?pack=' . (int)$pack['id']); ?>">
                                Open Pack
                            </a>

                            <?php if ((string)$pack['status'] === 'final' && $isCurrent): ?>
                                <a class="btn primary" href="<?= e(BASE_URL . 'booking-document-pack-download.php?pack=' . (int)$pack['id']); ?>">
                                    Download Verified Files ZIP
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

</div>
</main>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
