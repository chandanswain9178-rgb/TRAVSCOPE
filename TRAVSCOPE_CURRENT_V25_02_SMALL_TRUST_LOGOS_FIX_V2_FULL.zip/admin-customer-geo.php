<?php
/**
 * TRAVSCOPE V24.32 – dependent residential location directory.
 * No customer/personally identifying data is sent to third-party services:
 * only selected public geographic names are looked up after staff selection.
 * Country/state directory is bundled for offline availability.
 */
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: private, no-store');
if (empty($_SESSION['admin_id'])) {
    http_response_code(401); echo json_encode(['error'=>'Please sign in again.']); exit;
}
$token = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if ($token === '' || empty($_SESSION['admin_customers_csrf']) || !hash_equals((string)$_SESSION['admin_customers_csrf'], $token)) {
    http_response_code(403); echo json_encode(['error'=>'Your session token has expired. Reload Customer Management.']); exit;
}
$directory = json_decode((string)@file_get_contents(__DIR__.'/customer-location-directory.json'), true);
if (!is_array($directory)) {
    http_response_code(503); echo json_encode(['error'=>'Location directory missing. Upload all V24.32 patch files.']); exit;
}
$action = (string)($_GET['action'] ?? 'countries');
$country = trim((string)($_GET['country'] ?? ''));
$state = trim((string)($_GET['state'] ?? ''));
$district = trim((string)($_GET['district'] ?? ''));
foreach ([$country,$state,$district] as $part) {
    if (strlen($part)>150 || preg_match('/[\x00-\x1f]/', $part)) {
        http_response_code(422);echo json_encode(['error'=>'Invalid location value.']);exit;
    }
}
function crmGeoList(array $items): array {
    $out=[];
    foreach ($items as $item) {
        $name=trim((string)$item);
        if ($name==='' || strlen($name)>180) continue;
        $key=function_exists('mb_strtolower')?mb_strtolower($name,'UTF-8'):strtolower($name);
        $out[$key]=$name;
    }
    $out=array_values($out);natcasesort($out);return array_values($out);
}
function crmGeoCached(string $cacheKey, int $ttl, callable $fetcher) {
    $dir = rtrim(sys_get_temp_dir(),DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR.'travscope-public-location-directory';
    if (!is_dir($dir)) @mkdir($dir,0700,true);
    $file=$dir.DIRECTORY_SEPARATOR.hash('sha256',$cacheKey).'.json';
    if (is_file($file) && (time()-(int)filemtime($file))<$ttl) {
        $stored=json_decode((string)@file_get_contents($file),true);
        if (is_array($stored)) return $stored;
    }
    $value=$fetcher();
    if (is_array($value)) @file_put_contents($file,json_encode($value,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE),LOCK_EX);
    return $value;
}
function crmGeoRemote(string $url, ?array $post=null): ?array {
    // Fixed allow-list: never accept a URL from the request.
    if (!in_array($url,[
       'https://countriesnow.space/api/v0.1/countries/states',
       'https://countriesnow.space/api/v0.1/countries/state/cities',
       'https://raw.githubusercontent.com/KTBsomen/Indian-state-district-json/main/india-states-districts-latest.json'
    ],true)) return null;
    $raw=false;$status=0;
    if (function_exists('curl_init')) {
        $ch=curl_init($url);
        $opts=[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_CONNECTTIMEOUT=>4,CURLOPT_TIMEOUT=>11,
          CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_USERAGENT=>'TRAVSCOPE customer location directory / 24.32',
          CURLOPT_HTTPHEADER=>['Accept: application/json','Content-Type: application/json']];
        if ($post!==null) { $opts[CURLOPT_POST]=true;$opts[CURLOPT_POSTFIELDS]=json_encode($post,JSON_UNESCAPED_UNICODE); }
        curl_setopt_array($ch,$opts);$raw=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    } elseif (ini_get('allow_url_fopen')) {
        $method=$post===null?'GET':'POST';$context=stream_context_create([
           'http'=>['method'=>$method,'content'=>$post!==null?json_encode($post,JSON_UNESCAPED_UNICODE):'','timeout'=>11,'ignore_errors'=>false,
             'header'=>"Accept: application/json\r\nContent-Type: application/json\r\nUser-Agent: TRAVSCOPE-location-directory\r\n"],
           'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]
        ]);
        $raw=@file_get_contents($url,false,$context);$status=($raw===false)?0:200;
    }
    if (!is_string($raw) || $status<200 || $status>=300 || strlen($raw)>2000000) return null;
    $json=json_decode($raw,true);return is_array($json)?$json:null;
}
function crmGeoCountryApiName(string $name):string {
    $aliases=['Ivory Coast'=>"Côte d'Ivoire",'Turkey'=>'Turkey','South Korea'=>'South Korea','Russia'=>'Russia'];
    return $aliases[$name]??$name;
}
function crmGeoResponse(array $values, bool $manual=false, string $message='', string $scope='') : void {
    echo json_encode(['items'=>crmGeoList($values),'manual'=>$manual,'message'=>$message,'scope'=>$scope],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;
}
if ($action==='countries') {
    crmGeoResponse(array_column($directory['countries']??[],'name'),false,'All ISO-recognised countries and territories.','country');
}
if ($country==='') { http_response_code(422);echo json_encode(['error'=>'Choose a country first.']);exit; }
if ($action==='states') {
    $remote=crmGeoCached('states:'.$country,86400*4,function()use($country){
       $data=crmGeoRemote('https://countriesnow.space/api/v0.1/countries/states',['country'=>crmGeoCountryApiName($country)]);
       return (!empty($data['error']) || !is_array($data['data']['states']??null))?null:array_values(array_filter(array_map(static fn($s)=>is_array($s)?($s['name']??''):'',$data['data']['states'])));
    });
    $fallback=$directory['states'][$country]??[];
    $items=is_array($remote)&&count($remote)>0?$remote:$fallback;
    crmGeoResponse($items,!$items,$items?'Choose a state or province.':'No subdivision directory available; enter state/province manually.','state');
}
if ($state==='') { http_response_code(422);echo json_encode(['error'=>'Choose a state/province first.']);exit; }
if ($action==='districts') {
    if (strcasecmp($country,'India')===0) {
        $lookup=crmGeoCached('india-districts-current',86400*7,static function(){
            $data=crmGeoRemote('https://raw.githubusercontent.com/KTBsomen/Indian-state-district-json/main/india-states-districts-latest.json');
            return is_array($data)?$data:null;
        });
        $aliases=['Orissa'=>'Odisha','Pondicherry'=>'Puducherry','NCT of Delhi'=>'Delhi','Andaman & Nicobar Islands'=>'Andaman and Nicobar Islands'];
        $stateName=$aliases[$state]??$state;
        if (is_array($lookup)) foreach ($lookup as $row) {
            if (is_array($row) && strcasecmp(trim((string)($row['state']??'')),$stateName)===0) {
                crmGeoResponse((array)($row['districts']??[]),false,'Choose the district for '.$stateName.'.','district');
            }
        }
        // Non-invented offline safety-net for Odisha when external district directory is unavailable.
        if (strcasecmp($stateName,'Odisha')===0) crmGeoResponse([
         'Angul','Balangir','Balasore','Bargarh','Bhadrak','Boudh','Cuttack','Deogarh','Dhenkanal','Gajapati','Ganjam','Jagatsinghpur','Jajpur','Jharsuguda','Kalahandi','Kandhamal','Kendrapara','Keonjhar','Khordha','Koraput','Malkangiri','Mayurbhanj','Nabarangpur','Nayagarh','Nuapada','Puri','Rayagada','Sambalpur','Subarnapur','Sundargarh'
        ],false,'Offline Odisha districts. You may type another district if it is not listed.','district');
    }
    crmGeoResponse([],true,'No verified district directory is available for this selection. Type the district (or leave blank if not applicable), then choose a city.','district');
}
if ($action==='cities') {
    // Where a specifically curated district shortlist exists, present it first so the
    // selected district really narrows the locality options. This is NOT a full gazetteer.
    if (strcasecmp($country,'India')===0 && $district!=='') {
        $shortlists=(array)($directory['india_district_city_shortlist'][$state]??[]);
        $districtAliases=['Kendujhar'=>'Keonjhar','Jagatsinghapur'=>'Jagatsinghpur','Subarnapur (Sonepur)'=>'Subarnapur'];
        $districtName=$districtAliases[$district]??$district;
        foreach($shortlists as $districtKey=>$localities){
            if (strcasecmp($districtKey,$districtName)===0 && $localities) {
                crmGeoResponse((array)$localities,false,'Common city/town suggestions for '.$district.' district. This is a shortlist; choose Other to enter a different locality.','district');
            }
        }
    }
    // CountriesNow lists other cities by country/state, not a verified district map;
    // the UI states this limitation instead of asserting a false city/district match.
    $items=crmGeoCached('state-cities:'.$country.':'.$state,86400*5,function()use($country,$state){
       $data=crmGeoRemote('https://countriesnow.space/api/v0.1/countries/state/cities',['country'=>crmGeoCountryApiName($country),'state'=>$state]);
       if (!empty($data['error']) || !is_array($data['data']??null)) return null;
       return array_slice($data['data'],0,5000);
    });
    if (!is_array($items) || !$items) {
        // Reuse the established TRAVSCOPE offline state/town reference, without modifying that module.
        require_once __DIR__.'/location-master-functions.php';
        $fallback=function_exists('tsLocationFallbackCities')?tsLocationFallbackCities($country,$state):[];
        if ($fallback) crmGeoResponse($fallback,false,'Offline suggestions: common cities/towns in this state. More locations can be entered manually; confirm the selected district.','state');
        crmGeoResponse([],true,'No verified online city directory is available. Enter city/locality manually.','state');
    }
    crmGeoResponse($items,false,'Cities are suggestions for the chosen state/province. Confirm the correct district before saving.','state');
}
http_response_code(404);echo json_encode(['error'=>'Unknown location request.']);
