<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — SYSTEM CONFIGURATION + MASTER SETTINGS
|--------------------------------------------------------------------------
|
| Reuses the EXISTING `settings` table already used by admin-settings.php.
| No second settings table is introduced.
|
| All reads fail open to the catalog default.
| All writes are typed, validated, transactional and permission-protected.
|
*/

$tsSystemAclFile = __DIR__ . '/access-control-functions.php';
if (
    is_file($tsSystemAclFile)
    && !function_exists('tsAclCan')
) {
    require_once $tsSystemAclFile;
}


function tsSystemSettingsTableReady(PDO $pdo): bool
{
    static $ready = null;

    if (is_bool($ready)) {
        return $ready;
    }

    try {
        $stmt = $pdo->query("
            SELECT
                COUNT(DISTINCT column_name)
            FROM information_schema.columns
            WHERE table_schema = DATABASE()
              AND table_name = 'settings'
              AND column_name IN (
                    'id',
                    'setting_key',
                    'setting_value'
                  )
        ");

        return $ready =
            ((int)$stmt->fetchColumn() >= 3);

    } catch (Throwable $e) {
        return $ready = false;
    }
}


function tsSystemSettingsCatalog(): array
{
    return [
        'commercial' => [
            'title' => 'Commercial Defaults',
            'icon' => 'fa-solid fa-percent',
            'description' =>
                'Defaults used when a new CRM quotation costing form is opened. Existing quotation versions are never changed.',
            'fields' => [
                'ops_default_markup_type' => [
                    'label' => 'Default Markup Type',
                    'type' => 'select',
                    'default' => 'fixed',
                    'options' => [
                        'fixed' => 'Fixed Amount',
                        'percent' => 'Percentage %',
                    ],
                    'used_by' => 'CRM · New Quotation Version',
                ],
                'ops_default_markup_value' => [
                    'label' => 'Default Markup Value',
                    'type' => 'number',
                    'default' => '0',
                    'min' => 0,
                    'max' => 10000000,
                    'step' => '0.01',
                    'used_by' => 'CRM · New Quotation Version',
                    'help' =>
                        'When Markup Type is Percentage, keep this at 0–100.',
                ],
            ],
        ],

        'customer_automation' => [
            'title' => 'Customer Communication Automation',
            'icon' => 'fa-solid fa-envelope-circle-check',
            'description' =>
                'Controls automatic Booking communication job creation. Manual sends remain available.',
            'fields' => [
                'ops_auto_payment_reminders' => [
                    'label' => 'Automatic Payment Reminders',
                    'type' => 'toggle',
                    'default' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_payment_reminder_days_before' => [
                    'label' => 'Payment Reminder · Days Before Due',
                    'type' => 'number',
                    'default' => '3',
                    'min' => 0,
                    'max' => 60,
                    'step' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_payment_overdue_days_after' => [
                    'label' => 'Payment Overdue Reminder · Days After Due',
                    'type' => 'number',
                    'default' => '1',
                    'min' => 0,
                    'max' => 60,
                    'step' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_auto_document_reminders' => [
                    'label' => 'Automatic Missing Document Reminders',
                    'type' => 'toggle',
                    'default' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_repeat_missing_document_reminders' => [
                    'label' => 'Repeat Missing Document Reminders',
                    'type' => 'toggle',
                    'default' => '0',
                    'used_by' => 'Communication Center',
                    'help' => 'Enable after testing if you want reminders to repeat until documents are supplied.',
                ],
                'ops_document_reminder_repeat_days' => [
                    'label' => 'Missing Document Reminder Repeat · Days',
                    'type' => 'number',
                    'default' => '2',
                    'min' => 1,
                    'max' => 30,
                    'step' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_document_reminder_max_emails' => [
                    'label' => 'Missing Document · Maximum Reminder Emails',
                    'type' => 'number',
                    'default' => '5',
                    'min' => 1,
                    'max' => 20,
                    'step' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_repeat_overdue_payment_reminders' => [
                    'label' => 'Repeat Overdue Payment Reminders',
                    'type' => 'toggle',
                    'default' => '0',
                    'used_by' => 'Communication Center',
                    'help' => 'The existing first overdue reminder remains unchanged; enable this only for repeat emails.',
                ],
                'ops_payment_overdue_repeat_days' => [
                    'label' => 'Overdue Payment Reminder Repeat · Days',
                    'type' => 'number',
                    'default' => '3',
                    'min' => 1,
                    'max' => 30,
                    'step' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_payment_overdue_max_emails' => [
                    'label' => 'Overdue Payment · Maximum Reminder Emails',
                    'type' => 'number',
                    'default' => '3',
                    'min' => 1,
                    'max' => 20,
                    'step' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_auto_travel_document_validity_reminders' => [
                    'label' => 'Automatic Passport / Travel Document Validity Alerts',
                    'type' => 'toggle',
                    'default' => '0',
                    'used_by' => 'Communication Center',
                ],
                'ops_auto_departure_messages' => [
                    'label' => 'Automatic Departure Countdown',
                    'type' => 'toggle',
                    'default' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_departure_message_first_days' => [
                    'label' => 'First Departure Message · Days Before',
                    'type' => 'number',
                    'default' => '7',
                    'min' => 1,
                    'max' => 90,
                    'step' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_departure_message_final_days' => [
                    'label' => 'Final Departure Message · Days Before',
                    'type' => 'number',
                    'default' => '1',
                    'min' => 0,
                    'max' => 30,
                    'step' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_auto_voucher_delivery' => [
                    'label' => 'Automatic Final Voucher Delivery',
                    'type' => 'toggle',
                    'default' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_auto_document_pack_delivery' => [
                    'label' => 'Automatic Final Document Pack Delivery',
                    'type' => 'toggle',
                    'default' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_auto_post_trip_review' => [
                    'label' => 'Automatic Post-Trip Review Request',
                    'type' => 'toggle',
                    'default' => '1',
                    'used_by' => 'Communication Center',
                ],
                'ops_post_trip_review_days_after' => [
                    'label' => 'Post-Trip Review · Days After Completion',
                    'type' => 'number',
                    'default' => '1',
                    'min' => 0,
                    'max' => 30,
                    'step' => '1',
                    'used_by' => 'Communication Center',
                ],
            ],
        ],

        'reminder_engine' => [
            'title' => 'Automatic Reminder Engine',
            'icon' => 'fa-solid fa-bell-concierge',
            'description' =>
                'Cross-stage automation for quotation follow-ups, supplier RFQ reminders and post-booking supplier confirmation follow-ups. Email only; WhatsApp handoff remains manual unless a WhatsApp API is added later.',
            'fields' => [
                'ops_auto_quotation_followups' => [
                    'label' => 'Automatic Customer Quotation Follow-ups',
                    'type' => 'toggle',
                    'default' => '0',
                    'used_by' => 'Communication Automation',
                ],
                'ops_quotation_followup_first_days' => [
                    'label' => 'First Quotation Follow-up · Days After Email',
                    'type' => 'number',
                    'default' => '2',
                    'min' => 1,
                    'max' => 30,
                    'step' => '1',
                    'used_by' => 'Communication Automation',
                ],
                'ops_quotation_followup_repeat_days' => [
                    'label' => 'Quotation Follow-up Repeat · Days',
                    'type' => 'number',
                    'default' => '3',
                    'min' => 1,
                    'max' => 30,
                    'step' => '1',
                    'used_by' => 'Communication Automation',
                ],
                'ops_quotation_followup_max_reminders' => [
                    'label' => 'Quotation Follow-up · Maximum Emails',
                    'type' => 'number',
                    'default' => '3',
                    'min' => 0,
                    'max' => 10,
                    'step' => '1',
                    'used_by' => 'Communication Automation',
                ],
                'ops_auto_supplier_quote_reminders' => [
                    'label' => 'Automatic Supplier RFQ Reminders',
                    'type' => 'toggle',
                    'default' => '0',
                    'used_by' => 'Supplier Procurement',
                ],
                'ops_supplier_quote_reminder_repeat_hours' => [
                    'label' => 'Supplier RFQ Reminder Repeat · Hours',
                    'type' => 'number',
                    'default' => '24',
                    'min' => 1,
                    'max' => 336,
                    'step' => '1',
                    'used_by' => 'Supplier Procurement',
                    'help' => 'The first reminder still follows the Reminder Due time saved on the supplier request.',
                ],
                'ops_supplier_quote_max_reminders' => [
                    'label' => 'Supplier RFQ · Maximum Automatic Reminders',
                    'type' => 'number',
                    'default' => '3',
                    'min' => 0,
                    'max' => 10,
                    'step' => '1',
                    'used_by' => 'Supplier Procurement',
                ],
                'ops_auto_supplier_confirmation_reminders' => [
                    'label' => 'Automatic Supplier Booking Confirmation Reminders',
                    'type' => 'toggle',
                    'default' => '0',
                    'used_by' => 'Post-Booking Supplier Procurement',
                ],
                'ops_supplier_confirmation_first_hours' => [
                    'label' => 'First Supplier Confirmation Follow-up · Hours',
                    'type' => 'number',
                    'default' => '24',
                    'min' => 1,
                    'max' => 336,
                    'step' => '1',
                    'used_by' => 'Post-Booking Supplier Procurement',
                ],
                'ops_supplier_confirmation_repeat_hours' => [
                    'label' => 'Supplier Confirmation Repeat · Hours',
                    'type' => 'number',
                    'default' => '24',
                    'min' => 1,
                    'max' => 336,
                    'step' => '1',
                    'used_by' => 'Post-Booking Supplier Procurement',
                ],
                'ops_supplier_confirmation_max_reminders' => [
                    'label' => 'Supplier Confirmation · Maximum Automatic Reminders',
                    'type' => 'number',
                    'default' => '3',
                    'min' => 0,
                    'max' => 10,
                    'step' => '1',
                    'used_by' => 'Post-Booking Supplier Procurement',
                ],
            ],
        ],

        'supplier_sla' => [
            'title' => 'Supplier Confirmation SLA',
            'icon' => 'fa-solid fa-handshake',
            'description' =>
                'Escalation timing for post-Booking supplier confirmation monitoring.',
            'fields' => [
                'ops_supplier_response_warning_hours' => [
                    'label' => 'Supplier Response Warning · Hours',
                    'type' => 'number',
                    'default' => '24',
                    'min' => 1,
                    'max' => 720,
                    'step' => '1',
                    'used_by' => 'System Notifications',
                ],
                'ops_supplier_response_high_hours' => [
                    'label' => 'Supplier Response High Escalation · Hours',
                    'type' => 'number',
                    'default' => '72',
                    'min' => 1,
                    'max' => 1440,
                    'step' => '1',
                    'used_by' => 'System Notifications',
                ],
            ],
        ],

        'operations_risk' => [
            'title' => 'Departure Risk Windows',
            'icon' => 'fa-solid fa-plane-departure',
            'description' =>
                'Controls the Booking departure-readiness alert horizon and severity thresholds.',
            'fields' => [
                'ops_departure_risk_window_days' => [
                    'label' => 'Readiness Risk Window · Days',
                    'type' => 'number',
                    'default' => '14',
                    'min' => 1,
                    'max' => 120,
                    'step' => '1',
                    'used_by' => 'System Notifications',
                ],
                'ops_departure_risk_high_days' => [
                    'label' => 'High Risk When Departure Within · Days',
                    'type' => 'number',
                    'default' => '7',
                    'min' => 1,
                    'max' => 60,
                    'step' => '1',
                    'used_by' => 'System Notifications',
                ],
                'ops_departure_risk_critical_days' => [
                    'label' => 'Critical Risk When Departure Within · Days',
                    'type' => 'number',
                    'default' => '3',
                    'min' => 0,
                    'max' => 30,
                    'step' => '1',
                    'used_by' => 'System Notifications',
                ],
            ],
        ],

        'documents' => [
            'title' => 'Traveller Document Rules',
            'icon' => 'fa-solid fa-passport',
            'description' =>
                'Central document review and passport-validity thresholds. Destination-specific rules still require human verification.',
            'fields' => [
                'ops_passport_validity_months' => [
                    'label' => 'Passport Validity Warning · Months After Departure',
                    'type' => 'number',
                    'default' => '6',
                    'min' => 0,
                    'max' => 24,
                    'step' => '1',
                    'used_by' => 'Document & Traveller File Center',
                ],
                'ops_document_review_warning_hours' => [
                    'label' => 'Pending Document Review Warning · Hours',
                    'type' => 'number',
                    'default' => '48',
                    'min' => 1,
                    'max' => 720,
                    'step' => '1',
                    'used_by' => 'System Notifications',
                ],
                'ops_document_review_high_hours' => [
                    'label' => 'Pending Document Review High · Hours',
                    'type' => 'number',
                    'default' => '120',
                    'min' => 1,
                    'max' => 1440,
                    'step' => '1',
                    'used_by' => 'System Notifications',
                ],
            ],
        ],

        'repeat_sales' => [
            'title' => 'Repeat Sales Defaults',
            'icon' => 'fa-solid fa-rotate',
            'description' =>
                'Default follow-up timing when a completed Booking has no explicit execution follow-up date.',
            'fields' => [
                'ops_repeat_sales_followup_days' => [
                    'label' => 'Repeat Sales Follow-Up · Days After Completion',
                    'type' => 'number',
                    'default' => '30',
                    'min' => 1,
                    'max' => 365,
                    'step' => '1',
                    'used_by' => 'Business Analytics + Repeat Sales',
                ],
            ],
        ],
    ];
}


function tsSystemSettingDefinition(string $key): ?array
{
    foreach (tsSystemSettingsCatalog() as $groupKey => $group) {
        foreach ((array)$group['fields'] as $fieldKey => $field) {
            if ($fieldKey === $key) {
                $field['group'] = $groupKey;
                return $field;
            }
        }
    }

    return null;
}


function tsSystemSettingRaw(
    PDO $pdo,
    string $key,
    ?string $fallback = null
): string {
    static $cache = [];

    $definition =
        tsSystemSettingDefinition($key);

    $default =
        $fallback
        ?? (
            $definition !== null
                ? (string)$definition['default']
                : ''
        );

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    if (!tsSystemSettingsTableReady($pdo)) {
        return $cache[$key] = $default;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT setting_value
            FROM settings
            WHERE setting_key = ?
            LIMIT 1
        ");
        $stmt->execute([$key]);

        $value = $stmt->fetchColumn();

        return $cache[$key] =
            $value !== false
                ? (string)$value
                : $default;

    } catch (Throwable $e) {
        return $cache[$key] = $default;
    }
}


function tsSystemSettingInt(
    PDO $pdo,
    string $key,
    ?int $fallback = null
): int {
    $definition =
        tsSystemSettingDefinition($key);

    $value =
        (int)tsSystemSettingRaw(
            $pdo,
            $key,
            $fallback !== null
                ? (string)$fallback
                : null
        );

    if ($definition) {
        if (isset($definition['min'])) {
            $value = max((int)$definition['min'], $value);
        }

        if (isset($definition['max'])) {
            $value = min((int)$definition['max'], $value);
        }
    }

    return $value;
}


function tsSystemSettingFloat(
    PDO $pdo,
    string $key,
    ?float $fallback = null
): float {
    $definition =
        tsSystemSettingDefinition($key);

    $value =
        (float)tsSystemSettingRaw(
            $pdo,
            $key,
            $fallback !== null
                ? (string)$fallback
                : null
        );

    if ($definition) {
        if (isset($definition['min'])) {
            $value = max((float)$definition['min'], $value);
        }

        if (isset($definition['max'])) {
            $value = min((float)$definition['max'], $value);
        }
    }

    return $value;
}


function tsSystemSettingBool(
    PDO $pdo,
    string $key,
    ?bool $fallback = null
): bool {
    $value =
        strtolower(
            trim(
                tsSystemSettingRaw(
                    $pdo,
                    $key,
                    $fallback === null
                        ? null
                        : ($fallback ? '1' : '0')
                )
            )
        );

    return in_array(
        $value,
        ['1','true','yes','on','enabled'],
        true
    );
}


function tsSystemNormalizeSettingValue(
    string $key,
    mixed $input
): string {
    $field =
        tsSystemSettingDefinition($key);

    if (!$field) {
        throw new RuntimeException(
            'Unknown operational setting: ' . $key
        );
    }

    $type =
        (string)$field['type'];

    if ($type === 'toggle') {
        return !empty($input) ? '1' : '0';
    }

    if ($type === 'select') {
        $value =
            trim((string)$input);

        if (
            !array_key_exists(
                $value,
                (array)($field['options'] ?? [])
            )
        ) {
            throw new RuntimeException(
                (string)$field['label']
                . ' has an invalid option.'
            );
        }

        return $value;
    }

    if ($type === 'number') {
        if (
            $input === ''
            || $input === null
            || !is_numeric($input)
        ) {
            throw new RuntimeException(
                (string)$field['label']
                . ' must be numeric.'
            );
        }

        $value =
            (float)$input;

        if (
            isset($field['min'])
            && $value < (float)$field['min']
        ) {
            throw new RuntimeException(
                (string)$field['label']
                . ' must be at least '
                . (string)$field['min']
                . '.'
            );
        }

        if (
            isset($field['max'])
            && $value > (float)$field['max']
        ) {
            throw new RuntimeException(
                (string)$field['label']
                . ' must not exceed '
                . (string)$field['max']
                . '.'
            );
        }

        $step =
            (string)($field['step'] ?? '1');

        return
            str_contains($step, '.')
                ? rtrim(
                    rtrim(
                        number_format(
                            $value,
                            2,
                            '.',
                            ''
                        ),
                        '0'
                    ),
                    '.'
                )
                : (string)(int)round($value);
    }

    return trim((string)$input);
}


function tsSystemValidateCrossRules(array $values): void
{
    $markupType =
        (string)(
            $values['ops_default_markup_type']
            ?? 'fixed'
        );

    $markupValue =
        (float)(
            $values['ops_default_markup_value']
            ?? 0
        );

    if (
        $markupType === 'percent'
        && $markupValue > 100
    ) {
        throw new RuntimeException(
            'Default Percentage Markup cannot exceed 100%.'
        );
    }

    $supplierWarning =
        (int)(
            $values['ops_supplier_response_warning_hours']
            ?? 24
        );

    $supplierHigh =
        (int)(
            $values['ops_supplier_response_high_hours']
            ?? 72
        );

    if ($supplierHigh <= $supplierWarning) {
        throw new RuntimeException(
            'Supplier High Escalation must be later than the Supplier Warning threshold.'
        );
    }

    $riskWindow =
        (int)(
            $values['ops_departure_risk_window_days']
            ?? 14
        );

    $riskHigh =
        (int)(
            $values['ops_departure_risk_high_days']
            ?? 7
        );

    $riskCritical =
        (int)(
            $values['ops_departure_risk_critical_days']
            ?? 3
        );

    if (
        $riskWindow < $riskHigh
        || $riskHigh < $riskCritical
    ) {
        throw new RuntimeException(
            'Departure Risk thresholds must follow: Window ≥ High ≥ Critical.'
        );
    }

    $firstDeparture =
        (int)(
            $values['ops_departure_message_first_days']
            ?? 7
        );

    $finalDeparture =
        (int)(
            $values['ops_departure_message_final_days']
            ?? 1
        );

    if ($firstDeparture <= $finalDeparture) {
        throw new RuntimeException(
            'First Departure Message must be scheduled earlier than the Final Departure Message.'
        );
    }

    $docWarning =
        (int)(
            $values['ops_document_review_warning_hours']
            ?? 48
        );

    $docHigh =
        (int)(
            $values['ops_document_review_high_hours']
            ?? 120
        );

    if ($docHigh <= $docWarning) {
        throw new RuntimeException(
            'Document Review High threshold must be later than the Warning threshold.'
        );
    }
}


function tsSystemSaveSettings(
    PDO $pdo,
    array $input,
    int $adminId
): array {
    if (!tsSystemSettingsTableReady($pdo)) {
        throw new RuntimeException(
            'The existing settings table is unavailable.'
        );
    }

    if (function_exists('tsAclRequire')) {
        tsAclRequire(
            $pdo,
            $adminId,
            'manage_access',
            'update_operational_master_settings',
            'system_settings',
            null
        );
    }

    $normalized = [];

    foreach (tsSystemSettingsCatalog() as $group) {
        foreach ((array)$group['fields'] as $key => $field) {
            $normalized[$key] =
                tsSystemNormalizeSettingValue(
                    $key,
                    $input[$key]
                    ?? (
                        (string)$field['type'] === 'toggle'
                            ? '0'
                            : (string)$field['default']
                    )
                );
        }
    }

    tsSystemValidateCrossRules($normalized);

    $before = [];

    foreach ($normalized as $key => $value) {
        $before[$key] =
            tsSystemSettingRaw(
                $pdo,
                $key
            );
    }

    $pdo->beginTransaction();

    try {
        $find =
            $pdo->prepare("
                SELECT id
                FROM settings
                WHERE setting_key = ?
                LIMIT 1
                FOR UPDATE
            ");

        $update =
            $pdo->prepare("
                UPDATE settings
                SET
                    setting_value = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");

        $insert =
            $pdo->prepare("
                INSERT INTO settings
                (
                    setting_key,
                    setting_value
                )
                VALUES (?, ?)
            ");

        foreach ($normalized as $key => $value) {
            $find->execute([$key]);

            $id =
                (int)(
                    $find->fetchColumn()
                    ?: 0
                );

            if ($id > 0) {
                $update->execute([
                    $value,
                    $id
                ]);
            } else {
                $insert->execute([
                    $key,
                    $value
                ]);
            }
        }

        $pdo->commit();

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $e;
    }

    $changed = [];

    foreach ($normalized as $key => $value) {
        if (
            (string)($before[$key] ?? '')
            !== (string)$value
        ) {
            $changed[$key] = [
                'before' =>
                    (string)($before[$key] ?? ''),
                'after' =>
                    (string)$value,
            ];
        }
    }

    if (
        $changed
        && function_exists('tsAclAudit')
    ) {
        try {
            tsAclAudit(
                $pdo,
                $adminId,
                'manage_access',
                'update_operational_master_settings_values',
                'authorized',
                'system_settings',
                null,
                [
                    'changed_settings' =>
                        $changed,
                ]
            );
        } catch (Throwable $e) {
            error_log(
                'Operational settings audit: '
                . $e->getMessage()
            );
        }
    }

    return $changed;
}
