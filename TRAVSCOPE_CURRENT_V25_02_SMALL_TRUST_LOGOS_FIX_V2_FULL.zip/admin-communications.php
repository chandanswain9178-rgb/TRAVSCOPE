<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
require_once __DIR__.'/communication-center-functions.php';
require_once __DIR__.'/communication-email-view.php';
$access=__DIR__.'/access-control-functions.php'; if(is_file($access))require_once $access;
if(empty($_SESSION['admin_id'])){header('Location: '.BASE_URL.'admin-login.php');exit;}
$adminId=(int)$_SESSION['admin_id'];
if(!tsCommReady($pdo)){
    // SQL is deliberately not installed from a public/admin page; use phpMyAdmin after a backup.
    $requiredCommTables=['communication_inbox_messages','communication_attachments','communication_sync_state'];
    $missingCommTables=[];
    foreach ($requiredCommTables as $commTable) {
        $commCheck=tsCommTableProbe($pdo,$commTable);
        if (!$commCheck['ok']) $missingCommTables[$commTable]=$commCheck['reason'];
    }
    $commRuntimeDb='(unavailable)'; $commRuntimeAccount='(unavailable)';
    try { $commRuntimeDb=(string)$pdo->query('SELECT DATABASE()')->fetchColumn(); } catch (Throwable $e) {}
    try { $commRuntimeAccount=(string)$pdo->query('SELECT CURRENT_USER()')->fetchColumn(); } catch (Throwable $e) {}
    http_response_code(503);
    header('Content-Type: text/html; charset=utf-8');
    ?>
    <!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Communication Center Setup · TRAVSCOPE</title>
    <style>
    :root{font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#142b49;background:#f2f6fc}
    *{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:radial-gradient(circle at top left,#e2eefd,#f4f7fc 55%)}
    main{width:min(100%,740px);background:#fff;border:1px solid #dce6f3;border-radius:18px;box-shadow:0 16px 48px #163a6314;overflow:hidden}
    header{background:linear-gradient(110deg,#072447,#1163d1);padding:26px 30px;color:#fff}header small{letter-spacing:.12em;font-weight:800;opacity:.8}h1{font-size:25px;margin:8px 0 4px}header p{opacity:.85;margin:0;font-size:14px;line-height:1.6}
    .content{padding:24px 30px}h2{font-size:16px;margin:2px 0 10px}.warn{border-left:4px solid #ef9c1c;background:#fff8e9;padding:12px 14px;border-radius:7px;font-size:14px;line-height:1.5}
    code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;background:#eef3fb;padding:2px 5px;border-radius:4px;overflow-wrap:anywhere}
    ul{padding-left:20px;line-height:1.9;font-size:14px}.steps{font-size:14px;line-height:1.85;color:#405570}.actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:20px}
    a{display:inline-block;text-decoration:none;border-radius:9px;padding:10px 16px;background:#1869d8;color:#fff;font-weight:700;font-size:13px}
    a.secondary{background:#edf3fc;color:#174673}footer{padding:13px 30px;border-top:1px solid #e8eef6;font-size:12px;color:#7a8da5}
    @media(max-width:520px){header,.content,footer{padding-left:18px;padding-right:18px}h1{font-size:21px}}
    
/* V24.63 — space-managed Gmail-inspired communication workspace */
.tc-mail{padding:9px 13px 18px;max-width:1940px}
.tc-mail .page-head{padding:9px 13px;gap:8px;align-items:center;background:linear-gradient(110deg,#fff,#f4f9ff)}
.tc-mail .page-head h1{font-size:19px;letter-spacing:-.35px;margin:1px 0}
.tc-mail .page-head .eyebrow{font-size:9px;letter-spacing:.9px}
.tc-mail .stats{margin:0;gap:4px;display:flex;align-items:center;flex-wrap:wrap}
.tc-mail .stats .stat{flex:none;min-width:0;padding:5px 8px;gap:6px;border-radius:7px;font-size:10px;background:#f8fbff}
.tc-mail .stats .stat strong{font-size:15px}
.tc-mail .stats .stat i{font-size:11px}
.tc-mail .head-buttons .btn{padding:6px 9px;font-size:11px}
.tc-mail .mail-grid{grid-template-columns:minmax(320px,34%) minmax(0,1fr);gap:8px}
.tc-mail .inbox-tools{padding:7px 9px;gap:5px;min-height:40px}
.tc-mail .inbox-tools form{gap:5px}
.tc-mail .inbox-tools .btn,.tc-mail .inbox-tools .select{padding:6px 7px;font-size:11px}
.tc-mail .inbox-tools .muted{font-size:10px}
.tc-mail .searchbar{padding:6px 8px}
.tc-mail .searchbar form{grid-template-columns:minmax(100px,1fr) minmax(86px,auto) minmax(83px,auto) auto;gap:4px}
.tc-mail .searchbar .input,.tc-mail .searchbar .select{padding:7px 6px;font-size:11px}
.tc-mail .searchbar .btn{padding:6px 8px;font-size:11px}
.tc-mail .folders{padding:5px 7px;gap:2px;flex-wrap:nowrap;overflow-x:auto}
.tc-mail .folder{padding:5px 7px;font-size:10px;white-space:nowrap}
.tc-mail .mail-list{height:clamp(450px,calc(100vh - 264px),800px);min-height:450px}
.tc-mail .mail-row{padding:7px 8px;gap:7px;align-items:center;min-height:65px;border-left-width:2px}
.tc-mail .mail-row .avatar{width:27px;height:27px;flex-basis:27px;font-size:11px}
.tc-mail .mail-one{gap:4px}.tc-mail .mail-sender{font-size:11px;max-width:68%}
.tc-mail .mail-one .muted{font-size:9px}.tc-mail .mail-subject{font-size:11px;margin-top:1px;font-weight:750}
.tc-mail .mail-snippet{font-size:10px;margin-top:1px;line-height:1.24}
.tc-mail .mail-tags{margin-top:3px;gap:3px}.tc-mail .mail-tags .tag{font-size:9px;padding:1px 5px}
.tc-mail .reader-toolbar{padding:7px 10px;position:sticky;top:0;z-index:5}
.tc-mail .reader-toolbar .btn{padding:6px 8px;font-size:11px}
.tc-mail .reader-main{padding:12px 14px}.tc-mail .reader h2{font-size:18px}
.tc-mail .sender-line{padding:10px 0}.tc-mail .visual-iframe{height:clamp(350px,55vh,620px)}
.tc-mail .compose-card{background:#fff;scroll-margin-top:15px}
.tc-mail .compose-head{display:flex;justify-content:space-between;gap:9px;align-items:center;padding:9px 11px;font-size:12px}
.tc-mail .compose-body{padding:10px 12px}
.tc-mail .compose-recipients{display:flex;align-items:center;gap:9px;flex-wrap:wrap;padding:6px 3px 10px;border-bottom:1px solid #edf1f7;font-size:12px}
.tc-mail .compose-recipients .compose-subject{width:100%;font-size:11px;color:#6c7e95;overflow-wrap:anywhere}
.tc-mail .editor-toolbar{display:flex;align-items:center;gap:3px;padding:7px 3px;border-bottom:1px solid #e5edf6}
.tc-mail .editor-toolbar[hidden],.tc-mail .rich-editor[hidden],.tc-mail .compose-error[hidden]{display:none!important}
.tc-mail .editor-toolbar button{width:30px;height:28px;display:grid;place-items:center;border:1px solid transparent;background:transparent;border-radius:5px;color:#365779;cursor:pointer}
.tc-mail .editor-toolbar button:hover,.tc-mail .editor-toolbar button:focus-visible{background:#eaf3ff;border-color:#cce1ff;color:#125dcc;outline:none}
.tc-mail .tool-separator{height:18px;border-left:1px solid #d9e3f1;margin:0 3px}
.tc-mail .rich-editor{min-height:150px;max-height:460px;overflow:auto;padding:13px 6px;border:0;outline:0;white-space:pre-wrap;overflow-wrap:anywhere;font-size:13px;line-height:1.65;color:#22364f}
.tc-mail .rich-editor:empty:before{content:attr(data-placeholder);color:#98a6b8;pointer-events:none}
.tc-mail .rich-editor p{margin:0 0 10px}.tc-mail .rich-editor a{color:#126ae0;text-decoration:underline}
.tc-mail .rich-editor:focus-visible{box-shadow:inset 0 -2px 0 #b7d5ff}
.tc-mail .compose-footer{display:flex;justify-content:space-between;align-items:center;gap:9px;flex-wrap:wrap;border-top:1px solid #e5edf6;padding-top:9px}
.tc-mail .compose-error{color:#b12b2b;background:#fff2f2;border:1px solid #f2cece;border-radius:7px;padding:7px 9px;font-size:11px;margin:4px 0 8px}
.tc-mail .thread-html{margin-top:8px}.tc-mail .thread-html summary{font-size:11px;color:#1462d6;cursor:pointer}.tc-mail .thread-html iframe{width:100%;height:300px;border:1px solid #e0e8f3;border-radius:7px;background:#fff;margin-top:6px}
@media(max-width:1330px){.tc-mail .page-head .stats{order:3;width:100%}.tc-mail .page-head .head-buttons{margin-left:auto}}
@media(max-width:1100px){.tc-mail .mail-grid{grid-template-columns:minmax(300px,38%) minmax(0,1fr)}.tc-mail .searchbar form{grid-template-columns:1fr 1fr}.tc-mail .searchbar .input{grid-column:1/-1}}
@media(max-width:800px){.tc-mail{padding:7px}.tc-mail .mail-grid{display:flex;flex-direction:column}.tc-mail .mail-list{height:300px;min-height:300px}.tc-mail .page-head .stats{order:3}.tc-mail .stats .stat{padding:5px 7px}.tc-mail .reader-main{padding:10px}.tc-mail .visual-iframe{height:420px}}
@media(max-width:470px){.tc-mail .page-head{padding:9px}.tc-mail .inbox-tools .muted{width:100%}.tc-mail .stats{flex-wrap:wrap}.tc-mail .stats .stat{font-size:9px}.tc-mail .compose-footer .btn{width:100%}}
</style></head><body><main>
    <header><small>TRAVSCOPE · ADMINISTRATION / STEP 11E</small><h1>Communication Center Setup Required</h1><p>The shared inbox database is not fully installed or is inaccessible to the current database user.</p></header>
    <div class="content"><div class="warn"><strong>Your existing business data has not been changed.</strong><br>Complete the one-time database setup and refresh this page.</div>
    <div class="steps" style="margin-top:15px"><strong>PHP connection:</strong> Database <code><?=htmlspecialchars($commRuntimeDb,ENT_QUOTES,'UTF-8')?></code> · MySQL account <code><?=htmlspecialchars($commRuntimeAccount,ENT_QUOTES,'UTF-8')?></code></div>
    <h2 style="margin-top:22px">Tables needing attention</h2><ul>
    <?php foreach($missingCommTables as $commTable=>$commReason):?><li><code><?=htmlspecialchars($commTable,ENT_QUOTES,'UTF-8')?></code> — <?=htmlspecialchars($commReason,ENT_QUOTES,'UTF-8')?></li><?php endforeach;?>
    </ul><h2>Next step</h2><div class="steps">If phpMyAdmin lists these tables, <strong>do not import the SQL again</strong>. Check that the PHP connection database shown above matches phpMyAdmin and grant this site's MySQL user SELECT, INSERT and UPDATE permissions (plus other application-required privileges) for the database in MilesWeb. If a table is actually absent, back up the current database first, then import only <code>travscope-step-11e-shared-communication-center.sql</code>. Refresh this page.</div>
    <div class="actions"><a href="" onclick="location.reload();return false">Recheck installation</a><a class="secondary" href="<?=htmlspecialchars(BASE_URL.'admin-dashboard.php',ENT_QUOTES,'UTF-8')?>">Back to dashboard</a></div></div>
    <footer>For security, the schema must be installed manually by an authorised database administrator.</footer>
    </main></body></html>
    <?php
    exit;
}
if(function_exists('tsAclRequire')){try{tsAclRequire($pdo,$adminId,'view_crm','view_shared_communication_center','communication',0);}catch(Throwable $e){/* stay compatible when this permission key does not exist */}}
if(empty($_SESSION['ts_comm_csrf']))$_SESSION['ts_comm_csrf']=bin2hex(random_bytes(32));$csrf=(string)$_SESSION['ts_comm_csrf'];
$success=(string)($_SESSION['ts_comm_success']??'');$error=(string)($_SESSION['ts_comm_error']??'');unset($_SESSION['ts_comm_success'],$_SESSION['ts_comm_error']);

function tce(string $v):string{return htmlspecialchars($v,ENT_QUOTES,'UTF-8');}
function tcRedirect(string $url='admin-communications.php'):never{header('Location: '.BASE_URL.$url);exit;}

if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  if(!hash_equals($csrf,(string)($_POST['csrf']??'')))throw new RuntimeException('Security verification failed.');
  $action=(string)($_POST['action']??'');$messageId=max(0,(int)($_POST['message_id']??0));
  if($action==='sync'){$r=tsCommSyncInbox($pdo,max(1,min(90,(int)($_POST['lookback_days']??14))));if(!$r['available']||$r['error']!=='')throw new RuntimeException($r['error']?:'Mailbox sync failed.');$_SESSION['ts_comm_success']='Mailbox synced: '.$r['inserted'].' new message(s), '.$r['attachments'].' attachment(s), '.($r['html_updated']??0).' existing email(s) upgraded to HTML.';tcRedirect();}
  if($action==='compose'){
    $to=trim((string)($_POST['compose_to']??''));$subject=trim((string)($_POST['compose_subject']??''));
    $body=trim((string)($_POST['reply_body']??''));$html=(string)($_POST['reply_html']??'');
    $newId=tsCommSendNewEmail($pdo,$to,$subject,$body,$adminId,$html);
    unset($_SESSION['ts_comm_compose_draft']);
    $_SESSION['ts_comm_success']='HTML email composed, sent and saved with its table formatting.';
    tcRedirect('admin-communications.php?status=all&id='.$newId);
  }
  if($messageId<=0)throw new RuntimeException('Select a communication first.');$m=tsCommGetMessage($pdo,$messageId);if(!$m)throw new RuntimeException('Communication not found.');
  if($action==='mark_read'){$pdo->prepare('UPDATE communication_inbox_messages SET is_read=1 WHERE id=?')->execute([$messageId]);$_SESSION['ts_comm_success']='Marked as read.';tcRedirect('admin-communications.php?id='.$messageId);}
  if($action==='resolve'){$pdo->prepare("UPDATE communication_inbox_messages SET is_read=1,status='resolved',assigned_admin_id=COALESCE(assigned_admin_id,?) WHERE id=?")->execute([$adminId,$messageId]);$_SESSION['ts_comm_success']='Conversation resolved.';tcRedirect();}
  if($action==='assign'){$assign=max(0,(int)($_POST['assigned_admin_id']??0));$pdo->prepare('UPDATE communication_inbox_messages SET assigned_admin_id=? WHERE id=?')->execute([$assign?:null,$messageId]);$_SESSION['ts_comm_success']='Assignment updated.';tcRedirect('admin-communications.php?id='.$messageId);}
  if($action==='priority'){$p=(string)($_POST['priority']??'normal');if(!in_array($p,['low','normal','high','urgent'],true))$p='normal';$pdo->prepare('UPDATE communication_inbox_messages SET priority=? WHERE id=?')->execute([$p,$messageId]);$_SESSION['ts_comm_success']='Priority updated.';tcRedirect('admin-communications.php?id='.$messageId);}
  if($action==='reply'){$body=trim((string)($_POST['reply_body']??''));$html=(string)($_POST['reply_html']??'');tsCommSendEmail($pdo,$m,$body,$adminId,$html);$_SESSION['ts_comm_success']='Formatted HTML email reply sent and recorded in the communication thread.';tcRedirect('admin-communications.php?id='.$messageId.'#reply');}
  if($action==='record_external'){$channel=(string)($_POST['external_channel']??'whatsapp');if(!in_array($channel,['whatsapp','phone','manual'],true))$channel='manual';$direction=(string)($_POST['external_direction']??'inbound');if(!in_array($direction,['inbound','outbound','internal'],true))$direction='inbound';$body=trim((string)($_POST['external_body']??''));if($body==='')throw new RuntimeException('Enter the communication note/message.');$external='manual-'.$channel.'-'.bin2hex(random_bytes(8));$data=['mailbox_key'=>(string)$m['mailbox_key'],'external_message_id'=>$external,'thread_key'=>(string)$m['thread_key'],'direction'=>$direction,'channel'=>$channel,'sender_name'=>$direction==='outbound'?'TRAVSCOPE.COM':(string)$m['sender_name'],'sender_email'=>$direction==='outbound'?(defined('SMTP_USERNAME')?(string)SMTP_USERNAME:''):(string)$m['sender_email'],'recipient_name'=>$direction==='outbound'?(string)$m['sender_name']:'TRAVSCOPE.COM','recipient_email'=>$direction==='outbound'?(string)$m['sender_email']:(defined('SMTP_USERNAME')?(string)SMTP_USERNAME:''),'subject'=>$channel==='phone'?'Phone communication':'WhatsApp communication','body_text'=>$body,'message_date'=>date('Y-m-d H:i:s'),'is_read'=>1,'status'=>'resolved','priority'=>'normal','assigned_admin_id'=>$adminId,'party_type'=>(string)$m['party_type'],'supplier_id'=>$m['supplier_id']?:null,'supplier_request_id'=>$m['supplier_request_id']?:null,'enquiry_id'=>$m['enquiry_id']?:null,'trip_id'=>$m['trip_id']?:null,'quotation_version_id'=>$m['quotation_version_id']?:null,'booking_id'=>$m['booking_id']?:null,'match_confidence'=>100,'match_notes'=>'Manually recorded in Shared Communication Center.'];tsCommStoreMessage($pdo,$data);$_SESSION['ts_comm_success']=ucfirst($channel).' communication recorded in the same thread.';tcRedirect('admin-communications.php?id='.$messageId);}
  if($action==='relink'){
    $supplierId=max(0,(int)($_POST['supplier_id']??0));$supplierRequestId=0;$tripId=0;$enquiryId=0;$qv=max(0,(int)($_POST['quotation_version_id']??0));$bookingId=max(0,(int)($_POST['booking_id']??0));
    $sr=trim((string)($_POST['supplier_request']??''));if($sr!==''){$q=$pdo->prepare('SELECT id,supplier_id,trip_id FROM supplier_requests WHERE id=? OR request_code=? LIMIT 1');$q->execute([(int)$sr,$sr]);if($r=$q->fetch(PDO::FETCH_ASSOC)){$supplierRequestId=(int)$r['id'];$supplierId=$supplierId?:((int)$r['supplier_id']);$tripId=(int)($r['trip_id']??0);}}
    $trip=trim((string)($_POST['trip']??''));if($trip!==''){$q=$pdo->prepare('SELECT id,enquiry_id FROM trips WHERE id=? OR trip_code=? LIMIT 1');$q->execute([(int)$trip,$trip]);if($r=$q->fetch(PDO::FETCH_ASSOC)){$tripId=(int)$r['id'];$enquiryId=(int)$r['enquiry_id'];}}
    if($qv>0){$q=$pdo->prepare('SELECT lead_id FROM crm_package_versions WHERE id=? LIMIT 1');$q->execute([$qv]);$lead=(int)$q->fetchColumn();if($lead>0){$enquiryId=$lead;$q=$pdo->prepare('SELECT id FROM trips WHERE enquiry_id=? LIMIT 1');$q->execute([$lead]);$tripId=(int)$q->fetchColumn();}}
    $party=$supplierId>0?'supplier':(($enquiryId>0||$tripId>0||$qv>0||$bookingId>0)?'customer':'unknown');
    $pdo->prepare('UPDATE communication_inbox_messages SET party_type=?,supplier_id=?,supplier_request_id=?,enquiry_id=?,trip_id=?,quotation_version_id=?,booking_id=?,match_confidence=100,match_notes=? WHERE id=?')->execute([$party,$supplierId?:null,$supplierRequestId?:null,$enquiryId?:null,$tripId?:null,$qv?:null,$bookingId?:null,'Manually linked by admin.',$messageId]);
    $_SESSION['ts_comm_success']='Communication linkage updated.';tcRedirect('admin-communications.php?id='.$messageId);
  }
  if($action==='import_supplier_pdf'){$aid=max(0,(int)($_POST['attachment_id']??0));$supplierId=max(0,(int)($m['supplier_id']??0));$docId=tsCommImportPdfAttachment($pdo,$aid,$supplierId,$adminId);$_SESSION['ts_comm_success']='PDF imported into Supplier Document Center as document #'.$docId.'.';tcRedirect('admin-communications.php?id='.$messageId);}
 }catch(Throwable $e){$_SESSION['ts_comm_error']=$e->getMessage();if(($action??'')==='compose'){$_SESSION['ts_comm_compose_draft']=['to'=>(string)($_POST['compose_to']??''),'subject'=>(string)($_POST['compose_subject']??''),'html'=>substr((string)($_POST['reply_html']??''),0,240000),'body'=>substr((string)($_POST['reply_body']??''),0,20000)];tcRedirect('admin-communications.php?compose=1');}tcRedirect($messageId>0?'admin-communications.php?id='.$messageId:'admin-communications.php');}
}

$isCompose=(int)($_GET['compose']??0)===1;
$composeDraft=(array)($_SESSION['ts_comm_compose_draft']??[]);unset($_SESSION['ts_comm_compose_draft']);
$status=(string)($_GET['status']??'open');if(!in_array($status,['open','waiting','resolved','spam','all'],true))$status='open';$party=(string)($_GET['party']??'all');if(!in_array($party,['all','customer','supplier','unknown'],true))$party='all';$qText=trim((string)($_GET['q']??''));$selectedId=max(0,(int)($_GET['id']??0));
$where=[];$params=[];if($status!=='all'){$where[]='m.status=?';$params[]=$status;}if($party!=='all'){$where[]='m.party_type=?';$params[]=$party;}if($qText!==''){$where[]='(m.subject LIKE ? OR m.sender_email LIKE ? OR m.sender_name LIKE ? OR m.body_text LIKE ?)';$like='%'.$qText.'%';array_push($params,$like,$like,$like,$like);} $sqlWhere=$where?'WHERE '.implode(' AND ',$where):'';
$stmt=$pdo->prepare("SELECT m.*,s.company_name,sr.request_code,t.trip_code,b.booking_number,a.name assigned_name,(SELECT COUNT(*) FROM communication_attachments ca WHERE ca.message_id=m.id) attachment_count FROM communication_inbox_messages m LEFT JOIN suppliers s ON s.id=m.supplier_id LEFT JOIN supplier_requests sr ON sr.id=m.supplier_request_id LEFT JOIN trips t ON t.id=m.trip_id LEFT JOIN bookings b ON b.id=m.booking_id LEFT JOIN admins a ON a.id=m.assigned_admin_id $sqlWhere ORDER BY (m.status='open') DESC,(m.is_read=0) DESC,FIELD(m.priority,'urgent','high','normal','low'),m.message_date DESC,m.id DESC LIMIT 250");$stmt->execute($params);$rows=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
$selected=$isCompose?null:($selectedId?tsCommGetMessage($pdo,$selectedId):($rows?tsCommGetMessage($pdo,(int)$rows[0]['id']):null));if($selected){$pdo->prepare('UPDATE communication_inbox_messages SET is_read=1 WHERE id=?')->execute([(int)$selected['id']]);$a=$pdo->prepare('SELECT * FROM communication_attachments WHERE message_id=? ORDER BY id');$a->execute([(int)$selected['id']]);$attachments=$a->fetchAll(PDO::FETCH_ASSOC)?:[];$th=$pdo->prepare('SELECT * FROM communication_inbox_messages WHERE thread_key=? ORDER BY message_date ASC,id ASC');$th->execute([(string)$selected['thread_key']]);$thread=$th->fetchAll(PDO::FETCH_ASSOC)?:[];}else{$attachments=[];$thread=[];}
$admins=$pdo->query("SELECT id,name FROM admins WHERE status='active' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC)?:[];$suppliers=$pdo->query("SELECT id,company_name FROM suppliers WHERE status='active' ORDER BY company_name")->fetchAll(PDO::FETCH_ASSOC)?:[];
$stats=$pdo->query("SELECT SUM(status='open') open_count,SUM(status='open' AND is_read=0) unread_count,SUM(status='open' AND sla_due_at<NOW()) overdue_count,SUM(status='open' AND party_type='supplier') supplier_count,SUM(status='open' AND party_type='customer') customer_count FROM communication_inbox_messages")->fetch(PDO::FETCH_ASSOC)?:[];
$sync=$pdo->query("SELECT * FROM communication_sync_state WHERE mailbox_key='primary' LIMIT 1")->fetch(PDO::FETCH_ASSOC)?:null;
$hasHtml=$selected && trim((string)($selected['body_html']??''))!=='';
$showRemote=$hasHtml && (int)($_GET['images']??0)===1;
$emailDoc=$hasHtml?tsCommEmailFrameDocument((string)$selected['body_html'],$showRemote):'';
$viewParams=['status'=>$status,'party'=>$party,'q'=>$qText,'id'=>(int)($selected['id']??0)];
function tcQuery(array $params): string {return 'admin-communications.php?'.http_build_query($params);}
function tcEmailEditorToolbar(): string {return <<<'HTML'
<div class="editor-toolbar" id="tc-editor-toolbar" hidden aria-label="Email and table formatting">
  <button type="button" data-cmd="bold" aria-label="Bold" title="Bold (Ctrl+B)"><i class="fa-solid fa-bold"></i></button>
  <button type="button" data-cmd="italic" aria-label="Italic" title="Italic (Ctrl+I)"><i class="fa-solid fa-italic"></i></button>
  <button type="button" data-cmd="underline" aria-label="Underline" title="Underline (Ctrl+U)"><i class="fa-solid fa-underline"></i></button>
  <span class="tool-separator"></span>
  <button type="button" data-cmd="insertUnorderedList" aria-label="Bullet list" title="Bullet list"><i class="fa-solid fa-list-ul"></i></button>
  <button type="button" data-cmd="insertOrderedList" aria-label="Numbered list" title="Numbered list"><i class="fa-solid fa-list-ol"></i></button>
  <button type="button" data-cmd="createLink" aria-label="Insert link" title="Insert link"><i class="fa-solid fa-link"></i></button>
  <span class="tool-separator"></span>
  <button type="button" data-cmd="insertTable" class="table-tool" aria-label="Insert HTML table" title="Insert HTML table"><i class="fa-solid fa-table-cells"></i> Table</button>
  <button type="button" data-cmd="addRow" class="table-tool" aria-label="Add table row" title="Add row to selected table"><i class="fa-solid fa-table-rows"></i> + Row</button>
  <button type="button" data-cmd="addColumn" class="table-tool" aria-label="Add table column" title="Add column to selected table"><i class="fa-solid fa-table-columns"></i> + Col</button>
  <button type="button" data-cmd="removeTable" class="table-tool" aria-label="Remove table" title="Remove selected table"><i class="fa-solid fa-trash-can"></i></button>
  <span class="tool-separator"></span>
  <button type="button" data-cmd="source" class="table-tool" aria-label="Toggle HTML source" title="Paste or edit HTML source, including full tables"><i class="fa-solid fa-code"></i> HTML</button>
  <button type="button" data-cmd="removeFormat" aria-label="Clear formatting" title="Clear formatting"><i class="fa-solid fa-eraser"></i></button>
</div>
HTML;
}

?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Communication Center · TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<!-- Preserve the shared administration shell. -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
<style>
.tc-mail{--navy:#102c51;--blue:#1462d6;--teal:#0da895;--line:#e1e8f2;--muted:#718099;--bg:#eef4fb;max-width:1900px;margin:auto;padding:14px 18px 26px;color:#172b4b;font:13px/1.45 Inter,"Segoe UI",Arial,sans-serif}
.tc-mail *{box-sizing:border-box}.tc-mail h1,.tc-mail h2,.tc-mail h3,.tc-mail p{margin-top:0}.tc-mail h1{font-size:22px;line-height:1.2;margin-bottom:3px;letter-spacing:-.5px}.tc-mail h2{font-size:17px}.tc-mail a{color:inherit;text-decoration:none}.tc-mail button,.tc-mail select,.tc-mail input,.tc-mail textarea{font:inherit}.tc-mail .muted{color:var(--muted)}.tc-mail .small{font-size:11px}.tc-mail .panel{background:#fff;border:1px solid var(--line);border-radius:14px;overflow:hidden;min-width:0;box-shadow:0 8px 24px rgba(24,63,111,.035)}
.tc-mail .page-head{background:linear-gradient(110deg,#fff 30%,#edf6ff);border:1px solid #dce8f6;border-left:4px solid #176fe4;border-radius:15px;padding:13px 17px;display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap}.tc-mail .eyebrow{font-size:10px;font-weight:800;letter-spacing:1.2px;color:var(--blue);text-transform:uppercase}.tc-mail .head-buttons{display:flex;gap:7px;flex-wrap:wrap;align-items:center}
.tc-mail .btn{display:inline-flex;justify-content:center;align-items:center;gap:6px;border:1px solid #d9e4f2;background:#f6f9fe;color:#275078;padding:8px 11px;border-radius:8px;font-weight:700;cursor:pointer;white-space:nowrap}.tc-mail .btn:hover{background:#eaf3ff;border-color:#a9c9f2}.tc-mail .btn.primary{background:linear-gradient(110deg,#1462d6,#0c79e5);border-color:#1462d6;color:#fff}.tc-mail .btn.green{background:#ebfcf3;border-color:#bee9d0;color:#078657}.tc-mail .btn.ghost{background:#fff}.tc-mail .input,.tc-mail .select,.tc-mail textarea{border:1px solid #d1deed;color:#253c5a;background:#fff;border-radius:8px;padding:8px 10px;min-width:0;max-width:100%}.tc-mail textarea{width:100%;resize:vertical;line-height:1.55}.tc-mail .input:focus,.tc-mail textarea:focus,.tc-mail .select:focus{outline:2px solid #b9d7ff;outline-offset:0}
.tc-mail .stats{display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin:9px 0}.tc-mail .stat{padding:6px 12px;background:#fff;border:1px solid var(--line);border-radius:9px;display:flex;align-items:center;gap:9px;min-width:112px;font-size:11px;color:#617692}.tc-mail .stat strong{font-size:18px;line-height:1;color:#123b6b}.tc-mail .stat i{color:#1970df}.tc-mail .stat.red strong,.tc-mail .stat.red i{color:#c52e3a}.tc-mail .flash{margin:10px 0;padding:10px 14px;border-radius:8px;border:1px solid}.tc-mail .flash.ok{color:#06784c;background:#edfff5;border-color:#bdecd3}.tc-mail .flash.err{color:#af2828;background:#fff0f0;border-color:#f7caca}
.tc-mail .mail-grid{display:grid;grid-template-columns:minmax(300px,35%) minmax(0,1fr);gap:10px;align-items:start}.tc-mail .inbox-tools{padding:10px 12px;display:flex;align-items:center;gap:7px;border-bottom:1px solid var(--line);flex-wrap:wrap}.tc-mail .inbox-tools form{display:flex;align-items:center;gap:6px;flex-wrap:wrap}.tc-mail .inbox-tools .select{padding:7px 8px}.tc-mail .inbox-tools .btn{padding:8px}.tc-mail .searchbar{padding:10px 12px;background:#fbfdff;border-bottom:1px solid var(--line)}.tc-mail .searchbar form{display:grid;grid-template-columns:minmax(0,1fr) auto auto auto;gap:6px}.tc-mail .searchbar .input{width:100%}.tc-mail .folders{display:flex;gap:5px;align-items:center;flex-wrap:wrap;padding:8px 12px;border-bottom:1px solid var(--line);background:#fff}.tc-mail .folder{font-weight:650;font-size:11px;color:#607995;padding:6px 9px;border-radius:6px;border:1px solid transparent}.tc-mail .folder.active{background:#e9f3ff;color:#135bc4;border-color:#d0e5ff}
.tc-mail .mail-list{height:min(72vh,860px);min-height:480px;overflow:auto;scrollbar-color:#bdcfe4 transparent}.tc-mail .mail-row{display:flex;gap:10px;align-items:flex-start;padding:12px;border-bottom:1px solid #edf2f8;border-left:3px solid transparent;transition:background .15s}.tc-mail .mail-row:hover{background:#f4f9ff}.tc-mail .mail-row.active{background:#eaf4ff;border-left-color:#1462d6}.tc-mail .mail-row.unread{font-weight:750;background-color:#f9fcff}.tc-mail .mail-row.unread .mail-subject{color:#102a4b}.tc-mail .avatar{width:32px;height:32px;border-radius:50%;background:#e7ecfa;color:#1762c4;display:grid;place-items:center;flex:0 0 32px;font-size:13px;font-weight:850}.tc-mail .mail-row:nth-child(3n+2) .avatar{background:#e2f8f1;color:#088967}.tc-mail .mail-row:nth-child(3n+3) .avatar{background:#fff1e2;color:#bd6b07}.tc-mail .mail-info{min-width:0;flex:1}.tc-mail .mail-one{display:flex;align-items:center;gap:5px;justify-content:space-between}.tc-mail .mail-sender,.tc-mail .mail-subject,.tc-mail .mail-snippet{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.tc-mail .mail-sender{font-size:12px;max-width:65%}.tc-mail .mail-subject{font-size:12px;font-weight:800;margin-top:3px}.tc-mail .mail-snippet{font-size:11px;color:#7d8ba1;font-weight:400;margin-top:3px}.tc-mail .mail-tags{display:flex;gap:4px;margin-top:6px;flex-wrap:wrap}.tc-mail .tag{display:inline-block;border-radius:999px;background:#f0f3f8;color:#5c6e87;padding:2px 7px;font-size:10px;font-weight:750}.tc-mail .tag.supplier{color:#07845b;background:#e6f8ef}.tc-mail .tag.customer{color:#175fcc;background:#eaf2ff}.tc-mail .tag.urgent,.tc-mail .tag.overdue{color:#bb2d34;background:#ffebed}.tc-mail .tag.high{color:#b96b07;background:#fff3de}.tc-mail .no-mail{text-align:center;padding:48px 15px;color:#889bb3}
.tc-mail .reader{min-height:610px}.tc-mail .reader-toolbar{padding:10px 14px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;gap:8px;align-items:center;flex-wrap:wrap;background:#fcfdff}.tc-mail .reader-main{padding:18px 21px}.tc-mail .reader h2{margin:0;font-size:20px;line-height:1.32;color:#162d4d;overflow-wrap:anywhere}.tc-mail .sender-line{display:flex;align-items:center;gap:10px;padding:16px 0 12px}.tc-mail .sender-line .avatar{height:39px;width:39px;flex-basis:39px;font-size:17px}.tc-mail .sender-address{font-size:12px;color:#6c7b90;overflow-wrap:anywhere}.tc-mail .sender-date{margin-left:auto;align-self:flex-start;white-space:nowrap;color:#8492a5;font-size:11px}.tc-mail .reader-labels{display:flex;gap:5px;flex-wrap:wrap;margin:7px 0 0}.tc-mail .mail-content{border:1px solid #e0e8f3;border-radius:11px;overflow:hidden;background:#fff}.tc-mail .content-tabs{padding:7px 10px;background:#f7faff;border-bottom:1px solid #e8eef6;display:flex;gap:7px;align-items:center;flex-wrap:wrap}.tc-mail .view-button{background:transparent;border:1px solid transparent;border-radius:6px;color:#607c9f;cursor:pointer;padding:5px 10px;font-weight:750}.tc-mail .view-button.active{background:#fff;border-color:#cbdcf1;color:#135fc7;box-shadow:0 1px 3px #13395d10}.tc-mail .visual-iframe{display:block;width:100%;height:600px;border:0;background:#fff}.tc-mail .plain-copy{white-space:pre-wrap;word-break:break-word;padding:18px 22px;max-height:700px;overflow:auto;min-height:180px;font:13px/1.72 "Segoe UI",Arial,sans-serif}.tc-mail .hidden{display:none!important}.tc-mail .reading-tip{font-size:11px;color:#70859e;margin-top:8px}.tc-mail .section-card{border:1px solid var(--line);border-radius:11px;margin-top:12px;background:#fff;padding:12px 14px}.tc-mail .section-card h3{font-size:13px;color:#1d4067;margin-bottom:10px}.tc-mail .attachment-grid{display:flex;flex-wrap:wrap;gap:8px}.tc-mail .attachment{border:1px solid #dce6f3;border-radius:8px;padding:10px 12px;display:flex;gap:8px;align-items:flex-start;min-width:190px;max-width:100%;background:#fcfdff}.tc-mail .attachment-name{font-size:11px;font-weight:700;overflow-wrap:anywhere}.tc-mail .section-card summary{cursor:pointer;font-weight:800;color:#1d4067}.tc-mail .section-card[open] summary{margin-bottom:12px}.tc-mail .compose-card{border:1px solid #cfdeef;border-radius:12px;margin-top:14px;background:#fbfdff;overflow:hidden}.tc-mail .compose-head{padding:11px 14px;background:#eff6ff;color:#1c4c85;font-weight:800;border-bottom:1px solid #dfeafa}.tc-mail .compose-body{padding:12px}.tc-mail .tc-fields{display:grid;grid-template-columns:1fr 1fr;gap:12px}.tc-mail .stack{display:flex;flex-wrap:wrap;gap:7px;align-items:center}.tc-mail .stack form{display:flex;gap:7px;flex-wrap:wrap;align-items:center}.tc-mail .section-card .input,.tc-mail .section-card .select{max-width:100%}.tc-mail .thread-item{border-left:3px solid #cbd7e7;padding:10px 12px;background:#f8fbff;margin-top:8px;border-radius:0 9px 9px 0}.tc-mail .thread-item.outbound{border-left-color:#1462d6}.tc-mail .thread-item.inbound{border-left-color:#15ab7c}.tc-mail .thread-item .copy{white-space:pre-wrap;color:#4b607c;margin-top:6px;overflow-wrap:anywhere}
/* Keep the global admin visual decorator from inflating this compact header. */
body.ts-pro-admin .tc-mail .page-head .ts-iq200-titlebar{display:block!important;padding:0!important;margin:0!important;border:0!important;background:transparent!important;box-shadow:none!important}
body.ts-pro-admin .tc-mail .page-head .ts-iq200-titlebar .ts-iq-title-icon{display:none!important}
@media(max-width:1170px){.tc-mail .mail-grid{grid-template-columns:minmax(280px,38%) minmax(0,1fr)}.tc-mail .searchbar form{grid-template-columns:1fr 1fr}.tc-mail .searchbar .input{grid-column:1/-1}.tc-mail .tc-fields{grid-template-columns:1fr}}
@media(max-width:800px){.tc-mail{padding:9px}.tc-mail .mail-grid{display:flex;flex-direction:column}.tc-mail .mail-grid>.panel{width:100%}.tc-mail .mail-list{height:340px;min-height:0}.tc-mail .reader-main{padding:12px}.tc-mail .visual-iframe{height:490px}.tc-mail .sender-line{flex-wrap:wrap}.tc-mail .sender-date{margin-left:49px;width:100%}.tc-mail .stats .stat{flex:1;min-width:100px}}
@media(max-width:450px){.tc-mail .page-head{padding:12px}.tc-mail .searchbar form{grid-template-columns:1fr 1fr}.tc-mail .inbox-tools{align-items:flex-start}.tc-mail .visual-iframe{height:390px}}

/* Apply the V24.63 editor styles in the actual mailbox stylesheet (not only setup mode). */
.tc-mail .compose-card{background:#fff;scroll-margin-top:15px}
.tc-mail .compose-head{display:flex;justify-content:space-between;gap:9px;align-items:center;padding:9px 11px;font-size:12px}
.tc-mail .compose-body{padding:10px 12px}
.tc-mail .compose-recipients{display:flex;align-items:center;gap:9px;flex-wrap:wrap;padding:6px 3px 10px;border-bottom:1px solid #edf1f7;font-size:12px}
.tc-mail .compose-recipients .compose-subject{width:100%;font-size:11px;color:#6c7e95;overflow-wrap:anywhere}
.tc-mail .editor-toolbar{display:flex;align-items:center;gap:3px;padding:7px 3px;border-bottom:1px solid #e5edf6}
.tc-mail .editor-toolbar[hidden],.tc-mail .rich-editor[hidden],.tc-mail .compose-error[hidden]{display:none!important}
.tc-mail .editor-toolbar button{width:30px;height:28px;display:grid;place-items:center;border:1px solid transparent;background:transparent;border-radius:5px;color:#365779;cursor:pointer}
.tc-mail .editor-toolbar button:hover,.tc-mail .editor-toolbar button:focus-visible{background:#eaf3ff;border-color:#cce1ff;color:#125dcc;outline:none}
.tc-mail .tool-separator{height:18px;border-left:1px solid #d9e3f1;margin:0 3px}
.tc-mail .rich-editor{min-height:150px;max-height:460px;overflow:auto;padding:13px 6px;border:0;outline:0;white-space:pre-wrap;overflow-wrap:anywhere;font-size:13px;line-height:1.65;color:#22364f}
.tc-mail .rich-editor:empty:before{content:attr(data-placeholder);color:#98a6b8;pointer-events:none}
.tc-mail .rich-editor p{margin:0 0 10px}.tc-mail .rich-editor a{color:#126ae0;text-decoration:underline}
.tc-mail .rich-editor:focus-visible{box-shadow:inset 0 -2px 0 #b7d5ff}
.tc-mail .compose-footer{display:flex;justify-content:space-between;align-items:center;gap:9px;flex-wrap:wrap;border-top:1px solid #e5edf6;padding-top:9px}
.tc-mail .compose-error{color:#b12b2b;background:#fff2f2;border:1px solid #f2cece;border-radius:7px;padding:7px 9px;font-size:11px;margin:4px 0 8px}

/* V24.64: Gmail-style HTML table composer. Uses inline, email-compatible table formatting on send. */
.tc-mail .editor-toolbar{flex-wrap:wrap}
.tc-mail .editor-toolbar button.table-tool{width:auto;padding:0 9px;gap:5px;display:inline-flex;font-size:11px;font-weight:750;white-space:nowrap}
.tc-mail .rich-editor{white-space:normal;min-height:185px}
.tc-mail .rich-editor table{border-collapse:collapse;width:100%;max-width:100%;margin:10px 0;table-layout:auto;font-size:12px;background:#fff}
.tc-mail .rich-editor th,.tc-mail .rich-editor td{border:1px solid #cad7e8;padding:7px 9px;min-width:28px;vertical-align:top}
.tc-mail .rich-editor th{background:#edf4ff;font-weight:800}
.tc-mail .rich-editor td:focus{outline:1px solid #126ae0}
.tc-mail .rich-editor blockquote{border-left:3px solid #b2c9e6;padding-left:10px}
.tc-mail .html-source-editor{width:100%;min-height:185px;resize:vertical;border:1px solid #cadaeb;border-radius:7px;font:12px/1.55 Consolas,monospace;padding:12px;background:#fbfdff;color:#1d385a}
.tc-mail .html-source-editor[hidden]{display:none!important}
.tc-mail .compose-address{display:grid;grid-template-columns:70px minmax(0,1fr);align-items:center;gap:8px;margin-bottom:9px;font-size:12px}
.tc-mail .compose-address .input{width:100%}
.tc-mail .compose-hint{font-size:10px;color:#6c7e95;margin:6px 0 8px}
.tc-mail .compose-main{padding:13px 16px}
@media(max-width:530px){.tc-mail .editor-toolbar button.table-tool{padding:0 6px;font-size:10px}.tc-mail .compose-address{grid-template-columns:1fr;gap:3px}}
</style>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head><body class="tc-comms-page">
<div class="tc-mail wrap">
  <header class="page-head"><div><span class="eyebrow">Customer relationship management · Shared inbox</span><h1><i class="fa-regular fa-envelope" style="color:#126ae0"></i> Communication Center</h1><span class="muted small">Email conversations, supplier replies, attachments and follow-ups — in one workspace</span></div>
    <div class="head-buttons"><a class="btn primary" href="<?=tce(tcQuery(['compose'=>1]))?>"><i class="fa-solid fa-pen-to-square"></i> Compose</a><a class="btn ghost" href="<?=tce(BASE_URL.'admin-crm.php')?>"><i class="fa-solid fa-route"></i> CRM / Trips</a><a class="btn ghost" href="<?=tce(BASE_URL.'admin-dashboard.php')?>"><i class="fa-solid fa-gauge"></i> Dashboard</a></div>
  <div class="stats" aria-label="Mailbox summary">
  <?php foreach([['Open','open_count','fa-inbox'],['Unread','unread_count','fa-envelope'],['SLA overdue','overdue_count','fa-clock'],['Supplier','supplier_count','fa-building'],['Customer','customer_count','fa-user']] as $n=>$data):?>
    <span class="stat <?=$n===2?'red':''?>"><i class="fa-solid <?=$data[2]?>"></i> <?=tce($data[0])?> <strong><?=intval($stats[$data[1]]??0)?></strong></span>
  <?php endforeach;?></div>
  </header>
  <?php if($success):?><div class="flash ok"><i class="fa-solid fa-circle-check"></i> <?=tce($success)?></div><?php endif;?>
  <?php if($error):?><div class="flash err"><i class="fa-solid fa-triangle-exclamation"></i> <?=tce($error)?></div><?php endif;?>
  <div class="mail-grid">
    <section class="panel" aria-label="Email inbox">
      <div class="inbox-tools"><form method="post"><input type="hidden" name="csrf" value="<?=tce($csrf)?>"><input type="hidden" name="action" value="sync"><select class="select" name="lookback_days" aria-label="Email synchronisation range"><?php foreach([7,14,30,90] as $days):?><option value="<?=$days?>" <?=$days===14?'selected':''?>><?=$days?> days</option><?php endforeach;?></select><button class="btn primary" type="submit"><i class="fa-solid fa-rotate"></i> Sync Email</button></form><span class="muted small">Last sync: <?=tce((string)($sync['last_success_at']??'Never'))?></span></div>
      <div class="searchbar"><form method="get"><input class="input" name="q" value="<?=tce($qText)?>" placeholder="Search sender, subject or message…" aria-label="Search emails"><select class="select" name="status" aria-label="Status"><?php foreach(['all'=>'All statuses','open'=>'Open','waiting'=>'Waiting','resolved'=>'Resolved','spam'=>'Spam'] as $value=>$label):?><option value="<?=$value?>" <?=$status===$value?'selected':''?>><?=$label?></option><?php endforeach;?></select><select class="select" name="party" aria-label="Party type"><?php foreach(['all'=>'All parties','supplier'=>'Supplier','customer'=>'Customer','unknown'=>'Unknown'] as $value=>$label):?><option value="<?=$value?>" <?=$party===$value?'selected':''?>><?=$label?></option><?php endforeach;?></select><button class="btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Filter</button></form></div>
      <nav class="folders" aria-label="Inbox categories"><?php foreach(['all'=>'All Mail','open'=>'Inbox','waiting'=>'Waiting','resolved'=>'Resolved','spam'=>'Spam'] as $value=>$label):?><a class="folder <?=$status===$value?'active':''?>" href="<?=tce(tcQuery(['status'=>$value,'party'=>$party,'q'=>$qText]))?>"><?=$label?></a><?php endforeach;?><span class="muted small" style="margin-left:auto"><?=count($rows)?> loaded</span></nav>
      <div class="mail-list">
      <?php if(!$rows):?><div class="no-mail"><i class="fa-regular fa-envelope-open" style="font-size:32px"></i><p style="margin-top:10px">No messages match these filters.</p><a class="btn" href="<?=tce(tcQuery(['status'=>'all','party'=>'all']))?>">Show all mail</a></div><?php endif;?>
      <?php foreach($rows as $r):$active=$selected && (int)$selected['id']===(int)$r['id'];$over=!empty($r['sla_due_at'])&&$r['status']==='open'&&strtotime((string)$r['sla_due_at'])<time();$sender=(string)($r['sender_name']?:$r['sender_email']?:'Unknown sender');?>
        <a class="mail-row <?=empty($r['is_read'])?'unread':''?> <?=$active?'active':''?>" href="<?=tce(tcQuery(['status'=>$status,'party'=>$party,'q'=>$qText,'id'=>(int)$r['id']]))?>" <?=$active?'aria-current="true"':''?>>
          <span class="avatar"><?=tce(mb_strtoupper(mb_substr($sender,0,1)))?></span><div class="mail-info"><div class="mail-one"><strong class="mail-sender"><?=tce($sender)?></strong><span class="muted small" style="white-space:nowrap"><?=tce(date('d M H:i',strtotime((string)$r['message_date'])))?></span></div><div class="mail-subject"><?=tce((string)($r['subject']?:'(No subject)'))?></div><div class="mail-snippet"><?=tce(mb_substr(preg_replace('/\s+/u',' ',trim((string)$r['body_text']))??'',0,135))?></div><div class="mail-tags"><span class="tag <?=tce((string)$r['party_type'])?>"><?=tce(ucfirst((string)$r['party_type']))?></span><?php if((int)($r['attachment_count']??0)>0):?><span class="tag"><i class="fa-solid fa-paperclip"></i> <?=intval($r['attachment_count'])?></span><?php endif;?><?php if((string)$r['priority']!=='normal'):?><span class="tag <?=tce((string)$r['priority'])?>"><?=tce(ucfirst((string)$r['priority']))?></span><?php endif;?><?php if($over):?><span class="tag overdue">Overdue</span><?php endif;?></div></div>
        </a>
      <?php endforeach;?></div>
    </section>
    <section class="panel reader" aria-label="Email reader">
      <?php if($isCompose):?>
      <div class="reader-toolbar"><strong><i class="fa-solid fa-pen-to-square" style="color:#1462d6"></i> New HTML email</strong><a class="btn" href="admin-communications.php"><i class="fa-solid fa-arrow-left"></i> Inbox</a></div>
      <div class="reader-main compose-main"><h2 style="margin-bottom:7px">Compose message</h2>
        <p class="muted small">Create a new conversation with a fully formatted email, including HTML tables.</p>
        <form method="post" id="tc-reply-form" class="compose-card compose-body tc-reply-form" style="margin-top:10px">
          <input type="hidden" name="csrf" value="<?=tce($csrf)?>"><input type="hidden" name="action" value="compose"><input type="hidden" name="reply_html" id="tc-reply-html" value="">
          <label class="compose-address"><strong>To</strong><input class="input" type="email" name="compose_to" maxlength="190" required placeholder="recipient@example.com" value="<?=tce((string)($composeDraft['to']??''))?>"></label>
          <label class="compose-address"><strong>Subject</strong><input class="input" name="compose_subject" maxlength="190" required placeholder="Email subject" value="<?=tce((string)($composeDraft['subject']??''))?>"></label>
          <?=tcEmailEditorToolbar()?>
          <div id="tc-rich-editor" class="rich-editor" role="textbox" aria-label="Compose formatted HTML email" aria-multiline="true" contenteditable="true" data-placeholder="Compose your message. Insert a table or paste an Excel table…" hidden></div>
          <textarea id="tc-draft-restore" hidden><?=tce((string)($composeDraft['html']??''))?></textarea>
          <textarea id="tc-source-html" class="html-source-editor" aria-label="Email HTML source" placeholder="Paste HTML or a table here…" hidden></textarea>
          <p class="compose-hint">Insert Table · Paste tables from Excel/Word · HTML source. Outgoing mail includes a plain-text alternative.</p>
          <textarea name="reply_body" id="tc-reply-fallback" rows="7" required placeholder="Write your new email…"><?=tce((string)($composeDraft['body']??''))?></textarea>
          <p id="tc-compose-error" class="compose-error" role="alert" hidden></p>
          <div class="compose-footer"><span class="muted small"><i class="fa-solid fa-shield-halved"></i> Safe HTML tables, formatting and links</span><button type="submit" class="btn primary"><i class="fa-solid fa-paper-plane"></i> Send HTML Email</button></div>
        </form>
      </div>
      <?php elseif(!$selected):?><div class="no-mail" style="padding:100px 12px"><i class="fa-regular fa-envelope-open" style="font-size:44px"></i><h2 style="margin-top:15px">Select a message to read</h2><p>Choose a conversation from your inbox.</p></div>
      <?php else:?>
      <div class="reader-toolbar"><span class="muted small"><i class="fa-solid fa-envelope-open-text"></i> MESSAGE #<?=intval($selected['id'])?> · <?=tce(ucfirst((string)$selected['status']))?> · <?=tce(ucfirst((string)$selected['channel']))?></span><div class="stack"><a class="btn primary" href="#reply"><i class="fa-solid fa-reply"></i> Reply</a><form method="post"><input type="hidden" name="csrf" value="<?=tce($csrf)?>"><input type="hidden" name="action" value="mark_read"><input type="hidden" name="message_id" value="<?=intval($selected['id'])?>"><button class="btn" type="submit"><i class="fa-regular fa-envelope-open"></i> Mark read</button></form><?php if($selected['status']!=='resolved'):?><form method="post"><input type="hidden" name="csrf" value="<?=tce($csrf)?>"><input type="hidden" name="action" value="resolve"><input type="hidden" name="message_id" value="<?=intval($selected['id'])?>"><button class="btn green" type="submit"><i class="fa-solid fa-check"></i> Resolve</button></form><?php endif;?></div></div>
      <div class="reader-main">
        <h2><?=tce((string)($selected['subject']?:'(No subject)'))?></h2>
        <div class="reader-labels"><span class="tag <?=tce((string)$selected['party_type'])?>"><?=tce(ucfirst((string)$selected['party_type']))?></span><span class="tag <?=tce((string)$selected['priority'])?>"><?=tce(ucfirst((string)$selected['priority']))?> priority</span><?php if((int)($selected['match_confidence']??0)>0):?><span class="tag"><?=intval($selected['match_confidence'])?>% CRM match</span><?php endif;?><?php if(!empty($selected['company_name'])):?><span class="tag"><?=tce((string)$selected['company_name'])?></span><?php endif;?><?php if(!empty($selected['trip_code'])):?><a class="tag" href="<?=tce(BASE_URL.'admin-trip-commercial-hub.php?trip_id='.(int)$selected['trip_id'])?>">Trip <?=tce((string)$selected['trip_code'])?> ↗</a><?php endif;?><?php if(!empty($selected['request_code'])):?><a class="tag" href="<?=tce(BASE_URL.'admin-supplier-request-details.php?id='.(int)$selected['supplier_request_id'])?>">RFQ <?=tce((string)$selected['request_code'])?> ↗</a><?php endif;?><?php if(!empty($selected['booking_number'])):?><span class="tag">Booking <?=tce((string)$selected['booking_number'])?></span><?php endif;?><?php if(!empty($selected['version_number'])):?><span class="tag">Quote V<?=intval($selected['version_number'])?></span><?php endif;?></div>
        <?php $selectedSender=(string)($selected['sender_name']?:$selected['sender_email']?:'Unknown sender');?><div class="sender-line"><span class="avatar"><?=tce(mb_strtoupper(mb_substr($selectedSender,0,1)))?></span><div style="min-width:0"><strong><?=tce($selectedSender)?></strong><div class="sender-address">From: <?=tce((string)$selected['sender_email'])?><br>To: <?=tce((string)($selected['recipient_email']?:'TRAVSCOPE'))?></div></div><span class="sender-date"><?=tce(date('d M Y, h:i A',strtotime((string)$selected['message_date'])))?></span></div>
        <div class="mail-content">
          <div class="content-tabs"><span class="muted small" style="margin-right:auto"><i class="fa-solid fa-shield-halved"></i> Protected email viewer</span><?php if($hasHtml):?><button type="button" class="view-button active" data-view="html" aria-pressed="true">Formatted HTML</button><button type="button" class="view-button" data-view="text" aria-pressed="false">Plain text</button><?php else:?><span class="tag">Plain text email</span><?php endif;?></div>
          <?php if($hasHtml):?><div id="tc-html-body"><iframe class="visual-iframe" title="Formatted email body (isolated)" sandbox="allow-popups allow-popups-to-escape-sandbox" referrerpolicy="no-referrer" loading="lazy" srcdoc="<?=tce($emailDoc)?>"></iframe></div><?php endif;?>
          <div id="tc-text-body" class="plain-copy <?=$hasHtml?'hidden':''?>"><?=tce((string)$selected['body_text'])?></div>
        </div>
        <?php if($hasHtml):?><p class="reading-tip"><i class="fa-solid fa-lock"></i> Scripts and email forms are disabled. <?php if(!$showRemote):?>External images are blocked for privacy. <a href="<?=tce(tcQuery(array_merge($viewParams,['images'=>1])))?>" style="color:#1261c9;text-decoration:underline;font-weight:750">Load external images for this message</a><?php else:?>External images enabled for this view. <a href="<?=tce(tcQuery($viewParams))?>" style="color:#1261c9;text-decoration:underline">Block images again</a><?php endif;?></p><?php else:?><p class="reading-tip">Older messages may have plain text only. Run Sync Email (choose 30 or 90 days) to retrieve the original HTML if it remains available on the mail server.</p><?php endif;?>
        <?php if($attachments):?><div class="section-card"><h3><i class="fa-solid fa-paperclip" style="color:#1462d6"></i> Attachments (<?=count($attachments)?>)</h3><div class="attachment-grid"><?php foreach($attachments as $a):?><div class="attachment"><i class="fa-regular <?=!empty($a['is_pdf'])?'fa-file-pdf':'fa-file'?>" style="color:#1462d6;font-size:19px"></i><div style="min-width:0"><div class="attachment-name"><?=tce((string)$a['original_filename'])?></div><span class="muted small"><?=number_format(((int)$a['file_size'])/1024,1)?> KB</span><br><a style="color:#1462d6;font-weight:750" href="<?=tce(BASE_URL.'admin-communication-attachment.php?id='.(int)$a['id'])?>" target="_blank" rel="noopener noreferrer">Open / Download ↗</a><?php if((int)$a['is_pdf']===1 && !empty($selected['supplier_id'])):?><form method="post" style="margin-top:6px"><input type="hidden" name="csrf" value="<?=tce($csrf)?>"><input type="hidden" name="action" value="import_supplier_pdf"><input type="hidden" name="message_id" value="<?=intval($selected['id'])?>"><input type="hidden" name="attachment_id" value="<?=intval($a['id'])?>"><button class="btn green" type="submit">Supplier Docs<?=!empty($a['supplier_document_id'])?' #'.intval($a['supplier_document_id']):''?></button></form><?php endif;?></div></div><?php endforeach;?></div></div><?php endif;?>
        <?php $replyTo=(string)((($selected['direction']??'inbound')==='outbound')?($selected['recipient_email']??''):($selected['sender_email']??''));?>
        <div class="compose-card" id="reply">
          <div class="compose-head"><span><i class="fa-solid fa-reply"></i> Reply to conversation</span><span class="tag" style="background:#e6f5ed;color:#087d55"><i class="fa-solid fa-code"></i> Rich HTML email</span></div>
          <form method="post" class="compose-body tc-reply-form" id="tc-reply-form">
            <input type="hidden" name="csrf" value="<?=tce($csrf)?>"><input type="hidden" name="action" value="reply"><input type="hidden" name="message_id" value="<?=intval($selected['id'])?>">
            <input type="hidden" name="reply_html" id="tc-reply-html" value="">
            <div class="compose-recipients"><span class="muted">To</span> <strong><?=tce($replyTo)?></strong><span class="compose-subject"><?=tce(tsCommReplySubject($selected))?></span></div>
            <?=tcEmailEditorToolbar()?>
            <div id="tc-rich-editor" class="rich-editor" role="textbox" aria-label="Write formatted email reply" aria-multiline="true" contenteditable="true" data-placeholder="Write your professional reply…" hidden></div>
            <textarea id="tc-source-html" class="html-source-editor" aria-label="Email HTML source" placeholder="Paste safe HTML or an HTML table…" hidden></textarea>
            <p class="compose-hint">Insert Table or paste a table from Excel / Word. HTML source lets you enter table markup; unsafe content is removed on send.</p>
            <textarea name="reply_body" id="tc-reply-fallback" rows="6" placeholder="Write your reply…" required></textarea>
            <p id="tc-compose-error" role="alert" class="compose-error" hidden></p>
            <div class="compose-footer"><span class="muted small"><i class="fa-solid fa-shield-halved"></i> HTML with a plain-text alternative · safe formatting</span><button class="btn primary" type="submit"><i class="fa-solid fa-paper-plane"></i> Send HTML Reply</button></div>
          </form>
        </div>
        <details class="section-card"><summary><i class="fa-solid fa-list" style="color:#1462d6"></i> Conversation thread (<?=count($thread)?>)</summary><?php foreach($thread as $t):?><div class="thread-item <?=in_array((string)$t['direction'],['inbound','outbound'],true)?tce((string)$t['direction']):''?>"><strong><?=tce(ucfirst((string)$t['direction']))?> · <?=tce((string)($t['sender_name']?:$t['sender_email']))?></strong><span class="muted small" style="float:right"><?=tce((string)$t['message_date'])?></span><div class="copy"><?=tce(mb_substr((string)$t['body_text'],0,850))?></div><?php if((string)$t['direction']==='outbound' && trim((string)($t['body_html']??''))!==''):?><details class="thread-html"><summary><i class="fa-solid fa-code"></i> View formatted sent reply</summary><iframe title="Sent HTML reply" sandbox="" referrerpolicy="no-referrer" loading="lazy" srcdoc="<?=tce(tsCommEmailFrameDocument((string)$t['body_html'],false))?>"></iframe></details><?php endif;?></div><?php endforeach;?></details>
        <details class="section-card"><summary><i class="fa-solid fa-sliders" style="color:#1462d6"></i> Assignment, priority and CRM linking</summary>
          <div class="tc-fields"><form method="post"><input type="hidden" name="csrf" value="<?=tce($csrf)?>"><input type="hidden" name="action" value="assign"><input type="hidden" name="message_id" value="<?=intval($selected['id'])?>"><strong class="small">Assigned to</strong><div class="stack" style="margin-top:6px"><select class="select" name="assigned_admin_id"><option value="0">Unassigned</option><?php foreach($admins as $a):?><option value="<?=intval($a['id'])?>" <?=intval($selected['assigned_admin_id']??0)===intval($a['id'])?'selected':''?>><?=tce((string)$a['name'])?></option><?php endforeach;?></select><button class="btn" type="submit">Assign</button></div></form>
          <form method="post"><input type="hidden" name="csrf" value="<?=tce($csrf)?>"><input type="hidden" name="action" value="priority"><input type="hidden" name="message_id" value="<?=intval($selected['id'])?>"><strong class="small">Priority</strong><div class="stack" style="margin-top:6px"><select class="select" name="priority"><?php foreach(['low','normal','high','urgent'] as $priority):?><option value="<?=$priority?>" <?=$selected['priority']===$priority?'selected':''?>><?=ucfirst($priority)?></option><?php endforeach;?></select><button class="btn" type="submit">Update</button></div></form></div>
          <p class="muted small" style="margin-top:10px">SLA due: <?=tce((string)($selected['sla_due_at']?:'Not set'))?> · <?=tce((string)$selected['match_notes'])?></p><div style="border-top:1px solid #e9eff6;padding-top:10px"><strong class="small">Correct auto-match / link to trip</strong><form method="post" class="tc-fields" style="margin-top:8px"><input type="hidden" name="csrf" value="<?=tce($csrf)?>"><input type="hidden" name="action" value="relink"><input type="hidden" name="message_id" value="<?=intval($selected['id'])?>"><select class="select" name="supplier_id"><option value="0">No supplier</option><?php foreach($suppliers as $supplier):?><option value="<?=intval($supplier['id'])?>" <?=intval($selected['supplier_id']??0)===intval($supplier['id'])?'selected':''?>><?=tce((string)$supplier['company_name'])?></option><?php endforeach;?></select><input class="input" name="supplier_request" value="<?=tce((string)($selected['request_code']?:$selected['supplier_request_id']?:''))?>" placeholder="Supplier request code / ID"><input class="input" name="trip" value="<?=tce((string)($selected['trip_code']?:$selected['trip_id']?:''))?>" placeholder="Trip code / ID"><input class="input" type="number" name="quotation_version_id" value="<?=intval($selected['quotation_version_id']??0)?:''?>" placeholder="Quotation version ID"><input class="input" type="number" name="booking_id" value="<?=intval($selected['booking_id']??0)?:''?>" placeholder="Booking ID"><button class="btn" type="submit"><i class="fa-solid fa-link"></i> Save Link</button></form></div>
        </details>
        <details class="section-card"><summary><i class="fa-solid fa-phone-volume" style="color:#0e997d"></i> Record WhatsApp / phone communication</summary><form method="post" class="tc-fields"><input type="hidden" name="csrf" value="<?=tce($csrf)?>"><input type="hidden" name="action" value="record_external"><input type="hidden" name="message_id" value="<?=intval($selected['id'])?>"><select class="select" name="external_channel"><option value="whatsapp">WhatsApp</option><option value="phone">Phone</option><option value="manual">Other</option></select><select class="select" name="external_direction"><option value="inbound">Received</option><option value="outbound">Sent</option><option value="internal">Internal Note</option></select><textarea style="grid-column:1/-1" name="external_body" rows="3" placeholder="Paste the message or phone-call summary…" required></textarea><button class="btn green" type="submit">Record communication</button></form><p class="muted small" style="margin:8px 0 0">WhatsApp is recorded manually until the official WhatsApp Business API is connected.</p></details>
      </div><?php endif;?>
    </section>
  </div>
</div>
<script>
(function(){
  const html=document.getElementById('tc-html-body'),plain=document.getElementById('tc-text-body');
  const controls=document.querySelectorAll('.tc-mail [data-view]');
  controls.forEach(btn=>btn.addEventListener('click',()=>{
    const visual=btn.getAttribute('data-view')==='html';
    if(html)html.classList.toggle('hidden',!visual);if(plain)plain.classList.toggle('hidden',visual);
    controls.forEach(item=>{const active=item===btn;item.classList.toggle('active',active);item.setAttribute('aria-pressed',active?'true':'false');});
  }));
})();
</script>

<script>
(function(){
  'use strict';
  const form=document.getElementById('tc-reply-form');
  const editor=document.getElementById('tc-rich-editor');
  const fallback=document.getElementById('tc-reply-fallback');
  const htmlField=document.getElementById('tc-reply-html');
  const toolbar=document.getElementById('tc-editor-toolbar');
  const error=document.getElementById('tc-compose-error');
  const source=document.getElementById('tc-source-html');
  if(!form||!editor||!fallback||!htmlField||!toolbar)return;
  fallback.hidden=true;fallback.required=false;editor.hidden=false;toolbar.hidden=false;
  let sourceMode=false;
  const fail=(message)=>{if(error){error.textContent=message;error.hidden=false;}};
  const safeColor=(value)=>/^#[0-9a-f]{3}(?:[0-9a-f]{3})?$/i.test(value)||/^rgb\(\s*(?:[01]?\d?\d|2[0-4]\d|25[0-5])\s*,\s*(?:[01]?\d?\d|2[0-4]\d|25[0-5])\s*,\s*(?:[01]?\d?\d|2[0-4]\d|25[0-5])\s*\)$/i.test(value)||/^(?:black|white|navy|blue|red|green|gray|grey|yellow|orange|purple|teal|silver|maroon)$/i.test(value);
  const allowed=new Set(['P','DIV','BR','STRONG','B','EM','I','U','S','SPAN','UL','OL','LI','BLOCKQUOTE','A','H1','H2','H3','H4','TABLE','CAPTION','THEAD','TBODY','TFOOT','TR','TH','TD','COLGROUP','COL']);
  const blocked=new Set(['SCRIPT','STYLE','IFRAME','OBJECT','EMBED','SVG','MATH','FORM','TEMPLATE','NOSCRIPT','VIDEO','AUDIO','CANVAS','LINK','META']);
  function cleaned(html){
    const template=document.createElement('template');template.innerHTML=html;
    const output=document.createElement('div');
    function walk(node,parent){
      if(node.nodeType===Node.TEXT_NODE){parent.appendChild(document.createTextNode(node.nodeValue));return;}
      if(node.nodeType!==Node.ELEMENT_NODE||blocked.has(node.tagName))return;
      const tag=allowed.has(node.tagName)?node.tagName.toLowerCase():null;
      const holder=tag?document.createElement(tag):parent;
      if(tag){
        if(tag==='a'){
          const href=(node.getAttribute('href')||'').trim();
          if(/^(?:https?:\/\/\S+|mailto:[^\s@]+@[^\s@]+\.[^\s@]+)$/i.test(href))holder.setAttribute('href',href);
          else return Array.from(node.childNodes).forEach(child=>walk(child,parent));
        }
        if(['th','td'].includes(tag))['colspan','rowspan'].forEach(key=>{const val=Number(node.getAttribute(key));if(Number.isInteger(val)&&val>=1&&val<=12)holder.setAttribute(key,String(val));});
        const css=[];
        ['color','background-color'].forEach(key=>{let value=(node.style.getPropertyValue(key)||'').trim();if(!value&&key==='background-color')value=(node.getAttribute('bgcolor')||'').trim();if(safeColor(value))css.push(key+':'+value);});
        const align=node.style.textAlign||node.getAttribute('align')||'';
        if(['left','right','center','justify'].includes(align.toLowerCase()))css.push('text-align:'+align.toLowerCase());
        if(css.length)holder.setAttribute('style',css.join(';'));
        parent.appendChild(holder);
      }
      Array.from(node.childNodes).forEach(child=>walk(child,holder));
    }
    Array.from(template.content.childNodes).forEach(child=>walk(child,output));
    return output.innerHTML;
  }
  // Restore a draft when SMTP delivery or validation failed, without injecting raw HTML.
  const savedDraft=document.getElementById('tc-draft-restore');
  if(savedDraft && savedDraft.value.trim())editor.innerHTML=cleaned(savedDraft.value);
  else if(fallback.value.trim())editor.innerText=fallback.value;
  function insertHtml(html){
    if(sourceMode){source.value+=html;return;}
    editor.focus();document.execCommand('insertHTML',false,html);
  }
  // Preserve safe table and formatting markup copied from spreadsheets and rich emails.
  editor.addEventListener('paste',function(e){
    e.preventDefault();const clipboard=e.clipboardData;
    const rich=clipboard?clipboard.getData('text/html'):'';
    const plain=clipboard?clipboard.getData('text/plain'):'';
    if(rich){insertHtml(cleaned(rich));}else{editor.focus();document.execCommand('insertText',false,plain);}
  });
  function cellAtCaret(){
    const sel=window.getSelection();const node=sel&&sel.anchorNode;
    const element=node&&(node.nodeType===Node.ELEMENT_NODE?node:node.parentElement);
    const cell=element&&element.closest('td,th');return cell&&editor.contains(cell)?cell:null;
  }
  toolbar.addEventListener('mousedown',function(e){if(e.target.closest('button'))e.preventDefault();});
  toolbar.addEventListener('click',function(e){
    const button=e.target.closest('button[data-cmd]');if(!button)return;
    const cmd=button.dataset.cmd;if(error)error.hidden=true;
    if(cmd==='source'){
      if(!source)return;
      if(!sourceMode){source.value=editor.innerHTML;editor.hidden=true;source.hidden=false;source.focus();button.classList.add('active');}
      else{editor.innerHTML=cleaned(source.value);source.hidden=true;editor.hidden=false;editor.focus();button.classList.remove('active');}
      sourceMode=!sourceMode;return;
    }
    if(cmd==='insertTable'){
      const rowsInput=window.prompt('Number of rows (1–12)', '3');if(rowsInput===null)return;
      const colsInput=window.prompt('Number of columns (1–12)', '3');if(colsInput===null)return;
      const rows=Number(rowsInput),cols=Number(colsInput);
      if(!Number.isInteger(rows)||rows<1||rows>12||!Number.isInteger(cols)||cols<1||cols>12){fail('Enter between 1 and 12 rows and columns.');return;}
      let html='<table style="border-collapse:collapse;width:100%;border:1px solid #cbd5e1"><tbody>';
      for(let r=0;r<rows;r++){html+='<tr>';for(let c=0;c<cols;c++)html+='<'+(r===0?'th':'td')+' style="border:1px solid #cbd5e1;padding:7px 9px">&nbsp;</'+(r===0?'th':'td')+'>';html+='</tr>';}
      insertHtml(html+'</tbody></table><p><br></p>');return;
    }
    if(['addRow','addColumn','removeTable'].includes(cmd)){
      if(sourceMode){fail('Switch to the visual editor before changing a table.');return;}
      const cell=cellAtCaret();if(!cell){fail('Click inside a table cell first.');return;}
      const table=cell.closest('table');const tr=cell.closest('tr');if(!table||!tr)return;
      if(cmd==='removeTable'){table.remove();return;}
      if(cmd==='addRow'){
        const newRow=document.createElement('tr');
        Array.from(tr.children).forEach(old=>{if(!['TD','TH'].includes(old.tagName))return;const fresh=document.createElement('td');fresh.innerHTML='&nbsp;';newRow.appendChild(fresh);});
        tr.after(newRow);return;
      }
      if(cmd==='addColumn'){
        Array.from(table.rows).forEach(row=>{const fresh=document.createElement(row.rowIndex===0?'th':'td');fresh.innerHTML='&nbsp;';row.appendChild(fresh);});return;
      }
    }
    editor.focus();
    if(cmd==='createLink'){
      const selection=window.getSelection();if(!selection||selection.isCollapsed){fail('Select text for the link first.');return;}
      const url=window.prompt('Enter a secure URL (https://...)');if(url===null)return;
      if(!/^https?:\/\/\S+$/i.test(url.trim())){fail('Use a complete http:// or https:// URL.');return;}
      document.execCommand('createLink',false,url.trim());
    }else document.execCommand(cmd,false,null);
  });
  form.addEventListener('submit',function(e){
    // HTML source can be pasted in full, but must be normalized before sending.
    if(sourceMode)editor.innerHTML=cleaned(source.value);
    const plain=(editor.innerText||editor.textContent||'').replace(/\u00a0/g,' ').trim();
    if(!plain){e.preventDefault();fail('Write your email or fill a table before sending.');editor.hidden=false;source.hidden=true;editor.focus();return;}
    if(plain.length>20000){e.preventDefault();fail('Email is too long (maximum 20,000 characters).');return;}
    fallback.value=plain;htmlField.value=cleaned(editor.innerHTML);
    if(htmlField.value.length>240000){e.preventDefault();fail('HTML email is too large (maximum 240 KB).');return;}
    if(error)error.hidden=true;
  });
})();
</script>
<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
