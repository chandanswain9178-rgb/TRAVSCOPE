<?php
require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$siteName = 'TRAVSCOPE';
$logo = '';

try {
    $siteName = trim((string)getSetting($pdo, 'site_name', 'TRAVSCOPE')) ?: 'TRAVSCOPE';
    $logo = trim((string)getSetting($pdo, 'site_logo', ''));
} catch (Throwable $e) {
    $logo = '';
}

$logoUrl = '';
if ($logo !== '') {
    if (preg_match('#^https?://#i', $logo)) {
        $logoUrl = $logo;
    } else {
        $relative = ltrim(str_replace('\\', '/', $logo), '/');
        if (!str_contains($relative, '..')) {
            $logoUrl = rtrim((string)BASE_URL, '/') . '/' . $relative;
            $absolute = __DIR__ . '/' . $relative;
            if (is_file($absolute)) {
                $logoUrl .= (str_contains($logoUrl, '?') ? '&' : '?') . 'v=' . rawurlencode((string)filemtime($absolute));
            }
        }
    }
}

echo json_encode([
    'has_logo' => $logoUrl !== '',
    'logo_url' => $logoUrl,
    'site_name' => $siteName,
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
