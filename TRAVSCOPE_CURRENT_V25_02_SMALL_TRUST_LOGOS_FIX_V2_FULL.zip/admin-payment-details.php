<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| ADMIN PAYMENT DETAILS
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';

$billingFunctionsFile = __DIR__ . '/billing-functions.php';
if (is_file($billingFunctionsFile)) {
    require_once $billingFunctionsFile;
}

$accessControlFunctionsFile = __DIR__ . '/access-control-functions.php';
if (is_file($accessControlFunctionsFile)) {
    require_once $accessControlFunctionsFile;
}

requireAdmin();

$admin = currentAdmin($pdo);

if (!$admin) {
    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_mobile'],
        $_SESSION['admin_role']
    );
    redirect(BASE_URL . 'login.php');
}

$siteName = 'TRAVSCOPE.COM';
$currencySymbol = '₹';

try {
    $siteName = getSetting($pdo, 'site_name', 'TRAVSCOPE.COM');
    $currencySymbol = getSetting($pdo, 'currency_symbol', '₹');
} catch (Throwable $e) {
    error_log('Admin payment details settings error: ' . $e->getMessage());
}

$paymentId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($paymentId <= 0) {
    redirect(BASE_URL . 'admin-payments.php');
}

$success = '';
$error = '';

if (!empty($_SESSION['admin_payment_details_success'])) {
    $success = (string)$_SESSION['admin_payment_details_success'];
    unset($_SESSION['admin_payment_details_success']);
}

if (!empty($_SESSION['admin_payment_details_error'])) {
    $error = (string)$_SESSION['admin_payment_details_error'];
    unset($_SESSION['admin_payment_details_error']);
}

/*
|--------------------------------------------------------------------------
| APPROVE / REJECT
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $csrf = $_POST['csrf_token'] ?? '';
    $action = strtolower(trim((string)($_POST['action'] ?? '')));

    if (!verifyCsrf($csrf)) {
        $_SESSION['admin_payment_details_error'] =
            'Security validation failed. Please try again.';

        redirect(
            BASE_URL .
            'admin-payment-details.php?id=' .
            $paymentId
        );
    }

    if (!in_array($action, ['approve', 'reject'], true)) {
        $_SESSION['admin_payment_details_error'] =
            'Invalid payment action.';

        redirect(
            BASE_URL .
            'admin-payment-details.php?id=' .
            $paymentId
        );
    }

    try {
        if (function_exists('tsAclRequire')) {
            tsAclRequire(
                $pdo,
                (int)$admin['id'],
                'record_customer_payment',
                $action === 'approve'
                    ? 'approve_customer_payment'
                    : 'reject_customer_payment',
                'payment',
                $paymentId
            );
        }


        $pdo->beginTransaction();

        $stmt = $pdo->prepare("
            SELECT
                pay.id,
                pay.booking_id,
                pay.amount,
                pay.status AS payment_record_status,
                b.booking_number,
                b.total_amount,
                b.paid_amount,
                b.booking_status,
                b.payment_status,
                b.coupon_id,
                b.coupon_code,
                b.discount_amount
            FROM payments pay
            INNER JOIN bookings b
                ON b.id = pay.booking_id
            WHERE pay.id = ?
            LIMIT 1
            FOR UPDATE
        ");

        $stmt->execute([$paymentId]);
        $lockedPayment = $stmt->fetch();

        if (!$lockedPayment) {
            throw new RuntimeException('Payment record was not found.');
        }

        if (
            strtolower((string)$lockedPayment['payment_record_status'])
            !== 'pending'
        ) {
            throw new RuntimeException(
                'This payment has already been processed.'
            );
        }

        if ($action === 'approve') {

            $paymentAmount = max(
                0,
                (float)$lockedPayment['amount']
            );

            $totalAmount = max(
                0,
                (float)$lockedPayment['total_amount']
            );

            $currentPaid = max(
                0,
                (float)$lockedPayment['paid_amount']
            );

            if ($paymentAmount <= 0) {
                throw new RuntimeException(
                    'Payment amount is invalid.'
                );
            }

            if ($totalAmount <= 0) {
                throw new RuntimeException(
                    'Booking total amount is invalid.'
                );
            }

            $remainingBeforePayment = max(
                0,
                $totalAmount - $currentPaid
            );

            if ($paymentAmount > $remainingBeforePayment) {
                throw new RuntimeException(
                    'This payment amount is greater than the remaining booking balance. Verify the amount before approving.'
                );
            }

            $newPaidAmount =
                $currentPaid + $paymentAmount;

            if ($newPaidAmount >= $totalAmount) {
                $newPaidAmount = $totalAmount;
                $newPaymentStatus = 'paid';
                $newBookingStatus = 'confirmed';
            } else {
                $newPaymentStatus = 'partial';

                if (
                    strtolower(
                        (string)$lockedPayment['booking_status']
                    ) === 'confirmed'
                ) {
                    $newBookingStatus = 'confirmed';
                } else {
                    $newBookingStatus = 'pending';
                }
            }

            $stmt = $pdo->prepare("
                UPDATE payments
                SET
                    status = 'success',
                    paid_at = NOW()
                WHERE
                    id = ?
                    AND status = 'pending'
            ");

            $stmt->execute([$paymentId]);

            if ($stmt->rowCount() !== 1) {
                throw new RuntimeException(
                    'Payment could not be approved because its status changed.'
                );
            }

            $stmt = $pdo->prepare("
                UPDATE bookings
                SET
                    paid_amount = ?,
                    payment_status = ?,
                    booking_status = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $newPaidAmount,
                $newPaymentStatus,
                $newBookingStatus,
                (int)$lockedPayment['booking_id']
            ]);

            if (
                function_exists('tsBillReady')
                && tsBillReady($pdo)
            ) {
                tsBillOnPaymentApproved(
                    $pdo,
                    $paymentId,
                    (int)($admin['id'] ?? 0)
                );
            }


            /*
            |--------------------------------------------------------------------------
            | COUNT COUPON ONCE WHEN BOOKING BECOMES FULLY PAID
            |--------------------------------------------------------------------------
            |
            | The booking/payment rows are locked in this transaction. Coupon usage
            | is incremented only when this approval changes the booking from not
            | fully paid to fully paid.
            |--------------------------------------------------------------------------
            */

            $wasAlreadyFullyPaid =
                strtolower(
                    (string)$lockedPayment['payment_status']
                ) === 'paid'
                || $currentPaid >= $totalAmount;

            $becameFullyPaid =
                $newPaymentStatus === 'paid'
                && $newPaidAmount >= $totalAmount;

            $couponId =
                isset($lockedPayment['coupon_id'])
                ? (int)$lockedPayment['coupon_id']
                : 0;

            $discountAmount =
                isset($lockedPayment['discount_amount'])
                ? max(
                    0,
                    (float)$lockedPayment['discount_amount']
                )
                : 0;

            if (
                !$wasAlreadyFullyPaid
                && $becameFullyPaid
                && $couponId > 0
                && $discountAmount > 0
            ) {

                $stmt = $pdo->prepare("
                    SELECT
                        id,
                        code,
                        usage_limit,
                        used_count
                    FROM coupons
                    WHERE id = ?
                    LIMIT 1
                    FOR UPDATE
                ");

                $stmt->execute([
                    $couponId
                ]);

                $lockedCoupon =
                    $stmt->fetch(
                        PDO::FETCH_ASSOC
                    );

                if (!$lockedCoupon) {
                    throw new RuntimeException(
                        'The coupon attached to this booking no longer exists. Payment approval was cancelled.'
                    );
                }

                if (
                    $lockedCoupon['usage_limit'] !== null
                    && (int)$lockedCoupon['usage_limit'] > 0
                    && (int)$lockedCoupon['used_count']
                        >= (int)$lockedCoupon['usage_limit']
                ) {
                    throw new RuntimeException(
                        'This coupon has reached its usage limit. Payment approval was cancelled so the coupon count stays consistent.'
                    );
                }

                $stmt = $pdo->prepare("
                    UPDATE coupons
                    SET used_count = used_count + 1
                    WHERE id = ?
                ");

                $stmt->execute([
                    $couponId
                ]);

                if ($stmt->rowCount() !== 1) {
                    throw new RuntimeException(
                        'Coupon usage could not be recorded. Payment approval was cancelled.'
                    );
                }
            }

            $pdo->commit();

            $_SESSION['admin_payment_details_success'] =
                'Payment approved successfully for booking ' .
                $lockedPayment['booking_number'] .
                '.';

        } else {

            $stmt = $pdo->prepare("
                UPDATE payments
                SET
                    status = 'failed',
                    paid_at = NULL
                WHERE
                    id = ?
                    AND status = 'pending'
            ");

            $stmt->execute([$paymentId]);

            if ($stmt->rowCount() !== 1) {
                throw new RuntimeException(
                    'Payment could not be rejected because its status changed.'
                );
            }

            $pdo->commit();

            $_SESSION['admin_payment_details_success'] =
                'Payment rejected successfully. The customer can submit another payment.';
        }

    } catch (Throwable $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        error_log(
            'Admin payment details processing error: ' .
            $e->getMessage()
        );

        $_SESSION['admin_payment_details_error'] =
            $e->getMessage();
    }

    redirect(
        BASE_URL .
        'admin-payment-details.php?id=' .
        $paymentId
    );
}

/*
|--------------------------------------------------------------------------
| FETCH PAYMENT
|--------------------------------------------------------------------------
*/

$payment = null;

try {

    $stmt = $pdo->prepare("
        SELECT
            pay.id,
            pay.booking_id,
            pay.transaction_id,
            pay.payment_gateway,
            pay.amount,
            pay.currency,
            pay.payment_method,
            pay.status,
            pay.gateway_response,
            pay.paid_at,
            pay.created_at,

            b.booking_number,
            b.user_id,
            b.package_id,
            b.coupon_id,
            b.coupon_code,
            b.discount_amount,
            b.customer_name,
            b.customer_email,
            b.customer_mobile,
            b.travel_date,
            b.adults,
            b.children,
            b.total_amount,
            b.paid_amount,
            b.currency AS booking_currency,
            b.booking_status,
            b.payment_status,
            b.special_request,
            b.created_at AS booking_created_at,

            p.title AS package_title,
            p.package_code,
            p.duration_days,
            p.duration_nights,
            p.sale_price,
            p.regular_price,

            d.name AS destination_name,
            d.country AS destination_country

        FROM payments pay

        INNER JOIN bookings b
            ON b.id = pay.booking_id

        LEFT JOIN packages p
            ON p.id = b.package_id

        LEFT JOIN destinations d
            ON d.id = p.destination_id

        WHERE pay.id = ?

        LIMIT 1
    ");

    $stmt->execute([$paymentId]);
    $payment = $stmt->fetch();

} catch (Throwable $e) {

    error_log(
        'Admin payment details load error: ' .
        $e->getMessage()
    );

    $error = 'Payment details could not be loaded.';
}

if (!$payment) {
    http_response_code(404);
}

$totalAmount = $payment
    ? max(0, (float)$payment['total_amount'])
    : 0;

$paidAmount = $payment
    ? max(0, (float)$payment['paid_amount'])
    : 0;

$paymentAmount = $payment
    ? max(0, (float)$payment['amount'])
    : 0;

$balanceAmount = max(
    0,
    $totalAmount - $paidAmount
);

$balanceAfterApproval = max(
    0,
    $balanceAmount - $paymentAmount
);

$adminName = trim(
    (string)($admin['name'] ?? 'Admin')
);

if ($adminName === '') {
    $adminName = 'Admin';
}

$adminInitial = strtoupper(
    substr($adminName, 0, 1)
);

$csrfToken = csrfToken();

function paymentStatusClass($status)
{
    switch (strtolower((string)$status)) {
        case 'pending':
            return 'status-pending';
        case 'success':
            return 'status-success';
        case 'failed':
            return 'status-failed';
        case 'refunded':
            return 'status-refunded';
        default:
            return 'status-neutral';
    }
}

function paymentStatusLabel($status)
{
    switch (strtolower((string)$status)) {
        case 'pending':
            return 'Pending Verification';
        case 'success':
            return 'Verified / Successful';
        case 'failed':
            return 'Rejected / Failed';
        case 'refunded':
            return 'Refunded';
        default:
            return ucfirst((string)$status);
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>
<meta name="theme-color" content="#07192d">
<meta name="robots" content="noindex,nofollow">

<title>
Payment Details | <?= e($siteName); ?>
</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>
<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>
<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>
<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>

:root{
    --sidebar:#07192d;
    --primary:#0b74ff;
    --background:#f5f7fb;
    --white:#fff;
    --text:#172033;
    --muted:#778294;
    --border:#e6eaf0;
    --green:#0da66a;
    --orange:#e88b22;
    --red:#e24a5c;
    --purple:#7956d8;
    --shadow:0 8px 30px rgba(23,32,51,.06);
}

*{margin:0;padding:0;box-sizing:border-box}
body{
    font-family:'DM Sans',sans-serif;
    background:var(--background);
    color:var(--text);
}
a{text-decoration:none;color:inherit}
button,input{font-family:inherit}

.sidebar{
    position:fixed;
    top:0;left:0;bottom:0;
    width:265px;
    background:var(--sidebar);
    color:#fff;
    z-index:1100;
    overflow-y:auto;
    transition:.25s ease;
}
.sidebar-logo{
    height:80px;
    padding:0 23px;
    display:flex;
    align-items:center;
    gap:11px;
    border-bottom:1px solid rgba(255,255,255,.08);
    font-family:'Manrope',sans-serif;
    font-size:20px;
    font-weight:800;
}
.logo-icon{
    width:42px;height:42px;
    border-radius:12px;
    display:grid;
    place-items:center;
    background:linear-gradient(135deg,#0b74ff,#00b7ff);
    transform:rotate(-5deg);
}
.sidebar-logo span{color:#63b4ff}
.sidebar-menu{padding:20px 13px 35px}
.menu-title{
    padding:14px 13px 8px;
    color:#647990;
    font-size:10px;
    font-weight:800;
    letter-spacing:1.4px;
}
.menu-link{
    min-height:44px;
    margin:3px 0;
    padding:0 13px;
    border-radius:9px;
    display:flex;
    align-items:center;
    gap:11px;
    color:#9fb0c2;
    font-size:13px;
    font-weight:600;
}
.menu-link i{width:20px;text-align:center}
.menu-link:hover{color:#fff;background:rgba(255,255,255,.06)}
.menu-link.active{
    color:#fff;
    background:linear-gradient(135deg,#0b74ff,#0968e2);
}
.sidebar-overlay{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.42);
    z-index:1050;
    opacity:0;
    visibility:hidden;
}
.sidebar-overlay.show{opacity:1;visibility:visible}

.main{min-height:100vh;margin-left:265px}

.topbar{
    height:80px;
    padding:0 30px;
    position:sticky;
    top:0;
    z-index:900;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:20px;
    background:rgba(255,255,255,.96);
    border-bottom:1px solid var(--border);
}
.topbar-left,.top-actions{
    display:flex;
    align-items:center;
    gap:14px;
}
.mobile-menu{
    width:39px;height:39px;
    border:1px solid var(--border);
    border-radius:9px;
    display:none;
    place-items:center;
    background:#fff;
    cursor:pointer;
}
.topbar-title{
    font-family:'Manrope',sans-serif;
    font-size:15px;
    font-weight:800;
}
.view-site{
    height:38px;
    padding:0 13px;
    border:1px solid var(--border);
    border-radius:8px;
    display:flex;
    align-items:center;
    gap:7px;
    background:#fff;
    color:#657286;
    font-size:11px;
    font-weight:700;
}
.admin-profile{
    padding-left:14px;
    border-left:1px solid var(--border);
    display:flex;
    align-items:center;
    gap:9px;
}
.admin-avatar{
    width:38px;height:38px;
    border-radius:10px;
    display:grid;
    place-items:center;
    background:linear-gradient(135deg,var(--primary),#00a6ff);
    color:#fff;
    font-weight:800;
}
.admin-info strong{display:block;font-size:11px}
.admin-info span{display:block;margin-top:2px;color:var(--muted);font-size:9px}

.content{padding:30px;max-width:1450px;margin:0 auto}

.breadcrumbs{
    margin-bottom:15px;
    display:flex;
    align-items:center;
    gap:8px;
    color:#8994a3;
    font-size:10px;
}
.breadcrumbs a:hover{color:var(--primary)}

.page-heading{
    margin-bottom:22px;
    display:flex;
    justify-content:space-between;
    gap:20px;
    align-items:flex-start;
}
.page-heading h1{
    font-family:'Manrope',sans-serif;
    font-size:28px;
}
.page-heading p{
    margin-top:5px;
    color:var(--muted);
    font-size:11px;
}
.heading-actions{
    display:flex;
    gap:8px;
    flex-wrap:wrap;
}
.btn{
    min-height:38px;
    padding:0 13px;
    border:1px solid var(--border);
    border-radius:8px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:7px;
    background:#fff;
    color:#5d697b;
    font-size:10px;
    font-weight:800;
    cursor:pointer;
}
.btn-primary{
    border-color:var(--primary);
    background:var(--primary);
    color:#fff;
}

.alert{
    margin-bottom:20px;
    padding:13px 15px;
    border-radius:9px;
    display:flex;
    gap:9px;
    font-size:11px;
    line-height:1.5;
}
.alert-success{
    border:1px solid #bfe9d7;
    background:#edfaf5;
    color:#087a50;
}
.alert-error{
    border:1px solid #f0c3c9;
    background:#fff0f2;
    color:#b22e41;
}

.status{
    min-height:28px;
    padding:0 10px;
    border-radius:20px;
    display:inline-flex;
    align-items:center;
    font-size:9px;
    font-weight:800;
    text-transform:uppercase;
}
.status-pending{background:#fff4e4;color:#b66b08}
.status-success{background:#e9f9f2;color:#078454}
.status-failed{background:#ffedef;color:#c63248}
.status-refunded{background:#f0edff;color:#6848c7}
.status-neutral{background:#eef1f5;color:#667085}

.summary-grid{
    margin-bottom:20px;
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:14px;
}
.summary-card{
    padding:18px;
    border:1px solid var(--border);
    border-radius:12px;
    background:#fff;
    box-shadow:var(--shadow);
}
.summary-label{
    color:var(--muted);
    font-size:9px;
    font-weight:800;
    letter-spacing:.5px;
}
.summary-value{
    margin-top:7px;
    font-family:'Manrope',sans-serif;
    font-size:20px;
    font-weight:800;
}
.summary-sub{
    margin-top:4px;
    color:#8994a3;
    font-size:9px;
}

.layout{
    display:grid;
    grid-template-columns:minmax(0,1.45fr) minmax(320px,.75fr);
    gap:20px;
    align-items:start;
}
.card{
    margin-bottom:20px;
    border:1px solid var(--border);
    border-radius:12px;
    background:#fff;
    box-shadow:var(--shadow);
    overflow:hidden;
}
.card-header{
    padding:16px 18px;
    border-bottom:1px solid var(--border);
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
}
.card-header h2{
    font-family:'Manrope',sans-serif;
    font-size:14px;
}
.card-body{padding:18px}

.details-grid{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:16px 22px;
}
.detail.full{grid-column:1/-1}
.detail-label{
    margin-bottom:5px;
    color:#8a95a4;
    font-size:9px;
    font-weight:800;
    text-transform:uppercase;
    letter-spacing:.5px;
}
.detail-value{
    color:#263244;
    font-size:11px;
    font-weight:700;
    line-height:1.55;
    word-break:break-word;
}
.detail-value.mono{
    font-family:monospace;
    font-size:12px;
}
.muted{color:var(--muted);font-weight:500}

.gateway-response{
    max-height:280px;
    overflow:auto;
    padding:13px;
    border:1px solid var(--border);
    border-radius:8px;
    background:#f8fafc;
    color:#475467;
    white-space:pre-wrap;
    word-break:break-word;
    font-family:monospace;
    font-size:10px;
    line-height:1.55;
}

.money-list{display:grid;gap:11px}
.money-row{
    display:flex;
    justify-content:space-between;
    gap:15px;
    padding-bottom:10px;
    border-bottom:1px solid #edf0f3;
    font-size:10px;
}
.money-row:last-child{
    border-bottom:0;
    padding-bottom:0;
}
.money-row span{color:var(--muted)}
.money-row strong{
    font-family:'Manrope',sans-serif;
    font-size:11px;
}
.money-row.highlight{
    padding:11px;
    border:0;
    border-radius:8px;
    background:#f0f6ff;
}
.money-row.highlight strong{color:var(--primary)}

.verify-box{
    padding:15px;
    border:1px solid #f0d8b4;
    border-radius:10px;
    background:#fff9ef;
}
.verify-box h3{
    margin-bottom:7px;
    font-family:'Manrope',sans-serif;
    font-size:13px;
}
.verify-box p{
    color:#7d6a4c;
    font-size:10px;
    line-height:1.6;
}
.action-grid{
    margin-top:13px;
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:8px;
}
.action-btn{
    min-height:40px;
    border:0;
    border-radius:8px;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:7px;
    font-size:10px;
    font-weight:800;
    cursor:pointer;
}
.approve{background:#0da66a;color:#fff}
.reject{background:#e24a5c;color:#fff}

.not-found{
    padding:80px 20px;
    text-align:center;
}
.not-found i{
    margin-bottom:14px;
    color:#a5adba;
    font-size:40px;
}
.not-found h2{
    font-family:'Manrope',sans-serif;
    font-size:20px;
}
.not-found p{
    margin:7px 0 18px;
    color:var(--muted);
    font-size:11px;
}

@media(max-width:1100px){
    .summary-grid{grid-template-columns:repeat(2,1fr)}
    .layout{grid-template-columns:1fr}
}
@media(max-width:850px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main{margin-left:0}
    .mobile-menu{display:grid}
    .content{padding:20px}
}
@media(max-width:600px){
    .topbar{height:68px;padding:0 13px}
    .topbar-title,.admin-info,.view-site span{display:none}
    .admin-profile{padding-left:0;border:0}
    .content{padding:16px 12px 40px}
    .page-heading{flex-direction:column}
    .page-heading h1{font-size:23px}
    .summary-grid{grid-template-columns:1fr}
    .details-grid{grid-template-columns:1fr}
    .detail.full{grid-column:auto}
    .action-grid{grid-template-columns:1fr}
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
}
.main > .content,
.main .content:first-child{
    width:auto!important;
    max-width:none!important;
    margin:0!important;
    padding:16px 18px 20px!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<style id="ts-payment-compact-v2439">
/* Page-scoped redesign: do not alter the shared sidebar or other admin screens. */
#tsPaymentDetailsPage{padding:13px 14px 20px!important;max-width:none!important;width:100%!important;}
#tsPaymentDetailsPage .breadcrumbs{margin:0 0 8px!important;font-size:11px!important;gap:6px!important;}
#tsPaymentDetailsPage .page-heading{margin:0 0 11px!important;padding:13px 16px!important;align-items:center!important;border:1px solid #dce6f1!important;border-left:4px solid #2277e8!important;border-radius:12px!important;background:linear-gradient(110deg,#fff 60%,#eef6ff)!important;box-shadow:0 6px 18px rgba(18,47,89,.035)!important;}
#tsPaymentDetailsPage .page-heading h1{font-size:21px!important;line-height:1.16!important;color:#112d51!important;margin:0!important;}
#tsPaymentDetailsPage .page-heading p{font-size:10.5px!important;line-height:1.35!important;margin:4px 0 0!important;}
#tsPaymentDetailsPage .heading-actions .btn{min-height:33px!important;padding:0 12px!important;font-size:11px!important;}
#tsPaymentDetailsPage .alert{margin-bottom:10px!important;padding:9px 12px!important;}
#tsPaymentDetailsPage .summary-grid{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:10px!important;margin:0 0 11px!important;}
#tsPaymentDetailsPage .summary-card{position:relative;min-width:0!important;margin:0!important;padding:11px 13px!important;min-height:77px!important;border-radius:11px!important;border:1px solid #dce6f1!important;box-shadow:0 4px 13px rgba(19,53,93,.035)!important;}
#tsPaymentDetailsPage .summary-card::before{content:"";position:absolute;left:0;top:11px;bottom:11px;width:3px;border-radius:0 3px 3px 0;background:#2878ef;}
#tsPaymentDetailsPage .summary-card:nth-child(2)::before{background:#8953d9;}
#tsPaymentDetailsPage .summary-card:nth-child(3)::before{background:#08a978;}
#tsPaymentDetailsPage .summary-card:nth-child(4)::before{background:#e69227;}
#tsPaymentDetailsPage .summary-label{font-size:9px!important;color:#63758e!important;letter-spacing:.55px!important;}
#tsPaymentDetailsPage .summary-value{font-size:18px!important;line-height:1.25!important;margin:3px 0!important;color:#102b50!important;white-space:normal!important;overflow-wrap:anywhere!important;}
#tsPaymentDetailsPage .summary-sub{font-size:9px!important;margin:1px 0 0!important;line-height:1.25!important;}
/* Three-column desktop layout so every routine block appears together. */
#tsPaymentDetailsPage .payment-detail-layout{display:grid!important;grid-template-columns:minmax(0,.98fr) minmax(0,1.16fr) minmax(290px,.85fr)!important;grid-template-areas:"transaction customer sidebar" "package package sidebar"!important;align-items:start!important;gap:11px!important;width:100%!important;min-width:0!important;margin:0!important;}
#tsPaymentDetailsPage .payment-detail-main{display:contents!important;}
#tsPaymentDetailsPage .payment-transaction{grid-area:transaction!important;}
#tsPaymentDetailsPage .payment-customer{grid-area:customer!important;}
#tsPaymentDetailsPage .payment-package{grid-area:package!important;}
#tsPaymentDetailsPage .payment-detail-aside{grid-area:sidebar!important;display:flex!important;flex-direction:column!important;gap:10px!important;min-width:0!important;margin:0!important;padding:0!important;position:static!important;background:none!important;box-shadow:none!important;}
#tsPaymentDetailsPage .payment-detail-layout .card{margin:0!important;border-radius:11px!important;border:1px solid #dce5ef!important;box-shadow:0 4px 13px rgba(17,45,81,.04)!important;min-width:0!important;}
#tsPaymentDetailsPage .payment-detail-layout .card-header{padding:9px 12px!important;min-height:39px!important;border-bottom:1px solid #e5edf5!important;background:#f8fbff!important;}
#tsPaymentDetailsPage .payment-detail-layout .card-header h2{font-size:12px!important;line-height:1.3!important;color:#17375e!important;margin:0!important;}
#tsPaymentDetailsPage .payment-detail-layout .card-header h2 i{margin-right:6px;color:#2573df;}
#tsPaymentDetailsPage .payment-detail-layout .card-body{padding:11px 12px!important;}
#tsPaymentDetailsPage .details-grid{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:9px 12px!important;}
#tsPaymentDetailsPage .detail{min-width:0!important;margin:0!important;padding:0!important;}
#tsPaymentDetailsPage .detail.full{grid-column:1 / -1!important;}
#tsPaymentDetailsPage .detail-label{font-size:9px!important;margin:0 0 2px!important;letter-spacing:.4px!important;line-height:1.3!important;color:#647995!important;}
#tsPaymentDetailsPage .detail-value{font-size:11px!important;line-height:1.37!important;color:#223f63!important;}
#tsPaymentDetailsPage .detail-value.mono{font-size:11px!important;overflow-wrap:anywhere!important;}
#tsPaymentDetailsPage .status{min-height:23px!important;padding:0 9px!important;font-size:9px!important;}
#tsPaymentDetailsPage .payment-raw-details{border:1px solid #e4eaf2;border-radius:8px;background:#f9fbff;}
#tsPaymentDetailsPage .payment-raw-details>summary{list-style:none;display:flex;align-items:center;gap:7px;min-height:30px;cursor:pointer;padding:6px 9px;color:#375676;font-weight:800;font-size:10px;}
#tsPaymentDetailsPage .payment-raw-details>summary::-webkit-details-marker{display:none;}
#tsPaymentDetailsPage .payment-raw-caption{color:#8091a6;font-weight:500;margin-left:auto;font-size:9px;}
#tsPaymentDetailsPage .payment-raw-arrow{font-size:9px;transition:transform .15s;}
#tsPaymentDetailsPage .payment-raw-details[open] .payment-raw-arrow{transform:rotate(180deg);}
#tsPaymentDetailsPage .gateway-response{border:0!important;border-top:1px solid #e3ebf5!important;border-radius:0!important;background:#fff!important;margin:0!important;padding:9px!important;max-height:130px!important;font-size:10px!important;}
#tsPaymentDetailsPage .payment-raw-empty{padding:9px;}
#tsPaymentDetailsPage .payment-summary .money-list{gap:0!important;}
#tsPaymentDetailsPage .payment-summary .money-row{font-size:10px!important;line-height:1.3!important;padding:8px 0!important;align-items:center!important;}
#tsPaymentDetailsPage .payment-summary .money-row strong{font-size:11px!important;color:#213958!important;white-space:nowrap!important;}
#tsPaymentDetailsPage .payment-summary .money-row.highlight{padding:9px!important;margin:4px 0!important;}
#tsPaymentDetailsPage .payment-summary .money-row.highlight strong{color:#2168d2!important;}
#tsPaymentDetailsPage .payment-action .card-body{padding:10px 12px!important;}
#tsPaymentDetailsPage .payment-action .verify-box{padding:10px!important;border-radius:8px!important;}
#tsPaymentDetailsPage .payment-action .verify-box h3{font-size:11px!important;margin:0 0 5px!important;}
#tsPaymentDetailsPage .payment-action .verify-box p{font-size:10px!important;line-height:1.45!important;}
#tsPaymentDetailsPage .payment-action .action-grid{margin-top:9px!important;gap:7px!important;}
#tsPaymentDetailsPage .payment-action .action-btn{min-height:34px!important;font-size:10px!important;}
@media(max-width:1370px){#tsPaymentDetailsPage .payment-detail-layout{grid-template-columns:minmax(0,1fr) minmax(0,1fr)!important;grid-template-areas:"transaction customer" "package sidebar"!important;}}
@media(max-width:1000px){#tsPaymentDetailsPage .payment-detail-layout{grid-template-columns:minmax(0,1fr) minmax(0,1fr)!important;grid-template-areas:"transaction customer" "package sidebar"!important;}#tsPaymentDetailsPage .summary-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;}}
@media(max-width:700px){#tsPaymentDetailsPage{padding:10px!important;}#tsPaymentDetailsPage .page-heading{flex-direction:column!important;align-items:stretch!important;gap:9px!important;}#tsPaymentDetailsPage .summary-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:7px!important;}#tsPaymentDetailsPage .summary-card{padding:10px!important;}#tsPaymentDetailsPage .summary-value{font-size:15px!important;}#tsPaymentDetailsPage .payment-detail-layout{grid-template-columns:minmax(0,1fr)!important;grid-template-areas:"transaction" "customer" "package" "sidebar"!important;}#tsPaymentDetailsPage .details-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;}}
@media(max-width:400px){#tsPaymentDetailsPage .summary-grid{grid-template-columns:1fr!important;}#tsPaymentDetailsPage .details-grid{grid-template-columns:1fr!important;}#tsPaymentDetailsPage .detail.full{grid-column:auto!important;}}
</style>


<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>

<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->








<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->



<main class="main">

<header class="topbar">

    <div class="topbar-left">

        

        <div class="topbar-title">
            TRAVSCOPE Administration
        </div>

    </div>

    <div class="top-actions">

        <a
            href="<?= e(BASE_URL); ?>"
            target="_blank"
            class="view-site"
        >
            <i class="fa-solid fa-arrow-up-right-from-square"></i>
            <span>View Website</span>
        </a>

        <div class="admin-profile">

            <div class="admin-avatar">
                <?= e($adminInitial); ?>
            </div>

            <div class="admin-info">
                <strong><?= e($adminName); ?></strong>
                <span>
                    <?= e(
                        ucwords(
                            str_replace(
                                '_',
                                ' ',
                                (string)($admin['role'] ?? 'admin')
                            )
                        )
                    ); ?>
                </span>
            </div>

        </div>

    </div>

</header>

<div class="content ts-payment-details-page" id="tsPaymentDetailsPage">

    <div class="breadcrumbs">
        <a href="admin-dashboard.php">Dashboard</a>
        <i class="fa-solid fa-angle-right"></i>
        <a href="admin-payments.php">Payments</a>
        <i class="fa-solid fa-angle-right"></i>
        <span>Payment #<?= (int)$paymentId; ?></span>
    </div>

    <?php if (!$payment): ?>

        <?php if ($error !== ''): ?>
            <div class="alert alert-error">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <div><?= e($error); ?></div>
            </div>
        <?php endif; ?>

        <section class="card">
            <div class="not-found">
                <i class="fa-regular fa-credit-card"></i>
                <h2>Payment not found</h2>
                <p>
                    The requested payment does not exist or could not be loaded.
                </p>
                <a href="admin-payments.php" class="btn btn-primary">
                    <i class="fa-solid fa-arrow-left"></i>
                    Back to Payments
                </a>
            </div>
        </section>

    <?php else: ?>

        <div class="page-heading">

            <div>
                <h1>
                    Payment #<?= (int)$payment['id']; ?>
                </h1>
                <p>
                    <?= $payment['status'] === 'pending' ? 'Review the transaction before approval.' : 'Transaction and booking record with payment status.'; ?>
                </p>
            </div>

            <div class="heading-actions">

                <a
                    href="admin-booking-details.php?id=<?= (int)$payment['booking_id']; ?>"
                    class="btn btn-primary"
                >
                    <i class="fa-solid fa-calendar-check"></i>
                    View Booking
                </a>

                <a
                    href="admin-payments.php"
                    class="btn"
                >
                    <i class="fa-solid fa-arrow-left"></i>
                    Payments
                </a>

            </div>

        </div>

        <?php if ($success !== ''): ?>

            <div class="alert alert-success">
                <i class="fa-solid fa-circle-check"></i>
                <div><?= e($success); ?></div>
            </div>

        <?php endif; ?>

        <?php if ($error !== ''): ?>

            <div class="alert alert-error">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <div><?= e($error); ?></div>
            </div>

        <?php endif; ?>

        <section class="summary-grid">

            <div class="summary-card">
                <div class="summary-label">PAYMENT AMOUNT</div>
                <div class="summary-value">
                    <?= e($currencySymbol); ?>
                    <?= number_format($paymentAmount, 2); ?>
                </div>
                <div class="summary-sub">
                    Submitted for verification
                </div>
            </div>

            <div class="summary-card">
                <div class="summary-label">BOOKING TOTAL</div>
                <div class="summary-value">
                    <?= e($currencySymbol); ?>
                    <?= number_format($totalAmount, 2); ?>
                </div>
                <div class="summary-sub">
                    <?= e($payment['booking_number']); ?>
                </div>
            </div>

            <div class="summary-card">
                <div class="summary-label">CURRENTLY PAID</div>
                <div class="summary-value">
                    <?= e($currencySymbol); ?>
                    <?= number_format($paidAmount, 2); ?>
                </div>
                <div class="summary-sub">
                    Verified booking payments
                </div>
            </div>

            <div class="summary-card">
                <div class="summary-label">CURRENT BALANCE</div>
                <div class="summary-value">
                    <?= e($currencySymbol); ?>
                    <?= number_format($balanceAmount, 2); ?>
                </div>
                <div class="summary-sub">
                    <?php if ($payment['status'] === 'pending'): ?>
                        After approval:
                        <?= e($currencySymbol); ?>
                        <?= number_format($balanceAfterApproval, 2); ?>
                    <?php else: ?>
                        Remaining booking balance
                    <?php endif; ?>
                </div>
            </div>

        </section>

        <div class="payment-detail-layout">

            <div class="payment-detail-main">

                <section class="card payment-transaction">

                    <div class="card-header">
                        <h2>
                            <i class="fa-solid fa-money-check-dollar"></i>
                            Transaction Details
                        </h2>

                        <span
                            class="status <?= e(paymentStatusClass($payment['status'])); ?>"
                        >
                            <?= e(paymentStatusLabel($payment['status'])); ?>
                        </span>
                    </div>

                    <div class="card-body">

                        <div class="details-grid">

                            <div class="detail">
                                <div class="detail-label">
                                    Transaction / UTR
                                </div>
                                <div class="detail-value mono">
                                    <?= e(
                                        $payment['transaction_id']
                                        ?: 'Not provided'
                                    ); ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Payment Method
                                </div>
                                <div class="detail-value">
                                    <?= e(
                                        $payment['payment_method']
                                        ?: 'Not specified'
                                    ); ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Gateway
                                </div>
                                <div class="detail-value">
                                    <?= e(
                                        $payment['payment_gateway']
                                        ?: 'Manual / Not specified'
                                    ); ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Currency
                                </div>
                                <div class="detail-value">
                                    <?= e($payment['currency']); ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Submitted
                                </div>
                                <div class="detail-value">
                                    <?= date(
                                        'd M Y, h:i A',
                                        strtotime($payment['created_at'])
                                    ); ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Verified / Paid At
                                </div>
                                <div class="detail-value">
                                    <?php if (!empty($payment['paid_at'])): ?>
                                        <?= date(
                                            'd M Y, h:i A',
                                            strtotime($payment['paid_at'])
                                        ); ?>
                                    <?php else: ?>
                                        <span class="muted">
                                            Not verified yet
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="detail full payment-technical">
                                <details class="payment-raw-details">
                                    <summary><i class="fa-solid fa-code"></i> Gateway response <span class="payment-raw-caption">Technical record · Click to view</span><i class="fa-solid fa-chevron-down payment-raw-arrow"></i></summary>
                                    <?php if (
                                        trim(
                                            (string)$payment['gateway_response']
                                        ) !== ''
                                    ): ?>
                                        <div class="gateway-response"><?= e(
                                            $payment['gateway_response']
                                        ); ?></div>
                                    <?php else: ?>
                                        <div class="detail-value muted payment-raw-empty">No gateway response was stored for this payment.</div>
                                    <?php endif; ?>
                                </details>
                            </div>

                        </div>

                    </div>

                </section>

                <section class="card payment-customer">

                    <div class="card-header">
                        <h2>
                            <i class="fa-solid fa-calendar-check"></i>
                            Booking & Customer
                        </h2>
                    </div>

                    <div class="card-body">

                        <div class="details-grid">

                            <div class="detail">
                                <div class="detail-label">
                                    Booking Number
                                </div>
                                <div class="detail-value">
                                    <?= e($payment['booking_number']); ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Booking Status
                                </div>
                                <div class="detail-value">
                                    <?= e(
                                        ucfirst(
                                            (string)$payment['booking_status']
                                        )
                                    ); ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Customer
                                </div>
                                <div class="detail-value">
                                    <?= e($payment['customer_name']); ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Email
                                </div>
                                <div class="detail-value">
                                    <?= e($payment['customer_email']); ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Mobile
                                </div>
                                <div class="detail-value">
                                    <?= e($payment['customer_mobile']); ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Travel Date
                                </div>
                                <div class="detail-value">
                                    <?php if (!empty($payment['travel_date'])): ?>
                                        <?= date(
                                            'd M Y',
                                            strtotime($payment['travel_date'])
                                        ); ?>
                                    <?php else: ?>
                                        <span class="muted">
                                            Not selected
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Travellers
                                </div>
                                <div class="detail-value">
                                    <?= (int)$payment['adults']; ?> Adult(s),
                                    <?= (int)$payment['children']; ?> Child(ren)
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Coupon
                                </div>
                                <div class="detail-value">
                                    <?php if (
                                        !empty($payment['coupon_id'])
                                        && !empty($payment['coupon_code'])
                                    ): ?>
                                        <?= e($payment['coupon_code']); ?>
                                    <?php else: ?>
                                        <span class="muted">
                                            No coupon
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Coupon Discount
                                </div>
                                <div class="detail-value">
                                    <?php if (
                                        (float)$payment['discount_amount'] > 0
                                    ): ?>
                                        <?= e($currencySymbol); ?>
                                        <?= number_format(
                                            (float)$payment['discount_amount'],
                                            2
                                        ); ?>
                                    <?php else: ?>
                                        <span class="muted">
                                            No discount
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Booking Payment Status
                                </div>
                                <div class="detail-value">
                                    <?= e(
                                        ucfirst(
                                            (string)$payment['payment_status']
                                        )
                                    ); ?>
                                </div>
                            </div>

                        </div>

                    </div>

                </section>

                <section class="card payment-package">

                    <div class="card-header">
                        <h2>
                            <i class="fa-solid fa-suitcase-rolling"></i>
                            Package
                        </h2>
                    </div>

                    <div class="card-body">

                        <div class="details-grid">

                            <div class="detail full">
                                <div class="detail-label">
                                    Package
                                </div>
                                <div class="detail-value">
                                    <?= e(
                                        $payment['package_title']
                                        ?: 'Package unavailable'
                                    ); ?>

                                    <?php if (
                                        !empty($payment['package_code'])
                                    ): ?>
                                        <span class="muted">
                                            (<?= e($payment['package_code']); ?>)
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Destination
                                </div>
                                <div class="detail-value">
                                    <?= e(
                                        $payment['destination_name']
                                        ?: 'Not available'
                                    ); ?>

                                    <?php if (
                                        !empty($payment['destination_country'])
                                    ): ?>
                                        <span class="muted">
                                            · <?= e($payment['destination_country']); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="detail">
                                <div class="detail-label">
                                    Duration
                                </div>
                                <div class="detail-value">
                                    <?php if ($payment['package_id']): ?>
                                        <?= (int)$payment['duration_days']; ?>
                                        Day(s) /
                                        <?= (int)$payment['duration_nights']; ?>
                                        Night(s)
                                    <?php else: ?>
                                        <span class="muted">
                                            Not available
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>

                    </div>

                </section>

            </div>

            <aside class="payment-detail-aside">

                <section class="card payment-summary">

                    <div class="card-header">
                        <h2>
                            Payment Summary
                        </h2>
                    </div>

                    <div class="card-body">

                        <div class="money-list">

                            <div class="money-row">
                                <span>Booking Total</span>
                                <strong>
                                    <?= e($currencySymbol); ?>
                                    <?= number_format($totalAmount, 2); ?>
                                </strong>
                            </div>

                            <div class="money-row">
                                <span>Already Verified</span>
                                <strong>
                                    <?= e($currencySymbol); ?>
                                    <?= number_format($paidAmount, 2); ?>
                                </strong>
                            </div>

                            <div class="money-row highlight">
                                <span>This Submission</span>
                                <strong>
                                    <?= e($currencySymbol); ?>
                                    <?= number_format($paymentAmount, 2); ?>
                                </strong>
                            </div>

                            <div class="money-row">
                                <span>Current Balance</span>
                                <strong>
                                    <?= e($currencySymbol); ?>
                                    <?= number_format($balanceAmount, 2); ?>
                                </strong>
                            </div>

                            <?php if ($payment['status'] === 'pending'): ?>

                                <div class="money-row">
                                    <span>Balance After Approval</span>
                                    <strong>
                                        <?= e($currencySymbol); ?>
                                        <?= number_format(
                                            $balanceAfterApproval,
                                            2
                                        ); ?>
                                    </strong>
                                </div>

                            <?php endif; ?>

                        </div>

                    </div>

                </section>

                <?php if ($payment['status'] === 'pending'): ?>

                    <section class="card payment-action">

                        <div class="card-body">

                            <div class="verify-box">

                                <h3>
                                    <i class="fa-solid fa-shield-halved"></i>
                                    Verify Before Approval
                                </h3>

                                <p>
                                    Confirm the UTR/transaction reference and amount in your actual bank or UPI account before approving. Approval will add this amount to the booking's paid amount.
                                </p>

                                <div class="action-grid">

                                    <form
                                        method="post"
                                        class="approve-form"
                                    >
                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= e($csrfToken); ?>"
                                        >
                                        <input
                                            type="hidden"
                                            name="action"
                                            value="approve"
                                        >

                                        <button
                                            type="submit"
                                            class="action-btn approve"
                                        >
                                            <i class="fa-solid fa-check"></i>
                                            Approve
                                        </button>
                                    </form>

                                    <form
                                        method="post"
                                        class="reject-form"
                                    >
                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= e($csrfToken); ?>"
                                        >
                                        <input
                                            type="hidden"
                                            name="action"
                                            value="reject"
                                        >

                                        <button
                                            type="submit"
                                            class="action-btn reject"
                                        >
                                            <i class="fa-solid fa-xmark"></i>
                                            Reject
                                        </button>
                                    </form>

                                </div>

                            </div>

                        </div>

                    </section>

                <?php else: ?>

                    <section class="card payment-action">

                        <div class="card-header">
                            <h2>Processing Status</h2>
                        </div>

                        <div class="card-body">

                            <span
                                class="status <?= e(paymentStatusClass($payment['status'])); ?>"
                            >
                                <?= e(paymentStatusLabel($payment['status'])); ?>
                            </span>

                            <?php if (!empty($payment['paid_at'])): ?>

                                <div
                                    style="
                                        margin-top:10px;
                                        color:#778294;
                                        font-size:10px;
                                        line-height:1.6;
                                    "
                                >
                                    Processed on
                                    <?= date(
                                        'd M Y, h:i A',
                                        strtotime($payment['paid_at'])
                                    ); ?>.
                                </div>

                            <?php endif; ?>

                        </div>

                    </section>

                <?php endif; ?>

            </aside>

        </div>

    <?php endif; ?>

</div>

</main>

<script>

const sidebar =
    document.getElementById('sidebar');

const mobileMenu =
    document.getElementById('mobileMenu');

const sidebarOverlay =
    document.getElementById('sidebarOverlay');

function openSidebar() {
    sidebar.classList.add('open');
    sidebarOverlay.classList.add('show');
}

function closeSidebar() {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('show');
}

if (mobileMenu) {
    mobileMenu.addEventListener('click', function () {
        if (sidebar.classList.contains('open')) {
            closeSidebar();
        } else {
            openSidebar();
        }
    });
}

if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', closeSidebar);
}

window.addEventListener('resize', function () {
    if (window.innerWidth > 850) {
        closeSidebar();
    }
});

document
.querySelectorAll('.approve-form')
.forEach(function (form) {

    form.addEventListener('submit', function (event) {

        const confirmed = confirm(
            'Have you verified this transaction in your bank/UPI account?\n\nApprove only if the payment has actually been received.'
        );

        if (!confirmed) {
            event.preventDefault();
            return;
        }

        const button =
            form.querySelector('button');

        if (button) {
            button.disabled = true;
            button.innerHTML =
                '<i class="fa-solid fa-spinner fa-spin"></i> Approving...';
        }
    });
});

document
.querySelectorAll('.reject-form')
.forEach(function (form) {

    form.addEventListener('submit', function (event) {

        const confirmed = confirm(
            'Reject this payment submission?\n\nThe customer can submit another payment afterward.'
        );

        if (!confirmed) {
            event.preventDefault();
            return;
        }

        const button =
            form.querySelector('button');

        if (button) {
            button.disabled = true;
            button.innerHTML =
                '<i class="fa-solid fa-spinner fa-spin"></i> Rejecting...';
        }
    });
});

</script>







<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
