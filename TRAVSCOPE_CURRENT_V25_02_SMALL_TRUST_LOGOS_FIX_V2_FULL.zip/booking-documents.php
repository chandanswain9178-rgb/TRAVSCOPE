<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/document-functions.php';

requireLogin();

$user =
    currentUser($pdo);

if (!$user) {
    unset($_SESSION['user_id']);
    redirect(BASE_URL . 'login.php');
}

$userId =
    (int)$user['id'];

$bookingId =
    max(
        0,
        (int)(
            $_GET['booking']
            ?? $_POST['booking_id']
            ?? 0
        )
    );

if ($bookingId <= 0) {
    redirect(
        BASE_URL . 'my-bookings.php'
    );
}

if (!tsDocReady($pdo)) {
    http_response_code(503);
    exit(
        'Traveller Document Center is not installed yet.'
    );
}

$booking =
    tsDocBooking(
        $pdo,
        $bookingId
    );

if (
    (int)(
        $booking['user_id']
        ?? 0
    ) !== $userId
) {
    http_response_code(403);
    exit(
        'You do not have permission to access this Booking Document Center.'
    );
}

$error = '';
$success = '';

if (!empty($_SESSION['booking_documents_success'])) {
    $success =
        (string)$_SESSION['booking_documents_success'];

    unset(
        $_SESSION['booking_documents_success']
    );
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (
            !verifyCsrf(
                (string)(
                    $_POST['csrf_token']
                    ?? ''
                )
            )
        ) {
            throw new RuntimeException(
                'Security verification failed. Refresh and try again.'
            );
        }

        $action =
            (string)(
                $_POST['action']
                ?? ''
            );

        if ($action === 'add_traveller') {
            $traveller =
                tsDocAddTraveller(
                    $pdo,
                    $bookingId,
                    $userId,
                    'customer',
                    $userId,
                    null,
                    $_POST
                );

            $_SESSION['booking_documents_success'] =
                (string)$traveller['full_name']
                . ' added to your Booking traveller roster.';

        } elseif ($action === 'upload_document') {
            $document =
                tsDocAddUploadedDocument(
                    $pdo,
                    $bookingId,
                    'customer_upload',
                    $userId,
                    null,
                    $_POST,
                    $_FILES['document_file']
                    ?? []
                );

            $_SESSION['booking_documents_success'] =
                (string)$document['document_type']
                . ' uploaded for TRAVSCOPE verification.';

        } elseif ($action === 'import_vault_document') {
            $document =
                tsDocImportVaultDocument(
                    $pdo,
                    $bookingId,
                    max(
                        0,
                        (int)(
                            $_POST['traveller_id']
                            ?? 0
                        )
                    ),
                    max(
                        0,
                        (int)(
                            $_POST['profile_document_id']
                            ?? 0
                        )
                    ),
                    $userId,
                    null
                );

            $_SESSION['booking_documents_success'] =
                (string)$document['document_type']
                . ' copied from your Profile Vault into this Booking.';

        } elseif ($action === 'archive_document') {
            tsDocArchiveDocument(
                $pdo,
                $bookingId,
                max(
                    0,
                    (int)(
                        $_POST['document_id']
                        ?? 0
                    )
                ),
                $userId
            );

            $_SESSION['booking_documents_success'] =
                'Document removed from your active Booking upload list.';

        } else {
            throw new RuntimeException(
                'Invalid Booking document action.'
            );
        }

        redirect(
            BASE_URL
            . 'booking-documents.php?booking='
            . $bookingId
        );

    } catch (RuntimeException $e) {
        $error =
            $e->getMessage();

    } catch (Throwable $e) {
        error_log(
            'Customer Booking Document Center: '
            . $e->getMessage()
        );

        $error =
            'Unable to update your Booking documents right now.';
    }
}

tsDocEnsureLeadTraveller(
    $pdo,
    $bookingId
);

tsDocRefreshRequirements(
    $pdo,
    $bookingId
);

$travellers =
    tsDocTravellers(
        $pdo,
        $bookingId
    );

$documents =
    array_values(
        array_filter(
            tsDocDocuments(
                $pdo,
                $bookingId
            ),
            static fn($document) =>
                !empty(
                    $document['customer_visible']
                )
        )
    );

$requirements =
    tsDocRequirements(
        $pdo,
        $bookingId
    );

$summary =
    tsDocSummary(
        $pdo,
        $bookingId
    );

$currentPack =
    $summary['latest_final_pack']
    ?? null;

$household =
    tsDocHouseholdChoices(
        $pdo,
        $userId
    );

$vaultByTraveller = [];

foreach ($travellers as $traveller) {
    $sourceUserId =
        max(
            0,
            (int)(
                $traveller['source_user_id']
                ?? 0
            )
        );

    if ($sourceUserId > 0) {
        $vaultByTraveller[
            (int)$traveller['id']
        ] =
            tsDocVaultDocuments(
                $pdo,
                $sourceUserId
            );
    }
}

function cbdDate(?string $value): string
{
    if (!$value) {
        return 'Not set';
    }

    $ts = strtotime($value);

    return
        $ts
            ? date('d M Y', $ts)
            : 'Not set';
}

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>My Travel Documents | TRAVSCOPE.COM</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f5f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:66px;padding:10px 5%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;border-bottom:1px solid #e2e8f0}.brand{font-weight:900;color:#0f172a}.brand span{color:#2563eb}.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 11px;border:1px solid #cbd5e1;border-radius:9px;background:#fff;color:#334155;text-decoration:none;font-size:10px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.btn.danger{background:#fff1f2;border-color:#fecdd3;color:#be123c}.wrap{max-width:1050px;margin:24px auto;padding:0 13px}.hero{padding:17px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:19px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px;line-height:1.5}.notice{margin-top:10px;padding:10px 12px;border-radius:10px;font-size:10px}.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#047857}.err{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c}.stats{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin-top:11px}.stat{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.stat span{display:block;color:#64748b;font-size:7.5px;font-weight:900;text-transform:uppercase}.stat strong{display:block;margin-top:4px;font-size:12px}.card{margin-top:11px;background:#fff;border:1px solid #dfe7f0;border-radius:13px;overflow:hidden}.head{padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff}.head h2{margin:0;font-size:12px}.head p{margin:4px 0 0;color:#64748b;font-size:8.5px;line-height:1.5}.body{padding:11px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.grid .full{grid-column:1/-1}label{display:block;margin-bottom:4px;color:#475569;font-size:8px;font-weight:900}input,select,textarea{width:100%;min-height:35px;padding:7px 8px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;font-size:9px}textarea{min-height:62px}.row{padding:9px;border:1px solid #e2e8f0;border-radius:10px;background:#fff;margin-bottom:7px}.row:last-child{margin-bottom:0}.row-top{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.row strong{font-size:10px}.row small{display:block;margin-top:3px;color:#64748b;font-size:8px;line-height:1.45}.pill{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:7.5px;font-weight:900}.pill.verified,.pill.final{background:#dcfce7;color:#166534}.pill.pending,.pill.uploaded,.pill.required{background:#fff7ed;color:#c2410c}.pill.rejected{background:#fef2f2;color:#b91c1c}.pill.waived{background:#f1f5f9;color:#64748b}.alert{margin-top:5px;padding:6px 7px;border-radius:7px;background:#fff7ed;color:#c2410c;font-size:8px}.actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:7px}.vault{margin-top:7px;padding-top:7px;border-top:1px dashed #d8e0ea}.empty{padding:13px;text-align:center;color:#94a3b8;font-size:9px}
@media(max-width:760px){.stats{grid-template-columns:1fr 1fr}.grid{grid-template-columns:1fr}.grid .full{grid-column:auto}.top{align-items:flex-start;flex-direction:column}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>
<body>

<header class="top">
    <div class="brand">TRAV<span>SCOPE</span> · MY TRAVEL DOCUMENTS</div>

    <div style="display:flex;gap:7px;flex-wrap:wrap;">
        <a class="btn" href="<?= e(BASE_URL . 'profile.php#documents'); ?>">
            <i class="fa-solid fa-folder-open"></i>
            Profile Vault
        </a>

        <a class="btn primary" href="<?= e(BASE_URL . 'booking-details.php?id=' . $bookingId . '#traveller-document-center'); ?>">
            <i class="fa-solid fa-arrow-left"></i>
            Back to Booking
        </a>
    </div>
</header>

<main class="wrap">
<section class="hero">
    <h1>Traveller Documents & Trip File Center</h1>
    <p>
        Booking <?= e((string)$booking['booking_number']); ?>
        · <?= e((string)($booking['package_title'] ?: 'Travel Booking')); ?>
        <?php if (!empty($booking['destination_name'])): ?>
            · <?= e((string)$booking['destination_name']); ?>
        <?php endif; ?>
        <?php if (!empty($booking['travel_date'])): ?>
            · Depart <?= e(cbdDate((string)$booking['travel_date'])); ?>
        <?php endif; ?>
    </p>
</section>

<?php if ($success): ?>
    <div class="notice ok"><?= e($success); ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="notice err"><?= e($error); ?></div>
<?php endif; ?>

<div class="stats">
    <div class="stat"><span>Travellers Named</span><strong><?= (int)$summary['active_travellers']; ?> / <?= (int)$summary['expected_travellers']; ?></strong></div>
    <div class="stat"><span>Verified Docs</span><strong><?= (int)$summary['verified_documents']; ?></strong></div>
    <div class="stat"><span>Waiting Review</span><strong><?= (int)$summary['pending_documents']; ?></strong></div>
    <div class="stat"><span>Required Missing</span><strong><?= (int)$summary['missing_requirements']; ?></strong></div>
    <div class="stat"><span>Final Trip Pack</span><strong><?= $currentPack ? 'READY' : 'PENDING'; ?></strong></div>
</div>

<section class="card">
    <div class="head">
        <h2>Your Traveller Roster</h2>
        <p>Add every person travelling on this Booking. TRAVSCOPE uses this roster to verify traveller-by-traveller documents.</p>
    </div>

    <div class="body">
        <?php foreach ($travellers as $traveller): ?>
            <div class="row">
                <div>
                    <strong><?= e((string)$traveller['full_name']); ?></strong>
                    <small>
                        <?= e(ucfirst((string)$traveller['traveller_type'])); ?>
                        <?php if (!empty($traveller['relationship'])): ?> · <?= e((string)$traveller['relationship']); ?><?php endif; ?>
                        <?php if (!empty($traveller['date_of_birth'])): ?> · DOB <?= e(cbdDate((string)$traveller['date_of_birth'])); ?><?php endif; ?>
                    </small>
                </div>

                <?php if (!empty($vaultByTraveller[(int)$traveller['id']])): ?>
                    <div class="vault">
                        <small><strong>Profile Vault:</strong> reuse an existing identity/travel document for this Booking.</small>

                        <div class="actions">
                            <?php foreach ($vaultByTraveller[(int)$traveller['id']] as $vaultDoc): ?>
                                <form method="post">
                                    <input type="hidden" name="booking_id" value="<?= $bookingId; ?>">
                                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()); ?>">
                                    <input type="hidden" name="action" value="import_vault_document">
                                    <input type="hidden" name="traveller_id" value="<?= (int)$traveller['id']; ?>">
                                    <input type="hidden" name="profile_document_id" value="<?= (int)$vaultDoc['id']; ?>">

                                    <button class="btn" type="submit">
                                        <i class="fa-solid fa-copy"></i>
                                        <?= e((string)$vaultDoc['document_type']); ?>
                                    </button>
                                </form>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

        <?php if (!in_array(strtolower((string)$booking['booking_status']), ['cancelled','completed'], true)): ?>
            <details style="margin-top:8px;">
                <summary class="btn" style="list-style:none;width:max-content;">
                    <i class="fa-solid fa-user-plus"></i>
                    Add Traveller
                </summary>

                <form method="post" style="margin-top:8px;">
                    <input type="hidden" name="booking_id" value="<?= $bookingId; ?>">
                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()); ?>">
                    <input type="hidden" name="action" value="add_traveller">

                    <div class="grid">
                        <?php if ($household): ?>
                            <div class="full">
                                <label>Choose from My Family / Customer Profile</label>
                                <select name="source_key">
                                    <option value="">Manual traveller instead</option>
                                    <?php foreach ($household as $choice): ?>
                                        <option value="<?= e((string)$choice['key']); ?>">
                                            <?= e((string)$choice['label']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endif; ?>

                        <div>
                            <label>Manual Full Name</label>
                            <input name="full_name">
                        </div>

                        <div>
                            <label>Traveller Type</label>
                            <select name="traveller_type">
                                <option value="adult">Adult</option>
                                <option value="child">Child</option>
                                <option value="infant">Infant</option>
                            </select>
                        </div>

                        <div>
                            <label>Relationship</label>
                            <input name="relationship" placeholder="Spouse, Child, Friend">
                        </div>

                        <div>
                            <label>Date of Birth</label>
                            <input type="date" name="date_of_birth">
                        </div>

                        <div class="full">
                            <label>Nationality</label>
                            <input name="nationality" placeholder="India">
                        </div>
                    </div>

                    <button class="btn primary" type="submit" style="margin-top:7px;">Add Traveller</button>
                </form>
            </details>
        <?php endif; ?>
    </div>
</section>


<section class="card">
    <div class="head">
        <h2>Required Documents</h2>
        <p>TRAVSCOPE marks each required item as Uploaded, Verified, Rejected or Waived.</p>
    </div>

    <div class="body">
        <?php foreach ($requirements as $requirement): ?>
            <?php if (empty($requirement['is_required']) && (string)$requirement['status'] !== 'waived') continue; ?>

            <div class="row">
                <div class="row-top">
                    <div>
                        <strong><?= e((string)$requirement['document_type']); ?></strong>
                        <small>
                            <?= (int)$requirement['traveller_id'] > 0
                                ? e((string)($requirement['traveller_name'] ?: 'Traveller'))
                                : 'Booking / Group'; ?>
                            <?php if (!empty($requirement['note'])): ?> · <?= e((string)$requirement['note']); ?><?php endif; ?>
                        </small>
                    </div>

                    <span class="pill <?= e((string)$requirement['status']); ?>">
                        <?= e(strtoupper((string)$requirement['status'])); ?>
                    </span>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>


<section class="card">
    <div class="head">
        <h2>Upload Booking Documents</h2>
        <p>PDF/JPG/PNG/WEBP up to 8 MB. New files wait for TRAVSCOPE verification before they can enter the Final Trip Document Pack.</p>
    </div>

    <div class="body">
        <?php if (!in_array(strtolower((string)$booking['booking_status']), ['cancelled','completed'], true)): ?>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="booking_id" value="<?= $bookingId; ?>">
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()); ?>">
                <input type="hidden" name="action" value="upload_document">
                <input type="hidden" name="customer_visible" value="1">

                <div class="grid">
                    <div>
                        <label>Traveller / Group</label>
                        <select name="traveller_id">
                            <option value="0">Booking / Group Document</option>
                            <?php foreach ($travellers as $traveller): ?>
                                <option value="<?= (int)$traveller['id']; ?>">
                                    <?= e((string)$traveller['full_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label>Document Type *</label>
                        <select name="document_type" required>
                            <?php foreach (tsDocTypes() as $category => $types): ?>
                                <optgroup label="<?= e(ucfirst($category)); ?>">
                                    <?php foreach ($types as $type): ?>
                                        <option value="<?= e($type); ?>"><?= e($type); ?></option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label>Document Number / Reference</label>
                        <input name="document_number">
                    </div>

                    <div>
                        <label>Issuing Country</label>
                        <input name="issuing_country">
                    </div>

                    <div>
                        <label>Issue Date</label>
                        <input type="date" name="issue_date">
                    </div>

                    <div>
                        <label>Expiry / Valid Until</label>
                        <input type="date" name="expiry_date">
                    </div>

                    <div class="full">
                        <label>Choose File *</label>
                        <input
                            type="file"
                            name="document_file"
                            accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp"
                            required
                        >
                    </div>

                    <div class="full">
                        <label>Notes</label>
                        <textarea name="notes"></textarea>
                    </div>
                </div>

                <button class="btn primary" type="submit" style="margin-top:8px;">
                    <i class="fa-solid fa-cloud-arrow-up"></i>
                    Upload for Verification
                </button>
            </form>
        <?php endif; ?>

        <div style="margin-top:11px;">
            <?php if (!$documents): ?>
                <div class="empty">No Booking documents uploaded yet.</div>
            <?php endif; ?>

            <?php foreach ($documents as $document): ?>
                <?php $validity = tsDocValidity($document, $booking); ?>

                <div class="row">
                    <div class="row-top">
                        <div>
                            <strong>
                                <?= e((string)$document['document_type']); ?>
                                · <?= (int)$document['traveller_id'] > 0
                                    ? e((string)($document['traveller_name'] ?: 'Traveller'))
                                    : 'Booking / Group'; ?>
                            </strong>

                            <small>
                                <?= e(tsDocMaskNumber((string)($document['document_number'] ?? ''))); ?>
                                <?php if (!empty($document['expiry_date'])): ?> · Expiry <?= e(cbdDate((string)$document['expiry_date'])); ?><?php endif; ?>
                                · <?= e((string)$document['original_name']); ?>
                            </small>
                        </div>

                        <span class="pill <?= e((string)$document['verification_status']); ?>">
                            <?= e(strtoupper((string)$document['verification_status'])); ?>
                        </span>
                    </div>

                    <?php if (!empty($validity['blocking']) || !empty($validity['warning'])): ?>
                        <div class="alert"><?= e((string)$validity['message']); ?></div>
                    <?php endif; ?>

                    <?php if (!empty($document['verification_note'])): ?>
                        <div class="alert">
                            TRAVSCOPE Note: <?= e((string)$document['verification_note']); ?>
                        </div>
                    <?php endif; ?>

                    <div class="actions">
                        <a class="btn" target="_blank" href="<?= e(BASE_URL . 'booking-document-file.php?document=' . (int)$document['id']); ?>">
                            Open
                        </a>

                        <?php if (
                            in_array(
                                (string)$document['verification_status'],
                                ['pending','rejected'],
                                true
                            )
                            && (int)($document['created_by_user_id'] ?? 0) === $userId
                        ): ?>
                            <form method="post" onsubmit="return confirm('Remove this document from your active Booking uploads?');">
                                <input type="hidden" name="booking_id" value="<?= $bookingId; ?>">
                                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()); ?>">
                                <input type="hidden" name="action" value="archive_document">
                                <input type="hidden" name="document_id" value="<?= (int)$document['id']; ?>">
                                <button class="btn danger" type="submit">Remove</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>


<?php if ($currentPack): ?>
<section class="card">
    <div class="head">
        <h2>Final Trip Document Pack</h2>
        <p>Your current verified travel-file pack is ready.</p>
    </div>

    <div class="body">
        <div class="row">
            <div class="row-top">
                <div>
                    <strong><?= e((string)$currentPack['pack_code']); ?></strong>
                    <small>Final verified document pack for this Booking.</small>
                </div>

                <span class="pill final">FINAL</span>
            </div>

            <div class="actions">
                <a class="btn primary" target="_blank" href="<?= e(BASE_URL . 'booking-document-pack.php?pack=' . (int)$currentPack['id']); ?>">
                    Open Pack
                </a>

                <a class="btn" href="<?= e(BASE_URL . 'booking-document-pack-download.php?pack=' . (int)$currentPack['id']); ?>">
                    Download Verified Files ZIP
                </a>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

</main>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
