<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| CUSTOMER REGISTRATION
|--------------------------------------------------------------------------
|
| Registration:
|
| Full Name
| Email
| Mobile
| Country
| Password
|       ↓
| Create Account (email_verified = 0)
|       ↓
| Send Email OTP
|       ↓
| verify-email.php
|
*/

require_once __DIR__ . '/config.php';


/*
|--------------------------------------------------------------------------
| ALREADY LOGGED IN
|--------------------------------------------------------------------------
*/

if (isAdminLoggedIn()) {
    redirect(BASE_URL . 'admin-dashboard.php');
}

if (isLoggedIn()) {
    redirect(BASE_URL . 'dashboard.php');
}


/*
|--------------------------------------------------------------------------
| FORM VARIABLES
|--------------------------------------------------------------------------
*/

$error = '';

$fullName = '';
$email = '';
$mobile = '';
$country = 'India';


/*
|--------------------------------------------------------------------------
| LINK PRE-REGISTRATION BOOKING HISTORY
|--------------------------------------------------------------------------
|
| A visitor may have enquired and received a booking before creating an
| account. Older guest bookings therefore have user_id = NULL. Once the
| customer creates an account with the same email or mobile number, attach
| those orphan bookings to the new user so they appear in My Bookings.
|
*/

function linkPreRegistrationBookingHistory(
    PDO $pdo,
    int $userId,
    string $email,
    string $mobile
): void {

    if ($userId <= 0) {
        return;
    }

    $normalizedEmail = mb_strtolower(trim($email));
    $normalizedMobile = preg_replace('/[^0-9]/', '', $mobile);
    $mobileLast10 = strlen($normalizedMobile) >= 10
        ? substr($normalizedMobile, -10)
        : $normalizedMobile;

    $matchParts = [];
    $params = [$userId];

    if ($normalizedEmail !== '') {
        $matchParts[] = 'LOWER(TRIM(customer_email)) = ?';
        $params[] = $normalizedEmail;
    }

    if ($mobileLast10 !== '') {
        $matchParts[] = "
            RIGHT(
                REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                    TRIM(COALESCE(customer_mobile, '')),
                    ' ', ''), '-', ''), '(', ''), ')', ''), '+', ''),
                10
            ) = ?
        ";
        $params[] = $mobileLast10;
    }

    if (!$matchParts) {
        return;
    }

    $sql = "
        UPDATE bookings
        SET user_id = ?
        WHERE user_id IS NULL
          AND (" . implode(' OR ', $matchParts) . ")
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
}

/*
|--------------------------------------------------------------------------
| GOOGLE VERIFIED REGISTRATION
|--------------------------------------------------------------------------
|
| google-auth.php should save the verified Google profile in:
|
| $_SESSION['google_register'] = [
|     'google_sub' => '...',
|     'email'      => 'verified@gmail.com',
|     'full_name'  => 'Customer Name',
|     'picture'    => 'https://...'
| ];
|
| Then redirect to register.php.
|
| google_pending is also accepted for compatibility.
|
*/

$googleRegistration = false;
$googleSub = '';
$googlePicture = '';
$googleRegistrationData = null;

if (
    !empty($_SESSION['google_register'])
    &&
    is_array($_SESSION['google_register'])
) {
    $googleRegistrationData =
        $_SESSION['google_register'];

} elseif (
    !empty($_SESSION['google_pending'])
    &&
    is_array($_SESSION['google_pending'])
) {
    $googleRegistrationData =
        $_SESSION['google_pending'];
}

if (is_array($googleRegistrationData)) {

    $googleSub =
        trim(
            (string)(
                $googleRegistrationData['google_sub']
                ?? ''
            )
        );

    $email =
        normalizeEmail(
            (string)(
                $googleRegistrationData['email']
                ?? ''
            )
        );

    $fullName =
        trim(
            (string)(
                $googleRegistrationData['full_name']
                ?? 'Google Customer'
            )
        );

    $googlePicture =
        trim(
            (string)(
                $googleRegistrationData['picture']
                ?? ''
            )
        );

    if (
        $googleSub !== ''
        &&
        validEmail($email)
    ) {
        $googleRegistration = true;
    }
}

if (!empty($_SESSION['google_auth_error'])) {
    $error = (string)$_SESSION['google_auth_error'];
    unset($_SESSION['google_auth_error']);
}


/*
|--------------------------------------------------------------------------
| GOOGLE VERIFIED REGISTRATION - MOBILE ONLY
|--------------------------------------------------------------------------
|
| Google has already verified the email address.
| The customer only enters a mobile number here.
| No email OTP and no mobile OTP are required.
|
*/

if (
    isPost()
    &&
    $googleRegistration
) {

    if (!verifyCsrf($_POST['csrf_token'] ?? null)) {

        $error =
            'Security verification failed. Please refresh the page and try again.';

    } else {

        $mobile =
            normalizeMobile(
                (string)(
                    $_POST['mobile']
                    ?? ''
                )
            );

        if (!validMobile($mobile)) {

            $error =
                'Please enter a valid 10-digit mobile number.';

        } else {

            try {

                if (
                    $googleSub === ''
                    ||
                    !validEmail($email)
                ) {
                    throw new RuntimeException(
                        'Google registration session is invalid.'
                    );
                }

                /*
                |--------------------------------------------------------------------------
                | CHECK EXISTING GOOGLE USER
                |--------------------------------------------------------------------------
                */

                $stmt =
                    $pdo->prepare("
                        SELECT
                            id,
                            full_name,
                            email,
                            mobile,
                            status
                        FROM users
                        WHERE google_sub = ?
                        LIMIT 1
                    ");

                $stmt->execute([
                    $googleSub
                ]);

                $existingGoogleUser =
                    $stmt->fetch();

                if ($existingGoogleUser) {

                    if (
                        strtolower(
                            (string)(
                                $existingGoogleUser['status']
                                ?? ''
                            )
                        ) !== 'active'
                    ) {
                        throw new RuntimeException(
                            'This customer account is inactive.'
                        );
                    }

                    $existingGoogleMobile =
                        normalizeMobile(
                            (string)(
                                $existingGoogleUser['mobile']
                                ?? ''
                            )
                        );

                    if (
                        $existingGoogleMobile === ''
                        ||
                        !validMobile($existingGoogleMobile)
                    ) {

                        $mobileOwnerStmt =
                            $pdo->prepare("
                                SELECT id
                                FROM users
                                WHERE mobile = ?
                                  AND id <> ?
                                LIMIT 1
                            ");

                        $mobileOwnerStmt->execute([
                            $mobile,
                            (int)$existingGoogleUser['id']
                        ]);

                        if ($mobileOwnerStmt->fetch()) {

                            $error =
                                'This mobile number is already registered with another account.';

                        } else {

                            $update =
                                $pdo->prepare("
                                    UPDATE users
                                    SET
                                        mobile = ?,
                                        email_verified = 1
                                    WHERE id = ?
                                    LIMIT 1
                                ");

                            $update->execute([
                                $mobile,
                                (int)$existingGoogleUser['id']
                            ]);

                            $existingGoogleUser['mobile'] =
                                $mobile;
                        }

                    } elseif (
                        $existingGoogleMobile !== $mobile
                    ) {

                        $error =
                            'This Google account is already registered with another mobile number.';
                    }

                    if ($error === '') {

                        try {
                            linkPreRegistrationBookingHistory(
                                $pdo,
                                (int)$existingGoogleUser['id'],
                                (string)$existingGoogleUser['email'],
                                (string)($existingGoogleUser['mobile'] ?? $mobile)
                            );
                        } catch (Throwable $e) {
                            error_log('TRAVSCOPE existing Google history link error: ' . $e->getMessage());
                        }

                        session_regenerate_id(true);

                        unset(
                            $_SESSION['admin_id'],
                            $_SESSION['admin_name'],
                            $_SESSION['admin_email'],
                            $_SESSION['admin_mobile'],
                            $_SESSION['admin_role']
                        );

                        $_SESSION['user_id'] =
                            (int)$existingGoogleUser['id'];

                        $_SESSION['user_name'] =
                            (string)$existingGoogleUser['full_name'];

                        $_SESSION['user_email'] =
                            (string)$existingGoogleUser['email'];

                        $_SESSION['user_mobile'] =
                            (string)(
                                $existingGoogleUser['mobile']
                                ?? $mobile
                            );

                        unset(
                            $_SESSION['google_register'],
                            $_SESSION['google_pending'],
                            $_SESSION['google_auth_error']
                        );

                        redirect(
                            BASE_URL . 'dashboard.php'
                        );
                    }

                } else {

                    /*
                    |--------------------------------------------------------------------------
                    | CHECK EMAIL
                    |--------------------------------------------------------------------------
                    */

                    $stmt =
                        $pdo->prepare("
                            SELECT id
                            FROM users
                            WHERE email = ?
                            LIMIT 1
                        ");

                    $stmt->execute([
                        $email
                    ]);

                    if ($stmt->fetch()) {

                        $error =
                            'An account already exists with this email address. Please sign in instead.';

                    } else {

                        /*
                        |--------------------------------------------------------------------------
                        | CHECK MOBILE
                        |--------------------------------------------------------------------------
                        */

                        $stmt =
                            $pdo->prepare("
                                SELECT id
                                FROM users
                                WHERE mobile = ?
                                LIMIT 1
                            ");

                        $stmt->execute([
                            $mobile
                        ]);

                        if ($stmt->fetch()) {

                            $error =
                                'An account already exists with this mobile number. Please use another number or sign in.';

                        } else {

                            /*
                            |--------------------------------------------------------------------------
                            | RANDOM INTERNAL PASSWORD
                            |--------------------------------------------------------------------------
                            |
                            | Google users do not need to create a password here.
                            | This keeps the existing users.password column satisfied.
                            |
                            */

                            $passwordHash =
                                password_hash(
                                    bin2hex(
                                        random_bytes(32)
                                    ),
                                    PASSWORD_DEFAULT
                                );

                            if ($passwordHash === false) {
                                throw new RuntimeException(
                                    'Unable to create secure customer credentials.'
                                );
                            }

                            /*
                            |--------------------------------------------------------------------------
                            | CREATE VERIFIED GOOGLE CUSTOMER
                            |--------------------------------------------------------------------------
                            */

                            $pdo->beginTransaction();

                            $stmt =
                                $pdo->prepare("
                                    INSERT INTO users
                                    (
                                        full_name,
                                        email,
                                        mobile,
                                        password,
                                        profile_image,
                                        country,
                                        email_verified,
                                        status,
                                        google_sub
                                    )
                                    VALUES
                                    (
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        ?,
                                        1,
                                        'active',
                                        ?
                                    )
                                ");

                            $stmt->execute([
                                $fullName !== ''
                                    ? $fullName
                                    : 'Google Customer',
                                $email,
                                $mobile,
                                $passwordHash,
                                $googlePicture !== ''
                                    ? $googlePicture
                                    : null,
                                $country,
                                $googleSub
                            ]);

                            $userId =
                                (int)$pdo->lastInsertId();

                            if ($userId <= 0) {
                                throw new RuntimeException(
                                    'Google customer account could not be created.'
                                );
                            }

                            linkPreRegistrationBookingHistory($pdo, $userId, $email, $mobile);

                            $pdo->commit();

                            /*
                            |--------------------------------------------------------------------------
                            | AUTO LOGIN - NO OTP
                            |--------------------------------------------------------------------------
                            */

                            session_regenerate_id(true);

                            unset(
                                $_SESSION['admin_id'],
                                $_SESSION['admin_name'],
                                $_SESSION['admin_email'],
                                $_SESSION['admin_mobile'],
                                $_SESSION['admin_role']
                            );

                            $_SESSION['user_id'] =
                                $userId;

                            $_SESSION['user_name'] =
                                $fullName !== ''
                                    ? $fullName
                                    : 'Google Customer';

                            $_SESSION['user_email'] =
                                $email;

                            $_SESSION['user_mobile'] =
                                $mobile;

                            unset(
                                $_SESSION['google_register'],
                                $_SESSION['google_pending'],
                                $_SESSION['google_auth_error'],
                                $_SESSION['pending_verify_user_id'],
                                $_SESSION['pending_verify_email'],
                                $_SESSION['pending_verify_name'],
                                $_SESSION['otp_send_error']
                            );

                            redirect(
                                BASE_URL . 'dashboard.php'
                            );
                        }
                    }
                }

            } catch (PDOException $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                error_log(
                    'TRAVSCOPE Google registration database error: '
                    . $e->getMessage()
                );

                if ((string)$e->getCode() === '23000') {
                    $error =
                        'This email address or mobile number is already registered.';
                } else {
                    $error =
                        'Google registration could not be completed. Please try again.';
                }

            } catch (Throwable $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                error_log(
                    'TRAVSCOPE Google registration error: '
                    . $e->getMessage()
                );

                $error =
                    defined('APP_DEBUG')
                    && APP_DEBUG
                        ? 'Google registration error: ' . $e->getMessage()
                        : 'Google registration could not be completed. Please try again.';
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| REGISTRATION REQUEST
|--------------------------------------------------------------------------
*/

if (
    isPost()
    &&
    !$googleRegistration
) {

    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */

    if (!verifyCsrf($_POST['csrf_token'] ?? null)) {

        $error =
            'Security verification failed. Please refresh the page and try again.';

    } else {

        /*
        |--------------------------------------------------------------------------
        | INPUT
        |--------------------------------------------------------------------------
        */

        $fullName =
            trim(
                (string)(
                    $_POST['full_name']
                    ?? ''
                )
            );

        $email =
            normalizeEmail(
                (string)(
                    $_POST['email']
                    ?? ''
                )
            );

        $mobile =
            normalizeMobile(
                (string)(
                    $_POST['mobile']
                    ?? ''
                )
            );

        $country =
            trim(
                (string)(
                    $_POST['country']
                    ?? 'India'
                )
            );

        $password =
            (string)(
                $_POST['password']
                ?? ''
            );

        $confirmPassword =
            (string)(
                $_POST['confirm_password']
                ?? ''
            );

        $termsAccepted =
            isset($_POST['terms']);


        /*
        |--------------------------------------------------------------------------
        | VALIDATION
        |--------------------------------------------------------------------------
        */

        if (
            $fullName === ''
            ||
            mb_strlen($fullName) < 2
        ) {

            $error =
                'Please enter your full name.';

        } elseif (
            mb_strlen($fullName) > 150
        ) {

            $error =
                'Your name is too long.';

        } elseif (
            !validEmail($email)
        ) {

            $error =
                'Please enter a valid email address.';

        } elseif (
            !validMobile($mobile)
        ) {

            $error =
                'Please enter a valid 10-digit mobile number.';

        } elseif (
            $country === ''
            ||
            mb_strlen($country) > 100
        ) {

            $error =
                'Please select a valid country.';

        } elseif (
            strlen($password)
            <
            (
                defined('PASSWORD_MIN_LENGTH')
                    ? PASSWORD_MIN_LENGTH
                    : 8
            )
        ) {

            $minLength =
                defined('PASSWORD_MIN_LENGTH')
                    ? PASSWORD_MIN_LENGTH
                    : 8;

            $error =
                'Password must contain at least '
                . $minLength
                . ' characters.';

        } elseif (
            !preg_match('/[A-Z]/', $password)
        ) {

            $error =
                'Password must contain at least one uppercase letter.';

        } elseif (
            !preg_match('/[a-z]/', $password)
        ) {

            $error =
                'Password must contain at least one lowercase letter.';

        } elseif (
            !preg_match('/[0-9]/', $password)
        ) {

            $error =
                'Password must contain at least one number.';

        } elseif (
            $password !== $confirmPassword
        ) {

            $error =
                'Password and confirm password do not match.';

        } elseif (!$termsAccepted) {

            $error =
                'Please accept the Terms & Conditions and Privacy Policy.';

        } else {

            /*
            |--------------------------------------------------------------------------
            | CHECK EXISTING EMAIL
            |--------------------------------------------------------------------------
            */

            $existingEmail = null;

            try {

                $stmt =
                    $pdo->prepare("
                        SELECT
                            id,
                            full_name,
                            email,
                            email_verified,
                            status
                        FROM users
                        WHERE email = ?
                        LIMIT 1
                    ");

                $stmt->execute([
                    $email
                ]);

                $existingEmail =
                    $stmt->fetch();

            } catch (Throwable $e) {

                error_log(
                    'TRAVSCOPE registration email check: '
                    . $e->getMessage()
                );

                $error =
                    'We could not process your registration right now. Please try again.';
            }


            /*
            |--------------------------------------------------------------------------
            | EXISTING EMAIL
            |--------------------------------------------------------------------------
            */

            if (
                $error === ''
                &&
                $existingEmail
            ) {

                /*
                |--------------------------------------------------------------------------
                | ALREADY VERIFIED
                |--------------------------------------------------------------------------
                */

                if (
                    (int)$existingEmail['email_verified']
                    === 1
                ) {

                    $error =
                        'An account already exists with this email address. Please sign in instead.';

                } else {

                    /*
                    |--------------------------------------------------------------------------
                    | EXISTING BUT NOT VERIFIED
                    |--------------------------------------------------------------------------
                    */

                    $_SESSION['pending_verify_user_id'] =
                        (int)$existingEmail['id'];

                    $_SESSION['pending_verify_email'] =
                        (string)$existingEmail['email'];

                    $_SESSION['pending_verify_name'] =
                        (string)$existingEmail['full_name'];


                    /*
                    |--------------------------------------------------------------------------
                    | TRY TO SEND A FRESH OTP
                    |--------------------------------------------------------------------------
                    */

                    try {

                        $otpResult =
                            createEmailOtp(
                                $pdo,
                                (string)$existingEmail['email'],
                                (string)$existingEmail['full_name'],
                                'register'
                            );

                        $otpSent =
                            $otpResult === true
                            ||
                            (
                                is_array($otpResult)
                                &&
                                !empty($otpResult['success'])
                            );


                        if (!$otpSent) {

                            $otpMessage =
                                is_array($otpResult)
                                    ? (string)(
                                        $otpResult['message']
                                        ?? ''
                                    )
                                    : '';

                            error_log(
                                'TRAVSCOPE existing account OTP send failed: '
                                . $otpMessage
                            );

                            $_SESSION['otp_send_error'] =
                                $otpMessage !== ''
                                    ? $otpMessage
                                    : 'We could not send a new verification code. Please use Resend OTP.';
                        }

                    } catch (Throwable $e) {

                        error_log(
                            'TRAVSCOPE existing account OTP error: '
                            . $e->getMessage()
                        );

                        $_SESSION['otp_send_error'] =
                            'We could not send a new verification code. Please use Resend OTP.';
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | GO TO VERIFY PAGE
                    |--------------------------------------------------------------------------
                    */

                    redirect(
                        BASE_URL . 'verify-email.php'
                    );
                }
            }


            /*
            |--------------------------------------------------------------------------
            | CHECK EXISTING MOBILE
            |--------------------------------------------------------------------------
            */

            $existingMobile = null;

            if ($error === '') {

                try {

                    $stmt =
                        $pdo->prepare("
                            SELECT
                                id,
                                email,
                                email_verified
                            FROM users
                            WHERE mobile = ?
                            LIMIT 1
                        ");

                    $stmt->execute([
                        $mobile
                    ]);

                    $existingMobile =
                        $stmt->fetch();

                } catch (Throwable $e) {

                    error_log(
                        'TRAVSCOPE registration mobile check: '
                        . $e->getMessage()
                    );

                    $error =
                        'We could not process your registration right now. Please try again.';
                }
            }


            /*
            |--------------------------------------------------------------------------
            | DUPLICATE MOBILE
            |--------------------------------------------------------------------------
            */

            if (
                $error === ''
                &&
                $existingMobile
            ) {

                $error =
                    'An account already exists with this mobile number. Please use another number or sign in.';
            }


            /*
            |--------------------------------------------------------------------------
            | CREATE CUSTOMER
            |--------------------------------------------------------------------------
            */

            if ($error === '') {

                try {

                    /*
                    |--------------------------------------------------------------------------
                    | PASSWORD HASH
                    |--------------------------------------------------------------------------
                    */

                    $passwordHash =
                        password_hash(
                            $password,
                            PASSWORD_DEFAULT
                        );

                    if ($passwordHash === false) {

                        throw new RuntimeException(
                            'Unable to create password hash.'
                        );
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | START DATABASE TRANSACTION
                    |--------------------------------------------------------------------------
                    */

                    $pdo->beginTransaction();


                    /*
                    |--------------------------------------------------------------------------
                    | INSERT USER
                    |--------------------------------------------------------------------------
                    */

                    $stmt =
                        $pdo->prepare("
                            INSERT INTO users
                            (
                                full_name,
                                email,
                                mobile,
                                password,
                                profile_image,
                                country,
                                email_verified,
                                status
                            )
                            VALUES
                            (
                                ?,
                                ?,
                                ?,
                                ?,
                                NULL,
                                ?,
                                0,
                                'active'
                            )
                        ");

                    $stmt->execute([
                        $fullName,
                        $email,
                        $mobile,
                        $passwordHash,
                        $country
                    ]);


                    /*
                    |--------------------------------------------------------------------------
                    | USER ID
                    |--------------------------------------------------------------------------
                    */

                    $userId =
                        (int)$pdo->lastInsertId();


                    if ($userId <= 0) {

                        throw new RuntimeException(
                            'Customer account could not be created.'
                        );
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | LINK PRE-REGISTRATION BOOKINGS
                    |--------------------------------------------------------------------------
                    */

                    linkPreRegistrationBookingHistory($pdo, $userId, $email, $mobile);


                    /*
                    |--------------------------------------------------------------------------
                    | COMMIT USER
                    |--------------------------------------------------------------------------
                    */

                    $pdo->commit();


                    /*
                    |--------------------------------------------------------------------------
                    | STORE VERIFICATION SESSION
                    |--------------------------------------------------------------------------
                    */

                    $_SESSION['pending_verify_user_id'] =
                        $userId;

                    $_SESSION['pending_verify_email'] =
                        $email;

                    $_SESSION['pending_verify_name'] =
                        $fullName;


                    /*
                    |--------------------------------------------------------------------------
                    | CREATE + SEND EMAIL OTP
                    |--------------------------------------------------------------------------
                    |
                    | IMPORTANT:
                    |
                    | createEmailOtp requires:
                    |
                    | $pdo
                    | $email
                    | $name
                    | $purpose
                    |
                    */

                    try {

                        $otpResult =
                            createEmailOtp(
                                $pdo,
                                $email,
                                $fullName,
                                'register'
                            );


                        /*
                        |--------------------------------------------------------------------------
                        | OTP RESULT
                        |--------------------------------------------------------------------------
                        */

                        $otpSent =
                            $otpResult === true
                            ||
                            (
                                is_array($otpResult)
                                &&
                                !empty(
                                    $otpResult['success']
                                )
                            );


                        /*
                        |--------------------------------------------------------------------------
                        | OTP FAILED
                        |--------------------------------------------------------------------------
                        */

                        if (!$otpSent) {

                            $otpMessage =
                                is_array($otpResult)
                                    ? (string)(
                                        $otpResult['message']
                                        ?? ''
                                    )
                                    : '';


                            error_log(
                                'TRAVSCOPE registration OTP failed for '
                                . $email
                                . ' | '
                                . $otpMessage
                            );


                            /*
                            | User account has already been created.
                            |
                            | Do NOT leave the customer on register.php.
                            | Send them to verification page.
                            */

                            $_SESSION['otp_send_error'] =
                                $otpMessage !== ''
                                    ? $otpMessage
                                    : 'Verification email could not be sent. Please resend the OTP.';
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | ALWAYS GO TO EMAIL VERIFICATION
                        |--------------------------------------------------------------------------
                        */

                        redirect(
                            BASE_URL . 'verify-email.php'
                        );


                    } catch (Throwable $e) {

                        error_log(
                            'TRAVSCOPE registration OTP exception: '
                            . $e->getMessage()
                        );


                        /*
                        | Account exists even though SMTP failed.
                        */

                        $_SESSION['otp_send_error'] =
                            'The account was created, but the verification email could not be sent. Please use Resend OTP.';


                        redirect(
                            BASE_URL . 'verify-email.php'
                        );
                    }


                } catch (PDOException $e) {

                    /*
                    |--------------------------------------------------------------------------
                    | ROLLBACK
                    |--------------------------------------------------------------------------
                    */

                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }


                    error_log(
                        'TRAVSCOPE registration database error: '
                        . $e->getMessage()
                    );


                    /*
                    |--------------------------------------------------------------------------
                    | DUPLICATE KEY
                    |--------------------------------------------------------------------------
                    */

                    if (
                        (string)$e->getCode()
                        === '23000'
                    ) {

                        $error =
                            'An account already exists with this email address or mobile number.';

                    } else {

                        $error =
                            'Registration could not be completed. Please try again.';
                    }


                } catch (Throwable $e) {

                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }


                    error_log(
                        'TRAVSCOPE registration error: '
                        . $e->getMessage()
                    );


                    $error =
                        'Registration could not be completed. Please try again.';
                }
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

$csrfToken =
    csrfToken();

?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#071a2f"
>

<meta
    name="robots"
    content="noindex,nofollow"
>

<title>Create Account | TRAVSCOPE.COM</title>


<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

:root {
    --primary:#0b74ff;
    --primary-dark:#075ed1;
    --navy:#071a2f;
    --text:#172033;
    --muted:#6d7889;
    --border:#e3e8ef;
    --background:#f5f8fc;
    --danger:#c92a42;
    --success:#169b62;
}

* {
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body {
    min-height:100vh;
    font-family:'DM Sans',sans-serif;
    background:var(--background);
    color:var(--text);
}

a {
    color:inherit;
    text-decoration:none;
}

button,
input,
select {
    font-family:inherit;
}

.register-page {
    min-height:100vh;
    display:grid;
    grid-template-columns:minmax(430px,.9fr) minmax(560px,1.1fr);
}


/* LEFT */

.travel-side {
    min-height:100vh;
    position:relative;
    overflow:hidden;
    padding:52px 58px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    color:#fff;

    background:
        linear-gradient(
            125deg,
            rgba(3,18,34,.95),
            rgba(5,40,73,.67)
        ),
        url(
            'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1600&q=88'
        )
        center/cover no-repeat;
}

.logo {
    display:inline-flex;
    align-items:center;
    gap:11px;
    width:max-content;
    position:relative;
    z-index:2;
    font-family:'Manrope',sans-serif;
    font-size:23px;
    font-weight:800;
}

.logo-icon {
    width:45px;
    height:45px;
    border-radius:13px;
    display:grid;
    place-items:center;
    background:linear-gradient(135deg,#0b74ff,#00b6ff);
    box-shadow:0 10px 28px rgba(11,116,255,.25);
    transform:rotate(-5deg);
}

.logo span {
    color:#62b5ff;
}

.travel-content {
    position:relative;
    z-index:2;
    max-width:560px;
}

.travel-badge {
    display:inline-flex;
    align-items:center;
    gap:8px;
    padding:8px 13px;
    margin-bottom:20px;
    border:1px solid rgba(255,255,255,.18);
    border-radius:50px;
    background:rgba(255,255,255,.1);
    font-size:12px;
    font-weight:700;
}

.travel-content h1 {
    font-family:'Manrope',sans-serif;
    font-size:clamp(40px,4.7vw,64px);
    line-height:1.08;
    letter-spacing:-2px;
}

.travel-content h1 span {
    display:block;
    color:#62b5ff;
}

.travel-content p {
    max-width:510px;
    margin-top:20px;
    color:rgba(255,255,255,.78);
    font-size:15px;
    line-height:1.75;
}

.benefits {
    margin-top:28px;
    display:grid;
    gap:12px;
}

.benefit {
    display:flex;
    align-items:center;
    gap:10px;
    color:rgba(255,255,255,.85);
    font-size:12px;
    font-weight:600;
}

.benefit i {
    width:27px;
    height:27px;
    display:grid;
    place-items:center;
    border-radius:50%;
    background:rgba(255,255,255,.1);
    color:#71c2ff;
}

.travel-footer {
    position:relative;
    z-index:2;
    color:rgba(255,255,255,.55);
    font-size:11px;
}


/* RIGHT */

.form-side {
    min-height:100vh;
    padding:42px 55px;
    display:flex;
    align-items:center;
    justify-content:center;
    background:#fff;
}

.form-container {
    width:100%;
    max-width:590px;
}

.mobile-logo {
    display:none;
    color:var(--navy);
    margin-bottom:35px;
}

.mobile-logo span {
    color:var(--primary);
}

.form-header {
    margin-bottom:25px;
}

.form-header h2 {
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:34px;
    letter-spacing:-1px;
}

.form-header p {
    margin-top:7px;
    color:var(--muted);
    font-size:13px;
    line-height:1.6;
}

.alert {
    display:flex;
    align-items:flex-start;
    gap:10px;
    padding:13px 14px;
    margin-bottom:20px;
    border:1px solid #ffd8de;
    border-radius:11px;
    background:#fff1f3;
    color:var(--danger);
    font-size:12px;
    line-height:1.5;
}

.form-grid {
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:17px;
}

.field {
    margin-bottom:17px;
}

.field.full {
    grid-column:1/-1;
}

.field label {
    display:block;
    margin-bottom:7px;
    color:#344054;
    font-size:12px;
    font-weight:700;
}

.input-wrap {
    position:relative;
}

.input-icon {
    position:absolute;
    left:15px;
    top:50%;
    transform:translateY(-50%);
    color:#8a96a7;
    pointer-events:none;
}

.input-wrap input,
.input-wrap select {
    width:100%;
    height:53px;
    padding:0 45px;
    border:1px solid var(--border);
    border-radius:11px;
    outline:none;
    background:#fff;
    color:var(--text);
    font-size:14px;
    transition:.2s;
}

.input-wrap select {
    appearance:none;
    cursor:pointer;
}

.input-wrap input:focus,
.input-wrap select:focus {
    border-color:var(--primary);
    box-shadow:0 0 0 3px rgba(11,116,255,.09);
}

.password-toggle {
    position:absolute;
    top:50%;
    right:10px;
    transform:translateY(-50%);
    width:38px;
    height:38px;
    display:grid;
    place-items:center;
    border:0;
    border-radius:8px;
    background:transparent;
    color:#778294;
    cursor:pointer;
}

.password-help {
    margin-top:6px;
    color:#8a95a5;
    font-size:10px;
    line-height:1.5;
}

.terms {
    display:flex;
    align-items:flex-start;
    gap:9px;
    margin:4px 0 20px;
    color:#667085;
    font-size:11px;
    line-height:1.55;
}

.terms input {
    width:16px;
    height:16px;
    margin-top:1px;
    flex:0 0 auto;
    accent-color:var(--primary);
}

.terms a {
    color:var(--primary);
    font-weight:700;
}

.register-button {
    width:100%;
    min-height:55px;
    border:0;
    border-radius:12px;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:9px;
    background:var(--primary);
    color:#fff;
    font-size:14px;
    font-weight:700;
    cursor:pointer;
    box-shadow:0 12px 28px rgba(11,116,255,.2);
    transition:.2s;
}

.register-button:hover {
    background:var(--primary-dark);
    transform:translateY(-1px);
}

.register-button:disabled {
    opacity:.7;
    cursor:not-allowed;
}

.login-link {
    margin-top:22px;
    text-align:center;
    color:#687386;
    font-size:12px;
}

.login-link a {
    color:var(--primary);
    font-weight:700;
}

.security {
    margin-top:20px;
    display:flex;
    justify-content:center;
    align-items:center;
    gap:7px;
    color:#98a2b3;
    font-size:10px;
}

.security i {
    color:var(--success);
}


@media(max-width:1000px) {

    .register-page {
        grid-template-columns:1fr;
    }

    .travel-side {
        display:none;
    }

    .form-side {
        padding:35px 25px;
    }

    .mobile-logo {
        display:flex;
    }
}


@media(max-width:600px) {

    .form-side {
        align-items:flex-start;
        padding:26px 18px 40px;
    }

    .form-grid {
        grid-template-columns:1fr;
        gap:0;
    }

    .field.full {
        grid-column:auto;
    }

    .form-header h2 {
        font-size:29px;
    }
}


/* GOOGLE OAUTH 2.0 SIGN-UP */
.google-oauth-wrap{
    margin-top:18px;
}
.google-oauth-divider{
    display:flex;
    align-items:center;
    gap:12px;
    margin:20px 0 14px;
    color:#98a2b3;
    font-size:11px;
    font-weight:700;
    letter-spacing:.5px;
}
.google-oauth-divider::before,
.google-oauth-divider::after{
    content:"";
    height:1px;
    flex:1;
    background:var(--border);
}
.google-oauth-button{
    width:100%;
    min-height:54px;
    border:1px solid #ea4335;
    border-radius:12px;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:10px;
    background:#ea4335;
    color:#fff;
    font-size:14px;
    font-weight:700;
    transition:.2s;
}
.google-oauth-button:hover{
    border-color:#c9342a;
    background:#c9342a;
    transform:translateY(-1px);
}
.google-oauth-button .google-g{
    width:22px;
    height:22px;
    border-radius:50%;
    display:grid;
    place-items:center;
    font-weight:800;
    color:#4285f4;
    background:#fff;
    box-shadow:0 0 0 1px #e2e7ee;
}

.google-top-wrap{
    margin-bottom:22px;
}

.google-verified-box{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 15px;
    margin-bottom:20px;
    border:1px solid #cfe9da;
    border-radius:12px;
    background:#f0fbf5;
}

.google-verified-icon{
    width:38px;
    height:38px;
    flex:0 0 auto;
    border-radius:50%;
    display:grid;
    place-items:center;
    background:#169b62;
    color:#fff;
}

.google-verified-text strong{
    display:block;
    color:#174d37;
    font-size:13px;
}

.google-verified-text span{
    display:block;
    margin-top:3px;
    color:#537466;
    font-size:11px;
    word-break:break-all;
}

.google-mobile-note{
    margin-top:7px;
    color:#7b8796;
    font-size:10px;
    line-height:1.5;
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-public-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="public"></script>
</head>

<body>


<div class="register-page">


    <!-- LEFT SIDE -->

    <section class="travel-side">

        <a
            href="<?= e(BASE_URL); ?>"
            class="logo"
        >

            <div class="logo-icon">
                <i class="fa-solid fa-plane"></i>
            </div>

            TRAV<span>SCOPE</span>

        </a>


        <div class="travel-content">

            <div class="travel-badge">
                <i class="fa-solid fa-earth-americas"></i>
                Your journey starts here
            </div>

            <h1>
                Discover more.
                <span>Travel better.</span>
            </h1>

            <p>
                Create your TRAVSCOPE account to manage bookings,
                organize your journeys and discover extraordinary
                destinations around the world.
            </p>


            <div class="benefits">

                <div class="benefit">
                    <i class="fa-solid fa-check"></i>
                    Manage all your bookings in one place
                </div>

                <div class="benefit">
                    <i class="fa-solid fa-check"></i>
                    Discover worldwide holiday packages
                </div>

                <div class="benefit">
                    <i class="fa-solid fa-check"></i>
                    Secure account with email verification
                </div>

            </div>

        </div>


        <div class="travel-footer">
            © <?= date('Y'); ?> TRAVSCOPE.COM — Worldwide Travel Experiences
        </div>

    </section>


    <!-- FORM SIDE -->

    <section class="form-side">

        <div class="form-container">


            <a
                href="<?= e(BASE_URL); ?>"
                class="logo mobile-logo"
            >

                <div class="logo-icon">
                    <i class="fa-solid fa-plane"></i>
                </div>

                TRAV<span>SCOPE</span>

            </a>


            <div class="form-header">

                <?php if ($googleRegistration): ?>

                    <h2>Complete your Google sign-up</h2>

                    <p>
                        Your Google email is verified. Enter your mobile
                        number to finish creating your TRAVSCOPE account.
                    </p>

                <?php else: ?>

                    <h2>Create your account</h2>

                    <p>
                        Join TRAVSCOPE and start planning your next
                        unforgettable journey.
                    </p>

                <?php endif; ?>

            </div>


            <?php if (!$googleRegistration): ?>

                <div class="google-top-wrap">

                    <a
                        href="<?= e(BASE_URL . 'google-auth.php'); ?>"
                        class="google-oauth-button"
                    >
                        <span class="google-g">G</span>
                        Sign up with Google
                    </a>

                    <div class="google-oauth-divider">
                        OR REGISTER WITH EMAIL
                    </div>

                </div>

            <?php else: ?>

                <div class="google-verified-box">

                    <div class="google-verified-icon">
                        <i class="fa-solid fa-check"></i>
                    </div>

                    <div class="google-verified-text">
                        <strong>Google email verified</strong>
                        <span><?= e($email); ?></span>
                    </div>

                </div>

            <?php endif; ?>


            <?php if ($error !== ''): ?>

                <div
                    class="alert"
                    role="alert"
                >
                    <i class="fa-solid fa-circle-exclamation"></i>

                    <span>
                        <?= e($error); ?>
                    </span>
                </div>

            <?php endif; ?>


            <?php if ($googleRegistration): ?>

                <form
                    method="POST"
                    action=""
                    id="registerForm"
                    autocomplete="on"
                >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e($csrfToken); ?>"
                    >

                    <div class="field full">

                        <label for="mobile">
                            Mobile Number
                        </label>

                        <div class="input-wrap">

                            <i class="fa-solid fa-mobile-screen input-icon"></i>

                            <input
                                type="tel"
                                id="mobile"
                                name="mobile"
                                value="<?= e($mobile); ?>"
                                placeholder="Enter your 10-digit mobile number"
                                maxlength="15"
                                inputmode="numeric"
                                autocomplete="tel"
                                required
                                autofocus
                            >

                        </div>

                        <div class="google-mobile-note">
                            No OTP is required. This number will be saved
                            with your verified Google account.
                        </div>

                    </div>

                    <button
                        type="submit"
                        class="register-button"
                        id="registerButton"
                    >
                        <span>Complete Registration</span>
                        <i class="fa-solid fa-arrow-right"></i>
                    </button>

                </form>

            <?php else: ?>

            <form
                method="POST"
                action=""
                id="registerForm"
                autocomplete="on"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e($csrfToken); ?>"
                >


                <div class="form-grid">


                    <!-- NAME -->

                    <div class="field">

                        <label for="full_name">
                            Full Name
                        </label>

                        <div class="input-wrap">

                            <i class="fa-regular fa-user input-icon"></i>

                            <input
                                type="text"
                                id="full_name"
                                name="full_name"
                                value="<?= e($fullName); ?>"
                                placeholder="Your full name"
                                maxlength="150"
                                autocomplete="name"
                                required
                                autofocus
                            >

                        </div>

                    </div>


                    <!-- EMAIL -->

                    <div class="field">

                        <label for="email">
                            Email Address
                        </label>

                        <div class="input-wrap">

                            <i class="fa-regular fa-envelope input-icon"></i>

                            <input
                                type="email"
                                id="email"
                                name="email"
                                value="<?= e($email); ?>"
                                placeholder="you@example.com"
                                maxlength="190"
                                autocomplete="email"
                                required
                            >

                        </div>

                    </div>


                    <!-- MOBILE -->

                    <div class="field">

                        <label for="mobile">
                            Mobile Number
                        </label>

                        <div class="input-wrap">

                            <i class="fa-solid fa-mobile-screen input-icon"></i>

                            <input
                                type="tel"
                                id="mobile"
                                name="mobile"
                                value="<?= e($mobile); ?>"
                                placeholder="10-digit mobile number"
                                maxlength="15"
                                inputmode="numeric"
                                autocomplete="tel"
                                required
                            >

                        </div>

                    </div>


                    <!-- COUNTRY -->

                    <div class="field">

                        <label for="country">
                            Country
                        </label>

                        <div class="input-wrap">

                            <i class="fa-solid fa-earth-asia input-icon"></i>

                            <select
                                id="country"
                                name="country"
                                required
                            >

                                <option value="India" <?= $country === 'India' ? 'selected' : ''; ?>>
                                    India
                                </option>

                                <option value="United States" <?= $country === 'United States' ? 'selected' : ''; ?>>
                                    United States
                                </option>

                                <option value="United Kingdom" <?= $country === 'United Kingdom' ? 'selected' : ''; ?>>
                                    United Kingdom
                                </option>

                                <option value="United Arab Emirates" <?= $country === 'United Arab Emirates' ? 'selected' : ''; ?>>
                                    United Arab Emirates
                                </option>

                                <option value="Canada" <?= $country === 'Canada' ? 'selected' : ''; ?>>
                                    Canada
                                </option>

                                <option value="Australia" <?= $country === 'Australia' ? 'selected' : ''; ?>>
                                    Australia
                                </option>

                                <option value="Singapore" <?= $country === 'Singapore' ? 'selected' : ''; ?>>
                                    Singapore
                                </option>

                                <option value="Other" <?= $country === 'Other' ? 'selected' : ''; ?>>
                                    Other
                                </option>

                            </select>

                        </div>

                    </div>


                    <!-- PASSWORD -->

                    <div class="field">

                        <label for="password">
                            Password
                        </label>

                        <div class="input-wrap">

                            <i class="fa-solid fa-lock input-icon"></i>

                            <input
                                type="password"
                                id="password"
                                name="password"
                                placeholder="Create password"
                                minlength="8"
                                autocomplete="new-password"
                                required
                            >

                            <button
                                type="button"
                                class="password-toggle"
                                data-target="password"
                                aria-label="Show password"
                            >
                                <i class="fa-regular fa-eye"></i>
                            </button>

                        </div>

                        <div class="password-help">
                            Minimum 8 characters with uppercase,
                            lowercase and a number.
                        </div>

                    </div>


                    <!-- CONFIRM PASSWORD -->

                    <div class="field">

                        <label for="confirm_password">
                            Confirm Password
                        </label>

                        <div class="input-wrap">

                            <i class="fa-solid fa-lock input-icon"></i>

                            <input
                                type="password"
                                id="confirm_password"
                                name="confirm_password"
                                placeholder="Repeat password"
                                minlength="8"
                                autocomplete="new-password"
                                required
                            >

                            <button
                                type="button"
                                class="password-toggle"
                                data-target="confirm_password"
                                aria-label="Show password"
                            >
                                <i class="fa-regular fa-eye"></i>
                            </button>

                        </div>

                    </div>


                </div>


                <!-- TERMS -->

                <label class="terms">

                    <input
                        type="checkbox"
                        name="terms"
                        value="1"
                        required
                    >

                    <span>
                        I agree to the
                        <a href="<?= e(BASE_URL); ?>terms.php" target="_blank">
                            Terms & Conditions
                        </a>
                        and
                        <a href="<?= e(BASE_URL); ?>privacy.php" target="_blank">
                            Privacy Policy
                        </a>.
                    </span>

                </label>


                <!-- REGISTER -->

                <button
                    type="submit"
                    class="register-button"
                    id="registerButton"
                >

                    <span>Create Account</span>

                    <i class="fa-solid fa-arrow-right"></i>

                </button>


            </form>


            
            <?php endif; ?>


<div class="login-link">

                Already have an account?

                <a href="<?= e(BASE_URL); ?>login.php">
                    Sign in
                </a>

            </div>


            <div class="security">

                <i class="fa-solid fa-shield-halved"></i>

                Your account is protected with secure email verification.

            </div>


        </div>

    </section>


</div>


<script>

/*
|--------------------------------------------------------------------------
| PASSWORD VISIBILITY
|--------------------------------------------------------------------------
*/

document
    .querySelectorAll('.password-toggle')
    .forEach(function (button) {

        button.addEventListener(
            'click',
            function () {

                const targetId =
                    button.getAttribute('data-target');

                const input =
                    document.getElementById(targetId);

                const icon =
                    button.querySelector('i');

                if (!input || !icon) {
                    return;
                }

                const visible =
                    input.type === 'text';

                input.type =
                    visible
                        ? 'password'
                        : 'text';

                icon.classList.toggle(
                    'fa-eye',
                    visible
                );

                icon.classList.toggle(
                    'fa-eye-slash',
                    !visible
                );

                button.setAttribute(
                    'aria-label',
                    visible
                        ? 'Show password'
                        : 'Hide password'
                );
            }
        );
    });


/*
|--------------------------------------------------------------------------
| MOBILE INPUT
|--------------------------------------------------------------------------
*/

const mobileInput =
    document.getElementById('mobile');

if (mobileInput) {

    mobileInput.addEventListener(
        'input',
        function () {

            this.value =
                this.value.replace(
                    /[^0-9+]/g,
                    ''
                );
        }
    );
}


/*
|--------------------------------------------------------------------------
| PASSWORD MATCH
|--------------------------------------------------------------------------
*/

const passwordInput =
    document.getElementById('password');

const confirmInput =
    document.getElementById('confirm_password');


function validatePasswordMatch() {

    if (
        !passwordInput
        ||
        !confirmInput
    ) {
        return;
    }

    if (
        confirmInput.value !== ''
        &&
        passwordInput.value !== confirmInput.value
    ) {

        confirmInput.setCustomValidity(
            'Passwords do not match.'
        );

    } else {

        confirmInput.setCustomValidity('');
    }
}


if (
    passwordInput
    &&
    confirmInput
) {

    passwordInput.addEventListener(
        'input',
        validatePasswordMatch
    );

    confirmInput.addEventListener(
        'input',
        validatePasswordMatch
    );
}


/*
|--------------------------------------------------------------------------
| PREVENT DOUBLE SUBMISSION
|--------------------------------------------------------------------------
*/

const registerForm =
    document.getElementById('registerForm');

const registerButton =
    document.getElementById('registerButton');


if (
    registerForm
    &&
    registerButton
) {

    registerForm.addEventListener(
        'submit',
        function () {

            registerButton.disabled = true;

            registerButton.innerHTML =
                <?= $googleRegistration
                    ? "'<i class=\"fa-solid fa-circle-notch fa-spin\"></i> Completing Registration...'"
                    : "'<i class=\"fa-solid fa-circle-notch fa-spin\"></i> Creating Account...'"
                ?>;
        }
    );
}

</script>


<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>