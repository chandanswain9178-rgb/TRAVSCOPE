<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE STEP 11F - DESTINATION-WISE HOTEL ALLOCATION ENGINE
|--------------------------------------------------------------------------
| Supplier hotel inventory remains the source pool. A quotation freezes a
| destination/night/category hotel plan without exposing supplier cost.
| The accepted quotation keeps its own allocation rows and final vouchers
| include only the latest allocation state for that accepted version.
*/


function tsHAStrLower(string $value): string
{
    return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
}

function tsHAStrLen(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
}

function tsHAStrSub(string $value, int $start, int $length): string
{
    return function_exists('mb_substr') ? mb_substr($value, $start, $length, 'UTF-8') : substr($value, $start, $length);
}

function tsHAStrRipos(string $haystack, string $needle)
{
    return function_exists('mb_strripos') ? mb_strripos($haystack, $needle, 0, 'UTF-8') : strripos($haystack, $needle);
}

function tsHATableExists(PDO $pdo, string $table): bool
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
    try { $s=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?"); $s->execute([$table]); if ((int)$s->fetchColumn()>0) return true; } catch (Throwable $e) {}
    try { $pdo->query('SELECT 1 FROM `'.$table.'` LIMIT 0'); return true; } catch (Throwable $e) {}
    try { $q=$pdo->quote($table); if ($q!==false) { $s=$pdo->query('SHOW TABLES LIKE '.$q); return $s?(bool)$s->fetchColumn():false; } } catch (Throwable $e) {}
    return false;
}

function tsHAReady(PDO $pdo): bool
{
    return tsHATableExists($pdo, 'trip_hotel_allocations');
}

function tsHANormalizeCity(string $value): string
{
    $value = trim($value);
    if ($value === '') return '';
    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if ($converted !== false) $value = $converted;
    }
    $value = strtolower($value);
    $value = preg_replace('/\b(?:hotel|resort|houseboat|overnight|stay|at|in|the)\b/', ' ', $value) ?? $value;
    $value = preg_replace('/[^a-z0-9]+/', ' ', $value) ?? $value;
    $value = preg_replace('/\s+/', ' ', $value) ?? $value;
    $value = trim($value);

    $aliases = [
        'phalgam' => 'pahalgam',
        'pahal gam' => 'pahalgam',
        'srinager' => 'srinagar',
        'srinaagr' => 'srinagar',
        'gul marg' => 'gulmarg',
        'sona marg' => 'sonamarg',
        'trivandrum' => 'thiruvananthapuram',
        'portblair' => 'port blair',
    ];
    return $aliases[$value] ?? $value;
}

function tsHACleanCityLabel(string $value): string
{
    $value = trim(html_entity_decode(strip_tags($value), ENT_QUOTES, 'UTF-8'));
    $value = preg_replace('/\s+/', ' ', $value) ?? $value;
    $value = preg_replace('/^(?:hotel|resort|houseboat)\s+(?:at|in)\s+/iu', '', $value) ?? $value;
    $value = preg_replace('/\s+(?:hotel|resort|houseboat)$/iu', '', $value) ?? $value;
    $value = trim($value, " .,:;-\t\n\r\0\x0B");
    if (tsHAStrLen($value) > 80) $value = tsHAStrSub($value, 0, 80);

    $norm = tsHANormalizeCity($value);
    $pretty = [
        'pahalgam' => 'Pahalgam',
        'srinagar' => 'Srinagar',
        'gulmarg' => 'Gulmarg',
        'sonamarg' => 'Sonamarg',
        'thiruvananthapuram' => 'Thiruvananthapuram',
        'port blair' => 'Port Blair',
    ];
    return $pretty[$norm] ?? ucwords($value);
}

function tsHAStar($value): ?int
{
    if ($value === null || $value === '') return null;
    if (is_numeric($value)) {
        $n = (int)$value;
        return in_array($n, [2,3,4,5], true) ? $n : null;
    }
    if (preg_match('/\b([2-5])\s*(?:star|\*)/iu', (string)$value, $m)) return (int)$m[1];
    if (preg_match('/\bfive\s*star\b/iu', (string)$value)) return 5;
    return null;
}

function tsHAItineraryArray($raw): array
{
    if (is_array($raw)) $days = $raw;
    elseif (is_string($raw) && trim($raw) !== '') {
        $decoded = json_decode($raw, true);
        $days = is_array($decoded) ? $decoded : [];
    } else $days = [];

    $out = [];
    foreach ($days as $index => $day) {
        if (!is_array($day)) continue;
        $title = trim((string)($day['title'] ?? ''));
        $description = trim((string)($day['description'] ?? ''));
        if ($title === '' && $description === '') continue;
        $out[] = [
            'day_number' => max(1, (int)($day['day_number'] ?? ($index + 1))),
            'title' => $title,
            'description' => $description,
        ];
    }
    usort($out, static fn($a,$b) => ((int)$a['day_number']) <=> ((int)$b['day_number']));
    return array_values($out);
}

function tsHAKnownInventoryCities(PDO $pdo, ?int $contractVersionId = null): array
{
    if (!tsHATableExists($pdo, 'supplier_contract_hotel_inventory')) return [];
    try {
        $sql = "SELECT DISTINCT city FROM supplier_contract_hotel_inventory WHERE status IN ('active','review') AND city<>''";
        $params = [];
        if ($contractVersionId && $contractVersionId > 0) {
            $sql .= " AND contract_version_id=?";
            $params[] = $contractVersionId;
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $out = [];
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) ?: [] as $city) {
            $city = trim((string)$city);
            if ($city === '') continue;
            $out[tsHANormalizeCity($city)] = $city;
        }
        return $out;
    } catch (Throwable $e) {
        return [];
    }
}


function tsHAKnownHotelMasterCities(PDO $pdo): array
{
    $out=[];
    if (tsHATableExists($pdo,'destination_locations')) {
        try {
            $sql="SELECT dl.location_name FROM destination_locations dl WHERE dl.status='active' AND TRIM(COALESCE(dl.location_name,''))<>''";
            foreach($pdo->query($sql)->fetchAll(PDO::FETCH_COLUMN)?:[] as $city){
                $city=trim((string)$city);if($city==='')continue;$out[tsHANormalizeCity($city)]=$city;
            }
        } catch(Throwable $ignored) {}
    }
    if (tsHATableExists($pdo,'hotels')) {
        try {
            $sql="SELECT DISTINCT COALESCE(NULLIF(dl.location_name,''),NULLIF(h.city,''),d.name) city FROM hotels h LEFT JOIN destination_locations dl ON dl.id=h.location_id LEFT JOIN destinations d ON d.id=h.destination_id WHERE h.status='active'";
            foreach($pdo->query($sql)->fetchAll(PDO::FETCH_COLUMN)?:[] as $city){
                $city=trim((string)$city);if($city==='')continue;$out[tsHANormalizeCity($city)]=$city;
            }
        } catch(Throwable $ignored) {}
    }
    return $out;
}

function tsHACanonicalKnownCity(string $city, array $knownCities): string
{
    $city=tsHACleanCityLabel($city);$norm=tsHANormalizeCity($city);if($norm===''||!$knownCities)return $city;
    if(isset($knownCities[$norm]))return (string)$knownCities[$norm];
    if(strlen($norm)<4)return $city;
    $matches=[];
    foreach($knownCities as $knownNorm=>$label){
        if($knownNorm===''||strlen($knownNorm)<4)continue;
        if(str_starts_with($knownNorm,$norm)||str_starts_with($norm,$knownNorm))$matches[(string)$knownNorm]=(string)$label;
    }
    return count($matches)===1 ? (string)reset($matches) : $city;
}

function tsHACitiesEquivalent(string $a,string $b): bool
{
    $na=tsHANormalizeCity($a);$nb=tsHANormalizeCity($b);if($na===''||$nb==='')return false;if($na===$nb)return true;
    if(strlen($na)>=4 && strlen($nb)>=4 && (str_starts_with($na,$nb)||str_starts_with($nb,$na)))return true;
    return false;
}

function tsHADetectNight(array $day, array $knownCities = []): array
{
    $title = trim((string)($day['title'] ?? ''));
    $description = trim((string)($day['description'] ?? ''));
    $text = trim($title . "\n" . $description);

    $type = 'hotel';
    if (preg_match('/\bhouse\s*boat\b|\bhouseboat\b/iu', $text)) $type = 'houseboat';
    elseif (preg_match('/\bcamp\b|\btent\b/iu', $text)) $type = 'camp';
    elseif (preg_match('/\bresort\b/iu', $text)) $type = 'resort';

    $city = '';
    $patterns = [
        '/overnight\s+stay\s*:\s*([^\r\n.;,]+)/iu',
        '/overnight\s+(?:stay\s+)?(?:in|at)\s+(?:the\s+)?(?:hotel|resort|house\s*boat|houseboat)?\s*(?:at|in)?\s*([^\r\n.;,]+)/iu',
        '/overnight\s+(?:at|in)\s+([^\r\n.;,]+)/iu',
    ];
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $text, $m)) {
            $candidate = tsHACleanCityLabel((string)$m[1]);
            if ($candidate !== '') { $city = $candidate; break; }
        }
    }

    if ($city === '' && $knownCities) {
        $bestPos = -1;
        $bestCity = '';
        $hay = tsHAStrLower($text);
        foreach ($knownCities as $norm => $label) {
            if ($norm === '') continue;
            $pos = tsHAStrRipos($hay, tsHAStrLower((string)$label));
            if ($pos !== false && $pos > $bestPos) {
                $bestPos = $pos;
                $bestCity = (string)$label;
            }
        }
        if ($bestCity !== '') $city = tsHACleanCityLabel($bestCity);
    }

    if ($city === '' && $title !== '' && !preg_match('/\bdeparture\b|\bdepart\b|airport\s+drop/iu', $title)) {
        $parts = preg_split('/\s*(?:→|–|—|->|\-|\bto\b)\s*/iu', $title) ?: [];
        for ($i = count($parts)-1; $i >= 0; $i--) {
            $candidate = trim((string)$parts[$i]);
            $candidate = preg_replace('/\([^)]*\)/u', '', $candidate) ?? $candidate;
            $candidate = preg_replace('/\b(?:approx|kms?|hours?|drive|local sightseeing|sightseeing|shikara ride|pickup|pick up)\b.*$/iu', '', $candidate) ?? $candidate;
            $candidate = tsHACleanCityLabel($candidate);
            if ($candidate !== '' && tsHAStrLen($candidate) <= 60 && !preg_match('/\bdeparture\b|\bairport\b/iu', $candidate)) {
                $city = $candidate;
                break;
            }
        }
    }

    return [
        'city' => $city,
        'accommodation_type' => $type,
        'confidence' => $city !== '' ? 'detected' : 'review',
    ];
}

function tsHASelectedContractContext(PDO $pdo, int $tripId): ?array
{
    if (
        $tripId <= 0
        || !tsHATableExists($pdo, 'cost_sheet_contract_package_sources')
        || !tsHATableExists($pdo, 'supplier_contract_rate_groups')
    ) return null;

    try {
        $stmt = $pdo->prepare("\n            SELECT\n                cs.contract_version_id, cs.itinerary_id, cs.rate_group_id,\n                g.supplier_id, g.supplier_category, g.mapped_star_category, g.meal_plan,\n                c.contract_code, c.contract_name, s.company_name supplier_name\n            FROM cost_sheet_contract_package_sources cs\n            JOIN supplier_contract_rate_groups g ON g.id=cs.rate_group_id\n            LEFT JOIN supplier_contracts c ON c.id=g.contract_id\n            LEFT JOIN suppliers s ON s.id=g.supplier_id\n            WHERE cs.trip_id=?\n            ORDER BY cs.id DESC\n            LIMIT 1\n        ");
        $stmt->execute([$tripId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

function tsHAHotelPool(
    PDO $pdo,
    string $city,
    ?int $hotelCategory,
    ?array $contractContext = null
): array {
    $cityNorm = tsHANormalizeCity($city);
    if ($cityNorm === '') return [];
    if (empty($contractContext['supplier_id'])) return [];

    /*
    | V21 source rule:
    | Supplier hotel choices are maintained once per supplier, not per package
    | or season. Package cost still comes from the selected seasonal package
    | rate group; this pool only supplies eligible accommodation names.
    */
    if (tsHATableExists($pdo, 'supplier_hotel_options')) {
        try {
            $sql = "SELECT o.*,s.company_name supplier_name,h.hotel_name canonical_hotel_name,'supplier_option' source_kind
                    FROM supplier_hotel_options o
                    LEFT JOIN suppliers s ON s.id=o.supplier_id
                    LEFT JOIN hotels h ON h.id=o.hotel_id
                    WHERE o.status='active' AND o.supplier_id=?
                    ORDER BY CASE WHEN o.hotel_id IS NOT NULL THEN 0 ELSE 1 END,o.sort_order,o.id";
            $st=$pdo->prepare($sql);$st->execute([(int)$contractContext['supplier_id']]);$rows=$st->fetchAll(PDO::FETCH_ASSOC)?:[];
            $exactCategory=trim((string)($contractContext['supplier_category']??''));$exact=[];$star=[];
            foreach($rows as $row){
                $rowCity=(string)($row['city']??'');
                if(!tsHACitiesEquivalent($rowCity,$city))continue;
                if($exactCategory!=='' && strcasecmp(trim((string)($row['supplier_category']??'')),$exactCategory)===0){$exact[]=$row;continue;}
                if($hotelCategory!==null && (int)($row['mapped_star_category']??0)===$hotelCategory)$star[]=$row;
            }
            if($exact)return $exact;
            if($star)return $star;
            return [];
        } catch(Throwable $e) { return []; }
    }

    // Legacy fallback for installations that have not yet migrated to V21.
    if (!tsHATableExists($pdo, 'supplier_contract_hotel_inventory')) return [];
    $sql = "SELECT i.*,s.company_name supplier_name,c.contract_code,c.contract_name,h.hotel_name canonical_hotel_name,'legacy_inventory' source_kind
            FROM supplier_contract_hotel_inventory i
            LEFT JOIN suppliers s ON s.id=i.supplier_id
            LEFT JOIN supplier_contracts c ON c.id=i.contract_id
            LEFT JOIN hotels h ON h.id=i.hotel_id
            WHERE i.status='active' AND i.supplier_id=?
            ORDER BY CASE i.mapping_status WHEN 'matched' THEN 0 WHEN 'created' THEN 1 ELSE 2 END,i.source_order,i.id";
    try{$st=$pdo->prepare($sql);$st->execute([(int)$contractContext['supplier_id']]);$rows=$st->fetchAll(PDO::FETCH_ASSOC)?:[];}catch(Throwable $e){return [];}
    $exactCategory=trim((string)($contractContext['supplier_category']??''));$exact=[];$star=[];
    foreach($rows as $row){
        if(!tsHACitiesEquivalent((string)($row['city']??''),$city))continue;
        if($exactCategory!==''&&strcasecmp(trim((string)($row['supplier_category']??'')),$exactCategory)===0){$exact[]=$row;continue;}
        if($hotelCategory!==null&&(int)($row['mapped_star_category']??0)===$hotelCategory)$star[]=$row;
    }
    return $exact?:$star;
}

function tsHAHotelMasterPool(
    PDO $pdo,
    string $city,
    ?int $hotelCategory,
    ?int $destinationId = null
): array {
    if (!tsHATableExists($pdo, 'hotels')) return [];
    $cityNorm = tsHANormalizeCity($city);
    if ($cityNorm === '') return [];

    $hasImage = false;
    try {
        $st=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='hotels' AND column_name='primary_image'");
        $st->execute();
        $hasImage=(int)$st->fetchColumn()>0;
    } catch (Throwable $ignored) {}
    $imageExpr = $hasImage ? 'h.primary_image' : 'NULL';

    $where = ["h.status='active'"];
    $params = [];
    if ($destinationId && $destinationId > 0) {
        $where[] = 'h.destination_id=?';
        $params[] = $destinationId;
    }
    if ($hotelCategory && in_array($hotelCategory,[3,4,5],true)) {
        $where[] = 'h.star_category=?';
        $params[] = $hotelCategory;
    }

    $sql = "SELECT h.id,h.destination_id,h.location_id,h.hotel_name,h.city,h.star_category,
                   h.default_room_type,h.default_meal_plan,h.is_preferred,h.priority_order,
                   h.preferred_supplier_id,{$imageExpr} primary_image,
                   d.name destination_name,dl.location_name,s.company_name supplier_name
            FROM hotels h
            JOIN destinations d ON d.id=h.destination_id
            LEFT JOIN destination_locations dl ON dl.id=h.location_id
            LEFT JOIN suppliers s ON s.id=h.preferred_supplier_id
            WHERE ".implode(' AND ',$where)."
            ORDER BY h.is_preferred DESC,h.priority_order,h.hotel_name";
    try {
        $st=$pdo->prepare($sql);$st->execute($params);$rows=$st->fetchAll(PDO::FETCH_ASSOC)?:[];
    } catch (Throwable $e) { return []; }

    $exact=[];$destinationWide=[];
    foreach($rows as $row){
        $loc=(string)($row['location_name'] ?: ($row['city'] ?? ''));
        if(tsHACitiesEquivalent($loc,$city)){$exact[]=$row;continue;}
        if(tsHACitiesEquivalent((string)$row['destination_name'],$city))$destinationWide[]=$row;
    }
    $picked=$exact ?: $destinationWide;
    // If a parent destination id was stale/mismatched but the city is exact, retry
    // without the parent filter. This keeps City -> Hotel matching authoritative.
    if(!$picked && $destinationId && $destinationId>0){
        return tsHAHotelMasterPool($pdo,$city,$hotelCategory,null);
    }
    return array_slice($picked,0,60);
}

function tsHAHotelMasterCandidate(PDO $pdo, int $hotelId, array $allocation): ?array
{
    if ($hotelId <= 0 || !tsHATableExists($pdo,'hotels')) return null;
    $hasImage=false;
    try{$st=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='hotels' AND column_name='primary_image'");$st->execute();$hasImage=(int)$st->fetchColumn()>0;}catch(Throwable $ignored){}
    $imageExpr=$hasImage?'h.primary_image':'NULL';
    $st=$pdo->prepare("SELECT h.*,{$imageExpr} primary_image,d.name destination_name,dl.location_name,s.company_name supplier_name FROM hotels h JOIN destinations d ON d.id=h.destination_id LEFT JOIN destination_locations dl ON dl.id=h.location_id LEFT JOIN suppliers s ON s.id=h.preferred_supplier_id WHERE h.id=? AND h.status='active' LIMIT 1");
    $st->execute([$hotelId]);$row=$st->fetch(PDO::FETCH_ASSOC);if(!$row)return null;

    $allocationDestinationId=(int)($allocation['destination_id']??0);
    $allocationCity=tsHANormalizeCity((string)($allocation['destination_name']??''));
    $hotelCity=tsHANormalizeCity((string)($row['location_name'] ?: ($row['city']??'')));
    $hotelDestination=tsHANormalizeCity((string)($row['destination_name']??''));
    if($allocationDestinationId>0 && (int)$row['destination_id']!==$allocationDestinationId
       && !tsHACitiesEquivalent($hotelCity,$allocationCity)
       && !tsHACitiesEquivalent($hotelDestination,$allocationCity))return null;
    $star=(int)($allocation['hotel_category']??0);
    if($star>0 && (int)$row['star_category']!==$star)return null;
    if($allocationCity!=='' && !tsHACitiesEquivalent($hotelCity,$allocationCity) && !tsHACitiesEquivalent($hotelDestination,$allocationCity))return null;
    return $row;
}

function tsHASupplierOptionCandidate(PDO $pdo, int $optionId, array $allocation): ?array
{
    if ($optionId <= 0 || !tsHATableExists($pdo,'supplier_hotel_options')) return null;
    $st=$pdo->prepare("SELECT o.*,h.hotel_name canonical_hotel_name FROM supplier_hotel_options o LEFT JOIN hotels h ON h.id=o.hotel_id WHERE o.id=? AND o.status='active' LIMIT 1");
    $st->execute([$optionId]);$row=$st->fetch(PDO::FETCH_ASSOC);if(!$row)return null;
    if(!empty($allocation['source_supplier_id']) && (int)$row['supplier_id']!==(int)$allocation['source_supplier_id'])return null;
    if(!tsHACitiesEquivalent((string)($row['city']??''),(string)($allocation['destination_name']??'')))return null;
    $allocationCategory=trim((string)($allocation['source_inventory_category']??''));
    if($allocationCategory!=='' && strcasecmp(trim((string)($row['supplier_category']??'')),$allocationCategory)!==0){
        $star=!empty($allocation['hotel_category'])?(int)$allocation['hotel_category']:0;
        if($star<=0 || (int)($row['mapped_star_category']??0)!==$star)return null;
    }
    return $row;
}

function tsHAInventoryCandidate(PDO $pdo, int $inventoryId, array $allocation): ?array
{
    if ($inventoryId <= 0 || !tsHATableExists($pdo, 'supplier_contract_hotel_inventory')) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT i.*, h.hotel_name canonical_hotel_name
        FROM supplier_contract_hotel_inventory i
        LEFT JOIN hotels h ON h.id=i.hotel_id
        WHERE i.id=?
          AND i.status='active'
        LIMIT 1
    ");
    $stmt->execute([$inventoryId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) return null;

    if (
        !empty($allocation['source_contract_version_id'])
        && (int)$row['contract_version_id'] !== (int)$allocation['source_contract_version_id']
    ) {
        return null;
    }

    if (
        !empty($allocation['source_supplier_id'])
        && (int)$row['supplier_id'] !== (int)$allocation['source_supplier_id']
    ) {
        return null;
    }

    if (!tsHACitiesEquivalent((string)$row['city'], (string)($allocation['destination_name'] ?? ''))) {
        return null;
    }

    $allocationCategory = trim((string)($allocation['source_inventory_category'] ?? ''));
    if (
        $allocationCategory !== ''
        && strcasecmp(trim((string)$row['supplier_category']), $allocationCategory) !== 0
    ) {
        $star = !empty($allocation['hotel_category']) ? (int)$allocation['hotel_category'] : 0;
        if ($star <= 0 || (int)($row['mapped_star_category'] ?? 0) !== $star) {
            return null;
        }
    }

    return $row;
}

function tsHAQuotationInfo(PDO $pdo, int $versionId): ?array
{
    try {
        $stmt = $pdo->prepare("\n            SELECT v.*, t.id trip_id, t.trip_code, t.enquiry_id,\n                   e.destination customer_destination, e.destination_id customer_destination_id\n            FROM crm_package_versions v\n            LEFT JOIN trips t ON t.enquiry_id=v.lead_id\n            LEFT JOIN enquiries e ON e.id=v.lead_id\n            WHERE v.id=? LIMIT 1\n        ");
        $stmt->execute([$versionId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

function tsHAOvernightSegments(
    PDO $pdo,
    array $itinerary,
    ?string $travelDate,
    int $durationNights,
    ?int $contractVersionId = null
): array {
    $days = tsHAItineraryArray($itinerary);
    if (!$days || $durationNights <= 0) return [];

    $knownCities = array_replace(tsHAKnownHotelMasterCities($pdo), tsHAKnownInventoryCities($pdo, $contractVersionId));
    $nightRows = [];
    $nightIndex = 0;

    foreach ($days as $day) {
        if ($nightIndex >= $durationNights) break;
        $detected = tsHADetectNight($day, $knownCities);
        $city = trim((string)$detected['city']);
        if ($city !== '') $city = tsHACanonicalKnownCity($city, $knownCities);
        if ($city === '' && preg_match('/\bdeparture\b|\bdepart\b/iu', (string)$day['title'])) continue;

        $checkIn = null;
        if ($travelDate && strtotime($travelDate) !== false) {
            $checkIn = date('Y-m-d', strtotime($travelDate . ' +' . $nightIndex . ' day'));
        }
        $nightRows[] = [
            'city' => $city !== '' ? $city : 'Overnight destination to review',
            'accommodation_type' => (string)$detected['accommodation_type'],
            'check_in_date' => $checkIn,
            'day_number' => (int)$day['day_number'],
            'source_title' => (string)$day['title'],
        ];
        $nightIndex++;
    }

    // If the itinerary had fewer useful day rows than nights, keep explicit review rows.
    while ($nightIndex < $durationNights) {
        $checkIn = null;
        if ($travelDate && strtotime($travelDate) !== false) {
            $checkIn = date('Y-m-d', strtotime($travelDate . ' +' . $nightIndex . ' day'));
        }
        $nightRows[] = [
            'city' => 'Overnight destination to review',
            'accommodation_type' => 'hotel',
            'check_in_date' => $checkIn,
            'day_number' => $nightIndex + 1,
            'source_title' => '',
        ];
        $nightIndex++;
    }

    $segments = [];
    foreach ($nightRows as $row) {
        $norm = tsHANormalizeCity((string)$row['city']);
        $type = (string)$row['accommodation_type'];
        $lastIndex = count($segments) - 1;
        if (
            $lastIndex >= 0
            && (string)$segments[$lastIndex]['city_norm'] === $norm
            && (string)$segments[$lastIndex]['accommodation_type'] === $type
        ) {
            $segments[$lastIndex]['nights']++;
            if (!empty($segments[$lastIndex]['check_in_date'])) {
                $segments[$lastIndex]['check_out_date'] = date(
                    'Y-m-d',
                    strtotime($segments[$lastIndex]['check_in_date'] . ' +' . $segments[$lastIndex]['nights'] . ' day')
                );
            }
            continue;
        }

        $checkOut = null;
        if (!empty($row['check_in_date'])) {
            $checkOut = date('Y-m-d', strtotime($row['check_in_date'] . ' +1 day'));
        }
        $segments[] = [
            'city' => (string)$row['city'],
            'city_norm' => $norm,
            'accommodation_type' => $type,
            'check_in_date' => $row['check_in_date'],
            'check_out_date' => $checkOut,
            'nights' => 1,
            'source_day' => (int)$row['day_number'],
        ];
    }
    return $segments;
}

function tsHAEvent(PDO $pdo, array $allocation, string $type, ?string $oldStatus, ?string $newStatus, string $message, int $adminId): void
{
    if (!tsHATableExists($pdo, 'trip_hotel_allocation_events')) return;
    try {
        $stmt = $pdo->prepare("\n            INSERT INTO trip_hotel_allocation_events\n            (allocation_id,trip_id,quotation_version_id,booking_id,event_type,old_status,new_status,message,admin_id)\n            VALUES (?,?,?,?,?,?,?,?,?)\n        ");
        $stmt->execute([
            (int)($allocation['id'] ?? 0),
            (int)($allocation['trip_id'] ?? 0),
            (int)($allocation['quotation_version_id'] ?? 0),
            !empty($allocation['booking_id']) ? (int)$allocation['booking_id'] : null,
            $type,
            $oldStatus,
            $newStatus,
            $message !== '' ? $message : null,
            $adminId > 0 ? $adminId : null,
        ]);
    } catch (Throwable $e) {
        error_log('Hotel allocation event: ' . $e->getMessage());
    }
}

function tsHABuildForQuotation(
    PDO $pdo,
    int $tripId,
    int $versionId,
    $hotelCategory = null,
    ?string $travelDate = null,
    $itinerary = null,
    int $adminId = 0,
    bool $force = false
): array {
    if (!tsHAReady($pdo)) return ['created'=>0,'rows'=>[],'warning'=>'Step 11F SQL is not installed.'];
    $version = tsHAQuotationInfo($pdo, $versionId);
    if (!$version || (int)($version['trip_id'] ?? 0) !== $tripId) {
        throw new RuntimeException('Quotation/Trip hotel allocation context was not found.');
    }

    $existing = tsHAForQuotation($pdo, $versionId);
    if ($existing && !$force) return ['created'=>0,'rows'=>$existing,'warning'=>'Existing allocation plan kept.'];
    if ($force) {
        foreach ($existing as $row) {
            if (!empty($row['booking_id']) || in_array((string)$row['allocation_status'], ['requested','confirmed'], true)) {
                throw new RuntimeException('This hotel plan is already requested/confirmed. Create a new quotation version instead of rebuilding it.');
            }
        }
        $pdo->prepare("DELETE FROM trip_hotel_allocations WHERE quotation_version_id=?")->execute([$versionId]);
    }

    $snapshot = [];
    $decoded = json_decode((string)($version['custom_notes'] ?? ''), true);
    if (is_array($decoded)) $snapshot = $decoded;
    $itineraryArray = tsHAItineraryArray($itinerary ?? ($snapshot['itinerary_days'] ?? $version['itinerary'] ?? []));
    $durationNights = max(0, (int)($snapshot['duration_nights'] ?? 0));
    if ($durationNights <= 0) $durationNights = max(0, count($itineraryArray) - 1);
    if ($durationNights <= 0) return ['created'=>0,'rows'=>[],'warning'=>'No package nights were found.'];

    $travelDate = trim((string)($travelDate ?? $version['travel_date'] ?? '')) ?: null;
    $star = tsHAStar($hotelCategory ?? $version['hotel_category'] ?? $snapshot['pricing']['hotel_category'] ?? null);
    $context = tsHASelectedContractContext($pdo, $tripId);
    if ($star === null && !empty($context['mapped_star_category'])) $star = (int)$context['mapped_star_category'];
    $segments = tsHAOvernightSegments($pdo, $itineraryArray, $travelDate, $durationNights, !empty($context['contract_version_id']) ? (int)$context['contract_version_id'] : null);

    $insert = $pdo->prepare("\n        INSERT INTO trip_hotel_allocations\n        (trip_id,enquiry_id,quotation_version_id,booking_id,source_supplier_id,source_contract_version_id,source_inventory_category,destination_id,destination_name,accommodation_type,check_in_date,check_out_date,nights,hotel_category,selection_mode,hotel_id,hotel_name_snapshot,alternatives_json,room_type,meal_plan,allocation_status,sort_order,created_by_admin_id,updated_by_admin_id)\n        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)\n    ");

    $created = 0;
    foreach ($segments as $index => $segment) {
        $city = (string)$segment['city'];
        $pool = [];
        if ($segment['accommodation_type'] !== 'houseboat' && tsHANormalizeCity($city) !== 'destination to review') {
            $pool = tsHAHotelPool($pdo, $city, $star, $context);
        }

        $alternatives = [];
        foreach ($pool as $candidate) {
            $name = trim((string)($candidate['canonical_hotel_name'] ?? $candidate['hotel_name'] ?? ''));
            if ($name === '') continue;
            $sourceKind=(string)($candidate['source_kind']??'legacy_inventory');
            $alternatives[] = [
                'inventory_id' => $sourceKind==='legacy_inventory' ? (int)($candidate['id'] ?? 0) : 0,
                'option_id' => $sourceKind==='supplier_option' ? (int)($candidate['id'] ?? 0) : 0,
                'source_kind' => $sourceKind,
                'hotel_id' => !empty($candidate['hotel_id']) ? (int)$candidate['hotel_id'] : null,
                'name' => $name,
                'supplier_hotel_name' => (string)($candidate['hotel_name'] ?? $name),
                'room_type' => (string)($candidate['room_type'] ?? ''),
                'meal_plan' => (string)($candidate['meal_plan'] ?? ''),
            ];
        }
        // Avoid giant quotation cells; retain a generous list while keeping JSON manageable.
        $alternatives = array_slice($alternatives, 0, 20);
        $first = $pool[0] ?? [];
        $roomType = trim((string)($first['room_type'] ?? ''));
        $mealPlan = trim((string)($first['meal_plan'] ?? $context['meal_plan'] ?? ''));
        $selectionMode = $pool ? 'supplier_option_pool' : 'supplier_option_pool_missing';
        $status = 'proposed';

        $insert->execute([
            $tripId,
            (int)$version['lead_id'],
            $versionId,
            null,
            !empty($first['supplier_id']) ? (int)$first['supplier_id'] : (!empty($context['supplier_id']) ? (int)$context['supplier_id'] : null),
            !empty($first['contract_version_id']) ? (int)$first['contract_version_id'] : (!empty($context['contract_version_id']) ? (int)$context['contract_version_id'] : null),
            trim((string)($first['supplier_category'] ?? $context['supplier_category'] ?? '')) ?: null,
            !empty($first['destination_id']) ? (int)$first['destination_id'] : null,
            $city,
            (string)$segment['accommodation_type'],
            $segment['check_in_date'] ?: null,
            $segment['check_out_date'] ?: null,
            max(1, (int)$segment['nights']),
            $star,
            $selectionMode,
            null,
            null,
            $alternatives ? json_encode($alternatives, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : null,
            $roomType !== '' ? $roomType : null,
            $mealPlan !== '' ? $mealPlan : null,
            $status,
            $index + 1,
            $adminId > 0 ? $adminId : null,
            $adminId > 0 ? $adminId : null,
        ]);
        $id = (int)$pdo->lastInsertId();
        $row = ['id'=>$id,'trip_id'=>$tripId,'quotation_version_id'=>$versionId,'booking_id'=>null];
        tsHAEvent($pdo, $row, 'auto_built', null, 'proposed', 'Hotel night plan built from quotation itinerary.', $adminId);
        $created++;
    }

    return ['created'=>$created,'rows'=>tsHAForQuotation($pdo,$versionId),'warning'=>$context ? '' : 'No supplier contract rate is selected. Hotel rows can still use active Hotel Master Pro properties matched by destination/location/category.'];
}

function tsHAForQuotation(PDO $pdo, int $versionId): array
{
    if (!tsHAReady($pdo) || $versionId <= 0) return [];
    $hasImage=false;
    try{$c=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='hotels' AND column_name='primary_image'");$c->execute();$hasImage=(int)$c->fetchColumn()>0;}catch(Throwable $ignored){}
    $imageExpr=$hasImage?'h.primary_image':'NULL';
    $stmt = $pdo->prepare("\n        SELECT a.*, s.company_name supplier_name, c.contract_code, h.hotel_name canonical_hotel_name, {$imageExpr} canonical_hotel_image\n        FROM trip_hotel_allocations a\n        LEFT JOIN suppliers s ON s.id=a.source_supplier_id\n        LEFT JOIN supplier_contract_versions v ON v.id=a.source_contract_version_id\n        LEFT JOIN supplier_contracts c ON c.id=v.contract_id\n        LEFT JOIN hotels h ON h.id=a.hotel_id\n        WHERE a.quotation_version_id=?\n        ORDER BY a.sort_order,a.id\n    ");
    $stmt->execute([$versionId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    foreach ($rows as &$row) {
        $decoded = json_decode((string)($row['alternatives_json'] ?? ''), true);
        $row['alternatives'] = is_array($decoded) ? $decoded : [];
        // V21: while a stay is still proposed/requested, refresh the supplier's
        // location/category Hotel Options live. The chosen hotel snapshot itself
        // remains frozen once selected/confirmed.
        if(!empty($row['source_supplier_id']) && !in_array((string)($row['allocation_status']??''),['confirmed','cancelled'],true)){
            $ctx=['supplier_id'=>(int)$row['source_supplier_id'],'supplier_category'=>(string)($row['source_inventory_category']??'')];
            $live=tsHAHotelPool($pdo,(string)($row['destination_name']??''),!empty($row['hotel_category'])?(int)$row['hotel_category']:null,$ctx);
            if($live){$alts=[];foreach($live as $candidate){$name=trim((string)($candidate['canonical_hotel_name']??$candidate['hotel_name']??''));if($name==='')continue;$source=(string)($candidate['source_kind']??'supplier_option');$alts[]=['inventory_id'=>$source==='legacy_inventory'?(int)($candidate['id']??0):0,'option_id'=>$source==='supplier_option'?(int)($candidate['id']??0):0,'source_kind'=>$source,'hotel_id'=>!empty($candidate['hotel_id'])?(int)$candidate['hotel_id']:null,'name'=>$name,'supplier_hotel_name'=>(string)($candidate['hotel_name']??$name),'room_type'=>(string)($candidate['room_type']??''),'meal_plan'=>(string)($candidate['meal_plan']??'')];}if($alts)$row['alternatives']=array_slice($alts,0,30);}
        }
        $row['master_hotels'] = tsHAHotelMasterPool(
            $pdo,
            (string)($row['destination_name'] ?? ''),
            !empty($row['hotel_category']) ? (int)$row['hotel_category'] : null,
            !empty($row['destination_id']) ? (int)$row['destination_id'] : null
        );
    }
    unset($row);
    return $rows;
}

function tsHAForBooking(PDO $pdo, int $bookingId): array
{
    if (!tsHAReady($pdo) || $bookingId <= 0) return [];
    try {
        $stmt = $pdo->prepare("SELECT quotation_version_id FROM booking_trip_links WHERE booking_id=? LIMIT 1");
        $stmt->execute([$bookingId]);
        $versionId = (int)($stmt->fetchColumn() ?: 0);
        if ($versionId <= 0) return [];
        return tsHAForQuotation($pdo, $versionId);
    } catch (Throwable $e) {
        return [];
    }
}

function tsHACustomerSafeRows(array $rows): array
{
    $out = [];
    foreach ($rows as $row) {
        $alts = [];
        $rawAlts = is_array($row['alternatives'] ?? null)
            ? $row['alternatives']
            : (json_decode((string)($row['alternatives_json'] ?? ''), true) ?: []);
        foreach ($rawAlts as $alt) {
            if (!is_array($alt)) continue;
            $name = trim((string)($alt['name'] ?? ''));
            if ($name !== '' && !in_array($name, $alts, true)) $alts[] = $name;
        }
        foreach ((array)($row['master_hotels'] ?? []) as $hotel) {
            if (!is_array($hotel)) continue;
            $name=trim((string)($hotel['hotel_name'] ?? ''));
            if($name!=='' && !in_array($name,$alts,true))$alts[]=$name;
        }
        $out[] = [
            'destination_name' => (string)($row['destination_name'] ?? ''),
            'accommodation_type' => (string)($row['accommodation_type'] ?? 'hotel'),
            'check_in_date' => $row['check_in_date'] ?? null,
            'check_out_date' => $row['check_out_date'] ?? null,
            'nights' => max(1, (int)($row['nights'] ?? 1)),
            'hotel_category' => !empty($row['hotel_category']) ? (int)$row['hotel_category'] : null,
            'hotel_name' => trim((string)($row['canonical_hotel_name'] ?? $row['hotel_name_snapshot'] ?? '')),
            'hotel_image' => trim((string)($row['canonical_hotel_image'] ?? '')),
            'alternatives' => array_slice($alts, 0, 8),
            'room_type' => (string)($row['room_type'] ?? ''),
            'meal_plan' => (string)($row['meal_plan'] ?? ''),
            'status' => (string)($row['allocation_status'] ?? 'proposed'),
            'confirmation_reference' => (string)($row['supplier_confirmation_ref'] ?? ''),
        ];
    }
    return $out;
}

function tsHABindBooking(PDO $pdo, int $versionId, int $bookingId, int $adminId = 0): void
{
    if (!tsHAReady($pdo) || $versionId <= 0 || $bookingId <= 0) return;
    $rows = tsHAForQuotation($pdo, $versionId);
    $pdo->prepare("UPDATE trip_hotel_allocations SET booking_id=?,updated_by_admin_id=?,updated_at=NOW() WHERE quotation_version_id=? AND (booking_id IS NULL OR booking_id=0)")
        ->execute([$bookingId, $adminId > 0 ? $adminId : null, $versionId]);
    foreach ($rows as $row) {
        $row['booking_id'] = $bookingId;
        tsHAEvent($pdo, $row, 'booking_bound', (string)$row['allocation_status'], (string)$row['allocation_status'], 'Accepted quotation hotel plan frozen to booking.', $adminId);
    }
}

function tsHAAllocationById(PDO $pdo, int $id): ?array
{
    if (!tsHAReady($pdo) || $id <= 0) return null;
    $stmt = $pdo->prepare("SELECT * FROM trip_hotel_allocations WHERE id=? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) return null;
    $row['alternatives'] = json_decode((string)($row['alternatives_json'] ?? ''), true) ?: [];
    return $row;
}

function tsHAUpdateAllocation(PDO $pdo, int $id, array $input, int $adminId): array
{
    $row = tsHAAllocationById($pdo, $id);
    if (!$row) throw new RuntimeException('Hotel allocation was not found.');

    $oldStatus = (string)$row['allocation_status'];
    $status = strtolower(trim((string)($input['allocation_status'] ?? $oldStatus)));
    $allowed = ['proposed','requested','confirmed','unavailable','replaced','cancelled'];
    if (!in_array($status, $allowed, true)) $status = $oldStatus;

    /*
    | V16: the quotation can consume either:
    |  1) exact Supplier Contract hotel inventory, or
    |  2) an ACTIVE location/category Hotel Master property added by Admin.
    | New properties are still created only in Hotel Master / Supplier Master,
    | never by free-text inside the quotation.
    */
    $choice = trim((string)($input['hotel_choice'] ?? ''));
    $optionId = max(0, (int)($input['option_id'] ?? 0));
    $inventoryId = max(0, (int)($input['inventory_id'] ?? 0)); // legacy compatibility
    $masterHotelId = max(0, (int)($input['hotel_id'] ?? 0));   // backward compatibility
    if ($choice !== '') {
        if (preg_match('/^offer:(\d+)$/', $choice, $m)) {$optionId=(int)$m[1];$inventoryId=0;$masterHotelId=0;}
        elseif (preg_match('/^inv:(\d+)$/', $choice, $m)) {$inventoryId=(int)$m[1];$optionId=0;$masterHotelId=0;}
        elseif (preg_match('/^master:(\d+)$/', $choice, $m)) {$masterHotelId=(int)$m[1];$optionId=0;$inventoryId=0;}
        elseif ($choice === 'none') {$optionId=0;$inventoryId=0;$masterHotelId=0;}
    }

    $supplierCandidate = $optionId > 0 ? tsHASupplierOptionCandidate($pdo,$optionId,$row) : ($inventoryId > 0 ? tsHAInventoryCandidate($pdo, $inventoryId, $row) : null);
    $masterCandidate = $masterHotelId > 0 ? tsHAHotelMasterCandidate($pdo, $masterHotelId, $row) : null;

    if ($optionId > 0 && !$supplierCandidate) {
        throw new RuntimeException('The selected supplier hotel option is not active for the same supplier/location/category.');
    }
    if ($inventoryId > 0 && !$supplierCandidate) {
        throw new RuntimeException('The selected legacy supplier hotel is not active for the same location/category.');
    }
    if ($masterHotelId > 0 && !$masterCandidate) {
        throw new RuntimeException('The selected Hotel Master property does not match this quotation location/category.');
    }

    $hasNewCandidate = (bool)($supplierCandidate || $masterCandidate);
    $clearSelection = ($choice === 'none');
    $hasExisting = !$clearSelection && trim((string)($row['hotel_name_snapshot'] ?? '')) !== '';

    if (
        $status === 'confirmed'
        && (string)($row['accommodation_type'] ?? 'hotel') !== 'houseboat'
        && !$hasNewCandidate
        && !$hasExisting
    ) {
        throw new RuntimeException('Select a location-wise hotel from Supplier Inventory or Hotel Master before marking it Confirmed.');
    }
    if (
        $status === 'confirmed'
        && (string)($row['accommodation_type'] ?? '') === 'houseboat'
        && !$supplierCandidate
        && !$hasExisting
    ) {
        throw new RuntimeException('This is a houseboat night. Confirm the houseboat through supplier service/houseboat inventory.');
    }

    $hotelId = null;
    $hotelName = null;
    $roomType = trim((string)($input['room_type'] ?? ''));
    $mealPlan = trim((string)($input['meal_plan'] ?? ''));
    $selectionMode = (string)($row['selection_mode'] ?? 'supplier_pool');
    $eventMessage = 'Hotel allocation workflow status/note updated.';

    if ($supplierCandidate) {
        $hotelId = !empty($supplierCandidate['hotel_id']) ? (int)$supplierCandidate['hotel_id'] : null;
        $hotelName = trim((string)($supplierCandidate['canonical_hotel_name'] ?? $supplierCandidate['hotel_name'] ?? ''));
        if ($roomType === '') $roomType = trim((string)($supplierCandidate['room_type'] ?? ''));
        if ($mealPlan === '') $mealPlan = trim((string)($supplierCandidate['meal_plan'] ?? ''));
        $selectionMode = $optionId>0 ? 'supplier_hotel_option' : 'specific_supplier_inventory';
        $eventMessage = $optionId>0 ? 'Supplier location/category hotel option selected/confirmed. Package price remains based on the selected seasonal package rate.' : 'Legacy supplier-contract hotel selected/confirmed for this quotation segment.';
    } elseif ($masterCandidate) {
        $hotelId = (int)$masterCandidate['id'];
        $hotelName = trim((string)$masterCandidate['hotel_name']);
        if ($roomType === '') $roomType = trim((string)($masterCandidate['default_room_type'] ?? ''));
        if ($mealPlan === '') $mealPlan = trim((string)($masterCandidate['default_meal_plan'] ?? ''));
        $selectionMode = 'hotel_master';
        $eventMessage = 'Admin Hotel Master location hotel selected/confirmed for this quotation segment.';
    } elseif ($hasExisting) {
        $hotelId = !empty($row['hotel_id']) ? (int)$row['hotel_id'] : null;
        $hotelName = trim((string)$row['hotel_name_snapshot']);
        if ($roomType === '') $roomType = trim((string)($row['room_type'] ?? ''));
        if ($mealPlan === '') $mealPlan = trim((string)($row['meal_plan'] ?? ''));
    } elseif ($clearSelection) {
        $selectionMode = 'supplier_option_pool';
        $eventMessage = 'Specific hotel selection cleared; quotation returned to supplier/location hotel options.';
    }

    $stmt = $pdo->prepare("
        UPDATE trip_hotel_allocations SET
            selection_mode=?,hotel_id=?,hotel_name_snapshot=?,room_type=?,meal_plan=?,allocation_status=?,
            supplier_confirmation_ref=?,supplier_note=?,updated_by_admin_id=?,updated_at=NOW()
        WHERE id=?
    ");
    $stmt->execute([
        $selectionMode,
        $hotelId,
        $hotelName !== '' ? $hotelName : null,
        $roomType !== '' ? $roomType : null,
        $mealPlan !== '' ? $mealPlan : null,
        $status,
        trim((string)($input['supplier_confirmation_ref'] ?? '')) ?: null,
        trim((string)($input['supplier_note'] ?? '')) ?: null,
        $adminId > 0 ? $adminId : null,
        $id,
    ]);

    $updated = tsHAAllocationById($pdo, $id) ?: $row;
    tsHAEvent($pdo,$updated,'updated',$oldStatus,$status,$eventMessage,$adminId);
    return $updated;
}

function tsHAMarkRequested(PDO $pdo, int $versionId, int $adminId): int
{
    if (!tsHAReady($pdo)) return 0;
    $rows = tsHAForQuotation($pdo, $versionId);
    $count = 0;
    foreach ($rows as $row) {
        if ((string)$row['allocation_status'] !== 'proposed') continue;

        $alternatives = is_array($row['alternatives'] ?? null)
            ? $row['alternatives']
            : (json_decode((string)($row['alternatives_json'] ?? ''), true) ?: []);

        /*
        | Do not mark a segment requested when the Supplier Contract does not
        | contain a matching location/category hotel pool. Fix inventory first.
        */
        $masterHotels = is_array($row['master_hotels'] ?? null) ? $row['master_hotels'] : [];
        if (!$alternatives && !$masterHotels && (string)($row['accommodation_type'] ?? '') !== 'houseboat') {
            continue;
        }

        $pdo->prepare("UPDATE trip_hotel_allocations SET allocation_status='requested',updated_by_admin_id=?,updated_at=NOW() WHERE id=?")
            ->execute([$adminId > 0 ? $adminId : null, (int)$row['id']]);
        $row['allocation_status']='requested';
        tsHAEvent($pdo,$row,'requested','proposed','requested','Hotel availability requested/queued from the approved location-wise Hotel Master / supplier pool.',$adminId);
        $count++;
    }
    return $count;
}

function tsHASummary(array $rows): array
{
    $out = ['total'=>count($rows),'nights'=>0,'confirmed'=>0,'requested'=>0,'review'=>0];
    foreach ($rows as $row) {
        $out['nights'] += max(1,(int)($row['nights'] ?? 1));
        $st=(string)($row['allocation_status'] ?? 'proposed');
        if($st==='confirmed')$out['confirmed']++;
        elseif($st==='requested')$out['requested']++;
        if(tsHANormalizeCity((string)($row['destination_name'] ?? ''))==='destination to review' || (empty($row['alternatives']) && empty($row['master_hotels'])))$out['review']++;
    }
    return $out;
}
