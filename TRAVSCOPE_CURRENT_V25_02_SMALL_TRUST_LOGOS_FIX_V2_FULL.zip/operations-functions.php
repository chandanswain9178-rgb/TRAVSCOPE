<?php
declare(strict_types=1);

$hotelAllocationFunctionsFile = __DIR__ . '/hotel-allocation-functions.php';
if (is_file($hotelAllocationFunctionsFile)) require_once $hotelAllocationFunctionsFile;

/*
|--------------------------------------------------------------------------
| TRAVSCOPE OPERATIONS READINESS + VOUCHERS
|--------------------------------------------------------------------------
*/

function tsOpsTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];

    $key = strtolower($table);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
              AND table_name = ?
        ");
        $stmt->execute([$table]);

        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}


function tsOpsReady(PDO $pdo): bool
{
    return
        tsOpsTableExists($pdo, 'booking_operation_checks')
        && tsOpsTableExists($pdo, 'booking_voucher_versions')
        && tsOpsTableExists($pdo, 'bookings');
}


function tsOpsChecklistDefinitions(): array
{
    return [
        'finance_clearance' => 'Finance / Payment Clearance Approved',
        'traveller_documents_verified' => 'Traveller Documents Verified',
        'final_itinerary_verified' => 'Final Itinerary & Timings Verified',
        'emergency_contacts_verified' => 'Emergency / On-Tour Contacts Verified',
        'special_requests_verified' => 'Special Requests / Notes Verified',
        'final_supplier_reconfirmation' => 'Final Supplier Reconfirmation Completed',
    ];
}


function tsOpsEnsureChecklist(PDO $pdo, int $bookingId): void
{
    if ($bookingId <= 0 || !tsOpsReady($pdo)) {
        return;
    }

    $stmt = $pdo->prepare("
        INSERT IGNORE INTO booking_operation_checks
        (
            booking_id,
            check_key,
            label,
            is_required,
            is_complete
        )
        VALUES (?, ?, ?, 1, 0)
    ");

    foreach (tsOpsChecklistDefinitions() as $key => $label) {
        $stmt->execute([
            $bookingId,
            $key,
            $label
        ]);
    }
}


function tsOpsChecklist(PDO $pdo, int $bookingId): array
{
    if ($bookingId <= 0 || !tsOpsReady($pdo)) {
        return [];
    }

    tsOpsEnsureChecklist($pdo, $bookingId);

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_operation_checks
        WHERE booking_id = ?
        ORDER BY id ASC
    ");
    $stmt->execute([$bookingId]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsOpsSupplierConfirmationSummary(PDO $pdo, int $bookingId): array
{
    $summary = [
        'total_supplier_services' => 0,
        'confirmed_supplier_services' => 0,
        'alternative_required' => 0,
        'rejected' => 0,
        'pending' => 0,
        'all_confirmed' => true,
    ];

    if (
        $bookingId <= 0
        || !tsOpsTableExists($pdo, 'booking_service_snapshots')
    ) {
        return $summary;
    }

    $stmt = $pdo->prepare("
        SELECT
            procurement_status,
            COUNT(*) AS total
        FROM booking_service_snapshots
        WHERE booking_id = ?
          AND (
                source_supplier_id IS NOT NULL
                OR internal_supplier_cost > 0
          )
        GROUP BY procurement_status
    ");
    $stmt->execute([$bookingId]);

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
        $status = (string)($row['procurement_status'] ?? 'pending');
        $count = (int)($row['total'] ?? 0);

        $summary['total_supplier_services'] += $count;

        if ($status === 'confirmed') {
            $summary['confirmed_supplier_services'] += $count;
        } elseif ($status === 'alternative_required') {
            $summary['alternative_required'] += $count;
        } elseif ($status === 'rejected') {
            $summary['rejected'] += $count;
        } else {
            $summary['pending'] += $count;
        }
    }

    $summary['all_confirmed'] =
        $summary['total_supplier_services'] === 0
        || (
            $summary['confirmed_supplier_services']
            === $summary['total_supplier_services']
        );

    return $summary;
}


function tsOpsVoucherVersions(PDO $pdo, int $bookingId): array
{
    if (
        $bookingId <= 0
        || !tsOpsTableExists($pdo, 'booking_voucher_versions')
    ) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_voucher_versions
        WHERE booking_id = ?
        ORDER BY version_number DESC, id DESC
    ");
    $stmt->execute([$bookingId]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsOpsLatestFinalVoucher(PDO $pdo, int $bookingId): ?array
{
    if (
        $bookingId <= 0
        || !tsOpsTableExists($pdo, 'booking_voucher_versions')
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_voucher_versions
        WHERE booking_id = ?
          AND status = 'final'
        ORDER BY version_number DESC, id DESC
        LIMIT 1
    ");
    $stmt->execute([$bookingId]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function tsOpsVoucherById(PDO $pdo, int $voucherId): ?array
{
    if (
        $voucherId <= 0
        || !tsOpsTableExists($pdo, 'booking_voucher_versions')
    ) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT
            v.*,
            b.user_id,
            b.booking_number,
            b.booking_status,
            b.customer_name,
            b.customer_email,
            b.customer_mobile,
            b.travel_date,
            b.adults,
            b.children,
            b.currency
        FROM booking_voucher_versions v
        JOIN bookings b
            ON b.id = v.booking_id
        WHERE v.id = ?
        LIMIT 1
    ");
    $stmt->execute([$voucherId]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function tsOpsReadiness(PDO $pdo, int $bookingId): array
{
    $result = [
        'booking_confirmed' => false,
        'supplier_services_confirmed' => false,
        'voucher_finalized' => false,
        'manual_required' => 0,
        'manual_completed' => 0,
        'completed' => 0,
        'total' => 0,
        'percent' => 0,
        'ready' => false,
        'supplier_summary' => tsOpsSupplierConfirmationSummary($pdo, $bookingId),
        'latest_final_voucher' => null,
    ];

    if ($bookingId <= 0 || !tsOpsReady($pdo)) {
        return $result;
    }

    $stmt = $pdo->prepare("
        SELECT booking_status
        FROM bookings
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$bookingId]);
    $bookingStatus = (string)($stmt->fetchColumn() ?: '');

    $result['booking_confirmed'] =
        in_array(
            $bookingStatus,
            ['confirmed', 'completed'],
            true
        );

    $result['supplier_services_confirmed'] =
        !empty(
            $result['supplier_summary']['all_confirmed']
        );

    $result['latest_final_voucher'] =
        tsOpsLatestFinalVoucher($pdo, $bookingId);

    $result['voucher_finalized'] =
        !empty($result['latest_final_voucher']);

    $checks = tsOpsChecklist($pdo, $bookingId);

    foreach ($checks as $check) {
        if (empty($check['is_required'])) {
            continue;
        }

        $result['manual_required']++;

        if (!empty($check['is_complete'])) {
            $result['manual_completed']++;
        }
    }

    $automatic = [
        $result['booking_confirmed'],
        $result['supplier_services_confirmed'],
        $result['voucher_finalized'],
    ];

    $result['completed'] =
        $result['manual_completed']
        + count(
            array_filter(
                $automatic,
                static fn($value) => $value === true
            )
        );

    $result['total'] =
        $result['manual_required']
        + count($automatic);

    $result['percent'] =
        $result['total'] > 0
            ? (int)round(
                $result['completed']
                / $result['total']
                * 100
            )
            : 0;

    $result['ready'] =
        $result['total'] > 0
        && $result['completed'] === $result['total'];

    return $result;
}


function tsOpsCreateVoucherVersion(
    PDO $pdo,
    int $bookingId,
    int $adminId,
    string $status = 'draft'
): array {
    if (!tsOpsReady($pdo)) {
        throw new RuntimeException(
            'Operations & Voucher SQL is not installed yet.'
        );
    }

    $status =
        strtolower(
            trim($status)
        );

    if (!in_array($status, ['draft', 'final'], true)) {
        $status = 'draft';
    }

    $stmt = $pdo->prepare("
        SELECT
            b.*,
            p.title AS master_package_title,
            p.description AS master_package_description,
            p.inclusions AS master_inclusions,
            p.exclusions AS master_exclusions,
            p.itinerary AS master_itinerary,
            p.terms AS master_terms,
            p.duration_days AS master_duration_days,
            p.duration_nights AS master_duration_nights,
            d.name AS master_destination_name
        FROM bookings b
        LEFT JOIN packages p
            ON p.id = b.package_id
        LEFT JOIN destinations d
            ON d.id = p.destination_id
        WHERE b.id = ?
        LIMIT 1
    ");
    $stmt->execute([$bookingId]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$booking) {
        throw new RuntimeException(
            'Booking was not found.'
        );
    }

    if ((string)$booking['booking_status'] === 'cancelled') {
        throw new RuntimeException(
            'A cancelled Booking cannot issue a travel voucher.'
        );
    }

    $supplierSummary =
        tsOpsSupplierConfirmationSummary(
            $pdo,
            $bookingId
        );

    if (
        $status === 'final'
        && empty($supplierSummary['all_confirmed'])
    ) {
        throw new RuntimeException(
            'Final voucher cannot be issued until all supplier-backed Booking services are confirmed.'
        );
    }

    $tripLink = null;
    $quoteSnapshot = null;

    if (tsOpsTableExists($pdo, 'booking_trip_links')) {
        $stmt = $pdo->prepare("
            SELECT
                l.*,
                t.trip_code
            FROM booking_trip_links l
            JOIN trips t
                ON t.id = l.trip_id
            WHERE l.booking_id = ?
            LIMIT 1
        ");
        $stmt->execute([$bookingId]);
        $tripLink =
            $stmt->fetch(PDO::FETCH_ASSOC)
            ?: null;
    }

    if (tsOpsTableExists($pdo, 'booking_quotation_snapshots')) {
        $stmt = $pdo->prepare("
            SELECT *
            FROM booking_quotation_snapshots
            WHERE booking_id = ?
            LIMIT 1
        ");
        $stmt->execute([$bookingId]);
        $quoteSnapshot =
            $stmt->fetch(PDO::FETCH_ASSOC)
            ?: null;
    }

    $services = [];

    if (tsOpsTableExists($pdo, 'booking_service_snapshots')) {
        $stmt = $pdo->prepare("
            SELECT *
            FROM booking_service_snapshots
            WHERE booking_id = ?
            ORDER BY sort_order ASC, id ASC
        ");
        $stmt->execute([$bookingId]);

        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $service) {
            /*
             * CUSTOMER-SAFE ONLY:
             * Do NOT include source supplier ID/name or internal supplier cost.
             */
            $services[] = [
                'service_type' =>
                    (string)($service['service_type'] ?? 'other'),
                'title' =>
                    (string)($service['title'] ?? ''),
                'destination_name' =>
                    (string)($service['destination_name'] ?? ''),
                'service_date_from' =>
                    $service['service_date_from'] ?? null,
                'service_date_to' =>
                    $service['service_date_to'] ?? null,
                'quantity' =>
                    (float)($service['quantity'] ?? 1),
                'specifications' =>
                    (string)($service['specifications'] ?? ''),
                'procurement_status' =>
                    (string)($service['procurement_status'] ?? 'pending'),
                'confirmation_reference' =>
                    (string)(
                        $service['supplier_confirmation_ref']
                        ?? ''
                    ),
            ];
        }
    }

    $quoteJson = [];

    if ($quoteSnapshot) {
        $decoded =
            json_decode(
                (string)(
                    $quoteSnapshot['quotation_snapshot_json']
                    ?? ''
                ),
                true
            );

        if (is_array($decoded)) {
            $quoteJson = $decoded;
        }
    }

    $packageTitle =
        trim(
            (string)(
                $quoteSnapshot['package_title']
                ?? $booking['master_package_title']
                ?? 'Travel Booking'
            )
        );

    $destination =
        trim(
            (string)(
                $quoteSnapshot['destination_name']
                ?? $booking['master_destination_name']
                ?? ''
            )
        );

    $itinerary =
        $quoteSnapshot['itinerary_json']
        ?? $booking['master_itinerary']
        ?? null;

    $snapshot = [
        'voucher_schema' => 1,
        'booking_id' => $bookingId,
        'booking_number' =>
            (string)$booking['booking_number'],
        'trip_code' =>
            (string)($tripLink['trip_code'] ?? ''),
        'customer' => [
            'name' =>
                (string)$booking['customer_name'],
            'email' =>
                (string)($booking['customer_email'] ?? ''),
            'mobile' =>
                (string)($booking['customer_mobile'] ?? ''),
        ],
        'travel' => [
            'destination' => $destination,
            'travel_date' =>
                $quoteSnapshot['travel_date']
                ?? $booking['travel_date']
                ?? null,
            'adults' =>
                (int)($booking['adults'] ?? 0),
            'children' =>
                (int)($booking['children'] ?? 0),
            'duration_days' =>
                (int)(
                    $quoteJson['duration_days']
                    ?? $booking['master_duration_days']
                    ?? 0
                ),
            'duration_nights' =>
                (int)(
                    $quoteJson['duration_nights']
                    ?? $booking['master_duration_nights']
                    ?? 0
                ),
        ],
        'package' => [
            'title' => $packageTitle,
            'description' =>
                (string)(
                    $quoteSnapshot['package_description']
                    ?? $booking['master_package_description']
                    ?? ''
                ),
            'itinerary' => $itinerary,
            'inclusions' =>
                (string)(
                    $quoteSnapshot['inclusions']
                    ?? $booking['master_inclusions']
                    ?? ''
                ),
            'exclusions' =>
                (string)(
                    $quoteSnapshot['exclusions']
                    ?? $booking['master_exclusions']
                    ?? ''
                ),
            'terms' =>
                (string)(
                    $quoteSnapshot['terms']
                    ?? $booking['master_terms']
                    ?? ''
                ),
            'customer_notes' =>
                (string)(
                    $quoteSnapshot['customer_notes']
                    ?? $booking['special_request']
                    ?? ''
                ),
        ],
        'services' => $services,
        'hotels' => (function () use ($pdo, $bookingId) {
            if (!function_exists('tsHAForBooking') || !function_exists('tsHACustomerSafeRows')) return [];
            try { return tsHACustomerSafeRows(tsHAForBooking($pdo,$bookingId)); }
            catch (Throwable $e) { error_log('Voucher hotel snapshot: '.$e->getMessage()); return []; }
        })(),
        'transport' => (function () use ($pdo, $bookingId) {
            if (!function_exists('tsTAForBooking') || !function_exists('tsTACustomerSafeRows')) return [];
            try { return tsTACustomerSafeRows(tsTAForBooking($pdo,$bookingId)); }
            catch (Throwable $e) { error_log('Voucher transport snapshot: '.$e->getMessage()); return []; }
        })(),
        'issued_at' => date('c'),
    ];

    $stmt = $pdo->prepare("
        SELECT COALESCE(MAX(version_number),0)+1
        FROM booking_voucher_versions
        WHERE booking_id = ?
    ");
    $stmt->execute([$bookingId]);
    $version =
        max(
            1,
            (int)$stmt->fetchColumn()
        );

    $safeBooking =
        preg_replace(
            '/[^A-Za-z0-9-]+/',
            '',
            (string)$booking['booking_number']
        );

    if ($safeBooking === '') {
        $safeBooking =
            'BOOKING'
            . $bookingId;
    }

    $voucherCode =
        'TV-'
        . strtoupper($safeBooking)
        . '-V'
        . $version;

    $stmt = $pdo->prepare("
        INSERT INTO booking_voucher_versions
        (
            booking_id,
            version_number,
            voucher_code,
            status,
            snapshot_json,
            created_by_admin_id,
            finalized_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $bookingId,
        $version,
        $voucherCode,
        $status,
        json_encode(
            $snapshot,
            JSON_UNESCAPED_UNICODE
            | JSON_UNESCAPED_SLASHES
        ),
        $adminId > 0
            ? $adminId
            : null,
        $status === 'final'
            ? date('Y-m-d H:i:s')
            : null
    ]);

    $voucherId =
        (int)$pdo->lastInsertId();

    $stmt = $pdo->prepare("
        SELECT *
        FROM booking_voucher_versions
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$voucherId]);

    return
        $stmt->fetch(PDO::FETCH_ASSOC)
        ?: [];
}
