TRAVSCOPE V24.12 - DELETE OTP ON/OFF CONTROL
=============================================

WHAT CHANGED
- Added Admin > General Settings > Website Controls > Delete OTP Verification.
- ON (default): destructive Admin Delete/Remove actions require Admin email OTP.
- OFF: destructive Admin Delete/Remove actions proceed without OTP.
- Existing delete permissions, CSRF checks, foreign-key/history protections and page-specific safety rules remain unchanged.

DATABASE
- No schema migration is required.
- The existing settings table stores admin_delete_otp_enabled automatically when Save Settings is used.
- If the setting does not yet exist, the system defaults to ON.

FILES CHANGED
- admin-settings.php
- admin-delete-otp-functions.php

DEPLOYMENT
1. Back up website files/database.
2. Upload the patch files or deploy the full website package.
3. Sign in to Admin.
4. Open General Settings > Website Controls.
5. Set Delete OTP Verification to On or Off and click Save Settings.
6. Test with a safe unused record.
