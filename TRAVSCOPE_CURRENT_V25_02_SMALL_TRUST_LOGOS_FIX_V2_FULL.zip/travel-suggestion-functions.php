<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE V24.26 · FLIGHT / TRAIN SUGGESTION SERVICE
|--------------------------------------------------------------------------
| Quotation planning only. This module never books/tickets a flight or train.
| Flight provider is intentionally isolated behind tsTravelSearchFlights().
| Train V1 starts with manual/schedule suggestions and provider hooks.
*/

function tsTravelE(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function tsTravelTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];
    if (array_key_exists($table, $cache)) return $cache[$table];
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
        $stmt->execute([$table]);
        return $cache[$table] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$table] = false;
    }
}

function tsTravelModuleReady(PDO $pdo): bool
{
    foreach (['flight_searches','flight_options','itinerary_flights','train_searches','train_options','itinerary_trains'] as $table) {
        if (!tsTravelTableExists($pdo, $table)) return false;
    }
    return true;
}

function tsTravelSetting(PDO $pdo, string $key, string $default = ''): string
{
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key=? LIMIT 1");
        $stmt->execute([$key]);
        $value = $stmt->fetchColumn();
        return $value === false ? $default : (string)$value;
    } catch (Throwable $e) {
        return $default;
    }
}

function tsTravelSetSetting(PDO $pdo, string $key, string $value): void
{
    $stmt = $pdo->prepare("INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
    $stmt->execute([$key,$value]);
}

function tsTravelLogApi(PDO $pdo, array $row): void
{
    if (!tsTravelTableExists($pdo, 'travel_api_logs')) return;
    try {
        $stmt = $pdo->prepare("INSERT INTO travel_api_logs(service_type,provider,action_name,enquiry_id,trip_id,request_summary,http_status,response_status,error_message,duration_ms,created_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([
            $row['service_type'] ?? 'flight', $row['provider'] ?? 'unknown', $row['action_name'] ?? 'search',
            $row['enquiry_id'] ?? null, $row['trip_id'] ?? null, $row['request_summary'] ?? null,
            $row['http_status'] ?? null, $row['response_status'] ?? 'error', $row['error_message'] ?? null,
            $row['duration_ms'] ?? null, $row['created_by_admin_id'] ?? null,
        ]);
    } catch (Throwable $e) {
        error_log('TRAVSCOPE travel API log error: '.$e->getMessage());
    }
}

function tsTravelHttpJson(string $url, string $method = 'GET', array $headers = [], array $form = [], int $timeout = 25): array
{
    if (!function_exists('curl_init')) {
        return ['ok'=>false,'status'=>0,'data'=>null,'error'=>'cURL extension is not available on this server.'];
    }
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CUSTOMREQUEST => strtoupper($method),
        CURLOPT_HTTPHEADER => $headers,
    ]);
    if (strtoupper($method) !== 'GET') {
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($form));
    }
    $body = curl_exec($ch);
    $err = curl_error($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $decoded = is_string($body) ? json_decode($body, true) : null;
    if ($body === false || $err !== '') return ['ok'=>false,'status'=>$status,'data'=>$decoded,'error'=>$err ?: 'HTTP request failed.'];
    if ($status < 200 || $status >= 300) {
        $msg = '';
        if (is_array($decoded)) {
            $msg = (string)($decoded['error_description'] ?? $decoded['errors'][0]['detail'] ?? $decoded['error'] ?? '');
        }
        return ['ok'=>false,'status'=>$status,'data'=>$decoded,'error'=>$msg ?: 'Provider returned HTTP '.$status.'.'];
    }
    return ['ok'=>true,'status'=>$status,'data'=>$decoded,'error'=>''];
}

function tsTravelAmadeusBase(PDO $pdo): string
{
    return strtolower(tsTravelSetting($pdo,'amadeus_environment','test')) === 'production'
        ? 'https://api.amadeus.com'
        : 'https://test.api.amadeus.com';
}

function tsTravelAmadeusToken(PDO $pdo): array
{
    $clientId = trim(tsTravelSetting($pdo,'amadeus_client_id',''));
    $clientSecret = trim(tsTravelSetting($pdo,'amadeus_client_secret',''));
    if ($clientId === '' || $clientSecret === '') {
        return ['ok'=>false,'token'=>'','error'=>'Amadeus API credentials are not configured. Add the Client ID and Client Secret in Flight Suggestion settings.'];
    }
    $res = tsTravelHttpJson(
        tsTravelAmadeusBase($pdo).'/v1/security/oauth2/token',
        'POST',
        ['Content-Type: application/x-www-form-urlencoded'],
        ['grant_type'=>'client_credentials','client_id'=>$clientId,'client_secret'=>$clientSecret],
        20
    );
    if (!$res['ok']) return ['ok'=>false,'token'=>'','error'=>$res['error'],'status'=>$res['status']];
    $token = trim((string)($res['data']['access_token'] ?? ''));
    if ($token === '') return ['ok'=>false,'token'=>'','error'=>'Amadeus token response did not contain an access token.'];
    return ['ok'=>true,'token'=>$token,'error'=>'','status'=>$res['status']];
}

function tsTravelDurationMinutes(string $iso): ?int
{
    $iso = trim($iso);
    if ($iso === '') return null;
    try {
        $interval = new DateInterval($iso);
        return ((int)$interval->d * 1440) + ((int)$interval->h * 60) + (int)$interval->i;
    } catch (Throwable $e) {
        return null;
    }
}

function tsTravelFormatDuration(?int $minutes): string
{
    if (!$minutes) return '—';
    $h = intdiv($minutes,60); $m=$minutes%60;
    return ($h ? $h.'h ' : '').($m ? $m.'m' : ($h ? '' : '0m'));
}

function tsTravelDateTimeDb(?string $iso): ?string
{
    $iso = trim((string)$iso);
    if ($iso === '') return null;
    try { return (new DateTime($iso))->format('Y-m-d H:i:s'); }
    catch (Throwable $e) { return null; }
}

function tsTravelCabinMap(string $cabin): string
{
    $cabin = strtoupper(trim($cabin));
    $allowed = ['ECONOMY','PREMIUM_ECONOMY','BUSINESS','FIRST'];
    return in_array($cabin,$allowed,true) ? $cabin : 'ECONOMY';
}

function tsTravelSearchFlights(PDO $pdo, array $params, int $adminId): array
{
    if (!tsTravelModuleReady($pdo)) return ['ok'=>false,'options'=>[],'error'=>'Flight/Train suggestion database setup has not been installed yet.'];
    $origin = strtoupper(preg_replace('/[^A-Z0-9]/','', (string)($params['origin_code'] ?? '')) ?? '');
    $destination = strtoupper(preg_replace('/[^A-Z0-9]/','', (string)($params['destination_code'] ?? '')) ?? '');
    $date = trim((string)($params['departure_date'] ?? ''));
    $adults = max(1,min(9,(int)($params['adults'] ?? 1)));
    $children = max(0,min(8,(int)($params['children'] ?? 0)));
    $cabin = tsTravelCabinMap((string)($params['cabin_class'] ?? 'ECONOMY'));
    $maxStops = isset($params['max_stops']) && $params['max_stops'] !== '' ? max(0,min(3,(int)$params['max_stops'])) : 1;
    $airlineFilter = strtoupper(trim((string)($params['airline_filter'] ?? '')));
    $departAfter = trim((string)($params['depart_after'] ?? ''));
    $departBefore = trim((string)($params['depart_before'] ?? ''));
    $maxDuration = max(0,(int)($params['max_duration_minutes'] ?? 0));
    $maxFare = max(0,(float)($params['max_fare'] ?? 0));
    $leadId = max(0,(int)($params['enquiry_id'] ?? 0));
    $tripId = max(0,(int)($params['trip_id'] ?? 0));
    $packageId = max(0,(int)($params['package_id'] ?? 0));
    if (strlen($origin) < 3 || strlen($destination) < 3 || !preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)) {
        return ['ok'=>false,'options'=>[],'error'=>'Enter valid origin/destination airport codes and travel date.'];
    }
    if ($origin === $destination) return ['ok'=>false,'options'=>[],'error'=>'Origin and destination cannot be the same.'];

    $provider = strtolower(trim(tsTravelSetting($pdo,'flight_suggestion_provider','amadeus')) ?: 'amadeus');
    $request = compact('origin','destination','date','adults','children','cabin','maxStops','airlineFilter','departAfter','departBefore','maxDuration','maxFare');

    $cacheMinutes=max(0,min(120,(int)tsTravelSetting($pdo,'flight_suggestion_cache_minutes','10')));
    if($cacheMinutes>0){
        try{
            $requestJson=json_encode($request,JSON_UNESCAPED_SLASHES);
            $stmt=$pdo->prepare("SELECT id FROM flight_searches WHERE origin_code=? AND destination_code=? AND departure_date=? AND adults=? AND children=? AND cabin_class=? AND max_stops=? AND provider=? AND request_json=? AND response_status IN ('success','cached') AND created_at>=DATE_SUB(NOW(),INTERVAL ? MINUTE) ORDER BY id DESC LIMIT 1");
            $stmt->execute([$origin,$destination,$date,$adults,$children,$cabin,$maxStops,$provider,$requestJson,$cacheMinutes]);
            $cachedId=(int)($stmt->fetchColumn()?:0);
            if($cachedId>0){
                $stmt=$pdo->prepare("SELECT * FROM flight_options WHERE search_id=? ORDER BY stops ASC,COALESCE(duration_minutes,999999) ASC,COALESCE(total_fare,999999999) ASC,id ASC");$stmt->execute([$cachedId]);
                $cached=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
                if($cached){
                    $filtered=array_values(array_filter($cached,static function($o)use($airlineFilter,$departAfter,$departBefore,$maxDuration,$maxFare){
                        if($airlineFilter!=='' && stripos((string)($o['airline_code']??'').' '.(string)($o['airline_name']??''),$airlineFilter)===false)return false;
                        if($maxDuration>0 && (int)($o['duration_minutes']??0)>$maxDuration)return false;
                        if($maxFare>0 && (float)($o['total_fare']??0)>$maxFare)return false;
                        $time=!empty($o['departure_at'])?date('H:i',strtotime((string)$o['departure_at'])):'';
                        if($departAfter!=='' && $time!=='' && $time<$departAfter)return false;
                        if($departBefore!=='' && $time!=='' && $time>$departBefore)return false;
                        return true;
                    }));
                    return ['ok'=>true,'options'=>$filtered,'search_id'=>$cachedId,'cached'=>true,'error'=>''];
                }
            }
        }catch(Throwable $cacheError){error_log('Flight search cache: '.$cacheError->getMessage());}
    }

    $stmt=$pdo->prepare("INSERT INTO flight_searches(enquiry_id,trip_id,package_id,origin_code,destination_code,departure_date,adults,children,cabin_class,trip_type,max_stops,provider,request_json,response_status,created_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,'one_way',?,?,?,'pending',?)");
    $stmt->execute([$leadId?:null,$tripId?:null,$packageId?:null,$origin,$destination,$date,$adults,$children,$cabin,$maxStops,$provider,json_encode($request,JSON_UNESCAPED_SLASHES),$adminId?:null]);
    $searchId=(int)$pdo->lastInsertId();

    if ($provider !== 'amadeus') {
        $pdo->prepare("UPDATE flight_searches SET response_status='error',error_message=? WHERE id=?")->execute(['Configured flight provider is not available in this release. Choose Amadeus or use Manual Flight Suggestion.',$searchId]);
        return ['ok'=>false,'options'=>[],'search_id'=>$searchId,'error'=>'Configured flight provider is not available in this release. Use Amadeus or Manual Flight Suggestion.'];
    }

    $started=microtime(true);
    $token=tsTravelAmadeusToken($pdo);
    if(!$token['ok']){
        $pdo->prepare("UPDATE flight_searches SET response_status='error',error_message=? WHERE id=?")->execute([$token['error'],$searchId]);
        tsTravelLogApi($pdo,['service_type'=>'flight','provider'=>'amadeus','action_name'=>'token','enquiry_id'=>$leadId?:null,'trip_id'=>$tripId?:null,'request_summary'=>$origin.'-'.$destination.' '.$date,'response_status'=>'error','error_message'=>$token['error'],'duration_ms'=>(int)((microtime(true)-$started)*1000),'created_by_admin_id'=>$adminId?:null]);
        return ['ok'=>false,'options'=>[],'search_id'=>$searchId,'error'=>$token['error']];
    }

    $query=[
        'originLocationCode'=>$origin,
        'destinationLocationCode'=>$destination,
        'departureDate'=>$date,
        'adults'=>$adults,
        'travelClass'=>$cabin,
        'currencyCode'=>strtoupper(tsTravelSetting($pdo,'currency_code','INR') ?: 'INR'),
        'max'=>25,
    ];
    if($children>0)$query['children']=$children;
    $url=tsTravelAmadeusBase($pdo).'/v2/shopping/flight-offers?'.http_build_query($query);
    $res=tsTravelHttpJson($url,'GET',['Authorization: Bearer '.$token['token'],'Accept: application/json'],[],30);
    $duration=(int)((microtime(true)-$started)*1000);
    tsTravelLogApi($pdo,['service_type'=>'flight','provider'=>'amadeus','action_name'=>'flight_offers_search','enquiry_id'=>$leadId?:null,'trip_id'=>$tripId?:null,'request_summary'=>$origin.'-'.$destination.' '.$date,'http_status'=>$res['status'],'response_status'=>$res['ok']?'success':'error','error_message'=>$res['error'] ?: null,'duration_ms'=>$duration,'created_by_admin_id'=>$adminId?:null]);
    if(!$res['ok']){
        $pdo->prepare("UPDATE flight_searches SET response_status='error',error_message=? WHERE id=?")->execute([$res['error'],$searchId]);
        return ['ok'=>false,'options'=>[],'search_id'=>$searchId,'error'=>$res['error']];
    }

    $dict=(array)($res['data']['dictionaries']['carriers'] ?? []);
    $options=[];
    foreach((array)($res['data']['data'] ?? []) as $offer){
        $itinerary=(array)($offer['itineraries'][0] ?? []);
        $segments=(array)($itinerary['segments'] ?? []);
        if(!$segments)continue;
        $stops=max(0,count($segments)-1);
        if($stops>$maxStops)continue;
        $first=(array)$segments[0]; $last=(array)$segments[count($segments)-1];
        $carrier=(string)($first['carrierCode'] ?? $offer['validatingAirlineCodes'][0] ?? '');
        $airline=(string)($dict[$carrier] ?? $carrier);
        $flightNo=$carrier.(string)($first['number'] ?? '');
        $stopCodes=[];
        if(count($segments)>1){foreach(array_slice($segments,0,-1) as $seg){$code=(string)($seg['arrival']['iataCode'] ?? '');if($code!=='')$stopCodes[]=$code;}}
        $durationMin=tsTravelDurationMinutes((string)($itinerary['duration'] ?? ''));
        $price=(float)($offer['price']['grandTotal'] ?? $offer['price']['total'] ?? 0);
        $depTimeRaw=(string)($first['departure']['at'] ?? '');
        $depClock=$depTimeRaw!==''?date('H:i',strtotime($depTimeRaw)):'';
        if($airlineFilter!=='' && stripos($carrier.' '.$airline,$airlineFilter)===false)continue;
        if($maxDuration>0 && $durationMin!==null && $durationMin>$maxDuration)continue;
        if($maxFare>0 && $price>$maxFare)continue;
        if($departAfter!=='' && $depClock!=='' && $depClock<$departAfter)continue;
        if($departBefore!=='' && $depClock!=='' && $depClock>$departBefore)continue;
        $travellerCount=max(1,$adults+$children);
        $baggage='';
        $fareDetails=(array)($offer['travelerPricings'][0]['fareDetailsBySegment'][0] ?? []);
        $bag=(array)($fareDetails['includedCheckedBags'] ?? []);
        if(isset($bag['weight']))$baggage=(string)$bag['weight'].' '.strtoupper((string)($bag['weightUnit'] ?? 'KG'));
        elseif(isset($bag['quantity']))$baggage=(string)$bag['quantity'].' checked bag(s)';
        $dep=tsTravelDateTimeDb((string)($first['departure']['at'] ?? ''));
        $arr=tsTravelDateTimeDb((string)($last['arrival']['at'] ?? ''));
        $currency=(string)($offer['price']['currency'] ?? 'INR');
        $stmt=$pdo->prepare("INSERT INTO flight_options(search_id,provider_option_id,airline_code,airline_name,flight_number,origin_code,destination_code,departure_at,arrival_at,stops,stop_codes,duration_minutes,cabin_class,baggage,currency,total_fare,fare_per_person,segments_json,raw_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([$searchId,(string)($offer['id']??''),$carrier,$airline,$flightNo,$origin,$destination,$dep,$arr,$stops,implode(', ',$stopCodes),$durationMin,$cabin,$baggage,$currency,$price,$price/$travellerCount,json_encode($segments,JSON_UNESCAPED_SLASHES),json_encode($offer,JSON_UNESCAPED_SLASHES)]);
        $id=(int)$pdo->lastInsertId();
        $options[]=['id'=>$id,'search_id'=>$searchId,'airline_code'=>$carrier,'airline_name'=>$airline,'flight_number'=>$flightNo,'origin_code'=>$origin,'destination_code'=>$destination,'departure_at'=>$dep,'arrival_at'=>$arr,'stops'=>$stops,'stop_codes'=>implode(', ',$stopCodes),'duration_minutes'=>$durationMin,'cabin_class'=>$cabin,'baggage'=>$baggage,'currency'=>$currency,'total_fare'=>$price,'fare_per_person'=>$price/$travellerCount];
    }
    $pdo->prepare("UPDATE flight_searches SET response_status='success',error_message=NULL WHERE id=?")->execute([$searchId]);
    usort($options, static fn($a,$b)=>[$a['stops'],$a['duration_minutes']?:99999,$a['total_fare']?:999999999] <=> [$b['stops'],$b['duration_minutes']?:99999,$b['total_fare']?:999999999]);
    return ['ok'=>true,'options'=>$options,'search_id'=>$searchId,'error'=>''];
}

function tsTravelFlightOption(PDO $pdo, int $id): ?array
{
    if($id<=0 || !tsTravelTableExists($pdo,'flight_options'))return null;
    $stmt=$pdo->prepare("SELECT o.*,s.enquiry_id,s.trip_id,s.package_id,s.departure_date FROM flight_options o JOIN flight_searches s ON s.id=o.search_id WHERE o.id=? LIMIT 1");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

function tsTravelSelectFlight(PDO $pdo, int $optionId, array $ctx, int $adminId): int
{
    $o=tsTravelFlightOption($pdo,$optionId); if(!$o)throw new RuntimeException('Flight option was not found.');
    $tripId=max(0,(int)($ctx['trip_id']??$o['trip_id']??0)); $leadId=max(0,(int)($ctx['enquiry_id']??$o['enquiry_id']??0)); $packageId=max(0,(int)($ctx['package_id']??$o['package_id']??0));
    $preferred=!empty($ctx['preferred'])?1:0;
    if($preferred && $tripId>0)$pdo->prepare("UPDATE itinerary_flights SET preferred=0 WHERE trip_id=? AND status<>'cancelled'")->execute([$tripId]);
    $order=max(1,(int)($ctx['sector_order']??1));
    $priceMode=in_array((string)($ctx['price_mode']??''),['details_only','indicative_fare','included_in_package'],true)?(string)$ctx['price_mode']:'details_only';
    $displayFare=$priceMode==='indicative_fare'?1:0;
    $stmt=$pdo->prepare("INSERT INTO itinerary_flights(enquiry_id,trip_id,package_id,flight_option_id,sector_order,origin_code,destination_code,travel_date,airline_name,airline_code,flight_number,departure_at,arrival_at,stops,stop_codes,duration_minutes,cabin_class,baggage,price_mode,display_fare,fare_amount,currency,status,preferred,notes,segments_json,created_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'suggested',?,?,?,?)");
    $stmt->execute([$leadId?:null,$tripId?:null,$packageId?:null,$optionId,$order,$o['origin_code'],$o['destination_code'],$o['departure_date'],$o['airline_name'],$o['airline_code'],$o['flight_number'],$o['departure_at'],$o['arrival_at'],$o['stops'],$o['stop_codes'],$o['duration_minutes'],$o['cabin_class'],$o['baggage'],$priceMode,$displayFare,$o['total_fare'],$o['currency'],$preferred,trim((string)($ctx['notes']??'')),$o['segments_json'],$adminId?:null]);
    return (int)$pdo->lastInsertId();
}

function tsTravelAddManualFlight(PDO $pdo,array $data,int $adminId): int
{
    if(!tsTravelModuleReady($pdo))throw new RuntimeException('Run the V24.26 SQL upgrade first.');
    $origin=strtoupper(trim((string)($data['origin_code']??'')));$dest=strtoupper(trim((string)($data['destination_code']??'')));
    if($origin===''||$dest==='')throw new RuntimeException('Origin and destination are required.');
    $date=trim((string)($data['travel_date']??''));
    $dep=tsTravelDateTimeDb((string)($data['departure_at']??''));$arr=tsTravelDateTimeDb((string)($data['arrival_at']??''));
    $priceMode=in_array((string)($data['price_mode']??''),['details_only','indicative_fare','included_in_package'],true)?(string)$data['price_mode']:'details_only';
    $stmt=$pdo->prepare("INSERT INTO itinerary_flights(enquiry_id,trip_id,package_id,sector_order,origin_code,destination_code,travel_date,airline_name,airline_code,flight_number,departure_at,arrival_at,stops,stop_codes,duration_minutes,cabin_class,baggage,price_mode,display_fare,fare_amount,currency,status,preferred,notes,created_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'suggested',?,?,?)");
    $stmt->execute([max(0,(int)($data['enquiry_id']??0))?:null,max(0,(int)($data['trip_id']??0))?:null,max(0,(int)($data['package_id']??0))?:null,max(1,(int)($data['sector_order']??1)),$origin,$dest,$date?:null,trim((string)($data['airline_name']??'')),strtoupper(trim((string)($data['airline_code']??''))),trim((string)($data['flight_number']??'')),$dep,$arr,max(0,(int)($data['stops']??0)),trim((string)($data['stop_codes']??'')),isset($data['duration_minutes'])?(int)$data['duration_minutes']:null,tsTravelCabinMap((string)($data['cabin_class']??'ECONOMY')),trim((string)($data['baggage']??'')),$priceMode,$priceMode==='indicative_fare'?1:0,isset($data['fare_amount'])?(float)$data['fare_amount']:null,strtoupper(trim((string)($data['currency']??'INR')))?:'INR',!empty($data['preferred'])?1:0,trim((string)($data['notes']??'')),$adminId?:null]);
    return (int)$pdo->lastInsertId();
}

function tsTravelAddManualTrain(PDO $pdo,array $data,int $adminId): int
{
    if(!tsTravelModuleReady($pdo))throw new RuntimeException('Run the V24.26 SQL upgrade first.');
    $origin=strtoupper(trim((string)($data['origin_code']??'')));$dest=strtoupper(trim((string)($data['destination_code']??'')));$number=trim((string)($data['train_number']??''));
    if($origin===''||$dest===''||$number==='')throw new RuntimeException('Train number, origin and destination are required.');
    $priceMode=in_array((string)($data['price_mode']??''),['details_only','indicative_fare','included_in_package'],true)?(string)$data['price_mode']:'details_only';
    $stmt=$pdo->prepare("INSERT INTO itinerary_trains(enquiry_id,trip_id,package_id,sector_order,origin_code,destination_code,journey_date,train_number,train_name,departure_at,arrival_at,duration_minutes,travel_class,running_days,availability_text,price_mode,display_fare,fare_amount,currency,status,preferred,notes,created_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'suggested',?,?,?)");
    $stmt->execute([max(0,(int)($data['enquiry_id']??0))?:null,max(0,(int)($data['trip_id']??0))?:null,max(0,(int)($data['package_id']??0))?:null,max(1,(int)($data['sector_order']??1)),$origin,$dest,trim((string)($data['journey_date']??''))?:null,$number,trim((string)($data['train_name']??'')),tsTravelDateTimeDb((string)($data['departure_at']??'')),tsTravelDateTimeDb((string)($data['arrival_at']??'')),isset($data['duration_minutes'])?(int)$data['duration_minutes']:null,trim((string)($data['travel_class']??'')),trim((string)($data['running_days']??'')),trim((string)($data['availability_text']??'')),$priceMode,$priceMode==='indicative_fare'?1:0,isset($data['fare_amount'])?(float)$data['fare_amount']:null,strtoupper(trim((string)($data['currency']??'INR')))?:'INR',!empty($data['preferred'])?1:0,trim((string)($data['notes']??'')),$adminId?:null]);
    return (int)$pdo->lastInsertId();
}

function tsTravelSuggestions(PDO $pdo,int $leadId=0,int $tripId=0): array
{
    $out=['flights'=>[],'trains'=>[]];
    if(!tsTravelModuleReady($pdo))return $out;
    $where=$tripId>0?'trip_id=?':'enquiry_id=?';$id=$tripId>0?$tripId:$leadId;
    if($id<=0)return $out;
    $stmt=$pdo->prepare("SELECT * FROM itinerary_flights WHERE {$where} AND status<>'cancelled' ORDER BY sector_order ASC,preferred DESC,id ASC");$stmt->execute([$id]);$out['flights']=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
    $stmt=$pdo->prepare("SELECT * FROM itinerary_trains WHERE {$where} AND status<>'cancelled' ORDER BY sector_order ASC,preferred DESC,id ASC");$stmt->execute([$id]);$out['trains']=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
    return $out;
}

function tsTravelDeleteSuggestion(PDO $pdo,string $type,int $id,int $tripId,int $leadId): void
{
    $table=$type==='train'?'itinerary_trains':'itinerary_flights';
    if(!tsTravelTableExists($pdo,$table))return;
    $stmt=$pdo->prepare("DELETE FROM {$table} WHERE id=? AND ((trip_id=? AND ?>0) OR (enquiry_id=? AND ?>0)) LIMIT 1");
    $stmt->execute([$id,$tripId,$tripId,$leadId,$leadId]);
}

function tsTravelUpdateSuggestionStatus(PDO $pdo,string $type,int $id,string $status,int $tripId,int $leadId): void
{
    $allowed=['suggested','selected','quoted','booking_requested','booked','cancelled'];
    if(!in_array($status,$allowed,true))throw new RuntimeException('Invalid suggestion status.');
    $table=$type==='train'?'itinerary_trains':'itinerary_flights';
    $stmt=$pdo->prepare("UPDATE {$table} SET status=? WHERE id=? AND ((trip_id=? AND ?>0) OR (enquiry_id=? AND ?>0))");
    $stmt->execute([$status,$id,$tripId,$tripId,$leadId,$leadId]);
}

function tsTravelSuggestionSnapshot(PDO $pdo,int $leadId,int $tripId): array
{
    $s=tsTravelSuggestions($pdo,$leadId,$tripId);
    $flightKeys=['id','sector_order','origin_code','destination_code','travel_date','airline_name','airline_code','flight_number','departure_at','arrival_at','stops','stop_codes','duration_minutes','cabin_class','baggage','price_mode','display_fare','fare_amount','currency','status','preferred','notes'];
    $trainKeys=['id','sector_order','origin_code','destination_code','journey_date','train_number','train_name','departure_at','arrival_at','duration_minutes','travel_class','running_days','availability_text','price_mode','display_fare','fare_amount','currency','status','preferred','notes'];
    $clean=static function(array $rows,array $keys):array{ return array_map(static function($row)use($keys){$x=[];foreach($keys as $k)$x[$k]=$row[$k]??null;return $x;},$rows);};
    return ['flights'=>$clean($s['flights'],$flightKeys),'trains'=>$clean($s['trains'],$trainKeys)];
}

function tsTravelSuggestionDisclaimer(string $type='flight'): string
{
    return $type==='train'
        ? 'Train details are suggested for itinerary planning only. Schedule, availability, fare and class availability may change until the ticket is confirmed.'
        : 'Flight details are suggested for itinerary planning only. Schedules, availability, fares and baggage allowances may change until booking is confirmed and ticketed.';
}
