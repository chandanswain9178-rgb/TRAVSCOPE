# TRAVSCOPE V25.01 — Credential Logo Library & Document Recognition Strip

Base: V25.00 (development). Database schema: unchanged. **No SQL required.**

## What is new

- Admin → General Settings → **Quotation Trust & Credentials**:
  - Four independent credential labels, image paths and explicit Publication Approval selectors.
  - Four browser image upload controls with live preview; PNG/JPG (up to 3 MB, 24–5000 px, max 12 MP). No SVG or code-bearing formats.
  - Images are stored with randomized filenames in `uploads/settings/branding/` and the relative paths are saved using the existing `settings` table.
  - No label or logo is shown unless the admin selects **Display – Authorised to use** for that exact slot and both label and image are set.
- One centrally maintained recognition strip appears on public website footer areas (Home, Packages, Package Details, Destinations and Contact).
- The same enabled logos appear in customer quotation HTML/print/PDF, customer quotation portal, booking/tax invoice HTML print, money receipt HTML print, booking voucher and supplier payment voucher.
- The automatically emailed *verified money-receipt PDF* embeds approved local PNG/JPG marks (not fetched from external domains).
- Responsive logo strip layout for desktop, laptop, mobile and A4 print. Logo and labels render only from explicit settings.

## How to enable

1. Back up V25.00 website and database. Upload PATCH ZIP, preserving the `assets` folder and PHP paths.
2. Login as admin and open `admin-settings.php#settings-quotation_credentials`.
3. Add a descriptive label for each credential (e.g. the exact registration or affiliation for which you have authorization).
4. Use **Browse logo image** in the matching Credential card; choose a PNG or JPG from your computer.
5. Set that slot's **Publication Approval** to `Display – Authorised to use` only if permitted to use the mark. Click Save Settings.
6. Check the public website footer and a quotation, tax invoice, money receipt, and both voucher print previews.
7. Generate one verified money receipt PDF from the existing test booking to verify actual PDF image embedding.

## Important

- These logos must represent actual registrations or affiliations. Uploading a government tourism logo does not establish recognition, accreditation or partnership. Do not enable it unless authorized.
- A locally uploaded PNG/JPG is strongly recommended. A manually entered HTTPS image URL can display in HTML/browser print, but the emailed receipt PDF intentionally does *not* retrieve remote URLs for security and reproducibility.
- This changes **display/branding only**. It does not change supplier, quotation, invoice, payment or booking calculations.
- The customer **Document Logo** and website **Website Logo** settings remain separate and unchanged.
- Existing historical invoice/receipt amounts and references are unchanged. The logo strip reads current general settings at render time; to freeze affiliations historically would require a later document-snapshot enhancement.
- PHP lint checks and an isolated receipt PDF/logo visibility test were performed. An authenticated MilesWeb settings upload, actual customer document previews and live emailing require development-host verification.
