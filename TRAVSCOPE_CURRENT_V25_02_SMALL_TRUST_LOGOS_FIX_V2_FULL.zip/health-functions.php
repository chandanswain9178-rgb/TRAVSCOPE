<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — DATA QUALITY + SYSTEM HEALTH CENTER
|--------------------------------------------------------------------------
|
| READ-ONLY diagnostics.
| No business row is changed by this helper.
| No SQL migration is required for this phase.
|
*/

function tsHealthTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];

    $key = strtolower($table);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
              AND table_name = ?
        ");
        $stmt->execute([$table]);

        return $cache[$key] =
            ((int)$stmt->fetchColumn() > 0);

    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}


function tsHealthColumnExists(
    PDO $pdo,
    string $table,
    string $column
): bool {
    static $cache = [];

    $key =
        strtolower(
            $table . '.' . $column
        );

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    if (
        !preg_match('/^[A-Za-z0-9_]+$/', $table)
        || !preg_match('/^[A-Za-z0-9_]+$/', $column)
    ) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = DATABASE()
              AND table_name = ?
              AND column_name = ?
        ");
        $stmt->execute([
            $table,
            $column
        ]);

        return $cache[$key] =
            ((int)$stmt->fetchColumn() > 0);

    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}


function tsHealthIndexExists(
    PDO $pdo,
    string $table,
    array $columns
): bool {
    if (
        !tsHealthTableExists($pdo, $table)
        || !$columns
    ) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT
                index_name,
                GROUP_CONCAT(
                    column_name
                    ORDER BY seq_in_index
                    SEPARATOR ','
                ) AS column_list
            FROM information_schema.statistics
            WHERE table_schema = DATABASE()
              AND table_name = ?
            GROUP BY index_name
        ");
        $stmt->execute([$table]);

        $wanted =
            strtolower(
                implode(',', $columns)
            );

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: []
            as $row
        ) {
            $list =
                strtolower(
                    (string)(
                        $row['column_list']
                        ?? ''
                    )
                );

            if (
                $list === $wanted
                || str_starts_with(
                    $list,
                    $wanted . ','
                )
            ) {
                return true;
            }
        }

    } catch (Throwable $e) {
        return false;
    }

    return false;
}


function tsHealthScalar(
    PDO $pdo,
    string $sql,
    array $params = []
): float {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    return
        (float)(
            $stmt->fetchColumn()
            ?: 0
        );
}


function tsHealthRows(
    PDO $pdo,
    string $sql,
    array $params = [],
    int $limit = 20
): array {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    return
        array_slice(
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            ?: [],
            0,
            max(1, min(100, $limit))
        );
}


function tsHealthCheck(
    string $id,
    string $category,
    string $title,
    string $status,
    string $message,
    string $recommendation = '',
    int $count = 0,
    array $details = [],
    ?string $link = null
): array {
    if (
        !in_array(
            $status,
            ['pass','info','warning','fail'],
            true
        )
    ) {
        $status = 'info';
    }

    return [
        'id' => $id,
        'category' => $category,
        'title' => $title,
        'status' => $status,
        'message' => $message,
        'recommendation' => $recommendation,
        'count' => $count,
        'details' => $details,
        'link' => $link,
    ];
}


function tsHealthRuntimeChecks(): array
{
    $checks = [];

    $phpOk =
        version_compare(
            PHP_VERSION,
            '8.1.0',
            '>='
        );

    $checks[] =
        tsHealthCheck(
            'runtime_php',
            'Runtime',
            'PHP Version',
            $phpOk
                ? 'pass'
                : 'fail',
            'Running PHP '
                . PHP_VERSION
                . '.',
            $phpOk
                ? ''
                : 'Upgrade PHP to 8.1+ before using the current TRAVSCOPE codebase.'
        );

    $required = [
        'pdo_mysql' => 'MySQL database access',
        'mbstring' => 'Unicode customer/supplier data',
        'fileinfo' => 'secure upload MIME validation',
        'openssl' => 'secure mail/payment/network operations',
    ];

    foreach ($required as $extension => $purpose) {
        $loaded =
            extension_loaded(
                $extension
            );

        $checks[] =
            tsHealthCheck(
                'runtime_ext_' . $extension,
                'Runtime',
                'PHP Extension · ' . $extension,
                $loaded
                    ? 'pass'
                    : 'fail',
                $loaded
                    ? (
                        $extension
                        . ' is available for '
                        . $purpose
                        . '.'
                    )
                    : (
                        $extension
                        . ' is missing; '
                        . $purpose
                        . ' may fail.'
                    ),
                $loaded
                    ? ''
                    : 'Enable the PHP ' . $extension . ' extension in hosting/PHP settings.'
            );
    }

    $optional = [
        'imap' => 'Booking/quotation email reply synchronization',
        'zip' => 'Final Trip Document Pack ZIP download',
        'curl' => 'external HTTP integrations/payment gateways',
        'intl' => 'international formatting support',
    ];

    foreach ($optional as $extension => $purpose) {
        $loaded =
            extension_loaded(
                $extension
            );

        $checks[] =
            tsHealthCheck(
                'runtime_optional_' . $extension,
                'Runtime',
                'Optional Extension · ' . $extension,
                $loaded
                    ? 'pass'
                    : 'warning',
                $loaded
                    ? (
                        $extension
                        . ' is available.'
                    )
                    : (
                        $extension
                        . ' is not enabled; '
                        . $purpose
                        . ' is limited.'
                    ),
                $loaded
                    ? ''
                    : 'Enable this extension only if you use the related feature.'
            );
    }

    $phpMailer =
        class_exists(
            '\PHPMailer\PHPMailer\PHPMailer'
        );

    $checks[] =
        tsHealthCheck(
            'runtime_phpmailer',
            'Runtime',
            'PHPMailer',
            $phpMailer
                ? 'pass'
                : 'fail',
            $phpMailer
                ? 'PHPMailer is loaded.'
                : 'PHPMailer class is not available.',
            $phpMailer
                ? ''
                : 'Check PHPMailer/src files and config.php loader paths.'
        );

    return $checks;
}


function tsHealthStorageChecks(): array
{
    $checks = [];

    $root =
        defined('ROOT_PATH')
            ? rtrim(
                (string)ROOT_PATH,
                '/\\'
            )
            : __DIR__;

    $paths = [
        'uploads' => [
            $root . '/uploads',
            true,
            'Main upload root',
        ],
        'profiles' => [
            $root . '/uploads/profiles',
            false,
            'Customer profile images',
        ],
        'traveller_documents' => [
            $root . '/uploads/traveller-documents',
            false,
            'Customer Profile traveller documents',
        ],
        'booking_documents' => [
            $root . '/uploads/booking-documents',
            false,
            'Booking traveller documents',
        ],
    ];

    foreach ($paths as $key => [$path, $required, $label]) {
        $exists =
            is_dir($path);

        $writable =
            $exists
                ? is_writable($path)
                : (
                    is_dir(dirname($path))
                    && is_writable(dirname($path))
                );

        if ($exists && $writable) {
            $status = 'pass';
            $message =
                $label
                . ' directory exists and is writable.';

        } elseif (!$exists && $writable) {
            $status =
                $required
                    ? 'warning'
                    : 'info';

            $message =
                $label
                . ' directory does not exist yet, but its parent is writable.';

        } else {
            $status =
                $required
                    ? 'fail'
                    : 'warning';

            $message =
                $label
                . ' directory is unavailable or not writable.';
        }

        $checks[] =
            tsHealthCheck(
                'storage_' . $key,
                'Storage',
                $label,
                $status,
                $message,
                $status === 'pass'
                    ? ''
                    : 'Check hosting ownership/permissions. Prefer 0755 directories and do not make document folders world-writable.',
                0,
                [[
                    'path' => $path,
                    'exists' =>
                        $exists
                            ? 'Yes'
                            : 'No',
                    'writable' =>
                        $writable
                            ? 'Yes'
                            : 'No',
                ]]
            );
    }

    return $checks;
}


function tsHealthModuleChecks(PDO $pdo): array
{
    $modules = [
        'Core Booking' => [
            'admins',
            'users',
            'enquiries',
            'bookings',
            'payments',
            'packages',
            'destinations',
        ],
        'CRM / Trip Foundation' => [
            'trips',
            'booking_trip_links',
            'crm_lead_meta',
            'crm_package_versions',
        ],
        'Service Costing' => [
            'trip_service_requirements',
            'cost_sheets',
            'cost_sheet_items',
        ],
        'Supplier Contracts / Procurement' => [
            'supplier_contracts',
            'supplier_rate_cards',
            'supplier_rate_items',
            'supplier_booking_orders',
            'supplier_booking_order_items',
            'supplier_booking_order_messages',
            'supplier_booking_order_tokens',
        ],
        'Accepted Quotation Snapshot' => [
            'quotation_acceptances',
            'booking_quotation_snapshots',
            'booking_service_snapshots',
        ],
        'Operations / Voucher' => [
            'booking_operation_checks',
            'booking_voucher_versions',
        ],
        'Travel Execution' => [
            'booking_execution_states',
            'booking_execution_contacts',
            'booking_execution_updates',
            'booking_execution_incidents',
            'booking_execution_checks',
        ],
        'Supplier Finance / Profitability' => [
            'supplier_invoices',
            'supplier_invoice_items',
            'supplier_payments',
            'booking_actual_direct_costs',
            'booking_profitability_closures',
        ],
        'Amendments / Cancellation Finance' => [
            'booking_amendments',
            'booking_cancellation_financials',
        ],
        'Customer Billing' => [
            'booking_payment_schedules',
            'booking_payment_installments',
            'payment_installment_allocations',
            'booking_invoice_versions',
            'booking_payment_receipts',
            'booking_customer_refunds',
            'booking_billing_adjustments',
            'booking_billing_reminders',
        ],
        'Traveller Documents' => [
            'booking_travellers',
            'booking_travel_documents',
            'booking_document_requirements',
            'booking_document_pack_versions',
        ],
        'Customer Communication' => [
            'booking_communications',
            'booking_communication_templates',
            'booking_communication_jobs',
        ],
        'Permissions / Audit' => [
            'admin_access_assignments',
            'admin_permission_overrides',
            'protected_action_audit',
        ],
        'Repeat Sales' => [
            'repeat_sales_opportunities',
        ],
        'System Notifications' => [
            'admin_notifications',
            'system_notification_state',
        ],
    ];

    $checks = [];

    foreach ($modules as $module => $tables) {
        $missing = [];

        foreach ($tables as $table) {
            if (!tsHealthTableExists($pdo, $table)) {
                $missing[] = $table;
            }
        }

        $checks[] =
            tsHealthCheck(
                'module_' . md5($module),
                'Modules',
                $module,
                !$missing
                    ? 'pass'
                    : 'warning',
                !$missing
                    ? 'All expected tables are installed.'
                    : (
                        count($missing)
                        . ' expected table'
                        . (
                            count($missing) === 1
                                ? ' is'
                                : 's are'
                        )
                        . ' missing.'
                    ),
                !$missing
                    ? ''
                    : 'Import the migration for this module only if you intend to use that feature.',
                count($missing),
                array_map(
                    static fn($table) => [
                        'missing_table' => $table,
                    ],
                    $missing
                )
            );
    }

    return $checks;
}


function tsHealthDataIntegrityChecks(PDO $pdo): array
{
    $checks = [];

    /*
    |--------------------------------------------------------------------------
    | Trip / Booking bridge integrity
    |--------------------------------------------------------------------------
    */

    if (
        tsHealthTableExists($pdo, 'booking_trip_links')
        && tsHealthTableExists($pdo, 'bookings')
        && tsHealthTableExists($pdo, 'trips')
    ) {
        try {
            $rows =
                tsHealthRows(
                    $pdo,
                    "
                    SELECT
                        l.id AS link_id,
                        l.booking_id,
                        l.trip_id,
                        l.enquiry_id
                    FROM booking_trip_links l
                    LEFT JOIN bookings b
                        ON b.id = l.booking_id
                    LEFT JOIN trips t
                        ON t.id = l.trip_id
                    WHERE
                        (l.booking_id IS NOT NULL AND b.id IS NULL)
                        OR
                        (l.trip_id IS NOT NULL AND t.id IS NULL)
                    ORDER BY l.id ASC
                    LIMIT 50
                    "
                );

            $count =
                (int)tsHealthScalar(
                    $pdo,
                    "
                    SELECT COUNT(*)
                    FROM booking_trip_links l
                    LEFT JOIN bookings b
                        ON b.id = l.booking_id
                    LEFT JOIN trips t
                        ON t.id = l.trip_id
                    WHERE
                        (l.booking_id IS NOT NULL AND b.id IS NULL)
                        OR
                        (l.trip_id IS NOT NULL AND t.id IS NULL)
                    "
                );

            $checks[] =
                tsHealthCheck(
                    'data_orphan_trip_links',
                    'Data Integrity',
                    'Orphan Trip / Booking Links',
                    $count === 0
                        ? 'pass'
                        : 'fail',
                    $count === 0
                        ? 'No broken Trip/Booking bridge references found.'
                        : $count . ' broken Trip/Booking bridge reference(s) found.',
                    $count === 0
                        ? ''
                        : 'Do not delete these blindly. Open the related Booking/Trip history and repair the exact bridge reference after confirming the intended record.',
                    $count,
                    $rows
                );

            $duplicateBookings =
                tsHealthRows(
                    $pdo,
                    "
                    SELECT
                        booking_id,
                        COUNT(*) AS link_count,
                        GROUP_CONCAT(id ORDER BY id) AS link_ids
                    FROM booking_trip_links
                    WHERE booking_id IS NOT NULL
                    GROUP BY booking_id
                    HAVING COUNT(*) > 1
                    ORDER BY link_count DESC
                    LIMIT 50
                    "
                );

            $checks[] =
                tsHealthCheck(
                    'data_duplicate_booking_trip_link',
                    'Data Integrity',
                    'Duplicate Booking → Trip Links',
                    !$duplicateBookings
                        ? 'pass'
                        : 'warning',
                    !$duplicateBookings
                        ? 'Each linked Booking has one bridge record.'
                        : count($duplicateBookings) . ' Booking(s) have multiple bridge rows.',
                    !$duplicateBookings
                        ? ''
                        : 'Review these records before cleanup. A duplicate bridge can cause duplicated analytics/finance joins.',
                    count($duplicateBookings),
                    $duplicateBookings
                );

        } catch (Throwable $e) {
            $checks[] =
                tsHealthCheck(
                    'data_trip_link_scan_error',
                    'Data Integrity',
                    'Trip / Booking Link Scan',
                    'warning',
                    'Unable to complete Trip/Booking bridge scan: ' . $e->getMessage(),
                    'Check current booking_trip_links schema.'
                );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Snapshot integrity
    |--------------------------------------------------------------------------
    */

    if (
        tsHealthTableExists($pdo, 'booking_trip_links')
        && tsHealthTableExists($pdo, 'booking_quotation_snapshots')
        && tsHealthTableExists($pdo, 'bookings')
    ) {
        try {
            $rows =
                tsHealthRows(
                    $pdo,
                    "
                    SELECT
                        b.id AS booking_id,
                        b.booking_number,
                        b.booking_status,
                        l.trip_id,
                        l.quotation_version_id
                    FROM booking_trip_links l
                    JOIN bookings b
                        ON b.id = l.booking_id
                    LEFT JOIN booking_quotation_snapshots q
                        ON q.booking_id = b.id
                    WHERE l.booking_id IS NOT NULL
                      AND l.quotation_version_id IS NOT NULL
                      AND q.id IS NULL
                    ORDER BY b.id DESC
                    LIMIT 50
                    "
                );

            $count =
                (int)tsHealthScalar(
                    $pdo,
                    "
                    SELECT COUNT(*)
                    FROM booking_trip_links l
                    JOIN bookings b
                        ON b.id = l.booking_id
                    LEFT JOIN booking_quotation_snapshots q
                        ON q.booking_id = b.id
                    WHERE l.booking_id IS NOT NULL
                      AND l.quotation_version_id IS NOT NULL
                      AND q.id IS NULL
                    "
                );

            $checks[] =
                tsHealthCheck(
                    'data_missing_booking_quote_snapshot',
                    'Commercial Integrity',
                    'Missing Accepted Quotation Snapshot',
                    $count === 0
                        ? 'pass'
                        : 'fail',
                    $count === 0
                        ? 'All quotation-linked Bookings have a frozen quotation snapshot.'
                        : $count . ' quotation-linked Booking(s) are missing booking_quotation_snapshots.',
                    $count === 0
                        ? ''
                        : 'Do not regenerate from live package data automatically. Recover from the exact accepted quotation/version history.',
                    $count,
                    $rows
                );

        } catch (Throwable $e) {
            $checks[] =
                tsHealthCheck(
                    'data_quote_snapshot_scan_error',
                    'Commercial Integrity',
                    'Accepted Quotation Snapshot Scan',
                    'warning',
                    'Unable to complete snapshot scan: ' . $e->getMessage()
                );
        }
    }

    if (
        tsHealthTableExists($pdo, 'booking_quotation_snapshots')
        && tsHealthTableExists($pdo, 'bookings')
    ) {
        try {
            $count =
                (int)tsHealthScalar(
                    $pdo,
                    "
                    SELECT COUNT(*)
                    FROM booking_quotation_snapshots q
                    LEFT JOIN bookings b
                        ON b.id = q.booking_id
                    WHERE b.id IS NULL
                    "
                );

            $rows =
                tsHealthRows(
                    $pdo,
                    "
                    SELECT q.id, q.booking_id, q.quotation_version_id
                    FROM booking_quotation_snapshots q
                    LEFT JOIN bookings b
                        ON b.id = q.booking_id
                    WHERE b.id IS NULL
                    ORDER BY q.id DESC
                    LIMIT 50
                    "
                );

            $checks[] =
                tsHealthCheck(
                    'data_orphan_quote_snapshots',
                    'Commercial Integrity',
                    'Orphan Booking Quotation Snapshots',
                    $count === 0
                        ? 'pass'
                        : 'fail',
                    $count === 0
                        ? 'No quotation snapshot points to a missing Booking.'
                        : $count . ' quotation snapshot(s) point to missing Bookings.',
                    $count === 0
                        ? ''
                        : 'Preserve snapshot history. Recover the missing Booking/bridge if possible before deleting any snapshot.',
                    $count,
                    $rows
                );

        } catch (Throwable $e) {
            // Keep scan non-blocking.
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Service / Supplier orphans
    |--------------------------------------------------------------------------
    */

    if (
        tsHealthTableExists($pdo, 'booking_service_snapshots')
        && tsHealthTableExists($pdo, 'bookings')
    ) {
        try {
            $count =
                (int)tsHealthScalar(
                    $pdo,
                    "
                    SELECT COUNT(*)
                    FROM booking_service_snapshots s
                    LEFT JOIN bookings b
                        ON b.id = s.booking_id
                    WHERE b.id IS NULL
                    "
                );

            $rows =
                tsHealthRows(
                    $pdo,
                    "
                    SELECT
                        s.id,
                        s.booking_id,
                        s.service_type,
                        s.title
                    FROM booking_service_snapshots s
                    LEFT JOIN bookings b
                        ON b.id = s.booking_id
                    WHERE b.id IS NULL
                    ORDER BY s.id DESC
                    LIMIT 50
                    "
                );

            $checks[] =
                tsHealthCheck(
                    'data_orphan_service_snapshots',
                    'Data Integrity',
                    'Orphan Booking Service Snapshots',
                    $count === 0
                        ? 'pass'
                        : 'fail',
                    $count === 0
                        ? 'No Booking service snapshot points to a missing Booking.'
                        : $count . ' service snapshot(s) point to missing Bookings.',
                    $count === 0
                        ? ''
                        : 'Treat these as commercial history. Investigate the Booking link before any cleanup.',
                    $count,
                    $rows
                );

        } catch (Throwable $e) {
        }
    }

    if (
        tsHealthTableExists($pdo, 'supplier_booking_orders')
        && tsHealthTableExists($pdo, 'bookings')
        && tsHealthTableExists($pdo, 'suppliers')
    ) {
        try {
            $count =
                (int)tsHealthScalar(
                    $pdo,
                    "
                    SELECT COUNT(*)
                    FROM supplier_booking_orders o
                    LEFT JOIN bookings b
                        ON b.id = o.booking_id
                    LEFT JOIN suppliers s
                        ON s.id = o.supplier_id
                    WHERE b.id IS NULL
                       OR s.id IS NULL
                    "
                );

            $rows =
                tsHealthRows(
                    $pdo,
                    "
                    SELECT
                        o.id,
                        o.order_code,
                        o.booking_id,
                        o.supplier_id,
                        o.status
                    FROM supplier_booking_orders o
                    LEFT JOIN bookings b
                        ON b.id = o.booking_id
                    LEFT JOIN suppliers s
                        ON s.id = o.supplier_id
                    WHERE b.id IS NULL
                       OR s.id IS NULL
                    ORDER BY o.id DESC
                    LIMIT 50
                    "
                );

            $checks[] =
                tsHealthCheck(
                    'data_orphan_supplier_orders',
                    'Supplier Integrity',
                    'Broken Supplier Procurement References',
                    $count === 0
                        ? 'pass'
                        : 'fail',
                    $count === 0
                        ? 'Supplier Booking Orders reference valid Booking and Supplier records.'
                        : $count . ' supplier procurement order(s) have a missing Booking or Supplier.',
                    $count === 0
                        ? ''
                        : 'Preserve order/message history. Restore or relink the missing master record after manual verification.',
                    $count,
                    $rows
                );

        } catch (Throwable $e) {
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Traveller document integrity
    |--------------------------------------------------------------------------
    */

    if (
        tsHealthTableExists($pdo, 'booking_travel_documents')
        && tsHealthTableExists($pdo, 'bookings')
    ) {
        try {
            $travellerJoin =
                tsHealthTableExists(
                    $pdo,
                    'booking_travellers'
                )
                    ? "
                        LEFT JOIN booking_travellers t
                            ON t.id = d.traveller_id
                      "
                    : '';

            $travellerCondition =
                tsHealthTableExists(
                    $pdo,
                    'booking_travellers'
                )
                    ? "
                        OR (
                            d.traveller_id > 0
                            AND t.id IS NULL
                        )
                      "
                    : '';

            $count =
                (int)tsHealthScalar(
                    $pdo,
                    "
                    SELECT COUNT(*)
                    FROM booking_travel_documents d
                    LEFT JOIN bookings b
                        ON b.id = d.booking_id
                    {$travellerJoin}
                    WHERE b.id IS NULL
                    {$travellerCondition}
                    "
                );

            $checks[] =
                tsHealthCheck(
                    'data_booking_document_references',
                    'Document Integrity',
                    'Booking Document References',
                    $count === 0
                        ? 'pass'
                        : 'fail',
                    $count === 0
                        ? 'Booking document database references are consistent.'
                        : $count . ' Booking document row(s) reference missing Booking/Traveller records.',
                    $count === 0
                        ? ''
                        : 'Do not delete the file first. Repair the database relationship while preserving the document audit trail.',
                    $count
                );

        } catch (Throwable $e) {
        }
    }

    return $checks;
}


function tsHealthFinanceChecks(PDO $pdo): array
{
    $checks = [];

    if (
        !tsHealthTableExists($pdo, 'bookings')
        || !tsHealthTableExists($pdo, 'payments')
    ) {
        return $checks;
    }

    try {
        $refundJoin =
            tsHealthTableExists(
                $pdo,
                'booking_customer_refunds'
            )
                ? "
                    LEFT JOIN (
                        SELECT
                            booking_id,
                            COALESCE(
                                SUM(
                                    CASE
                                        WHEN status = 'paid'
                                        THEN amount
                                        ELSE 0
                                    END
                                ),
                                0
                            ) AS paid_refunds
                        FROM booking_customer_refunds
                        GROUP BY booking_id
                    ) r
                        ON r.booking_id = b.id
                  "
                : '';

        $refundExpr =
            tsHealthTableExists(
                $pdo,
                'booking_customer_refunds'
            )
                ? "COALESCE(r.paid_refunds,0)"
                : "0";

        $sql = "
            SELECT
                b.id AS booking_id,
                b.booking_number,
                b.total_amount,
                b.paid_amount AS stored_paid_amount,
                b.payment_status,
                COALESCE(p.success_payments,0) AS success_payments,
                {$refundExpr} AS paid_refunds,
                GREATEST(
                    COALESCE(p.success_payments,0)
                    - {$refundExpr},
                    0
                ) AS expected_net_paid
            FROM bookings b
            LEFT JOIN (
                SELECT
                    booking_id,
                    COALESCE(
                        SUM(
                            CASE
                                WHEN status = 'success'
                                THEN amount
                                ELSE 0
                            END
                        ),
                        0
                    ) AS success_payments
                FROM payments
                GROUP BY booking_id
            ) p
                ON p.booking_id = b.id
            {$refundJoin}
            WHERE ABS(
                b.paid_amount
                - GREATEST(
                    COALESCE(p.success_payments,0)
                    - {$refundExpr},
                    0
                )
            ) > 0.01
            ORDER BY b.id DESC
            LIMIT 50
        ";

        $rows =
            tsHealthRows(
                $pdo,
                $sql,
                [],
                50
            );

        $countSql =
            "
            SELECT COUNT(*)
            FROM (
                SELECT b.id
                FROM bookings b
                LEFT JOIN (
                    SELECT
                        booking_id,
                        COALESCE(
                            SUM(
                                CASE
                                    WHEN status = 'success'
                                    THEN amount
                                    ELSE 0
                                END
                            ),
                            0
                        ) AS success_payments
                    FROM payments
                    GROUP BY booking_id
                ) p
                    ON p.booking_id = b.id
                {$refundJoin}
                WHERE ABS(
                    b.paid_amount
                    - GREATEST(
                        COALESCE(p.success_payments,0)
                        - {$refundExpr},
                        0
                    )
                ) > 0.01
            ) x
            ";

        $count =
            (int)tsHealthScalar(
                $pdo,
                $countSql
            );

        $checks[] =
            tsHealthCheck(
                'finance_booking_paid_reconciliation',
                'Finance Integrity',
                'Booking Paid Amount Reconciliation',
                $count === 0
                    ? 'pass'
                    : 'warning',
                $count === 0
                    ? 'Booking paid_amount matches successful customer payments less paid refunds.'
                    : $count . ' Booking(s) differ from the customer payment/refund ledger.',
                $count === 0
                    ? ''
                    : 'Do not auto-correct. Review each Booking/payment/refund history first; older manually migrated Bookings may require an explicit reconciliation decision.',
                $count,
                $rows,
                'admin-payments.php'
            );

    } catch (Throwable $e) {
        $checks[] =
            tsHealthCheck(
                'finance_reconciliation_scan',
                'Finance Integrity',
                'Booking Paid Amount Reconciliation',
                'warning',
                'Unable to run customer-payment reconciliation: ' . $e->getMessage(),
                'Check current payments/refund schema before attempting any financial repair.'
            );
    }

    if (
        tsHealthTableExists(
            $pdo,
            'booking_profitability_closures'
        )
    ) {
        try {
            $count =
                (int)tsHealthScalar(
                    $pdo,
                    "
                    SELECT COUNT(*)
                    FROM booking_profitability_closures c
                    LEFT JOIN bookings b
                        ON b.id = c.booking_id
                    WHERE b.id IS NULL
                    "
                );

            $checks[] =
                tsHealthCheck(
                    'finance_orphan_profitability_closure',
                    'Finance Integrity',
                    'Profitability Closure References',
                    $count === 0
                        ? 'pass'
                        : 'fail',
                    $count === 0
                        ? 'All profitability closures reference valid Bookings.'
                        : $count . ' profitability closure(s) reference missing Bookings.',
                    $count === 0
                        ? ''
                        : 'Preserve closure snapshots. Recover the Booking relationship before any data cleanup.',
                    $count
                );

        } catch (Throwable $e) {
        }
    }

    return $checks;
}


function tsHealthFileChecks(PDO $pdo): array
{
    $checks = [];

    $root =
        defined('ROOT_PATH')
            ? rtrim(
                (string)ROOT_PATH,
                '/\\'
            )
            : __DIR__;

    if (
        tsHealthTableExists(
            $pdo,
            'booking_travel_documents'
        )
        && tsHealthColumnExists(
            $pdo,
            'booking_travel_documents',
            'file_path'
        )
    ) {
        try {
            $stmt = $pdo->query("
                SELECT
                    id,
                    booking_id,
                    traveller_id,
                    document_type,
                    original_name,
                    file_path,
                    verification_status
                FROM booking_travel_documents
                WHERE verification_status <> 'archived'
                ORDER BY id DESC
                LIMIT 5000
            ");

            $missing = [];

            foreach (
                $stmt->fetchAll(PDO::FETCH_ASSOC)
                ?: []
                as $row
            ) {
                $relative =
                    ltrim(
                        trim(
                            (string)$row['file_path']
                        ),
                        '/\\'
                    );

                if ($relative === '') {
                    $missing[] =
                        $row;
                    continue;
                }

                $full =
                    $root
                    . DIRECTORY_SEPARATOR
                    . str_replace(
                        ['/', '\\'],
                        DIRECTORY_SEPARATOR,
                        $relative
                    );

                if (!is_file($full)) {
                    $missing[] =
                        $row;
                }
            }

            $checks[] =
                tsHealthCheck(
                    'files_booking_documents',
                    'File Integrity',
                    'Booking Document Files',
                    !$missing
                        ? 'pass'
                        : 'fail',
                    !$missing
                        ? 'All scanned active Booking document rows have a physical file.'
                        : count($missing) . ' active Booking document file(s) are missing from storage.',
                    !$missing
                        ? ''
                        : 'Restore files from backup or mark/re-upload through the Document Center. Do not silently repoint a document to an unrelated file.',
                    count($missing),
                    array_slice(
                        $missing,
                        0,
                        30
                    )
                );

        } catch (Throwable $e) {
            $checks[] =
                tsHealthCheck(
                    'files_booking_documents_scan',
                    'File Integrity',
                    'Booking Document Files',
                    'warning',
                    'Unable to scan Booking document files: ' . $e->getMessage()
                );
        }
    }

    if (
        tsHealthTableExists(
            $pdo,
            'user_travel_documents'
        )
        && tsHealthColumnExists(
            $pdo,
            'user_travel_documents',
            'file_path'
        )
    ) {
        try {
            $stmt = $pdo->query("
                SELECT
                    id,
                    user_id,
                    document_type,
                    original_name,
                    file_path
                FROM user_travel_documents
                ORDER BY id DESC
                LIMIT 5000
            ");

            $missing = [];

            foreach (
                $stmt->fetchAll(PDO::FETCH_ASSOC)
                ?: []
                as $row
            ) {
                $relative =
                    ltrim(
                        trim(
                            (string)$row['file_path']
                        ),
                        '/\\'
                    );

                $full =
                    $root
                    . DIRECTORY_SEPARATOR
                    . str_replace(
                        ['/', '\\'],
                        DIRECTORY_SEPARATOR,
                        $relative
                    );

                if (
                    $relative === ''
                    || !is_file($full)
                ) {
                    $missing[] =
                        $row;
                }
            }

            $checks[] =
                tsHealthCheck(
                    'files_profile_documents',
                    'File Integrity',
                    'Customer Profile Document Files',
                    !$missing
                        ? 'pass'
                        : 'warning',
                    !$missing
                        ? 'All scanned Customer Profile document rows have a physical file.'
                        : count($missing) . ' Customer Profile document file(s) are missing.',
                    !$missing
                        ? ''
                        : 'Restore from backup or ask the customer to upload a replacement. Booking copies are separate and should not be overwritten.',
                    count($missing),
                    array_slice(
                        $missing,
                        0,
                        30
                    )
                );

        } catch (Throwable $e) {
        }
    }

    return $checks;
}


function tsHealthIndexChecks(PDO $pdo): array
{
    $targets = [
        [
            'booking_trip_links',
            ['booking_id'],
            'Booking bridge lookup',
        ],
        [
            'booking_trip_links',
            ['trip_id'],
            'Trip bridge lookup',
        ],
        [
            'booking_service_snapshots',
            ['booking_id'],
            'Booking service lookup',
        ],
        [
            'supplier_booking_orders',
            ['booking_id'],
            'Booking supplier procurement lookup',
        ],
        [
            'booking_payment_installments',
            ['booking_id'],
            'Booking installment lookup',
        ],
        [
            'booking_communications',
            ['booking_id'],
            'Booking communication timeline',
        ],
        [
            'admin_notifications',
            ['admin_id','status'],
            'Admin notification inbox',
        ],
    ];

    $checks = [];

    foreach ($targets as [$table, $columns, $purpose]) {
        if (!tsHealthTableExists($pdo, $table)) {
            continue;
        }

        $exists =
            tsHealthIndexExists(
                $pdo,
                $table,
                $columns
            );

        $checks[] =
            tsHealthCheck(
                'index_' . $table . '_' . implode('_', $columns),
                'Database Performance',
                'Index · ' . $table . '(' . implode(', ', $columns) . ')',
                $exists
                    ? 'pass'
                    : 'warning',
                $exists
                    ? $purpose . ' index is available.'
                    : $purpose . ' index was not detected.',
                $exists
                    ? ''
                    : 'Add an index only after confirming the exact current table definition. This Health Center does not alter indexes automatically.'
            );
    }

    return $checks;
}


function tsHealthDiagnostics(PDO $pdo): array
{
    $checks = [];

    if (
        tsHealthTableExists(
            $pdo,
            'booking_communication_jobs'
        )
    ) {
        try {
            $failed =
                (int)tsHealthScalar(
                    $pdo,
                    "
                    SELECT COUNT(*)
                    FROM booking_communication_jobs
                    WHERE status = 'failed'
                    "
                );

            $rows =
                tsHealthRows(
                    $pdo,
                    "
                    SELECT
                        id,
                        booking_id,
                        job_type,
                        channel,
                        due_at,
                        last_error
                    FROM booking_communication_jobs
                    WHERE status = 'failed'
                    ORDER BY id DESC
                    LIMIT 30
                    "
                );

            $checks[] =
                tsHealthCheck(
                    'diag_failed_communication_jobs',
                    'Diagnostics',
                    'Failed Communication Jobs',
                    $failed === 0
                        ? 'pass'
                        : 'warning',
                    $failed === 0
                        ? 'No failed customer communication jobs.'
                        : $failed . ' customer communication job(s) are failed.',
                    $failed === 0
                        ? ''
                        : 'Open the exact Booking Communication Center and resolve SMTP/template/recipient issues before retrying.',
                    $failed,
                    $rows,
                    'admin-communication-queue.php'
                );

        } catch (Throwable $e) {
        }
    }

    if (
        tsHealthTableExists(
            $pdo,
            'admin_notifications'
        )
    ) {
        try {
            $critical =
                (int)tsHealthScalar(
                    $pdo,
                    "
                    SELECT COUNT(*)
                    FROM admin_notifications
                    WHERE status IN ('unread','read')
                      AND severity = 'critical'
                    "
                );

            $checks[] =
                tsHealthCheck(
                    'diag_critical_notifications',
                    'Diagnostics',
                    'Active Critical Notifications',
                    $critical === 0
                        ? 'pass'
                        : 'warning',
                    $critical === 0
                        ? 'No active Critical system notifications.'
                        : $critical . ' active Critical notification(s) need operational attention.',
                    $critical === 0
                        ? ''
                        : 'Open System Notifications and resolve the underlying business condition. Do not treat notification deletion as a repair.',
                    $critical,
                    [],
                    'admin-notifications.php?severity=critical&status=active'
                );

        } catch (Throwable $e) {
        }
    }

    return $checks;
}


function tsHealthScan(PDO $pdo): array
{
    $started =
        microtime(true);

    $checks = [];

    foreach ([
        tsHealthRuntimeChecks(),
        tsHealthStorageChecks(),
        tsHealthModuleChecks($pdo),
        tsHealthDataIntegrityChecks($pdo),
        tsHealthFinanceChecks($pdo),
        tsHealthFileChecks($pdo),
        tsHealthIndexChecks($pdo),
        tsHealthDiagnostics($pdo),
    ] as $group) {
        foreach ($group as $check) {
            $checks[] = $check;
        }
    }

    $summary = [
        'pass' => 0,
        'info' => 0,
        'warning' => 0,
        'fail' => 0,
        'total' => count($checks),
    ];

    foreach ($checks as $check) {
        $summary[
            (string)$check['status']
        ]++;
    }

    $summary['health_score'] =
        $summary['total'] > 0
            ? max(
                0,
                round(
                    (
                        (
                            $summary['pass']
                            + $summary['info'] * 0.8
                            + $summary['warning'] * 0.4
                        )
                        / $summary['total']
                    ) * 100
                )
            )
            : 100;

    $summary['duration_ms'] =
        (int)round(
            (
                microtime(true)
                - $started
            ) * 1000
        );

    return [
        'generated_at' =>
            date('Y-m-d H:i:s'),
        'summary' => $summary,
        'checks' => $checks,
    ];
}
