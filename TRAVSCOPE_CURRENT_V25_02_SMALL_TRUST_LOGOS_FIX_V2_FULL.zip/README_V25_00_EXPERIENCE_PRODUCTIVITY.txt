TRAVSCOPE V25.00 — EXPERIENCE & PRODUCTIVITY UPGRADE
Base: TRAVSCOPE V24.99 — Complete Responsive Typography Foundation
Release type: progressive screen-only UX improvements. No database/schema changes.

WHAT CHANGED
------------
- Shared V25.00 screen-only CSS/JS loaded by the same 97 pages that use the
  V24.99 responsive foundation: 68 admin/staff and 29 public/customer pages.
- Admin workspace toolbar: Jump to page section; Comfort text; Compact view.
- Display preferences are remembered in local browser storage (no personal or
  quotation data is stored by this feature). Settings can be toggled off.
- Keyboard: Alt + Shift + J focuses the admin Jump to selector; a keyboard-first
  Skip to main content link is provided on accessible page layouts.
- Back-to-top button appears on long scrolling pages (admin and public).
- Tables that genuinely overflow get a local horizontal scroll region and a
  readable scroll hint, including dynamically inserted tables.
- Responsive sizing for controls and a reduced-motion fallback.
- The public website does not show the admin workspace toolbar.
- No existing form processing, quote version, rate, customer, hotel/vehicle,
  invoice, accounting, or database code is changed by this release.
- Screen-only CSS and media=screen mean quotation/invoice/voucher A4 print rules
  are excluded from these modifications.

FILES CHANGED
-------------
- 97 HTML-generating PHP pages: two new CSS/JS links per page, before </head>.
- NEW: assets/travscope-experience-v2500.css
- NEW: assets/travscope-experience-v2500.js
- NEW: README_V25_00_EXPERIENCE_PRODUCTIVITY.txt
- NEW: QA_V25_00.md (audit notes)

DEPLOYMENT (MILESWEB / travscope.com DEVELOPMENT HOST)
------------------------------------------------------
1. Back up your working V24.99 site and the database.
2. Upload the PATCH ZIP contents into your actual web root (preserve folders).
3. Verify the two V25.00 assets are in /assets/.
4. Hard-refresh (Ctrl+Shift+R), or clear the site cache.
5. Admin: test CRM/trip quotation, rate selection, supplier requests, bookings,
   hotel allocation, vehicle allocation, payments and settings. Use the new
   Jump to, Comfort text and Compact view options, especially at laptop width.
6. Public: test homepage, package details, search, login, register, booking.
7. Test one quotation export and one invoice PDF at A4 (screen CSS is excluded,
   but live print/export still requires verification).
8. Check 1920x1080, 1366x768, 1280x800, 390x844, 320x568, and browser zoom.
9. If a regression appears, restore V24.99 and capture URL, error screenshot,
   browser zoom and the interaction that produced the problem.

TESTING / LIMITATIONS
---------------------
- PHP source syntax and JS syntax have been checked locally.
- Chromium isolated admin/public UI fixtures tested across five widths with
  navigation, preference toggles, table scrolling and dynamic table insertion.
- Fixture tests are NOT a substitute for authenticated MilesWeb page flows.
- No login to the live development website, database mutation, or end-to-end
  quotation PDF verification was performed in this release.

SQL
---
No SQL required.
