TRAVSCOPE V24.90 — BULK PACKAGE MASTER CREATION
Base: V24.89 — Intellectual Client Content Standard
Date: 07 October 2026

WHAT CHANGED
- Supplier Packages & Rates now supports bulk creation into Package Master.
- Use the existing row checkboxes or Select All Visible, then click:
  "Add Selected to Package Master".
- Each eligible supplier package is created as an editable TRAVSCOPE Draft using
  the same trusted Create Package From Supplier workflow as the existing
  single-package button.
- Existing linked Package Master records are detected and skipped. They are never
  duplicated or overwritten.
- Packages without an active package/version or active exact-PAX rate are skipped
  and reported to the admin.
- Bulk creation keeps supplier source links, exact-PAX quotation costing,
  supplier-derived reference price periods, itinerary, package content and the
  V24.89 intellectual-client content rules.
- The existing permanent-delete workflow remains separate and unchanged.

ADMIN WORKFLOW
1. Open Supplier Control > Supplier Packages / Rates.
2. Filter by supplier/search/readiness if required.
3. Tick individual packages or use Select All Visible.
4. Click Add Selected to Package Master.
5. Confirm once.
6. TRAVSCOPE creates all eligible Package Master records as Drafts in one run.
7. Existing links and not-ready packages are safely skipped and summarized.

DATABASE
No SQL required.
