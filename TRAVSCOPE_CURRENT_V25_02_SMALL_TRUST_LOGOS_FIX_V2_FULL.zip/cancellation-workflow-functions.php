<?php
/**
 * TRAVSCOPE Booking cancellation / Finance bridge.
 * An administrator's booking-status cancellation creates a cancellation case,
 * but NEVER makes a refund payable until a separate finance assessment.
 */

declare(strict_types=1);
require_once __DIR__ . '/cancellation-mail-functions.php';

function tsCancelRecordDirect(PDO $pdo, int $bookingId, int $adminId, string $origin): int
{
    if ($bookingId <= 0 || $adminId <= 0) {
        throw new RuntimeException('Invalid booking or administrator.');
    }
    if ($pdo->inTransaction()) {
        throw new RuntimeException('Cancellation must start outside another transaction.');
    }
    $pdo->beginTransaction();
    try {
        $lock = $pdo->prepare('SELECT id, booking_status FROM bookings WHERE id=? FOR UPDATE');
        $lock->execute([$bookingId]);
        $booking = $lock->fetch(PDO::FETCH_ASSOC);
        if (!$booking || !in_array(strtolower((string)$booking['booking_status']), ['pending','confirmed'], true)) {
            throw new RuntimeException('Only pending or confirmed bookings can be cancelled.');
        }
        // Reuse a customer's existing pending cancellation, rather than making a duplicate.
        $find = $pdo->prepare("SELECT id,status FROM booking_cancellations WHERE booking_id=? AND status IN ('approved','pending') ORDER BY FIELD(status,'approved','pending'),id DESC LIMIT 1 FOR UPDATE");
        $find->execute([$bookingId]);
        $existing = $find->fetch(PDO::FETCH_ASSOC);
        $caseId = 0;
        $note = 'Direct administrative cancellation from ' . substr(trim($origin), 0, 90)
            . '; refund/penalty assessment must be recorded separately. Admin ID ' . $adminId . '.';
        if ($existing) {
            $caseId = (int)$existing['id'];
            if ($existing['status'] === 'pending') {
                $update = $pdo->prepare("UPDATE booking_cancellations SET status='approved', admin_notes=?, processed_at=NOW(),updated_at=NOW() WHERE id=? AND status='pending'");
                $update->execute([$note,$caseId]);
            }
        } else {
            $ins = $pdo->prepare("INSERT INTO booking_cancellations (booking_id,user_id,reason,status,admin_notes,requested_at,processed_at) SELECT id,user_id,?,'approved',?,NOW(),NOW() FROM bookings WHERE id=?");
            $ins->execute(['Administrative booking cancellation; assess charges and refunds in Finance → Cancellations.',$note,$bookingId]);
            $caseId = (int)$pdo->lastInsertId();
        }
        $update = $pdo->prepare("UPDATE bookings SET booking_status='cancelled',updated_at=NOW() WHERE id=? AND booking_status IN ('pending','confirmed')");
        $update->execute([$bookingId]);
        if ($update->rowCount() !== 1) throw new RuntimeException('Booking status changed; please retry.');
        $pdo->commit();
        $notice = tsCancelSendMail($pdo,$caseId,'approved',$adminId);
        if (session_status()===PHP_SESSION_ACTIVE && !$notice['ok']) {
            $_SESSION['admin_cancellation_mail_notice'] = (string)$notice['message'];
        }
        return $caseId;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/** Backfills exactly one case for a legacy direct cancellation, on explicit admin POST only. */
function tsCancelOpenLegacyCase(PDO $pdo, int $bookingId, int $adminId): int
{
    if ($bookingId <= 0 || $adminId <= 0) throw new RuntimeException('Invalid legacy cancellation.');
    $pdo->beginTransaction();
    try {
        $s = $pdo->prepare('SELECT id,booking_status,user_id,updated_at,created_at FROM bookings WHERE id=? FOR UPDATE');
        $s->execute([$bookingId]);
        $booking = $s->fetch(PDO::FETCH_ASSOC);
        if (!$booking || strtolower((string)$booking['booking_status']) !== 'cancelled') throw new RuntimeException('This booking is not cancelled.');
        $s = $pdo->prepare("SELECT id FROM booking_cancellations WHERE booking_id=? AND status IN ('approved','pending') ORDER BY id DESC LIMIT 1 FOR UPDATE");
        $s->execute([$bookingId]);
        $id = (int)($s->fetchColumn() ?: 0);
        if (!$id) {
            $s = $pdo->prepare("INSERT INTO booking_cancellations (booking_id,user_id,reason,status,admin_notes,requested_at,processed_at) VALUES (?,?,?,'approved',?,COALESCE(?,NOW()),NOW())");
            $s->execute([$bookingId,$booking['user_id'],'Historical administrative cancellation; financial review required.','Reconciled from an already-cancelled Booking by administrator #'.$adminId.'; no refund approved yet.',$booking['updated_at'] ?: $booking['created_at']]);
            $id = (int)$pdo->lastInsertId();
        }
        $pdo->commit();
        return $id;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}
