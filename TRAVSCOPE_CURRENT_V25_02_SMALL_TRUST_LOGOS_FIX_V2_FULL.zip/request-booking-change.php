<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/amendment-functions.php';
requireLogin();

$user = currentUser($pdo);
if (!$user) {
    unset($_SESSION['user_id']);
    redirect(BASE_URL . 'login.php');
}

$userId = (int)$user['id'];
$bookingId = max(0,(int)($_GET['booking'] ?? $_POST['booking_id'] ?? 0));
if ($bookingId <= 0) redirect(BASE_URL . 'my-bookings.php');

$stmt=$pdo->prepare("SELECT b.*,p.title AS package_title,d.name AS destination_name FROM bookings b LEFT JOIN packages p ON p.id=b.package_id LEFT JOIN destinations d ON d.id=p.destination_id WHERE b.id=? AND b.user_id=? LIMIT 1");
$stmt->execute([$bookingId,$userId]);
$booking=$stmt->fetch(PDO::FETCH_ASSOC);
if (!$booking) { http_response_code(404); exit('Booking not found.'); }
if (!tsAmendReady($pdo)) { http_response_code(503); exit('Booking change module is not installed yet.'); }

$error='';
$success='';
$pending=tsAmendPending($pdo,$bookingId);
$canRequest=!$pending && !in_array(strtolower((string)$booking['booking_status']),['cancelled','completed'],true);

if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        if (!verifyCsrf((string)($_POST['csrf_token']??''))) throw new RuntimeException('Security verification failed. Refresh and try again.');
        if (!$canRequest) throw new RuntimeException('This Booking cannot accept a new change request right now.');
        $am=tsAmendCreateRequest($pdo,$bookingId,'customer',$userId,null,trim((string)($_POST['request_text']??'')));
        $_SESSION['booking_change_success']='Booking change request V'.(int)$am['version_number'].' submitted to TRAVSCOPE.';
        redirect(BASE_URL.'request-booking-change.php?booking='.$bookingId);
    } catch (RuntimeException $e) {
        $error=$e->getMessage();
    } catch (Throwable $e) {
        error_log('Customer Booking change request: '.$e->getMessage());
        $error='Unable to submit Booking change request.';
    }
}

if (!empty($_SESSION['booking_change_success'])) {
    $success=(string)$_SESSION['booking_change_success'];
    unset($_SESSION['booking_change_success']);
    $pending=tsAmendPending($pdo,$bookingId);
    $canRequest=false;
}

$siteName=getSetting($pdo,'site_name','TRAVSCOPE.COM');
$currencySymbol=getSetting($pdo,'currency_symbol','₹');
$fullName=trim((string)($user['full_name']??'Traveller'));
function rbcE(?string $v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Request Booking Change | <?= rbcE($siteName); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f5f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.header{height:70px;padding:0 5%;display:flex;align-items:center;justify-content:space-between;background:#fff;border-bottom:1px solid #e2e8f0}.logo{font-weight:900;color:#0f172a}.logo span{color:#2563eb}.wrap{max-width:900px;margin:28px auto;padding:0 14px}.card{background:#fff;border:1px solid #e2e8f0;border-radius:15px;box-shadow:0 8px 25px rgba(15,23,42,.05);overflow:hidden}.head{padding:16px 18px;border-bottom:1px solid #e2e8f0;background:#fbfdff}.head h1{margin:0;font-size:18px}.head p{margin:5px 0 0;color:#64748b;font-size:11px;line-height:1.5}.body{padding:17px}.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px}.summary div{padding:10px;border-radius:10px;background:#f8fafc;border:1px solid #e2e8f0}.summary span{display:block;color:#64748b;font-size:8px;font-weight:900;text-transform:uppercase}.summary strong{display:block;margin-top:4px;font-size:11px}textarea{width:100%;min-height:140px;padding:12px;border:1px solid #cbd5e1;border-radius:10px;font:inherit;font-size:12px;resize:vertical}.btn{display:inline-flex;align-items:center;gap:7px;padding:10px 13px;border-radius:9px;border:0;background:#2563eb;color:#fff;text-decoration:none;font-weight:800;font-size:11px;cursor:pointer}.btn.light{background:#fff;color:#475569;border:1px solid #cbd5e1}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.notice{padding:11px 12px;border-radius:10px;margin-bottom:12px;font-size:11px}.ok{background:#ecfdf5;color:#047857;border:1px solid #a7f3d0}.err{background:#fef2f2;color:#b91c1c;border:1px solid #fecaca}.pending{padding:13px;border:1px solid #fed7aa;border-radius:11px;background:#fff7ed;color:#9a3412;font-size:11px;line-height:1.55}@media(max-width:700px){.summary{grid-template-columns:1fr 1fr}}@media(max-width:480px){.summary{grid-template-columns:1fr}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-public-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="public"></script>
</head>
<body>
<header class="header"><div class="logo">TRAV<span>SCOPE</span></div><div><?= rbcE($fullName); ?></div></header>
<main class="wrap"><section class="card"><div class="head"><h1>Request a Booking Change</h1><p>TRAVSCOPE will review supplier availability, cost and customer price impact before anything is changed.</p></div><div class="body">
<?php if ($success): ?><div class="notice ok"><i class="fa-solid fa-circle-check"></i> <?= rbcE($success); ?></div><?php endif; ?>
<?php if ($error): ?><div class="notice err"><i class="fa-solid fa-triangle-exclamation"></i> <?= rbcE($error); ?></div><?php endif; ?>
<div class="summary"><div><span>Booking</span><strong><?= rbcE((string)$booking['booking_number']); ?></strong></div><div><span>Package</span><strong><?= rbcE((string)($booking['package_title']?:'Travel Booking')); ?></strong></div><div><span>Destination</span><strong><?= rbcE((string)($booking['destination_name']?:'-')); ?></strong></div><div><span>Current Total</span><strong><?= rbcE($currencySymbol); ?><?= number_format((float)$booking['total_amount'],2); ?></strong></div></div>
<?php if ($pending): ?>
<div class="pending"><strong>Amendment V<?= (int)$pending['version_number']; ?> is already under review.</strong><br><?= nl2br(rbcE((string)$pending['request_text'])); ?></div><div class="actions"><a class="btn light" href="<?= rbcE(BASE_URL.'booking-details.php?id='.$bookingId); ?>"><i class="fa-solid fa-arrow-left"></i> Back to Booking</a></div>
<?php elseif ($canRequest): ?>
<form method="post"><input type="hidden" name="booking_id" value="<?= $bookingId; ?>"><input type="hidden" name="csrf_token" value="<?= rbcE(csrfToken()); ?>"><label for="request_text" style="display:block;margin-bottom:6px;font-size:11px;font-weight:800;">What would you like to change?</label><textarea id="request_text" name="request_text" maxlength="5000" required placeholder="Example: Please change the Puri hotel to a sea-facing room and shift the check-in date by one day."><?= rbcE((string)($_POST['request_text']??'')); ?></textarea><div style="margin-top:7px;color:#64748b;font-size:10px;line-height:1.5;">Submitting this request does not change your Booking automatically. TRAVSCOPE first verifies supplier and price impact.</div><div class="actions"><button class="btn" type="submit"><i class="fa-solid fa-paper-plane"></i> Submit Change Request</button><a class="btn light" href="<?= rbcE(BASE_URL.'booking-details.php?id='.$bookingId); ?>">Cancel</a></div></form>
<?php else: ?><div class="pending">This Booking cannot accept a new change request.</div><div class="actions"><a class="btn light" href="<?= rbcE(BASE_URL.'booking-details.php?id='.$bookingId); ?>">Back to Booking</a></div><?php endif; ?>
</div></section></main>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
