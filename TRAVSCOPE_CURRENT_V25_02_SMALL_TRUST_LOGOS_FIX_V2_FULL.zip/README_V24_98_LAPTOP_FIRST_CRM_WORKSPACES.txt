TRAVSCOPE V24.98 — Laptop-first Costing / RFQ / Hotel / Transport Workspaces
==========================================================================
BASE: V24.97 Professional Itinerary Studio
NO DATABASE CHANGE — No SQL required.

PURPOSE
Improve actual daily operation on 1366x768 / 1280x800 / 1024px laptop screens while preserving the existing PHP forms, CSRF tokens, supplier contract source-of-truth, quotation version IDs, and POST actions.

SCREENS UPDATED
1. admin-crm.php — Trip Services & Cost Sheet
   - Quick links to Services and Cost Sheet.
   - Condensed verbose service descriptions with Read full requirements / Show less.
   - At narrower widths, supplier costing summary appears before long service cards.
   - Cost calculator, Add Service, Refresh Supplier Costs, pricing logic untouched.

2. admin-supplier-requests.php — Supplier Requests / RFQ
   - Quick links to Build RFQ, Suppliers, Responses.
   - Optional Compact overview toggle.
   - Reduced oversized containers, improved readable text field sizes and responsive grids.
   - Source selection, sending, supplier quote history and status logic untouched.

3. admin-trip-hotel-allocations.php — Destination-wise Hotel Allocation
   - Segment navigation chips, one allocation editor open at a time.
   - Hotel-source alternatives folded under an accessible Show matching hotel options summary, except where missing inventory warnings must remain visible.
   - Compact trip context, counts, cards and responsive form fields.
   - Build/Refresh, Mark Requested, Save Allocation remain original PHP actions.

4. admin-trip-transport-allocations.php — Supplier Vehicle / Transport Allocation
   - Transport segment navigation and one open editor at a time.
   - Compact context/status summary, fields and action buttons.
   - Missing supplier vehicle rate warning remains visible when its segment is open.
   - Supplier Contract Vehicle Rules remain the sole source for selectable vehicle rules.

DESIGN / ACCESSIBILITY
- Layouts adapt at widths 1600, 1320, 1080 and 720 CSS px, with additional adjustments for <780px height.
- 13px standard editable field text; readable buttons, wrap-safe long package names.
- Keyboard-operable buttons, aria-expanded and aria-current where applicable.
- Progressive enhancement: if Javascript is disabled, all original forms/cards remain visible.
- Print rules do not hide collapsed allocation details.
- No new server endpoints or schema migrations.

CHANGED FILES
- admin-crm.php
- admin-supplier-requests.php
- admin-trip-hotel-allocations.php
- admin-trip-transport-allocations.php
- assets/crm-laptop-workspaces-v2498.css [NEW]
- assets/crm-laptop-workspaces-v2498.js  [NEW]
- README_V24_98_LAPTOP_FIRST_CRM_WORKSPACES.txt [NEW]

DEPLOYMENT
- Back up production before overwriting any file.
- Upload PATCH contents relative to site root, preserving assets/ subfolder.
- Refresh browser with Ctrl+Shift+R to clear stale files.
- Test on 1366x768 and 1280x800: navigate each section; open each segment; edit and Save; refresh and verify persisted values; test supplier RFQ send only to a test supplier.
- Confirm required PHP-DB services in staging before deploying production; browser interaction/integration with the live database was not run in the build environment.
- The laptop CSS/JS are additive and can be rolled back by reverting 4 page includes and removing 2 assets.
