<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE STEP 11A - SUPPLIER DOCUMENT / CONTRACT INTELLIGENCE
|--------------------------------------------------------------------------
| This layer is intentionally separate from Package import. Supplier PDFs are
| treated as source contracts/rate sheets first, then later mapped into hotel,
| vehicle and package pricing rows without changing the existing rate engine.
*/


function tsSupplierDocumentTextLen(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
}

function tsSupplierDocumentTextSubstr(string $value, int $start, ?int $length = null): string
{
    if (function_exists('mb_substr')) {
        return $length === null ? mb_substr($value, $start, null, 'UTF-8') : mb_substr($value, $start, $length, 'UTF-8');
    }
    return $length === null ? substr($value, $start) : substr($value, $start, $length);
}

function tsSupplierDocumentTextLower(string $value): string
{
    return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
}

function tsSupplierDocTableExists(PDO $pdo, string $table): bool
{
    /*
     * Do not rely only on `SHOW TABLES LIKE ?` here. Some shared-hosting
     * MariaDB/PDO combinations do not allow a placeholder in SHOW statements,
     * which made TRAVSCOPE report a table as missing even while the same page
     * could successfully SELECT rows from it. Use three safe checks instead.
     */
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        return false;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = DATABASE()
              AND table_name = ?
        ");
        $stmt->execute([$table]);
        if ((int)$stmt->fetchColumn() > 0) {
            return true;
        }
    } catch (Throwable $ignored) {
        // Continue to direct-query fallback below.
    }

    try {
        // A zero-row SELECT is the most reliable proof that the table exists.
        $pdo->query('SELECT 1 FROM `' . $table . '` LIMIT 0');
        return true;
    } catch (Throwable $ignored) {
        // Continue to SHOW fallback below.
    }

    try {
        $quoted = $pdo->quote($table);
        if ($quoted !== false) {
            $stmt = $pdo->query('SHOW TABLES LIKE ' . $quoted);
            return $stmt ? (bool)$stmt->fetchColumn() : false;
        }
    } catch (Throwable $ignored) {
    }

    return false;
}


function tsSupplierDocColumnExists(PDO $pdo, string $table, string $column): bool
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) return false;
    try {
        $stmt = $pdo->query('SHOW COLUMNS FROM `' . $table . '` LIKE ' . $pdo->quote($column));
        if ($stmt && $stmt->fetch(PDO::FETCH_ASSOC)) return true;
    } catch (Throwable $ignored) {}
    try { $pdo->query('SELECT `' . $column . '` FROM `' . $table . '` LIMIT 0'); return true; } catch (Throwable $ignored) {}
    return false;
}

function tsSupplierSeasonKey(string $name): string
{
    $name = strtolower(trim($name));
    $name = preg_replace('/[^a-z0-9]+/', '-', $name) ?? '';
    $name = trim($name, '-');
    return $name !== '' ? substr($name, 0, 80) : 'regular';
}

function tsSupplierSeasonInput(array $input): array
{
    $name = trim((string)($input['season_name'] ?? 'Regular Season'));
    if ($name === '') $name = 'Regular Season';
    $type = strtolower(trim((string)($input['season_type'] ?? 'regular')));
    $allowedTypes = ['regular','shoulder','high','peak','festival','special'];
    if (!in_array($type, $allowedTypes, true)) $type = 'regular';
    $defaults = ['regular'=>10,'shoulder'=>20,'high'=>50,'peak'=>100,'festival'=>110,'special'=>120];
    $priority = array_key_exists('rate_priority', $input) && trim((string)$input['rate_priority']) !== ''
        ? (int)$input['rate_priority'] : $defaults[$type];
    $priority = max(0, min(1000, $priority));
    $basis = strtolower(trim((string)($input['applicability_basis'] ?? 'arrival_date')));
    if (!in_array($basis, ['arrival_date','departure_date','majority_nights','manual_confirmation'], true)) $basis = 'arrival_date';
    return [
        'season_name'=>$name,
        'season_key'=>tsSupplierSeasonKey($name),
        'season_type'=>$type,
        'rate_priority'=>$priority,
        'applicability_basis'=>$basis,
    ];
}


/**
 * STEP 11A self-healing schema installer.
 *
 * Older TRAVSCOPE builds could contain supplier_contracts / supplier_rate_cards
 * without the Step 11A document-versioning tables.  The Supplier Document
 * Center is an additive module, so it is safe to create these two bridge tables
 * on demand.  No hard foreign keys are used here because several shared-hosting
 * MariaDB installations reject cross-table FK definitions even when the parent
 * schema is otherwise valid.
 */
function tsSupplierDocumentEnsureSchema(PDO $pdo): array
{
    $result = ['supplier_documents'=>false,'supplier_contract_versions'=>false,'changed'=>false,'supplier_core_changed'=>false];

    // V5: Step 11A can now bootstrap the Supplier Contract / Predefined Rate
    // core tables first. This prevents a false dead-end where Supplier Master
    // exists but the additive contract tables were never imported.
    if (function_exists('tsSupplierEnsureRateEngineSchema')) {
        try {
            $core = tsSupplierEnsureRateEngineSchema($pdo);
            if (!empty($core['changed'])) {
                $result['changed'] = true;
                $result['supplier_core_changed'] = true;
            }
        } catch (Throwable $e) {
            throw new RuntimeException('Supplier core schema auto-setup failed: ' . $e->getMessage(), 0, $e);
        }
    }

    if (!tsSupplierDocTableExists($pdo, 'supplier_contracts')) {
        throw new RuntimeException('Supplier Contracts table could not be created. Import travscope-core-schema-auto-repair.sql once, then reload this page.');
    }

    if (!tsSupplierDocTableExists($pdo, 'supplier_documents')) {
        $pdo->exec("\n            CREATE TABLE IF NOT EXISTS supplier_documents (\n              id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,\n              supplier_id BIGINT UNSIGNED NOT NULL,\n              destination_id BIGINT UNSIGNED DEFAULT NULL,\n              document_code VARCHAR(60) NOT NULL,\n              document_type VARCHAR(50) NOT NULL DEFAULT 'rate_sheet',\n              title VARCHAR(190) NOT NULL,\n              original_filename VARCHAR(255) NOT NULL,\n              stored_path VARCHAR(500) NOT NULL,\n              file_sha256 CHAR(64) NOT NULL,\n              mime_type VARCHAR(120) NOT NULL DEFAULT 'application/pdf',\n              file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,\n              source_channel VARCHAR(40) NOT NULL DEFAULT 'manual_upload',\n              source_email VARCHAR(190) DEFAULT NULL,\n              received_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,\n              valid_from DATE DEFAULT NULL,\n              valid_to DATE DEFAULT NULL,\n              currency VARCHAR(10) NOT NULL DEFAULT 'INR',\n              extraction_status VARCHAR(20) NOT NULL DEFAULT 'pending',\n              extraction_method VARCHAR(40) DEFAULT NULL,\n              extraction_confidence DECIMAL(5,2) DEFAULT NULL,\n              source_coverage DECIMAL(5,2) DEFAULT NULL,\n              detected_supplier_name VARCHAR(255) DEFAULT NULL,\n              detected_destination_text VARCHAR(255) DEFAULT NULL,\n              detected_itinerary_count INT UNSIGNED NOT NULL DEFAULT 0,\n              detected_hotel_category_count INT UNSIGNED NOT NULL DEFAULT 0,\n              detected_rate_group_count INT UNSIGNED NOT NULL DEFAULT 0,\n              detected_meal_plan VARCHAR(60) DEFAULT NULL,\n              detected_tax_notes TEXT DEFAULT NULL,\n              detected_cancellation_terms MEDIUMTEXT DEFAULT NULL,\n              detected_transport_terms MEDIUMTEXT DEFAULT NULL,\n              analysis_json LONGTEXT DEFAULT NULL,\n              status VARCHAR(20) NOT NULL DEFAULT 'review',\n              notes TEXT DEFAULT NULL,\n              uploaded_by_admin_id BIGINT UNSIGNED DEFAULT NULL,\n              created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n              updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n              PRIMARY KEY (id),\n              UNIQUE KEY uq_supplier_document_code (document_code),\n              UNIQUE KEY uq_supplier_document_hash (supplier_id,file_sha256),\n              KEY idx_supplier_document_supplier (supplier_id,status,received_at),\n              KEY idx_supplier_document_validity (valid_from,valid_to),\n              KEY idx_supplier_document_type (document_type,status),\n              KEY idx_supplier_document_destination (destination_id)\n            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci\n        ");
        $result['changed'] = true;
    }

    if (!tsSupplierDocTableExists($pdo, 'supplier_contract_versions')) {
        $pdo->exec("\n            CREATE TABLE IF NOT EXISTS supplier_contract_versions (\n              id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,\n              contract_id BIGINT UNSIGNED NOT NULL,\n              supplier_document_id BIGINT UNSIGNED NOT NULL,\n              version_no INT UNSIGNED NOT NULL,\n              version_label VARCHAR(40) DEFAULT NULL,\n              season_name VARCHAR(100) NOT NULL DEFAULT 'Regular Season',\n              season_key VARCHAR(80) NOT NULL DEFAULT 'regular',\n              season_type VARCHAR(30) NOT NULL DEFAULT 'regular',\n              rate_priority INT UNSIGNED NOT NULL DEFAULT 10,\n              applicability_basis VARCHAR(30) NOT NULL DEFAULT 'arrival_date',\n              valid_from DATE DEFAULT NULL,\n              valid_to DATE DEFAULT NULL,\n              currency VARCHAR(10) NOT NULL DEFAULT 'INR',\n              supplier_tax_percent DECIMAL(7,4) NOT NULL DEFAULT 0.0000,\n              tax_included TINYINT(1) NOT NULL DEFAULT 0,\n              payment_terms TEXT DEFAULT NULL,\n              cancellation_terms MEDIUMTEXT DEFAULT NULL,\n              transport_terms MEDIUMTEXT DEFAULT NULL,\n              meal_plan VARCHAR(60) DEFAULT NULL,\n              source_snapshot_json LONGTEXT DEFAULT NULL,\n              status VARCHAR(20) NOT NULL DEFAULT 'review',\n              created_by_admin_id BIGINT UNSIGNED DEFAULT NULL,\n              activated_by_admin_id BIGINT UNSIGNED DEFAULT NULL,\n              activated_at DATETIME DEFAULT NULL,\n              created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n              updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n              PRIMARY KEY (id),\n              UNIQUE KEY uq_supplier_contract_version (contract_id,version_no),\n              UNIQUE KEY uq_supplier_contract_document (contract_id,supplier_document_id),\n              KEY idx_supplier_contract_version_status (contract_id,status,valid_from,valid_to),\n              KEY idx_supplier_contract_version_document (supplier_document_id)\n            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci\n        ");
        $result['changed'] = true;
    }

    /* Step 11E uses supplier_email as a source channel.  Older 11A builds used
       an ENUM that did not include it; VARCHAR keeps future channels additive. */
    try {
        $pdo->exec("ALTER TABLE supplier_documents MODIFY source_channel VARCHAR(40) NOT NULL DEFAULT 'manual_upload'");
    } catch (Throwable $ignored) {}

    /* V15 seasonal supplier tariffs. Multiple seasonal versions may stay ACTIVE
       together; rate_priority resolves intentional peak/high-season overlaps. */
    if (tsSupplierDocTableExists($pdo, 'supplier_contract_versions')) {
        $seasonColumns = [
            'season_name' => "VARCHAR(100) NOT NULL DEFAULT 'Regular Season' AFTER version_label",
            'season_key' => "VARCHAR(80) NOT NULL DEFAULT 'regular' AFTER season_name",
            'season_type' => "VARCHAR(30) NOT NULL DEFAULT 'regular' AFTER season_key",
            'rate_priority' => "INT UNSIGNED NOT NULL DEFAULT 10 AFTER season_type",
            'applicability_basis' => "VARCHAR(30) NOT NULL DEFAULT 'arrival_date' AFTER rate_priority",
        ];
        foreach ($seasonColumns as $column => $definition) {
            if (!tsSupplierDocColumnExists($pdo, 'supplier_contract_versions', $column)) {
                try {
                    $pdo->exec('ALTER TABLE supplier_contract_versions ADD COLUMN `' . $column . '` ' . $definition);
                    $result['changed'] = true;
                } catch (Throwable $e) {
                    throw new RuntimeException('Seasonal rate schema upgrade failed for ' . $column . ': ' . $e->getMessage(), 0, $e);
                }
            }
        }
        try {
            $pdo->exec("UPDATE supplier_contract_versions SET season_name='Regular Season' WHERE season_name IS NULL OR TRIM(season_name)=''");
            $pdo->exec("UPDATE supplier_contract_versions SET season_key='regular' WHERE season_key IS NULL OR TRIM(season_key)=''");
            $pdo->exec("UPDATE supplier_contract_versions SET season_type='regular' WHERE season_type IS NULL OR TRIM(season_type)=''");
            $pdo->exec("UPDATE supplier_contract_versions SET applicability_basis='arrival_date' WHERE applicability_basis IS NULL OR TRIM(applicability_basis)=''");
        } catch (Throwable $ignored) {}
    }

    $result['supplier_documents'] = tsSupplierDocTableExists($pdo, 'supplier_documents');
    $result['supplier_contract_versions'] = tsSupplierDocTableExists($pdo, 'supplier_contract_versions');
    return $result;
}

function tsSupplierDocumentCenterReady(PDO $pdo): bool
{
    return tsSupplierDocTableExists($pdo, 'supplier_documents')
        && tsSupplierDocTableExists($pdo, 'supplier_contract_versions')
        && tsSupplierDocTableExists($pdo, 'supplier_contracts');
}

function tsSupplierDocumentPrivateRoot(): string
{
    $root = defined('TRAVSCOPE_PRIVATE_STORAGE_DIR')
        ? trim((string)TRAVSCOPE_PRIVATE_STORAGE_DIR)
        : dirname(__DIR__) . '/travscope-private';

    if ($root === '') {
        throw new RuntimeException('TRAVSCOPE private storage path is not configured.');
    }

    return rtrim($root, '/\\');
}

function tsSupplierDocumentStorageDir(): string
{
    $root = tsSupplierDocumentPrivateRoot();
    $dir = $root . '/supplier-documents';

    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
        throw new RuntimeException(
            'Unable to create private Supplier Document storage. Define TRAVSCOPE_PRIVATE_STORAGE_DIR in config.php to a writable folder outside public_html.'
        );
    }

    return $dir;
}

function tsSupplierDocumentStoredPath(string $relative): string
{
    $relative = ltrim(str_replace('\\', '/', trim($relative)), '/');

    if ($relative === '' || str_contains($relative, '..')) {
        throw new RuntimeException('Invalid Supplier Document storage path.');
    }

    $root = tsSupplierDocumentPrivateRoot();
    $full = $root . '/' . $relative;

    $rootReal = realpath($root);
    $fileReal = realpath($full);

    if (!$rootReal || !$fileReal || !is_file($fileReal)) {
        throw new RuntimeException('Supplier Document file is not available.');
    }

    $rootPrefix = rtrim($rootReal, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
    if (!str_starts_with($fileReal, $rootPrefix)) {
        throw new RuntimeException('Supplier Document path is outside private storage.');
    }

    return $fileReal;
}

function tsSupplierDocumentCode(PDO $pdo): string
{
    $prefix = 'SDOC-' . date('Ymd') . '-';

    for ($i = 0; $i < 30; $i++) {
        $code = $prefix . strtoupper(bin2hex(random_bytes(3)));
        $stmt = $pdo->prepare("SELECT id FROM supplier_documents WHERE document_code=? LIMIT 1");
        $stmt->execute([$code]);
        if (!$stmt->fetchColumn()) {
            return $code;
        }
    }

    return $prefix . strtoupper(bin2hex(random_bytes(5)));
}

function tsSupplierDocumentCommandExists(string $command): bool
{
    $command = preg_replace('/[^A-Za-z0-9_.-]/', '', $command);
    if ($command === '') return false;

    $out = [];
    $code = 1;
    @exec('command -v ' . escapeshellarg($command) . ' 2>/dev/null', $out, $code);
    return $code === 0 && !empty($out);
}

function tsSupplierDocumentRunCommand(string $command): string
{
    $output = [];
    $exitCode = 0;
    @exec($command . ' 2>/dev/null', $output, $exitCode);

    return $exitCode === 0 ? trim(implode("\n", $output)) : '';
}

function tsSupplierDocumentCleanText(string $text): string
{
    $text = str_replace(["\r\n", "\r", "\xC2\xA0"], ["\n", "\n", ' '], $text);
    $text = preg_replace('/[ \t]+/u', ' ', $text) ?? $text;
    $text = preg_replace('/\n[ \t]+/u', "\n", $text) ?? $text;
    $text = preg_replace('/\n{4,}/u', "\n\n\n", $text) ?? $text;
    return trim($text);
}

function tsSupplierDocumentExtractNativePdfText(string $file): string
{
    if (!is_file($file) || !tsSupplierDocumentCommandExists('pdftotext')) {
        return '';
    }

    $tmp = tempnam(sys_get_temp_dir(), 'ts_sdoc_');
    if ($tmp === false) return '';
    @unlink($tmp);
    $tmp .= '.txt';

    try {
        tsSupplierDocumentRunCommand(
            'pdftotext -layout -enc UTF-8 '
            . escapeshellarg($file) . ' ' . escapeshellarg($tmp)
        );

        if (!is_file($tmp)) return '';
        return tsSupplierDocumentCleanText((string)@file_get_contents($tmp));
    } finally {
        @unlink($tmp);
    }
}

function tsSupplierDocumentExtractOcrPdfText(string $file): string
{
    if (
        !is_file($file)
        || !tsSupplierDocumentCommandExists('pdftoppm')
        || !tsSupplierDocumentCommandExists('tesseract')
    ) {
        return '';
    }

    $workDir = sys_get_temp_dir() . '/ts_sdoc_ocr_' . bin2hex(random_bytes(5));
    if (!@mkdir($workDir, 0700, true)) return '';

    $prefix = $workDir . '/page';

    try {
        tsSupplierDocumentRunCommand(
            'pdftoppm -f 1 -l 40 -jpeg -r 180 '
            . escapeshellarg($file) . ' ' . escapeshellarg($prefix)
        );

        $pages = glob($prefix . '-*.jpg') ?: [];
        natsort($pages);
        $chunks = [];

        foreach (array_values($pages) as $index => $page) {
            $base = $workDir . '/ocr-' . ($index + 1);
            tsSupplierDocumentRunCommand(
                'tesseract ' . escapeshellarg($page) . ' ' . escapeshellarg($base)
                . ' -l eng --oem 1 --psm 3'
            );
            $txt = $base . '.txt';
            if (is_file($txt)) {
                $value = tsSupplierDocumentCleanText((string)@file_get_contents($txt));
                if ($value !== '') {
                    $chunks[] = '--- PAGE ' . ($index + 1) . " ---\n" . $value;
                }
            }
        }

        return tsSupplierDocumentCleanText(implode("\n\n", $chunks));
    } finally {
        foreach (glob($workDir . '/*') ?: [] as $f) @unlink($f);
        @rmdir($workDir);
    }
}

function tsSupplierDocumentExtractPdfText(string $file): array
{
    $native = tsSupplierDocumentExtractNativePdfText($file);
    $nativeChars = tsSupplierDocumentTextLen(trim($native));

    if ($nativeChars >= 300) {
        return [
            'text' => $native,
            'method' => 'native',
            'native_chars' => $nativeChars,
            'ocr_chars' => 0,
        ];
    }

    $ocr = tsSupplierDocumentExtractOcrPdfText($file);
    $ocrChars = tsSupplierDocumentTextLen(trim($ocr));

    if ($ocrChars > $nativeChars && $ocrChars >= 80) {
        return [
            'text' => $ocr,
            'method' => 'ocr',
            'native_chars' => $nativeChars,
            'ocr_chars' => $ocrChars,
        ];
    }

    if ($nativeChars >= 80) {
        return [
            'text' => $native,
            'method' => 'native-fallback',
            'native_chars' => $nativeChars,
            'ocr_chars' => $ocrChars,
        ];
    }

    return [
        'text' => '',
        'method' => 'unavailable',
        'native_chars' => $nativeChars,
        'ocr_chars' => $ocrChars,
    ];
}

function tsSupplierDocumentExtractDocxText(string $file): array
{
    if (!is_file($file)) return ['text'=>'','method'=>'docx-unavailable','native_chars'=>0,'ocr_chars'=>0];

    $xml = '';
    $method = 'docx-native';
    if (class_exists('ZipArchive')) {
        $zip = new ZipArchive();
        if ($zip->open($file) === true) {
            try {
                $raw = $zip->getFromName('word/document.xml');
                if (is_string($raw)) $xml = $raw;
            } finally {
                $zip->close();
            }
        }
    }
    // Shared-hosting fallback: many PHP builds disable ZipArchive/DOM even when
    // the OS unzip utility is available. No shell input is user-controlled here;
    // the path is escaped and the internal OOXML member name is fixed.
    if ($xml === '' && function_exists('tsSupplierDocumentCommandExists') && tsSupplierDocumentCommandExists('unzip')) {
        $xml = tsSupplierDocumentRunCommand('unzip -p ' . escapeshellarg($file) . ' word/document.xml');
        $method = 'docx-unzip';
    }
    if ($xml === '') return ['text'=>'','method'=>'docx-unavailable','native_chars'=>0,'ocr_chars'=>0];

    $text = '';
    if (class_exists('DOMDocument')) {
        $dom = new DOMDocument();
        $old = libxml_use_internal_errors(true);
        $ok = $dom->loadXML($xml, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
        libxml_clear_errors();
        libxml_use_internal_errors($old);
        if ($ok) {
            $xp = new DOMXPath($dom);
            $xp->registerNamespace('w','http://schemas.openxmlformats.org/wordprocessingml/2006/main');
            $body = $xp->query('//w:body')->item(0);
            if ($body) {
                $lines=[];
                foreach ($body->childNodes as $node) {
                    if (!($node instanceof DOMElement)) continue;
                    $local = $node->localName;
                    if ($local === 'p') {
                        $texts=[];
                        foreach ($xp->query('.//w:t',$node) as $t) $texts[]=(string)$t->textContent;
                        $line=trim(implode('',$texts));
                        if($line!=='')$lines[]=$line;
                    } elseif ($local === 'tbl') {
                        foreach ($xp->query('./w:tr',$node) as $tr) {
                            $cells=[];
                            foreach ($xp->query('./w:tc',$tr) as $tc) {
                                $texts=[];
                                foreach ($xp->query('.//w:t',$tc) as $t) $texts[]=(string)$t->textContent;
                                $cells[]=trim(implode('',$texts));
                            }
                            if($cells)$lines[]=implode("\t",$cells);
                        }
                        $lines[]='';
                    }
                }
                $text=implode("\n",$lines);
            }
        }
    }

    // Extension-free OOXML fallback. Process each table as a unit so paragraph
    // tags inside cells do not destroy tab-separated column boundaries.
    if (trim($text) === '') {
        $x = preg_replace_callback('/<w:tbl\b[^>]*>.*?<\/w:tbl>/isu', static function(array $m): string {
            $t=(string)$m[0];
            $t=preg_replace('/<w:tab\b[^>]*\/>/iu', "\t", $t) ?? $t;
            $t=preg_replace('/<w:br\b[^>]*\/>/iu', ' ', $t) ?? $t;
            $t=preg_replace('/<\/w:p\s*>/iu', ' ', $t) ?? $t;
            $t=preg_replace('/<\/w:tc\s*>/iu', "\t", $t) ?? $t;
            $t=preg_replace('/<\/w:tr\s*>/iu', "\n", $t) ?? $t;
            $t=preg_replace('/<[^>]+>/u', '', $t) ?? $t;
            $t=html_entity_decode($t, ENT_QUOTES | ENT_XML1, 'UTF-8');
            return "\n".$t."\n";
        }, $xml) ?? $xml;
        // Remaining non-table paragraphs become separate logical lines.
        $x = preg_replace('/<w:tab\b[^>]*\/>/iu', "\t", $x) ?? $x;
        $x = preg_replace('/<w:br\b[^>]*\/>/iu', "\n", $x) ?? $x;
        $x = preg_replace('/<\/w:p\s*>/iu', "\n", $x) ?? $x;
        $x = preg_replace('/<[^>]+>/u', '', $x) ?? $x;
        $x = html_entity_decode($x, ENT_QUOTES | ENT_XML1, 'UTF-8');
        $rows=[];
        foreach (preg_split('/\R/u',$x) ?: [] as $line) {
            $line=preg_replace('/[ ]+/u',' ',(string)$line) ?? (string)$line;
            $line=preg_replace('/ *\t */u',"\t",$line) ?? $line;
            $line=trim($line," \t\n\r\0\x0B");
            $line=preg_replace('/\t+$/u','',$line) ?? $line;
            if($line!=='')$rows[]=$line;
        }
        $text=implode("\n",$rows);
        $method .= '-fallback';
    }

    // DOCX tables need tab boundaries for reliable column-to-rate mapping, so
    // normalize spaces/newlines without collapsing tabs as the generic cleaner does.
    $text = str_replace(["\r\n", "\r", "\xC2\xA0"], ["\n", "\n", ' '], $text);
    $docxLines=[];
    foreach (preg_split('/\n/u',$text) ?: [] as $line) {
        $line=preg_replace('/[ ]+/u',' ',(string)$line) ?? (string)$line;
        $line=preg_replace('/ *\t */u',"\t",$line) ?? $line;
        $line=trim($line," \n\r");
        if($line!=='')$docxLines[]=$line;
    }
    $text=trim(implode("\n",$docxLines));
    return ['text'=>$text,'method'=>$method,'native_chars'=>tsSupplierDocumentTextLen($text),'ocr_chars'=>0];
}

function tsSupplierDocumentExtractFileText(string $file): array
{
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    if ($ext === 'docx') return tsSupplierDocumentExtractDocxText($file);
    return tsSupplierDocumentExtractPdfText($file);
}

function tsSupplierDocumentDate(string $value, ?int $defaultYear = null): ?string
{
    $value = trim($value);
    if ($value === '') return null;

    $value = preg_replace('/(\d)(st|nd|rd|th)\b/i', '$1', $value) ?? $value;
    $value = preg_replace('/\s+/', ' ', $value) ?? $value;

    if ($defaultYear && !preg_match('/\b(19|20)\d{2}\b/', $value)) {
        $value .= ' ' . $defaultYear;
    }

    $ts = strtotime($value);
    return $ts ? date('Y-m-d', $ts) : null;
}

function tsSupplierDocumentDetectValidity(string $text): array
{
    $patterns = [
        '/\bvalid(?:ity)?\s*(?:from)?\s*[:\-]?\s*([0-9]{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]{3,9}(?:\s+\d{4})?)\s*(?:to|till|until|\-|–|—)\s*([0-9]{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]{3,9}(?:\s+\d{4})?)/iu',
        '/\bfrom\s+([0-9]{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]{3,9}(?:\s+\d{4})?)\s+(?:to|till|until)\s+([0-9]{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]{3,9}(?:\s+\d{4})?)/iu',
        '/\bvalid(?:ity)?\s*[:\-]?\s*([0-9]{1,2}[\/\-.][0-9]{1,2}[\/\-.]\d{2,4})\s*(?:to|till|until|\-|–|—)\s*([0-9]{1,2}[\/\-.][0-9]{1,2}[\/\-.]\d{2,4})/iu',
    ];

    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $text, $m)) {
            $end = tsSupplierDocumentDate((string)$m[2]);
            $year = $end ? (int)substr($end, 0, 4) : null;
            $start = tsSupplierDocumentDate((string)$m[1], $year);
            if ($start && $end) {
                if ($start > $end) [$start, $end] = [$end, $start];
                return [$start, $end];
            }
        }
    }

    // A supplier may publish only an expiry statement (e.g. "Rates are valid
    // till 31st Mar. 2024"). Keep the end date instead of silently discarding it;
    // admin must still enter/confirm the season start date before activation.
    if (preg_match('/\brates?\s+(?:are\s+)?valid\s+(?:till|until|up\s+to)\s*[:\-]?\s*([0-9]{1,2}(?:st|nd|rd|th)?[ .\/-]+[A-Za-z]{3,9}[ .\/-]+(?:19|20)\d{2})/iu', $text, $m)) {
        $end=tsSupplierDocumentDate(str_replace(['.','/','-'],' ',(string)$m[1]));
        if($end)return [null,$end];
    }

    return [null, null];
}

function tsSupplierDocumentExtractSection(string $text, string $startPattern, array $endPatterns, int $maxChars = 4000): string
{
    if (!preg_match($startPattern, $text, $start, PREG_OFFSET_CAPTURE)) {
        return '';
    }

    $offset = (int)$start[0][1];
    $slice = substr($text, $offset);
    $end = strlen($slice);

    foreach ($endPatterns as $pattern) {
        if (preg_match($pattern, $slice, $m, PREG_OFFSET_CAPTURE, 1)) {
            $candidate = (int)$m[0][1];
            if ($candidate > 0 && $candidate < $end) $end = $candidate;
        }
    }

    return trim(tsSupplierDocumentTextSubstr(substr($slice, 0, $end), 0, $maxChars));
}

function tsSupplierDocumentAnalyzeText(string $text, ?array $supplier = null): array
{
    $clean = tsSupplierDocumentCleanText($text);
    $lower = tsSupplierDocumentTextLower($clean);

    $documentType = 'other';
    if (preg_match('/\b(invoice|tax invoice)\b/iu', $clean)) {
        $documentType = 'invoice';
    } elseif (preg_match('/\b(booking confirmation|hotel confirmation|confirmation voucher)\b/iu', $clean)) {
        $documentType = 'booking_confirmation';
    } elseif (preg_match('/\bquotation\b|\bquote\b/iu', $clean) && !preg_match('/\bmultiple itinerar|hotel selection|rates valid\b/iu', $clean)) {
        $documentType = 'quotation';
    } elseif ((preg_match('/\b(itinerar(?:y|ies)|package included|nights?\s*(?:&|and)\s*\d+\s*days?|\d{1,2}N\s*[-\/]\s*\d{1,2}D|SVHC\s*[-–]?\s*\d+)\b/iu', $clean))
        && preg_match('/\b(rate|rates|(?:0?2|0?4|0?6)\s*PAX|pax\s*0?2|per person|tariff)\b/iu', $clean)) {
        $documentType = 'package_tariff';
    } elseif (preg_match('/\bhotel\b/iu', $clean) && preg_match('/\b(rate|tariff)\b/iu', $clean)) {
        $documentType = 'hotel_rate_sheet';
    } elseif (preg_match('/\b(vehicle|transport|transfer)\b/iu', $clean) && preg_match('/\b(rate|tariff)\b/iu', $clean)) {
        $documentType = 'transport_tariff';
    } elseif (preg_match('/\b(rate|rates|tariff|contract)\b/iu', $clean)) {
        $documentType = 'rate_sheet';
    }

    [$validFrom, $validTo] = tsSupplierDocumentDetectValidity($clean);

    $emails = [];
    if (preg_match_all('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/iu', $clean, $m)) {
        $emails = array_values(array_unique(array_map('strtolower', $m[0])));
    }

    $websites = [];
    if (preg_match_all('/(?:https?:\/\/|www\.)[^\s,;]+/iu', $clean, $m)) {
        $websites = array_values(array_unique($m[0]));
    }

    $supplierDetected = '';
    $lines = preg_split('/\n+/', $clean) ?: [];
    foreach (array_slice($lines, 0, 20) as $line) {
        $line = trim($line);
        if ($line === '' || tsSupplierDocumentTextLen($line) < 4 || tsSupplierDocumentTextLen($line) > 150) continue;
        if (preg_match('/^(cell|tel|phone|mobile|email|website|address|dear|gst)/iu', $line)) continue;
        if (preg_match('/\b(tours?|travels?|holidays?|hospitality|dmc|tourism|vacations?)\b/iu', $line)) {
            $supplierDetected = $line;
            break;
        }
    }

    $durations = [];
    foreach ([
        '/\b(\d{1,2})\s*Nights?\s*(?:&|and|\/)\s*(\d{1,2})\s*Days?\b/iu',
        '/\b(\d{1,2})\s*N\s*[-\/]\s*(\d{1,2})\s*D\b/iu',
    ] as $durationPattern) {
        if (preg_match_all($durationPattern, $clean, $m, PREG_SET_ORDER)) {
            foreach ($m as $row) {
                $key = (int)$row[1] . 'N/' . (int)$row[2] . 'D';
                $durations[$key] = ['nights'=>(int)$row[1],'days'=>(int)$row[2],'label'=>$key];
            }
        }
    }

    $categoryPatterns = [
        '5 Star Luxury' => '/\b(?:0?5|Five)\s*Star\s*(?:Luxury|Premium)\b/iu',
        '5 Star' => '/\b(?:0?5|Five)\s*Star(?:\s*(?:Hotel|Hotels|Deluxe))?\b/iu',
        '4 Star Luxury' => '/\b0?4\s*Star\s*Luxury\b/iu',
        '4 Star' => '/\b0?4\s*Star\b/iu',
        '3 Star' => '/\b0?3\s*Star\b/iu',
        '2 Star' => '/\b0?2\s*Star\b/iu',
        'Deluxe' => '/\bDeluxe\s*(?:\(CP\)|CP)?\b/iu',
        'Super Deluxe' => '/\bSuper\s*Deluxe\s*(?:\(CP\)|CP)?\b|\bSuperDeluxe\s*(?:\(CP\)|CP)?\b/iu',
        'Superior' => '/\bSuperior\s*(?:\(CP\)|CP)?\b/iu',
        'Premium' => '/\bPremium\s*(?:\(CP\)|CP)?\b/iu',
        'Standard' => '/\bStandard\s*(?:Hotels?|MAPAI|CPAI|MAP|CP)?\b/iu',
        'Budget' => '/\bBudget\s*(?:Hotels?|MAPAI|CPAI|MAP|CP)?\b/iu',
    ];
    $categories = [];
    foreach ($categoryPatterns as $label => $pattern) {
        if (preg_match($pattern, $clean)) $categories[] = $label;
    }

    $mealPlan = '';
    foreach (['MAPAI','CPAI','APAI','MAP','CP','AP','EP'] as $code) {
        if (preg_match('/\b' . preg_quote($code, '/') . '\b/iu', $clean)) {
            $mealPlan = $code;
            break;
        }
    }

    $cancellation = tsSupplierDocumentExtractSection(
        $clean,
        '/\bCancellation\s+(?:Policy|Terms?)\b\s*:?/iu',
        [
            '/\b\d{1,2}\s*Nights?\s*(?:&|and|\/)\s*\d{1,2}\s*Days?\b/iu',
            '/\bPackage\s+Included\b/iu',
            '/\bTerms\s+(?:and|&)\s+Conditions\b/iu',
        ],
        2800
    );

    $transport = tsSupplierDocumentExtractSection(
        $clean,
        '/\b(?:The\s+)?transport\b/iu',
        [
            '/\bCancellation\s+(?:Policy|Terms?)\b/iu',
            '/\b\d{1,2}\s*Nights?\s*(?:&|and|\/)\s*\d{1,2}\s*Days?\b/iu',
        ],
        2500
    );

    $taxNotes = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line !== '' && preg_match('/\b(GST|tax(?:es)?)\b/iu', $line)) {
            $taxNotes[] = $line;
            if (count($taxNotes) >= 8) break;
        }
    }

    $rateGroupCount = preg_match_all('/\b(?:Pax\s*0?2|0?2\s*PAX)\b/iu', $clean, $tmp) ?: 0;
    $hasHotelEvidence = (bool)preg_match('/\bHotel\b/iu', $clean);
    $hasTransportEvidence = (bool)preg_match('/\b(Innova|Crysta|Etios|Tavera|Tempo\s+Traveller|Swift\s+De[sz]ire|vehicle|transport)\b/iu', $clean);
    $hasRateEvidence = (bool)preg_match('/\b(?:Pax\s*0?2|0?2\s*PAX)\b|\bper person\b|\/\-pp\b|\bExtra Bed\b|Child\s+w\/?o\s+Bed/iu', $clean);

    $checks = [
        10 => !empty($supplier) || $supplierDetected !== '',
        10 => $documentType !== 'other',
        15 => $validFrom !== null && $validTo !== null,
        10 => tsSupplierDocumentTextLen($clean) >= 1000,
        15 => count($durations) > 0,
        10 => count($categories) > 0,
        5  => $mealPlan !== '',
        10 => $cancellation !== '',
        10 => $transport !== '' || $hasTransportEvidence,
        5  => $hasRateEvidence,
    ];

    // Array keys above intentionally collide in PHP, so calculate explicitly.
    $coverage = 0;
    $coverage += (!empty($supplier) || $supplierDetected !== '') ? 10 : 0;
    $coverage += $documentType !== 'other' ? 10 : 0;
    $coverage += ($validFrom && $validTo) ? 15 : 0;
    $coverage += tsSupplierDocumentTextLen($clean) >= 1000 ? 10 : 0;
    $coverage += count($durations) > 0 ? 15 : 0;
    $coverage += count($categories) > 0 ? 10 : 0;
    $coverage += $mealPlan !== '' ? 5 : 0;
    $coverage += $cancellation !== '' ? 10 : 0;
    $coverage += ($transport !== '' || $hasTransportEvidence) ? 10 : 0;
    $coverage += $hasRateEvidence ? 5 : 0;

    $warnings = [];
    if (!$validFrom || !$validTo) $warnings[] = 'Validity dates were not confidently detected.';
    if (!$durations) $warnings[] = 'No separate itinerary duration heading was detected.';
    if (!$categories) $warnings[] = 'No supplier hotel/package category was detected.';
    if (!$hasRateEvidence) $warnings[] = 'No clear PAX/per-person rate matrix was detected.';
    if ($cancellation === '') $warnings[] = 'Cancellation policy was not detected.';

    return [
        'document_type' => $documentType,
        'supplier_detected' => $supplierDetected,
        'supplier_selected' => $supplier['company_name'] ?? '',
        'emails' => $emails,
        'websites' => $websites,
        'valid_from' => $validFrom,
        'valid_to' => $validTo,
        'itineraries' => array_values($durations),
        'itinerary_count' => count($durations),
        'hotel_categories' => $categories,
        'hotel_category_count' => count($categories),
        'meal_plan' => $mealPlan,
        'cancellation_terms' => $cancellation,
        'transport_terms' => $transport,
        'tax_notes' => array_values(array_unique($taxNotes)),
        'rate_group_count' => $rateGroupCount,
        'has_hotel_evidence' => $hasHotelEvidence,
        'has_transport_evidence' => $hasTransportEvidence,
        'has_rate_evidence' => $hasRateEvidence,
        'source_coverage' => min(100, $coverage),
        'warnings' => $warnings,
        'text_chars' => tsSupplierDocumentTextLen($clean),
    ];
}

function tsSupplierDocumentUpload(
    PDO $pdo,
    array $file,
    int $supplierId,
    ?int $destinationId,
    int $adminId,
    array $options = []
): int {
    if (!tsSupplierDocumentCenterReady($pdo)) {
        throw new RuntimeException('Supplier Document Center SQL is not installed yet.');
    }
    if ($supplierId <= 0) throw new RuntimeException('Select the supplier first.');
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Supplier document upload failed.');
    }
    if ((int)($file['size'] ?? 0) <= 0 || (int)$file['size'] > 30 * 1024 * 1024) {
        throw new RuntimeException('Supplier document must be between 1 byte and 30 MB.');
    }

    $tmp = (string)($file['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) {
        throw new RuntimeException('Invalid supplier document upload.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = strtolower((string)$finfo->file($tmp));
    $ext = strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
    $allowedExt = ['pdf','docx'];
    $allowedMime = ['application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/zip','application/octet-stream'];
    if (!in_array($ext,$allowedExt,true) || !in_array($mime,$allowedMime,true)) {
        throw new RuntimeException('Step 11A accepts supplier PDF or DOCX rate-sheet documents.');
    }

    $supplierStmt = $pdo->prepare("SELECT * FROM suppliers WHERE id=? LIMIT 1");
    $supplierStmt->execute([$supplierId]);
    $supplier = $supplierStmt->fetch(PDO::FETCH_ASSOC);
    if (!$supplier) throw new RuntimeException('Supplier not found.');

    $hash = hash_file('sha256', $tmp);
    $dup = $pdo->prepare("SELECT id,document_code FROM supplier_documents WHERE supplier_id=? AND file_sha256=? LIMIT 1");
    $dup->execute([$supplierId, $hash]);
    if ($existing = $dup->fetch(PDO::FETCH_ASSOC)) {
        throw new RuntimeException('This exact supplier document is already saved as ' . (string)$existing['document_code'] . '.');
    }

    $code = tsSupplierDocumentCode($pdo);
    $year = date('Y');
    $month = date('m');
    $baseDir = tsSupplierDocumentStorageDir() . '/' . $year . '/' . $month;
    if (!is_dir($baseDir) && !@mkdir($baseDir, 0750, true) && !is_dir($baseDir)) {
        throw new RuntimeException('Unable to create supplier document storage folder.');
    }

    $storedName = $code . '-' . bin2hex(random_bytes(5)) . '.' . $ext;
    $fullPath = $baseDir . '/' . $storedName;
    if (!move_uploaded_file($tmp, $fullPath)) {
        throw new RuntimeException('Unable to save supplier document to private storage.');
    }
    @chmod($fullPath, 0640);

    $relative = 'supplier-documents/' . $year . '/' . $month . '/' . $storedName;
    $extracted = tsSupplierDocumentExtractFileText($fullPath);
    $analysis = tsSupplierDocumentAnalyzeText((string)$extracted['text'], $supplier);
    if(preg_match('/\b(20\d{2})\b/',(string)($file['name']??''),$ym) && !empty($analysis['valid_to'])){
        $filenameYear=(int)$ym[1];$sourceYear=(int)substr((string)$analysis['valid_to'],0,4);
        if($filenameYear!==$sourceYear){
            $analysis['warnings'][]='Filename year '.$filenameYear.' differs from a validity/expiry year '.$sourceYear.' detected inside the supplier document. Confirm the season dates before activation.';
        }
    }

    $requestedType = trim((string)($options['document_type'] ?? ''));
    $documentType = $requestedType !== '' && $requestedType !== 'auto'
        ? $requestedType
        : (string)$analysis['document_type'];

    $title = trim((string)($options['title'] ?? ''));
    if ($title === '') {
        $typeLabel = ucwords(str_replace('_', ' ', $documentType));
        $title = (string)$supplier['company_name'] . ' · ' . $typeLabel;
        if (!empty($analysis['valid_from']) && !empty($analysis['valid_to'])) {
            $title .= ' · ' . date('d M Y', strtotime((string)$analysis['valid_from']))
                . ' - ' . date('d M Y', strtotime((string)$analysis['valid_to']));
        }
    }

    $validFrom = trim((string)($options['valid_from'] ?? '')) ?: ($analysis['valid_from'] ?? null);
    $validTo = trim((string)($options['valid_to'] ?? '')) ?: ($analysis['valid_to'] ?? null);

    $receivedAt = trim((string)($options['received_at'] ?? ''));
    if ($receivedAt === '') {
        $receivedAt = date('Y-m-d H:i:s');
    } else {
        $receivedAt = str_replace('T', ' ', $receivedAt);
        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $receivedAt)) $receivedAt .= ':00';
    }

    $status = $analysis['text_chars'] >= 80 ? 'review' : 'failed';
    $extractionStatus = $analysis['text_chars'] >= 80 ? 'analyzed' : 'failed';

    try {
        $stmt = $pdo->prepare("\n            INSERT INTO supplier_documents\n            (supplier_id,destination_id,document_code,document_type,title,original_filename,stored_path,file_sha256,mime_type,file_size,source_channel,source_email,received_at,valid_from,valid_to,currency,extraction_status,extraction_method,extraction_confidence,source_coverage,detected_supplier_name,detected_destination_text,detected_itinerary_count,detected_hotel_category_count,detected_rate_group_count,detected_meal_plan,detected_tax_notes,detected_cancellation_terms,detected_transport_terms,analysis_json,status,notes,uploaded_by_admin_id)\n            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)\n        ");

        $stmt->execute([
            $supplierId,
            $destinationId ?: null,
            $code,
            $documentType,
            $title,
            basename((string)($file['name'] ?? ('supplier-document.' . $ext))),
            $relative,
            $hash,
            $mime ?: ($ext==='docx'?'application/vnd.openxmlformats-officedocument.wordprocessingml.document':'application/pdf'),
            (int)$file['size'],
            trim((string)($options['source_channel'] ?? 'manual_upload')) ?: 'manual_upload',
            trim((string)($options['source_email'] ?? '')) ?: null,
            $receivedAt,
            $validFrom ?: null,
            $validTo ?: null,
            strtoupper(trim((string)($options['currency'] ?? ($supplier['default_currency'] ?? 'INR')))) ?: 'INR',
            $extractionStatus,
            (string)$extracted['method'],
            (float)$analysis['source_coverage'],
            (float)$analysis['source_coverage'],
            trim((string)$analysis['supplier_detected']) ?: null,
            trim((string)($options['destination_text'] ?? '')) ?: null,
            (int)$analysis['itinerary_count'],
            (int)$analysis['hotel_category_count'],
            (int)$analysis['rate_group_count'],
            trim((string)$analysis['meal_plan']) ?: null,
            $analysis['tax_notes'] ? implode("\n", $analysis['tax_notes']) : null,
            trim((string)$analysis['cancellation_terms']) ?: null,
            trim((string)$analysis['transport_terms']) ?: null,
            json_encode($analysis, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            $status,
            trim((string)($options['notes'] ?? '')) ?: null,
            $adminId ?: null,
        ]);

        return (int)$pdo->lastInsertId();
    } catch (Throwable $e) {
        @unlink($fullPath);
        throw $e;
    }
}

function tsSupplierDocumentGet(PDO $pdo, int $documentId): ?array
{
    $stmt = $pdo->prepare("\n        SELECT sd.*, s.company_name,s.supplier_code,s.default_currency,\n               d.name AS destination_name,d.country AS destination_country\n        FROM supplier_documents sd\n        JOIN suppliers s ON s.id=sd.supplier_id\n        LEFT JOIN destinations d ON d.id=sd.destination_id\n        WHERE sd.id=?\n        LIMIT 1\n    ");
    $stmt->execute([$documentId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function tsSupplierDocumentCreateContractFromDocument(PDO $pdo, int $documentId, int $adminId, array $input): array
{
    $document = tsSupplierDocumentGet($pdo, $documentId);
    if (!$document) throw new RuntimeException('Supplier document not found.');

    $name = trim((string)($input['contract_name'] ?? ''));
    if ($name === '') $name = trim((string)$document['title']);

    $validFrom = trim((string)($input['valid_from'] ?? $document['valid_from'] ?? ''));
    $validTo = trim((string)($input['valid_to'] ?? $document['valid_to'] ?? ''));
    if ($validFrom === '' || $validTo === '') {
        throw new RuntimeException('Contract validity dates are required before creating the contract.');
    }
    if ($validTo < $validFrom) throw new RuntimeException('Contract end date cannot be before start date.');

    $currency = strtoupper(trim((string)($input['currency'] ?? $document['currency'] ?? 'INR'))) ?: 'INR';
    $taxIncluded = !empty($input['tax_included']) ? 1 : 0;
    $taxPercent = max(0, (float)($input['supplier_tax_percent'] ?? 0));
    $paymentTerms = trim((string)($input['payment_terms'] ?? '')) ?: null;
    $cancellation = trim((string)($input['cancellation_terms'] ?? $document['detected_cancellation_terms'] ?? '')) ?: null;
    $transport = trim((string)($input['transport_terms'] ?? $document['detected_transport_terms'] ?? '')) ?: null;
    $mealPlan = trim((string)($input['meal_plan'] ?? $document['detected_meal_plan'] ?? '')) ?: null;
    $notes = trim((string)($input['notes'] ?? $document['notes'] ?? '')) ?: null;
    $season = tsSupplierSeasonInput($input);

    if (!function_exists('tsSupplierContractCode')) {
        throw new RuntimeException('supplier-functions.php does not contain the Contract Rate Engine helpers.');
    }

    $pdo->beginTransaction();
    try {
        $contractCode = tsSupplierContractCode($pdo, (int)$document['supplier_id']);
        $stmt = $pdo->prepare("\n            INSERT INTO supplier_contracts\n            (supplier_id,contract_code,contract_name,currency,valid_from,valid_to,status,source_reference,supplier_tax_percent,tax_included,payment_terms,cancellation_terms,notes,created_by_admin_id,updated_by_admin_id)\n            VALUES (?,?,?,?,?,?,'draft',?,?,?,?,?,?,?,?)\n        ");
        $stmt->execute([
            (int)$document['supplier_id'],
            $contractCode,
            $name,
            $currency,
            $validFrom,
            $validTo,
            $document['document_code'],
            $taxPercent,
            $taxIncluded,
            $paymentTerms,
            $cancellation,
            $notes,
            $adminId ?: null,
            $adminId ?: null,
        ]);
        $contractId = (int)$pdo->lastInsertId();

        $version = $pdo->prepare("\n            INSERT INTO supplier_contract_versions\n            (contract_id,supplier_document_id,version_no,version_label,season_name,season_key,season_type,rate_priority,applicability_basis,valid_from,valid_to,currency,supplier_tax_percent,tax_included,payment_terms,cancellation_terms,transport_terms,meal_plan,source_snapshot_json,status,created_by_admin_id)\n            VALUES (?,?,1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'review',?)\n        ");
        $version->execute([
            $contractId,
            $documentId,
            'V1',
            $season['season_name'],
            $season['season_key'],
            $season['season_type'],
            $season['rate_priority'],
            $season['applicability_basis'],
            $validFrom,
            $validTo,
            $currency,
            $taxPercent,
            $taxIncluded,
            $paymentTerms,
            $cancellation,
            $transport,
            $mealPlan,
            $document['analysis_json'],
            $adminId ?: null,
        ]);
        $versionId = (int)$pdo->lastInsertId();

        $pdo->prepare("UPDATE supplier_documents SET status='linked',updated_at=NOW() WHERE id=?")
            ->execute([$documentId]);

        $pdo->commit();
        return ['contract_id' => $contractId, 'version_id' => $versionId, 'contract_code' => $contractCode];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function tsSupplierDocumentAddContractVersion(PDO $pdo, int $documentId, int $contractId, int $adminId, array $input): int
{
    $document = tsSupplierDocumentGet($pdo, $documentId);
    if (!$document) throw new RuntimeException('Supplier document not found.');

    $stmt = $pdo->prepare("SELECT * FROM supplier_contracts WHERE id=? AND supplier_id=? LIMIT 1");
    $stmt->execute([$contractId, (int)$document['supplier_id']]);
    $contract = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$contract) throw new RuntimeException('Select a contract that belongs to this supplier.');

    $exists = $pdo->prepare("SELECT id FROM supplier_contract_versions WHERE contract_id=? AND supplier_document_id=? LIMIT 1");
    $exists->execute([$contractId, $documentId]);
    if ($exists->fetchColumn()) throw new RuntimeException('This document is already linked to that contract.');

    $max = $pdo->prepare("SELECT COALESCE(MAX(version_no),0)+1 FROM supplier_contract_versions WHERE contract_id=?");
    $max->execute([$contractId]);
    $versionNo = max(1, (int)$max->fetchColumn());

    $validFrom = trim((string)($input['valid_from'] ?? $document['valid_from'] ?? $contract['valid_from']));
    $validTo = trim((string)($input['valid_to'] ?? $document['valid_to'] ?? $contract['valid_to']));
    if ($validFrom === '' || $validTo === '') throw new RuntimeException('Version validity dates are required.');
    if ($validTo < $validFrom) throw new RuntimeException('Version end date cannot be before start date.');

    $currency = strtoupper(trim((string)($input['currency'] ?? $document['currency'] ?? $contract['currency']))) ?: 'INR';
    $taxIncluded = !empty($input['tax_included']) ? 1 : 0;
    $taxPercent = max(0, (float)($input['supplier_tax_percent'] ?? $contract['supplier_tax_percent'] ?? 0));
    $paymentTerms = trim((string)($input['payment_terms'] ?? $contract['payment_terms'] ?? '')) ?: null;
    $cancellation = trim((string)($input['cancellation_terms'] ?? $document['detected_cancellation_terms'] ?? $contract['cancellation_terms'] ?? '')) ?: null;
    $transport = trim((string)($input['transport_terms'] ?? $document['detected_transport_terms'] ?? '')) ?: null;
    $mealPlan = trim((string)($input['meal_plan'] ?? $document['detected_meal_plan'] ?? '')) ?: null;

    $season = tsSupplierSeasonInput($input);

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("\n            INSERT INTO supplier_contract_versions\n            (contract_id,supplier_document_id,version_no,version_label,season_name,season_key,season_type,rate_priority,applicability_basis,valid_from,valid_to,currency,supplier_tax_percent,tax_included,payment_terms,cancellation_terms,transport_terms,meal_plan,source_snapshot_json,status,created_by_admin_id)\n            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'review',?)\n        ");
        $stmt->execute([
            $contractId,
            $documentId,
            $versionNo,
            'V' . $versionNo,
            $season['season_name'],
            $season['season_key'],
            $season['season_type'],
            $season['rate_priority'],
            $season['applicability_basis'],
            $validFrom,
            $validTo,
            $currency,
            $taxPercent,
            $taxIncluded,
            $paymentTerms,
            $cancellation,
            $transport,
            $mealPlan,
            $document['analysis_json'],
            $adminId ?: null,
        ]);
        $versionId = (int)$pdo->lastInsertId();
        $pdo->prepare("UPDATE supplier_documents SET status='linked',updated_at=NOW() WHERE id=?")
            ->execute([$documentId]);
        $pdo->commit();
        return $versionId;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function tsSupplierDocumentActivateContractVersion(PDO $pdo, int $versionId, int $adminId): void
{
    $stmt = $pdo->prepare("\n        SELECT v.*,c.supplier_id,c.contract_name,d.document_code\n        FROM supplier_contract_versions v\n        JOIN supplier_contracts c ON c.id=v.contract_id\n        JOIN supplier_documents d ON d.id=v.supplier_document_id\n        WHERE v.id=? LIMIT 1\n    ");
    $stmt->execute([$versionId]);
    $version = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$version) throw new RuntimeException('Contract version not found.');

    /*
    | Step 11A never silently reuses old price rows under a newly activated
    | source tariff. If this contract already has active predefined rates,
    | the new document version must stay in Review until Step 11B/11C maps
    | and verifies the replacement rates.
    */
    $rateCountStmt = $pdo->prepare("SELECT COUNT(*) FROM supplier_rate_cards WHERE contract_id=? AND status='active'");
    $rateCountStmt->execute([(int)$version['contract_id']]);
    $legacyActiveRates=(int)$rateCountStmt->fetchColumn();
    if ($legacyActiveRates > 0 && (string)$version['status'] !== 'active') {
        // A reviewed Step 11C matrix is a safe replacement source. This lets the
        // same supplier contract carry independent Regular/High/Peak seasons.
        $replacementReady=false;
        if(tsSupplierDocTableExists($pdo,'supplier_contract_rate_groups') && tsSupplierDocTableExists($pdo,'supplier_contract_pax_rates')){
            $st=$pdo->prepare("SELECT COUNT(*) FROM supplier_contract_rate_groups WHERE contract_version_id=? AND status='active'");$st->execute([$versionId]);$g=(int)$st->fetchColumn();
            $st=$pdo->prepare("SELECT COUNT(*) FROM supplier_contract_pax_rates WHERE contract_version_id=? AND status='active'");$st->execute([$versionId]);$r=(int)$st->fetchColumn();
            $replacementReady=$g>0 && $r>0;
        }
        if(!$replacementReady){
            throw new RuntimeException('This contract already has active predefined rate rows. Build and approve the replacement Step 11C PAX matrix for this season before activating the new source version.');
        }
    }

    /* STEP 11B safety: when the document contains hotel/transport inventory,
       require that inventory to be built and approved before activation. */
    if (
        tsSupplierDocTableExists($pdo, 'supplier_contract_hotel_inventory')
        && tsSupplierDocTableExists($pdo, 'supplier_contract_vehicle_rules')
    ) {
        $analysis = json_decode((string)($version['source_snapshot_json'] ?? ''), true);
        if (!is_array($analysis)) $analysis = [];
        $expectsInventory = !empty($analysis['has_hotel_evidence']) || !empty($analysis['has_transport_evidence']);
        if ($expectsInventory) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM supplier_contract_hotel_inventory WHERE contract_version_id=?");
            $stmt->execute([$versionId]);
            $hotelInventoryCount = (int)$stmt->fetchColumn();
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM supplier_contract_vehicle_rules WHERE contract_version_id=?");
            $stmt->execute([$versionId]);
            $vehicleInventoryCount = (int)$stmt->fetchColumn();
            if ($hotelInventoryCount + $vehicleInventoryCount === 0) {
                throw new RuntimeException('Build the Step 11B Hotel + Vehicle Inventory from this supplier source document before activating the contract version.');
            }
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM supplier_contract_hotel_inventory WHERE contract_version_id=? AND status='review'");
            $stmt->execute([$versionId]);
            $reviewHotels = (int)$stmt->fetchColumn();
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM supplier_contract_vehicle_rules WHERE contract_version_id=? AND status='review'");
            $stmt->execute([$versionId]);
            $reviewVehicles = (int)$stmt->fetchColumn();
            if ($reviewHotels + $reviewVehicles > 0) {
                throw new RuntimeException('Approve the Step 11B Hotel + Vehicle Inventory before activating this contract version.');
            }
        }
    }


    /* STEP 11C safety: tariff/rate-sheet documents must have their commercial
       itinerary/category/PAX matrix built and approved before activation. */
    if (
        tsSupplierDocTableExists($pdo, 'supplier_contract_itineraries')
        && tsSupplierDocTableExists($pdo, 'supplier_contract_rate_groups')
        && tsSupplierDocTableExists($pdo, 'supplier_contract_pax_rates')
    ) {
        $analysis = json_decode((string)($version['source_snapshot_json'] ?? ''), true);
        if (!is_array($analysis)) $analysis = [];
        $expectsRates = !empty($analysis['has_rate_evidence']) || (int)($analysis['rate_group_count'] ?? 0) > 0;
        if ($expectsRates) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM supplier_contract_rate_groups WHERE contract_version_id=?");
            $stmt->execute([$versionId]);
            $groupCount = (int)$stmt->fetchColumn();
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM supplier_contract_pax_rates WHERE contract_version_id=?");
            $stmt->execute([$versionId]);
            $paxCount = (int)$stmt->fetchColumn();
            if ($groupCount === 0 || $paxCount === 0) {
                throw new RuntimeException('Build the Step 11C Supplier PAX Rate Matrix from this tariff before activating the contract version.');
            }
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM supplier_contract_rate_groups WHERE contract_version_id=? AND status='review'");
            $stmt->execute([$versionId]);
            $reviewGroups = (int)$stmt->fetchColumn();
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM supplier_contract_pax_rates WHERE contract_version_id=? AND status='review'");
            $stmt->execute([$versionId]);
            $reviewPax = (int)$stmt->fetchColumn();
            if ($reviewGroups + $reviewPax > 0) {
                throw new RuntimeException('Approve the Step 11C Supplier PAX Rate Matrix before activating this contract version.');
            }
        }
    }

    /* V15: keep independent seasons active at the same time. A revised
       document supersedes only the same season key. Overlaps between different
       seasons are valid only when priority differs (e.g. Regular 10, Peak 100). */
    $seasonKey = trim((string)($version['season_key'] ?? 'regular')) ?: 'regular';
    $priority = max(0, (int)($version['rate_priority'] ?? 10));
    $overlap = $pdo->prepare("SELECT id,season_name,season_key,rate_priority,valid_from,valid_to FROM supplier_contract_versions WHERE contract_id=? AND status='active' AND id<>? AND NOT (valid_to < ? OR valid_from > ?)");
    $overlap->execute([(int)$version['contract_id'],$versionId,$version['valid_from'],$version['valid_to']]);
    foreach ($overlap->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
        $rowKey = trim((string)($row['season_key'] ?? 'regular')) ?: 'regular';
        if ($rowKey !== $seasonKey && (int)($row['rate_priority'] ?? 10) === $priority) {
            throw new RuntimeException('Season overlap needs a clear priority. ' . (string)($row['season_name'] ?? 'Existing season') . ' overlaps this period with priority ' . $priority . '. Change one priority (Regular 10, High 50, Peak 100) and activate again.');
        }
    }

    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE supplier_contract_versions SET status='superseded',updated_at=NOW() WHERE contract_id=? AND status='active' AND id<>? AND season_key=?")
            ->execute([(int)$version['contract_id'], $versionId, $seasonKey]);

        $pdo->prepare("UPDATE supplier_contract_versions SET status='active',activated_by_admin_id=?,activated_at=NOW(),updated_at=NOW() WHERE id=?")
            ->execute([$adminId ?: null, $versionId]);

        $range = $pdo->prepare("SELECT MIN(valid_from) min_from,MAX(valid_to) max_to FROM supplier_contract_versions WHERE contract_id=? AND (status='active' OR id=?)");
        $range->execute([(int)$version['contract_id'],$versionId]);
        $activeRange = $range->fetch(PDO::FETCH_ASSOC) ?: [];
        $contractFrom = (string)($activeRange['min_from'] ?? $version['valid_from']);
        $contractTo = (string)($activeRange['max_to'] ?? $version['valid_to']);

        $pdo->prepare("\n            UPDATE supplier_contracts SET\n                currency=?,valid_from=?,valid_to=?,status='active',source_reference=?,supplier_tax_percent=?,tax_included=?,payment_terms=?,cancellation_terms=?,updated_by_admin_id=?,updated_at=NOW()\n            WHERE id=?\n        ")->execute([
            $version['currency'],
            $contractFrom,
            $contractTo,
            $version['document_code'],
            $version['supplier_tax_percent'],
            $version['tax_included'],
            $version['payment_terms'],
            $version['cancellation_terms'],
            $adminId ?: null,
            (int)$version['contract_id'],
        ]);

        $pdo->prepare("UPDATE supplier_documents SET status='linked',updated_at=NOW() WHERE id=?")
            ->execute([(int)$version['supplier_document_id']]);

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function tsSupplierDocumentReanalyze(PDO $pdo, int $documentId): array
{
    $document = tsSupplierDocumentGet($pdo, $documentId);
    if (!$document) throw new RuntimeException('Supplier document not found.');
    $path = tsSupplierDocumentStoredPath((string)$document['stored_path']);

    $supplierStmt = $pdo->prepare("SELECT * FROM suppliers WHERE id=? LIMIT 1");
    $supplierStmt->execute([(int)$document['supplier_id']]);
    $supplier = $supplierStmt->fetch(PDO::FETCH_ASSOC) ?: null;

    $extracted = tsSupplierDocumentExtractFileText($path);
    $analysis = tsSupplierDocumentAnalyzeText((string)$extracted['text'], $supplier ?: null);

    $stmt = $pdo->prepare("\n        UPDATE supplier_documents SET\n            document_type=?,valid_from=COALESCE(?,valid_from),valid_to=COALESCE(?,valid_to),\n            extraction_status=?,extraction_method=?,extraction_confidence=?,source_coverage=?,\n            detected_supplier_name=?,detected_itinerary_count=?,detected_hotel_category_count=?,\n            detected_rate_group_count=?,detected_meal_plan=?,detected_tax_notes=?,\n            detected_cancellation_terms=?,detected_transport_terms=?,analysis_json=?,\n            status=CASE WHEN status='archived' THEN status ELSE ? END,updated_at=NOW()\n        WHERE id=?\n    ");
    $status = $analysis['text_chars'] >= 80 ? 'review' : 'failed';
    $stmt->execute([
        $analysis['document_type'],
        $analysis['valid_from'],
        $analysis['valid_to'],
        $analysis['text_chars'] >= 80 ? 'analyzed' : 'failed',
        $extracted['method'],
        $analysis['source_coverage'],
        $analysis['source_coverage'],
        $analysis['supplier_detected'] ?: null,
        $analysis['itinerary_count'],
        $analysis['hotel_category_count'],
        $analysis['rate_group_count'],
        $analysis['meal_plan'] ?: null,
        $analysis['tax_notes'] ? implode("\n", $analysis['tax_notes']) : null,
        $analysis['cancellation_terms'] ?: null,
        $analysis['transport_terms'] ?: null,
        json_encode($analysis, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        $status,
        $documentId,
    ]);

    return $analysis;
}
