<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — CROSS-STAGE AUTOMATIC REMINDER ENGINE
|--------------------------------------------------------------------------
| Adds pre-booking quotation follow-ups and supplier reminders to the
| existing post-booking Communication Center. No new database tables.
|--------------------------------------------------------------------------
*/

$tsAutoSettings = __DIR__ . '/system-settings-functions.php';
if (is_file($tsAutoSettings) && !function_exists('tsSystemSettingInt')) {
    require_once $tsAutoSettings;
}

$tsAutoSupplier = __DIR__ . '/supplier-functions.php';
if (is_file($tsAutoSupplier) && !function_exists('tsSupplierEmail')) {
    require_once $tsAutoSupplier;
}

$tsAutoQuotation = __DIR__ . '/quotation-customer-functions.php';
if (is_file($tsAutoQuotation) && !function_exists('qcpCustomerQuotationUrl')) {
    require_once $tsAutoQuotation;
}

function tsAutoTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];
    $key = strtolower($table);
    if (array_key_exists($key, $cache)) return $cache[$key];

    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
        $stmt->execute([$table]);
        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}

function tsAutoBool(PDO $pdo, string $key, bool $fallback): bool
{
    return function_exists('tsSystemSettingBool')
        ? tsSystemSettingBool($pdo, $key, $fallback)
        : $fallback;
}

function tsAutoInt(PDO $pdo, string $key, int $fallback): int
{
    return function_exists('tsSystemSettingInt')
        ? tsSystemSettingInt($pdo, $key, $fallback)
        : $fallback;
}

function tsAutoMail(PDO $pdo, string $to, string $name, string $subject, string $html, string $plain): array
{
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'message' => 'Recipient email is unavailable.'];
    }
    if (!class_exists('\\PHPMailer\\PHPMailer\\PHPMailer')) {
        return ['ok' => false, 'message' => 'PHPMailer is unavailable.'];
    }

    try {
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        if (defined('SMTP_ENABLED') && SMTP_ENABLED) {
            $mail->isSMTP();
            $mail->Host = defined('SMTP_HOST') ? SMTP_HOST : 'smtp.gmail.com';
            $mail->SMTPAuth = defined('SMTP_AUTH') ? (bool)SMTP_AUTH : true;
            $mail->Username = defined('SMTP_USERNAME') ? SMTP_USERNAME : '';
            $mail->Password = defined('SMTP_PASSWORD') ? SMTP_PASSWORD : '';
            $mail->Port = defined('SMTP_PORT') ? (int)SMTP_PORT : 587;
            if (defined('SMTP_ENCRYPTION') && trim((string)SMTP_ENCRYPTION) !== '') {
                $mail->SMTPSecure = SMTP_ENCRYPTION;
            }
        }

        $from = defined('MAIL_FROM_ADDRESS') ? (string)MAIL_FROM_ADDRESS : (defined('SMTP_USERNAME') ? (string)SMTP_USERNAME : '');
        $fromName = defined('MAIL_FROM_NAME') ? (string)MAIL_FROM_NAME : 'TRAVSCOPE.COM';
        $mail->setFrom($from, $fromName);
        $mail->addAddress($to, $name !== '' ? $name : 'Traveller');
        if (defined('MAIL_REPLY_TO') && filter_var(MAIL_REPLY_TO, FILTER_VALIDATE_EMAIL)) {
            $mail->addReplyTo((string)MAIL_REPLY_TO, $fromName);
        }
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $html;
        $mail->AltBody = $plain;
        $mail->send();
        return ['ok' => true, 'message' => 'Email sent.'];
    } catch (Throwable $e) {
        error_log('TRAVSCOPE automatic reminder email: ' . $e->getMessage());
        return ['ok' => false, 'message' => $e->getMessage()];
    }
}

function tsAutoQuotationReminderCount(PDO $pdo, int $versionId): array
{
    if (!tsAutoTableExists($pdo, 'crm_quotation_messages')) return ['count' => 0, 'last_at' => null];
    $stmt = $pdo->prepare("SELECT COUNT(*) AS total, MAX(sent_at) AS last_at FROM crm_quotation_messages WHERE version_id=? AND direction='outbound' AND body_text LIKE 'AUTO QUOTATION FOLLOW-UP #%'");
    $stmt->execute([$versionId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    return ['count' => (int)($row['total'] ?? 0), 'last_at' => $row['last_at'] ?? null];
}

function tsAutoQuotationFollowups(PDO $pdo, int $limit = 25): array
{
    $result = ['eligible' => 0, 'sent' => 0, 'failed' => 0, 'errors' => []];
    if (!tsAutoBool($pdo, 'ops_auto_quotation_followups', false)) return $result;
    if (!function_exists('qcpCustomerQuotationUrl')) return $result;
    if (!tsAutoTableExists($pdo, 'crm_package_versions') || !tsAutoTableExists($pdo, 'enquiries')) return $result;

    $firstDays = tsAutoInt($pdo, 'ops_quotation_followup_first_days', 2);
    $repeatDays = tsAutoInt($pdo, 'ops_quotation_followup_repeat_days', 3);
    $maxReminders = tsAutoInt($pdo, 'ops_quotation_followup_max_reminders', 3);
    if ($maxReminders <= 0) return $result;

    $sql = "
        SELECT v.*, e.name AS customer_name, e.email AS customer_email, e.status AS enquiry_status
        FROM crm_package_versions v
        JOIN enquiries e ON e.id=v.lead_id
        WHERE v.email_sent_at IS NOT NULL
          AND v.id=(SELECT v2.id FROM crm_package_versions v2 WHERE v2.lead_id=v.lead_id ORDER BY v2.version_number DESC,v2.id DESC LIMIT 1)
          AND LOWER(COALESCE(e.status,'')) NOT IN ('converted','closed','cancelled','rejected')
    ";
    if (tsAutoTableExists($pdo, 'quotation_acceptances')) {
        $sql .= " AND NOT EXISTS (SELECT 1 FROM quotation_acceptances a WHERE a.quotation_version_id=v.id)";
    }
    if (tsAutoTableExists($pdo, 'quotation_customer_responses')) {
        $sql .= " AND NOT EXISTS (SELECT 1 FROM quotation_customer_responses qr WHERE qr.quotation_version_id=v.id AND qr.decision IN ('accepted','change_requested','rejected'))";
    }
    $sql .= " ORDER BY v.email_sent_at ASC LIMIT 250";

    $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $now = time();

    foreach ($rows as $row) {
        if ($result['sent'] + $result['failed'] >= $limit) break;
        $email = trim((string)($row['customer_email'] ?? ''));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) continue;

        $stats = tsAutoQuotationReminderCount($pdo, (int)$row['id']);
        if ($stats['count'] >= $maxReminders) continue;

        $baseAt = $stats['count'] > 0 && !empty($stats['last_at'])
            ? strtotime((string)$stats['last_at'])
            : strtotime((string)$row['email_sent_at']);
        if (!$baseAt) continue;
        $waitDays = $stats['count'] > 0 ? $repeatDays : $firstDays;
        $dueAt = strtotime('+' . max(0, $waitDays) . ' days', $baseAt);
        if (!$dueAt || $dueAt > $now) continue;

        $result['eligible']++;
        $number = $stats['count'] + 1;
        $leadId = (int)$row['lead_id'];
        $versionId = (int)$row['id'];
        $versionNumber = (int)($row['version_number'] ?? 1);
        $customer = trim((string)($row['customer_name'] ?? 'Traveller')) ?: 'Traveller';
        $title = trim((string)($row['package_title'] ?? 'Travel Quotation')) ?: 'Travel Quotation';
        $link = qcpCustomerQuotationUrl($leadId, $versionId, 30);
        $subject = 'Reminder: Your TRAVSCOPE quotation V' . $versionNumber . ' · ' . $title;

        $safeCustomer = htmlspecialchars($customer, ENT_QUOTES, 'UTF-8');
        $safeTitle = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        $safeLink = htmlspecialchars($link, ENT_QUOTES, 'UTF-8');
        $html = '<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#172033;line-height:1.65">'
            . '<div style="padding:18px 20px;background:#0f172a;color:#fff;border-radius:14px 14px 0 0"><strong style="font-size:19px">TRAVSCOPE</strong><div style="font-size:12px;opacity:.8">Quotation Follow-up</div></div>'
            . '<div style="padding:22px;border:1px solid #e2e8f0;border-top:0;border-radius:0 0 14px 14px">'
            . '<p>Dear ' . $safeCustomer . ',</p><p>This is a friendly reminder about your travel quotation for <strong>' . $safeTitle . '</strong>.</p>'
            . '<p>You can securely review the latest quotation and choose <strong>Accept</strong>, <strong>Request Changes</strong>, or <strong>Reject</strong>.</p>'
            . '<p><a href="' . $safeLink . '" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:bold">Review Latest Quotation</a></p>'
            . '<p style="font-size:12px;color:#64748b">If you have already spoken with our team, you may reply to this email with any changes you need.</p>'
            . '<p>Regards,<br>TRAVSCOPE.COM</p></div></div>';
        $plain = "Dear {$customer},\n\nThis is a friendly reminder about your travel quotation for {$title}.\n\nReview latest quotation: {$link}\n\nYou can Accept, Request Changes, or Reject from the secure page.\n\nRegards,\nTRAVSCOPE.COM";

        $mail = tsAutoMail($pdo, $email, $customer, $subject, $html, $plain);
        if (empty($mail['ok'])) {
            $result['failed']++;
            $result['errors'][] = 'Quotation V' . $versionNumber . ' / Lead #' . $leadId . ': ' . (string)$mail['message'];
            continue;
        }

        try {
            if (tsAutoTableExists($pdo, 'crm_quotation_messages')) {
                $messageId = '<auto-qfollow-' . $versionId . '-' . $number . '-' . bin2hex(random_bytes(4)) . '@travscope.local>';
                $stmt = $pdo->prepare("INSERT INTO crm_quotation_messages (lead_id,version_id,direction,sender_email,recipient_email,subject,body_text,message_id,in_reply_to,sent_at) VALUES (?,?,'outbound',?,?,?,?,?,NULL,NOW())");
                $stmt->execute([
                    $leadId,
                    $versionId,
                    defined('MAIL_FROM_ADDRESS') ? (string)MAIL_FROM_ADDRESS : (defined('SMTP_USERNAME') ? (string)SMTP_USERNAME : ''),
                    $email,
                    $subject,
                    'AUTO QUOTATION FOLLOW-UP #' . $number . "\n\n" . $plain,
                    $messageId,
                ]);
            }
            if (tsAutoTableExists($pdo, 'crm_lead_meta')) {
                $pdo->prepare("UPDATE crm_lead_meta SET last_contact_at=NOW(),updated_at=NOW() WHERE enquiry_id=?")->execute([$leadId]);
            }
            $result['sent']++;
        } catch (Throwable $e) {
            // Email already left the server. Log the storage failure but do not retry immediately as a failed send.
            $result['sent']++;
            $result['errors'][] = 'Quotation reminder sent but timeline logging failed for Lead #' . $leadId . ': ' . $e->getMessage();
        }
    }

    return $result;
}

function tsAutoSupplierContact(PDO $pdo, int $supplierId, ?int $contactId): ?array
{
    if ($contactId && tsAutoTableExists($pdo, 'supplier_contacts')) {
        $stmt = $pdo->prepare("SELECT * FROM supplier_contacts WHERE id=? AND supplier_id=? AND status='active' LIMIT 1");
        $stmt->execute([$contactId, $supplierId]);
        if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) return $row;
    }
    return function_exists('tsSupplierPrimaryContact') ? tsSupplierPrimaryContact($pdo, $supplierId) : null;
}

function tsAutoSupplierQuoteReminders(PDO $pdo, int $limit = 25): array
{
    $result = ['eligible' => 0, 'sent' => 0, 'failed' => 0, 'errors' => []];
    if (!tsAutoBool($pdo, 'ops_auto_supplier_quote_reminders', false)) return $result;
    if (!function_exists('tsSupplierEmail') || !tsAutoTableExists($pdo, 'supplier_requests')) return $result;

    $repeatHours = tsAutoInt($pdo, 'ops_supplier_quote_reminder_repeat_hours', 24);
    $maxReminders = tsAutoInt($pdo, 'ops_supplier_quote_max_reminders', 3);
    if ($maxReminders <= 0) return $result;

    $stmt = $pdo->query("
        SELECT r.*,s.company_name
        FROM supplier_requests r
        JOIN suppliers s ON s.id=r.supplier_id
        WHERE r.channel='email'
          AND r.first_response_at IS NULL
          AND r.reminder_due_at IS NOT NULL
          AND r.reminder_due_at<=NOW()
          AND r.status IN ('sent','awaiting_response','reminder_sent')
        ORDER BY r.reminder_due_at ASC,r.id ASC
        LIMIT 250
    ");

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $request) {
        if ($result['sent'] + $result['failed'] >= $limit) break;

        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM supplier_request_events WHERE supplier_request_id=? AND event_type='auto_reminder_sent'");
        $countStmt->execute([(int)$request['id']]);
        $count = (int)$countStmt->fetchColumn();
        if ($count >= $maxReminders) {
            $pdo->prepare("UPDATE supplier_requests SET reminder_due_at=NULL WHERE id=?")->execute([(int)$request['id']]);
            continue;
        }

        $result['eligible']++;
        $supplierId = (int)$request['supplier_id'];
        $supplierStmt = $pdo->prepare("SELECT * FROM suppliers WHERE id=? LIMIT 1");
        $supplierStmt->execute([$supplierId]);
        $supplier = $supplierStmt->fetch(PDO::FETCH_ASSOC) ?: null;
        if (!$supplier) continue;
        $contact = tsAutoSupplierContact($pdo, $supplierId, !empty($request['supplier_contact_id']) ? (int)$request['supplier_contact_id'] : null);

        $number = $count + 1;
        $mailRequest = $request;
        $mailRequest['subject'] = 'Reminder #' . $number . ': ' . (string)$request['subject'];
        $mailRequest['requirement_text'] = "Dear Partner,\n\nAutomatic follow-up from TRAVSCOPE for Supplier Request " . (string)$request['request_code'] . ". Kindly share your current NET quotation / availability at the earliest.\n\n" . (string)$request['requirement_text'];
        $mail = tsSupplierEmail($pdo, $mailRequest, $supplier, $contact);

        if (empty($mail['ok'])) {
            $result['failed']++;
            $result['errors'][] = (string)$request['request_code'] . ': ' . (string)($mail['message'] ?? 'Supplier reminder failed.');
            if (function_exists('tsSupplierEvent')) tsSupplierEvent($pdo, (int)$request['id'], 'auto_reminder_failed', null, (string)($mail['message'] ?? 'Automatic supplier reminder failed.'), 'email');
            continue;
        }

        $pdo->prepare("UPDATE supplier_requests SET status='reminder_sent',last_reminder_at=NOW(),reminder_due_at=DATE_ADD(NOW(),INTERVAL " . max(1, $repeatHours) . " HOUR),updated_at=NOW() WHERE id=?")->execute([(int)$request['id']]);
        if (function_exists('tsSupplierEvent')) tsSupplierEvent($pdo, (int)$request['id'], 'auto_reminder_sent', null, 'Automatic supplier quotation reminder #' . $number . ' sent.', 'email');
        if (function_exists('tsSupplierMessage')) tsSupplierMessage($pdo, (int)$request['id'], 'system', null, 'AUTO SUPPLIER QUOTE REMINDER #' . $number . ' sent by email.', 'email');
        $result['sent']++;
    }

    return $result;
}

function tsAutoSupplierBookingReminders(PDO $pdo, int $limit = 25, ?int $bookingId = null): array
{
    $result = ['eligible' => 0, 'sent' => 0, 'failed' => 0, 'errors' => []];
    if (!tsAutoBool($pdo, 'ops_auto_supplier_confirmation_reminders', false)) return $result;
    if (!function_exists('tsSupplierBookingEmail') || !tsAutoTableExists($pdo, 'supplier_booking_orders')) return $result;

    $firstHours = tsAutoInt($pdo, 'ops_supplier_confirmation_first_hours', 24);
    $repeatHours = tsAutoInt($pdo, 'ops_supplier_confirmation_repeat_hours', 24);
    $maxReminders = tsAutoInt($pdo, 'ops_supplier_confirmation_max_reminders', 3);
    if ($maxReminders <= 0) return $result;

    $sql = "
        SELECT o.*,b.booking_number,b.currency,t.trip_code,s.company_name
        FROM supplier_booking_orders o
        JOIN bookings b ON b.id=o.booking_id
        JOIN trips t ON t.id=o.trip_id
        JOIN suppliers s ON s.id=o.supplier_id
        WHERE o.sent_at IS NOT NULL
          AND o.status IN ('sent','partially_confirmed')
          AND b.booking_status<>'cancelled'
    ";
    $params = [];
    if ($bookingId && $bookingId > 0) {
        $sql .= " AND o.booking_id=?";
        $params[] = $bookingId;
    }
    $sql .= " ORDER BY COALESCE(o.last_response_at,o.sent_at) ASC,o.id ASC LIMIT 250";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $now = time();
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $order) {
        if ($result['sent'] + $result['failed'] >= $limit) break;
        $orderId = (int)$order['id'];

        $itemsStmt = $pdo->prepare("SELECT * FROM supplier_booking_order_items WHERE supplier_booking_order_id=? AND status IN ('confirmation_required','confirmation_requested') ORDER BY sort_order,id");
        $itemsStmt->execute([$orderId]);
        $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        if (!$items) continue;

        $msgStmt = $pdo->prepare("SELECT COUNT(*) AS total,MAX(sent_at) AS last_at FROM supplier_booking_order_messages WHERE supplier_booking_order_id=? AND sender_type='system' AND channel='email' AND message LIKE 'AUTO SUPPLIER CONFIRMATION REMINDER #%'");
        $msgStmt->execute([$orderId]);
        $stats = $msgStmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $count = (int)($stats['total'] ?? 0);
        if ($count >= $maxReminders) continue;

        $anchor = $count > 0 && !empty($stats['last_at'])
            ? strtotime((string)$stats['last_at'])
            : strtotime((string)($order['last_response_at'] ?: $order['sent_at']));
        if (!$anchor) continue;
        $waitHours = $count > 0 ? $repeatHours : $firstHours;
        $dueAt = strtotime('+' . max(1, $waitHours) . ' hours', $anchor);
        if (!$dueAt || $dueAt > $now) continue;

        $result['eligible']++;
        $supplierId = (int)$order['supplier_id'];
        $supplierStmt = $pdo->prepare("SELECT * FROM suppliers WHERE id=? LIMIT 1");
        $supplierStmt->execute([$supplierId]);
        $supplier = $supplierStmt->fetch(PDO::FETCH_ASSOC) ?: null;
        if (!$supplier) continue;
        $contact = tsAutoSupplierContact($pdo, $supplierId, !empty($order['supplier_contact_id']) ? (int)$order['supplier_contact_id'] : null);

        $number = $count + 1;
        $mailOrder = $order;
        $mailOrder['subject'] = 'Reminder #' . $number . ': ' . (string)$order['subject'];
        $mailOrder['request_text'] = "Automatic follow-up: please confirm the remaining pending booked service(s).\n\n" . trim((string)($order['request_text'] ?? ''));
        $mail = tsSupplierBookingEmail($pdo, $mailOrder, $supplier, $contact, $items);

        if (empty($mail['ok'])) {
            $result['failed']++;
            $result['errors'][] = (string)$order['order_code'] . ': ' . (string)($mail['message'] ?? 'Supplier confirmation reminder failed.');
            continue;
        }

        if (function_exists('tsSupplierBookingMessage')) {
            tsSupplierBookingMessage($pdo, $orderId, 'system', null, 'AUTO SUPPLIER CONFIRMATION REMINDER #' . $number . ' sent by email.', 'email');
        }
        $result['sent']++;
    }

    return $result;
}

function tsAutoRun(PDO $pdo, int $limit = 25, ?int $bookingId = null, bool $global = true): array
{
    $result = [
        'quotation' => ['eligible'=>0,'sent'=>0,'failed'=>0,'errors'=>[]],
        'supplier_quote' => ['eligible'=>0,'sent'=>0,'failed'=>0,'errors'=>[]],
        'supplier_confirmation' => ['eligible'=>0,'sent'=>0,'failed'=>0,'errors'=>[]],
        'sent' => 0,
        'failed' => 0,
        'errors' => [],
    ];

    if ($global) {
        // Divide each cron run's cross-stage send budget across the three queues
        // so a large quotation backlog cannot starve supplier follow-ups.
        $limit = max(1, $limit);
        $base = intdiv($limit, 3);
        $extra = $limit % 3;
        $quotas = [
            max(0, $base + ($extra > 0 ? 1 : 0)),
            max(0, $base + ($extra > 1 ? 1 : 0)),
            max(0, $base),
        ];

        if ($quotas[0] > 0) $result['quotation'] = tsAutoQuotationFollowups($pdo, $quotas[0]);
        if ($quotas[1] > 0) $result['supplier_quote'] = tsAutoSupplierQuoteReminders($pdo, $quotas[1]);
        if ($quotas[2] > 0) $result['supplier_confirmation'] = tsAutoSupplierBookingReminders($pdo, $quotas[2], null);
    } elseif ($bookingId && $bookingId > 0) {
        $result['supplier_confirmation'] = tsAutoSupplierBookingReminders($pdo, $limit, $bookingId);
    }

    foreach (['quotation','supplier_quote','supplier_confirmation'] as $key) {
        $result['sent'] += (int)$result[$key]['sent'];
        $result['failed'] += (int)$result[$key]['failed'];
        foreach ((array)$result[$key]['errors'] as $error) $result['errors'][] = $error;
    }
    return $result;
}
