<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/notification-functions.php';

requireAdmin();

$admin =
    currentAdmin($pdo);

if (
    !$admin
    || strtolower(
        (string)(
            $admin['status']
            ?? ''
        )
    ) !== 'active'
) {
    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_role']
    );

    redirect(
        BASE_URL
        . 'admin-login.php'
    );
}

$adminId =
    (int)$admin['id'];

if (empty($_SESSION['admin_notifications_csrf'])) {
    $_SESSION['admin_notifications_csrf'] =
        bin2hex(
            random_bytes(32)
        );
}

$csrfToken =
    (string)$_SESSION['admin_notifications_csrf'];

$error = '';
$success = '';

if (!empty($_SESSION['admin_notifications_success'])) {
    $success =
        (string)$_SESSION['admin_notifications_success'];

    unset(
        $_SESSION['admin_notifications_success']
    );
}

if (!tsNotifyReady($pdo)) {
    $error =
        'Import TRAVSCOPE_System_Notifications_Escalation_Engine.sql to activate the notification engine.';
}

$statusFilter =
    (string)(
        $_GET['status']
        ?? 'active'
    );

if (
    !in_array(
        $statusFilter,
        [
            'active',
            'unread',
            'dismissed',
            'resolved',
            'all',
        ],
        true
    )
) {
    $statusFilter =
        'active';
}

$severityFilter =
    (string)(
        $_GET['severity']
        ?? ''
    );

if (
    !in_array(
        $severityFilter,
        [
            '',
            'info',
            'warning',
            'high',
            'critical',
        ],
        true
    )
) {
    $severityFilter = '';
}

$categoryFilter =
    trim(
        (string)(
            $_GET['category']
            ?? ''
        )
    );

if (
    $_SERVER['REQUEST_METHOD']
    === 'POST'
) {
    $postedToken =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    if (
        $postedToken === ''
        || !hash_equals(
            $csrfToken,
            $postedToken
        )
    ) {
        $error =
            'Security verification failed. Refresh and try again.';

    } elseif (!tsNotifyReady($pdo)) {
        $error =
            'Notification SQL is not installed.';

    } else {
        try {
            $action =
                (string)(
                    $_POST['action']
                    ?? ''
                );

            if ($action === 'sync') {
                $result =
                    tsNotifySync($pdo);

                $_SESSION['admin_notifications_success'] =
                    'Notification sources synchronized. '
                    . (int)$result['created_or_updated']
                    . ' recipient alert record(s) refreshed.';

            } elseif ($action === 'mark_all_read') {
                $count =
                    tsNotifyMarkAllRead(
                        $pdo,
                        $adminId
                    );

                $_SESSION['admin_notifications_success'] =
                    $count
                    . ' notification'
                    . ($count === 1 ? '' : 's')
                    . ' marked read.';

            } elseif (
                in_array(
                    $action,
                    [
                        'mark_read',
                        'mark_unread',
                        'dismiss',
                    ],
                    true
                )
            ) {
                $notificationId =
                    max(
                        0,
                        (int)(
                            $_POST['notification_id']
                            ?? 0
                        )
                    );

                $targetStatus =
                    match ($action) {
                        'mark_read' => 'read',
                        'mark_unread' => 'unread',
                        default => 'dismissed',
                    };

                tsNotifySetStatus(
                    $pdo,
                    $adminId,
                    $notificationId,
                    $targetStatus
                );

                $_SESSION['admin_notifications_success'] =
                    match ($targetStatus) {
                        'read' => 'Notification marked read.',
                        'unread' => 'Notification returned to unread.',
                        default => 'Notification dismissed. It will reopen only if its escalation level increases.',
                    };

            } else {
                throw new RuntimeException(
                    'Invalid notification action.'
                );
            }

            $query =
                http_build_query([
                    'status' =>
                        $statusFilter,
                    'severity' =>
                        $severityFilter,
                    'category' =>
                        $categoryFilter,
                ]);

            redirect(
                BASE_URL
                . 'admin-notifications.php?'
                . $query
            );

        } catch (RuntimeException $e) {
            $error =
                $e->getMessage();

        } catch (Throwable $e) {
            error_log(
                'Admin Notifications action: '
                . $e->getMessage()
            );

            $error =
                'Unable to complete notification action: '
                . $e->getMessage();
        }
    }
}

if (tsNotifyReady($pdo)) {
    try {
        tsNotifyMaybeSync(
            $pdo,
            120
        );
    } catch (Throwable $e) {
        error_log(
            'Notification background sync: '
            . $e->getMessage()
        );
    }
}

$summary =
    tsNotifySummary(
        $pdo,
        $adminId
    );

$categories =
    tsNotifyCategories(
        $pdo,
        $adminId
    );

$rows =
    tsNotifyRows(
        $pdo,
        $adminId,
        $statusFilter,
        $severityFilter,
        $categoryFilter
    );

function ntE(?string $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function ntDate(?string $value): string
{
    if (!$value) {
        return '-';
    }

    $ts =
        strtotime($value);

    return
        $ts
            ? date(
                'd M Y · h:i A',
                $ts
            )
            : (string)$value;
}

function ntSeverityLabel(string $severity): string
{
    return
        match ($severity) {
            'critical' => 'CRITICAL',
            'high' => 'HIGH',
            'warning' => 'WARNING',
            default => 'INFO',
        };
}

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>System Notifications | TRAVSCOPE Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:68px;padding:10px 4%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;border-bottom:1px solid #dfe7f0;position:sticky;top:0;z-index:20}.brand{font-weight:900;color:#0f172a}.brand span{color:#2563eb}.top-actions{display:flex;gap:7px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;gap:6px;border:1px solid #cbd5e1;border-radius:9px;padding:8px 10px;background:#fff;color:#334155;text-decoration:none;font-size:9px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.btn.good{background:#059669;border-color:#059669;color:#fff}.btn.warn{background:#fff7ed;border-color:#fed7aa;color:#c2410c}.btn.danger{background:#fff1f2;border-color:#fecdd3;color:#be123c}.wrap{max-width:1280px;margin:20px auto;padding:0 13px}.hero{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;padding:17px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:20px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px;line-height:1.5}.notice{margin-top:10px;padding:10px 12px;border-radius:10px;font-size:10px}.notice.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#047857}.notice.err{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c}.stats{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin-top:11px}.stat{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.stat span{display:block;color:#64748b;font-size:7.5px;font-weight:900;text-transform:uppercase}.stat strong{display:block;margin-top:4px;font-size:13px}.stat.critical{background:#fef2f2;border-color:#fecaca}.stat.critical strong{color:#b91c1c}.stat.high{background:#fff7ed;border-color:#fed7aa}.stat.high strong{color:#c2410c}.filters{display:flex;gap:6px;flex-wrap:wrap;margin-top:11px;padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.filters a{padding:6px 9px;border:1px solid #cbd5e1;border-radius:999px;background:#fff;color:#475569;text-decoration:none;font-size:8px;font-weight:900}.filters a.active{background:#0f172a;border-color:#0f172a;color:#fff}.filters select{min-height:30px;padding:5px 7px;border:1px solid #cbd5e1;border-radius:8px;font-size:8.5px}.list{margin-top:11px}.item{margin-bottom:8px;padding:11px;border:1px solid #dfe7f0;border-left-width:5px;border-radius:12px;background:#fff}.item.unread{box-shadow:0 7px 20px rgba(15,23,42,.05)}.item.critical{border-left-color:#dc2626;background:linear-gradient(90deg,#fff1f2,#fff 18%)}.item.high{border-left-color:#ea580c;background:linear-gradient(90deg,#fff7ed,#fff 18%)}.item.warning{border-left-color:#d97706}.item.info{border-left-color:#2563eb}.item-top{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.item h3{margin:0;font-size:11px}.item p{margin:5px 0 0;color:#64748b;font-size:9px;line-height:1.5}.meta{display:flex;gap:5px;flex-wrap:wrap;margin-top:7px}.pill{display:inline-flex;padding:4px 7px;border-radius:999px;background:#f1f5f9;color:#64748b;font-size:7.5px;font-weight:900}.pill.critical{background:#fee2e2;color:#b91c1c}.pill.high{background:#ffedd5;color:#c2410c}.pill.warning{background:#fef3c7;color:#92400e}.pill.unread{background:#dbeafe;color:#1d4ed8}.actions{display:flex;gap:5px;flex-wrap:wrap;margin-top:8px}.empty{padding:28px;text-align:center;color:#94a3b8;border:1px dashed #cbd5e1;border-radius:12px;background:#fff;font-size:10px}
@media(max-width:850px){.stats{grid-template-columns:repeat(2,1fr)}.top,.hero{align-items:flex-start;flex-direction:column}}
@media(max-width:520px){.stats{grid-template-columns:1fr}.item-top{display:block}.item-top .pill{margin-top:7px}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head>
<body>

<header class="top">
    <div class="brand">
        TRAV<span>SCOPE</span> · SYSTEM NOTIFICATIONS
    </div>

    <div class="top-actions">
        <a
            class="btn"
            href="<?= ntE(BASE_URL . 'admin-dashboard.php'); ?>"
        >
            <i class="fa-solid fa-gauge-high"></i>
            Dashboard
        </a>

        <form method="post">
            <input
                type="hidden"
                name="csrf_token"
                value="<?= ntE($csrfToken); ?>"
            >
            <input
                type="hidden"
                name="action"
                value="sync"
            >

            <button
                class="btn primary"
                type="submit"
                <?= !tsNotifyReady($pdo) ? 'disabled' : ''; ?>
            >
                <i class="fa-solid fa-rotate"></i>
                Sync Alerts
            </button>
        </form>

        <form method="post">
            <input
                type="hidden"
                name="csrf_token"
                value="<?= ntE($csrfToken); ?>"
            >
            <input
                type="hidden"
                name="action"
                value="mark_all_read"
            >

            <button
                class="btn"
                type="submit"
                <?= (int)$summary['unread'] <= 0 ? 'disabled' : ''; ?>
            >
                Mark All Read
            </button>
        </form>
    </div>
</header>

<main class="wrap">

<section class="hero">
    <div>
        <h1>System Notifications & Escalation Inbox</h1>
        <p>
            Owner follow-ups, supplier confirmations, collections, departure readiness,
            traveller documents, live incidents, finance exceptions, customer communication
            jobs and repeat-sales follow-ups — automatically deduplicated and resolved when
            the underlying condition clears.
        </p>
    </div>

    <div>
        <span class="pill unread">
            <?= (int)$summary['unread']; ?> UNREAD
        </span>
    </div>
</section>

<?php if ($success): ?>
    <div class="notice ok"><?= ntE($success); ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="notice err"><?= ntE($error); ?></div>
<?php endif; ?>

<div class="stats">
    <div class="stat"><span>Unread</span><strong><?= (int)$summary['unread']; ?></strong></div>
    <div class="stat critical"><span>Critical Active</span><strong><?= (int)$summary['critical']; ?></strong></div>
    <div class="stat high"><span>High Active</span><strong><?= (int)$summary['high']; ?></strong></div>
    <div class="stat"><span>Warning Active</span><strong><?= (int)$summary['warning']; ?></strong></div>
    <div class="stat"><span>Due / Overdue</span><strong><?= (int)$summary['due']; ?></strong></div>
</div>

<div class="filters">
    <?php
    $baseFilters = [
        'severity' => $severityFilter,
        'category' => $categoryFilter,
    ];
    ?>

    <?php foreach ([
        'active' => 'Active',
        'unread' => 'Unread',
        'dismissed' => 'Dismissed',
        'resolved' => 'Resolved',
        'all' => 'All'
    ] as $key => $label): ?>
        <a
            class="<?= $statusFilter === $key ? 'active' : ''; ?>"
            href="<?= ntE(
                BASE_URL
                . 'admin-notifications.php?'
                . http_build_query(
                    array_merge(
                        $baseFilters,
                        ['status' => $key]
                    )
                )
            ); ?>"
        >
            <?= ntE($label); ?>
        </a>
    <?php endforeach; ?>

    <form method="get" style="display:flex;gap:6px;flex-wrap:wrap;">
        <input
            type="hidden"
            name="status"
            value="<?= ntE($statusFilter); ?>"
        >

        <select name="severity">
            <option value="">All Severity</option>
            <?php foreach ([
                'critical' => 'Critical',
                'high' => 'High',
                'warning' => 'Warning',
                'info' => 'Info'
            ] as $key => $label): ?>
                <option
                    value="<?= ntE($key); ?>"
                    <?= $severityFilter === $key ? 'selected' : ''; ?>
                >
                    <?= ntE($label); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <select name="category">
            <option value="">All Categories</option>
            <?php foreach ($categories as $category): ?>
                <option
                    value="<?= ntE((string)$category); ?>"
                    <?= $categoryFilter === (string)$category ? 'selected' : ''; ?>
                >
                    <?= ntE((string)$category); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button class="btn" type="submit">
            Filter
        </button>
    </form>
</div>

<div class="list">
    <?php if (!$rows): ?>
        <div class="empty">
            No notifications match this view.
        </div>
    <?php endif; ?>

    <?php foreach ($rows as $row): ?>
        <?php
        $severity =
            (string)$row['severity'];

        $status =
            (string)$row['status'];
        ?>

        <article
            class="item <?= ntE($severity); ?> <?= $status === 'unread' ? 'unread' : ''; ?>"
        >
            <div class="item-top">
                <div>
                    <h3><?= ntE((string)$row['title']); ?></h3>
                    <p><?= ntE((string)($row['message'] ?? '')); ?></p>
                </div>

                <span class="pill <?= ntE($severity); ?>">
                    <?= ntE(ntSeverityLabel($severity)); ?>
                </span>
            </div>

            <div class="meta">
                <span class="pill"><?= ntE((string)$row['category']); ?></span>
                <span class="pill <?= $status === 'unread' ? 'unread' : ''; ?>">
                    <?= ntE(strtoupper($status)); ?>
                </span>
                <span class="pill">
                    Escalation L<?= (int)$row['escalation_level']; ?>
                </span>
                <span class="pill">
                    Seen <?= ntE(ntDate((string)$row['last_detected_at'])); ?>
                </span>

                <?php if (!empty($row['due_at'])): ?>
                    <span class="pill">
                        Due <?= ntE(ntDate((string)$row['due_at'])); ?>
                    </span>
                <?php endif; ?>

                <?php if (!empty($row['email_sent_at'])): ?>
                    <span class="pill">
                        Email Escalated <?= ntE(ntDate((string)$row['email_sent_at'])); ?>
                    </span>
                <?php endif; ?>
            </div>

            <div class="actions">
                <?php if (!empty($row['link_url'])): ?>
                    <a
                        class="btn primary"
                        href="<?= ntE(
                            tsNotifyAbsoluteUrl(
                                (string)$row['link_url']
                            )
                        ); ?>"
                    >
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        Open Source
                    </a>
                <?php endif; ?>

                <?php if ($status === 'unread'): ?>
                    <form method="post">
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= ntE($csrfToken); ?>"
                        >
                        <input
                            type="hidden"
                            name="action"
                            value="mark_read"
                        >
                        <input
                            type="hidden"
                            name="notification_id"
                            value="<?= (int)$row['id']; ?>"
                        >

                        <button class="btn good" type="submit">
                            Mark Read
                        </button>
                    </form>
                <?php elseif ($status === 'read'): ?>
                    <form method="post">
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= ntE($csrfToken); ?>"
                        >
                        <input
                            type="hidden"
                            name="action"
                            value="mark_unread"
                        >
                        <input
                            type="hidden"
                            name="notification_id"
                            value="<?= (int)$row['id']; ?>"
                        >

                        <button class="btn" type="submit">
                            Mark Unread
                        </button>
                    </form>
                <?php endif; ?>

                <?php if (in_array($status, ['unread','read'], true)): ?>
                    <form
                        method="post"
                        onsubmit="return confirm('Dismiss this alert? It will reopen automatically if its escalation level increases.');"
                    >
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= ntE($csrfToken); ?>"
                        >
                        <input
                            type="hidden"
                            name="action"
                            value="dismiss"
                        >
                        <input
                            type="hidden"
                            name="notification_id"
                            value="<?= (int)$row['id']; ?>"
                        >

                        <button class="btn warn" type="submit">
                            Dismiss
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </article>
    <?php endforeach; ?>
</div>

</main>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
