<?php
declare(strict_types=1);
/** TRAVSCOPE V24.33 — RailRadar timetable-only suggestion adapter. Never books tickets. */

function tsRailRadarConfigured(PDO $pdo): bool {
    return trim(tsTravelSetting($pdo, 'railradar_api_key', '')) !== '';
}

function tsRailRadarRequest(PDO $pdo, string $path, array $query = []): array {
    $key = trim(tsTravelSetting($pdo, 'railradar_api_key', ''));
    if ($key === '') return ['ok'=>false,'data'=>[],'status'=>0,'error'=>'Configure a RailRadar API key in API Settings first.'];
    if (!function_exists('curl_init')) return ['ok'=>false,'data'=>[],'status'=>0,'error'=>'The server requires the PHP cURL extension.'];
    // No user-controlled external host or redirects: credentials must only reach the API host.
    if (!preg_match('~^/(?:lookup/stations|trains/between/[A-Z0-9]{2,8}/[A-Z0-9]{2,8})$~D', $path)) {
        return ['ok'=>false,'data'=>[],'status'=>0,'error'=>'Invalid RailRadar API route.'];
    }
    $url = 'https://api.railradar.in/v1'.$path.($query ? '?'.http_build_query($query, '', '&', PHP_QUERY_RFC3986) : '');
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER=>true, CURLOPT_FOLLOWLOCATION=>false,
        CURLOPT_CONNECTTIMEOUT=>8, CURLOPT_TIMEOUT=>22,
        CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2,
        CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$key, 'Accept: application/json'],
    ]);
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $body = is_string($raw) ? json_decode($raw,true) : null;
    if ($raw === false || $err !== '') return ['ok'=>false,'data'=>[],'status'=>$status,'error'=>'RailRadar connection failed. Please try again or enter the train manually.'];
    if ($status === 429) return ['ok'=>false,'data'=>[],'status'=>$status,'error'=>'RailRadar request limit reached. Try again later, or enter the train manually.'];
    if ($status === 401 || $status === 403) return ['ok'=>false,'data'=>[],'status'=>$status,'error'=>'RailRadar API key is invalid or does not have access. Check API Settings.'];
    if ($status === 404) return ['ok'=>true,'data'=>['trains'=>[]],'status'=>$status,'error'=>''];
    if ($status < 200 || $status >= 300 || !is_array($body) || ($body['success']??false)!==true) {
        $detail = is_array($body) ? ($body['error']['message']??null) : null;
        return ['ok'=>false,'data'=>[],'status'=>$status,'error'=>is_string($detail) && $detail!=='' ? substr($detail,0,230) : 'RailRadar temporarily cannot return results. Manual entry is still available.'];
    }
    return ['ok'=>true,'data'=>is_array($body['data']??null)?$body['data']:[],'status'=>$status,'error'=>''];
}

/** A short-lived server-side station dictionary; API key and request context are never cached. */
function tsRailRadarStationSuggestions(PDO $pdo, string $search): array {
    $search=trim($search);
    if (strlen($search)<2 || strlen($search)>65) return ['ok'=>true,'stations'=>[],'error'=>''];
    $cachePath=rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR.'travscope_rr_stations_v2433.json';
    $map=null;
    if (is_file($cachePath) && filemtime($cachePath) > time()-43200) {
        $decoded=json_decode((string)@file_get_contents($cachePath),true);
        if (is_array($decoded)) $map=$decoded;
    }
    if ($map===null) {
        $result=tsRailRadarRequest($pdo,'/lookup/stations');
        if (!$result['ok']) return ['ok'=>false,'stations'=>[],'error'=>$result['error']];
        $map=$result['data'];
        if ($map && count($map)<30000 && is_writable(dirname($cachePath))) {
            @file_put_contents($cachePath,json_encode($map,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX);
            @chmod($cachePath,0600);
        }
    }
    $out=[];
    foreach ($map as $code=>$name) {
        if (!is_string($name) || !is_string($code)) continue;
        if (stripos($code,$search)===false && stripos($name,$search)===false) continue;
        $out[]=['code'=>strtoupper($code),'name'=>$name];
        if (count($out)>=16) break;
    }
    return ['ok'=>true,'stations'=>$out,'error'=>''];
}

/** Translate only documented RailRadar route fields. Date is when train reaches FROM station. */
function tsRailRadarMapRouteRow(array $row,string $from,string $to,string $date): ?array {
    $train=is_array($row['train']??null)?$row['train']:[];
    $origin=is_array($row['from']??null)?$row['from']:[];
    $dest=is_array($row['to']??null)?$row['to']:[];
    $number=trim((string)($train['number']??''));
    if (!preg_match('/^[0-9]{5}$/D',$number)) return null;
    $depart=(string)($origin['departure']??''); $arrive=(string)($dest['arrival']??'');
    $departureAt=null;$arrivalAt=null;
    $fromDay=max(1,(int)($origin['day']??1));$toDay=max($fromDay,(int)($dest['day']??$fromDay));
    if (preg_match('/^([01][0-9]|2[0-3]):[0-5][0-9]$/D',$depart)) $departureAt=$date.' '.$depart.':00';
    if (preg_match('/^([01][0-9]|2[0-3]):[0-5][0-9]$/D',$arrive)) {
        $d=new DateTimeImmutable($date);
        $arrivalAt=$d->modify('+'.min(10,$toDay-$fromDay).' days')->format('Y-m-d').' '.$arrive.':00';
    }
    $running=array_values(array_filter(array_map('strval',is_array($train['runDays']??null)?$train['runDays']:[])));
    return [
        'train_number'=>$number,'train_name'=>substr((string)($train['name']??''),0,190),
        'origin_code'=>$from,'destination_code'=>$to,
        'departure_at'=>$departureAt,'arrival_at'=>$arrivalAt,
        'duration_minutes'=>isset($row['duration'])?max(0,(int)$row['duration']):null,
        'running_days'=>implode(', ',array_map('ucfirst',$running)),
        'distance'=>isset($row['distance'])?(string)$row['distance']:'',
        'train_type'=>(string)($train['type']??''),
        'total_halts'=>isset($row['totalHaltsBetween'])?(int)$row['totalHaltsBetween']:null,
        'raw_json'=>json_encode($row,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
    ];
}

function tsRailRadarSearchRoutes(PDO $pdo,array $params,int $adminId): array {
    if (!tsTravelModuleReady($pdo)) throw new RuntimeException('Run the V24.26 Flight/Train SQL upgrade first.');
    $from=strtoupper(trim((string)($params['origin_code']??'')));
    $to=strtoupper(trim((string)($params['destination_code']??'')));
    $date=trim((string)($params['journey_date']??''));
    if (!preg_match('/^[A-Z0-9]{2,8}$/D',$from) || !preg_match('/^[A-Z0-9]{2,8}$/D',$to) || $from===$to) throw new RuntimeException('Select two different valid station codes.');
    $d=DateTimeImmutable::createFromFormat('!Y-m-d',$date);
    if (!$d || $d->format('Y-m-d')!==$date) throw new RuntimeException('Choose a valid journey date.');
    if (!tsRailRadarConfigured($pdo)) throw new RuntimeException('Enter your RailRadar API key in API Settings, or use manual train entry.');
    $lead=max(0,(int)($params['enquiry_id']??0));$trip=max(0,(int)($params['trip_id']??0));$package=max(0,(int)($params['package_id']??0));
    if ($lead<=0 && $trip<=0) throw new RuntimeException('Open a customer enquiry or trip before searching trains.');
    // Reuse a recent search belonging to the SAME trip/enquiry only.
    $cacheMinutes=max(0,min(120,(int)tsTravelSetting($pdo,'railradar_cache_minutes','30')));
    if ($cacheMinutes>0) {
        $stmt=$pdo->prepare("SELECT id FROM train_searches WHERE origin_code=? AND destination_code=? AND journey_date=? AND provider='railradar' AND response_status='success' AND ((trip_id=? AND ?>0) OR (enquiry_id=? AND ?>0)) AND created_at >= DATE_SUB(NOW(),INTERVAL ? MINUTE) ORDER BY id DESC LIMIT 1");
        $stmt->execute([$from,$to,$date,$trip,$trip,$lead,$lead,$cacheMinutes]);$oldId=(int)($stmt->fetchColumn()?:0);
        if ($oldId>0) {
            $stmt=$pdo->prepare('SELECT * FROM train_options WHERE search_id=? ORDER BY departure_at ASC,train_number ASC');
            $stmt->execute([$oldId]);$saved=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
            if ($saved) {
                // This cache is scoped to the same trip/enquiry; it cannot cross contexts.
                return ['ok'=>true,'options'=>$saved,'search_id'=>$oldId,'cached'=>true,'error'=>''];
            }
        }
    }
    $stmt=$pdo->prepare("INSERT INTO train_searches(enquiry_id,trip_id,package_id,origin_code,destination_code,journey_date,provider,request_json,response_status,created_by_admin_id) VALUES(?,?,?,?,?,?,'railradar',?,'pending',?)");
    $stmt->execute([$lead?:null,$trip?:null,$package?:null,$from,$to,$date,json_encode(['from'=>$from,'to'=>$to,'date'=>$date]),$adminId?:null]);
    $searchId=(int)$pdo->lastInsertId();
    $started=microtime(true);
    $api=tsRailRadarRequest($pdo,'/trains/between/'.$from.'/'.$to,['date'=>$date,'live'=>'false']);
    tsTravelLogApi($pdo,['service_type'=>'train','provider'=>'railradar','action_name'=>'trains_between','enquiry_id'=>$lead?:null,'trip_id'=>$trip?:null,'request_summary'=>$from.' → '.$to.' '.$date,'http_status'=>$api['status'],'response_status'=>$api['ok']?'success':'error','error_message'=>$api['error']?:null,'duration_ms'=>(int)((microtime(true)-$started)*1000),'created_by_admin_id'=>$adminId?:null]);
    if (!$api['ok']) {
        $pdo->prepare("UPDATE train_searches SET response_status='error',error_message=? WHERE id=?")->execute([substr($api['error'],0,1000),$searchId]);
        return ['ok'=>false,'options'=>[],'search_id'=>$searchId,'cached'=>false,'error'=>$api['error']];
    }
    $options=[];
    foreach ((array)($api['data']['trains']??[]) as $row) {
        if (!is_array($row))continue;
        $o=tsRailRadarMapRouteRow($row,$from,$to,$date);if ($o===null)continue;
        $stmt=$pdo->prepare('INSERT INTO train_options(search_id,provider_option_id,train_number,train_name,origin_code,destination_code,departure_at,arrival_at,duration_minutes,travel_class,running_days,availability_text,currency,fare_amount,raw_json) VALUES(?,?,?,?,?,?,?,?,?,NULL,?,NULL,NULL,NULL,?)');
        $stmt->execute([$searchId,$o['train_number'],$o['train_number'],$o['train_name'],$from,$to,$o['departure_at'],$o['arrival_at'],$o['duration_minutes'],$o['running_days'],$o['raw_json']]);
        $o['id']=(int)$pdo->lastInsertId();$o['search_id']=$searchId;
        $options[]=$o;
    }
    $pdo->prepare("UPDATE train_searches SET response_status='success',error_message=NULL WHERE id=?")->execute([$searchId]);
    usort($options,static fn($a,$b)=>strcmp((string)$a['departure_at'],(string)$b['departure_at']));
    return ['ok'=>true,'options'=>$options,'search_id'=>$searchId,'cached'=>false,'error'=>''];
}

function tsRailRadarSelectTrain(PDO $pdo,int $optionId,array $ctx,int $adminId): int {
    $stmt=$pdo->prepare('SELECT o.*,s.enquiry_id,s.trip_id,s.package_id,s.journey_date FROM train_options o INNER JOIN train_searches s ON s.id=o.search_id WHERE o.id=? AND s.provider=\'railradar\' LIMIT 1');
    $stmt->execute([$optionId]);$o=$stmt->fetch(PDO::FETCH_ASSOC);
    if (!$o)throw new RuntimeException('This train option is no longer available. Search again.');
    $lead=max(0,(int)($ctx['enquiry_id']??0));$trip=max(0,(int)($ctx['trip_id']??0));$package=max(0,(int)($ctx['package_id']??0));
    // This protects against someone changing option_id in a POST to import a different trip's result.
    // A reused cached search may belong to a different context; the current explicitly selected route can be used only for this request.
    $expectedFrom=strtoupper(trim((string)($ctx['origin_code']??'')));$expectedTo=strtoupper(trim((string)($ctx['destination_code']??'')));
    $expectedDate=(string)($ctx['journey_date']??'');
    if ($expectedFrom!==$o['origin_code'] || $expectedTo!==$o['destination_code'] || $expectedDate!==$o['journey_date']) throw new RuntimeException('Train search context changed. Please search again.');
    if (!((int)$o['trip_id']===$trip && $trip>0) && !((int)$o['enquiry_id']===$lead && $lead>0)) {
        throw new RuntimeException('This result belongs to another quotation. Please run a new train search.');
    }
    $class=trim((string)($ctx['travel_class']??''));if (strlen($class)>30)throw new RuntimeException('Train class is too long.');
    $order=max(1,min(50,(int)($ctx['sector_order']??1)));
    $notes='RailRadar schedule suggestion; seat availability, class availability and fare have not been checked. No ticket has been booked.';
    $stmt=$pdo->prepare("INSERT INTO itinerary_trains(enquiry_id,trip_id,package_id,train_option_id,sector_order,origin_code,destination_code,journey_date,train_number,train_name,departure_at,arrival_at,duration_minutes,travel_class,running_days,availability_text,price_mode,display_fare,fare_amount,currency,status,preferred,notes,created_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'details_only',0,NULL,'INR','suggested',0,?,?)");
    $stmt->execute([$lead?:null,$trip?:null,$package?:null,$optionId,$order,$o['origin_code'],$o['destination_code'],$o['journey_date'],$o['train_number'],$o['train_name'],$o['departure_at'],$o['arrival_at'],$o['duration_minutes'],$class,$o['running_days'],'Not checked',$notes,$adminId?:null]);
    return (int)$pdo->lastInsertId();
}
