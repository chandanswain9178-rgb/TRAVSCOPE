<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — SYSTEM JOBS + CRON CONTROL
|--------------------------------------------------------------------------
|
| Tracks CLI jobs without executing them from the browser.
|
| Existing cron scripts continue to perform their original business work.
| This helper only adds:
| - run history
| - MySQL advisory overlap lock
| - last run / duration / exit code
| - stale detection
| - Admin notification escalation
|
| If the System Jobs SQL is not installed, the cron script is allowed to
| continue in its legacy untracked mode.
|
*/


function tsJobTableExists(
    PDO $pdo,
    string $table
): bool {
    static $cache = [];

    $key =
        strtolower($table);

    if (
        array_key_exists(
            $key,
            $cache
        )
    ) {
        return
            $cache[$key];
    }

    if (
        !preg_match(
            '/^[A-Za-z0-9_]+$/',
            $table
        )
    ) {
        return false;
    }

    try {
        $stmt =
            $pdo->prepare("
                SELECT COUNT(*)
                FROM information_schema.tables
                WHERE table_schema = DATABASE()
                  AND table_name = ?
            ");

        $stmt->execute([$table]);

        return
            $cache[$key] =
                (
                    (int)$stmt->fetchColumn()
                    > 0
                );

    } catch (Throwable $e) {
        return
            $cache[$key] =
                false;
    }
}


function tsJobReady(PDO $pdo): bool
{
    return
        tsJobTableExists(
            $pdo,
            'system_job_state'
        )
        && tsJobTableExists(
            $pdo,
            'system_job_runs'
        );
}


function tsJobCatalog(): array
{
    return [
        'communication_automation' => [
            'label' =>
                'Reminder + Communication Automation',

            'script' =>
                'communication-cron.php',

            'command' =>
                'php /FULL/PATH/communication-cron.php --run --all --limit=25',

            'expected_interval_minutes' =>
                15,

            'stale_after_minutes' =>
                45,
        ],

        'notification_sync' => [
            'label' =>
                'System Notifications + Escalation',

            'script' =>
                'notification-cron.php',

            'command' =>
                'php /FULL/PATH/notification-cron.php --email',

            'expected_interval_minutes' =>
                15,

            'stale_after_minutes' =>
                45,
        ],

        'health_scan' => [
            'label' =>
                'System Health Scan',

            'script' =>
                'health-cron.php',

            'command' =>
                'php /FULL/PATH/health-cron.php',

            'expected_interval_minutes' =>
                60,

            'stale_after_minutes' =>
                180,
        ],
    ];
}


function tsJobEnsureCatalog(
    PDO $pdo
): void {
    if (!tsJobReady($pdo)) {
        return;
    }

    $stmt =
        $pdo->prepare("
            INSERT INTO system_job_state
            (
                job_key,
                job_label,
                script_name,
                command_example,
                expected_interval_minutes,
                stale_after_minutes,
                is_enabled
            )
            VALUES (?, ?, ?, ?, ?, ?, 1)
            ON DUPLICATE KEY UPDATE
                job_label =
                    VALUES(job_label),
                script_name =
                    VALUES(script_name),
                command_example =
                    VALUES(command_example)
        ");

    foreach (
        tsJobCatalog()
        as $jobKey => $job
    ) {
        $stmt->execute([
            $jobKey,
            (string)$job['label'],
            (string)$job['script'],
            (string)$job['command'],
            (int)$job[
                'expected_interval_minutes'
            ],
            (int)$job[
                'stale_after_minutes'
            ],
        ]);
    }
}


function tsJobToken(): string
{
    $hex =
        bin2hex(
            random_bytes(16)
        );

    return
        substr($hex, 0, 8)
        . '-'
        . substr($hex, 8, 4)
        . '-'
        . substr($hex, 12, 4)
        . '-'
        . substr($hex, 16, 4)
        . '-'
        . substr($hex, 20, 12);
}


function tsJobLockName(
    string $jobKey
): string {
    return
        'travscope_job_'
        . substr(
            sha1($jobKey),
            0,
            40
        );
}


function tsJobAcquireMysqlLock(
    PDO $pdo,
    string $jobKey
): bool {
    try {
        $stmt =
            $pdo->prepare("
                SELECT GET_LOCK(?, 0)
            ");

        $stmt->execute([
            tsJobLockName($jobKey)
        ]);

        return
            (int)$stmt->fetchColumn()
            === 1;

    } catch (Throwable $e) {
        /*
        | If the DB engine does not support advisory locks,
        | do NOT prevent the existing cron business logic.
        */
        error_log(
            'TRAVSCOPE job advisory lock: '
            . $e->getMessage()
        );

        return true;
    }
}


function tsJobReleaseMysqlLock(
    PDO $pdo,
    string $jobKey
): void {
    try {
        $stmt =
            $pdo->prepare("
                SELECT RELEASE_LOCK(?)
            ");

        $stmt->execute([
            tsJobLockName($jobKey)
        ]);

    } catch (Throwable $e) {
        error_log(
            'TRAVSCOPE job advisory unlock: '
            . $e->getMessage()
        );
    }
}


function tsJobRecordSkipped(
    PDO $pdo,
    string $jobKey,
    string $reason,
    array $meta = [],
    int $exitCode = 4
): void {
    if (!tsJobReady($pdo)) {
        return;
    }

    $token =
        tsJobToken();

    try {
        $stmt =
            $pdo->prepare("
                INSERT INTO system_job_runs
                (
                    job_key,
                    run_token,
                    started_at,
                    finished_at,
                    status,
                    exit_code,
                    duration_ms,
                    summary,
                    meta_json
                )
                VALUES (
                    ?,
                    ?,
                    NOW(),
                    NOW(),
                    'skipped',
                    ?,
                    0,
                    ?,
                    ?
                )
            ");

        $stmt->execute([
            $jobKey,
            $token,
            $exitCode,
            mb_substr(
                $reason,
                0,
                1000
            ),
            $meta
                ? json_encode(
                    $meta,
                    JSON_UNESCAPED_UNICODE
                    | JSON_UNESCAPED_SLASHES
                )
                : null,
        ]);

    } catch (Throwable $e) {
        error_log(
            'TRAVSCOPE skipped job audit: '
            . $e->getMessage()
        );
    }
}


function tsJobBegin(
    PDO $pdo,
    string $jobKey,
    array $meta = []
): array {
    $context = [
        'tracked' => false,
        'acquired' => true,
        'disabled' => false,
        'job_key' => $jobKey,
        'run_id' => null,
        'token' => null,
        'started_at' =>
            microtime(true),
    ];

    if (!tsJobReady($pdo)) {
        return $context;
    }

    tsJobEnsureCatalog($pdo);

    try {
        $stmt =
            $pdo->prepare("
                SELECT
                    is_enabled
                FROM system_job_state
                WHERE job_key = ?
                LIMIT 1
            ");

        $stmt->execute([
            $jobKey
        ]);

        $enabled =
            (int)(
                $stmt->fetchColumn()
                ?: 0
            );

        if ($enabled !== 1) {
            $context['tracked'] =
                true;

            $context['disabled'] =
                true;

            tsJobRecordSkipped(
                $pdo,
                $jobKey,
                'Job disabled in System Jobs Control Center.',
                $meta,
                0
            );

            return $context;
        }

        $acquired =
            tsJobAcquireMysqlLock(
                $pdo,
                $jobKey
            );

        if (!$acquired) {
            $context['tracked'] =
                true;

            $context['acquired'] =
                false;

            tsJobRecordSkipped(
                $pdo,
                $jobKey,
                'Overlap prevented: another process currently owns the job lock.',
                $meta
            );

            return $context;
        }

        $token =
            tsJobToken();

        $stmt =
            $pdo->prepare("
                INSERT INTO system_job_runs
                (
                    job_key,
                    run_token,
                    started_at,
                    status,
                    meta_json
                )
                VALUES (
                    ?,
                    ?,
                    NOW(),
                    'running',
                    ?
                )
            ");

        $stmt->execute([
            $jobKey,
            $token,
            $meta
                ? json_encode(
                    $meta,
                    JSON_UNESCAPED_UNICODE
                    | JSON_UNESCAPED_SLASHES
                )
                : null,
        ]);

        $runId =
            (int)$pdo->lastInsertId();

        $pdo->prepare("
            UPDATE system_job_state
            SET
                running_token = ?,
                running_since = NOW(),
                last_started_at = NOW(),
                last_status = 'running',
                last_message = 'Job started.',
                last_meta_json = ?
            WHERE job_key = ?
        ")->execute([
            $token,
            $meta
                ? json_encode(
                    $meta,
                    JSON_UNESCAPED_UNICODE
                    | JSON_UNESCAPED_SLASHES
                )
                : null,
            $jobKey,
        ]);

        $context['tracked'] =
            true;

        $context['run_id'] =
            $runId;

        $context['token'] =
            $token;

        return $context;

    } catch (Throwable $e) {
        /*
        | Tracking failure must not break the original cron business process.
        */
        error_log(
            'TRAVSCOPE job begin tracking: '
            . $e->getMessage()
        );

        return $context;
    }
}


function tsJobFinish(
    PDO $pdo,
    array $context,
    string $status,
    int $exitCode,
    string $summary,
    array $meta = []
): void {
    $jobKey =
        (string)(
            $context['job_key']
            ?? ''
        );

    if (
        !in_array(
            $status,
            [
                'success',
                'warning',
                'failure',
                'skipped',
            ],
            true
        )
    ) {
        $status =
            'failure';
    }

    $durationMs =
        max(
            0,
            (int)round(
                (
                    microtime(true)
                    - (float)(
                        $context[
                            'started_at'
                        ]
                        ?? microtime(true)
                    )
                )
                * 1000
            )
        );

    if (
        !empty(
            $context['tracked']
        )
        && !empty(
            $context['run_id']
        )
        && tsJobReady($pdo)
    ) {
        try {
            $pdo->beginTransaction();

            $stmt =
                $pdo->prepare("
                    UPDATE system_job_runs
                    SET
                        finished_at = NOW(),
                        status = ?,
                        exit_code = ?,
                        duration_ms = ?,
                        summary = ?,
                        meta_json = ?
                    WHERE id = ?
                      AND run_token = ?
                ");

            $stmt->execute([
                $status,
                $exitCode,
                $durationMs,
                mb_substr(
                    $summary,
                    0,
                    1000
                ),
                $meta
                    ? json_encode(
                        $meta,
                        JSON_UNESCAPED_UNICODE
                        | JSON_UNESCAPED_SLASHES
                    )
                    : null,
                (int)$context['run_id'],
                (string)$context['token'],
            ]);

            $extra = '';

            if ($status === 'success') {
                $extra =
                    ', last_success_at = NOW()';

            } elseif (
                $status === 'warning'
            ) {
                $extra =
                    ', last_warning_at = NOW()';

            } elseif (
                $status === 'failure'
            ) {
                $extra =
                    ', last_failure_at = NOW()';
            }

            $stmt =
                $pdo->prepare("
                    UPDATE system_job_state
                    SET
                        running_token = NULL,
                        running_since = NULL,
                        last_finished_at = NOW(),
                        last_duration_ms = ?,
                        last_exit_code = ?,
                        last_status = ?,
                        last_message = ?,
                        last_meta_json = ?
                        {$extra}
                    WHERE job_key = ?
                      AND (
                            running_token = ?
                            OR running_token IS NULL
                          )
                ");

            $stmt->execute([
                $durationMs,
                $exitCode,
                $status,
                mb_substr(
                    $summary,
                    0,
                    1000
                ),
                $meta
                    ? json_encode(
                        $meta,
                        JSON_UNESCAPED_UNICODE
                        | JSON_UNESCAPED_SLASHES
                    )
                    : null,
                $jobKey,
                (string)$context['token'],
            ]);

            $pdo->commit();

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log(
                'TRAVSCOPE job finish tracking: '
                . $e->getMessage()
            );
        }
    }

    if (
        !empty(
            $context['acquired']
        )
        && $jobKey !== ''
    ) {
        tsJobReleaseMysqlLock(
            $pdo,
            $jobKey
        );
    }

    try {
        tsJobSyncAlerts($pdo);

    } catch (Throwable $e) {
        error_log(
            'TRAVSCOPE job alert sync: '
            . $e->getMessage()
        );
    }
}


function tsJobRows(PDO $pdo): array
{
    if (!tsJobReady($pdo)) {
        return [];
    }

    tsJobEnsureCatalog($pdo);

    try {
        $stmt =
            $pdo->query("
                SELECT
                    *,
                    TIMESTAMPDIFF(
                        MINUTE,
                        COALESCE(
                            last_finished_at,
                            updated_at
                        ),
                        NOW()
                    ) AS minutes_since_finish,

                    TIMESTAMPDIFF(
                        MINUTE,
                        running_since,
                        NOW()
                    ) AS running_minutes
                FROM system_job_state
                ORDER BY
                    FIELD(
                        job_key,
                        'communication_automation',
                        'notification_sync',
                        'health_scan'
                    ),
                    job_label ASC
            ");

        $rows =
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            )
            ?: [];

    } catch (Throwable $e) {
        return [];
    }

    foreach ($rows as &$row) {
        $enabled =
            (int)$row['is_enabled']
            === 1;

        $runningMinutes =
            $row['running_minutes']
            !== null
                ? (int)$row[
                    'running_minutes'
                ]
                : null;

        $minutesSince =
            (int)(
                $row[
                    'minutes_since_finish'
                ]
                ?? 0
            );

        $staleAfter =
            max(
                1,
                (int)$row[
                    'stale_after_minutes'
                ]
            );

        $isStaleRunning =
            $enabled
            && $runningMinutes !== null
            && $runningMinutes
                > $staleAfter;

        $isStale =
            $enabled
            && $row['last_status']
                !== 'never'
            && $row['last_status']
                !== 'running'
            && $minutesSince
                > $staleAfter;

        $neverStale =
            $enabled
            && $row['last_status']
                === 'never'
            && $minutesSince
                > $staleAfter;

        $row['is_stale_running'] =
            $isStaleRunning;

        $row['is_stale'] =
            $isStale
            || $neverStale;

        if (!$enabled) {
            $row['health'] =
                'disabled';

        } elseif ($isStaleRunning) {
            $row['health'] =
                'critical';

        } elseif (
            $row['is_stale']
        ) {
            $row['health'] =
                'stale';

        } elseif (
            (string)$row[
                'last_status'
            ] === 'failure'
        ) {
            $row['health'] =
                'failure';

        } elseif (
            (string)$row[
                'last_status'
            ] === 'warning'
        ) {
            $row['health'] =
                'warning';

        } elseif (
            (string)$row[
                'last_status'
            ] === 'success'
        ) {
            $row['health'] =
                'healthy';

        } elseif (
            (string)$row[
                'last_status'
            ] === 'running'
        ) {
            $row['health'] =
                'running';

        } else {
            $row['health'] =
                'never';
        }
    }

    unset($row);

    return $rows;
}


function tsJobRecentRuns(
    PDO $pdo,
    ?string $jobKey = null,
    int $limit = 100
): array {
    if (!tsJobReady($pdo)) {
        return [];
    }

    $limit =
        max(
            1,
            min(
                500,
                $limit
            )
        );

    try {
        if ($jobKey) {
            $stmt =
                $pdo->prepare("
                    SELECT *
                    FROM system_job_runs
                    WHERE job_key = ?
                    ORDER BY id DESC
                    LIMIT {$limit}
                ");

            $stmt->execute([
                $jobKey
            ]);

        } else {
            $stmt =
                $pdo->query("
                    SELECT *
                    FROM system_job_runs
                    ORDER BY id DESC
                    LIMIT {$limit}
                ");
        }

        return
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            )
            ?: [];

    } catch (Throwable $e) {
        return [];
    }
}


function tsJobSetPolicy(
    PDO $pdo,
    string $jobKey,
    bool $enabled,
    int $expectedMinutes,
    int $staleMinutes,
    int $adminId
): void {
    if (!tsJobReady($pdo)) {
        throw new RuntimeException(
            'System Jobs SQL is not installed.'
        );
    }

    if (
        function_exists(
            'tsAclRequire'
        )
    ) {
        tsAclRequire(
            $pdo,
            $adminId,
            'manage_access',
            'update_system_job_policy',
            'system_job',
            null,
            [
                'job_key' =>
                    $jobKey,
            ]
        );
    }

    if (
        !array_key_exists(
            $jobKey,
            tsJobCatalog()
        )
    ) {
        throw new RuntimeException(
            'Unknown System Job.'
        );
    }

    $expectedMinutes =
        max(
            1,
            min(
                1440,
                $expectedMinutes
            )
        );

    $staleMinutes =
        max(
            $expectedMinutes,
            min(
                10080,
                $staleMinutes
            )
        );

    $stmt =
        $pdo->prepare("
            UPDATE system_job_state
            SET
                is_enabled = ?,
                expected_interval_minutes = ?,
                stale_after_minutes = ?,
                updated_at = NOW()
            WHERE job_key = ?
        ");

    $stmt->execute([
        $enabled ? 1 : 0,
        $expectedMinutes,
        $staleMinutes,
        $jobKey,
    ]);
}


function tsJobAdminRecipients(
    PDO $pdo
): array {
    try {
        $stmt =
            $pdo->query("
                SELECT id
                FROM admins
                WHERE status = 'active'
                  AND role IN (
                        'admin',
                        'super_admin'
                      )
                ORDER BY id ASC
            ");

        return
            array_map(
                'intval',
                $stmt->fetchAll(
                    PDO::FETCH_COLUMN
                )
                ?: []
            );

    } catch (Throwable $e) {
        return [];
    }
}


function tsJobSyncAlerts(
    PDO $pdo
): void {
    if (!tsJobReady($pdo)) {
        return;
    }

    $notificationFile =
        __DIR__
        . '/notification-functions.php';

    if (
        is_file(
            $notificationFile
        )
        && !function_exists(
            'tsNotifyUpsert'
        )
    ) {
        require_once
            $notificationFile;
    }

    if (
        !function_exists(
            'tsNotifyReady'
        )
        || !tsNotifyReady($pdo)
        || !function_exists(
            'tsNotifyUpsert'
        )
        || !function_exists(
            'tsNotifyResolveSource'
        )
    ) {
        return;
    }

    $syncStartedAt =
        date(
            'Y-m-d H:i:s'
        );

    $recipients =
        tsJobAdminRecipients($pdo);

    if (!$recipients) {
        return;
    }

    foreach (
        tsJobRows($pdo)
        as $job
    ) {
        if (
            (int)$job[
                'is_enabled'
            ] !== 1
        ) {
            continue;
        }

        $health =
            (string)$job['health'];

        $severity = null;
        $level = 0;
        $message = '';

        if ($health === 'critical') {
            $severity =
                'critical';

            $level = 3;

            $message =
                'Job appears stuck/running longer than its stale threshold.';

        } elseif (
            $health === 'stale'
            || $health === 'never'
        ) {
            $severity =
                'high';

            $level = 2;

            $message =
                'Job has not completed within its configured stale threshold.';

        } elseif (
            $health === 'failure'
        ) {
            $severity =
                'high';

            $level = 2;

            $message =
                'Latest tracked job run failed.';

        } elseif (
            $health === 'warning'
        ) {
            $severity =
                'warning';

            $level = 1;

            $message =
                'Latest tracked job run completed with warnings.';
        }

        if ($severity === null) {
            continue;
        }

        $message .=
            ' Last status: '
            . (string)$job[
                'last_status'
            ]
            . '. Last message: '
            . (
                trim(
                    (string)(
                        $job[
                            'last_message'
                        ]
                        ?? ''
                    )
                )
                ?: '-'
            );

        foreach (
            $recipients
            as $adminId
        ) {
            tsNotifyUpsert(
                $pdo,
                $adminId,
                'system-job-'
                    . (string)$job[
                        'job_key'
                    ],
                'system_jobs',
                'system_job',
                $severity,
                $level,
                'System Job Alert · '
                    . (string)$job[
                        'job_label'
                    ],
                $message,
                'system_job',
                null,
                'admin-system-jobs.php',
                'system_job_state',
                null,
                null,
                [
                    'job_key' =>
                        (string)$job[
                            'job_key'
                        ],

                    'health' =>
                        $health,

                    'last_exit_code' =>
                        $job[
                            'last_exit_code'
                        ],

                    'stale_after_minutes' =>
                        (int)$job[
                            'stale_after_minutes'
                        ],
                ],
                $syncStartedAt
            );
        }
    }

    tsNotifyResolveSource(
        $pdo,
        'system_jobs',
        $syncStartedAt
    );
}
