<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/supplier-functions.php';
$accessControlFunctionsFile=__DIR__.'/access-control-functions.php';
if(is_file($accessControlFunctionsFile))require_once $accessControlFunctionsFile;

if (empty($_SESSION['admin_id'])) { header('Location: '.BASE_URL.'login.php'); exit; }

// Backward-compatible routing: a supplier request ID belongs to the detail workspace.
if (isset($_GET['id']) && (int)$_GET['id'] > 0 && empty($_GET['lead'])) {
    header('Location: admin-supplier-request-details.php?id='.(int)$_GET['id']);
    exit;
}
$adminId=(int)$_SESSION['admin_id'];
$stmt=$pdo->prepare("SELECT id,name,role,status FROM admins WHERE id=? LIMIT 1");
$stmt->execute([$adminId]); $admin=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$admin || ($admin['status']??'')!=='active'){unset($_SESSION['admin_id']);header('Location: '.BASE_URL.'login.php');exit;}
if(function_exists('tsAclRequire')){try{tsAclRequire($pdo,$adminId,'view_supplier_cost','view_supplier_requests_cost','supplier_request',null);}catch(RuntimeException $e){http_response_code(403);exit(htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8'));}}

if(empty($_SESSION['supplier_request_csrf'])) $_SESSION['supplier_request_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['supplier_request_csrf'];
$success=(string)($_SESSION['supplier_request_success']??'');
$error=(string)($_SESSION['supplier_request_error']??'');
unset($_SESSION['supplier_request_success'],$_SESSION['supplier_request_error']);

$leadId=max(0,(int)($_GET['lead']??$_POST['lead_id']??0));
$tripId=max(0,(int)($_GET['trip']??$_POST['trip_id']??0));
$serviceRequirementId=max(0,(int)($_GET['service']??$_POST['service_requirement_id']??0));
$lead=null; $latestVersion=null; $matchedDestinationId=null; $selectedServiceRequirement=null;
$tripContext=null; $sourcingPackageId=0;

/* V24.21: resolve the package/destination from the active Trip first. */
if($tripId>0){
    try{
        $stmt=$pdo->prepare("
            SELECT t.id,t.enquiry_id,t.package_id,t.destination_id,t.trip_title,t.travel_start_date,
                   p.destination_id AS package_destination_id,p.title AS package_title,p.package_code,
                   p.source_supplier_id,p.source_supplier_package_code
            FROM trips t
            LEFT JOIN packages p ON p.id=t.package_id
            WHERE t.id=? LIMIT 1
        ");
        $stmt->execute([$tripId]);
        $tripContext=$stmt->fetch(PDO::FETCH_ASSOC)?:null;
        if($tripContext){
            if($leadId<=0)$leadId=(int)($tripContext['enquiry_id']??0);
            $sourcingPackageId=max(0,(int)($tripContext['package_id']??0));
            $matchedDestinationId=!empty($tripContext['destination_id'])
                ? (int)$tripContext['destination_id']
                : (!empty($tripContext['package_destination_id'])?(int)$tripContext['package_destination_id']:null);
        }
    }catch(Throwable $ignored){}
}

if($leadId>0){
    $stmt=$pdo->prepare("
        SELECT
            e.*,
            m.assigned_admin_id,
            p.destination_id AS package_destination_id,
            d.name AS destination_master_name
        FROM enquiries e
        LEFT JOIN crm_lead_meta m ON m.enquiry_id=e.id
        LEFT JOIN packages p ON p.id=e.package_id
        LEFT JOIN destinations d ON d.id=e.destination_id
        WHERE e.id=?
        LIMIT 1
    ");
    $stmt->execute([$leadId]); $lead=$stmt->fetch(PDO::FETCH_ASSOC);
    if($lead){
        $stmt=$pdo->prepare("SELECT * FROM crm_package_versions WHERE lead_id=? ORDER BY version_number DESC,id DESC LIMIT 1");
        $stmt->execute([$leadId]); $latestVersion=$stmt->fetch(PDO::FETCH_ASSOC)?:null;
        /*
         * REAL DESTINATION RESOLUTION
         * Priority:
         * 1. enquiry.destination_id
         * 2. selected package.destination_id
         * 3. exact normalized legacy text match (backward compatibility only)
         *
         * Never use fuzzy LIKE matching here. Wrong spelling must not accidentally
         * select a supplier from another destination.
         */
        if(!$matchedDestinationId){
            $matchedDestinationId =
                !empty($lead['destination_id'])
                    ? (int)$lead['destination_id']
                    : (!empty($lead['package_destination_id'])
                        ? (int)$lead['package_destination_id']
                        : null);
        }
        if($sourcingPackageId<=0 && !empty($lead['package_id']))$sourcingPackageId=(int)$lead['package_id'];

        if (!$matchedDestinationId && !empty($lead['destination'])) {
            $legacyDestination=trim((string)$lead['destination']);
            $shortDestination=trim((string)preg_replace('/\s*,\s*[^,]+$/u','',$legacyDestination));
            $stmt=$pdo->prepare("
                SELECT id
                FROM destinations
                WHERE status='active'
                  AND (
                       LOWER(TRIM(name)) = LOWER(TRIM(?))
                    OR LOWER(TRIM(CONCAT(name, ', ', country))) = LOWER(TRIM(?))
                    OR LOWER(TRIM(name)) = LOWER(TRIM(?))
                  )
                ORDER BY CASE WHEN LOWER(TRIM(CONCAT(name, ', ', country)))=LOWER(TRIM(?)) THEN 1 ELSE 2 END,id
                LIMIT 1
            ");
            $stmt->execute([$legacyDestination,$legacyDestination,$shortDestination,$legacyDestination]);
            $matchedDestinationId=$stmt->fetchColumn() ?: null;
        }
    }
}

function buildSupplierRequirement(?array $lead, ?array $version): string {
    if(!$lead) return '';
    $rows=[];
    $rows[]='TRAVSCOPE SUPPLIER RATE REQUEST';
    $rows[]='Destination: '.((string)($lead['destination']??'') ?: '-');
    $rows[]='Travel Date: '.((string)($version['travel_date']??$lead['travel_date']??'') ?: '-');
    $rows[]='Travellers: '.(int)($version['adults']??$lead['adults']??0).' Adult(s) + '.(int)($version['children']??$lead['children']??0).' Child(ren)';
    if(!empty($version['package_title'])) $rows[]='Itinerary / Package: '.(string)$version['package_title'];
    if(!empty($version['hotel_category'])) $rows[]='Hotel Category: '.(int)$version['hotel_category'].' Star / Similar';
    if(!empty($version['itinerary'])) $rows[]="\nDAY-WISE ITINERARY\n".trim((string)$version['itinerary']);
    if(!empty($version['inclusions'])) $rows[]="\nINCLUSIONS\n".trim((string)$version['inclusions']);
    if(!empty($version['exclusions'])) $rows[]="\nEXCLUSIONS\n".trim((string)$version['exclusions']);
    if(!empty($lead['message'])) $rows[]="\nCUSTOMER REQUIREMENT\n".trim((string)$lead['message']);
    return implode("\n",$rows);
}

function buildSupplierServiceRequirement(array $service, array $lead): string {
    $labels=[
        'hotel'=>'Hotel','transport'=>'Transport / Vehicle','transfer'=>'Transfer',
        'activity'=>'Activity','sightseeing'=>'Sightseeing','flight'=>'Flight',
        'visa'=>'Visa','train'=>'Train','cruise'=>'Cruise','guide'=>'Guide',
        'insurance'=>'Travel Insurance','meal'=>'Meal / Supplement','other'=>'Other Service'
    ];
    $type=strtolower((string)($service['service_type']??'other'));
    $rows=['TRAVSCOPE SERVICE RATE REQUEST'];
    $rows[]='Service: '.($labels[$type]??ucwords(str_replace('_',' ',$type)));
    if(!empty($service['title']))$rows[]='Requirement: '.trim((string)$service['title']);
    if(!empty($service['destination_name']))$rows[]='Destination: '.trim((string)$service['destination_name']);
    elseif(!empty($lead['destination']))$rows[]='Destination: '.trim((string)$lead['destination']);
    if(!empty($service['service_date_from'])){
        $date=(string)$service['service_date_from'];
        if(!empty($service['service_date_to'])&&$service['service_date_to']!==$service['service_date_from'])$date.=' to '.$service['service_date_to'];
        $rows[]='Service Date: '.$date;
    }elseif(!empty($lead['travel_date']))$rows[]='Travel Date: '.(string)$lead['travel_date'];
    $rows[]='Travellers: '.(int)($service['adults']??$lead['adults']??0).' Adult(s) + '.(int)($service['children']??$lead['children']??0).' Child(ren)';
    if(!empty($service['specifications']))$rows[]="\nSERVICE SPECIFICATION\n".trim((string)$service['specifications']);
    $rows[]="\nPlease share your best NET supplier rate, GST/tax, availability, validity, inclusions/exclusions, payment terms and cancellation terms.";
    if(!empty($service['trip_code']))$rows[]='Trip Reference: '.(string)$service['trip_code'];
    return implode("\n",$rows);
}

if($lead && $serviceRequirementId>0){
    $stmt=$pdo->prepare("
        SELECT r.*,d.name destination_name,t.trip_code
        FROM trip_service_requirements r
        LEFT JOIN destinations d ON d.id=r.destination_id
        LEFT JOIN trips t ON t.id=r.trip_id
        WHERE r.id=? AND r.enquiry_id=?
        LIMIT 1
    ");
    $stmt->execute([$serviceRequirementId,$leadId]);
    $selectedServiceRequirement=$stmt->fetch(PDO::FETCH_ASSOC)?:null;
    if($selectedServiceRequirement){
        $tripId=(int)$selectedServiceRequirement['trip_id'];
        if(!empty($selectedServiceRequirement['destination_id']))$matchedDestinationId=(int)$selectedServiceRequirement['destination_id'];
    }else{
        $serviceRequirementId=0;
    }
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        if(!hash_equals($csrf,(string)($_POST['csrf']??''))) throw new RuntimeException('Security verification failed.');
        if(function_exists('tsAclRequire'))tsAclRequire($pdo,$adminId,'manage_supplier_procurement','manage_supplier_requests','supplier_request',null);
        $action=(string)($_POST['action']??'');


        if($action==='use_contract_rate'){
            if(!$lead)throw new RuntimeException('Open a valid enquiry first.');

            $postedServiceRequirementId=max(0,(int)($_POST['service_requirement_id']??0));
            $rateItemId=max(0,(int)($_POST['rate_item_id']??0));

            if($postedServiceRequirementId<=0||$rateItemId<=0){
                throw new RuntimeException('Select a valid Trip service and contract rate.');
            }

            $stmt=$pdo->prepare("
                SELECT r.*,d.name destination_name,d.country destination_country,t.trip_code
                FROM trip_service_requirements r
                LEFT JOIN destinations d ON d.id=r.destination_id
                LEFT JOIN trips t ON t.id=r.trip_id
                WHERE r.id=? AND r.enquiry_id=?
                LIMIT 1
            ");
            $stmt->execute([$postedServiceRequirementId,$leadId]);
            $rateService=$stmt->fetch(PDO::FETCH_ASSOC)?:null;

            if(!$rateService){
                throw new RuntimeException('The Trip service requirement was not found.');
            }

            $applied=
                tsSupplierApplyContractRate(
                    $pdo,
                    $rateItemId,
                    $rateService,
                    $adminId
                );

            $calc=(array)($applied['calculation']??[]);
            $rate=(array)($applied['rate']??[]);

            $_SESSION['supplier_request_success']=
                'Contract rate selected: '
                .(string)($rate['company_name']??'Supplier')
                .' · '
                .(string)($rate['contract_code']??'')
                .' · '
                .(string)($rate['currency']??'INR')
                .' '
                .number_format((float)($calc['supplier_total']??0),2)
                .' added to the Trip Cost Sheet.';

            header(
                'Location: admin-supplier-requests.php?lead='.$leadId
                .'&trip='.(int)$rateService['trip_id']
                .'&service='.$postedServiceRequirementId
            );
            exit;
        }

        if($action==='create_requests'){
            if(!$lead) throw new RuntimeException('Open a valid enquiry first.');
            $supplierIds=array_values(array_unique(array_filter(array_map('intval',(array)($_POST['supplier_ids']??[])))));
            if(!$supplierIds) throw new RuntimeException('Select at least one supplier.');

            $postedTripId=max(0,(int)($_POST['trip_id']??0));
            $postedServiceRequirementId=max(0,(int)($_POST['service_requirement_id']??0));
            $postedServiceRequirement=null;
            if($postedServiceRequirementId>0){
                $stmt=$pdo->prepare("
                    SELECT r.*,d.name destination_name,t.trip_code
                    FROM trip_service_requirements r
                    LEFT JOIN destinations d ON d.id=r.destination_id
                    LEFT JOIN trips t ON t.id=r.trip_id
                    WHERE r.id=? AND r.enquiry_id=?
                    LIMIT 1
                ");
                $stmt->execute([$postedServiceRequirementId,$leadId]);
                $postedServiceRequirement=$stmt->fetch(PDO::FETCH_ASSOC)?:null;
                if(!$postedServiceRequirement)throw new RuntimeException('Invalid Trip service requirement.');
                $postedTripId=(int)$postedServiceRequirement['trip_id'];
                if(!empty($postedServiceRequirement['destination_id']))$matchedDestinationId=(int)$postedServiceRequirement['destination_id'];
            }

            $requestType=(string)($_POST['request_type']??'quote_existing_itinerary');
            if(!in_array($requestType,['quote_existing_itinerary','create_itinerary','service_quote'],true)) $requestType='quote_existing_itinerary';
            if($postedServiceRequirement)$requestType='service_quote';
            $channel=(string)($_POST['channel']??'email');
            if(!in_array($channel,['email','whatsapp','phone','manual'],true)) $channel='email';
            $subject=trim((string)($_POST['subject']??''));
            $requirement=trim((string)($_POST['requirement_text']??''));
            $special=trim((string)($_POST['special_requirements']??''));
            $reminderHours=max(0,(int)($_POST['reminder_hours']??2));
            if($subject==='')$subject=$postedServiceRequirement
                ? 'Travscope Service Rate Request - '.(string)$postedServiceRequirement['title']
                : 'Travscope Supplier Rate Request - '.((string)$lead['destination'] ?: 'Travel');
            if($postedServiceRequirement && $requirement==='')$requirement=buildSupplierServiceRequirement($postedServiceRequirement,$lead);
            if($requirement==='') throw new RuntimeException('Supplier requirement cannot be empty.');

            $group=tsSupplierRequestGroupCode($pdo);
            $pdo->beginTransaction();
            $created=[];
            foreach($supplierIds as $supplierId){
                $stmt=$pdo->prepare("SELECT * FROM suppliers WHERE id=? AND status='active' LIMIT 1");
                $stmt->execute([$supplierId]); $supplier=$stmt->fetch(PDO::FETCH_ASSOC);
                if(!$supplier) continue;
                $contact=tsSupplierPrimaryContact($pdo,$supplierId);
                $code=tsSupplierRequestCode($pdo);
                $reminder=$reminderHours>0 ? date('Y-m-d H:i:s',time()+$reminderHours*3600) : null;
                $stmt=$pdo->prepare("
                    INSERT INTO supplier_requests
                    (request_code,request_group_code,enquiry_id,trip_id,service_requirement_id,
                     supplier_id,supplier_contact_id,request_type,destination_id,
                     subject,requirement_text,special_requirements,channel,status,reminder_due_at,assigned_admin_id,
                     created_by_admin_id,updated_by_admin_id)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ");
                $stmt->execute([
                    $code,$group,$leadId,$postedTripId?:null,$postedServiceRequirementId?:null,
                    $supplierId,$contact['id']??null,$requestType,$matchedDestinationId,
                    $subject,$requirement,$special?:null,$channel,'draft',$reminder,
                    (int)($lead['assigned_admin_id']??0)?:$adminId,$adminId,$adminId
                ]);
                $rid=(int)$pdo->lastInsertId();
                tsSupplierEvent($pdo,$rid,'created',$adminId,'Supplier request created.',$channel);
                tsSupplierMessage($pdo,$rid,'admin',$adminId,$requirement.($special ? "\n\nSpecial Requirements:\n".$special : ''),$channel);
                $created[]=['id'=>$rid,'supplier'=>$supplier,'contact'=>$contact];
            }
            if($postedServiceRequirementId>0 && $created){
                $pdo->prepare("UPDATE trip_service_requirements SET status='sourcing',updated_at=NOW() WHERE id=?")
                    ->execute([$postedServiceRequirementId]);
            }
            $pdo->commit();

            $sent=0; $failed=0;
            if($channel==='email'){
                foreach($created as $row){
                    $stmt=$pdo->prepare("SELECT * FROM supplier_requests WHERE id=?");
                    $stmt->execute([$row['id']]); $request=$stmt->fetch(PDO::FETCH_ASSOC);
                    $result=tsSupplierEmail($pdo,$request,$row['supplier'],$row['contact']);
                    if($result['ok']){
                        $pdo->prepare("UPDATE supplier_requests SET status='awaiting_response',sent_at=NOW(),updated_by_admin_id=? WHERE id=?")->execute([$adminId,$row['id']]);
                        tsSupplierEvent($pdo,$row['id'],'sent',$adminId,'Supplier request sent by email.','email');
                        $sent++;
                    } else {
                        tsSupplierEvent($pdo,$row['id'],'send_failed',$adminId,$result['message'],'email');
                        $failed++;
                    }
                }
            }
            $_SESSION['supplier_request_success']=count($created).' supplier request(s) created'.($channel==='email' ? "; {$sent} emailed".($failed?"; {$failed} need manual action":'') : '.');
            header('Location: admin-supplier-requests.php?lead='.$leadId.($postedTripId?'&trip='.$postedTripId:'').($postedServiceRequirementId?'&service='.$postedServiceRequirementId:''));exit;
        }

        if($action==='send_email'){
            $requestId=max(0,(int)($_POST['request_id']??0));
            $stmt=$pdo->prepare("SELECT r.*,s.company_name FROM supplier_requests r JOIN suppliers s ON s.id=r.supplier_id WHERE r.id=?");
            $stmt->execute([$requestId]); $request=$stmt->fetch(PDO::FETCH_ASSOC);
            if(!$request) throw new RuntimeException('Supplier request not found.');
            $stmt=$pdo->prepare("SELECT * FROM suppliers WHERE id=?");$stmt->execute([(int)$request['supplier_id']]);$supplier=$stmt->fetch(PDO::FETCH_ASSOC);
            $contact=tsSupplierPrimaryContact($pdo,(int)$request['supplier_id']);
            $result=tsSupplierEmail($pdo,$request,$supplier,$contact);
            if(!$result['ok']) throw new RuntimeException($result['message']);
            $pdo->prepare("UPDATE supplier_requests SET channel='email',status='awaiting_response',sent_at=COALESCE(sent_at,NOW()),updated_by_admin_id=? WHERE id=?")->execute([$adminId,$requestId]);
            tsSupplierEvent($pdo,$requestId,'sent',$adminId,'Supplier request sent by email.','email');
            $_SESSION['supplier_request_success']='Supplier email sent.';
            header('Location: admin-supplier-requests.php?lead='.(int)$request['enquiry_id']);exit;
        }

        if($action==='mark_sent'){
            $requestId=max(0,(int)($_POST['request_id']??0));
            $channel=(string)($_POST['channel']??'manual');
            if(!in_array($channel,['whatsapp','phone','manual'],true))$channel='manual';
            $pdo->prepare("UPDATE supplier_requests SET channel=?,status='awaiting_response',sent_at=COALESCE(sent_at,NOW()),updated_by_admin_id=? WHERE id=?")->execute([$channel,$adminId,$requestId]);
            tsSupplierEvent($pdo,$requestId,'sent',$adminId,'Request marked sent via '.ucfirst($channel).'.',$channel);
            $_SESSION['supplier_request_success']='Request marked as sent.';
            header('Location: admin-supplier-requests.php?lead='.$leadId);exit;
        }

        if($action==='send_reminder'){
            $requestId=max(0,(int)($_POST['request_id']??0));
            $stmt=$pdo->prepare("SELECT r.*,s.company_name FROM supplier_requests r JOIN suppliers s ON s.id=r.supplier_id WHERE r.id=?");
            $stmt->execute([$requestId]);$request=$stmt->fetch(PDO::FETCH_ASSOC);
            if(!$request)throw new RuntimeException('Request not found.');
            $stmt=$pdo->prepare("SELECT * FROM suppliers WHERE id=?");$stmt->execute([(int)$request['supplier_id']]);$supplier=$stmt->fetch(PDO::FETCH_ASSOC);
            $contact=tsSupplierPrimaryContact($pdo,(int)$request['supplier_id']);
            $request['subject']='Reminder: '.$request['subject'];
            $request['requirement_text']="Dear Partner,\n\nJust following up on our supplier request ".$request['request_code'].". Kindly share your current quote at the earliest.\n\n".$request['requirement_text'];
            $result=tsSupplierEmail($pdo,$request,$supplier,$contact);
            if(!$result['ok'])throw new RuntimeException($result['message']);
            $pdo->prepare("UPDATE supplier_requests SET status='reminder_sent',last_reminder_at=NOW(),reminder_due_at=DATE_ADD(NOW(),INTERVAL 2 HOUR),updated_by_admin_id=? WHERE id=?")->execute([$adminId,$requestId]);
            tsSupplierEvent($pdo,$requestId,'reminder_sent',$adminId,'Supplier reminder sent by email.','email');
            $_SESSION['supplier_request_success']='Supplier reminder sent.';
            header('Location: admin-supplier-requests.php?lead='.(int)$request['enquiry_id']);exit;
        }
    }catch(Throwable $e){
        if($pdo->inTransaction())$pdo->rollBack();
        $_SESSION['supplier_request_error']=$e->getMessage();
        header('Location: admin-supplier-requests.php'.($leadId?'?lead='.$leadId:''));exit;
    }
}

$params=[];$where=[];
if($leadId>0){$where[]='r.enquiry_id=?';$params[]=$leadId;}
$statusFilter=trim((string)($_GET['status']??''));
if($statusFilter!==''){$where[]='r.status=?';$params[]=$statusFilter;}
$whereSql=$where?'WHERE '.implode(' AND ',$where):'';

$stmt=$pdo->prepare("
SELECT r.*,s.company_name,s.priority,
       c.contact_name,c.email contact_email,c.whatsapp contact_whatsapp,c.mobile contact_mobile,
       q.version_number latest_quote_version,q.total_supplier_cost,q.currency quote_currency,q.id quote_id,
       tsr.service_type linked_service_type,tsr.title linked_service_title,tsr.status linked_service_status,t.trip_code
FROM supplier_requests r
JOIN suppliers s ON s.id=r.supplier_id
LEFT JOIN supplier_contacts c ON c.id=r.supplier_contact_id
LEFT JOIN supplier_quotes q ON q.id=(SELECT q2.id FROM supplier_quotes q2 WHERE q2.supplier_request_id=r.id ORDER BY q2.version_number DESC,q2.id DESC LIMIT 1)
LEFT JOIN trip_service_requirements tsr ON tsr.id=r.service_requirement_id
LEFT JOIN trips t ON t.id=r.trip_id
{$whereSql}
ORDER BY r.created_at DESC,r.id DESC
");
$stmt->execute($params);$requests=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];

$suppliers=[];
if($lead){
    /*
     * Package-linked supplier first, then exact destination-mapped suppliers.
     * This is important for old enquiries where enquiry.package_id and
     * enquiry.destination_id were never populated, but the Trip has them.
     */
    try{
        $params=[];$conditions=[];
        if($sourcingPackageId>0){
            $conditions[]="EXISTS(SELECT 1 FROM package_supplier_options pso WHERE pso.package_id=? AND pso.supplier_id=s.id AND pso.status='active' AND pso.enabled_for_quotation=1)";
            $params[]=$sourcingPackageId;
        }
        if($matchedDestinationId){
            $conditions[]="EXISTS(SELECT 1 FROM supplier_destinations sd WHERE sd.supplier_id=s.id AND sd.destination_id=?)";
            $params[]=(int)$matchedDestinationId;
        }
        if($conditions){
            $matchedPackageExpr=$sourcingPackageId>0
                ? "EXISTS(SELECT 1 FROM package_supplier_options pso2 WHERE pso2.package_id=".(int)$sourcingPackageId." AND pso2.supplier_id=s.id AND pso2.status='active' AND pso2.enabled_for_quotation=1)"
                : '0';
            $matchedDestinationExpr=$matchedDestinationId
                ? "EXISTS(SELECT 1 FROM supplier_destinations sd2 WHERE sd2.supplier_id=s.id AND sd2.destination_id=".(int)$matchedDestinationId.")"
                : '0';
            $sql="SELECT DISTINCT s.*, {$matchedPackageExpr} AS matched_package, {$matchedDestinationExpr} AS matched_destination,
                         c.contact_name,c.email,c.whatsapp,c.mobile
                  FROM suppliers s
                  LEFT JOIN supplier_contacts c ON c.id=(
                      SELECT c2.id FROM supplier_contacts c2
                      WHERE c2.supplier_id=s.id AND c2.status='active'
                      ORDER BY c2.is_primary DESC,
                               CASE c2.department WHEN 'Sales' THEN 1 WHEN 'Operations' THEN 2 ELSE 3 END,
                               c2.id ASC LIMIT 1
                  )
                  WHERE s.status='active' AND (".implode(' OR ',$conditions).")
                  ORDER BY matched_package DESC,matched_destination DESC,
                           CASE s.priority WHEN 'preferred' THEN 1 WHEN 'regular' THEN 2 ELSE 3 END,
                           s.company_name ASC";
            $stmt=$pdo->prepare($sql);$stmt->execute($params);
            $suppliers=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
        }
    }catch(Throwable $ignored){$suppliers=[];}
}
$requirement=$selectedServiceRequirement?buildSupplierServiceRequirement($selectedServiceRequirement,$lead?:[]):buildSupplierRequirement($lead,$latestVersion);

$requestCount=count($requests);
$quoteCount=0;$awaitingCount=0;$overdueCount=0;
foreach($requests as $rqRow){
    if(!empty($rqRow['quote_id'])) $quoteCount++;
    if(empty($rqRow['first_response_at']) && in_array((string)($rqRow['status']??''),['sent','awaiting_response','reminder_sent'],true)) $awaitingCount++;
    if(empty($rqRow['first_response_at']) && !empty($rqRow['reminder_due_at']) && strtotime((string)$rqRow['reminder_due_at'])<time()) $overdueCount++;
}
$packageDisplayTitle=trim((string)($tripContext['package_title']??$latestVersion['package_title']??''));
$packageDisplayCode=trim((string)($tripContext['package_code']??''));
$destinationDisplay=trim((string)($lead['destination_master_name']??$lead['destination']??''));
$travelDisplay=trim((string)($tripContext['travel_start_date']??$latestVersion['travel_date']??$lead['travel_date']??''));
$adultDisplay=(int)($latestVersion['adults']??$lead['adults']??0);
$childDisplay=(int)($latestVersion['children']??$lead['children']??0);

$contractRateMatches=[];
if($selectedServiceRequirement && function_exists('tsSupplierFindContractRates')){
    $contractRateMatches=
        tsSupplierFindContractRates(
            $pdo,
            $selectedServiceRequirement
        );
}
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Supplier Requests | TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f5f7fb;color:#172033;font-family:Arial,sans-serif}.page{max-width:1500px;margin:auto;padding:26px}.top{display:flex;justify-content:space-between;gap:16px;align-items:start;margin-bottom:18px}.top h1{margin:0}.top p{color:#718096}.btn{display:inline-flex;gap:7px;align-items:center;border:0;border-radius:10px;padding:10px 13px;text-decoration:none;cursor:pointer;font-weight:700}.primary{background:#0b74ff;color:#fff}.soft{background:#edf4ff;color:#175fae}.dark{background:#07192d;color:#fff}.warn{background:#fff6df;color:#8b6500}.panel{background:#fff;border:1px solid #e4e9f0;border-radius:16px;padding:18px;margin-bottom:16px;box-shadow:0 6px 24px rgba(7,25,45,.04)}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.full{grid-column:1/-1}.field label{display:block;font-size:12px;font-weight:800;margin-bottom:6px}.input,select,textarea{width:100%;border:1px solid #d8e0ea;border-radius:10px;padding:10px;font:inherit;background:#fff}textarea{min-height:150px}.supplier-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.supplier-option{display:block;border:1px solid #dfe6ee;border-radius:12px;padding:12px}.supplier-option.match{border-color:#9cc3ff;background:#f6faff}.supplier-option small{display:block;color:#748095;margin-top:5px}.badge{display:inline-flex;padding:5px 8px;border-radius:999px;background:#eef4fb;font-size:11px;font-weight:800}.good{background:#e9f8ef;color:#17663e}.alert{padding:12px 14px;border-radius:10px;margin-bottom:14px}.ok{background:#e9f8ef;color:#17663e}.err{background:#fff0f0;color:#a23030}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;min-width:1100px}th,td{padding:12px 10px;border-bottom:1px solid #edf1f5;text-align:left;font-size:13px;vertical-align:top}th{color:#69768a;font-size:12px}.actions{display:flex;gap:6px;flex-wrap:wrap}.muted{color:#7a8798}.overdue{color:#b33131;font-weight:800}@media(max-width:900px){.grid,.supplier-grid{grid-template-columns:1fr}.full{grid-column:auto}.top{display:block}}
.rate-engine{border:1px solid #bbf7d0;background:#f0fdf4}.rate-engine-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.rate-engine-head h2{margin:0;color:#166534}.rate-engine-head p{margin:5px 0 0;color:#4b5563;font-size:12px}.rate-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:13px}.rate-choice{border:1px solid #d1fae5;border-radius:13px;padding:12px;background:#fff}.rate-choice-top{display:flex;justify-content:space-between;gap:10px}.rate-choice h3{margin:0;font-size:13px}.rate-choice small{display:block;color:#64748b;margin-top:4px;font-size:10px;line-height:1.45}.rate-choice .money{font-size:18px;font-weight:900;color:#047857;white-space:nowrap}.rate-badges{display:flex;gap:5px;flex-wrap:wrap;margin:8px 0}.rate-badges span{font-size:9px;font-weight:900;padding:4px 7px;border-radius:999px;background:#ecfdf5;color:#047857}.rate-badges .verify{background:#fff7ed;color:#c2410c}.rate-formula{padding:7px 8px;border-radius:9px;background:#f8fafc;color:#475569;font-size:9px}.no-rate{margin-top:12px;padding:10px 11px;border:1px dashed #cbd5e1;border-radius:11px;color:#64748b;font-size:11px;background:#fff}
@media(max-width:900px){.rate-grid{grid-template-columns:1fr}}
.request-cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.request-card{border:1px solid #e2e8f0;border-radius:14px;padding:14px;background:#fff}.request-card-head{display:flex;justify-content:space-between;gap:10px}.request-card h3{margin:0 0 4px;font-size:15px}.request-meta{color:#64748b;font-size:12px}.request-status{display:inline-flex;padding:5px 9px;border-radius:999px;background:#eef2ff;color:#4338ca;font-size:10px;font-weight:900}.request-cost{font-size:18px;font-weight:900;margin:9px 0}.request-actions{display:flex;gap:7px;flex-wrap:wrap}.create-rfq{border:1px solid #dbeafe;border-radius:15px;background:#f8fbff;overflow:hidden;margin-bottom:16px}.create-rfq>summary{padding:14px 16px;cursor:pointer;font-size:16px;font-weight:900;color:#1d4ed8;list-style:none}.create-rfq>summary::-webkit-details-marker{display:none}.create-rfq[open]>summary{border-bottom:1px solid #dbeafe;background:#eff6ff}.create-rfq-body{padding:16px}@media(max-width:900px){.request-cards{grid-template-columns:1fr}}

/* V24.25 Supplier RFQ workspace: CRM-grade page-body redesign. Sidebar/topbar stay unchanged. */
.rfq-shell{max-width:1540px;margin:0 auto}.rfq-hero{position:relative;overflow:hidden;border:1px solid #d9e5f5;border-radius:18px;background:linear-gradient(135deg,#ffffff 0%,#f7fbff 68%,#eef8ff 100%);box-shadow:0 10px 28px rgba(15,42,76,.07);margin-bottom:16px}.rfq-hero:before{content:"";position:absolute;left:0;top:0;bottom:0;width:5px;background:linear-gradient(180deg,#2563eb,#06b6d4)}.rfq-hero-main{display:flex;justify-content:space-between;gap:18px;align-items:center;padding:20px 22px 16px}.rfq-eyebrow{font-size:10px;font-weight:900;letter-spacing:.12em;color:#2563eb;text-transform:uppercase;margin-bottom:6px}.rfq-hero h1{margin:0;color:#102a4f;font-size:28px;line-height:1.1}.rfq-hero-sub{margin:6px 0 0;color:#64748b;font-size:13px}.rfq-hero-actions{display:flex;gap:9px;flex-wrap:wrap;justify-content:flex-end}.rfq-hero-actions .btn{min-height:40px;padding:0 14px;border-radius:11px;box-shadow:0 6px 14px rgba(15,23,42,.07)}
.rfq-workflow{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;padding:0 18px 18px}.rfq-step{display:flex;align-items:center;gap:9px;padding:11px 12px;border:1px solid #dbe5f0;border-radius:12px;background:#fff;min-width:0}.rfq-step-num{width:28px;height:28px;border-radius:9px;display:grid;place-items:center;background:#e2e8f0;color:#475569;font-size:12px;font-weight:900;flex:0 0 auto}.rfq-step strong{display:block;color:#1e293b;font-size:11px}.rfq-step small{display:block;color:#64748b;font-size:9px;margin-top:2px}.rfq-step.done{background:#ecfdf5;border-color:#a7f3d0}.rfq-step.done .rfq-step-num{background:#10b981;color:white}.rfq-step.active{background:#eff6ff;border-color:#93c5fd;box-shadow:inset 0 0 0 1px #60a5fa}.rfq-step.active .rfq-step-num{background:#2563eb;color:white}.rfq-step.future{background:#f8fafc}
.rfq-overview{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:16px}.rfq-overview-card{border:1px solid #e2e8f0;border-radius:15px;background:#fff;padding:14px 15px;box-shadow:0 7px 20px rgba(15,23,42,.045);position:relative;overflow:hidden}.rfq-overview-card:before{content:"";position:absolute;left:0;right:0;top:0;height:3px}.rfq-overview-card.customer:before{background:#2563eb}.rfq-overview-card.package:before{background:#7c3aed}.rfq-overview-card.supplier:before{background:#f59e0b}.rfq-overview-card.status:before{background:#10b981}.rfq-overview-title{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:9px}.rfq-overview-title span{font-size:9px;font-weight:900;color:#64748b;text-transform:uppercase;letter-spacing:.06em}.rfq-overview-icon{width:30px;height:30px;border-radius:9px;display:grid;place-items:center;color:#fff;font-size:12px}.customer .rfq-overview-icon{background:#2563eb}.package .rfq-overview-icon{background:#7c3aed}.supplier .rfq-overview-icon{background:#f59e0b}.status .rfq-overview-icon{background:#10b981}.rfq-overview-card h3{margin:0 0 9px;color:#0f2f5a;font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rfq-facts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}.rfq-fact{padding:7px 8px;border-radius:9px;background:#f8fafc;min-width:0}.rfq-fact small{display:block;color:#94a3b8;font-size:8px;font-weight:800;text-transform:uppercase}.rfq-fact b{display:block;color:#334155;font-size:10px;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rfq-builder{border:1px solid #dbe5f0;border-radius:17px;background:#fff;box-shadow:0 10px 26px rgba(15,23,42,.055);overflow:hidden;margin-bottom:16px}.rfq-builder-head{display:flex;align-items:center;justify-content:space-between;gap:15px;padding:15px 17px;border-bottom:1px solid #e2e8f0;background:linear-gradient(135deg,#f8fbff,#ffffff)}.rfq-builder-head-left{display:flex;gap:12px;align-items:center}.rfq-builder-head-icon{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:linear-gradient(135deg,#2563eb,#4f46e5);color:#fff;font-size:17px;box-shadow:0 7px 18px rgba(37,99,235,.22)}.rfq-builder-head strong{display:block;color:#102a4f;font-size:16px}.rfq-builder-head small{display:block;color:#64748b;font-size:11px;margin-top:3px}.rfq-builder-body{padding:16px}.rfq-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.rfq-field-card{border:1px solid #dbe5f0;border-radius:14px;padding:12px;background:#fff}.rfq-field-card.blue{background:#f5f9ff;border-color:#bfdbfe}.rfq-field-card.violet{background:#faf7ff;border-color:#ddd6fe}.rfq-field-card.amber{background:#fffbf3;border-color:#fed7aa}.rfq-field-card.rose{background:#fff7f8;border-color:#fecdd3}.rfq-field-card.cyan{background:#f2fdff;border-color:#a5f3fc}.rfq-field-card.green{background:#f3fdf8;border-color:#bbf7d0}.rfq-field-head{display:flex;align-items:flex-start;gap:9px;margin-bottom:8px}.rfq-field-icon{width:31px;height:31px;border-radius:9px;display:grid;place-items:center;color:#fff;font-size:12px;flex:0 0 auto}.blue .rfq-field-icon{background:#2563eb}.violet .rfq-field-icon{background:#7c3aed}.amber .rfq-field-icon{background:#f59e0b}.rose .rfq-field-icon{background:#e11d48}.cyan .rfq-field-icon{background:#0891b2}.green .rfq-field-icon{background:#10b981}.rfq-field-head label{margin:0;color:#1e293b;font-size:11px;font-weight:900}.rfq-field-head small{display:block;color:#64748b;font-size:9px;line-height:1.35;margin-top:2px}.rfq-field-card input,.rfq-field-card select,.rfq-field-card textarea{background:rgba(255,255,255,.94);border:1px solid #cbd5e1;border-radius:10px;box-shadow:0 1px 2px rgba(15,23,42,.02)}.rfq-field-card textarea{min-height:170px;line-height:1.48}.rfq-field-card.full{grid-column:1/-1}
.rfq-supplier-section{margin-top:14px;border-top:1px solid #e2e8f0;padding-top:14px}.rfq-section-head{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:10px}.rfq-section-head h3{margin:0;color:#102a4f;font-size:14px}.rfq-section-head span{color:#64748b;font-size:10px}.supplier-grid{grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.supplier-option{position:relative;padding:13px 13px 13px 42px;border-radius:13px;box-shadow:0 4px 12px rgba(15,23,42,.035);transition:.16s ease;background:#fff}.supplier-option:hover{transform:translateY(-1px);border-color:#93c5fd;box-shadow:0 8px 18px rgba(37,99,235,.08)}.supplier-option input{position:absolute;left:13px;top:15px;width:17px;height:17px;accent-color:#2563eb}.supplier-option.match{background:#f0fdf4;border-color:#86efac}.supplier-option strong{font-size:12px;color:#0f2f5a}.supplier-option small{font-size:10px;line-height:1.4}.rfq-send-row{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:14px;padding:12px 13px;border-radius:12px;background:#f8fafc;border:1px solid #e2e8f0}.rfq-send-row small{color:#64748b;font-size:10px}.rfq-send-row .btn.primary{background:linear-gradient(135deg,#2563eb,#4f46e5);padding:11px 16px;box-shadow:0 8px 18px rgba(37,99,235,.18)}
.create-rfq{border:0;background:transparent;margin-bottom:0;overflow:visible}.create-rfq>summary{display:none}.create-rfq-body{padding:0}.create-rfq-cta,.panel-intro{display:none}.grid.form-grid{display:contents}.field-help{display:none}
.rfq-history{border:1px solid #dbe5f0;border-radius:17px;background:#fff;box-shadow:0 9px 24px rgba(15,23,42,.045);padding:16px}.rfq-history-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px}.rfq-history-head h2{margin:0;color:#102a4f;font-size:17px}.rfq-history-head p{margin:3px 0 0;color:#64748b;font-size:10px}.request-cards{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.request-card{border-radius:13px;box-shadow:0 5px 15px rgba(15,23,42,.035);border-color:#e2e8f0}.request-card-head h3{color:#102a4f}.request-cost{color:#0f766e}.request-actions .btn{font-size:10px;padding:8px 10px;border-radius:9px}
@media(max-width:1150px){.rfq-workflow{grid-template-columns:repeat(3,minmax(0,1fr))}.rfq-overview{grid-template-columns:repeat(2,minmax(0,1fr))}.supplier-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:760px){.page{padding:14px}.rfq-hero-main{align-items:flex-start;flex-direction:column}.rfq-hero-actions{justify-content:flex-start}.rfq-workflow,.rfq-overview,.rfq-form-grid,.supplier-grid,.request-cards{grid-template-columns:1fr}.rfq-field-card.full{grid-column:auto}.rfq-send-row{align-items:stretch;flex-direction:column}.rfq-send-row .btn{justify-content:center}.rfq-hero h1{font-size:23px}}


/* V24.70 International RFQ Directory */
.page{max-width:none;padding:18px 20px}.rfq-shell{max-width:none}.rfq-hero{border-radius:16px;margin-bottom:10px}.rfq-hero-main{padding:14px 16px 12px}.rfq-eyebrow{font-size:9px;margin-bottom:4px}.rfq-hero h1{font-size:23px}.rfq-hero-sub{font-size:11px;margin-top:4px}.rfq-hero-actions .btn{min-height:34px;padding:0 11px;font-size:10px}.rfq-hero-kpis{display:flex;gap:6px;flex-wrap:wrap;margin-top:9px}.rfq-kpi{display:inline-flex;align-items:center;gap:6px;background:#fff;border:1px solid #dbe6f2;border-radius:999px;padding:5px 8px;box-shadow:0 2px 8px rgba(15,42,76,.035)}.rfq-kpi span{font-size:7px;font-weight:900;text-transform:uppercase;letter-spacing:.04em;color:#64748b}.rfq-kpi b{font-size:12px;color:#102a4f}.rfq-kpi.alert b{color:#b42318}.rfq-process{border-top:1px solid #e6edf5}.rfq-process>summary{list-style:none;cursor:pointer;padding:8px 16px;font-size:9px;font-weight:900;color:#315f88;display:flex;align-items:center;gap:7px}.rfq-process>summary::-webkit-details-marker{display:none}.rfq-process>summary:after{content:"+";margin-left:auto;color:#2563eb;font-size:14px}.rfq-process[open]>summary:after{content:"−"}.rfq-process .rfq-workflow{padding:0 12px 12px;gap:6px}.rfq-process .rfq-step{padding:8px 9px}.rfq-process .rfq-step-num{width:24px;height:24px;border-radius:7px}.rfq-overview{gap:8px;margin-bottom:10px}.rfq-overview-card{padding:10px 11px;border-radius:12px}.rfq-overview-card h3{font-size:13px;margin-bottom:6px}.rfq-overview-icon{width:26px;height:26px}.rfq-fact{padding:5px 6px}.rfq-builder,.rfq-history{border-radius:14px}.rfq-history{padding:12px}.rfq-history-head{margin-bottom:8px}.rfq-history-head h2{font-size:15px}.request-cards{display:flex;flex-direction:column;gap:6px}.request-card{display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:11px;min-height:64px}.request-card-head{min-width:240px;flex:1}.request-card-head h3{font-size:12px;margin-bottom:2px}.request-card>.request-meta{min-width:120px;font-size:10px}.request-status{padding:4px 7px;font-size:8px}.request-cost{min-width:165px;margin:0;font-size:13px}.request-actions{margin-left:auto;justify-content:flex-end;flex:0 0 auto}.request-actions .btn{padding:7px 8px;font-size:9px}.create-rfq-body{padding:12px}.rfq-form-grid{gap:8px}.rfq-field-card{padding:10px}.rfq-field-card textarea{min-height:120px}.supplier-option{padding-top:10px;padding-bottom:10px}.rfq-send-row{margin-top:10px;padding:9px 10px}@media(max-width:1050px){.request-card{flex-wrap:wrap}.request-card-head{min-width:55%}.request-actions{width:100%;justify-content:flex-start;margin-left:0}.request-cost{margin-left:auto}}@media(max-width:760px){.page{padding:12px}.rfq-hero-main{padding:13px}.rfq-hero-kpis{display:grid;grid-template-columns:1fr 1fr}.rfq-kpi{justify-content:space-between}.request-card{display:block}.request-card-head,.request-card>.request-meta,.request-cost{min-width:0;margin:0 0 7px}.request-actions{width:auto}}

</style>
<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
<link rel="stylesheet" href="assets/crm-laptop-workspaces-v2498.css?v=2498">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head><body><div class="page"><div class="rfq-shell">
<?php if($success):?><div class="alert ok"><i class="fa-solid fa-circle-check"></i> <?=tsSupE($success)?></div><?php endif;?>
<?php if($error):?><div class="alert err"><i class="fa-solid fa-triangle-exclamation"></i> <?=tsSupE($error)?></div><?php endif;?>
<section class="rfq-hero"><div class="rfq-hero-main"><div><div class="rfq-eyebrow">Supplier Sourcing Workspace</div><h1>Supplier Requests & RFQ</h1><p class="rfq-hero-sub"><?php if($lead):?>#ENQ<?=str_pad((string)$leadId,5,'0',STR_PAD_LEFT)?> · <?=tsSupE((string)($lead['name']??''))?> · <?=tsSupE($destinationDisplay ?: 'Destination not set')?><?= $travelDisplay ? ' · '.tsSupE($travelDisplay) : '' ?><?php else:?>Create, send, track and compare supplier quotation requests in one compact workspace.<?php endif;?></p><div class="rfq-hero-kpis"><span class="rfq-kpi"><span>Requests</span><b><?=$requestCount?></b></span><span class="rfq-kpi"><span>Quotes</span><b><?=$quoteCount?></b></span><span class="rfq-kpi"><span>Awaiting</span><b><?=$awaitingCount?></b></span><span class="rfq-kpi <?=$overdueCount>0?'alert':''?>"><span>Overdue</span><b><?=$overdueCount?></b></span><?php if($lead):?><span class="rfq-kpi"><span>Matched Suppliers</span><b><?=count($suppliers)?></b></span><?php endif;?></div></div><div class="rfq-hero-actions"><?php if($lead):?><a class="btn soft" href="admin-crm.php?lead=<?=$leadId?><?= $tripId ? '&trip='.$tripId : '' ?>"><i class="fa-solid fa-arrow-left"></i> Back to Quotation</a><?php endif;?><a class="btn soft" href="admin-suppliers.php"><i class="fa-solid fa-building"></i> Supplier Master</a><?php if($lead):?><a class="btn dark" href="admin-supplier-compare.php?lead=<?=$leadId?>"><i class="fa-solid fa-scale-balanced"></i> Compare Quotes</a><?php endif;?></div></div><details class="rfq-process"><summary><i class="fa-solid fa-route"></i> RFQ workflow — requirement → package → supplier → follow-up → compare</summary><div class="rfq-workflow"><div class="rfq-step <?=$lead?'done':'future'?>"><span class="rfq-step-num">1</span><div><strong>Customer Requirement</strong><small>Enquiry & travel details</small></div></div><div class="rfq-step <?=$sourcingPackageId>0?'done':'active'?>"><span class="rfq-step-num">2</span><div><strong>Package & Supplier</strong><small>Package link / destination</small></div></div><div class="rfq-step <?=($requestCount>0)?'done':'active'?>"><span class="rfq-step-num">3</span><div><strong>Build RFQ</strong><small>Requirement & communication</small></div></div><div class="rfq-step <?=($requestCount>0)?'done':'future'?>"><span class="rfq-step-num">4</span><div><strong>Send & Follow-up</strong><small>Supplier communication</small></div></div><div class="rfq-step <?=($quoteCount>0)?'active':'future'?>"><span class="rfq-step-num">5</span><div><strong>Compare & Select</strong><small>Final supplier costing</small></div></div></div></details></section>
<?php if($lead):?><section class="rfq-overview"><article class="rfq-overview-card customer"><div class="rfq-overview-title"><span>Customer Requirement</span><i class="rfq-overview-icon fa-solid fa-user"></i></div><h3><?=tsSupE((string)($lead['name']??'Customer'))?></h3><div class="rfq-facts"><div class="rfq-fact"><small>Destination</small><b><?=tsSupE($destinationDisplay ?: '—')?></b></div><div class="rfq-fact"><small>Travellers</small><b><?=$adultDisplay?> Adults + <?=$childDisplay?> Child<?= $childDisplay===1?'':'ren' ?></b></div></div></article><article class="rfq-overview-card package"><div class="rfq-overview-title"><span>Selected Package</span><i class="rfq-overview-icon fa-solid fa-suitcase-rolling"></i></div><h3><?=tsSupE($packageDisplayTitle ?: 'No Package Master selected')?></h3><div class="rfq-facts"><div class="rfq-fact"><small>Package Code</small><b><?=tsSupE($packageDisplayCode ?: '—')?></b></div><div class="rfq-fact"><small>Travel Date</small><b><?=tsSupE($travelDisplay ?: '—')?></b></div></div></article><article class="rfq-overview-card supplier"><div class="rfq-overview-title"><span>Supplier Sourcing</span><i class="rfq-overview-icon fa-solid fa-handshake"></i></div><h3><?=count($suppliers)?> Supplier<?=count($suppliers)===1?'':'s'?> Available</h3><div class="rfq-facts"><div class="rfq-fact"><small>Package Link</small><b><?=$sourcingPackageId>0?'Resolved':'Not linked'?></b></div><div class="rfq-fact"><small>Destination Map</small><b><?=$matchedDestinationId?'Matched':'Check mapping'?></b></div></div></article><article class="rfq-overview-card status"><div class="rfq-overview-title"><span>RFQ Progress</span><i class="rfq-overview-icon fa-solid fa-paper-plane"></i></div><h3><?=$requestCount?> Request<?= $requestCount===1?'':'s' ?> · <?=$quoteCount?> Quote<?= $quoteCount===1?'':'s' ?></h3><div class="rfq-facts"><div class="rfq-fact"><small>Status</small><b><?=$quoteCount>0?'Quotes received':($requestCount>0?'Awaiting supplier':'Ready to send')?></b></div><div class="rfq-fact"><small>Next Action</small><b><?=$quoteCount>0?'Compare quote':'Send / follow-up'?></b></div></div></article></section><?php endif;?>
<?php if($lead && $selectedServiceRequirement):?>
<div class="panel rate-engine">
<div class="rate-engine-head">
<div>
<h2><i class="fa-solid fa-tags"></i> Check Contract / Predefined Rate First</h2>
<p>Travscope searches active supplier contracts by exact service, destination, travel date and PAX. A rate becomes authoritative only after Admin clicks <strong>Use in Cost Sheet</strong>.</p>
</div>
<span class="badge good"><?=count($contractRateMatches)?> match<?=count($contractRateMatches)===1?'':'es'?></span>
</div>

<?php if($contractRateMatches):?>
<div class="rate-grid">
<?php foreach($contractRateMatches as $match):
    $calc=(array)($match['calculation']??[]);
?>
<div class="rate-choice">
<div class="rate-choice-top">
<div>
<h3><?=tsSupE((string)$match['company_name'])?></h3>
<small><?=tsSupE((string)$match['contract_code'])?> · <?=tsSupE((string)$match['rate_title'])?></small>
<small><?=tsSupE((string)$match['rate_name'])?> · <?=tsSupE(tsSupplierRateUnitBases()[(string)$match['unit_basis']]??(string)$match['unit_basis'])?></small>
</div>
<div class="money"><?=tsSupE((string)$match['currency'])?> <?=number_format((float)($calc['supplier_total']??0),2)?></div>
</div>

<div class="rate-badges">
<span><?=tsSupE(ucwords(str_replace('_',' ',(string)$match['availability_status'])))?></span>
<?php if(!empty($match['confirmation_required'])):?><span class="verify">CONFIRMATION REQUIRED</span><?php endif;?>
<?php if(!empty($match['nationality_rule'])):?><span class="verify">VERIFY NATIONALITY</span><?php endif;?>
<?php if(!empty($match['blackout_dates'])):?><span class="verify">CHECK BLACKOUT</span><?php endif;?>
</div>

<div class="rate-formula">
Base <?=number_format((float)($calc['base_cost']??0),2)?>
<?php if((float)($calc['tax_amount']??0)>0):?> + Tax <?=number_format((float)$calc['tax_amount'],2)?><?php endif;?>
<?php if((float)($calc['supplement_amount']??0)>0):?> + Supplement <?=number_format((float)$calc['supplement_amount'],2)?><?php endif;?>
· <?=tsSupE((string)($calc['formula']??''))?>
</div>

<form method="post" style="margin-top:9px">
<input type="hidden" name="csrf" value="<?=tsSupE($csrf)?>">
<input type="hidden" name="action" value="use_contract_rate">
<input type="hidden" name="lead_id" value="<?=$leadId?>">
<input type="hidden" name="trip_id" value="<?=$tripId?>">
<input type="hidden" name="service_requirement_id" value="<?=$serviceRequirementId?>">
<input type="hidden" name="rate_item_id" value="<?=(int)$match['rate_item_id']?>">
<button class="btn primary" type="submit"><i class="fa-solid fa-check"></i> Use in Cost Sheet</button>
<a class="btn soft" href="admin-supplier-details.php?id=<?=(int)$match['supplier_id']?>#contracts-rates"><i class="fa-solid fa-file-contract"></i> View Contract</a>
</form>
</div>
<?php endforeach;?>
</div>
<?php else:?>
<div class="no-rate">
<strong>No applicable predefined rate found.</strong>
Send a fresh RFQ below. You can later save the negotiated supplier rate into Supplier 360 → Contracts & Predefined Rates.
</div>
<?php endif;?>
</div>
<?php endif;?>

<?php if($lead):?>
<section class="rfq-builder">
<div class="rfq-builder-head"><div class="rfq-builder-head-left"><div class="rfq-builder-head-icon"><i class="fa-solid fa-paper-plane"></i></div><div><strong>Build & Send Supplier RFQ</strong><small>Confirm the requirement, choose the communication channel and select the correct supplier(s).</small></div></div><span class="badge good"><i class="fa-solid fa-circle-check"></i>&nbsp; Structured sourcing</span></div>
<div class="rfq-builder-body">
<details class="create-rfq" open>
<summary>RFQ Form</summary>
<div class="create-rfq-body">
<div class="create-rfq-cta"><div><strong>Ready to send a supplier request?</strong><small>Fill the professional RFQ form below. Clear information helps suppliers respond faster with accurate costing.</small></div><span class="badge good"><i class="fa-solid fa-check"></i>&nbsp; Structured supplier communication</span></div>
<form method="post">
<input type="hidden" name="csrf" value="<?=tsSupE($csrf)?>"><input type="hidden" name="action" value="create_requests"><input type="hidden" name="lead_id" value="<?=$leadId?>">
<input type="hidden" name="trip_id" value="<?=$tripId?>"><input type="hidden" name="service_requirement_id" value="<?=$serviceRequirementId?>">
<?php if($selectedServiceRequirement):?><div style="padding:11px 12px;margin-bottom:12px;border:1px solid #fed7aa;border-radius:11px;background:#fff7ed;color:#9a3412"><strong><i class="fa-solid fa-link"></i> Exact Trip Service: <?=tsSupE((string)$selectedServiceRequirement['title'])?></strong><div style="font-size:11px;margin-top:3px"><?=tsSupE(ucwords(str_replace('_',' ',(string)$selectedServiceRequirement['service_type'])))?> · <?=tsSupE((string)($selectedServiceRequirement['trip_code']??''))?></div></div><?php endif;?>
<div class="panel-intro">Use this form to create a clear, readable supplier request. Keep the subject concise, verify the itinerary/requirement content, mention any upgrade requests, then choose one or more suppliers below.</div>
<div class="rfq-form-grid">
<div class="rfq-field-card blue"><div class="rfq-field-head"><span class="rfq-field-icon"><i class="fa-solid fa-list-check"></i></span><div><label>Request Type</label><small>Choose what you want the supplier to quote.</small></div></div><select name="request_type" <?=$selectedServiceRequirement?'disabled':''?>><option value="quote_existing_itinerary">Quote Existing Itinerary</option><option value="create_itinerary">Create New Itinerary + Quote</option><option value="service_quote" <?=$selectedServiceRequirement?'selected':''?>>Quote Exact Trip Service</option></select><?php if($selectedServiceRequirement):?><input type="hidden" name="request_type" value="service_quote"><?php endif;?></div>
<div class="rfq-field-card violet"><div class="rfq-field-head"><span class="rfq-field-icon"><i class="fa-solid fa-share-nodes"></i></span><div><label>Send / Record Channel</label><small>Email, WhatsApp, phone or manual communication.</small></div></div><select name="channel"><option value="email">Email — send automatically</option><option value="whatsapp">WhatsApp — create request, open WhatsApp manually</option><option value="phone">Phone — create request, call supplier</option><option value="manual">Manual / Other</option></select></div>
<div class="rfq-field-card green full"><div class="rfq-field-head"><span class="rfq-field-icon"><i class="fa-solid fa-heading"></i></span><div><label>RFQ Subject</label><small>Clear subject line visible to the supplier.</small></div></div><input class="input" name="subject" value="<?=tsSupE('Travscope Supplier Rate Request - '.((string)$lead['destination']))?>"></div>
<div class="rfq-field-card amber full"><div class="rfq-field-head"><span class="rfq-field-icon"><i class="fa-solid fa-file-lines"></i></span><div><label>Requirement Sent to Supplier</label><small>Main itinerary, dates, travellers and service requirement. Review before sending.</small></div></div><textarea name="requirement_text"><?=tsSupE($requirement)?></textarea></div>
<div class="rfq-field-card rose full"><div class="rfq-field-head"><span class="rfq-field-icon"><i class="fa-solid fa-star"></i></span><div><label>Special Requirements / Upgrades</label><small>Optional upgrades, special handling or extra supplier instructions.</small></div></div><textarea name="special_requirements" placeholder="Example: Standard vehicle is Sedan. Customer requests Innova Crysta. Please quote upgrade supplement separately. Hotel upgrade / room upgrade / meal upgrade can also be written here."></textarea></div>
<div class="rfq-field-card cyan"><div class="rfq-field-head"><span class="rfq-field-icon"><i class="fa-solid fa-clock"></i></span><div><label>Reminder After</label><small>Set the supplier follow-up due time.</small></div></div><select name="reminder_hours"><option value="1">1 Hour</option><option value="2" selected>2 Hours</option><option value="4">4 Hours</option><option value="24">Tomorrow / 24 Hours</option><option value="0">No Automatic Due Time</option></select></div>
</div>

<div class="rfq-supplier-section"><div class="rfq-section-head"><div><h3><i class="fa-solid fa-building-user"></i> Select Supplier(s)</h3><span>Choose one or more matched suppliers to receive this quotation request.</span></div><span class="badge"><?=count($suppliers)?> available</span></div>
<?php if($sourcingPackageId>0):?><div style="margin:-4px 0 10px;padding:9px 11px;border-radius:9px;background:#ecfdf5;color:#047857;font-size:11px"><i class="fa-solid fa-link"></i> Supplier choices are prioritised from the Package Master selected in this Trip<?php if($matchedDestinationId):?> and its destination mapping<?php endif;?>.</div><?php endif;?>
<?php if(!$suppliers):?>
<p class="muted">
No active supplier is available for the selected Package Master / destination.
Please check <strong>Package Supplier Map</strong> for the package selected in this quotation, or map the supplier under <strong>Supplier Master → Destinations</strong>.
</p>
<?php endif;?>
<div class="supplier-grid">
<?php foreach($suppliers as $s):?>
<label class="supplier-option <?=$s['matched_destination']?'match':''?>">
<input type="checkbox" name="supplier_ids[]" value="<?=(int)$s['id']?>">
<strong><?=tsSupE((string)$s['company_name'])?></strong>
<?php if(!empty($s['matched_package'])):?><span class="request-status" style="margin-left:6px;background:#dcfce7;color:#047857">PACKAGE LINKED</span><?php elseif(!empty($s['matched_destination'])):?><span class="request-status" style="margin-left:6px;background:#dbeafe;color:#1d4ed8">DESTINATION MATCH</span><?php endif;?>
<small><?=tsSupE(ucfirst((string)$s['priority']))?> · <?=tsSupE((string)($s['contact_name']?:'No contact'))?></small>
<small><?=tsSupE((string)($s['email']?:$s['whatsapp']?:$s['mobile']?:'No communication detail'))?></small>
</label>
<?php endforeach;?>
</div>
<div class="rfq-send-row"><small><i class="fa-solid fa-circle-info"></i> TRAVSCOPE creates one supplier conversation per selected supplier and keeps each quote history separate.</small><button class="btn primary"><i class="fa-solid fa-paper-plane"></i> Create / Send RFQ</button></div>
</div>
</form>
</div>
</details></div></section>
<?php endif;?>

<section class="rfq-history"><div class="rfq-history-head"><div><h2><?= $lead ? 'Supplier Responses & Quote Tracking' : 'All Supplier Requests' ?></h2><p>Each supplier has one conversation and quote history. Open a card to review responses, quote versions and reminders.</p></div><?php if($lead):?><a class="btn soft" href="admin-supplier-compare.php?lead=<?=$leadId?>"><i class="fa-solid fa-scale-balanced"></i> Compare Quotes</a><?php endif;?></div>
<div class="request-cards">
<?php if(!$requests):?><div class="request-card"><strong>No supplier requests yet.</strong><div class="request-meta" style="margin-top:5px">Send an RFQ above to start supplier sourcing.</div></div><?php endif;?>
<?php foreach($requests as $r):
    $waiting=''; if(!empty($r['sent_at']) && empty($r['first_response_at'])){$seconds=max(0,time()-strtotime((string)$r['sent_at']));$waiting=floor($seconds/3600).'h '.floor(($seconds%3600)/60).'m waiting';}
    $isOverdue=!empty($r['reminder_due_at']) && strtotime((string)$r['reminder_due_at'])<time() && empty($r['first_response_at']);
?>
<div class="request-card"><div class="request-card-head"><div><h3><?=tsSupE((string)$r['company_name'])?></h3><div class="request-meta"><?=tsSupE((string)$r['request_code'])?> · <?=tsSupE((string)($r['contact_name']?:'No contact'))?></div></div><span class="request-status"><?=tsSupE(ucwords(str_replace('_',' ',(string)$r['status'])))?></span></div>
<?php if(!empty($r['linked_service_title'])):?><div style="display:inline-flex;margin-top:8px;padding:4px 7px;border-radius:999px;background:#fff7ed;color:#c2410c;font-size:9px;font-weight:900"><i class="fa-solid fa-link"></i>&nbsp; <?=tsSupE((string)$r['linked_service_title'])?></div><?php endif;?>
<div class="request-meta" style="margin-top:9px"><strong><?=tsSupE(ucfirst((string)$r['channel']))?></strong> · <?=tsSupE((string)($r['sent_at']?:'Not sent yet'))?></div>
<?php if($waiting):?><div class="request-meta <?=$isOverdue?'overdue':''?>" style="margin-top:5px"><?=tsSupE($waiting)?><?=$isOverdue?' · Reminder due':''?></div><?php endif;?>
<div class="request-cost"><?php if($r['quote_id']):?>Quote V<?=(int)$r['latest_quote_version']?> · <?=tsSupE((string)$r['quote_currency'])?> <?=number_format((float)$r['total_supplier_cost'],2)?><?php else:?>No quote received yet<?php endif;?></div>
<div class="request-actions"><a class="btn primary" href="admin-supplier-request-details.php?id=<?=(int)$r['id']?>"><i class="fa-solid fa-comments"></i> Conversation & Quotes</a><?php if(!empty($r['contact_email'])):?><form method="post"><input type="hidden" name="csrf" value="<?=tsSupE($csrf)?>"><input type="hidden" name="action" value="send_email"><input type="hidden" name="request_id" value="<?=(int)$r['id']?>"><input type="hidden" name="lead_id" value="<?=(int)$r['enquiry_id']?>"><button class="btn soft"><i class="fa-solid fa-envelope"></i> Email</button></form><?php endif;?><?php $wa=tsSupplierWhatsappNumber((string)($r['contact_whatsapp']?:$r['contact_mobile'])); if($wa):?><a target="_blank" class="btn soft" href="https://wa.me/<?=tsSupE($wa)?>?text=<?=rawurlencode((string)$r['requirement_text']."\n\nReference: ".$r['request_code'])?>"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a><?php endif;?><?php if(in_array($r['status'],['awaiting_response','reminder_sent','sent'],true)):?><form method="post"><input type="hidden" name="csrf" value="<?=tsSupE($csrf)?>"><input type="hidden" name="action" value="send_reminder"><input type="hidden" name="request_id" value="<?=(int)$r['id']?>"><input type="hidden" name="lead_id" value="<?=(int)$r['enquiry_id']?>"><button class="btn warn"><i class="fa-solid fa-bell"></i> Reminder</button></form><?php endif;?></div></div>
<?php endforeach;?>
</div></section>
</div></div>
<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
<script src="assets/crm-laptop-workspaces-v2498.js?v=2498" defer></script>
</body></html>
