<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE STEP 10 - PACKAGE SERVICES AUTOMATION
|--------------------------------------------------------------------------
| Shared helpers for Package Service Templates -> CRM Trip Requirements ->
| mapped Supplier draft sourcing requests. Nothing is sent automatically.
|--------------------------------------------------------------------------
*/

if (!function_exists('tsPackageServicesTableExists')) {
function tsPackageServicesTableExists(PDO $pdo, string $table = 'package_services'): bool
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
        $stmt->execute([$table]);
        return (int)$stmt->fetchColumn() > 0;
    } catch (Throwable $e) {
        return false;
    }
}
}

function tsPackageServiceTypes(): array
{
    return [
        'hotel' => 'Hotel',
        'transport' => 'Transport / Vehicle',
        'transfer' => 'Transfer',
        'sightseeing' => 'Sightseeing',
        'activity' => 'Activity / Ticket',
        'meal' => 'Meal / Supplement',
        'guide' => 'Guide / Tour Escort',
        'flight' => 'Flight',
        'train' => 'Train',
        'visa' => 'Visa',
        'insurance' => 'Travel Insurance',
        'cruise' => 'Cruise',
        'other' => 'Other Service',
    ];
}

function tsPackageServiceLabel(string $type): string
{
    $type = strtolower(trim($type));
    return tsPackageServiceTypes()[$type] ?? ucwords(str_replace('_', ' ', $type ?: 'Other'));
}

function tsPackageServiceSupplierCode(string $type): string
{
    return match (strtolower(trim($type))) {
        'transfer' => 'airport_transfer',
        'insurance' => 'travel_insurance',
        default => strtolower(trim($type)),
    };
}

function tsPackageQuantityBases(): array
{
    return [
        'fixed' => 'Fixed Quantity',
        'per_person' => 'Per Traveller',
        'per_adult' => 'Per Adult',
        'per_child' => 'Per Child',
        'per_room' => 'Per Room',
        'per_night' => 'Per Night',
    ];
}

function tsPackagePreferredSupplier(PDO $pdo, string $serviceType, ?int $destinationId = null): ?array
{
    if (!tsPackageServicesTableExists($pdo, 'suppliers') || !tsPackageServicesTableExists($pdo, 'supplier_services') || !tsPackageServicesTableExists($pdo, 'supplier_service_types')) {
        return null;
    }

    $code = tsPackageServiceSupplierCode($serviceType);

    $sql = "
        SELECT s.id, s.company_name, s.priority, s.internal_rating,
               ss.is_preferred AS service_preferred,
               COALESCE(sd.is_preferred,0) AS destination_preferred
        FROM suppliers s
        JOIN supplier_services ss ON ss.supplier_id=s.id
        JOIN supplier_service_types st ON st.id=ss.service_type_id AND st.service_code=? AND st.active=1
        LEFT JOIN supplier_destinations sd ON sd.supplier_id=s.id AND sd.destination_id=?
        WHERE s.status='active'
          AND (? IS NULL OR sd.destination_id IS NOT NULL OR NOT EXISTS (
                SELECT 1 FROM supplier_destinations x WHERE x.supplier_id=s.id
          ))
        ORDER BY
            COALESCE(sd.is_preferred,0) DESC,
            ss.is_preferred DESC,
            CASE s.priority WHEN 'preferred' THEN 1 WHEN 'regular' THEN 2 ELSE 3 END,
            COALESCE(s.internal_rating,0) DESC,
            s.id ASC
        LIMIT 1
    ";

    try {
        $stmt = $pdo->prepare($sql);
        $dest = ($destinationId ?? 0) > 0 ? (int)$destinationId : null;
        $stmt->execute([$code, $dest, $dest]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        error_log('Package preferred supplier lookup: ' . $e->getMessage());
        return null;
    }
}

function tsPackageServiceExtractMatchingLines(string $text, array $needles, int $maxChars = 1800): string
{
    $text = trim($text);
    if ($text === '') return '';
    $lines = preg_split('/\R+/u', $text) ?: [];
    $matches = [];
    foreach ($lines as $line) {
        $line = trim((string)$line, " \t\n\r\0\x0B•-*–—");
        if ($line === '') continue;
        $lower = mb_strtolower($line);
        foreach ($needles as $needle) {
            if (mb_strpos($lower, mb_strtolower($needle)) !== false) {
                $matches[] = $line;
                break;
            }
        }
    }
    $out = implode("\n", array_values(array_unique($matches)));
    return mb_substr($out, 0, $maxChars);
}

function tsPackageAutoBuildServices(PDO $pdo, int $packageId, int $adminId = 0): array
{
    $result = ['added'=>0,'mapped'=>0,'warnings'=>[]];
    if ($packageId <= 0 || !tsPackageServicesTableExists($pdo, 'package_services')) {
        $result['warnings'][] = 'Step 10 package_services table is not installed.';
        return $result;
    }

    $stmt = $pdo->prepare("SELECT * FROM packages WHERE id=? LIMIT 1");
    $stmt->execute([$packageId]);
    $package = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$package) {
        $result['warnings'][] = 'Package not found.';
        return $result;
    }

    $destinationId = !empty($package['destination_id']) ? (int)$package['destination_id'] : null;
    $durationDays = max(1, (int)($package['duration_days'] ?? 1));
    $durationNights = max(0, (int)($package['duration_nights'] ?? max(0,$durationDays-1)));

    $existingStmt = $pdo->prepare("SELECT id,service_type,title,source_package_hotel_id,hotel_star_category,preferred_supplier_id FROM package_services WHERE package_id=?");
    $existingStmt->execute([$packageId]);
    $existing = $existingStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $existsHotel = [];
    $existsType = [];
    foreach ($existing as $row) {
        if (!empty($row['source_package_hotel_id'])) $existsHotel[(int)$row['source_package_hotel_id']] = true;
        $existsType[strtolower((string)$row['service_type'])] = true;
    }

    $insert = $pdo->prepare("
        INSERT INTO package_services
        (package_id,service_type,title,destination_id,source_package_hotel_id,hotel_star_category,
         preferred_supplier_id,service_day_from,service_day_to,quantity,quantity_basis,service_mode,
         specifications,auto_create_requirement,auto_prepare_supplier_request,sort_order,status,
         created_by_admin_id,updated_by_admin_id)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'active',?,?)
    ");

    $sort = (int)$pdo->query("SELECT COALESCE(MAX(sort_order),0) FROM package_services WHERE package_id=".(int)$packageId)->fetchColumn();

    // Hotel rows come from the verified Package Hotel assignments (Step 06).
    if (tsPackageServicesTableExists($pdo, 'package_hotels')) {
        try {
            $hs = $pdo->prepare("SELECT * FROM package_hotels WHERE package_id=? ORDER BY star_category,id");
            $hs->execute([$packageId]);
            foreach ($hs->fetchAll(PDO::FETCH_ASSOC) ?: [] as $hotel) {
                $sourceHotelId = (int)$hotel['id'];
                if (isset($existsHotel[$sourceHotelId])) continue;
                $supplierId = !empty($hotel['supplier_id']) ? (int)$hotel['supplier_id'] : 0;
                if ($supplierId <= 0) {
                    $preferred = tsPackagePreferredSupplier($pdo, 'hotel', $destinationId);
                    $supplierId = (int)($preferred['id'] ?? 0);
                }
                $spec = [];
                if (!empty($hotel['hotel_name_snapshot'])) $spec[] = 'Hotel: '.$hotel['hotel_name_snapshot'];
                if (!empty($hotel['room_type'])) $spec[] = 'Room Type: '.$hotel['room_type'];
                if (!empty($hotel['meal_plan'])) $spec[] = 'Meal Plan: '.$hotel['meal_plan'];
                if ((int)($hotel['nights'] ?? 0) > 0) $spec[] = 'Nights: '.(int)$hotel['nights'];
                $insert->execute([
                    $packageId,'hotel','Hotel – '.(string)$hotel['hotel_name_snapshot'],
                    !empty($hotel['destination_id']) ? (int)$hotel['destination_id'] : $destinationId,
                    $sourceHotelId,(int)$hotel['star_category'],$supplierId>0?$supplierId:null,
                    1,$durationDays,1,'per_room','included',implode("\n",$spec),1,$supplierId>0?1:0,++$sort,
                    $adminId>0?$adminId:null,$adminId>0?$adminId:null
                ]);
                $result['added']++;
                if ($supplierId > 0) $result['mapped']++;
            }
        } catch (Throwable $e) {
            $result['warnings'][] = 'Hotel services could not be auto-built: '.$e->getMessage();
        }
    }

    $inclusions = (string)($package['inclusions'] ?? '');
    $rules = [
        'transport' => ['vehicle','transport','sedan','innova','tempo traveller','coach','car'],
        'transfer' => ['airport transfer','airport pickup','airport pick-up','airport drop','arrival transfer','departure transfer','pickup and drop'],
        'sightseeing' => ['sightseeing','city tour','local tour'],
        'activity' => ['activity','activities','ticket','tickets','ferry','boat ride','entrance'],
        'meal' => ['breakfast','lunch','dinner','meal plan','meals'],
        'guide' => ['guide','tour escort'],
        'flight' => ['flight included','airfare included','air ticket included','air tickets included'],
        'train' => ['train included','rail ticket included','railway ticket included'],
        'visa' => ['visa included','visa assistance'],
        'insurance' => ['travel insurance','insurance included'],
        'cruise' => ['cruise'],
    ];
    $titles = [
        'transport'=>'Transport / Vehicle','transfer'=>'Arrival / Departure Transfer','sightseeing'=>'Sightseeing',
        'activity'=>'Activities / Tickets','meal'=>'Meals','guide'=>'Guide / Tour Escort','flight'=>'Flight',
        'train'=>'Train','visa'=>'Visa','insurance'=>'Travel Insurance','cruise'=>'Cruise'
    ];
    $bases = [
        'transport'=>'fixed','transfer'=>'fixed','sightseeing'=>'fixed','activity'=>'per_person','meal'=>'per_person',
        'guide'=>'fixed','flight'=>'per_person','train'=>'per_person','visa'=>'per_person','insurance'=>'per_person','cruise'=>'per_person'
    ];

    foreach ($rules as $type => $needles) {
        if (isset($existsType[$type])) continue;
        $spec = tsPackageServiceExtractMatchingLines($inclusions, $needles);
        if ($spec === '') continue;
        $preferred = tsPackagePreferredSupplier($pdo, $type, $destinationId);
        $supplierId = (int)($preferred['id'] ?? 0);
        $insert->execute([
            $packageId,$type,$titles[$type] ?? tsPackageServiceLabel($type),$destinationId,null,null,
            $supplierId>0?$supplierId:null,1,$durationDays,1,$bases[$type] ?? 'fixed','included',$spec,1,$supplierId>0?1:0,++$sort,
            $adminId>0?$adminId:null,$adminId>0?$adminId:null
        ]);
        $result['added']++;
        if ($supplierId > 0) $result['mapped']++;
    }

    return $result;
}

function tsPackageAutoMapServiceSuppliers(PDO $pdo, int $packageId, int $adminId = 0): array
{
    $result = ['mapped'=>0,'unmapped'=>0];
    if (!tsPackageServicesTableExists($pdo, 'package_services')) return $result;
    $stmt = $pdo->prepare("SELECT id,service_type,destination_id FROM package_services WHERE package_id=? AND status='active' AND (preferred_supplier_id IS NULL OR preferred_supplier_id=0)");
    $stmt->execute([$packageId]);
    $upd = $pdo->prepare("UPDATE package_services SET preferred_supplier_id=?,auto_prepare_supplier_request=1,updated_by_admin_id=?,updated_at=NOW() WHERE id=?");
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
        $supplier = tsPackagePreferredSupplier($pdo,(string)$row['service_type'],!empty($row['destination_id'])?(int)$row['destination_id']:null);
        if ($supplier) {
            $upd->execute([(int)$supplier['id'],$adminId>0?$adminId:null,(int)$row['id']]);
            $result['mapped']++;
        } else {
            $result['unmapped']++;
        }
    }
    return $result;
}

function tsPackageSelectedHotelStarFromEnquiry(array $enquiry): ?int
{
    $text = (string)($enquiry['message'] ?? '');
    if (preg_match('/(?:Tour\s+Hotel\s+Category|Hotel\s+Category)\s*:\s*([345])\s*Star/iu', $text, $m)) {
        return (int)$m[1];
    }
    return null;
}

function tsPackageRoomsFromEnquiry(array $enquiry): int
{
    $text = (string)($enquiry['message'] ?? '');
    if (preg_match('/(?:Tour\s+Rooms|Rooms\s+Required)\s*:\s*(\d+)/iu', $text, $m)) {
        return max(1,(int)$m[1]);
    }
    $pax = max(1,(int)($enquiry['adults'] ?? 1) + (int)($enquiry['children'] ?? 0));
    return max(1,(int)ceil($pax/2));
}

function tsPackageServiceQuantity(array $service, array $enquiry, int $durationNights): float
{
    $base = max(0.01,(float)($service['quantity'] ?? 1));
    $adults = max(0,(int)($enquiry['adults'] ?? 0));
    $children = max(0,(int)($enquiry['children'] ?? 0));
    return match ((string)($service['quantity_basis'] ?? 'fixed')) {
        'per_person' => $base * max(1,$adults+$children),
        'per_adult' => $base * max(1,$adults),
        'per_child' => $base * $children,
        'per_room' => $base * tsPackageRoomsFromEnquiry($enquiry),
        'per_night' => $base * max(1,$durationNights),
        default => $base,
    };
}

function tsPackageServiceDate(?string $travelStart, ?int $day): ?string
{
    $travelStart = trim((string)$travelStart);
    if ($travelStart === '' || !$day || $day <= 0) return $travelStart !== '' ? $travelStart : null;
    $ts = strtotime($travelStart.' +'.max(0,$day-1).' days');
    return $ts ? date('Y-m-d',$ts) : $travelStart;
}

function tsPackageDraftSupplierRequest(PDO $pdo, array $trip, array $enquiry, array $requirement, array $service, int $adminId = 0): ?int
{
    $supplierId = (int)($service['preferred_supplier_id'] ?? 0);
    if ($supplierId <= 0 || !tsPackageServicesTableExists($pdo,'supplier_requests')) return null;

    // Idempotent: do not prepare the same supplier + service requirement twice.
    $check = $pdo->prepare("SELECT id FROM supplier_requests WHERE trip_id=? AND service_requirement_id=? AND supplier_id=? AND status<>'cancelled' ORDER BY id DESC LIMIT 1");
    $check->execute([(int)$trip['id'],(int)$requirement['id'],$supplierId]);
    $existing = (int)$check->fetchColumn();
    if ($existing > 0) return $existing;

    $supplierStmt = $pdo->prepare("SELECT * FROM suppliers WHERE id=? AND status='active' LIMIT 1");
    $supplierStmt->execute([$supplierId]);
    $supplier = $supplierStmt->fetch(PDO::FETCH_ASSOC);
    if (!$supplier) return null;

    $contact = null;
    if (tsPackageServicesTableExists($pdo,'supplier_contacts')) {
        $cs = $pdo->prepare("SELECT * FROM supplier_contacts WHERE supplier_id=? AND status='active' ORDER BY is_primary DESC,id ASC LIMIT 1");
        $cs->execute([$supplierId]);
        $contact = $cs->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    // Use current max ID + random suffix to avoid collision without requiring supplier-functions.php.
    $year = date('Y');
    for ($i=0;$i<20;$i++) {
        $code = 'SR-'.$year.'-'.str_pad((string)random_int(1,999999),6,'0',STR_PAD_LEFT);
        $c=$pdo->prepare("SELECT id FROM supplier_requests WHERE request_code=? LIMIT 1");$c->execute([$code]);
        if (!$c->fetchColumn()) break;
    }
    $group = 'SRG-'.$year.'-'.str_pad((string)random_int(1,999999),6,'0',STR_PAD_LEFT);

    $destination = '';
    if (!empty($requirement['destination_id']) && tsPackageServicesTableExists($pdo,'destinations')) {
        $ds=$pdo->prepare("SELECT name,country FROM destinations WHERE id=? LIMIT 1");$ds->execute([(int)$requirement['destination_id']]);
        if ($d=$ds->fetch(PDO::FETCH_ASSOC)) $destination=trim((string)$d['name'].(!empty($d['country'])?', '.$d['country']:''));
    }

    $subject = 'TRAVSCOPE Supplier Rate Request · '.((string)($requirement['title'] ?? tsPackageServiceLabel((string)$service['service_type'])));
    $reqText = "TRAVSCOPE PACKAGE SERVICE RATE REQUEST\n"
        .'Trip: '.(string)($trip['trip_code'] ?? '')."\n"
        .'Service: '.tsPackageServiceLabel((string)$service['service_type'])."\n"
        .'Requirement: '.(string)($requirement['title'] ?? '')."\n"
        .($destination!==''?'Destination: '.$destination."\n":'')
        .(!empty($requirement['service_date_from'])?'Service Date: '.$requirement['service_date_from'].(!empty($requirement['service_date_to'])?' to '.$requirement['service_date_to']:'')."\n":'')
        .'Travellers: '.max(0,(int)($enquiry['adults']??0)).' Adult(s) + '.max(0,(int)($enquiry['children']??0))." Child(ren)\n"
        .'Quantity: '.number_format((float)($requirement['quantity']??1),2,'.','')."\n\n"
        .trim((string)($requirement['specifications'] ?? ''))
        ."\n\nPlease share your best NET supplier rate, tax/GST, availability, validity, inclusions/exclusions, payment terms and cancellation terms.";

    $channel = ($contact && filter_var((string)($contact['email']??''),FILTER_VALIDATE_EMAIL)) ? 'email' : 'manual';
    $ins = $pdo->prepare("
        INSERT INTO supplier_requests
        (request_code,request_group_code,enquiry_id,trip_id,service_requirement_id,supplier_id,supplier_contact_id,
         request_type,destination_id,subject,requirement_text,special_requirements,channel,status,assigned_admin_id,
         created_by_admin_id,updated_by_admin_id)
        VALUES (?,?,?,?,?,?,?,'service_quote',?,?,?,?,?,'draft',?,?,?)
    ");
    $ins->execute([
        $code,$group,(int)$enquiry['id'],(int)$trip['id'],(int)$requirement['id'],$supplierId,
        $contact?(int)$contact['id']:null,!empty($requirement['destination_id'])?(int)$requirement['destination_id']:null,
        $subject,$reqText,null,$channel,$adminId>0?$adminId:null,$adminId>0?$adminId:null,$adminId>0?$adminId:null
    ]);
    return (int)$pdo->lastInsertId();
}

function tsPackageSyncTripServicesFromPackage(PDO $pdo, int $tripId, int $adminId = 0): array
{
    $result = ['package_id'=>0,'created_requirements'=>0,'existing_requirements'=>0,'draft_supplier_requests'=>0,'warnings'=>[]];
    if ($tripId<=0 || !tsPackageServicesTableExists($pdo,'package_services') || !tsPackageServicesTableExists($pdo,'trip_service_requirements')) return $result;

    $ts=$pdo->prepare("SELECT * FROM trips WHERE id=? LIMIT 1");$ts->execute([$tripId]);$trip=$ts->fetch(PDO::FETCH_ASSOC);
    if (!$trip || empty($trip['package_id'])) return $result;
    $packageId=(int)$trip['package_id'];$result['package_id']=$packageId;

    $es=$pdo->prepare("SELECT * FROM enquiries WHERE id=? LIMIT 1");$es->execute([(int)$trip['enquiry_id']]);$enquiry=$es->fetch(PDO::FETCH_ASSOC);
    if (!$enquiry) return $result;

    $count=$pdo->prepare("SELECT COUNT(*) FROM package_services WHERE package_id=? AND status='active'");$count->execute([$packageId]);
    if ((int)$count->fetchColumn()===0) {
        $built=tsPackageAutoBuildServices($pdo,$packageId,$adminId);
        foreach($built['warnings']??[] as $w) $result['warnings'][]=$w;
    }

    $ps=$pdo->prepare("SELECT * FROM packages WHERE id=? LIMIT 1");$ps->execute([$packageId]);$package=$ps->fetch(PDO::FETCH_ASSOC) ?: [];
    $durationNights=max(0,(int)($package['duration_nights']??0));
    $selectedStar=tsPackageSelectedHotelStarFromEnquiry($enquiry);

    $ss=$pdo->prepare("SELECT * FROM package_services WHERE package_id=? AND status='active' AND auto_create_requirement=1 ORDER BY sort_order,id");
    $ss->execute([$packageId]);

    $hasSourceColumn=false;
    try {
        $cs=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='trip_service_requirements' AND column_name='source_package_service_id'");$cs->execute();
        $hasSourceColumn=(int)$cs->fetchColumn()>0;
    } catch(Throwable $e){}

    foreach($ss->fetchAll(PDO::FETCH_ASSOC) ?: [] as $service) {
        $star=!empty($service['hotel_star_category'])?(int)$service['hotel_star_category']:null;
        if ((string)$service['service_type']==='hotel') {
            if (!$selectedStar) {
                if (!in_array('Hotel category was not captured in the enquiry; hotel service was not auto-created to avoid choosing the wrong 3/4/5 Star option.', $result['warnings'], true)) {
                    $result['warnings'][] = 'Hotel category was not captured in the enquiry; hotel service was not auto-created to avoid choosing the wrong 3/4/5 Star option.';
                }
                continue;
            }
            if ($star && $star!==$selectedStar) continue;
        }

        $existing=null;
        if ($hasSourceColumn) {
            $chk=$pdo->prepare("SELECT * FROM trip_service_requirements WHERE trip_id=? AND source_package_service_id=? LIMIT 1");
            $chk->execute([$tripId,(int)$service['id']]);$existing=$chk->fetch(PDO::FETCH_ASSOC) ?: null;
        }
        if ($existing) {
            $result['existing_requirements']++;
            $requirement=$existing;
        } else {
            $from=tsPackageServiceDate($trip['travel_start_date']??$enquiry['travel_date']??null,!empty($service['service_day_from'])?(int)$service['service_day_from']:1);
            $to=tsPackageServiceDate($trip['travel_start_date']??$enquiry['travel_date']??null,!empty($service['service_day_to'])?(int)$service['service_day_to']:(int)($package['duration_days']??1));
            $qty=tsPackageServiceQuantity($service,$enquiry,$durationNights);
            if ($qty<=0 && (string)$service['quantity_basis']==='per_child') continue;
            $spec=trim((string)($service['specifications']??''));
            $spec.=($spec!==''?"\n\n":'').'Source: Package Service Template #'.(int)$service['id'];

            if ($hasSourceColumn) {
                $ins=$pdo->prepare("INSERT INTO trip_service_requirements (trip_id,enquiry_id,source_package_service_id,service_type,title,destination_id,service_date_from,service_date_to,quantity,adults,children,specifications,status,sort_order,created_by_admin_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?, 'rate_required',?,?)");
                $ins->execute([$tripId,(int)$enquiry['id'],(int)$service['id'],(string)$service['service_type'],(string)$service['title'],!empty($service['destination_id'])?(int)$service['destination_id']:(!empty($trip['destination_id'])?(int)$trip['destination_id']:null),$from,$to,$qty,max(0,(int)$enquiry['adults']),max(0,(int)$enquiry['children']),$spec,(int)$service['sort_order'],$adminId>0?$adminId:null]);
            } else {
                $ins=$pdo->prepare("INSERT INTO trip_service_requirements (trip_id,enquiry_id,service_type,title,destination_id,service_date_from,service_date_to,quantity,adults,children,specifications,status,sort_order,created_by_admin_id) VALUES (?,?,?,?,?,?,?,?,?,?,?, 'rate_required',?,?)");
                $ins->execute([$tripId,(int)$enquiry['id'],(string)$service['service_type'],(string)$service['title'],!empty($service['destination_id'])?(int)$service['destination_id']:(!empty($trip['destination_id'])?(int)$trip['destination_id']:null),$from,$to,$qty,max(0,(int)$enquiry['adults']),max(0,(int)$enquiry['children']),$spec,(int)$service['sort_order'],$adminId>0?$adminId:null]);
            }
            $rid=(int)$pdo->lastInsertId();
            $rq=$pdo->prepare("SELECT * FROM trip_service_requirements WHERE id=?");$rq->execute([$rid]);$requirement=$rq->fetch(PDO::FETCH_ASSOC) ?: ['id'=>$rid];
            $result['created_requirements']++;
        }

        if (!empty($service['auto_prepare_supplier_request']) && !empty($service['preferred_supplier_id'])) {
            try {
                $before=0;
                $c=$pdo->prepare("SELECT COUNT(*) FROM supplier_requests WHERE trip_id=? AND service_requirement_id=? AND supplier_id=? AND status<>'cancelled'");
                $c->execute([$tripId,(int)$requirement['id'],(int)$service['preferred_supplier_id']]);$before=(int)$c->fetchColumn();
                $requestId=tsPackageDraftSupplierRequest($pdo,$trip,$enquiry,$requirement,$service,$adminId);
                if ($requestId && $before===0) $result['draft_supplier_requests']++;
            } catch(Throwable $e) {
                $result['warnings'][]='Supplier routing failed for '.$service['title'].': '.$e->getMessage();
            }
        }
    }

    return $result;
}

function tsPackageSnapshotDirectBookingServices(PDO $pdo, int $bookingId, int $adminId = 0): array
{
    $result=['created_snapshots'=>0,'existing_snapshots'=>0,'warnings'=>[]];
    if($bookingId<=0 || !tsPackageServicesTableExists($pdo,'booking_service_snapshots') || !tsPackageServicesTableExists($pdo,'bookings')) return $result;

    // CRM accepted-quotation bookings already freeze services through crm-functions.php.
    if(tsPackageServicesTableExists($pdo,'booking_trip_links')){
        $l=$pdo->prepare("SELECT id FROM booking_trip_links WHERE booking_id=? LIMIT 1");$l->execute([$bookingId]);
        if($l->fetchColumn()) return $result;
    }

    $bq=$pdo->prepare("SELECT b.*,p.duration_days,p.duration_nights,p.destination_id package_destination_id FROM bookings b LEFT JOIN packages p ON p.id=b.package_id WHERE b.id=? LIMIT 1");
    $bq->execute([$bookingId]);$booking=$bq->fetch(PDO::FETCH_ASSOC);
    if(!$booking || empty($booking['package_id'])) return $result;
    $packageId=(int)$booking['package_id'];

    $cnt=$pdo->prepare("SELECT COUNT(*) FROM package_services WHERE package_id=? AND status='active'");$cnt->execute([$packageId]);
    if((int)$cnt->fetchColumn()===0) tsPackageAutoBuildServices($pdo,$packageId,$adminId);

    $selectedStar=null;
    if(preg_match('/^([345])_star$/',(string)($booking['hotel_category']??''),$m)) $selectedStar=(int)$m[1];
    $pseudoEnquiry=[
        'adults'=>(int)($booking['adults']??0),
        'children'=>(int)($booking['children']??0),
        'message'=>'',
    ];
    $durationNights=max(0,(int)($booking['duration_nights']??0));

    // Direct snapshots have no CRM service requirement source. Idempotency is
    // based on a marker in specifications so repeated calls are safe.
    $services=$pdo->prepare("SELECT * FROM package_services WHERE package_id=? AND status='active' AND auto_create_requirement=1 ORDER BY sort_order,id");
    $services->execute([$packageId]);
    foreach($services->fetchAll(PDO::FETCH_ASSOC)?:[] as $service){
        $star=!empty($service['hotel_star_category'])?(int)$service['hotel_star_category']:null;
        if((string)$service['service_type']==='hotel'){
            if(!$selectedStar){
                continue; // Never guess a paid hotel category on a direct booking.
            }
            if($star && $star!==$selectedStar) continue;
        }

        $marker='[[PACKAGE_SERVICE:'.(int)$service['id'].']]';
        $chk=$pdo->prepare("SELECT id FROM booking_service_snapshots WHERE booking_id=? AND specifications LIKE ? LIMIT 1");
        $chk->execute([$bookingId,'%'.$marker.'%']);
        if($chk->fetchColumn()){$result['existing_snapshots']++;continue;}

        $from=tsPackageServiceDate($booking['travel_date']??null,!empty($service['service_day_from'])?(int)$service['service_day_from']:1);
        $to=tsPackageServiceDate($booking['travel_date']??null,!empty($service['service_day_to'])?(int)$service['service_day_to']:max(1,(int)($booking['duration_days']??1)));
        $qty=tsPackageServiceQuantity($service,$pseudoEnquiry,$durationNights);
        if($qty<=0 && (string)$service['quantity_basis']==='per_child') continue;
        $spec=trim((string)($service['specifications']??''));
        $spec.=($spec!==''?"\n\n":'').$marker."\nDirect website booking service snapshot.";
        $supplierId=(int)($service['preferred_supplier_id']??0);
        $supplierName=null;
        if($supplierId>0){$sq=$pdo->prepare("SELECT company_name FROM suppliers WHERE id=? AND status='active' LIMIT 1");$sq->execute([$supplierId]);$supplierName=$sq->fetchColumn()?:null;if(!$supplierName)$supplierId=0;}
        $destinationId=!empty($service['destination_id'])?(int)$service['destination_id']:(!empty($booking['package_destination_id'])?(int)$booking['package_destination_id']:null);
        $destinationName=null;
        if($destinationId){$dq=$pdo->prepare("SELECT name FROM destinations WHERE id=? LIMIT 1");$dq->execute([$destinationId]);$destinationName=$dq->fetchColumn()?:null;}
        $ins=$pdo->prepare("INSERT INTO booking_service_snapshots(booking_id,trip_id,source_service_requirement_id,sort_order,service_type,title,destination_id,destination_name,service_date_from,service_date_to,quantity,adults,children,specifications,source_supplier_id,source_supplier_name,internal_supplier_cost,procurement_status) VALUES (?,0,NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?)");
        $ins->execute([
            $bookingId,(int)$service['sort_order'],(string)$service['service_type'],(string)$service['title'],$destinationId,$destinationName,$from,$to,$qty,max(0,(int)$booking['adults']),max(0,(int)$booking['children']),$spec,$supplierId>0?$supplierId:null,$supplierName,$supplierId>0?'confirmation_required':'pending'
        ]);
        $result['created_snapshots']++;
    }
    return $result;
}
