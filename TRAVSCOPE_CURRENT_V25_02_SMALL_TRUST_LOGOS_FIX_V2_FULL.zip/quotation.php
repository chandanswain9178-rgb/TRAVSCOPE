<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE CUSTOMER QUOTATION PORTAL
| VERSION: 2026-09-09-R1
|--------------------------------------------------------------------------
| Secure customer link:
|   Review exact quotation version
|   Download official PDF
|   Accept -> create booking through the existing Booking Bridge
|   Request changes
|   Reject quotation
|--------------------------------------------------------------------------
*/

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/quotation-customer-functions.php';
require_once __DIR__ . '/crm-functions.php';
$commercialWorkflowFile = __DIR__ . '/commercial-workflow-functions.php';
if (is_file($commercialWorkflowFile)) require_once $commercialWorkflowFile;

function qh(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function qnl(?string $value): string
{
    return nl2br(qh(trim((string)$value)));
}

function qasset(?string $path): string
{
    $path = trim((string)$path);
    if ($path === '') {
        return '';
    }

    if (preg_match('~^https?://~i', $path)) {
        return $path;
    }

    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}

$leadId = max(0, (int)($_GET['lead'] ?? 0));
$versionId = max(0, (int)($_GET['version'] ?? 0));
$expires = max(0, (int)($_GET['expires'] ?? 0));
$token = trim((string)($_GET['token'] ?? ''));

$linkValid = qcpTokenValid($leadId, $versionId, $expires, $token);
$context = $linkValid ? qcpContext($pdo, $leadId, $versionId) : null;

if (empty($_SESSION['quotation_customer_csrf'])) {
    $_SESSION['quotation_customer_csrf'] = bin2hex(random_bytes(32));
}
$csrf = (string)$_SESSION['quotation_customer_csrf'];

$flash = $_SESSION['quotation_customer_flash'] ?? null;
unset($_SESSION['quotation_customer_flash']);

$portalUrl = BASE_URL
    . 'quotation.php?lead=' . $leadId
    . '&version=' . $versionId
    . '&expires=' . $expires
    . '&token=' . rawurlencode($token);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $linkValid && $context) {
    try {
        $postedCsrf = (string)($_POST['csrf_token'] ?? '');
        if ($postedCsrf === '' || !hash_equals($csrf, $postedCsrf)) {
            throw new RuntimeException('Your secure form session expired. Please refresh this page and try again.');
        }

        if (!qcpResponseTableReady($pdo)) {
            throw new RuntimeException('Quotation response setup is not complete yet. Please contact TRAVSCOPE.');
        }

        $decision = strtolower(trim((string)($_POST['decision'] ?? '')));
        $note = trim((string)($_POST['customer_note'] ?? ''));

        if (!in_array($decision, ['accepted', 'change_requested', 'rejected'], true)) {
            throw new RuntimeException('Please choose a valid quotation response.');
        }

        $acceptedExisting = $context['accepted_booking'] ?? null;
        $isLatest = (int)$context['version_number'] >= (int)$context['latest_version_number'];

        if ($acceptedExisting) {
            $_SESSION['quotation_customer_flash'] = [
                'type' => 'success',
                'message' => 'This quotation is already accepted. Your booking number is ' . (string)$acceptedExisting['booking_number'] . '.',
            ];
            header('Location: ' . $portalUrl);
            exit;
        }

        if (!$isLatest) {
            throw new RuntimeException('A newer quotation version has been issued. Please use the latest quotation link sent by TRAVSCOPE.');
        }

        if (in_array($decision, ['change_requested', 'rejected'], true) && mb_strlen($note) < 3) {
            throw new RuntimeException('Please add a short note so our travel team knows what you would like changed.');
        }

        $tripId = max(0, (int)($context['trip_id'] ?? 0));
        $bookingId = null;
        $bookingNumber = '';

        if ($decision === 'accepted') {
            if ($tripId <= 0) {
                throw new RuntimeException('This quotation is not yet linked to a Trip. Please contact TRAVSCOPE before accepting it.');
            }

            $result = crmAcceptQuotationAndCreateBooking(
                $pdo,
                $leadId,
                $versionId,
                $tripId,
                0,
                'customer_portal',
                $note
            );

            $bookingId = (int)$result['booking_id'];
            $bookingNumber = (string)$result['booking_number'];

            qcpLogResponse(
                $pdo,
                $leadId,
                $tripId,
                $versionId,
                $bookingId,
                'accepted',
                $note
            );

            qcpLogCrmActivity(
                $pdo,
                $leadId,
                'Customer accepted Quotation V' . (int)$context['version_number'],
                'Accepted from the secure Customer Quotation Portal. Booking ' . $bookingNumber . ' was created automatically.'
                . ($note !== '' ? "\nCustomer note: " . $note : '')
            );

            qcpNotifyAdmins(
                $pdo,
                $context,
                'accepted',
                $note,
                $bookingId,
                $bookingNumber
            );

            if (function_exists('tsCWMarkCustomerDecision')) {
                tsCWMarkCustomerDecision($pdo, $tripId, $leadId, $versionId, 'accepted', $note);
            }

            $_SESSION['quotation_customer_flash'] = [
                'type' => 'success',
                'message' => 'Quotation accepted successfully. Your booking number is ' . $bookingNumber . '. Our travel team will now proceed with the booking arrangements.',
            ];
        } else {
            qcpLogResponse(
                $pdo,
                $leadId,
                $tripId > 0 ? $tripId : null,
                $versionId,
                null,
                $decision,
                $note
            );

            qcpUpdateSalesForResponse(
                $pdo,
                $leadId,
                $tripId > 0 ? $tripId : null,
                $decision,
                $note
            );

            $activitySubject = $decision === 'change_requested'
                ? 'Customer requested changes to Quotation V' . (int)$context['version_number']
                : 'Customer rejected Quotation V' . (int)$context['version_number'];

            qcpLogCrmActivity($pdo, $leadId, $activitySubject, $note);
            qcpNotifyAdmins($pdo, $context, $decision, $note);

            if (function_exists('tsCWCreateChangeRequest') && $decision === 'change_requested') {
                tsCWCreateChangeRequest($pdo, [
                    'lead_id' => $leadId,
                    'trip_id' => $tripId,
                    'quotation_version_id' => $versionId,
                    'source' => 'customer_portal',
                    'request_type' => 'auto',
                    'priority' => 'normal',
                    'request_text' => $note,
                    'requested_by_name' => (string)($context['customer_name'] ?? ''),
                    'requested_by_email' => (string)($context['customer_email'] ?? ''),
                ]);
            } elseif (function_exists('tsCWMarkCustomerDecision')) {
                tsCWMarkCustomerDecision($pdo, $tripId, $leadId, $versionId, $decision, $note);
            }

            $_SESSION['quotation_customer_flash'] = [
                'type' => $decision === 'change_requested' ? 'warning' : 'info',
                'message' => $decision === 'change_requested'
                    ? 'Your change request has been sent to our travel team. We will prepare a revised quotation.'
                    : 'Your response has been recorded. Our travel team may contact you to understand your requirements better.',
            ];
        }

        header('Location: ' . $portalUrl);
        exit;
    } catch (Throwable $e) {
        error_log('TRAVSCOPE quotation portal response error: ' . $e->getMessage());
        $flash = [
            'type' => 'error',
            'message' => $e->getMessage(),
        ];
    }
}

$siteName = function_exists('getSetting')
    ? (string)getSetting($pdo, 'site_name', 'TRAVSCOPE.COM')
    : 'TRAVSCOPE.COM';

$sitePhone = function_exists('getSetting')
    ? (string)getSetting($pdo, 'contact_phone', '')
    : '';

$siteEmail = function_exists('getSetting')
    ? (string)getSetting($pdo, 'contact_email', '')
    : '';

$documentLogo = function_exists('getSetting')
    ? trim((string)getSetting($pdo, 'document_logo', 'assets/travscope-document-logo-wide.png'))
    : 'assets/travscope-document-logo-wide.png';
if ($documentLogo === '') $documentLogo = 'assets/travscope-document-logo-wide.png';
$siteLogo = qasset($documentLogo);
$documentHeaderName = 'Memorable Hospitality Pvt. Ltd.';

$snapshot = is_array($context['snapshot'] ?? null) ? $context['snapshot'] : [];
$currency = strtoupper(trim((string)($snapshot['currency'] ?? 'INR'))) ?: 'INR';
$price = (float)($context['final_price'] ?? 0);
$durationDays = max(0, (int)($snapshot['duration_days'] ?? 0));
$durationNights = max(0, (int)($snapshot['duration_nights'] ?? 0));
$itinerary = is_array($snapshot['itinerary_days'] ?? null) ? $snapshot['itinerary_days'] : [];
$flightSuggestions = is_array($snapshot['flight_suggestions'] ?? null) ? $snapshot['flight_suggestions'] : [];
$trainSuggestions = is_array($snapshot['train_suggestions'] ?? null) ? $snapshot['train_suggestions'] : [];
$hotelAllocations = is_array($snapshot['hotel_allocations'] ?? null) ? $snapshot['hotel_allocations'] : [];
$transportAllocations = is_array($snapshot['transport_allocations'] ?? null) ? $snapshot['transport_allocations'] : [];
$acceptedBooking = $context['accepted_booking'] ?? null;
$isLatest = $context ? ((int)$context['version_number'] >= (int)$context['latest_version_number']) : false;
$responseReady = $context ? qcpResponseTableReady($pdo) : false;
$pdfUrl = $context ? qcpPdfUrl($leadId, $versionId) : '';
$mainImage = qasset($snapshot['main_image'] ?? '');
$pricing = is_array($snapshot['pricing'] ?? null) ? $snapshot['pricing'] : [];
$customerNotes = trim((string)($snapshot['customer_notes'] ?? ''));
$terms = trim((string)($snapshot['terms'] ?? $context['terms'] ?? ''));
$inclusions = trim((string)($snapshot['inclusions'] ?? $context['inclusions'] ?? ''));
$exclusions = trim((string)($snapshot['exclusions'] ?? $context['exclusions'] ?? ''));
$description = trim((string)($snapshot['description'] ?? $context['package_description'] ?? ''));
$highlights = trim((string)($snapshot['tour_highlights'] ?? ''));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow,noarchive">
<title><?= qh($context ? 'Quotation V' . (int)$context['version_number'] . ' | ' . $siteName : 'Quotation | ' . $siteName); ?></title>
<style>
:root{--navy:#07192d;--blue:#0b74ff;--sky:#eaf4ff;--ink:#142033;--muted:#65758b;--line:#dfe7f0;--bg:#f4f7fb;--green:#0a8f62;--greenbg:#e8f8f2;--red:#c73737;--redbg:#fff0f0;--amber:#a86200;--amberbg:#fff6e7;--shadow:0 18px 48px rgba(13,36,63,.10)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;line-height:1.6}.topbar{background:#fff;color:var(--navy);padding:14px 20px;border-top:5px solid var(--navy);border-bottom:1px solid var(--line)}.topbar-in{max-width:1100px;margin:auto;display:flex;align-items:center;justify-content:space-between;gap:20px}.document-brand{display:grid;grid-template-columns:3in minmax(180px,1fr);align-items:center;gap:18px;font-weight:900;letter-spacing:.2px;min-width:0}.document-brand img{display:block;width:3in;max-width:3in;max-height:1.2in;height:auto;object-fit:contain;background:#fff}.document-brand .company{font-size:15px;line-height:1.25}.document-brand .trade{display:block;margin-top:3px;color:#64748b;font-size:10px;font-weight:800}.secure{font-size:11px;color:#64748b;text-align:right}.wrap{max-width:1100px;margin:26px auto 70px;padding:0 16px}.card{background:white;border:1px solid var(--line);border-radius:18px;box-shadow:var(--shadow);overflow:hidden}.hero{display:grid;grid-template-columns:1.15fr .85fr;min-height:290px}.hero-copy{padding:34px}.eyebrow{font-size:11px;font-weight:900;letter-spacing:1.4px;color:var(--blue);text-transform:uppercase}.hero h1{font-size:34px;line-height:1.15;margin:9px 0 10px;color:var(--navy)}.hero p{color:var(--muted);margin:0}.hero-img{background:linear-gradient(135deg,#0b74ff,#07192d);min-height:260px}.hero-img img{width:100%;height:100%;object-fit:cover;display:block}.version-pill{display:inline-flex;align-items:center;margin-top:18px;padding:7px 11px;border-radius:999px;background:var(--sky);color:#0759b7;font-size:11px;font-weight:900}.facts{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:16px}.fact{background:white;border:1px solid var(--line);border-radius:14px;padding:15px}.fact small{display:block;font-size:10px;font-weight:900;letter-spacing:.8px;color:#7b899c;text-transform:uppercase}.fact strong{display:block;margin-top:4px;color:var(--navy);font-size:16px}.fact.price strong{color:var(--green);font-size:20px}.notice{margin:16px 0;padding:14px 16px;border-radius:13px;border:1px solid}.notice.success{background:var(--greenbg);border-color:#bdebd8;color:#076746}.notice.warning{background:var(--amberbg);border-color:#f0d29f;color:#865000}.notice.error{background:var(--redbg);border-color:#efc1c1;color:#a52b2b}.notice.info{background:#eef5ff;border-color:#c8dcfa;color:#215e9f}.grid{display:grid;grid-template-columns:minmax(0,1fr) 330px;gap:18px;margin-top:18px}.section{background:white;border:1px solid var(--line);border-radius:16px;padding:22px;margin-bottom:16px}.section h2{margin:0 0 13px;color:var(--navy);font-size:19px}.section h3{color:var(--navy)}.muted{color:var(--muted)}.prose{white-space:normal;color:#43536a}.prose br{line-height:1.7}.days{display:grid;gap:12px}.day{border:1px solid var(--line);border-radius:14px;overflow:hidden;background:#fff}.day-head{padding:12px 15px;background:#f8fafc;font-weight:900;color:var(--navy)}.day-body{display:grid;grid-template-columns:150px 1fr}.day-body.noimg{grid-template-columns:1fr}.day-img{width:150px;height:145px;object-fit:cover}.day-copy{padding:14px 15px;color:#4b5d74;font-size:13px}.side{position:relative}.action-card{position:sticky;top:16px;background:white;border:1px solid var(--line);border-radius:16px;padding:19px;box-shadow:var(--shadow)}.action-card h2{font-size:19px;margin:0 0 5px;color:var(--navy)}.action-card p{font-size:12px;color:var(--muted);margin:0 0 12px}.textarea{width:100%;min-height:96px;border:1px solid #ccd8e5;border-radius:11px;padding:11px;font:inherit;font-size:13px;resize:vertical;outline:none}.textarea:focus{border-color:var(--blue);box-shadow:0 0 0 3px rgba(11,116,255,.10)}.btn{display:flex;width:100%;align-items:center;justify-content:center;text-decoration:none;border:0;border-radius:11px;padding:12px 14px;margin-top:9px;font-weight:900;cursor:pointer;font-size:13px}.btn.accept{background:var(--green);color:white}.btn.change{background:var(--blue);color:white}.btn.reject{background:white;color:var(--red);border:1px solid #efbebe}.btn.pdf{background:var(--navy);color:white}.btn:disabled{opacity:.45;cursor:not-allowed}.statusbox{padding:14px;border-radius:12px;background:var(--greenbg);border:1px solid #bdebd8;color:#076746;font-weight:800;font-size:13px}.superseded{padding:14px;border-radius:12px;background:var(--amberbg);border:1px solid #f0d29f;color:#865000;font-size:13px}.mini{font-size:11px;color:#7a899b;margin-top:10px}.contact{margin-top:15px;border-top:1px solid var(--line);padding-top:12px;font-size:11px;color:#748398}.fatal{max-width:680px;margin:80px auto;background:white;border:1px solid var(--line);border-radius:18px;padding:30px;box-shadow:var(--shadow);text-align:center}.fatal h1{color:var(--navy)}.pricing-lines{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.pricing-line{padding:12px;border-radius:12px;background:#f8fafc;border:1px solid var(--line)}.pricing-line small{color:var(--muted);display:block}.pricing-line strong{color:var(--navy)}
.suggestion-grid{display:grid;gap:10px}.suggestion-card{border:1px solid var(--line);border-radius:14px;padding:14px;background:#fbfdff}.suggestion-card.flight{border-left:4px solid #2563eb}.suggestion-card.train{border-left:4px solid #10b981}.suggestion-top{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.suggestion-title{font-weight:900;color:var(--navy)}.suggestion-route{margin-top:4px;color:#475569;font-weight:700}.suggestion-meta{display:flex;gap:6px;flex-wrap:wrap;margin-top:9px}.suggestion-chip{padding:5px 8px;border-radius:999px;background:#eef4ff;color:#1d4ed8;font-size:10px;font-weight:800}.suggestion-card.train .suggestion-chip{background:#ecfdf5;color:#047857}.suggestion-fare{font-weight:900;color:var(--green);white-space:nowrap}.suggestion-note{margin-top:10px;padding:10px 12px;border-radius:10px;background:#fff8e8;color:#865000;font-size:11px}
@media(max-width:850px){.hero{grid-template-columns:1fr}.hero-img{order:-1;min-height:210px}.hero-copy{padding:24px}.hero h1{font-size:28px}.facts{grid-template-columns:repeat(2,1fr)}.grid{grid-template-columns:1fr}.action-card{position:static}.day-body{grid-template-columns:110px 1fr}.day-img{width:110px;height:120px}.pricing-lines{grid-template-columns:1fr}}
@media(max-width:720px){.topbar-in{align-items:flex-start;flex-direction:column}.document-brand{grid-template-columns:1fr}.document-brand img{width:min(3in,100%);max-width:100%}.secure{text-align:left}.wrap{margin-top:15px}.facts{grid-template-columns:1fr 1fr}.fact{padding:12px}.hero h1{font-size:25px}.day-body,.day-body.noimg{grid-template-columns:1fr}.day-img{width:100%;height:180px}.section{padding:17px}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>
<body>
<div class="topbar"><div class="topbar-in"><div class="document-brand"><?php if($siteLogo!==''):?><img src="<?=qh($siteLogo)?>" alt="Travscope document logo"><?php endif;?><div><span class="company"><?= qh($documentHeaderName); ?></span><span class="trade">Trade Name: Travscope</span></div></div><div class="secure">🔒 Secure customer quotation · Exact version protected</div></div></div>

<?php if (!$linkValid): ?>
<div class="fatal">
    <div style="font-size:40px">🔒</div>
    <h1>Quotation link expired or invalid</h1>
    <p class="muted">For your privacy, customer quotation links are time-limited. Please ask TRAVSCOPE to resend your quotation.</p>
</div>
<?php elseif (!$context): ?>
<div class="fatal">
    <div style="font-size:40px">📄</div>
    <h1>Quotation not found</h1>
    <p class="muted">The quotation may have been removed or the link does not match an available quotation.</p>
</div>
<?php else: ?>
<div class="wrap">
    <?php if (is_array($flash) && !empty($flash['message'])): ?>
        <div class="notice <?= qh((string)($flash['type'] ?? 'info')); ?>"><?= qh((string)$flash['message']); ?></div>
    <?php endif; ?>

    <section class="card hero">
        <div class="hero-copy">
            <div class="eyebrow">Personalized travel quotation</div>
            <h1><?= qh((string)$context['package_title']); ?></h1>
            <p><?= qh(trim((string)($snapshot['short_description'] ?? '')) ?: 'Prepared especially for your upcoming journey.'); ?></p>
            <div class="version-pill">Quotation Version <?= (int)$context['version_number']; ?> · For <?= qh((string)$context['customer_name']); ?></div>
        </div>
        <div class="hero-img">
            <?php if ($mainImage !== ''): ?><img src="<?= qh($mainImage); ?>" alt="<?= qh((string)$context['package_title']); ?>"><?php endif; ?>
        </div>
    </section>

    <div class="facts">
        <div class="fact"><small>Travel date</small><strong><?= qh(qcpDate((string)($context['travel_date'] ?? ''))); ?></strong></div>
        <div class="fact"><small>Duration</small><strong><?= $durationDays; ?>D / <?= $durationNights; ?>N</strong></div>
        <div class="fact"><small>Travellers</small><strong><?= (int)$context['adults']; ?> Adult + <?= (int)$context['children']; ?> Child</strong></div>
        <div class="fact price"><small>Final quotation</small><strong><?= qh(qcpMoney($price, $currency)); ?></strong></div>
    </div>

    <?php if (!$responseReady): ?>
        <div class="notice error">Customer response database setup is pending. The quotation can be reviewed, but response buttons remain disabled until TRAVSCOPE completes the Step 02 SQL installation.</div>
    <?php endif; ?>

    <?php if (!$isLatest && !$acceptedBooking): ?>
        <div class="notice warning"><strong>Newer quotation available.</strong> This is Version <?= (int)$context['version_number']; ?>, while Version <?= (int)$context['latest_version_number']; ?> has already been created. For safety, this older version cannot be accepted or rejected. Please use the newest link sent by TRAVSCOPE.</div>
    <?php endif; ?>

    <div class="grid">
        <main>
            <?php if ($description !== ''): ?>
            <section class="section">
                <h2>Package overview</h2>
                <div class="prose"><?= qnl($description); ?></div>
            </section>
            <?php endif; ?>

            <?php if ($highlights !== ''): ?>
            <section class="section">
                <h2>Tour highlights</h2>
                <div class="prose"><?= qnl($highlights); ?></div>
            </section>
            <?php endif; ?>

            <?php if ($pricing): ?>
            <section class="section">
                <h2>Quotation pricing</h2>
                <div class="pricing-lines">
                    <?php if (!empty($pricing['hotel_category'])): ?><div class="pricing-line"><small>Hotel category</small><strong><?= qh((string)$pricing['hotel_category']); ?> Star</strong></div><?php endif; ?>
                    <?php if ((float)($pricing['adult_unit_rate'] ?? 0) > 0): ?><div class="pricing-line"><small>Adult rate</small><strong><?= qh(qcpMoney((float)$pricing['adult_unit_rate'], $currency)); ?></strong></div><?php endif; ?>
                    <?php if ((float)($pricing['adult_subtotal'] ?? 0) > 0): ?><div class="pricing-line"><small>Adult subtotal</small><strong><?= qh(qcpMoney((float)$pricing['adult_subtotal'], $currency)); ?></strong></div><?php endif; ?>
                    <?php if ((float)($pricing['child_subtotal'] ?? 0) > 0): ?><div class="pricing-line"><small>Child subtotal</small><strong><?= qh(qcpMoney((float)$pricing['child_subtotal'], $currency)); ?></strong></div><?php endif; ?>
                </div>
                <p class="mini">Final payable quotation shown above is the authoritative customer price for this quotation version.</p>
            </section>
            <?php endif; ?>

            <?php if ($hotelAllocations): ?>
            <section class="section">
                <h2>Proposed accommodation</h2>
                <div style="display:grid;gap:10px">
                <?php foreach ($hotelAllocations as $hotelRow): if (!is_array($hotelRow)) continue;
                    $actual = trim((string)($hotelRow['hotel_name'] ?? ''));
                    $alts = is_array($hotelRow['alternatives'] ?? null) ? array_values(array_filter(array_map('strval',$hotelRow['alternatives']))) : [];
                    $hotelText = $actual !== '' ? $actual : ($alts ? implode(' / ', array_slice($alts,0,5)) . ' or similar' : (($hotelRow['accommodation_type'] ?? '') === 'houseboat' ? 'Houseboat as per selected category' : 'To be confirmed'));
                    $hotelImage = trim((string)($hotelRow['hotel_image'] ?? ''));
                    $hotelImageUrl = $hotelImage !== '' ? (preg_match('~^https?://~i',$hotelImage) ? $hotelImage : rtrim(BASE_URL,'/').'/'.ltrim($hotelImage,'/')) : '';
                ?>
                    <div style="border:1px solid #e0e7ef;border-radius:12px;padding:13px;background:#fbfdff">
                        <?php if ($hotelImageUrl !== ''): ?><img src="<?= qh($hotelImageUrl); ?>" alt="<?= qh($actual !== '' ? $actual : (string)($hotelRow['destination_name'] ?? 'Hotel')); ?>" style="width:100%;max-height:210px;object-fit:cover;border-radius:10px;margin-bottom:10px" loading="lazy"><?php endif; ?>
                        <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">
                            <strong><?= qh((string)($hotelRow['destination_name'] ?? '')); ?> · <?= max(1,(int)($hotelRow['nights'] ?? 1)); ?> Night<?= max(1,(int)($hotelRow['nights'] ?? 1))===1?'':'s'; ?></strong>
                            <span class="mini"><?= !empty($hotelRow['hotel_category']) ? (int)$hotelRow['hotel_category'].' Star' : qh(ucwords((string)($hotelRow['accommodation_type'] ?? 'Hotel'))); ?></span>
                        </div>
                        <div style="margin-top:6px;color:#34465c;font-weight:700"><?= qh($hotelText); ?></div>
                        <?php if (!empty($hotelRow['room_type']) || !empty($hotelRow['meal_plan'])): ?><div class="mini" style="margin-top:5px"><?= qh(trim((string)($hotelRow['room_type'] ?? ''))); ?><?= (!empty($hotelRow['room_type']) && !empty($hotelRow['meal_plan'])) ? ' · ' : ''; ?><?= qh(trim((string)($hotelRow['meal_plan'] ?? ''))); ?></div><?php endif; ?>
                        <?php if ($actual !== '' && ($hotelRow['status'] ?? '') === 'confirmed'): ?><div class="mini" style="margin-top:5px;color:#087952;font-weight:800">Confirmed accommodation<?= !empty($hotelRow['confirmation_reference']) ? ' · Ref '.$hotelRow['confirmation_reference'] : ''; ?></div><?php endif; ?>
                    </div>
                <?php endforeach; ?>
                </div>
                <p class="mini" style="margin-top:10px">Hotels shown as alternatives are subject to availability. A same/similar category property may be confirmed unless a specific property is explicitly marked confirmed.</p>
            </section>
            <?php endif; ?>

            <?php if ($transportAllocations): ?>
            <section class="section">
                <h2>Proposed Transport</h2>
                <?php foreach ($transportAllocations as $tr): if(!is_array($tr)) continue;
                    $vehicle=trim((string)($tr['vehicle_type']??''));
                    $alts=is_array($tr['alternatives']??null)?$tr['alternatives']:[];
                    $vehicleText=$vehicle!==''?$vehicle:($alts?implode(' / ',array_slice($alts,0,4)).' or similar / as per pax':'Vehicle to be confirmed as per supplier contract');
                ?>
                <div class="pricing-line" style="margin-bottom:10px">
                    <small><?= qh((string)($tr['route_label']??'Transport as per itinerary')); ?></small>
                    <strong><?= qh($vehicleText); ?></strong>
                    <div class="muted" style="font-size:11px;margin-top:4px">
                        <?= (int)($tr['pax_total']??0); ?> traveller(s)
                        <?php if(!empty($tr['ac_basis']) && $tr['ac_basis']!=='unspecified'): ?> · <?= qh(strtoupper(str_replace('_',' ',(string)$tr['ac_basis']))); ?><?php endif; ?>
                        <?php if(!empty($tr['service_date_from'])): ?> · <?= qh(qcpDate((string)$tr['service_date_from'])); ?><?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
                <p class="mini">Final vehicle number and driver details are issued after supplier confirmation.</p>
            </section>
            <?php endif; ?>

            <?php
            $quotationServices = is_array($snapshot['quotation_services'] ?? null) ? $snapshot['quotation_services'] : [];
            $otherQuotationServices = array_values(array_filter($quotationServices, static function($row): bool {
                if (!is_array($row)) return false;
                $type = strtolower((string)($row['service_type'] ?? 'other'));
                return !in_array($type, ['hotel','transport'], true) && strtolower((string)($row['status'] ?? '')) !== 'cancelled';
            }));
            ?>
            <?php if ($otherQuotationServices): ?>
            <section class="section">
                <h2>Other included services</h2>
                <div style="display:grid;gap:9px">
                    <?php foreach ($otherQuotationServices as $service): ?>
                        <div style="border:1px solid #e0e7ef;border-radius:12px;padding:12px;background:#fbfdff">
                            <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap">
                                <strong><?= qh((string)($service['title'] ?: ($service['service_label'] ?? 'Service'))); ?></strong>
                                <span class="mini"><?= qh((string)($service['service_label'] ?? ucwords(str_replace('_',' ',(string)($service['service_type'] ?? 'other'))))); ?></span>
                            </div>
                            <?php if (!empty($service['destination_name'])): ?><div class="mini" style="margin-top:4px"><?= qh((string)$service['destination_name']); ?></div><?php endif; ?>
                            <?php if (!empty($service['specifications'])): ?><div style="margin-top:5px;color:#34465c"><?= qnl((string)$service['specifications']); ?></div><?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <?php if ($flightSuggestions): ?>
            <section class="section">
                <h2>Suggested flight options</h2>
                <div class="suggestion-grid">
                <?php foreach ($flightSuggestions as $f): if(!is_array($f)) continue; ?>
                    <article class="suggestion-card flight">
                        <div class="suggestion-top"><div><div class="suggestion-title">Suggested Flight · Sector <?= (int)($f['sector_order'] ?? 1); ?></div><div class="suggestion-route"><?= qh((string)($f['origin_code'] ?? '')); ?> → <?= qh((string)($f['destination_code'] ?? '')); ?> · <?= qh(trim((string)($f['airline_name'] ?? '').' '.(string)($f['flight_number'] ?? ''))); ?></div></div><?php if(!empty($f['display_fare']) && (float)($f['fare_amount'] ?? 0)>0): ?><div class="suggestion-fare"><?= qh((string)($f['currency'] ?? 'INR')); ?> <?= number_format((float)$f['fare_amount'],2); ?>*</div><?php endif; ?></div>
                        <div class="suggestion-meta"><?php if(!empty($f['departure_at'])): ?><span class="suggestion-chip">Departure <?= qh(date('d M Y · H:i',strtotime((string)$f['departure_at']))); ?></span><?php endif; ?><?php if(!empty($f['arrival_at'])): ?><span class="suggestion-chip">Arrival <?= qh(date('d M Y · H:i',strtotime((string)$f['arrival_at']))); ?></span><?php endif; ?><span class="suggestion-chip"><?= (int)($f['stops'] ?? 0)===0?'Direct':(int)$f['stops'].' Stop(s)'; ?></span><?php if(!empty($f['cabin_class'])): ?><span class="suggestion-chip"><?= qh(ucwords(strtolower(str_replace('_',' ',(string)$f['cabin_class'])))); ?></span><?php endif; ?><?php if(!empty($f['baggage'])): ?><span class="suggestion-chip">Baggage <?= qh((string)$f['baggage']); ?></span><?php endif; ?></div>
                    </article>
                <?php endforeach; ?>
                </div>
                <div class="suggestion-note">Flight details are suggested for itinerary planning only. Schedules, availability, fares and baggage allowances may change until booking is confirmed and ticketed.</div>
            </section>
            <?php endif; ?>

            <?php if ($trainSuggestions): ?>
            <section class="section">
                <h2>Suggested train options</h2>
                <div class="suggestion-grid">
                <?php foreach ($trainSuggestions as $r): if(!is_array($r)) continue; ?>
                    <article class="suggestion-card train">
                        <div class="suggestion-top"><div><div class="suggestion-title">Suggested Train · Sector <?= (int)($r['sector_order'] ?? 1); ?></div><div class="suggestion-route"><?= qh((string)($r['origin_code'] ?? '')); ?> → <?= qh((string)($r['destination_code'] ?? '')); ?> · <?= qh(trim((string)($r['train_name'] ?? '').' '.(string)($r['train_number'] ?? ''))); ?></div></div><?php if(!empty($r['display_fare']) && (float)($r['fare_amount'] ?? 0)>0): ?><div class="suggestion-fare"><?= qh((string)($r['currency'] ?? 'INR')); ?> <?= number_format((float)$r['fare_amount'],2); ?>*</div><?php endif; ?></div>
                        <div class="suggestion-meta"><?php if(!empty($r['departure_at'])): ?><span class="suggestion-chip">Departure <?= qh(date('d M Y · H:i',strtotime((string)$r['departure_at']))); ?></span><?php endif; ?><?php if(!empty($r['arrival_at'])): ?><span class="suggestion-chip">Arrival <?= qh(date('d M Y · H:i',strtotime((string)$r['arrival_at']))); ?></span><?php endif; ?><?php if(!empty($r['travel_class'])): ?><span class="suggestion-chip">Class <?= qh((string)$r['travel_class']); ?></span><?php endif; ?><?php if(!empty($r['availability_text'])): ?><span class="suggestion-chip"><?= qh((string)$r['availability_text']); ?></span><?php endif; ?></div>
                    </article>
                <?php endforeach; ?>
                </div>
                <div class="suggestion-note">Train details are suggested for itinerary planning only. Schedule, availability, fare and class availability may change until the ticket is confirmed.</div>
            </section>
            <?php endif; ?>

            <?php if ($itinerary): ?>
            <section class="section">
                <h2>Day-wise itinerary</h2>
                <div class="days">
                    <?php foreach ($itinerary as $day): $dayImage = qasset($day['image'] ?? ''); ?>
                    <article class="day">
                        <div class="day-head">Day <?= (int)$day['day_number']; ?><?= trim((string)$day['title']) !== '' ? ' · ' . qh((string)$day['title']) : ''; ?></div>
                        <div class="day-body <?= $dayImage === '' ? 'noimg' : ''; ?>">
                            <?php if ($dayImage !== ''): ?><img class="day-img" src="<?= qh($dayImage); ?>" alt="Day <?= (int)$day['day_number']; ?>"><?php endif; ?>
                            <div class="day-copy"><?= qnl((string)$day['description']); ?></div>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <?php if ($inclusions !== ''): ?>
            <section class="section"><h2>Package inclusions</h2><div class="prose"><?= qnl($inclusions); ?></div></section>
            <?php endif; ?>

            <?php if ($exclusions !== ''): ?>
            <section class="section"><h2>Package exclusions</h2><div class="prose"><?= qnl($exclusions); ?></div></section>
            <?php endif; ?>

            <?php if ($customerNotes !== ''): ?>
            <section class="section"><h2>Customer-specific notes</h2><div class="prose"><?= qnl($customerNotes); ?></div></section>
            <?php endif; ?>

            <?php if ($terms !== ''): ?>
            <section class="section"><h2>Terms & conditions</h2><div class="prose"><?= qnl($terms); ?></div></section>
            <?php endif; ?>
        </main>

        <aside class="side">
            <div class="action-card">
                <h2>Your response</h2>
                <p>Review this exact quotation version and choose one option below.</p>

                <?php if ($acceptedBooking): ?>
                    <div class="statusbox">✓ Accepted<br>Booking: <?= qh((string)$acceptedBooking['booking_number']); ?></div>
                <?php elseif (!$isLatest): ?>
                    <div class="superseded">This quotation has been superseded by a newer version. Please use the latest quotation link.</div>
                <?php else: ?>
                    <form method="post" action="<?= qh($portalUrl); ?>" onsubmit="return window.qConfirmQuotation ? window.qConfirmQuotation(event) : true;">
                        <input type="hidden" name="csrf_token" value="<?= qh($csrf); ?>">
                        <textarea class="textarea" name="customer_note" placeholder="Optional for acceptance. For changes/rejection, please tell us the reason or what you want changed."></textarea>
                        <button class="btn accept" type="submit" name="decision" value="accepted" <?= !$responseReady ? 'disabled' : ''; ?> data-confirm="Accept this exact quotation and create your booking?">✓ Accept quotation & create booking</button>
                        <button class="btn change" type="submit" name="decision" value="change_requested" <?= !$responseReady ? 'disabled' : ''; ?> data-confirm="Send your requested changes to the TRAVSCOPE team?">✎ Request changes</button>
                        <button class="btn reject" type="submit" name="decision" value="rejected" <?= !$responseReady ? 'disabled' : ''; ?> data-confirm="Reject this quotation?">Reject quotation</button>
                    </form>
                <?php endif; ?>

                <?php if ($pdfUrl !== ''): ?>
                    <a class="btn pdf" target="_blank" rel="noopener" href="<?= qh($pdfUrl); ?>">↓ Download official PDF</a>
                <?php endif; ?>

                <div class="mini">This link is valid until <?= qh(date('d M Y, h:i A', $expires)); ?>. Your response is recorded against Quotation Version <?= (int)$context['version_number']; ?>.</div>

                <?php if ($sitePhone !== '' || $siteEmail !== ''): ?>
                <div class="contact"><strong>Need help?</strong><br><?= $sitePhone !== '' ? qh($sitePhone) . '<br>' : ''; ?><?= $siteEmail !== '' ? qh($siteEmail) : ''; ?></div>
                <?php endif; ?>
            </div>
        </aside>
    </div>
</div>
<?php endif; ?>
<?php require_once __DIR__ . '/credential-display.php'; echo tsCredentialsHtml($pdo, 'document'); ?>
<script>
window.qConfirmQuotation=function(ev){
    var submitter=ev.submitter;
    if(!submitter){return true;}
    var message=submitter.getAttribute('data-confirm')||'Submit this response?';
    return window.confirm(message);
};
</script>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
