<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);

    exit(
        "TRAVSCOPE Health Check is CLI-only.\n"
    );
}

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/health-functions.php';

$jobFunctions =
    __DIR__
    . '/job-functions.php';

if (is_file($jobFunctions)) {
    require_once
        $jobFunctions;
}

$job =
    function_exists('tsJobBegin')
        ? tsJobBegin(
            $pdo,
            'health_scan'
        )
        : [
            'tracked' => false,
            'acquired' => true,
            'disabled' => false,
            'job_key' =>
                'health_scan',
            'started_at' =>
                microtime(true),
        ];

if (!empty($job['disabled'])) {
    echo
        "Health scan is disabled in System Jobs Control Center.\n";

    exit(0);
}

if (empty($job['acquired'])) {
    fwrite(
        STDERR,
        "Overlap prevented: another Health cron is still running.\n"
    );

    exit(4);
}

try {
    $scan =
        tsHealthScan(
            $pdo
        );

    echo
        json_encode(
            $scan,
            JSON_PRETTY_PRINT
            | JSON_UNESCAPED_UNICODE
            | JSON_UNESCAPED_SLASHES
        )
        . PHP_EOL;

    $fail =
        (int)$scan[
            'summary'
        ]['fail'];

    $warning =
        (int)$scan[
            'summary'
        ]['warning'];

    if ($fail > 0) {
        if (function_exists('tsJobFinish')) {
            tsJobFinish(
                $pdo,
                $job,
                'failure',
                2,
                'System Health scan found '
                    . $fail
                    . ' FAIL and '
                    . $warning
                    . ' WARNING result(s).',
                [
                    'summary' =>
                        (array)$scan[
                            'summary'
                        ],
                ]
            );
        }

        exit(2);
    }

    if ($warning > 0) {
        if (function_exists('tsJobFinish')) {
            tsJobFinish(
                $pdo,
                $job,
                'warning',
                1,
                'System Health scan found '
                    . $warning
                    . ' WARNING result(s).',
                [
                    'summary' =>
                        (array)$scan[
                            'summary'
                        ],
                ]
            );
        }

        exit(1);
    }

    if (function_exists('tsJobFinish')) {
        tsJobFinish(
            $pdo,
            $job,
            'success',
            0,
            'System Health scan passed without FAIL or WARNING results.',
            [
                'summary' =>
                    (array)$scan[
                        'summary'
                    ],
            ]
        );
    }

    exit(0);

} catch (Throwable $e) {
    if (function_exists('tsJobFinish')) {
        tsJobFinish(
            $pdo,
            $job,
            'failure',
            3,
            'TRAVSCOPE health scan failed: '
                . $e->getMessage()
        );
    }

    fwrite(
        STDERR,
        'TRAVSCOPE health scan failed: '
        . $e->getMessage()
        . PHP_EOL
    );

    exit(3);
}
