<?php

declare(strict_types=1);

$hotelAllocationFunctionsFile = __DIR__ . '/hotel-allocation-functions.php';
if (is_file($hotelAllocationFunctionsFile)) require_once $hotelAllocationFunctionsFile;

/*
|--------------------------------------------------------------------------
| TRAVSCOPE CUSTOMER QUOTATION PORTAL HELPERS
| VERSION: 2026-09-09-R1
|--------------------------------------------------------------------------
*/

if (!function_exists('crmCustomerPackageSnapshot')) {
    function crmCustomerPackageSnapshot(?string $json): array
    {
        $data = json_decode((string)$json, true);
        return is_array($data) ? $data : [];
    }
}

function qcpSecret(): string
{
    foreach ([
        defined('APP_KEY') ? (string)APP_KEY : '',
        defined('GOOGLE_CLIENT_SECRET') ? (string)GOOGLE_CLIENT_SECRET : '',
        defined('SMTP_PASSWORD') ? (string)SMTP_PASSWORD : '',
    ] as $candidate) {
        $candidate = trim($candidate);
        if ($candidate !== '') {
            return hash('sha256', 'travscope-customer-quotation|' . $candidate);
        }
    }

    return hash(
        'sha256',
        (defined('BASE_URL') ? (string)BASE_URL : 'TRAVSCOPE')
        . '|customer-quotation-portal'
    );
}

function qcpToken(int $leadId, int $versionId, int $expires): string
{
    return hash_hmac(
        'sha256',
        'v1:' . $leadId . ':' . $versionId . ':' . $expires,
        qcpSecret()
    );
}

function qcpTokenValid(
    int $leadId,
    int $versionId,
    int $expires,
    string $token
): bool {
    if (
        $leadId <= 0
        || $versionId <= 0
        || $expires <= 0
        || trim($token) === ''
        || $expires < time()
    ) {
        return false;
    }

    return hash_equals(
        qcpToken($leadId, $versionId, $expires),
        trim($token)
    );
}

function qcpCustomerQuotationUrl(
    int $leadId,
    int $versionId,
    int $validDays = 30
): string {
    $validDays = max(1, min(90, $validDays));
    $expires = time() + ($validDays * 86400);

    return BASE_URL
        . 'quotation.php?lead=' . $leadId
        . '&version=' . $versionId
        . '&expires=' . $expires
        . '&token=' . rawurlencode(qcpToken($leadId, $versionId, $expires));
}

/*
| Existing admin-crm.php PDF signature compatibility.
| This lets the customer portal retain the exact PDF renderer already used
| by TRAVSCOPE without exposing an admin session.
*/
function qcpLegacyPdfSecret(): string
{
    foreach ([
        defined('APP_KEY') ? (string)APP_KEY : '',
        defined('GOOGLE_CLIENT_SECRET') ? (string)GOOGLE_CLIENT_SECRET : '',
        defined('SMTP_PASSWORD') ? (string)SMTP_PASSWORD : '',
    ] as $candidate) {
        $candidate = trim($candidate);
        if ($candidate !== '') {
            return hash('sha256', 'travscope-crm-quotation|' . $candidate);
        }
    }

    /*
     * The current production config has a configured application/mail secret.
     * This fallback is intentionally not used to manufacture a mismatched PDF
     * signature when those secrets are absent.
     */
    return '';
}

function qcpLegacyPdfToken(int $leadId, int $versionId): string
{
    $secret = qcpLegacyPdfSecret();
    if ($secret === '') {
        return '';
    }

    return hash_hmac(
        'sha256',
        $leadId . ':' . $versionId,
        $secret
    );
}

function qcpPdfUrl(int $leadId, int $versionId): string
{
    $token = qcpLegacyPdfToken($leadId, $versionId);
    if ($token === '') {
        return '';
    }

    return BASE_URL
        . 'admin-crm.php?lead=' . $leadId
        . '&quotation_pdf=1&version=' . $versionId
        . '&token=' . rawurlencode($token);
}

function qcpResponseTableReady(PDO $pdo): bool
{
    if (function_exists('crmTableExists')) {
        return crmTableExists($pdo, 'quotation_customer_responses');
    }

    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'quotation_customer_responses'");
        $stmt->execute();
        return (int)$stmt->fetchColumn() > 0;
    } catch (Throwable $e) {
        return false;
    }
}

function qcpNormalizeItinerary(array $days): array
{
    $out = [];
    foreach ($days as $index => $day) {
        if (!is_array($day)) {
            continue;
        }

        $title = trim((string)($day['title'] ?? ''));
        $description = trim((string)($day['description'] ?? ''));
        $image = trim((string)($day['image'] ?? ''));

        if ($title === '' && $description === '' && $image === '') {
            continue;
        }

        $out[] = [
            'day_number' => max(1, (int)($day['day_number'] ?? ($index + 1))),
            'title' => $title,
            'description' => $description,
            'image' => $image,
        ];
    }

    usort(
        $out,
        static fn(array $a, array $b): int => ((int)$a['day_number']) <=> ((int)$b['day_number'])
    );

    return array_values($out);
}

function qcpSnapshot(PDO $pdo, array $version): array
{
    $snapshot = crmCustomerPackageSnapshot((string)($version['custom_notes'] ?? ''));
    $packageId = max(0, (int)($snapshot['source_package_id'] ?? $version['package_id'] ?? 0));

    $days = is_array($snapshot['itinerary_days'] ?? null)
        ? qcpNormalizeItinerary($snapshot['itinerary_days'])
        : [];

    if (!$days) {
        $legacy = json_decode((string)($version['itinerary'] ?? ''), true);
        if (is_array($legacy)) {
            $days = qcpNormalizeItinerary($legacy);
        }
    }

    if ($packageId > 0 && function_exists('crmTableExists') && crmTableExists($pdo, 'packages')) {
        $stmt = $pdo->prepare('SELECT * FROM packages WHERE id = ? LIMIT 1');
        $stmt->execute([$packageId]);
        $package = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

        foreach ([
            'package_code', 'package_type', 'short_description', 'description',
            'duration_days', 'duration_nights', 'currency', 'main_image',
            'tour_highlights', 'inclusions', 'exclusions', 'terms'
        ] as $key) {
            $current = $snapshot[$key] ?? null;
            $missing = $current === null || $current === '';
            if (in_array($key, ['duration_days', 'duration_nights'], true)) {
                $missing = $missing || (int)$current <= 0;
            }
            if ($missing && array_key_exists($key, $package)) {
                $snapshot[$key] = $package[$key];
            }
        }

        if (!$days && crmTableExists($pdo, 'package_itinerary_days')) {
            $stmt = $pdo->prepare('SELECT day_number,title,description,image FROM package_itinerary_days WHERE package_id = ? ORDER BY sort_order ASC, day_number ASC, id ASC');
            $stmt->execute([$packageId]);
            $days = qcpNormalizeItinerary($stmt->fetchAll(PDO::FETCH_ASSOC) ?: []);
        }
    }

    if ($days) {
        $snapshot['itinerary_days'] = $days;
    }

    if (function_exists('tsHAForQuotation') && function_exists('tsHACustomerSafeRows')) {
        try {
            $snapshot['hotel_allocations'] = tsHACustomerSafeRows(
                tsHAForQuotation($pdo, (int)($version['id'] ?? 0))
            );
        } catch (Throwable $e) {
            error_log('Customer quotation hotel allocations: ' . $e->getMessage());
        }
    }


    if (function_exists('tsTAForQuotation') && function_exists('tsTACustomerSafeRows')) {
        try {
            $snapshot['transport_allocations'] = tsTACustomerSafeRows(
                tsTAForQuotation($pdo, (int)($version['id'] ?? 0))
            );
        } catch (Throwable $e) {
            error_log('Customer quotation transport allocations: ' . $e->getMessage());
        }
    }

    return $snapshot;
}

function qcpContext(PDO $pdo, int $leadId, int $versionId): ?array
{
    $stmt = $pdo->prepare("\n        SELECT\n            v.*,\n            e.name AS customer_name,\n            e.email AS customer_email,\n            e.mobile AS customer_mobile,\n            e.destination AS customer_destination,\n            e.destination_id AS customer_destination_id,\n            e.user_id AS customer_user_id,\n            t.id AS trip_id,\n            t.trip_code,\n            t.trip_title,\n            t.stage AS trip_stage,\n            t.owner_admin_id\n        FROM crm_package_versions v\n        INNER JOIN enquiries e ON e.id = v.lead_id\n        LEFT JOIN trips t ON t.enquiry_id = e.id\n        WHERE v.id = ? AND v.lead_id = ?\n        LIMIT 1\n    ");
    $stmt->execute([$versionId, $leadId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        return null;
    }

    $latestStmt = $pdo->prepare('SELECT MAX(version_number) FROM crm_package_versions WHERE lead_id = ?');
    $latestStmt->execute([$leadId]);
    $row['latest_version_number'] = (int)($latestStmt->fetchColumn() ?: 0);

    $row['snapshot'] = qcpSnapshot($pdo, $row);

    $accepted = null;
    if (function_exists('crmBookingAcceptanceByVersion')) {
        $accepted = crmBookingAcceptanceByVersion($pdo, $versionId);
    }
    $row['accepted_booking'] = $accepted;

    return $row;
}

function qcpClientIp(): string
{
    $ip = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
    return mb_substr($ip, 0, 64);
}

function qcpLogResponse(
    PDO $pdo,
    int $leadId,
    ?int $tripId,
    int $versionId,
    ?int $bookingId,
    string $decision,
    string $note
): void {
    if (!qcpResponseTableReady($pdo)) {
        return;
    }

    $stmt = $pdo->prepare("\n        INSERT INTO quotation_customer_responses\n        (\n            lead_id, trip_id, quotation_version_id, booking_id, decision,\n            customer_note, customer_ip, user_agent, created_at\n        )\n        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())\n    ");

    $stmt->execute([
        $leadId,
        $tripId && $tripId > 0 ? $tripId : null,
        $versionId,
        $bookingId && $bookingId > 0 ? $bookingId : null,
        $decision,
        trim($note) !== '' ? trim($note) : null,
        qcpClientIp() ?: null,
        mb_substr(trim((string)($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 500) ?: null,
    ]);
}

function qcpLogCrmActivity(
    PDO $pdo,
    int $leadId,
    string $subject,
    string $details
): void {
    if (!function_exists('crmTableExists') || !crmTableExists($pdo, 'crm_activities')) {
        return;
    }

    $stmt = $pdo->prepare("\n        INSERT INTO crm_activities\n        (lead_id, admin_id, activity_type, subject, details, follow_up_at, completed_at, created_at)\n        VALUES (?, NULL, 'quotation', ?, ?, NULL, NULL, NOW())\n    ");
    $stmt->execute([
        $leadId,
        mb_substr(trim($subject), 0, 180),
        trim($details) !== '' ? trim($details) : null,
    ]);
}

function qcpNotifyAdmins(
    PDO $pdo,
    array $context,
    string $decision,
    string $note,
    ?int $bookingId = null,
    string $bookingNumber = ''
): void {
    if (!function_exists('crmTableExists') || !crmTableExists($pdo, 'admin_notifications')) {
        return;
    }

    $leadId = (int)$context['lead_id'];
    $versionId = (int)$context['id'];
    $versionNumber = (int)$context['version_number'];
    $customer = trim((string)$context['customer_name']) ?: 'Customer';

    $adminIds = [];
    $ownerId = max(0, (int)($context['owner_admin_id'] ?? 0));
    if ($ownerId > 0) {
        $adminIds[] = $ownerId;
    }

    if (crmTableExists($pdo, 'crm_lead_meta')) {
        $stmt = $pdo->prepare('SELECT assigned_admin_id FROM crm_lead_meta WHERE enquiry_id = ? LIMIT 1');
        $stmt->execute([$leadId]);
        $assignedId = max(0, (int)($stmt->fetchColumn() ?: 0));
        if ($assignedId > 0) {
            $adminIds[] = $assignedId;
        }
    }

    if (!$adminIds && crmTableExists($pdo, 'admins')) {
        $stmt = $pdo->query("SELECT id FROM admins WHERE status = 'active' ORDER BY FIELD(role,'super_admin','admin','staff'), id ASC LIMIT 5");
        $adminIds = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN) ?: []);
    }

    $adminIds = array_values(array_unique(array_filter($adminIds)));
    if (!$adminIds) {
        return;
    }

    $map = [
        'accepted' => [
            'severity' => 'info',
            'title' => 'Customer accepted quotation',
            'message' => $customer . ' accepted Quotation V' . $versionNumber
                . ($bookingNumber !== '' ? ' · Booking ' . $bookingNumber . ' created.' : '.'),
        ],
        'change_requested' => [
            'severity' => 'warning',
            'title' => 'Quotation change requested',
            'message' => $customer . ' requested changes to Quotation V' . $versionNumber . '.',
        ],
        'rejected' => [
            'severity' => 'high',
            'title' => 'Customer rejected quotation',
            'message' => $customer . ' rejected Quotation V' . $versionNumber . '.',
        ],
    ];

    $info = $map[$decision] ?? $map['change_requested'];
    if (trim($note) !== '') {
        $info['message'] .= ' Note: ' . mb_substr(trim($note), 0, 350);
    }

    $link = !empty($context['trip_id'])
        ? BASE_URL . 'admin-trip-commercial-hub.php?trip_id=' . (int)$context['trip_id']
        : BASE_URL . 'admin-crm.php?lead=' . $leadId . '#packageProposal';

    $sql = "\n        INSERT INTO admin_notifications\n        (\n            admin_id, notification_key, source_key, category, severity, escalation_level,\n            title, message, entity_type, entity_id, link_url, source_table, source_id,\n            due_at, status, first_detected_at, last_detected_at, meta_json\n        )\n        VALUES (?, ?, 'customer_quotation', 'quotation', ?, 0, ?, ?, 'quotation_version', ?, ?, 'crm_package_versions', ?, NOW(), 'unread', NOW(), NOW(), ?)\n        ON DUPLICATE KEY UPDATE\n            severity = VALUES(severity),\n            title = VALUES(title),\n            message = VALUES(message),\n            link_url = VALUES(link_url),\n            source_id = VALUES(source_id),\n            status = 'unread',\n            read_at = NULL,\n            dismissed_at = NULL,\n            resolved_at = NULL,\n            due_at = NOW(),\n            last_detected_at = NOW(),\n            meta_json = VALUES(meta_json)\n    ";

    $stmt = $pdo->prepare($sql);
    foreach ($adminIds as $adminId) {
        $key = 'customer_quote:' . $versionId . ':' . $decision;
        $meta = json_encode([
            'lead_id' => $leadId,
            'quotation_version_id' => $versionId,
            'version_number' => $versionNumber,
            'decision' => $decision,
            'booking_id' => $bookingId,
            'booking_number' => $bookingNumber,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        $stmt->execute([
            $adminId,
            $key,
            $info['severity'],
            $info['title'],
            $info['message'],
            $versionId,
            $link,
            $versionId,
            $meta,
        ]);
    }
}

function qcpUpdateSalesForResponse(
    PDO $pdo,
    int $leadId,
    ?int $tripId,
    string $decision,
    string $note
): void {
    if ($decision === 'change_requested') {
        if ($tripId && $tripId > 0 && function_exists('crmTableExists') && crmTableExists($pdo, 'trips')) {
            $stmt = $pdo->prepare("UPDATE trips SET stage='negotiation', probability=70, next_action='Revise quotation requested by customer', next_action_date=CURDATE(), updated_at=NOW() WHERE id=? AND enquiry_id=?");
            $stmt->execute([$tripId, $leadId]);
        }
        $stmt = $pdo->prepare("UPDATE enquiries SET status='proposal', admin_notes=CONCAT(COALESCE(admin_notes,''), ?) WHERE id=?");
        $stmt->execute(["\n\nCustomer requested quotation changes on " . date('d M Y h:i A') . (trim($note) !== '' ? ': ' . trim($note) : '.'), $leadId]);
        return;
    }

    if ($decision === 'rejected') {
        if ($tripId && $tripId > 0 && function_exists('crmTableExists') && crmTableExists($pdo, 'trips')) {
            $stmt = $pdo->prepare("UPDATE trips SET stage='negotiation', probability=35, next_action='Follow up after customer rejected quotation', next_action_date=CURDATE(), updated_at=NOW() WHERE id=? AND enquiry_id=?");
            $stmt->execute([$tripId, $leadId]);
        }
        $stmt = $pdo->prepare("UPDATE enquiries SET status='follow_up', admin_notes=CONCAT(COALESCE(admin_notes,''), ?) WHERE id=?");
        $stmt->execute(["\n\nCustomer rejected quotation on " . date('d M Y h:i A') . (trim($note) !== '' ? ': ' . trim($note) : '.'), $leadId]);
    }
}

function qcpMoney(float $amount, string $currency = 'INR'): string
{
    $currency = strtoupper(trim($currency)) ?: 'INR';
    $symbol = $currency === 'INR' ? '₹' : $currency . ' ';
    return $symbol . number_format($amount, 2);
}

function qcpDate(?string $date): string
{
    $date = trim((string)$date);
    if ($date === '') {
        return 'To be confirmed';
    }

    $ts = strtotime($date);
    return $ts ? date('d M Y', $ts) : $date;
}
