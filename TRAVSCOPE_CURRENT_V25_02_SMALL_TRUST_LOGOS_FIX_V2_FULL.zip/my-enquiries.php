<?php
require_once __DIR__ . '/config.php';
requireLogin();

$user = currentUser($pdo);
if (!$user) {
    unset($_SESSION['user_id']);
    session_regenerate_id(true);
    redirect(BASE_URL . 'login.php');
}

if (strtolower((string)($user['status'] ?? '')) !== 'active') {
    unset($_SESSION['user_id']);
    session_regenerate_id(true);
    setFlash('error', 'Your account is currently unavailable.');
    redirect(BASE_URL . 'login.php');
}

if ((int)($user['email_verified'] ?? 0) !== 1) {
    $_SESSION['pending_verify_user_id'] = (int)$user['id'];
    $_SESSION['pending_verify_email'] = (string)$user['email'];
    $_SESSION['pending_verify_name'] = (string)$user['full_name'];
    unset($_SESSION['user_id']);
    redirect(BASE_URL . 'verify-email.php');
}

$userId = (int)$user['id'];
$email = strtolower(trim((string)$user['email']));
$fullName = trim((string)$user['full_name']);
$firstName = trim(explode(' ', $fullName)[0] ?? $fullName);
if ($firstName === '') $firstName = 'Traveller';
$userInitial = strtoupper(substr($firstName, 0, 1));
$siteName = getSetting($pdo, 'site_name', 'TRAVSCOPE.COM');
$search = trim((string)($_GET['q'] ?? ''));

$mobile = preg_replace('/[^0-9]/', '', (string)($user['mobile'] ?? ''));
$mobileLast10 = strlen($mobile) >= 10 ? substr($mobile, -10) : $mobile;

/*
|--------------------------------------------------------------------------
| IMPORTANT
|--------------------------------------------------------------------------
| Current enquiries table has no user_id column.
| Therefore historical enquiries are securely matched to the logged-in
| customer's registered email address or normalized mobile number.
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN status='new' THEN 1 ELSE 0 END) AS new_count,
        SUM(CASE WHEN status IN ('contacted','follow_up') THEN 1 ELSE 0 END) AS active_count
    FROM enquiries
    WHERE (
        LOWER(TRIM(email)) = ?
        OR (
            ? <> ''
            AND RIGHT(
                REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                    TRIM(COALESCE(mobile, '')),
                    ' ', ''), '-', ''), '(', ''), ')', ''), '+', ''),
                10
            ) = ?
        )
    )
");
$stmt->execute([$email, $mobileLast10, $mobileLast10]);
$stats = $stmt->fetch() ?: [];

$total = (int)($stats['total'] ?? 0);
$newCount = (int)($stats['new_count'] ?? 0);
$activeCount = (int)($stats['active_count'] ?? 0);


$stmt = $pdo->prepare("
    SELECT
        e.id,
        e.package_id,
        e.name,
        e.email,
        e.mobile,
        e.destination,
        e.travel_date,
        e.adults,
        e.children,
        e.budget,
        e.message,
        e.status,
        e.admin_notes,
        e.created_at,
        e.updated_at,
        p.title AS package_title,
        p.slug AS package_slug,
        p.package_code,
        p.main_image
    FROM enquiries e
    LEFT JOIN packages p ON p.id = e.package_id
    WHERE (
        LOWER(TRIM(e.email)) = ?
        OR (
            ? <> ''
            AND RIGHT(
                REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                    TRIM(COALESCE(e.mobile, '')),
                    ' ', ''), '-', ''), '(', ''), ')', ''), '+', ''),
                10
            ) = ?
        )
    )
      AND (
          ? = ''
          OR p.title LIKE ?
          OR p.package_code LIKE ?
      )
    ORDER BY e.id DESC
");
$searchLike = '%' . $search . '%';
$stmt->execute([$email, $mobileLast10, $mobileLast10, $search, $searchLike, $searchLike]);
$enquiries = $stmt->fetchAll();

function enquiryStatusLabel(string $status): string {
    return match ($status) {
        'new' => 'New',
        'contacted' => 'Contacted',
        'follow_up' => 'Follow Up',
        'converted' => 'Converted',
        'closed' => 'Closed',
        default => ucwords(str_replace('_', ' ', $status))
    };
}

function enquiryStatusClass(string $status): string {
    return match ($status) {
        'new' => 'st-new',
        'contacted' => 'st-contacted',
        'follow_up' => 'st-follow',
        'converted' => 'st-converted',
        'closed' => 'st-closed',
        default => 'st-new'
    };
}

function enquiryImage(?string $image): string {
    $image = trim((string)$image);
    if ($image === '') {
        return 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=900&q=85';
    }
    if (preg_match('#^https?://#i', $image)) return $image;
    return BASE_URL . ltrim($image, '/');
}

function enquiryDate(?string $date, string $format='d M Y'): string {
    if (!$date) return 'Not specified';
    $time = strtotime($date);
    return $time ? date($format, $time) : 'Not specified';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#07192d">
<title>My Enquiries | <?= e($siteName); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
:root{--navy:#07192d;--primary:#0b74ff;--cyan:#00b8ff;--bg:#f5f8fc;--text:#172033;--muted:#778294;--border:#e5eaf0;--green:#0aa66a;--orange:#ed8c21;--red:#df4859;--purple:#7657d5;--shadow:0 12px 35px rgba(7,25,45,.07)}
*{box-sizing:border-box;margin:0;padding:0}body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh}a{text-decoration:none;color:inherit}
.sidebar{position:fixed;left:0;top:0;bottom:0;width:265px;background:linear-gradient(180deg,#07192d,#061525);color:#fff;overflow-y:auto;z-index:1200;transition:.25s}
.logo{height:80px;padding:0 23px;display:flex;align-items:center;gap:11px;border-bottom:1px solid rgba(255,255,255,.08);font:800 20px 'Manrope'}
.logo-icon{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:linear-gradient(135deg,var(--primary),var(--cyan))}.logo span{color:#63b4ff}
.user{padding:22px 18px 17px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;gap:11px;align-items:center}.avatar{width:43px;height:43px;border-radius:50%;display:grid;place-items:center;background:rgba(99,180,255,.13);color:#78c0ff;font-weight:800}.user strong{font-size:12px}.user small{display:block;color:#7f93a9;font-size:9px;margin-top:3px}
.menu{padding:17px 13px 35px}.mt{padding:15px 13px 8px;color:#627990;font-size:9px;font-weight:800;letter-spacing:1.4px}.ml{min-height:47px;padding:0 14px;margin-bottom:4px;border-radius:10px;display:flex;align-items:center;gap:13px;color:#aebdcc;font-size:12px;font-weight:600}.ml i{width:19px;text-align:center}.ml:hover,.ml.active{color:#fff;background:rgba(11,116,255,.18)}.ml.active i{color:#63b4ff}
.main{margin-left:265px}.topbar{height:80px;padding:0 30px;position:sticky;top:0;z-index:900;background:rgba(255,255,255,.96);backdrop-filter:blur(12px);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}.top-left{display:flex;align-items:center;gap:13px}.topbar strong{display:block;color:var(--navy);font-size:13px}.topbar small{color:var(--muted);font-size:9px}.mobile{display:none;width:42px;height:42px;border:0;border-radius:10px;background:#edf4fb;color:var(--navy)}.explore{padding:12px 15px;border-radius:10px;background:var(--primary);color:#fff;font-size:11px;font-weight:700}
.content{padding:30px}.hero{padding:30px;margin-bottom:22px;border-radius:20px;background:linear-gradient(120deg,#07192d,#0a3b68);color:#fff;display:flex;justify-content:space-between;align-items:center;gap:20px;box-shadow:0 18px 50px rgba(7,25,45,.12)}.hero h1{font:800 30px 'Manrope'}.hero p{max-width:620px;margin-top:7px;color:rgba(255,255,255,.68);font-size:11px;line-height:1.7}.hero-icon{width:70px;height:70px;flex:0 0 70px;border-radius:18px;display:grid;place-items:center;background:rgba(255,255,255,.1);font-size:27px}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:15px;margin-bottom:22px}.stat{padding:18px;background:#fff;border:1px solid var(--border);border-radius:14px;box-shadow:var(--shadow)}.stat span{color:var(--muted);font-size:9px;font-weight:800;text-transform:uppercase}.stat strong{display:block;margin-top:8px;font:800 25px 'Manrope';color:var(--navy)}

.search-panel{background:#fff;border:1px solid var(--border);border-radius:17px;padding:20px;margin-bottom:22px;box-shadow:var(--shadow)}
.search-title{font:800 15px 'Manrope';color:var(--navy);margin-bottom:5px}.search-sub{color:var(--muted);font-size:9px;margin-bottom:14px}
.search-form{display:flex;gap:10px}.search-wrap{position:relative;flex:1}.search-wrap i{position:absolute;left:16px;top:50%;transform:translateY(-50%);color:#8997a8}
.search-input{width:100%;height:48px;border:1px solid #dce4ed;border-radius:11px;padding:0 15px 0 43px;font:500 11px 'DM Sans';outline:none}.search-input:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(11,116,255,.08)}
.search-btn,.clear-btn{height:48px;border:0;border-radius:11px;padding:0 20px;display:inline-flex;align-items:center;justify-content:center;gap:7px;font-size:10px;font-weight:800;cursor:pointer}.search-btn{background:#0b74ff!important;color:#fff!important}.clear-btn{background:#edf2f7;color:#526175}
.search-result{margin-top:11px;font-size:9px;color:#687689}.package-code{display:inline-block;margin-top:6px;padding:4px 7px;border-radius:6px;background:#eaf4ff;color:#0b67cf;font-size:8px;font-weight:800}

.section{background:#fff;border:1px solid var(--border);border-radius:17px;overflow:hidden;box-shadow:var(--shadow)}.head{min-height:68px;padding:0 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}.head h2{font:800 16px 'Manrope';color:var(--navy)}.head p{margin-top:3px;color:var(--muted);font-size:9px}
.list{padding:18px;display:grid;gap:15px}.card{border:1px solid var(--border);border-radius:15px;overflow:hidden;background:#fff}.card-main{padding:17px;display:grid;grid-template-columns:105px 1fr;gap:17px}.image{width:105px;height:105px;border-radius:12px;overflow:hidden;background:#edf2f7}.image img{width:100%;height:100%;object-fit:cover}.card-top{display:flex;justify-content:space-between;align-items:flex-start;gap:12px}.package{font:800 14px 'Manrope';color:var(--navy)}.destination{margin-top:5px;color:#738195;font-size:9px}.status{padding:6px 10px;border-radius:50px;font-size:8px;font-weight:800;text-transform:uppercase;white-space:nowrap}.st-new{background:#eaf4ff;color:#0b67cf}.st-contacted{background:#f1edff;color:#6846c5}.st-follow{background:#fff3e5;color:#b96b12}.st-converted{background:#e9faf2;color:#078652}.st-closed{background:#f0f2f5;color:#687484}
.details{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:13px}.detail{padding:9px;border-radius:9px;background:#f7f9fc}.detail span{display:block;color:#98a3b0;font-size:7px;text-transform:uppercase}.detail strong{display:block;margin-top:3px;color:#536176;font-size:9px}
.message{margin-top:12px;color:#5f6b7c;font-size:10px;line-height:1.7;white-space:pre-line}.submitted{margin-top:10px;color:#929dac;font-size:8px}
.admin-response{padding:14px 17px;border-top:1px solid #d8e7f8;background:#f4f9ff}.response-head{display:flex;align-items:center;gap:7px;color:#0b5fc2;font-size:9px;font-weight:800}.response-text{margin-top:7px;color:#42556d;font-size:10px;line-height:1.7;white-space:pre-line}
.empty{padding:55px 20px;text-align:center}.empty-icon{width:65px;height:65px;margin:0 auto 14px;border-radius:18px;display:grid;place-items:center;background:#eaf4ff;color:var(--primary);font-size:25px}.empty h3{font:800 17px 'Manrope';color:var(--navy)}.empty p{max-width:450px;margin:7px auto 16px;color:var(--muted);font-size:10px;line-height:1.7}.empty a{display:inline-flex;padding:11px 15px;border-radius:9px;background:var(--primary);color:#fff;font-size:9px;font-weight:800}
.overlay{display:none;position:fixed;inset:0;background:rgba(2,10,18,.55);z-index:1150}
@media(max-width:1050px){.stats{grid-template-columns:repeat(2,1fr)}.details{grid-template-columns:repeat(2,1fr)}}
@media(max-width:850px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:none}.overlay.show{display:block}.main{margin-left:0}.mobile{display:grid;place-items:center}.content{padding:20px}}
@media(max-width:650px){.search-form{flex-wrap:wrap}.search-wrap{flex-basis:100%}.search-btn,.clear-btn{flex:1}.topbar{height:70px;padding:0 14px}.topbar .labels{display:none}.content{padding:15px}.hero{padding:24px}.hero-icon{display:none}.stats{grid-template-columns:1fr 1fr}.card-main{grid-template-columns:1fr}.image{width:100%;height:180px}.details{grid-template-columns:1fr 1fr}}


/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-public-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="public"></script>
</head>
<body>
<div class="overlay" id="overlay"></div>

<aside class="sidebar" id="sidebar">
<a href="<?=e(BASE_URL)?>" class="logo"><span class="logo-icon"><i class="fa-solid fa-plane"></i></span>TRAV<span>SCOPE</span></a>
<div class="user"><div class="avatar"><?=e($userInitial)?></div><div><strong><?=e($fullName)?></strong><small>TRAVSCOPE Traveller</small></div></div>
<nav class="menu">
<div class="mt">MY TRAVSCOPE</div>
<a class="ml" href="dashboard.php"><i class="fa-solid fa-house"></i>Dashboard</a>
<a class="ml" href="packages.php"><i class="fa-solid fa-compass"></i>Explore Packages</a>
<a class="ml" href="my-bookings.php"><i class="fa-solid fa-suitcase-rolling"></i>My Bookings</a>
<a class="ml" href="wishlist.php"><i class="fa-regular fa-heart"></i>Wishlist</a>
<div class="mt">TRIP SUPPORT</div>
<a class="ml active" href="my-enquiries.php"><i class="fa-regular fa-message"></i>My Enquiries</a>
<a class="ml" href="reviews.php"><i class="fa-regular fa-star"></i>My Reviews</a>
<div class="mt">ACCOUNT</div>
<a class="ml" href="profile.php"><i class="fa-regular fa-user"></i>My Profile</a>
<a class="ml" href="change-password.php"><i class="fa-solid fa-lock"></i>Security</a>
<a class="ml" href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i>Logout</a>
</nav>
</aside>

<main class="main">
<header class="topbar">
<div class="top-left">
<button class="mobile" id="mobile"><i class="fa-solid fa-bars"></i></button>
<div class="labels"><strong>My Enquiries</strong><small>Track your travel requests and TRAVSCOPE follow-up.</small></div>
</div>
<a class="explore" href="packages.php"><i class="fa-solid fa-compass"></i> Explore Trips</a>
</header>

<div class="content">
<section class="hero">
<div><h1>My Travel Enquiries</h1><p>Keep track of the travel enquiries submitted using your registered email address, including trip details and the latest response from our team.</p></div>
<div class="hero-icon"><i class="fa-regular fa-message"></i></div>
</section>

<section class="stats">
<div class="stat"><span>Total Enquiries</span><strong><?=number_format($total)?></strong></div>
<div class="stat"><span>New</span><strong><?=number_format($newCount)?></strong></div>
<div class="stat"><span>In Progress</span><strong><?=number_format($activeCount)?></strong></div>
<a class="stat" href="my-bookings.php"><span>Converted Trips</span><strong><i class="fa-solid fa-arrow-right"></i></strong></a>
</section>

<section class="search-panel">
<div class="search-title"><i class="fa-solid fa-magnifying-glass"></i> Search Previous Enquiry</div>
<div class="search-sub">Search your enquiry history using the package name or package code.</div>
<form class="search-form" method="get" action="my-enquiries.php">
<div class="search-wrap">
<i class="fa-solid fa-magnifying-glass"></i>
<input class="search-input" type="search" name="q" value="<?=e($search)?>" placeholder="Enter package name or package code..." autocomplete="off">
</div>
<button class="search-btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
<?php if($search !== ''): ?><a class="clear-btn" href="my-enquiries.php"><i class="fa-solid fa-xmark"></i> Clear</a><?php endif; ?>
</form>
<?php if($search !== ''): ?><div class="search-result">Found <?=number_format(count($enquiries))?> result(s) for “<?=e($search)?>”.</div><?php endif; ?>
</section>

<section class="section">
<div class="head"><div><h2>Enquiry History</h2><p><?= $search !== '' ? 'Matching enquiries from your history.' : 'Active and previous enquiries. Converted trips move automatically to My Bookings.' ?></p></div></div>

<?php if(!$enquiries): ?>
<div class="empty">
<div class="empty-icon"><i class="fa-regular fa-message"></i></div>
<?php if($search !== ''): ?>
<h3>No matching enquiries</h3>
<p>No previous enquiry matched “<?=e($search)?>”. Search using another package name or package code.</p>
<a href="my-enquiries.php"><i class="fa-solid fa-rotate-left"></i>&nbsp; Show All Enquiries</a>
<?php else: ?>
<h3>No enquiries yet</h3>
<p>You have not submitted a travel enquiry using this account's registered email address.</p>
<a href="packages.php"><i class="fa-solid fa-compass"></i>&nbsp; Explore Packages</a>
<?php endif; ?>
</div>
<?php else: ?>

<div class="list">
<?php foreach($enquiries as $q):
$status = strtolower((string)$q['status']);
$travellers = (int)$q['adults'] + (int)$q['children'];
?>
<article class="card">
<div class="card-main">
<div class="image">
<img src="<?=e(enquiryImage($q['main_image'] ?? ''))?>" alt="<?=e($q['package_title'] ?: ($q['destination'] ?: 'Travel enquiry'))?>">
</div>

<div>
<div class="card-top">
<div>
<?php if(!empty($q['package_title'])): ?>
<a class="package" href="package-details.php?slug=<?=urlencode((string)$q['package_slug'])?>"><?=e($q['package_title'])?></a>
<?php if(!empty($q['package_code'])): ?><div><span class="package-code"><?=e($q['package_code'])?></span></div><?php endif; ?>
<?php else: ?>
<div class="package"><?=e($q['destination'] ?: 'Custom Travel Enquiry')?></div>
<?php endif; ?>
<div class="destination"><i class="fa-solid fa-location-dot"></i> <?=e($q['destination'] ?: 'Destination not specified')?></div>
</div>
<span class="status <?=e(enquiryStatusClass($status))?>"><?=e(enquiryStatusLabel($status))?></span>
</div>

<div class="details">
<div class="detail"><span>Travel Date</span><strong><?=e(enquiryDate($q['travel_date']))?></strong></div>
<div class="detail"><span>Travellers</span><strong><?=$travellers?> Guest(s)</strong></div>
<div class="detail"><span>Budget</span><strong><?= $q['budget'] !== null ? '₹'.number_format((float)$q['budget'],2) : 'Not specified' ?></strong></div>
<div class="detail"><span>Enquiry ID</span><strong>#<?=str_pad((string)$q['id'],6,'0',STR_PAD_LEFT)?></strong></div>
</div>

<?php if(trim((string)$q['message']) !== ''): ?>
<div class="message"><?=e($q['message'])?></div>
<?php endif; ?>

<div class="submitted">Submitted <?=e(enquiryDate($q['created_at'],'d M Y, h:i A'))?></div>
</div>
</div>

<?php if(trim((string)$q['admin_notes']) !== ''): ?>
<div class="admin-response">
<div class="response-head"><i class="fa-solid fa-headset"></i> TRAVSCOPE Response</div>
<div class="response-text"><?=e($q['admin_notes'])?></div>
</div>
<?php endif; ?>
</article>
<?php endforeach; ?>
</div>
<?php endif; ?>
</section>
</div>
</main>

<script>
const s=document.getElementById('sidebar'),m=document.getElementById('mobile'),o=document.getElementById('overlay');
function closeMenu(){s?.classList.remove('open');o?.classList.remove('show');document.body.style.overflow=''}
m?.addEventListener('click',()=>{s.classList.toggle('open');o.classList.toggle('show');document.body.style.overflow=s.classList.contains('open')?'hidden':''});
o?.addEventListener('click',closeMenu);
window.addEventListener('resize',()=>{if(innerWidth>850)closeMenu()});
</script>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
