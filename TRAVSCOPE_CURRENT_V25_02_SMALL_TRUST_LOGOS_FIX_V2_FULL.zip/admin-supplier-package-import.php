<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
require_once __DIR__.'/supplier-manual-package-functions.php';
require_once __DIR__.'/supplier-package-import-functions.php';
require_once __DIR__.'/package-supplier-functions.php';
require_once __DIR__.'/supplier-hotel-option-functions.php';
require_once __DIR__.'/supplier-hotel-import-functions.php';
if(function_exists('requireAdmin')) requireAdmin(); elseif(empty($_SESSION['admin_id'])){header('Location: '.(defined('BASE_URL')?BASE_URL:'').'login.php');exit;}
$adminId=(int)($_SESSION['admin_id']??0);
function spiE($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
if(empty($_SESSION['spi_csrf'])) $_SESSION['spi_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['spi_csrf'];
$supplierId=max(0,(int)($_GET['supplier_id']??$_POST['supplier_id']??0));
$suppliers=[];
try{$suppliers=$pdo->query("SELECT id,company_name,supplier_code,status FROM suppliers WHERE status='active' ORDER BY company_name")->fetchAll(PDO::FETCH_ASSOC)?:[];}catch(Throwable $e){}
if($supplierId<=0&&count($suppliers)===1)$supplierId=(int)$suppliers[0]['id'];
$supplier=$supplierId>0?tsMSSupplier($pdo,$supplierId):null;
$destinations=tsMSDestinationOptions($pdo);
$error='';
$success=(string)($_SESSION['spi_success']??'');unset($_SESSION['spi_success']);
$token=trim((string)($_GET['token']??$_POST['token']??''));
function spiPreview(string $token):?array{return $token!==''&&isset($_SESSION['spi_import_'.$token])&&is_array($_SESSION['spi_import_'.$token])?$_SESSION['spi_import_'.$token]:null;}
function spiCounts(array $rows):array{$c=['total'=>count($rows),'included'=>0,'valid'=>0,'errors'=>0,'updates'=>0,'excluded'=>0];foreach($rows as $r){if(!empty($r['excluded'])){$c['excluded']++;continue;}$c['included']++;if(empty($r['errors']))$c['valid']++;else$c['errors']++;if(!empty($r['existing']))$c['updates']++;}return $c;}
function spiDayCounts(array $rows):array{$c=['total'=>count($rows),'included'=>0,'valid'=>0,'errors'=>0,'excluded'=>0];foreach($rows as $r){if(!empty($r['excluded'])){$c['excluded']++;continue;}$c['included']++;if(empty($r['errors']))$c['valid']++;else$c['errors']++;}return $c;}
function spiContentCounts(array $rows):array{$c=['total'=>count($rows),'valid'=>0,'errors'=>0];foreach($rows as $r){if(empty($r['errors']))$c['valid']++;else$c['errors']++;}return $c;}
function spiHotelCounts(array $rows):array{$c=['total'=>count($rows),'included'=>0,'valid'=>0,'errors'=>0,'warnings'=>0,'duplicates'=>0,'missing_city'=>0,'excluded'=>0];foreach($rows as $r){if(!empty($r['excluded'])){$c['excluded']++;continue;}$c['included']++;if(empty($r['errors']))$c['valid']++;else$c['errors']++;if(!empty($r['warnings']))$c['warnings']++;if(!empty($r['existing_id']))$c['duplicates']++;foreach(($r['warnings']??[]) as $w)if(stripos((string)$w,'Location Master')!==false){$c['missing_city']++;break;}}return $c;}
function spiImportHotelRows(PDO $pdo,array $rows,int $supplierId,int $adminId,bool $updateDuplicates=false):array{$st=['new'=>0,'updated'=>0,'duplicates_skipped'=>0,'excluded'=>0,'failed'=>0,'messages'=>[]];foreach($rows as $r){if(!empty($r['excluded'])){$st['excluded']++;continue;}if(!empty($r['errors']))continue;if(!empty($r['existing_id'])&&!$updateDuplicates){$st['duplicates_skipped']++;continue;}try{$payload=$r;$payload['supplier_id']=$supplierId;$payload['option_id']=$updateDuplicates?(int)($r['existing_id']??0):0;$id=tsSHOSave($pdo,$payload,$adminId);if(($r['status']??'active')==='inactive'&&$id>0){$q=$pdo->prepare("UPDATE supplier_hotel_options SET status='inactive',updated_by_admin_id=?,updated_at=NOW() WHERE id=?");$q->execute([$adminId?:null,$id]);}if(!empty($r['existing_id']))$st['updated']++;else$st['new']++;}catch(Throwable $e){$st['failed']++;if(count($st['messages'])<5)$st['messages'][]='Hotel row '.(int)($r['row_no']??0).': '.$e->getMessage();}}return $st;}
function spiNormCode(string $v):string{return strtolower(trim($v));}
function spiGroupPackages(array $rateRows,array $dayRows):array{
    $g=[];
    foreach($rateRows as $i=>$r){$code=trim((string)($r['package_code']??''));$k=spiNormCode($code);if($k==='')$k='__rate_'.$i;if(!isset($g[$k]))$g[$k]=['code'=>$code,'rate_indices'=>[],'day_indices'=>[]];$g[$k]['rate_indices'][]=$i;if($g[$k]['code']===''&&$code!=='')$g[$k]['code']=$code;}
    foreach($dayRows as $i=>$r){$code=trim((string)($r['package_code']??''));$k=spiNormCode($code);if($k==='')$k='__day_'.$i;if(!isset($g[$k]))$g[$k]=['code'=>$code,'rate_indices'=>[],'day_indices'=>[]];$g[$k]['day_indices'][]=$i;if($g[$k]['code']===''&&$code!=='')$g[$k]['code']=$code;}
    uasort($g,function($a,$b){return strnatcasecmp((string)$a['code'],(string)$b['code']);});
    return $g;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        if(!hash_equals($csrf,(string)($_POST['csrf']??'')))throw new RuntimeException('Security verification failed.');
        $action=(string)($_POST['action']??'');
        if($action==='preview'){
            if(!$supplier)throw new RuntimeException('Choose supplier first.');
            if(empty($_FILES['import_file'])||!is_array($_FILES['import_file']))throw new RuntimeException('Choose Excel or CSV file.');
            $f=$_FILES['import_file'];if((int)($f['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)throw new RuntimeException('Upload failed. Choose the file again.');
            if((int)($f['size']??0)>10*1024*1024)throw new RuntimeException('Maximum file size is 10 MB.');
            $name=(string)($f['name']??'');$bundle=tsSPIParseImportFile((string)$f['tmp_name'],$name);
            $rows=tsSPIValidateRows($pdo,$bundle['rates']??[],$supplierId);if(!$rows)throw new RuntimeException('No package-rate rows found in file.');
            $dayRows=tsSPIValidateDayRows($pdo,$bundle['days']??[],$supplierId,$rows);
            $termRows=tsSPIValidateTermRows($pdo,$bundle['terms']??[],$supplierId,$rows);
            $contentRows=tsSPIValidateContentRows($pdo,$bundle['content']??[],$supplierId,$rows);
            $hotelRows=[];$ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
            if($ext==='xlsx'){
                $hotelMatrix=tsSHIParseFile((string)$f['tmp_name'],$name);
                if($hotelMatrix&&tsSHIXlsxLooksLikeImport($hotelMatrix))$hotelRows=tsSHIValidateRows($pdo,$hotelMatrix,$supplierId);
            }
            $token=bin2hex(random_bytes(16));$_SESSION['spi_import_'.$token]=['supplier_id'=>$supplierId,'file_name'=>$name,'rows'=>$rows,'days'=>$dayRows,'terms'=>$termRows,'content'=>$contentRows,'hotels'=>$hotelRows,'created_at'=>time()];
            header('Location: admin-supplier-package-import.php?supplier_id='.$supplierId.'&token='.rawurlencode($token));exit;
        }
        if(in_array($action,['revalidate','import','delete_selected','delete_rate_errors','delete_day_errors','delete_all_errors'],true)){
            $key='spi_import_'.$token;$data=$_SESSION[$key]??null;if(!is_array($data))throw new RuntimeException('Import preview expired. Upload the file again.');
            if((int)($data['supplier_id']??0)!==$supplierId)throw new RuntimeException('Supplier changed after preview.');

            $posted=is_array($_POST['rows']??null)?$_POST['rows']:[];
            $postedDays=is_array($_POST['day_rows']??null)?$_POST['day_rows']:[];
            $postedHotels=is_array($_POST['hotel_rows']??null)?$_POST['hotel_rows']:[];

            /* V23.4: package fields are edited once and applied to every exact-rate row/day in that package. */
            $pkgCommon=is_array($_POST['package_common']??null)?$_POST['package_common']:[];
            foreach($pkgCommon as $pc){if(!is_array($pc))continue;$orig=trim((string)($pc['original_code']??''));if($orig==='')continue;$newCode=trim((string)($pc['package_code']??$orig));
                foreach(($data['rows']??[]) as $ri=>$rr){if(strcasecmp(trim((string)($rr['package_code']??'')),$orig)!==0)continue;$ed=is_array($posted[$ri]??null)?$posted[$ri]:[];foreach(['package_code','package_name','route_summary'] as $f)if(array_key_exists($f,$pc))$ed[$f]=(string)$pc[$f];foreach(['destination_id','nights','days'] as $f)if(array_key_exists($f,$pc))$ed[$f]=(string)$pc[$f];$posted[$ri]=$ed;}
                foreach(($data['days']??[]) as $di=>$dd){if(strcasecmp(trim((string)($dd['package_code']??'')),$orig)!==0)continue;$ed=is_array($postedDays[$di]??null)?$postedDays[$di]:[];$ed['package_code']=$newCode;$postedDays[$di]=$ed;}
                foreach(($data['terms']??[]) as $ti=>$tt){if(strcasecmp(trim((string)($tt['package_code']??'')),$orig)===0)$data['terms'][$ti]['package_code']=$newCode;}
                foreach(($data['content']??[]) as $ci=>$cc){if(strcasecmp(trim((string)($cc['package_code']??'')),$orig)===0)$data['content'][$ci]['package_code']=$newCode;}
            }
            /* Season fields are edited once and applied to every category/PAX row in that season. */
            $seasonCommon=is_array($_POST['season_common']??null)?$_POST['season_common']:[];
            foreach($seasonCommon as $sc){if(!is_array($sc))continue;$op=trim((string)($sc['original_package_code']??''));$os=trim((string)($sc['original_season_name']??''));$of=trim((string)($sc['original_valid_from']??''));$ot=trim((string)($sc['original_valid_to']??''));
                foreach(($data['rows']??[]) as $ri=>$rr){if(strcasecmp(trim((string)($rr['package_code']??'')),$op)!==0)continue;if(strcasecmp(trim((string)($rr['season_name']??'')),$os)!==0)continue;if(trim((string)($rr['valid_from']??''))!==$of||trim((string)($rr['valid_to']??''))!==$ot)continue;$ed=is_array($posted[$ri]??null)?$posted[$ri]:[];foreach(['season_name','season_type','valid_from','valid_to','priority','applicability','status'] as $f)if(array_key_exists($f,$sc))$ed[$f]=(string)$sc[$f];$posted[$ri]=$ed;}
            }

            $data['rows']=tsSPIApplyCorrections($pdo,$data['rows']??[],$supplierId,$posted);
            $data['hotels']=tsSHIApplyPreviewCorrections($pdo,$data['hotels']??[],$supplierId,$postedHotels,[]);
            $deletedRates=0;$deletedDays=0;$deletedHotels=0;
            if(in_array($action,['delete_selected','delete_rate_errors','delete_all_errors'],true)){
                $selected=array_map('intval',array_keys(is_array($_POST['rate_delete']??null)?$_POST['rate_delete']:[]));$kept=[];
                foreach($data['rows'] as $ri=>$rr){$drop=$action==='delete_all_errors'?!empty($rr['errors']):($action==='delete_rate_errors'?!empty($rr['errors']):in_array((int)$ri,$selected,true));if($drop){$deletedRates++;continue;}$kept[]=$rr;}$data['rows']=$kept;
            }
            $data['days']=tsSPIApplyDayCorrections($pdo,$data['days']??[],$supplierId,$data['rows'],$postedDays);
            if(in_array($action,['delete_selected','delete_day_errors','delete_all_errors'],true)){
                $selectedDays=array_map('intval',array_keys(is_array($_POST['day_delete']??null)?$_POST['day_delete']:[]));$keptDays=[];
                foreach($data['days'] as $di=>$dd){$drop=$action==='delete_all_errors'?!empty($dd['errors']):($action==='delete_day_errors'?!empty($dd['errors']):in_array((int)$di,$selectedDays,true));if($drop){$deletedDays++;continue;}$keptDays[]=$dd;}$data['days']=$keptDays;
            }
            if(in_array($action,['delete_selected','delete_all_errors'],true)){
                $selectedHotels=array_map('intval',array_keys(is_array($_POST['hotel_delete']??null)?$_POST['hotel_delete']:[]));$keptHotels=[];
                foreach(($data['hotels']??[]) as $hi=>$hh){$drop=$action==='delete_all_errors'?!empty($hh['errors']):in_array((int)$hi,$selectedHotels,true);if($drop){$deletedHotels++;continue;}$keptHotels[]=$hh;}$data['hotels']=$keptHotels;
            }
            $_SESSION[$key]=$data;
            if(in_array($action,['delete_selected','delete_rate_errors','delete_day_errors','delete_all_errors'],true)){
                $_SESSION['spi_success']='Preview rows permanently removed: '.$deletedRates.' rate row(s), '.$deletedDays.' itinerary row(s) and '.$deletedHotels.' hotel row(s).';
                header('Location: admin-supplier-package-import.php?supplier_id='.$supplierId.'&token='.rawurlencode($token));exit;
            }
            if($action==='revalidate'){
                $_SESSION['spi_success']='Package, season, rate, itinerary and hotel corrections saved and revalidated.';
                header('Location: admin-supplier-package-import.php?supplier_id='.$supplierId.'&token='.rawurlencode($token));exit;
            }
            $counts=spiCounts($data['rows']);$dayCounts=spiDayCounts($data['days']??[]);$contentCounts=spiContentCounts($data['content']??[]);$hotelCounts=spiHotelCounts($data['hotels']??[]);
            if($counts['errors']>0||$dayCounts['errors']>0||$contentCounts['errors']>0||$hotelCounts['errors']>0)throw new RuntimeException('Fix all ERROR rows in Packages, Itinerary and Hotels before final import. Nothing was imported. Content below the preferred word range is automatically expanded and is shown as a warning, not an error.');
            if($hotelCounts['missing_city']>0&&empty($_POST['create_missing_hotel_locations']))throw new RuntimeException($hotelCounts['missing_city'].' hotel row(s) still have a city not in Location Master. Tick Create missing hotel cities, or correct the rows first.');
            $stats=tsSPIImport($pdo,$data['rows'],$supplierId,$adminId);
            $dayStats=tsSPIImportDays($pdo,$data['days']??[],$supplierId,$adminId);
            $termStats=tsSPIImportTerms($pdo,$data['terms']??[],$supplierId,$adminId);
            $contentStats=tsSPIImportPackageContent($pdo,$data['content']??[],$supplierId,$adminId);
            $hotelStats=spiImportHotelRows($pdo,$data['hotels']??[],$supplierId,$adminId,!empty($_POST['update_hotel_duplicates']));
            if(($hotelStats['failed']??0)>0)throw new RuntimeException('Package data imported, but '.$hotelStats['failed'].' hotel row(s) failed: '.implode(' | ',$hotelStats['messages']??[]));
            $masterSynced=0;$masterSyncErrors=0;$codes=[];
            foreach(($data['rows']??[]) as $rr){$c=trim((string)($rr['package_code']??''));if($c!=='')$codes[strtolower($c)]=$c;}
            foreach($codes as $packageCode){
                try{
                    $q=$pdo->prepare("SELECT id FROM packages WHERE source_type='supplier_imported' AND source_supplier_id=? AND LOWER(TRIM(source_supplier_package_code))=LOWER(TRIM(?)) ORDER BY id");
                    $q->execute([$supplierId,$packageCode]);
                    foreach($q->fetchAll(PDO::FETCH_COLUMN)?:[] as $pid){tsPSOSyncPackageContentFromSupplier($pdo,(int)$pid,$adminId);$masterSynced++;}
                }catch(Throwable $syncError){$masterSyncErrors++;error_log('V24.14 Package Master post-import sync: '.$syncError->getMessage());}
            }
            unset($_SESSION[$key]);
            $_SESSION['spi_success']='Unified supplier import complete: '.$stats['packages_created'].' package(s) created, '.$stats['packages_updated'].' existing package(s) updated, '.$stats['seasons_created'].' season(s), '.$stats['rate_categories_saved'].' rate matrix/matrices from '.$stats['rate_rows'].' exact PAX row(s), '.$dayStats['days_saved'].' day-itinerary row(s), '.$termStats['packages_with_terms'].' package term set(s), '.$contentStats['packages_with_content'].' rich-content package(s), '.$hotelStats['new'].' new hotel option(s), '.$hotelStats['updated'].' hotel option(s) updated, '.$hotelStats['duplicates_skipped'].' hotel duplicate(s) skipped, and '.$masterSynced.' linked Package Master record(s) refreshed'.($masterSyncErrors?' ('.$masterSyncErrors.' refresh warning(s))':'').'.';
            header('Location: admin-supplier-packages.php?supplier_id='.$supplierId);exit;
        }
        throw new RuntimeException('Unknown action.');
    }catch(Throwable $e){$error=$e->getMessage();}
}
$preview=spiPreview($token);
$counts=$preview?spiCounts($preview['rows']??[]):null;
$dayCounts=$preview?spiDayCounts($preview['days']??[]):null;
$contentCounts=$preview?spiContentCounts($preview['content']??[]):null;
$hotelCounts=$preview?spiHotelCounts($preview['hotels']??[]):null;
$packageGroups=$preview?spiGroupPackages($preview['rows']??[],$preview['days']??[]):[];
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Unified Supplier Import | TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260924-v234">
<style>
:root{--line:#dfe7f1;--ink:#123b63;--muted:#6f8297;--blue:#0b74ff;--green:#087d58;--red:#b42318;--amber:#8a5d06}
.wrap{width:100%;max-width:none;margin:0;padding:0}.hero{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;margin-bottom:10px}.hero h1{margin:0;color:var(--ink);font-size:24px}.hero p{margin:4px 0 0;color:var(--muted);font-size:10px}.actions,.toolbar{display:flex;gap:7px;flex-wrap:wrap;align-items:center}.btnx{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--line);background:#fff;color:#24557f;text-decoration:none;font-weight:850;font-size:9px;border-radius:9px;padding:8px 10px;cursor:pointer}.btnx.primary{background:var(--blue);color:#fff;border-color:var(--blue)}.btnx.danger{background:#fff1f1;color:var(--red);border-color:#f2b8b5}.btnx:disabled{opacity:.45;cursor:not-allowed}
.notice,.success,.error{padding:9px 11px;border-radius:10px;margin-bottom:10px;font-size:9px}.notice{background:#eef7ff;border:1px solid #cfe2f7;color:#315e88}.success{background:#ecfaf3;border:1px solid #c7ecd9;color:#11744f}.error{background:#fff1f1;border:1px solid #f1caca;color:#a23a3a}
.card{background:#fff;border:1px solid var(--line);border-radius:13px;margin-bottom:10px;overflow:hidden}.card-head{padding:12px 14px;border-bottom:1px solid #edf2f7}.card-head h2{margin:0;color:#163f67;font-size:15px}.card-head p{margin:3px 0 0;color:var(--muted);font-size:9px}.card-body{padding:12px}.upload-grid{display:grid;grid-template-columns:minmax(250px,.7fr) minmax(300px,1.3fr) auto;gap:10px;align-items:end}.field label,.mini-label{display:block;font-size:7px;font-weight:900;color:#60768d;text-transform:uppercase;margin-bottom:4px}.input,select,textarea{width:100%;border:1px solid #dbe5ef;border-radius:8px;background:#fff;color:#193e61;font-size:8px;padding:6px 7px;box-sizing:border-box}.stats{display:grid;grid-template-columns:repeat(9,1fr);gap:7px;margin-bottom:9px}.stat{border:1px solid var(--line);background:#fff;border-radius:10px;padding:9px}.stat span{font-size:7px;font-weight:900;text-transform:uppercase;color:#7a8da1}.stat strong{display:block;font-size:18px;color:#173f66;margin-top:2px}
.unified-head{display:flex;gap:8px;align-items:center;justify-content:space-between;flex-wrap:wrap;padding:9px 11px;border-bottom:1px solid var(--line);background:#fbfdff}.searchbox{min-width:250px;max-width:410px;flex:1}.package-stack{max-height:72vh;overflow:auto;padding:8px;background:#f6f9fc}.pkg{background:#fff;border:1px solid #dce6f0;border-radius:11px;margin-bottom:8px;overflow:hidden}.pkg[open]{box-shadow:0 4px 14px rgba(25,62,97,.07)}.pkg summary{list-style:none;cursor:pointer;padding:10px 12px;display:flex;align-items:center;gap:10px;background:#fff}.pkg summary::-webkit-details-marker{display:none}.pkg-code{font-size:11px;font-weight:950;color:#124f86;min-width:86px}.pkg-title{font-size:10px;font-weight:900;color:#173f66;flex:1;min-width:160px}.pkg-meta{font-size:8px;color:#6f8297;white-space:nowrap}.pill{display:inline-flex;padding:3px 6px;border-radius:999px;font-size:7px;font-weight:900}.pill.ok{background:#eaf8f1;color:#087d58}.pill.bad{background:#fff0f0;color:#b23a3a}.pill.upd{background:#fff5dc;color:#8a5d06}.pkg-body{border-top:1px solid #edf2f7;padding:10px}.section-title{font-size:10px;font-weight:950;color:#173f66;margin:1px 0 7px}.package-grid{display:grid;grid-template-columns:140px minmax(220px,1.2fr) minmax(200px,1fr) 80px 80px;gap:7px;margin-bottom:9px}.package-route{grid-column:1/-1}.season{border:1px solid #e1e9f2;border-radius:9px;margin-bottom:9px;overflow:hidden}.season-head{background:#fff8e9;padding:8px;border-bottom:1px solid #efe3c6}.season-grid{display:grid;grid-template-columns:minmax(150px,1.2fr) 100px 120px 120px 70px 135px 100px;gap:6px}.rate-scroll,.day-scroll{overflow:auto;border-top:1px solid #edf2f7;max-height:36vh}.grid-table{width:100%;border-collapse:separate;border-spacing:0;min-width:980px}.grid-table.day{min-width:1580px}.grid-table th{position:sticky;top:0;z-index:2;background:#edf5ff;color:#285577;font-size:7px;text-transform:uppercase;padding:6px;border-bottom:1px solid #d9e5f1;text-align:left}.grid-table td{padding:5px;border-bottom:1px solid #edf2f7;font-size:8px;vertical-align:top}.grid-table .input,.grid-table select{font-size:8px;padding:5px 6px;min-width:85px}.grid-table textarea.input{min-width:330px;min-height:46px}.msg{font-size:7px;line-height:1.35;min-width:180px}.massbar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin:0 0 8px}.massbar .spacer{flex:1}.bottom{position:sticky;bottom:0;z-index:8;background:#fff;border-top:1px solid #dfe7f1;padding:8px 10px;display:flex;justify-content:flex-end;gap:7px;align-items:center}.bottom .hint{margin-right:auto;color:#6f8297;font-size:8px}.empty-note{padding:16px;color:#8a5d06;background:#fff8e9;border-radius:8px;font-size:9px}.day-titlebar{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-top:10px;margin-bottom:6px}.pkg-hidden{display:none}.hotel-section{margin:10px 8px 0;border:1px solid #dce6f0;border-radius:11px;background:#fff;overflow:hidden}.hotel-section .hotel-head{display:flex;justify-content:space-between;gap:10px;align-items:center;padding:10px 12px;background:#f2f8ff;border-bottom:1px solid #dce6f0}.hotel-section .hotel-head b{color:#173f66;font-size:11px}.hotel-scroll{overflow:auto;max-height:42vh}.hotel-grid{min-width:1450px}.hotel-grid textarea{min-width:200px}
@media(max-width:1100px){.stats{grid-template-columns:repeat(3,1fr)}.package-grid{grid-template-columns:repeat(2,1fr)}.package-route{grid-column:1/-1}.season-grid{grid-template-columns:repeat(2,1fr)}}
</style>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" media="screen">

<!-- TRAVSCOPE V24.99 responsive screen foundation -->
<link rel="stylesheet" href="assets/travscope-responsive-core-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-responsive-admin-v2499.css?v=2499" media="screen">
<link rel="stylesheet" href="assets/travscope-experience-v2500.css?v=2500" media="screen">
<script defer src="assets/travscope-responsive-v2499.js?v=2499"></script>
<script defer src="assets/travscope-experience-v2500.js?v=2500" data-ts25-area="admin"></script>
</head><body>
<main class="main"><div class="content"><div class="wrap">
<div class="hero"><div><h1><i class="fa-solid fa-file-circle-plus"></i> Unified Supplier Package + Hotel Import</h1><p>Upload one Excel workbook once. TRAVSCOPE detects and previews supplier packages, rates, itinerary and supplier hotel options together.</p></div><div class="actions"><a class="btnx" href="admin-supplier-packages.php<?=$supplierId?'?supplier_id='.$supplierId:''?>"><i class="fa-solid fa-arrow-left"></i> Package Rates</a><a class="btnx" href="templates/TRAVSCOPE_Unified_Supplier_Package_Hotel_Import_Template.xlsx" download><i class="fa-solid fa-file-excel"></i> Unified Excel Template</a></div></div>
<div class="notice"><b>V24.91 One-Workbook Import:</b> one XLSX can contain <b>Package_Rates_Import + Day_Wise_Itinerary + Package_Terms + Package_Content + Hotel_Options_Import</b>. Upload once, review both package and hotel data on this page, then import everything with one final button.<br><b>V24.89 intellectual-client content standard:</b> Short Description is kept at <b>90–100 words</b>; Full Package Description at <b>190–200 words</b>; and each Day-wise Itinerary narrative at <b>190–200 words</b>. Text above the maximum is safely capped. Shorter copy is professionally expanded using only confirmed package, route, travel and supplier facts. Route/sightseeing/distance/travel metadata stays separate and is not counted in the day narrative.</div>
<?php if($success!==''):?><div class="success"><?=spiE($success)?></div><?php endif;?><?php if($error!==''):?><div class="error"><?=spiE($error)?></div><?php endif;?>
<?php if(!$preview):?>
<section class="card"><div class="card-head"><h2>1 · Choose supplier and upload one combined workbook</h2><p>Recommended: XLSX with both Package_Rates_Import and Hotel_Options_Import sheets. Legacy package-only XLSX/CSV still works.</p></div><div class="card-body"><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=spiE($csrf)?>"><input type="hidden" name="action" value="preview"><div class="upload-grid"><div class="field"><label>Supplier *</label><select name="supplier_id" required><option value="0">Select supplier…</option><?php foreach($suppliers as $s):?><option value="<?=(int)$s['id']?>" <?=$supplierId===(int)$s['id']?'selected':''?>><?=spiE($s['company_name'])?> · <?=spiE($s['supplier_code']??'')?></option><?php endforeach;?></select></div><div class="field"><label>Combined Supplier Excel *</label><input class="input" type="file" name="import_file" accept=".xlsx,.csv" required></div><button class="btnx primary" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Upload Once & Preview All</button></div></form></div></section>
<?php else:?>
<div class="stats">
<div class="stat"><span>Packages</span><strong><?=count($packageGroups)?></strong></div>
<div class="stat"><span>Rate Rows</span><strong><?=$counts['total']?></strong></div>
<div class="stat"><span>Rate Errors</span><strong><?=$counts['errors']?></strong></div>
<div class="stat"><span>Itinerary Days</span><strong><?=$dayCounts['total']?></strong></div>
<div class="stat"><span>Day Errors</span><strong><?=$dayCounts['errors']?></strong></div>
<div class="stat"><span>Content Errors</span><strong><?=$contentCounts['errors']?></strong></div>
<div class="stat"><span>Existing Rates</span><strong><?=$counts['updates']?></strong></div>
<div class="stat"><span>Hotel Rows</span><strong><?=$hotelCounts['total']??0?></strong></div>
<div class="stat"><span>Hotel Errors</span><strong><?=$hotelCounts['errors']??0?></strong></div>
</div>
<?php if(($contentCounts['errors']??0)>0):?>
<div class="error"><b>Rich-content validation failed.</b> Correct these rows in the Excel workbook and upload it again:<br>
<?php foreach(($preview['content']??[]) as $cr): if(empty($cr['errors']))continue; ?><b><?=spiE($cr['package_code']??'Package')?></b> — <?=spiE(implode(' | ',$cr['errors']))?><br><?php endforeach; ?>
</div>
<?php endif;?>
<form method="post" id="unifiedImportForm"><input type="hidden" name="csrf" value="<?=spiE($csrf)?>"><input type="hidden" name="token" value="<?=spiE($token)?>"><input type="hidden" name="supplier_id" value="<?=$supplierId?>">
<section class="card">
<div class="unified-head"><div><div class="section-title" style="margin:0">2 · Package details + rates + day-wise itinerary</div><div style="font-size:8px;color:#6f8297">No separate rate preview and itinerary preview. Everything is grouped package-wise below.</div></div><input id="packageSearch" class="input searchbox" placeholder="Search package code / package name…"><div class="toolbar"><button type="button" class="btnx" onclick="spiDetails(true)">Expand All</button><button type="button" class="btnx" onclick="spiDetails(false)">Collapse All</button><button type="submit" class="btnx danger" name="action" value="delete_all_errors"><i class="fa-solid fa-triangle-exclamation"></i> Delete All Errors</button></div></div>
<div class="package-stack" id="packageStack">
<?php $pkgNo=0;foreach($packageGroups as $g):$pkgNo++;$rateIdx=$g['rate_indices'];$dayIdx=$g['day_indices'];$firstRate=$rateIdx?($preview['rows'][$rateIdx[0]]??[]):[];$firstDay=$dayIdx?($preview['days'][$dayIdx[0]]??[]):[];$code=(string)($firstRate['package_code']??$firstDay['package_code']??$g['code']);$name=(string)($firstRate['package_name']??'');$perr=0;$pupd=0;foreach($rateIdx as $ri){if(!empty($preview['rows'][$ri]['errors']))$perr++;if(!empty($preview['rows'][$ri]['existing']))$pupd++;}foreach($dayIdx as $di)if(!empty($preview['days'][$di]['errors']))$perr++;foreach(($preview['content']??[]) as $cr)if(strcasecmp(trim((string)($cr['package_code']??'')),trim($code))===0&&!empty($cr['errors']))$perr++;$status=$perr>0?'ERROR':($pupd>0?'UPDATE':'READY');$search=strtolower($code.' '.$name.' '.($firstRate['route_summary']??''));?>
<details class="pkg" data-search="<?=spiE($search)?>" <?=$pkgNo===1?'open':''?>>
<summary><i class="fa-solid fa-chevron-right" style="font-size:8px;color:#7a8da1"></i><span class="pkg-code"><?=spiE($code?:'NO CODE')?></span><span class="pkg-title"><?=spiE($name?:($firstRate['route_summary']??'Itinerary-only package'))?></span><span class="pkg-meta"><?=count($rateIdx)?> rate rows · <?=count($dayIdx)?> days</span><span class="pill <?=$status==='ERROR'?'bad':($status==='UPDATE'?'upd':'ok')?>"><?=$status?></span></summary>
<div class="pkg-body">
<?php if($rateIdx):$pcKey='p'.substr(sha1(spiNormCode($code)),0,12);?>
<div class="section-title"><i class="fa-solid fa-box-open"></i> Package Overview</div>
<div class="package-grid">
<div class="field"><label>Package Code *</label><input class="input" name="package_common[<?=$pcKey?>][package_code]" value="<?=spiE($firstRate['package_code']??'')?>"><input type="hidden" name="package_common[<?=$pcKey?>][original_code]" value="<?=spiE($firstRate['package_code']??'')?>"></div>
<div class="field"><label>Package Name *</label><input class="input" name="package_common[<?=$pcKey?>][package_name]" value="<?=spiE($firstRate['package_name']??'')?>"></div>
<div class="field"><label>Destination / Tour Area *</label><select name="package_common[<?=$pcKey?>][destination_id]"><option value="0">Choose…</option><?php foreach($destinations as $d):?><option value="<?=(int)$d['id']?>" <?=(int)($firstRate['destination_id']??0)===(int)$d['id']?'selected':''?>><?=spiE($d['name'])?> · <?=spiE($d['country']??'')?></option><?php endforeach;?></select></div>
<div class="field"><label>Nights</label><input class="input" type="number" min="0" name="package_common[<?=$pcKey?>][nights]" value="<?=(int)($firstRate['nights']??0)?>"></div>
<div class="field"><label>Days</label><input class="input" type="number" min="1" name="package_common[<?=$pcKey?>][days]" value="<?=(int)($firstRate['days']??0)?>"></div>
<div class="field package-route"><label>Route / Night Summary</label><input class="input" name="package_common[<?=$pcKey?>][route_summary]" value="<?=spiE($firstRate['route_summary']??'')?>"></div>
</div>
<?php $seasonGroups=[];foreach($rateIdx as $ri){$rr=$preview['rows'][$ri];$sk=strtolower(trim((string)($rr['season_name']??'')).'|'.(string)($rr['valid_from']??'').'|'.(string)($rr['valid_to']??''));$seasonGroups[$sk][]=$ri;}foreach($seasonGroups as $srows):$sf=$preview['rows'][$srows[0]];$sKey='s'.substr(sha1($code.'|'.($sf['season_name']??'').'|'.($sf['valid_from']??'').'|'.($sf['valid_to']??'')),0,12);?>
<div class="season"><div class="season-head"><div class="section-title"><i class="fa-solid fa-calendar-days"></i> Season & Exact Package Rates</div><div class="season-grid">
<div class="field"><label>Season Name *</label><input class="input" name="season_common[<?=$sKey?>][season_name]" value="<?=spiE($sf['season_name']??'')?>"><input type="hidden" name="season_common[<?=$sKey?>][original_package_code]" value="<?=spiE($sf['package_code']??'')?>"><input type="hidden" name="season_common[<?=$sKey?>][original_season_name]" value="<?=spiE($sf['season_name']??'')?>"><input type="hidden" name="season_common[<?=$sKey?>][original_valid_from]" value="<?=spiE($sf['valid_from']??'')?>"><input type="hidden" name="season_common[<?=$sKey?>][original_valid_to]" value="<?=spiE($sf['valid_to']??'')?>"></div>
<div class="field"><label>Type</label><select name="season_common[<?=$sKey?>][season_type]"><?php foreach(['regular'=>'Regular','high'=>'High','peak'=>'Peak','festival'=>'Festival','special'=>'Special'] as $k=>$v):?><option value="<?=$k?>" <?=($sf['season_type']??'')===$k?'selected':''?>><?=$v?></option><?php endforeach;?></select></div>
<div class="field"><label>Valid From *</label><input class="input" type="date" name="season_common[<?=$sKey?>][valid_from]" value="<?=spiE($sf['valid_from']??'')?>"></div>
<div class="field"><label>Valid To *</label><input class="input" type="date" name="season_common[<?=$sKey?>][valid_to]" value="<?=spiE($sf['valid_to']??'')?>"></div>
<div class="field"><label>Priority</label><input class="input" type="number" name="season_common[<?=$sKey?>][priority]" value="<?=(int)($sf['priority']??10)?>"></div>
<div class="field"><label>Applicability</label><select name="season_common[<?=$sKey?>][applicability]"><?php foreach(['arrival_date'=>'Arrival Date','departure_date'=>'Departure Date','majority_nights'=>'Majority Nights','per_night'=>'Per Night','per_service_date'=>'Per Service Date','manual_confirmation'=>'Manual Confirmation'] as $k=>$v):?><option value="<?=$k?>" <?=($sf['applicability']??'arrival_date')===$k?'selected':''?>><?=$v?></option><?php endforeach;?></select></div>
<div class="field"><label>Status</label><select name="season_common[<?=$sKey?>][status]"><option value="active" <?=($sf['status']??'')==='active'?'selected':''?>>Active</option><option value="review" <?=($sf['status']??'')!=='active'?'selected':''?>>Review</option></select></div>
</div></div>
<div class="rate-scroll"><table class="grid-table"><thead><tr><th>Delete</th><th>Use</th><th>Supplier Category</th><th>TRAVSCOPE</th><th>PAX</th><th>Rate PP</th><th>Meal</th><th>Validation</th></tr></thead><tbody>
<?php foreach($srows as $ri):$r=$preview['rows'][$ri];?><tr><td><input class="rate-del" type="checkbox" name="rate_delete[<?=$ri?>]" value="1"></td><td><input type="checkbox" name="rows[<?=$ri?>][include]" value="1" <?=empty($r['excluded'])?'checked':''?>></td><td><input class="input" name="rows[<?=$ri?>][supplier_category]" value="<?=spiE($r['supplier_category']??'')?>"></td><td><input class="input" name="rows[<?=$ri?>][travscope_category]" value="<?=spiE($r['travscope_category']??'')?>"></td><td><input class="input" type="number" min="1" name="rows[<?=$ri?>][pax]" value="<?=(int)($r['pax']??0)?>"></td><td><input class="input" type="number" step="0.01" min="0" name="rows[<?=$ri?>][rate]" value="<?=spiE($r['rate']??'')?>"></td><td><input class="input" name="rows[<?=$ri?>][meal_plan]" value="<?=spiE($r['meal_plan']??'')?>"></td><td class="msg"><?php foreach(($r['errors']??[]) as $m):?><div style="color:#b23a3a">⛔ <?=spiE($m)?></div><?php endforeach;?><?php foreach(($r['warnings']??[]) as $m):?><div style="color:#946600">⚠ <?=spiE($m)?></div><?php endforeach;?></td></tr><?php endforeach;?>
</tbody></table></div></div>
<?php endforeach;?>
<?php else:?><div class="empty-note"><b>No package-rate rows remain for <?=spiE($code)?>.</b> Its itinerary cannot be imported as a new package until at least one valid package/season/rate row exists. Upload the workbook again if these rows were deleted accidentally.</div><?php endif;?>

<?php if($dayIdx):?><div class="day-titlebar"><div class="section-title" style="margin:0"><i class="fa-solid fa-list-ol"></i> Day-wise Itinerary</div><span style="font-size:8px;color:#6f8297"><?=count($dayIdx)?> day row(s) · blank season = same itinerary for every season</span></div><div class="day-scroll"><table class="grid-table day"><thead><tr><th>Delete</th><th>Use</th><th>Season</th><th>Day</th><th>Title</th><th>Start</th><th>Via / Sightseeing</th><th>End</th><th>Overnight</th><th>Detailed Itinerary</th><th>Meals</th><th>Travel Time</th><th>Validation</th></tr></thead><tbody>
<?php foreach($dayIdx as $di):$d=$preview['days'][$di];?><tr><td><input class="day-del" type="checkbox" name="day_delete[<?=$di?>]" value="1"></td><td><input type="checkbox" name="day_rows[<?=$di?>][include]" value="1" <?=empty($d['excluded'])?'checked':''?>></td><td><input class="input" name="day_rows[<?=$di?>][season_name]" value="<?=spiE($d['season_name']??'')?>" placeholder="All seasons"></td><td><input class="input" type="number" min="1" name="day_rows[<?=$di?>][day_no]" value="<?=(int)($d['day_no']??0)?>"></td><td><input class="input" name="day_rows[<?=$di?>][day_title]" value="<?=spiE($d['day_title']??'')?>"></td><td><input class="input" name="day_rows[<?=$di?>][start_location]" value="<?=spiE($d['start_location']??'')?>"></td><td><input class="input" name="day_rows[<?=$di?>][via_route]" value="<?=spiE($d['via_route']??'')?>"></td><td><input class="input" name="day_rows[<?=$di?>][end_location]" value="<?=spiE($d['end_location']??'')?>"></td><td><input class="input" name="day_rows[<?=$di?>][overnight_city]" value="<?=spiE($d['overnight_city']??'')?>"></td><td><textarea class="input" name="day_rows[<?=$di?>][description]" rows="2"><?=spiE($d['description']??'')?></textarea></td><td><input class="input" name="day_rows[<?=$di?>][meals]" value="<?=spiE($d['meals']??'')?>"></td><td><input class="input" name="day_rows[<?=$di?>][travel_time]" value="<?=spiE($d['travel_time']??'')?>"></td><td class="msg"><div style="color:#315e88;font-weight:800"><?=tsSPIImportWordCount((string)($d['description']??''))?> narrative words</div><?php foreach(($d['errors']??[]) as $m):?><div style="color:#b23a3a">⛔ <?=spiE($m)?></div><?php endforeach;?><?php foreach(($d['warnings']??[]) as $m):?><div style="color:#946600">⚠ <?=spiE($m)?></div><?php endforeach;?></td></tr><?php endforeach;?>
</tbody></table></div><?php endif;?>
</div></details>
<?php endforeach;?>
</div>
<?php if(!empty($preview['hotels'])):?>
<div class="hotel-section">
<div class="hotel-head"><div><b><i class="fa-solid fa-hotel"></i> 3 · Supplier Hotel Options</b><div style="font-size:8px;color:#6f8297;margin-top:2px">Detected automatically from Hotel_Options_Import in the same Excel workbook.</div></div><span class="pill <?=($hotelCounts['errors']??0)>0?'bad':'ok'?>"><?=($hotelCounts['errors']??0)>0?($hotelCounts['errors'].' ERROR'):($hotelCounts['valid'].' READY')?></span></div>
<div class="hotel-scroll"><table class="grid-table hotel-grid"><thead><tr><th>Delete</th><th>Use</th><th>Destination</th><th>City / Location</th><th>Supplier Category</th><th>TRAVSCOPE</th><th>Hotel</th><th>Room</th><th>Meal</th><th>Status</th><th>Validation</th></tr></thead><tbody>
<?php foreach(($preview['hotels']??[]) as $hi=>$h):?>
<tr><td><input class="hotel-del" type="checkbox" name="hotel_delete[<?=$hi?>]" value="1"></td><td><input type="checkbox" name="hotel_rows[<?=$hi?>][include]" value="1" <?=empty($h['excluded'])?'checked':''?>></td><td><select name="hotel_rows[<?=$hi?>][destination_id]"><option value="0">Choose…</option><?php foreach($destinations as $d):?><option value="<?=(int)$d['id']?>" <?=(int)($h['destination_id']??0)===(int)$d['id']?'selected':''?>><?=spiE($d['name'])?> · <?=spiE($d['country']??'')?></option><?php endforeach;?></select><div style="font-size:7px;color:#7a8da1;margin-top:2px">Excel: <?=spiE($h['source_destination']??$h['source_state']??'')?></div></td><td><input class="input" name="hotel_rows[<?=$hi?>][city]" value="<?=spiE($h['city']??'')?>"></td><td><input class="input" name="hotel_rows[<?=$hi?>][supplier_category]" value="<?=spiE($h['supplier_category']??'')?>"></td><td><input class="input" name="hotel_rows[<?=$hi?>][travscope_category]" value="<?=spiE($h['travscope_category']??'')?>"></td><td><input class="input" name="hotel_rows[<?=$hi?>][hotel_name]" value="<?=spiE($h['hotel_name']??'')?>"></td><td><input class="input" name="hotel_rows[<?=$hi?>][room_type]" value="<?=spiE($h['room_type']??'')?>"></td><td><input class="input" name="hotel_rows[<?=$hi?>][meal_plan]" value="<?=spiE($h['meal_plan']??'')?>"></td><td><select name="hotel_rows[<?=$hi?>][status]"><option value="active" <?=($h['status']??'active')==='active'?'selected':''?>>Active</option><option value="inactive" <?=($h['status']??'')==='inactive'?'selected':''?>>Inactive</option></select></td><td class="msg"><?php if(!empty($h['existing_id'])):?><div style="color:#946600">⚠ Existing supplier hotel option</div><?php endif;?><?php foreach(($h['errors']??[]) as $m):?><div style="color:#b23a3a">⛔ <?=spiE($m)?></div><?php endforeach;?><?php foreach(($h['warnings']??[]) as $m):?><div style="color:#946600">⚠ <?=spiE($m)?></div><?php endforeach;?><?php if(empty($h['errors'])&&empty($h['warnings'])):?><div style="color:#087d58">Ready</div><?php endif;?></td></tr>
<?php endforeach;?>
</tbody></table></div></div>
<?php endif;?>
<div class="bottom"><div class="hint">One workbook → package preview + hotel preview → one final import.</div><?php if(!empty($preview['hotels'])):?><label style="font-size:8px;color:#5f7388"><input type="checkbox" name="create_missing_hotel_locations" value="1" <?=($hotelCounts['missing_city']??0)>0?'checked':''?>> Create missing hotel cities</label><label style="font-size:8px;color:#5f7388"><input type="checkbox" name="update_hotel_duplicates" value="1"> Update hotel duplicates</label><?php endif;?><button class="btnx danger" type="submit" name="action" value="delete_selected" onclick="return spiConfirmDelete()"><i class="fa-solid fa-trash"></i> Delete Selected Rows</button><button class="btnx" type="submit" name="action" value="revalidate"><i class="fa-solid fa-rotate"></i> Save & Revalidate</button><button class="btnx primary" type="submit" name="action" value="import" <?=($counts['errors']>0||$dayCounts['errors']>0||($contentCounts['errors']??0)>0||($hotelCounts['errors']??0)>0)?'disabled':''?>><i class="fa-solid fa-file-import"></i> Import Packages + Hotels</button></div>
</section></form>
<?php endif;?>
</div></div></main>
<script>
function spiDetails(open){document.querySelectorAll('.pkg').forEach(function(d){d.open=open;});}
function spiConfirmDelete(){var n=document.querySelectorAll('.rate-del:checked,.day-del:checked,.hotel-del:checked').length;if(!n){alert('Select at least one row in a Delete column first.');return false;}return true;}
var ps=document.getElementById('packageSearch');if(ps){ps.addEventListener('input',function(){var q=this.value.toLowerCase().trim();document.querySelectorAll('.pkg').forEach(function(p){p.style.display=!q||p.dataset.search.includes(q)?'':'none';});});}
</script>
<script src="assets/travscope-pro-admin.js?v=20260924-v234" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script></body></html>
