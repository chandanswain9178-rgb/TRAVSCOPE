<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/hotel-google-places-functions.php';

if (empty($_SESSION['admin_id'])) { http_response_code(401); exit; }
$name = trim((string)($_GET['name'] ?? ''));
if (!tsHotelGoogleConfigured() || !preg_match('~^places/[A-Za-z0-9_-]+/photos/[A-Za-z0-9_-]+$~', $name)) {
    http_response_code(404); exit;
}
$url = tsHotelGooglePhotoUrl($name, 540, 360);
if ($url === '') { http_response_code(404); exit; }

$bytes = null; $mime = 'image/jpeg';
if (function_exists('curl_init')) {
    $ch = curl_init($url);
    if ($ch !== false) {
        curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>10,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_USERAGENT=>'TRAVSCOPE-HotelMaster/18']);
        $raw = curl_exec($ch);
        $status = (int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
        $ct = trim((string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE));
        curl_close($ch);
        if ($raw !== false && $status >= 200 && $status < 300) { $bytes=$raw; if (str_starts_with($ct,'image/')) $mime=$ct; }
    }
}
if ($bytes === null) { http_response_code(404); exit; }
header('Content-Type: '.$mime);
header('Cache-Control: private, max-age=3600');
header('X-Content-Type-Options: nosniff');
echo $bytes;
