<?php
declare(strict_types=1);
require_once __DIR__.'/supplier-manual-package-functions.php';

function tsSPIHeaderKey(string $v):string{$v=preg_replace('/^\xEF\xBB\xBF/','',trim($v))??trim($v);$v=strtolower($v);return preg_replace('/[^a-z0-9]+/','',$v)??$v;}
function tsSPIColMap(array $header):array{
    $aliases=[
        'supplier_code'=>['suppliercode','suppliercode*'],'package_code'=>['supplierpackagecode','supplierpackagecode*','packagecode'],'package_name'=>['packagename','packagename*','title'],
        'country'=>['country'],'state'=>['stateregion','state','region'],'destination'=>['destinationtourarea','destination','tourarea','destinationtourarea*'],'route_summary'=>['routenightsummary','routesummary','route','nightsummary'],
        'nights'=>['nights','nights*'],'days'=>['days','days*'],'meal_plan'=>['mealplan'],'season_name'=>['seasonname','seasonname*'],'season_type'=>['seasontype','seasontype*'],
        'valid_from'=>['validfrom','validfrom*','fromdate'],'valid_to'=>['validto','validto*','todate'],'priority'=>['priority'],'applicability'=>['applicability','applicabilitybasis'],
        'supplier_category'=>['suppliercategory','suppliercategory*','category'],'travscope_category'=>['travscopecategory','standardcategory'],'pax'=>['exactpax','exactpax*','pax'],'rate'=>['rateperperson','rateperperson*','ratepp'],
        'extra_bed'=>['extrabed'],'cnb'=>['childwithoutbed','cnb'],'cwb'=>['childwithbed','cwb'],'currency'=>['currency'],'supplier_tax_percent'=>['suppliertax','suppliertaxpercent','suppliertax%'],'tax_included'=>['taxincluded','taxincluded?'],'inclusions'=>['inclusions'],'exclusions'=>['exclusions'],'payment_terms'=>['paymentterms'],'cancellation_terms'=>['cancellationterms'],'transport_terms'=>['transportterms'],'internal_notes'=>['internalnotes','notes'],'status'=>['status','status*'],'source_reference'=>['sourcereference','source','reference']
    ];
    $norm=[];foreach($header as $i=>$h)$norm[tsSPIHeaderKey((string)$h)]=$i;$out=[];
    foreach($aliases as $field=>$keys){$out[$field]=null;foreach($keys as $k){$kk=tsSPIHeaderKey($k);if(array_key_exists($kk,$norm)){$out[$field]=$norm[$kk];break;}}}
    return $out;
}
function tsSPIRowValue(array $row,array $map,string $field):string{$i=$map[$field]??null;return $i===null?'':trim((string)($row[$i]??''));}
function tsSPIImportWordLimit(string $value,int $limit=200,?bool &$wasTrimmed=null):string{
    $wasTrimmed=false;$value=trim($value);if($value===''||$limit<=0)return $value;
    if(!preg_match_all('/\\S+/u',$value,$m,PREG_OFFSET_CAPTURE)||count($m[0])<=$limit)return $value;
    $last=$m[0][$limit-1];$end=(int)$last[1]+strlen((string)$last[0]);$wasTrimmed=true;
    return rtrim(substr($value,0,$end)).'…';
}
function tsSPIImportWordCount(string $value):int{if(!preg_match_all('/\\S+/u',trim($value),$m))return 0;return count($m[0]);}
function tsSPIFitIntellectualNarrative(string $value,array $facts,int $min=190,int $max=200,?bool &$wasExpanded=null,?bool &$wasTrimmed=null):string{
    $wasExpanded=false;$wasTrimmed=false;
    $value=tsSPIFormalDayText($value);if($value==='')return '';
    $initial=tsSPIImportWordCount($value);
    $start=tsSPIFormalDayText((string)($facts['start_location']??''));
    $via=tsSPIFormalDayText((string)($facts['via_route']??''));
    $end=tsSPIFormalDayText((string)($facts['end_location']??''));
    $overnight=tsSPIFormalDayText((string)($facts['overnight_city']??''));
    $distance=trim((string)($facts['distance_km']??''));
    $travel=trim((string)($facts['travel_time']??''));
    $meals=trim((string)($facts['meals']??''));
    $supplements=[];
    if($start!==''||$end!==''||$via!==''){
        $route='The day is organised as a continuous travel sector';
        if($start!==''&&$end!=='')$route.=' from '.$start.' to '.$end;
        elseif($start!=='')$route.=' beginning at '.$start;
        elseif($end!=='')$route.=' concluding at '.$end;
        if($via!=='')$route.=', with the confirmed route and sightseeing sequence covering '.$via;
        $supplements[]=$route.'.';
    }
    if($distance!==''||$travel!==''){
        $movement='For planning context, the recorded road movement';
        if($distance!=='')$movement.=' is approximately '.$distance.' km';
        if($travel!=='')$movement.=($distance!==''?' and':'').' carries an estimated travel time of '.$travel;
        $supplements[]=$movement.', while actual timing may vary with local road, traffic and operating conditions.';
    }
    if($overnight!=='')$supplements[]='The scheduled overnight halt is '.$overnight.', closing this day’s programme and establishing the operating base for the following sector.';
    if($meals!=='')$supplements[]='The supplier records the meal arrangement for this day as '.$meals.', which should be read together with the package inclusions and hotel plan.';
    $supplements[]='The sequence is presented chronologically so the traveller can distinguish transfer time, planned sightseeing and the overnight stop without mixing activities from the following day.';
    $supplements[]='Only locations, services and operating notes supported by the supplier itinerary are reflected here; optional or conditional experiences remain governed by the stated package terms.';
    $supplements[]='This structured presentation is intended to provide a precise understanding of the day’s travel flow, practical movement and confirmed sightseeing scope before the journey begins.';
    if($initial>$max){$value=tsSPIImportWordLimit($value,$max,$wasTrimmed);return $value;}
    foreach($supplements as $sentence){
        $current=tsSPIImportWordCount($value);if($current>=$min)break;
        $sentence=tsSPIFormalDayText($sentence);if($sentence==='')continue;
        $projected=$current+tsSPIImportWordCount($sentence);
        if($projected<=$max)$value=trim($value.' '.$sentence);
    }
    if(tsSPIImportWordCount($value)<$min){
        $fillers=[
            'This keeps the sequence clear.',
            'This keeps the confirmed travel sequence clear.',
            'This structure keeps the confirmed travel sequence clear for review.',
            'This structure keeps the confirmed travel sequence clear, factual and easy to review.',
            'This structure keeps the confirmed travel sequence clear, factual and easy for the customer to review before travel.',
            'This final context keeps the confirmed travel sequence factual, clear and professionally structured for the customer’s review before the journey begins.',
            'The narrative therefore remains focused on verified movement, scheduled stops and practical context, giving the customer a disciplined account of the confirmed day without speculative additions.'
        ];
        $current=tsSPIImportWordCount($value);$best='';$bestProjected=9999;
        foreach($fillers as $f){$f=tsSPIFormalDayText($f);$projected=$current+tsSPIImportWordCount($f);if($projected>=$min&&$projected<=$max&&$projected<$bestProjected){$best=$f;$bestProjected=$projected;}}
        if($best!=='')$value=trim($value.' '.$best);
    }
    if(tsSPIImportWordCount($value)>$max)$value=tsSPIImportWordLimit($value,$max,$wasTrimmed);
    $wasExpanded=$initial<$min && tsSPIImportWordCount($value)>$initial;
    return $value;
}

function tsSPIStripFollowingDaySpill(string $value,int $currentDay=0):string{
    $value=trim($value);if($value==='')return '';
    if(preg_match_all('/(?:^|[\r\n]+|(?<=[.!?])\s+)\s*Day\s*0*(\d{1,2})\b\s*(?:[:\-–—.]|\s)/iu',$value,$mm,PREG_OFFSET_CAPTURE)){
        foreach($mm[0] as $i=>$whole){
            $offset=(int)($whole[1]??0);$foundDay=(int)($mm[1][$i][0]??0);
            if($offset<=0)continue;
            if($currentDay<=0||$foundDay!==$currentDay)return rtrim(substr($value,0,$offset));
        }
    }
    return $value;
}
function tsSPIParseCsv(string $path):array{$fh=fopen($path,'rb');if(!$fh)throw new RuntimeException('Could not read CSV file.');$rows=[];while(($r=fgetcsv($fh,0,','))!==false){if(count($rows)===0&&isset($r[0]))$r[0]=preg_replace('/^\xEF\xBB\xBF/','',(string)$r[0])??(string)$r[0];$rows[]=$r;if(count($rows)>5001)break;}fclose($fh);return $rows;}
function tsSPIXlsxCol(string $ref):int{if(!preg_match('/^([A-Z]+)/i',$ref,$m))return 0;$n=0;foreach(str_split(strtoupper($m[1])) as $c)$n=$n*26+(ord($c)-64);return max(0,$n-1);}
function tsSPIXmlDecode(string $v):string{return html_entity_decode(preg_replace('/^\xEF\xBB\xBF/','',$v)??$v,ENT_QUOTES|ENT_XML1,'UTF-8');}
function tsSPIAttr(string $attrs,string $name):string{$q=preg_quote($name,'~');if(preg_match('~(?:^|\\s)'.$q.'\\s*=\\s*(["\\\'])(.*?)\\1~is',$attrs,$m))return tsSPIXmlDecode((string)$m[2]);return '';}
function tsSPITextNodes(string $xml):string{$out='';if(preg_match_all('~<(?:[A-Za-z0-9_]+:)?t\\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?t>~is',$xml,$mm))foreach($mm[1] as $t)$out.=tsSPIXmlDecode(strip_tags((string)$t));return $out;}
function tsSPIShared(ZipArchive $zip):array{$ss=$zip->getFromName('xl/sharedStrings.xml');if($ss===false||$ss==='')return [];$out=[];if(preg_match_all('~<(?:[A-Za-z0-9_]+:)?si\\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?si>~is',$ss,$mm))foreach($mm[1] as $x)$out[]=tsSPITextNodes((string)$x);return $out;}
function tsSPIParseSheet(string $sx,array $shared):array{$sx=preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/','',$sx)??$sx;$rows=[];if(!preg_match_all('~<(?:[A-Za-z0-9_]+:)?row\\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?row>~is',$sx,$rm))return [];
    foreach($rm[1] as $rx){$arr=[];if(preg_match_all('~<(?:[A-Za-z0-9_]+:)?c\\b([^>]*?)(?:\\s*/>|>(.*?)</(?:[A-Za-z0-9_]+:)?c>)~is',(string)$rx,$cells,PREG_SET_ORDER))foreach($cells as $cell){$attrs=(string)($cell[1]??'');$inner=(string)($cell[2]??'');$ref=tsSPIAttr($attrs,'r');if($ref==='')continue;$col=tsSPIXlsxCol($ref);$type=strtolower(tsSPIAttr($attrs,'t'));$val='';if($type==='inlinestr')$val=tsSPITextNodes($inner);else{$raw='';if(preg_match('~<(?:[A-Za-z0-9_]+:)?v\\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?v>~is',$inner,$vm))$raw=tsSPIXmlDecode(strip_tags((string)$vm[1]));if($type==='s')$val=$shared[(int)$raw]??'';elseif($type==='b')$val=$raw==='1'?'Yes':'No';else$val=$raw;}$arr[$col]=$val;}
        if($arr){$max=max(array_keys($arr));$dense=[];for($i=0;$i<=$max;$i++)$dense[]=$arr[$i]??'';$rows[]=$dense;}if(count($rows)>5001)break;}
    return $rows;
}
function tsSPIHasHeader(array $row):bool{$m=tsSPIColMap($row);return ($m['package_code']??null)!==null&&($m['season_name']??null)!==null&&($m['supplier_category']??null)!==null&&($m['pax']??null)!==null&&($m['rate']??null)!==null;}
function tsSPIParseXlsx(string $path):array{if(!class_exists('ZipArchive'))throw new RuntimeException('Excel import needs PHP ZipArchive. CSV import is available if php-zip is disabled.');$z=new ZipArchive();if($z->open($path)!==true)throw new RuntimeException('Could not open Excel workbook. Upload a normal .xlsx file.');try{$shared=tsSPIShared($z);$c=[];for($i=0;$i<$z->numFiles;$i++){$st=$z->statIndex($i);$n=(string)($st['name']??'');if(preg_match('~^xl/worksheets/[^/]+\\.xml$~i',$n))$c[]=$n;}if(!$c)throw new RuntimeException('No Excel worksheet found.');$first=[];foreach($c as $p){$sx=$z->getFromName($p);if($sx===false||$sx==='')continue;$rows=tsSPIParseSheet($sx,$shared);if(!$first&&$rows)$first=$rows;foreach(array_slice($rows,0,8,true) as $i=>$r)if(tsSPIHasHeader($r))return array_values(array_slice($rows,(int)$i));}if($first)return $first;throw new RuntimeException('No readable rows found in Excel workbook.');}finally{$z->close();}}
function tsSPIParseFile(string $path,string $name):array{$e=strtolower(pathinfo($name,PATHINFO_EXTENSION));if($e==='csv')return tsSPIParseCsv($path);if($e==='xlsx')return tsSPIParseXlsx($path);throw new RuntimeException('Only .xlsx and .csv files are supported.');}
function tsSPIDate(string $v):string{$v=trim($v);if($v==='')return '';if(is_numeric($v)){ $n=(float)$v;if($n>20000&&$n<80000){$ts=(int)(($n-25569)*86400);return gmdate('Y-m-d',$ts);} }$ts=strtotime($v);return $ts?date('Y-m-d',$ts):$v;}
function tsSPIFindDestination(PDO $pdo,string $destination,string $state,string $country):?array{$names=array_values(array_filter(array_unique([trim($destination),trim($state)]),fn($x)=>$x!==''));foreach($names as $n){$sql='SELECT id,name,'.(tsMSColumn($pdo,'destinations','country')?'country':"'' country").' FROM destinations WHERE LOWER(TRIM(name))=LOWER(TRIM(?))';$p=[$n];if($country!==''&&tsMSColumn($pdo,'destinations','country')){$sql.=" AND (LOWER(TRIM(country))=LOWER(TRIM(?)) OR TRIM(COALESCE(country,''))='')";$p[]=$country;}$sql.=' ORDER BY id LIMIT 1';$s=$pdo->prepare($sql);$s->execute($p);$r=$s->fetch(PDO::FETCH_ASSOC);if($r)return $r;}return null;}
function tsSPINormSeasonType(string $v):string{$n=strtolower(trim($v));if(str_contains($n,'peak'))return 'peak';if(str_contains($n,'festival'))return 'festival';if(str_contains($n,'high'))return 'high';if(str_contains($n,'special'))return 'special';return 'regular';}
function tsSPINormApplicability(string $v):string{$n=strtolower(trim($v));if(str_contains($n,'departure'))return 'departure_date';if(str_contains($n,'majority'))return 'majority_nights';if(str_contains($n,'per night'))return 'per_night';if(str_contains($n,'service'))return 'per_service_date';if(str_contains($n,'manual'))return 'manual_confirmation';return 'arrival_date';}
function tsSPINormStatus(string $v):string{$n=strtolower(trim($v));return $n==='active'?'active':'review';}
function tsSPIBool(string $v):int{$n=strtolower(trim($v));return in_array($n,['1','yes','y','true','included','include'],true)?1:0;}
function tsSPIStar(string $v):int{if(preg_match('/([2345])\s*(?:star|★|\*)?/i',$v,$m))return (int)$m[1];return 0;}
function tsSPIInferStarFromSupplierCategory(string $supplierCategory):int{
    $n=strtolower(trim($supplierCategory));
    if($n==='')return 0;
    if(preg_match('/\b5\s*star\b|premium|luxury|luxurious|suite/i',$n))return 5;
    if(preg_match('/\b4\s*star\b|super\s*deluxe|superdeluxe|superior|executive|boutique/i',$n))return 4;
    if(preg_match('/\b3\s*star\b|deluxe|standard|std\b/i',$n))return 3;
    if(preg_match('/\b2\s*star\b|budget|economy/i',$n))return 2;
    return 0;
}
function tsSPIResolvedStar(string $travscopeCategory,string $supplierCategory):int{
    $star=tsSPIStar($travscopeCategory);
    return $star>0?$star:tsSPIInferStarFromSupplierCategory($supplierCategory);
}
function tsSPIResolvedCategoryLabel(string $travscopeCategory,string $supplierCategory):string{
    $star=tsSPIResolvedStar($travscopeCategory,$supplierCategory);
    return $star>0?$star.' Star':trim($travscopeCategory);
}
function tsSPIFindPackage(PDO $pdo,int $supplierId,string $packageCode):int{$s=$pdo->prepare("SELECT c.id FROM supplier_contracts c JOIN supplier_contract_itineraries i ON i.contract_id=c.id WHERE c.supplier_id=? AND c.record_type='package' AND c.entry_mode='manual' AND LOWER(TRIM(i.supplier_package_code))=LOWER(TRIM(?)) ORDER BY c.id DESC LIMIT 1");$s->execute([$supplierId,$packageCode]);return (int)($s->fetchColumn()?:0);}
function tsSPIFindSeason(PDO $pdo,int $contractId,string $name,string $from,string $to):int{$s=$pdo->prepare("SELECT id FROM supplier_contract_versions WHERE contract_id=? AND LOWER(TRIM(season_name))=LOWER(TRIM(?)) AND valid_from=? AND valid_to=? ORDER BY id DESC LIMIT 1");$s->execute([$contractId,$name,$from,$to]);return (int)($s->fetchColumn()?:0);}
function tsSPIExactExists(PDO $pdo,int $supplierId,string $packageCode,string $season,string $from,string $to,string $category,int $pax):bool{$sql="SELECT p.id FROM supplier_contract_pax_rates p JOIN supplier_contract_rate_groups g ON g.id=p.rate_group_id JOIN supplier_contract_itineraries i ON i.id=p.itinerary_id JOIN supplier_contract_versions v ON v.id=p.contract_version_id JOIN supplier_contracts c ON c.id=v.contract_id WHERE c.supplier_id=? AND c.record_type='package' AND c.entry_mode='manual' AND LOWER(TRIM(i.supplier_package_code))=LOWER(TRIM(?)) AND LOWER(TRIM(v.season_name))=LOWER(TRIM(?)) AND v.valid_from=? AND v.valid_to=? AND LOWER(TRIM(g.supplier_category))=LOWER(TRIM(?)) AND p.pax_min=? AND p.pax_max=? LIMIT 1";$s=$pdo->prepare($sql);$s->execute([$supplierId,$packageCode,$season,$from,$to,$category,$pax,$pax]);return (bool)$s->fetchColumn();}
function tsSPIValidateRows(PDO $pdo,array $matrix,int $supplierId):array{
    if(count($matrix)<2)throw new RuntimeException('The import file has no data rows.');$header=array_shift($matrix);$map=tsSPIColMap($header);
    foreach(['package_code','package_name','destination','nights','days','season_name','season_type','valid_from','valid_to','supplier_category','pax','rate','status'] as $f)if(($map[$f]??null)===null)throw new RuntimeException('Missing required column: '.str_replace('_',' ',ucwords($f,'_')).'. Use the latest TRAVSCOPE Package Rates template.');
    $sup=tsMSSupplier($pdo,$supplierId);if(!$sup)throw new RuntimeException('Choose supplier first.');$supplierCode=trim((string)($sup['supplier_code']??''));$out=[];$rowNo=1;$seen=[];
    foreach($matrix as $row){$rowNo++;$blank=true;foreach($row as $v)if(trim((string)$v)!==''){$blank=false;break;}if($blank)continue;if(count($out)>=4000)break;
        $scode=tsSPIRowValue($row,$map,'supplier_code');$pkg=tsSPIRowValue($row,$map,'package_code');$name=tsSPIRowValue($row,$map,'package_name');$country=tsSPIRowValue($row,$map,'country');$state=tsSPIRowValue($row,$map,'state');$destText=tsSPIRowValue($row,$map,'destination');$route=tsSPIRowValue($row,$map,'route_summary');$nights=(int)tsSPIRowValue($row,$map,'nights');$days=(int)tsSPIRowValue($row,$map,'days');$meal=tsSPIRowValue($row,$map,'meal_plan');$season=tsSPIRowValue($row,$map,'season_name');$stype=tsSPINormSeasonType(tsSPIRowValue($row,$map,'season_type'));$from=tsSPIDate(tsSPIRowValue($row,$map,'valid_from'));$to=tsSPIDate(tsSPIRowValue($row,$map,'valid_to'));$priority=(int)(tsSPIRowValue($row,$map,'priority')?:10);$app=tsSPINormApplicability(tsSPIRowValue($row,$map,'applicability'));$cat=tsSPIRowValue($row,$map,'supplier_category');$trav=tsSPIRowValue($row,$map,'travscope_category');$travAuto=false;if($trav===''&&$cat!==''){$trav=tsSPIResolvedCategoryLabel('', $cat);$travAuto=$trav!=='';}$pax=(int)tsSPIRowValue($row,$map,'pax');$rate=(float)str_replace(',','',tsSPIRowValue($row,$map,'rate'));$status=tsSPINormStatus(tsSPIRowValue($row,$map,'status'));$currency=strtoupper(tsSPIRowValue($row,$map,'currency')?:((string)($sup['default_currency']??'INR')));$tax=(float)str_replace(',','',tsSPIRowValue($row,$map,'supplier_tax_percent'));$taxIncluded=tsSPIBool(tsSPIRowValue($row,$map,'tax_included'));$inclusions=tsSPIRowValue($row,$map,'inclusions');$exclusions=tsSPIRowValue($row,$map,'exclusions');$payment=tsSPIRowValue($row,$map,'payment_terms');$cancel=tsSPIRowValue($row,$map,'cancellation_terms');$transport=tsSPIRowValue($row,$map,'transport_terms');$internal=tsSPIRowValue($row,$map,'internal_notes');$errors=[];$warnings=[];
        if($scode!==''&&$supplierCode!==''&&strcasecmp($scode,$supplierCode)!==0)$errors[]='Supplier Code does not match selected supplier.';if($pkg==='')$errors[]='Supplier Package Code is required.';if($name==='')$errors[]='Package Name is required.';if($nights<0)$errors[]='Nights cannot be negative.';if($days<=0)$errors[]='Days must be greater than 0.';if($season==='')$errors[]='Season Name is required.';if($from===''||!preg_match('/^\\d{4}-\\d{2}-\\d{2}$/',$from))$errors[]='Valid From must be a valid date.';if($to===''||!preg_match('/^\\d{4}-\\d{2}-\\d{2}$/',$to))$errors[]='Valid To must be a valid date.';if($from!==''&&$to!==''&&$to<$from)$errors[]='Valid To cannot be before Valid From.';if($cat==='')$errors[]='Supplier Category is required.';if($pax<=0)$errors[]='Exact PAX must be greater than 0.';if($rate<=0)$errors[]='Rate Per Person must be greater than 0.';
        $dest=tsSPIFindDestination($pdo,$destText,$state,$country);if(!$dest)$errors[]='Destination/State not found in Destination Master.';$did=(int)($dest['id']??0);if($travAuto)$warnings[]='TRAVSCOPE Category auto-mapped from Supplier Category as '.$trav.'.';
        $key=strtolower($pkg.'|'.$season.'|'.$from.'|'.$to.'|'.$cat.'|'.$pax);if(isset($seen[$key]))$warnings[]='Duplicate row in this file; last imported value will replace the same exact PAX rate.';$seen[$key]=1;$existing=($pkg!==''&&$season!==''&&$from!==''&&$to!==''&&$cat!==''&&$pax>0)?tsSPIExactExists($pdo,$supplierId,$pkg,$season,$from,$to,$cat,$pax):false;if($existing)$warnings[]='Existing exact PAX rate will be updated/replaced.';
        $out[]=['row_no'=>$rowNo,'supplier_id'=>$supplierId,'supplier_code'=>$scode,'package_code'=>$pkg,'package_name'=>$name,'source_country'=>$country,'source_state'=>$state,'source_destination'=>$destText,'destination_id'=>$did,'destination_name'=>(string)($dest['name']??$destText),'route_summary'=>$route,'nights'=>$nights,'days'=>$days,'meal_plan'=>$meal,'season_name'=>$season,'season_type'=>$stype,'valid_from'=>$from,'valid_to'=>$to,'priority'=>$priority,'applicability'=>$app,'supplier_category'=>$cat,'travscope_category'=>$trav,'pax'=>$pax,'rate'=>$rate,'extra_bed'=>(float)str_replace(',','',tsSPIRowValue($row,$map,'extra_bed')),'cnb'=>(float)str_replace(',','',tsSPIRowValue($row,$map,'cnb')),'cwb'=>(float)str_replace(',','',tsSPIRowValue($row,$map,'cwb')),'currency'=>$currency,'supplier_tax_percent'=>$tax,'tax_included'=>$taxIncluded,'inclusions'=>$inclusions,'exclusions'=>$exclusions,'payment_terms'=>$payment,'cancellation_terms'=>$cancel,'transport_terms'=>$transport,'internal_notes'=>$internal,'status'=>$status,'source_reference'=>tsSPIRowValue($row,$map,'source_reference'),'existing'=>$existing,'excluded'=>false,'errors'=>$errors,'warnings'=>$warnings];
    }
    return $out;
}
function tsSPIRevalidateRow(PDO $pdo,array $r,int $supplierId,array $edit=[]):array{
    if($edit){$r['excluded']=empty($edit['include']);foreach(['package_code','package_name','route_summary','meal_plan','season_name','season_type','valid_from','valid_to','applicability','supplier_category','travscope_category','currency','status'] as $k)if(array_key_exists($k,$edit))$r[$k]=trim((string)$edit[$k]);foreach(['destination_id','nights','days','priority','pax'] as $k)if(array_key_exists($k,$edit))$r[$k]=(int)$edit[$k];foreach(['rate','extra_bed','cnb','cwb'] as $k)if(array_key_exists($k,$edit))$r[$k]=(float)str_replace(',','',(string)$edit[$k]);}
    if(!empty($r['excluded'])){$r['errors']=[];$r['warnings']=[];return $r;}
    $r['valid_from']=tsSPIDate((string)$r['valid_from']);$r['valid_to']=tsSPIDate((string)$r['valid_to']);if(trim((string)($r['travscope_category']??''))==='')$r['travscope_category']=tsSPIResolvedCategoryLabel('',(string)($r['supplier_category']??''));$r['season_type']=tsSPINormSeasonType((string)$r['season_type']);$r['applicability']=tsSPINormApplicability((string)$r['applicability']);$r['status']=tsSPINormStatus((string)$r['status']);$errors=[];$warnings=[];$did=(int)($r['destination_id']??0);if($did<=0)$errors[]='Choose a valid Destination / State.';if(trim((string)$r['package_code'])==='')$errors[]='Supplier Package Code is required.';if(trim((string)$r['package_name'])==='')$errors[]='Package Name is required.';if((int)$r['days']<=0)$errors[]='Days must be greater than 0.';if(trim((string)$r['season_name'])==='')$errors[]='Season Name is required.';if(!preg_match('/^\\d{4}-\\d{2}-\\d{2}$/',(string)$r['valid_from']))$errors[]='Valid From must be YYYY-MM-DD.';if(!preg_match('/^\\d{4}-\\d{2}-\\d{2}$/',(string)$r['valid_to']))$errors[]='Valid To must be YYYY-MM-DD.';if($r['valid_to']<$r['valid_from'])$errors[]='Valid To cannot be before Valid From.';if(trim((string)$r['supplier_category'])==='')$errors[]='Supplier Category is required.';if((int)$r['pax']<=0)$errors[]='Exact PAX must be greater than 0.';if((float)$r['rate']<=0)$errors[]='Rate Per Person must be greater than 0.';$r['existing']=empty($errors)?tsSPIExactExists($pdo,$supplierId,(string)$r['package_code'],(string)$r['season_name'],(string)$r['valid_from'],(string)$r['valid_to'],(string)$r['supplier_category'],(int)$r['pax']):false;if($r['existing'])$warnings[]='Existing exact PAX rate will be updated/replaced.';$r['errors']=$errors;$r['warnings']=$warnings;return $r;
}
function tsSPIApplyCorrections(PDO $pdo,array $rows,int $supplierId,array $posted):array{$out=[];foreach($rows as $i=>$r)$out[]=tsSPIRevalidateRow($pdo,$r,$supplierId,is_array($posted[$i]??null)?$posted[$i]:[]);return $out;}
function tsSPIUpdateOverview(PDO $pdo,int $contractId,array $r,int $adminId):void{
    $notes=trim((string)($r['internal_notes']??''));$src=trim((string)($r['source_reference']??''));if($notes===''&&$src!=='')$notes=$src;
    $pdo->prepare('UPDATE supplier_contracts SET contract_name=?,currency=?,supplier_tax_percent=?,tax_included=?,payment_terms=?,cancellation_terms=?,notes=?,source_reference=?,updated_by_admin_id=?,updated_at=NOW() WHERE id=?')->execute([(string)$r['package_name'],(string)$r['currency'],(float)($r['supplier_tax_percent']??0),(int)($r['tax_included']??0),trim((string)($r['payment_terms']??''))?:null,trim((string)($r['cancellation_terms']??''))?:null,$notes?:null,trim((string)($r['source_reference']??''))?:'IMPORTED EXCEL/CSV',$adminId?:null,$contractId]);
    $pdo->prepare('UPDATE supplier_contract_itineraries SET destination_id=?,supplier_package_code=?,title=?,duration_nights=?,duration_days=?,meal_plan=?,itinerary_text=?,inclusions=?,exclusions=?,currency=?,updated_by_admin_id=?,updated_at=NOW() WHERE contract_id=?')->execute([(int)$r['destination_id']?:null,(string)$r['package_code'],(string)$r['package_name'],(int)$r['nights'],(int)$r['days'],(string)$r['meal_plan']?:null,(string)$r['route_summary']?:null,trim((string)($r['inclusions']??''))?:null,trim((string)($r['exclusions']??''))?:null,(string)$r['currency'],$adminId?:null,$contractId]);
}
function tsSPIApplySeasonDetails(PDO $pdo,int $versionId,array $r,int $adminId):void{
    $status=tsSPINormStatus((string)($r['status']??'review'));
    $activated=$status==='active'?date('Y-m-d H:i:s'):null;
    $pdo->prepare('UPDATE supplier_contract_versions SET currency=?,supplier_tax_percent=?,tax_included=?,payment_terms=?,cancellation_terms=?,transport_terms=?,meal_plan=?,status=?,activated_by_admin_id=?,activated_at=?,updated_at=NOW() WHERE id=?')->execute([(string)$r['currency'],(float)($r['supplier_tax_percent']??0),(int)($r['tax_included']??0),trim((string)($r['payment_terms']??''))?:null,trim((string)($r['cancellation_terms']??''))?:null,trim((string)($r['transport_terms']??''))?:null,trim((string)($r['meal_plan']??''))?:null,$status,$status==='active'?($adminId?:null):null,$activated,$versionId]);
    $pdo->prepare('UPDATE supplier_contract_itineraries SET itinerary_text=?,inclusions=?,exclusions=?,meal_plan=?,currency=?,status=?,updated_by_admin_id=?,updated_at=NOW() WHERE contract_version_id=?')->execute([trim((string)($r['route_summary']??''))?:null,trim((string)($r['inclusions']??''))?:null,trim((string)($r['exclusions']??''))?:null,trim((string)($r['meal_plan']??''))?:null,(string)$r['currency'],$status==='active'?'active':'review',$adminId?:null,$versionId]);
    $pdo->prepare("UPDATE supplier_contract_rate_groups SET status=? WHERE contract_version_id=?")->execute([$status==='active'?'active':'review',$versionId]);
    $pdo->prepare("UPDATE supplier_contract_pax_rates SET status=? WHERE contract_version_id=?")->execute([$status==='active'?'active':'review',$versionId]);
    $pdo->prepare("UPDATE supplier_contracts SET status=IF(status='inactive','inactive',?),updated_by_admin_id=?,updated_at=NOW() WHERE id=(SELECT contract_id FROM supplier_contract_versions WHERE id=? LIMIT 1)")->execute([$status==='active'?'active':'draft',$adminId?:null,$versionId]);
}
function tsSPIImport(PDO $pdo,array $rows,int $supplierId,int $adminId):array{
    $usable=array_values(array_filter($rows,fn($r)=>empty($r['excluded'])&&empty($r['errors'])));if(!$usable)throw new RuntimeException('No valid included rows to import.');$packages=[];foreach($usable as $r)$packages[strtolower((string)$r['package_code'])][]=$r;$stats=['packages_created'=>0,'packages_updated'=>0,'seasons_created'=>0,'rate_categories_saved'=>0,'rate_rows'=>0];
    foreach($packages as $pkgRows){$first=$pkgRows[0];$contractId=tsSPIFindPackage($pdo,$supplierId,(string)$first['package_code']);$firstSeasonKey=strtolower($first['season_name'].'|'.$first['valid_from'].'|'.$first['valid_to']);$createdInitialVersion=0;
        if($contractId<=0){$res=tsMSCreatePackage($pdo,['supplier_id'=>$supplierId,'title'=>$first['package_name'],'supplier_package_code'=>$first['package_code'],'destination_id'=>$first['destination_id'],'duration_nights'=>$first['nights'],'duration_days'=>$first['days'],'valid_from'=>$first['valid_from'],'valid_to'=>$first['valid_to'],'season_name'=>$first['season_name'],'season_type'=>$first['season_type'],'rate_priority'=>$first['priority'],'applicability_basis'=>$first['applicability'],'currency'=>$first['currency'],'supplier_tax_percent'=>$first['supplier_tax_percent']??0,'tax_included'=>$first['tax_included']??0,'status'=>$first['status'],'meal_plan'=>$first['meal_plan'],'itinerary_text'=>$first['route_summary'],'inclusions'=>$first['inclusions']??'','exclusions'=>$first['exclusions']??'','payment_terms'=>$first['payment_terms']??'','cancellation_terms'=>$first['cancellation_terms']??'','transport_terms'=>$first['transport_terms']??'','notes'=>trim((string)($first['internal_notes']??'')),'source_reference'=>$first['source_reference']??'IMPORTED EXCEL/CSV'],$adminId);$contractId=(int)$res['contract_id'];$createdInitialVersion=(int)$res['version_id'];$stats['packages_created']++;}
        else{$stats['packages_updated']++;tsSPIUpdateOverview($pdo,$contractId,$first,$adminId);}
        $seasonGroups=[];foreach($pkgRows as $r)$seasonGroups[strtolower($r['season_name'].'|'.$r['valid_from'].'|'.$r['valid_to'])][]=$r;
        foreach($seasonGroups as $seasonKey=>$seasonRows){$sf=$seasonRows[0];if($createdInitialVersion>0&&$seasonKey===$firstSeasonKey)$versionId=$createdInitialVersion;else{$versionId=tsSPIFindSeason($pdo,$contractId,(string)$sf['season_name'],(string)$sf['valid_from'],(string)$sf['valid_to']);if($versionId<=0){$x=tsMSAddSeason($pdo,$contractId,['season_name'=>$sf['season_name'],'season_type'=>$sf['season_type'],'rate_priority'=>$sf['priority'],'applicability_basis'=>$sf['applicability'],'valid_from'=>$sf['valid_from'],'valid_to'=>$sf['valid_to'],'status'=>$sf['status']],$adminId);$versionId=(int)$x['version_id'];$stats['seasons_created']++;}}
            tsSPIApplySeasonDetails($pdo,$versionId,$sf,$adminId);$it=tsMSItineraryForVersion($pdo,$versionId);if(!$it)throw new RuntimeException('Could not load itinerary for imported season.');$catGroups=[];foreach($seasonRows as $r)$catGroups[strtolower((string)$r['supplier_category'])][]=$r;
            foreach($catGroups as $catRows){$cf=$catRows[0];$p=[];$rt=[];foreach($catRows as $r){$p[]=(int)$r['pax'];$rt[]=(float)$r['rate'];$stats['rate_rows']++;}tsMSSaveRateGroup($pdo,$versionId,(int)$it['id'],['supplier_category'=>$cf['supplier_category'],'mapped_star_category'=>tsSPIResolvedStar((string)$cf['travscope_category'],(string)$cf['supplier_category']),'meal_plan'=>$cf['meal_plan'],'status'=>$cf['status'],'pax'=>$p,'rate'=>$rt,'extra_bed_rate'=>$cf['extra_bed']?:'','child_without_bed_rate'=>$cf['cnb']?:'','child_with_bed_rate'=>$cf['cwb']?:'','child_with_bed_basis'=>'explicit'],$adminId);$stats['rate_categories_saved']++;}
        }
    }
    return $stats;
}

/* ===== V23.2: multi-sheet package + day-wise itinerary import ===== */
function tsSPIDayColMap(array $header):array{
    $aliases=[
        'package_code'=>['supplierpackagecode','supplierpackagecode*','packagecode'],
        'season_name'=>['appliestoseason','seasonname','season'],
        'day_no'=>['dayno','dayno*','daynumber','day'],
        'day_title'=>['daytitle','daytitle*','title'],
        'start_location'=>['startpickuplocation','startlocation','pickup'],
        'via_route'=>['viasightseeingroute','via','sightseeingroute','route'],
        'end_location'=>['enddroplocation','endlocation','drop'],
        'overnight_city'=>['overnightcity','overnight'],
        'description'=>['detaileddayitinerary','detaileddayitinerary*','daydescription','description','itinerary'],
        'meals'=>['meals','meal'],
        'distance_km'=>['distancekm','distance'],
        'travel_time'=>['approxtraveltime','traveltime','duration'],
        'internal_note'=>['internalnote','note','notes'],
        'status'=>['status','status*']
    ];
    $norm=[];foreach($header as $i=>$h)$norm[tsSPIHeaderKey((string)$h)]=$i;$out=[];
    foreach($aliases as $field=>$keys){$out[$field]=null;foreach($keys as $k){$kk=tsSPIHeaderKey($k);if(array_key_exists($kk,$norm)){$out[$field]=$norm[$kk];break;}}}
    return $out;
}
function tsSPIDayRowValue(array $row,array $map,string $field):string{$i=$map[$field]??null;return $i===null?'':trim((string)($row[$i]??''));}
function tsSPIContentColMap(array $header):array{
    $aliases=[
        'package_code'=>['supplierpackagecode','supplierpackagecode*','packagecode'],
        'short_description'=>['shortdescription','packageshortdescription'],
        'full_description'=>['fullpackagedescription','fulldescription','packagedescription'],
        'detailed_itinerary'=>['detaileddaywiseitinerary','daywiseitinerary','detaileditinerary'],
        'tour_highlights'=>['tourhighlights','packagehighlights','highlights'],
        'package_terms'=>['packagetermsconditions','packagetermsandconditions','packageterms','termsconditions'],
        'source_itinerary'=>['sourceitineraryfile','itinerarysource'],
        'source_rate_sheet'=>['sourceratesheet','ratesheetsource']
    ];
    $norm=[];foreach($header as $i=>$h)$norm[tsSPIHeaderKey((string)$h)]=$i;$out=[];
    foreach($aliases as $field=>$keys){$out[$field]=null;foreach($keys as $k){$kk=tsSPIHeaderKey($k);if(array_key_exists($kk,$norm)){$out[$field]=$norm[$kk];break;}}}
    return $out;
}
function tsSPIHasContentHeader(array $row):bool{$m=tsSPIContentColMap($row);return ($m['package_code']??null)!==null && (($m['short_description']??null)!==null || ($m['full_description']??null)!==null || ($m['tour_highlights']??null)!==null || ($m['package_terms']??null)!==null);}
function tsSPIContentRowValue(array $row,array $map,string $field):string{$i=$map[$field]??null;return $i===null?'':trim((string)($row[$i]??''));}

function tsSPIHasDayHeader(array $row):bool{$m=tsSPIDayColMap($row);return ($m['package_code']??null)!==null&&($m['day_no']??null)!==null&&($m['day_title']??null)!==null&&($m['description']??null)!==null;}
function tsSPIParseXlsxBundle(string $path):array{
    if(!class_exists('ZipArchive'))throw new RuntimeException('Excel import needs PHP ZipArchive. CSV import is available if php-zip is disabled.');
    $z=new ZipArchive();if($z->open($path)!==true)throw new RuntimeException('Could not open Excel workbook. Upload a normal .xlsx file.');
    try{
        $shared=tsSPIShared($z);$rateRows=[];$dayRows=[];$termRows=[];$contentRows=[];
        for($i=0;$i<$z->numFiles;$i++){
            $st=$z->statIndex($i);$n=(string)($st['name']??'');if(!preg_match('~^xl/worksheets/[^/]+\\.xml$~i',$n))continue;
            $sx=$z->getFromName($n);if($sx===false||$sx==='')continue;$rows=tsSPIParseSheet($sx,$shared);if(!$rows)continue;
            foreach(array_slice($rows,0,12,true) as $ri=>$r){
                if(!$rateRows&&tsSPIHasHeader($r)){$rateRows=array_values(array_slice($rows,(int)$ri));break;}
                if(!$dayRows&&tsSPIHasDayHeader($r)){$dayRows=array_values(array_slice($rows,(int)$ri));break;}
                if(!$termRows&&tsSPIHasTermsHeader($r)){$termRows=array_values(array_slice($rows,(int)$ri));break;}
                if(!$contentRows&&tsSPIHasContentHeader($r)){$contentRows=array_values(array_slice($rows,(int)$ri));break;}
            }
        }
        if(!$rateRows)throw new RuntimeException('Package_Rates_Import sheet/header was not found. Use the latest TRAVSCOPE supplier tour package template.');
        return ['rates'=>$rateRows,'days'=>$dayRows,'terms'=>$termRows,'content'=>$contentRows];
    }finally{$z->close();}
}
function tsSPIParseImportFile(string $path,string $name):array{
    $e=strtolower(pathinfo($name,PATHINFO_EXTENSION));
    if($e==='xlsx')return tsSPIParseXlsxBundle($path);
    if($e==='csv')return ['rates'=>tsSPIParseCsv($path),'days'=>[],'terms'=>[],'content'=>[]];
    throw new RuntimeException('Only .xlsx and .csv files are supported. Use .xlsx to import day-wise itinerary in the same file.');
}

function tsSPITermsColMap(array $header):array{
    $aliases=[
        'package_code'=>['supplierpackagecode','supplierpackagecode*','packagecode'],
        'season_name'=>['appliestoseason','season','seasonname'],
        'child_policy'=>['childpolicy'],
        'hotel_policy'=>['hotelsimilarpolicy','hotelpolicy','hotelavailabilitypolicy'],
        'checkin_policy'=>['checkincheckoutpolicy','checkincheckout'],
        'id_policy'=>['idrequirement','iddocumentpolicy'],
        'operational_note'=>['operationalnotes','operationalnote'],
        'must_carry'=>['mustcarry'],
        'customer_notes'=>['customernotes'],
        'internal_notes'=>['internalnotes','notes']
    ];
    $norm=[];foreach($header as $i=>$h)$norm[tsSPIHeaderKey((string)$h)]=$i;$out=[];
    foreach($aliases as $field=>$keys){$out[$field]=null;foreach($keys as $k){$kk=tsSPIHeaderKey($k);if(array_key_exists($kk,$norm)){$out[$field]=$norm[$kk];break;}}}
    return $out;
}
function tsSPIHasTermsHeader(array $row):bool{$m=tsSPITermsColMap($row);return ($m['package_code']??null)!==null && (($m['child_policy']??null)!==null || ($m['hotel_policy']??null)!==null || ($m['operational_note']??null)!==null);}
function tsSPITermRowValue(array $row,array $map,string $field):string{$i=$map[$field]??null;return $i===null?'':trim((string)($row[$i]??''));}
function tsSPIValidateTermRows(PDO $pdo,array $matrix,int $supplierId,array $rateRows=[]):array{
    if(!$matrix)return [];$header=array_shift($matrix);$map=tsSPITermsColMap($header);$out=[];$rowNo=1;
    foreach($matrix as $row){$rowNo++;$blank=true;foreach($row as $v)if(trim((string)$v)!==''){$blank=false;break;}if($blank)continue;
        $pkg=tsSPITermRowValue($row,$map,'package_code');if($pkg==='')continue;$season=tsSPITermRowValue($row,$map,'season_name');
        if(!tsSPISeasonExistsForPackage($pdo,$supplierId,$pkg,$season,$rateRows))continue;
        $hotel=tsSPITermRowValue($row,$map,'hotel_policy');$check=tsSPITermRowValue($row,$map,'checkin_policy');if($check!=='')$hotel=trim($hotel.($hotel!==''?"\n":'').$check);
        $ops=tsSPITermRowValue($row,$map,'operational_note');$carry=tsSPITermRowValue($row,$map,'must_carry');if($carry!=='')$ops=trim($ops.($ops!==''?"\n":'').'Must Carry: '.$carry);
        $out[]=['row_no'=>$rowNo,'package_code'=>$pkg,'season_name'=>$season,'child_policy'=>tsSPITermRowValue($row,$map,'child_policy'),'hotel_policy'=>$hotel,'id_policy'=>tsSPITermRowValue($row,$map,'id_policy'),'operational_note'=>$ops,'other'=>tsSPITermRowValue($row,$map,'customer_notes'),'internal_notes'=>tsSPITermRowValue($row,$map,'internal_notes')];
    }
    return $out;
}
function tsSPIImportTerms(PDO $pdo,array $rows,int $supplierId,int $adminId):array{
    $stats=['packages_with_terms'=>0,'seasons_updated'=>0];if(!$rows)return $stats;
    foreach($rows as $r){$pkg=trim((string)($r['package_code']??''));if($pkg==='')continue;$contractId=tsSPIFindPackage($pdo,$supplierId,$pkg);if($contractId<=0)continue;$versions=tsMSVersions($pdo,$contractId);$season=trim((string)($r['season_name']??''));$touched=false;
        foreach($versions as $v){if($season!==''&&strcasecmp(trim((string)($v['season_name']??'')),$season)!==0)continue;
            tsMSSavePolicies($pdo,(int)$v['id'],[
                'child_policy'=>(string)($r['child_policy']??''),'child_policy_visibility'=>'both',
                'hotel_policy'=>(string)($r['hotel_policy']??''),'hotel_policy_visibility'=>'both',
                'id_policy'=>(string)($r['id_policy']??''),'id_policy_visibility'=>'both',
                'operational_note'=>(string)($r['operational_note']??''),'operational_note_visibility'=>'both',
                'other'=>(string)($r['other']??''),'other_visibility'=>'both'
            ],$adminId);
            $stats['seasons_updated']++;$touched=true;
        }
        if($touched)$stats['packages_with_terms']++;
    }
    return $stats;
}

function tsSPIValidateContentRows(PDO $pdo,array $matrix,int $supplierId,array $rateRows=[]):array{
    if(!$matrix)return [];$header=array_shift($matrix);$map=tsSPIContentColMap($header);$out=[];$rowNo=1;
    foreach($matrix as $row){$rowNo++;$blank=true;foreach($row as $v)if(trim((string)$v)!==''){$blank=false;break;}if($blank)continue;
        $pkg=tsSPIContentRowValue($row,$map,'package_code');if($pkg==='')continue;
        $errors=[];if(!tsSPISeasonExistsForPackage($pdo,$supplierId,$pkg,'',$rateRows))$errors[]='Supplier package not found in rates/import or existing Supplier Packages.';
        $shortTrimmed=false;$fullTrimmed=false;$detailTrimmed=false;
        $short=tsSPIImportWordLimit(tsSPIContentRowValue($row,$map,'short_description'),100,$shortTrimmed);
        $full=tsSPIImportWordLimit(tsSPIContentRowValue($row,$map,'full_description'),200,$fullTrimmed);
        $detail=tsSPIImportWordLimit(tsSPIContentRowValue($row,$map,'detailed_itinerary'),200,$detailTrimmed);
        $high=tsSPIContentRowValue($row,$map,'tour_highlights');$terms=tsSPIContentRowValue($row,$map,'package_terms');
        if($short===''&&$full===''&&$high===''&&$terms==='')continue;
        $shortWords=tsSPIImportWordCount($short);$fullWords=tsSPIImportWordCount($full);$detailWords=tsSPIImportWordCount($detail);
        $warnings=[];if($short!==''&&$shortWords<90)$warnings[]='Short Description has '.$shortWords.' words; Package Master will professionally expand it to the 90–100 word standard using confirmed package data.';if($full!==''&&$fullWords<190)$warnings[]='Full Package Description has '.$fullWords.' words; Package Master will professionally expand it to the 190–200 word standard using confirmed package data.';if($detail!==''&&$detailWords<190)$warnings[]='Detailed Day-wise Itinerary has '.$detailWords.' words; day-level import uses the 190–200 word narrative standard.';if($shortTrimmed)$warnings[]='Short Description exceeded 100 words and was safely limited to the first 100 words.';if($fullTrimmed)$warnings[]='Full Package Description exceeded 200 words and was safely limited to the first 200 words.';if($detailTrimmed)$warnings[]='Detailed Day-wise Itinerary exceeded 200 words and was safely limited to the first 200 words.';
        $out[]=['row_no'=>$rowNo,'package_code'=>$pkg,'short_description'=>$short,'full_description'=>$full,'detailed_itinerary'=>$detail,'tour_highlights'=>$high,'package_terms'=>$terms,'source_itinerary'=>tsSPIContentRowValue($row,$map,'source_itinerary'),'source_rate_sheet'=>tsSPIContentRowValue($row,$map,'source_rate_sheet'),'errors'=>$errors,'warnings'=>$warnings];
    }
    return $out;
}
function tsSPIImportPackageContent(PDO $pdo,array $rows,int $supplierId,int $adminId):array{
    $stats=['packages_with_content'=>0,'seasons_updated'=>0,'content_fields_saved'=>0];if(!$rows||!tsMSTable($pdo,'supplier_contract_policy_items'))return $stats;
    $titles=[
        'short_description'=>'TRAVSCOPE Package Short Description',
        'full_description'=>'TRAVSCOPE Package Full Description',
        'tour_highlights'=>'TRAVSCOPE Tour Highlights',
        'package_terms'=>'TRAVSCOPE Package Terms & Conditions'
    ];
    foreach($rows as $r){if(!empty($r['errors']))continue;$pkg=trim((string)($r['package_code']??''));if($pkg==='')continue;$contractId=tsSPIFindPackage($pdo,$supplierId,$pkg);if($contractId<=0)continue;$versions=tsMSVersions($pdo,$contractId);$touched=false;
        foreach($versions as $v){$versionId=(int)$v['id'];if($versionId<=0)continue;
            $del=$pdo->prepare("DELETE FROM supplier_contract_policy_items WHERE contract_version_id=? AND policy_type='other' AND title IN (?,?,?,?)");
            $del->execute([$versionId,$titles['short_description'],$titles['full_description'],$titles['tour_highlights'],$titles['package_terms']]);
            $ins=$pdo->prepare("INSERT INTO supplier_contract_policy_items(contract_version_id,policy_type,title,content,visibility,status,created_by_admin_id,updated_by_admin_id) VALUES(?,'other',?,?,'customer','active',?,?)");
            foreach($titles as $key=>$title){$value=trim((string)($r[$key]??''));if($value==='')continue;$ins->execute([$versionId,$title,$value,$adminId?:null,$adminId?:null]);$stats['content_fields_saved']++;$touched=true;}
            if($touched)$stats['seasons_updated']++;
        }
        if($touched)$stats['packages_with_content']++;
    }
    return $stats;
}

function tsSPISeasonExistsForPackage(PDO $pdo,int $supplierId,string $packageCode,string $seasonName,array $rateRows=[]):bool{
    $packageFound=false;foreach($rateRows as $r){if(strcasecmp(trim((string)($r['package_code']??'')),$packageCode)!==0)continue;$packageFound=true;if($seasonName!==''&&strcasecmp(trim((string)($r['season_name']??'')),$seasonName)===0)return true;}
    if($seasonName===''&&$packageFound)return true;
    $contractId=tsSPIFindPackage($pdo,$supplierId,$packageCode);if($contractId<=0)return false;if($seasonName==='')return true;
    $s=$pdo->prepare('SELECT id FROM supplier_contract_versions WHERE contract_id=? AND LOWER(TRIM(season_name))=LOWER(TRIM(?)) LIMIT 1');$s->execute([$contractId,$seasonName]);return (bool)$s->fetchColumn();
}
function tsSPIValidateDayRows(PDO $pdo,array $matrix,int $supplierId,array $rateRows=[]):array{
    if(!$matrix)return [];$header=array_shift($matrix);$map=tsSPIDayColMap($header);
    foreach(['package_code','day_no','day_title','description'] as $f)if(($map[$f]??null)===null)throw new RuntimeException('Day_Wise_Itinerary sheet is missing required column: '.str_replace('_',' ',ucwords($f,'_')).'.');
    $out=[];$seen=[];$rowNo=1;
    foreach($matrix as $row){$rowNo++;$blank=true;foreach($row as $v)if(trim((string)$v)!==''){$blank=false;break;}if($blank)continue;if(count($out)>=5000)break;
        $pkg=tsSPIDayRowValue($row,$map,'package_code');$season=tsSPIDayRowValue($row,$map,'season_name');$dayNo=(int)tsSPIDayRowValue($row,$map,'day_no');$title=tsSPIDayRowValue($row,$map,'day_title');$rawDesc=tsSPIStripFollowingDaySpill(tsSPIDayRowValue($row,$map,'description'),$dayNo);$overnight=tsSPIDayRowValue($row,$map,'overnight_city');$facts=['start_location'=>tsSPIDayRowValue($row,$map,'start_location'),'via_route'=>tsSPIDayRowValue($row,$map,'via_route'),'end_location'=>tsSPIDayRowValue($row,$map,'end_location'),'overnight_city'=>$overnight,'distance_km'=>tsSPIDayRowValue($row,$map,'distance_km'),'travel_time'=>tsSPIDayRowValue($row,$map,'travel_time'),'meals'=>tsSPIDayRowValue($row,$map,'meals')];$descExpanded=false;$descTrimmed=false;$sourceWords=tsSPIImportWordCount($rawDesc);$desc=tsSPIFitIntellectualNarrative($rawDesc,$facts,190,200,$descExpanded,$descTrimmed);$status=tsSPINormStatus(tsSPIDayRowValue($row,$map,'status')?:'active');$errors=[];$warnings=[];$descWords=tsSPIImportWordCount($desc);if($descExpanded)$warnings[]='Detailed Day Itinerary expanded from '.$sourceWords.' to '.$descWords.' words using only confirmed route, travel and supplier-package facts.';if($descTrimmed)$warnings[]='Detailed Day Itinerary exceeded 200 words and was safely limited to 200 words.';
        if($pkg==='')$errors[]='Supplier Package Code is required.';if($dayNo<=0)$errors[]='Day No must be greater than 0.';if($title==='')$errors[]='Day Title is required.';if($desc==='')$errors[]='Detailed Day Itinerary is required.';
        if($pkg!==''&&!tsSPISeasonExistsForPackage($pdo,$supplierId,$pkg,$season,$rateRows))$errors[]=$season!==''?'Named season not found for this supplier package.':'Supplier package not found in rates/import or existing Supplier Packages.';
        $key=strtolower($pkg.'|'.($season!==''?$season:'__all__').'|'.$dayNo);if(isset($seen[$key]))$errors[]='Duplicate Day No for the same package/season in this workbook.';$seen[$key]=1;
        $out[]=['row_no'=>$rowNo,'package_code'=>$pkg,'season_name'=>$season,'day_no'=>$dayNo,'day_title'=>$title,'start_location'=>tsSPIDayRowValue($row,$map,'start_location'),'via_route'=>tsSPIDayRowValue($row,$map,'via_route'),'end_location'=>tsSPIDayRowValue($row,$map,'end_location'),'overnight_city'=>$overnight,'description'=>$desc,'meals'=>tsSPIDayRowValue($row,$map,'meals'),'distance_km'=>tsSPIDayRowValue($row,$map,'distance_km'),'travel_time'=>tsSPIDayRowValue($row,$map,'travel_time'),'internal_note'=>tsSPIDayRowValue($row,$map,'internal_note'),'status'=>$status,'excluded'=>false,'errors'=>$errors,'warnings'=>$warnings];
    }
    return $out;
}
function tsSPIRevalidateDay(PDO $pdo,array $r,int $supplierId,array $rateRows,array $edit=[]):array{
    if($edit){$r['excluded']=empty($edit['include']);foreach(['package_code','season_name','day_title','start_location','via_route','end_location','overnight_city','description','meals','distance_km','travel_time','internal_note','status'] as $k)if(array_key_exists($k,$edit))$r[$k]=trim((string)$edit[$k]);if(array_key_exists('day_no',$edit))$r['day_no']=(int)$edit['day_no'];}
    if(!empty($r['excluded'])){$r['errors']=[];$r['warnings']=[];return $r;}
    $r['status']=tsSPINormStatus((string)($r['status']??'active'));$errors=[];$warnings=[];$pkg=trim((string)($r['package_code']??''));$season=trim((string)($r['season_name']??''));
    $cleanDesc=tsSPIStripFollowingDaySpill((string)($r['description']??''),(int)($r['day_no']??0));$sourceWords=tsSPIImportWordCount($cleanDesc);$descExpanded=false;$descTrimmed=false;$r['description']=tsSPIFitIntellectualNarrative($cleanDesc,$r,190,200,$descExpanded,$descTrimmed);$descWords=tsSPIImportWordCount((string)$r['description']);if($descExpanded)$warnings[]='Detailed Day Itinerary expanded from '.$sourceWords.' to '.$descWords.' words using only confirmed route, travel and supplier-package facts.';if($descTrimmed)$warnings[]='Detailed Day Itinerary exceeded 200 words and was safely limited to 200 words.';
    if($pkg==='')$errors[]='Supplier Package Code is required.';if((int)($r['day_no']??0)<=0)$errors[]='Day No must be greater than 0.';if(trim((string)($r['day_title']??''))==='')$errors[]='Day Title is required.';if(trim((string)($r['description']??''))==='')$errors[]='Detailed Day Itinerary is required.';if($pkg!==''&&!tsSPISeasonExistsForPackage($pdo,$supplierId,$pkg,$season,$rateRows))$errors[]='Package/season not found.';$r['errors']=$errors;$r['warnings']=$warnings;return $r;
}
function tsSPIApplyDayCorrections(PDO $pdo,array $rows,int $supplierId,array $rateRows,array $posted):array{$out=[];foreach($rows as $i=>$r)$out[]=tsSPIRevalidateDay($pdo,$r,$supplierId,$rateRows,is_array($posted[$i]??null)?$posted[$i]:[]);return $out;}
function tsSPIFormalDayText(string $value): string
{
    $value=html_entity_decode(strip_tags($value),ENT_QUOTES|ENT_HTML5,'UTF-8');
    $value=str_replace(["\r\n","\r"],"\n",$value);
    $replacements=[
        '/\bRly\.?\s*Station\b/i'=>'Railway Station',
        '/\bGuwahatiAirport\b/i'=>'Guwahati Airport',
        '/\bElephanta\s+Falls?\b/i'=>'Elephant Falls',
        '/\bElephantaFall\b/i'=>'Elephant Falls',
        '/\bUmium Lake\b/i'=>'Umiam Lake',
        '/\bWard[’\']s\s+Lak\b/i'=>'Ward’s Lake',
        '/\bNabagraha\s*Temple\b/i'=>'Nabagraha Temple',
        '/\bIndo\s*[-–]?\s*BangladeshBorder\b/i'=>'Indo–Bangladesh Border',
        '/\bBomla\s*Pass\b/i'=>'Bumla Pass',
        '/\bMonestary\b/i'=>'Monastery',
    ];
    foreach($replacements as $pattern=>$replacement)$value=preg_replace($pattern,$replacement,$value)??$value;
    $value=str_replace(' & ',' and ',$value);
    $value=preg_replace('/\s+([,.;:])/u','$1',$value)??$value;
    $value=preg_replace('/([,.;:])(?=[A-Za-z])/u','$1 ',$value)??$value;
    $value=preg_replace('/\.{2,}/u','.',$value)??$value;
    $value=preg_replace('/[ \t]{2,}/u',' ',$value)??$value;
    $value=preg_replace('/ *\n */u',"\n",$value)??$value;
    $value=preg_replace('/\n{3,}/u',"\n\n",$value)??$value;
    $value=preg_replace('/\bAfter early breakfast drive\b/i','After an early breakfast, drive',$value)??$value;
    $value=preg_replace('/\bAfter early breakfast proceed\b/i','After an early breakfast, proceed',$value)??$value;
    $value=preg_replace('/\bAfter breakfast check out\b/i','After breakfast, check out',$value)??$value;
    $value=preg_replace('/\bOn the way\b/i','En route',$value)??$value;
    $value=preg_replace('/\bAlong the way\b/i','En route',$value)??$value;
    $value=preg_replace('/\breturn back\b/i','return',$value)??$value;
    $value=preg_replace('/\bby Own\b/i','at leisure',$value)??$value;
    $value=str_replace(['Hotel&','hotel&','connectsIndia','evenotherwise','longand','highmulti-hued','Jeep Safar','Sunda y'],['hotel and ','hotel and ','connects India','even otherwise','long and','high multi-hued','Jeep Safari','Sunday'],$value);
    $value=preg_replace('/\bAfter breakfast out to visit\b/i','After breakfast, proceed for local sightseeing and visit',$value)??$value;
    $value=preg_replace('/\bThen back to\b/i','Later, return to',$value)??$value;
    $value=preg_replace('/\bCheck out from Hotel\b/i','check out from the hotel',$value)??$value;
    $value=preg_replace('/\bChurch later transfer\b/i','Church, and later transfer',$value)??$value;
    $value=preg_replace('/\bIF Time permit Visit\b/i','if time permits, visit',$value)??$value;
    return trim($value);
}
function tsSPIComposeDayDescription(array $r):string{
    $dayNo=(int)($r['day_no']??0);
    $sourceMain=tsSPIStripFollowingDaySpill((string)($r['description']??''),$dayNo);
    $narrativeExpanded=false;$narrativeTrimmed=false;
    $narrative=tsSPIFitIntellectualNarrative($sourceMain,$r,190,200,$narrativeExpanded,$narrativeTrimmed);

    /*
     * V24.89: the 190–200 word requirement applies to the intellectual-client
     * narrative only. Operational route facts are stored after it as separate
     * metadata so they do not consume the narrative word allowance.
     */
    $meta=[];
    $start=tsSPIFormalDayText((string)($r['start_location']??''));
    $via=tsSPIFormalDayText((string)($r['via_route']??''));
    $end=tsSPIFormalDayText((string)($r['end_location']??''));
    $distance=trim((string)($r['distance_km']??''));
    $travelTime=trim((string)($r['travel_time']??''));
    $overnight=tsSPIFormalDayText((string)($r['overnight_city']??''));
    $meals=trim((string)($r['meals']??''));

    if($start!=='')$meta[]='Start: '.$start;
    if($via!=='')$meta[]='Via/Sightseeing: '.$via;
    if($end!=='')$meta[]='End: '.$end;
    if($distance!=='')$meta[]='Distance: '.$distance.' km';
    if($travelTime!=='')$meta[]='Approx travel time: '.$travelTime;
    $routeMeta=$meta?'['.implode(' | ',$meta).']':'';

    $stayMeta=[];
    if($overnight!=='')$stayMeta[]='Overnight: '.$overnight;
    if($meals!=='')$stayMeta[]='Meals: '.$meals;
    $stayLine=$stayMeta?'['.implode(' | ',$stayMeta).']':'';

    return trim(implode("

",array_values(array_filter([$narrative,$routeMeta,$stayLine],fn($v)=>$v!==''))));
}
function tsSPIImportDays(PDO $pdo,array $rows,int $supplierId,int $adminId):array{
    $usable=array_values(array_filter($rows,fn($r)=>empty($r['excluded'])&&empty($r['errors'])));$stats=['packages_with_itinerary'=>0,'seasons_updated'=>0,'days_saved'=>0];if(!$usable)return $stats;
    $byPackage=[];foreach($usable as $r)$byPackage[strtolower(trim((string)$r['package_code']))][]=$r;
    foreach($byPackage as $pkgRows){$packageCode=(string)$pkgRows[0]['package_code'];$contractId=tsSPIFindPackage($pdo,$supplierId,$packageCode);if($contractId<=0)continue;$seasons=tsMSVersions($pdo,$contractId);if(!$seasons)continue;$allRows=[];$specific=[];
        foreach($pkgRows as $r){$sn=strtolower(trim((string)($r['season_name']??'')));if($sn==='')$allRows[]=$r;else$specific[$sn][]=$r;}
        $packageTouched=false;
        foreach($seasons as $season){$sn=strtolower(trim((string)($season['season_name']??'')));$selected=$specific[$sn]??$allRows;if(!$selected)continue;usort($selected,fn($a,$b)=>(int)$a['day_no']<=> (int)$b['day_no']);$it=tsMSItineraryForVersion($pdo,(int)$season['id']);if(!$it)continue;$titles=[];$descs=[];$overnights=[];foreach($selected as $r){$titles[]=(string)$r['day_title'];$descs[]=tsSPIComposeDayDescription($r);$overnights[]=(string)($r['overnight_city']??'');}
            tsMSSaveDays($pdo,(int)$season['id'],(int)$it['id'],['day_title'=>$titles,'day_description'=>$descs,'overnight_city'=>$overnights,'status'=>'active'],$adminId);
            if(tsMSTable($pdo,'supplier_contract_day_itineraries')){foreach($selected as $r){$note=trim((string)($r['internal_note']??''));if($note==='')continue;$u=$pdo->prepare('UPDATE supplier_contract_day_itineraries SET source_excerpt=? WHERE itinerary_id=? AND day_number=?');$u->execute([$note,(int)$it['id'],(int)$r['day_no']]);}}
            $stats['seasons_updated']++;$stats['days_saved']+=count($selected);$packageTouched=true;
        }
        if($packageTouched)$stats['packages_with_itinerary']++;
    }
    return $stats;
}
