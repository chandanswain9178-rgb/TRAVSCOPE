<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TRAVSCOPE — TRAVEL EXECUTION + POST-TRIP CLOSURE
|--------------------------------------------------------------------------
|
| Pre-departure readiness remains in operations-functions.php.
| This module begins when the actual journey starts.
|
| No duplicate accounting ledger is created:
| on-tour actual expenses are posted through finance-functions.php into
| booking_actual_direct_costs and therefore flow into Actual Profitability.
|
*/

function tsExecTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];

    $key = strtolower($table);

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    try {
        $stmt = $pdo->prepare("\n            SELECT COUNT(*)\n            FROM information_schema.tables\n            WHERE table_schema = DATABASE()\n              AND table_name = ?\n        ");
        $stmt->execute([$table]);

        return $cache[$key] = ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        return $cache[$key] = false;
    }
}


function tsExecReady(PDO $pdo): bool
{
    return
        tsExecTableExists($pdo, 'booking_execution_states')
        && tsExecTableExists($pdo, 'booking_execution_contacts')
        && tsExecTableExists($pdo, 'booking_execution_updates')
        && tsExecTableExists($pdo, 'booking_execution_incidents')
        && tsExecTableExists($pdo, 'booking_execution_checks')
        && tsExecTableExists($pdo, 'bookings');
}


function tsExecContactTypes(): array
{
    return [
        'driver' => 'Driver / Transport',
        'guide' => 'Guide',
        'hotel' => 'Hotel / Front Desk',
        'airport_rep' => 'Airport Representative',
        'activity' => 'Activity Contact',
        'local_support' => 'Local Support',
        'emergency' => 'Emergency Contact',
        'other' => 'Other Operational Contact',
    ];
}


function tsExecUpdateTypes(): array
{
    return [
        'general' => 'General Update',
        'pickup' => 'Pickup / Transfer',
        'hotel' => 'Hotel',
        'transport' => 'Transport',
        'activity' => 'Activity / Sightseeing',
        'customer_update' => 'Customer Update',
        'supplier_update' => 'Supplier Update',
        'delay' => 'Delay / Timing Change',
        'completion' => 'Completion Update',
    ];
}


function tsExecIncidentTypes(): array
{
    return [
        'service_issue' => 'Service Issue',
        'hotel_issue' => 'Hotel Issue',
        'transport_issue' => 'Transport Issue',
        'delay' => 'Delay / Schedule Issue',
        'customer_support' => 'Customer Support',
        'medical' => 'Medical / Health Support',
        'safety' => 'Safety / Emergency',
        'supplier_failure' => 'Supplier Failure',
        'other' => 'Other Incident',
    ];
}


function tsExecCheckDefinitions(): array
{
    return [
        'all_booked_services_delivered' => 'All Booked Services Delivered / Accounted For',
        'final_hotel_transport_handover' => 'Final Hotel / Transport / Guide Handover Verified',
        'on_tour_expenses_posted' => 'All On-Tour Expenses / Adjustments Posted',
        'unused_refundable_services_reviewed' => 'Unused / Refundable Services Reviewed',
        'guest_handover_completed' => 'Guest Final Handover / Departure Completed',
    ];
}


function tsExecTripLink(PDO $pdo, int $bookingId): ?array
{
    if (
        $bookingId <= 0
        || !tsExecTableExists($pdo, 'booking_trip_links')
    ) {
        return null;
    }

    $stmt = $pdo->prepare("\n        SELECT\n            l.*,\n            t.trip_code\n        FROM booking_trip_links l\n        LEFT JOIN trips t\n            ON t.id = l.trip_id\n        WHERE l.booking_id = ?\n        LIMIT 1\n    ");
    $stmt->execute([$bookingId]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function tsExecEnsureState(PDO $pdo, int $bookingId): ?array
{
    if ($bookingId <= 0 || !tsExecReady($pdo)) {
        return null;
    }

    $tripLink = tsExecTripLink($pdo, $bookingId);

    $stmt = $pdo->prepare("\n        INSERT IGNORE INTO booking_execution_states\n        (booking_id, trip_id, execution_status)\n        VALUES (?, ?, 'pre_departure')\n    ");
    $stmt->execute([
        $bookingId,
        $tripLink && !empty($tripLink['trip_id'])
            ? (int)$tripLink['trip_id']
            : null,
    ]);

    $stmt = $pdo->prepare("\n        SELECT *\n        FROM booking_execution_states\n        WHERE booking_id = ?\n        LIMIT 1\n    ");
    $stmt->execute([$bookingId]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}


function tsExecEnsureChecks(PDO $pdo, int $bookingId): void
{
    if ($bookingId <= 0 || !tsExecReady($pdo)) {
        return;
    }

    $stmt = $pdo->prepare("\n        INSERT IGNORE INTO booking_execution_checks\n        (booking_id, check_key, label, is_required, is_complete)\n        VALUES (?, ?, ?, 1, 0)\n    ");

    foreach (tsExecCheckDefinitions() as $key => $label) {
        $stmt->execute([
            $bookingId,
            $key,
            $label,
        ]);
    }
}


function tsExecChecks(PDO $pdo, int $bookingId): array
{
    if ($bookingId <= 0 || !tsExecReady($pdo)) {
        return [];
    }

    tsExecEnsureChecks($pdo, $bookingId);

    $stmt = $pdo->prepare("\n        SELECT *\n        FROM booking_execution_checks\n        WHERE booking_id = ?\n        ORDER BY id ASC\n    ");
    $stmt->execute([$bookingId]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsExecContacts(PDO $pdo, int $bookingId, bool $customerOnly = false): array
{
    if ($bookingId <= 0 || !tsExecReady($pdo)) {
        return [];
    }

    $sql = "\n        SELECT *\n        FROM booking_execution_contacts\n        WHERE booking_id = ?\n          AND is_active = 1\n    ";

    if ($customerOnly) {
        $sql .= " AND customer_visible = 1 ";
    }

    $sql .= " ORDER BY sort_order ASC, id ASC ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$bookingId]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsExecUpdates(PDO $pdo, int $bookingId, bool $customerOnly = false): array
{
    if ($bookingId <= 0 || !tsExecReady($pdo)) {
        return [];
    }

    $sql = "\n        SELECT *\n        FROM booking_execution_updates\n        WHERE booking_id = ?\n    ";

    if ($customerOnly) {
        $sql .= " AND customer_visible = 1 ";
    }

    $sql .= " ORDER BY created_at DESC, id DESC LIMIT 60 ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$bookingId]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsExecIncidents(PDO $pdo, int $bookingId, bool $customerOnly = false): array
{
    if ($bookingId <= 0 || !tsExecReady($pdo)) {
        return [];
    }

    $sql = "\n        SELECT *\n        FROM booking_execution_incidents\n        WHERE booking_id = ?\n    ";

    if ($customerOnly) {
        $sql .= " AND customer_visible = 1 ";
    }

    $sql .= "\n        ORDER BY\n            CASE status\n                WHEN 'open' THEN 0\n                WHEN 'monitoring' THEN 1\n                ELSE 2\n            END,\n            CASE severity\n                WHEN 'critical' THEN 0\n                WHEN 'high' THEN 1\n                WHEN 'medium' THEN 2\n                ELSE 3\n            END,\n            created_at DESC, id DESC\n    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$bookingId]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}


function tsExecStart(PDO $pdo, int $bookingId, int $adminId): array
{
    if (!tsExecReady($pdo)) {
        throw new RuntimeException(
            'Travel Execution SQL is not installed yet.'
        );
    }

    $stmt = $pdo->prepare("\n        SELECT booking_status\n        FROM bookings\n        WHERE id = ?\n        LIMIT 1\n    ");
    $stmt->execute([$bookingId]);

    $bookingStatus =
        strtolower(
            (string)(
                $stmt->fetchColumn()
                ?: ''
            )
        );

    if ($bookingStatus !== 'confirmed') {
        throw new RuntimeException(
            'Trip Execution can start only after the Booking is Confirmed.'
        );
    }

    if (
        function_exists('tsOpsReady')
        && function_exists('tsOpsReadiness')
        && tsOpsReady($pdo)
    ) {
        $ops = tsOpsReadiness($pdo, $bookingId);

        if (empty($ops['ready'])) {
            throw new RuntimeException(
                'Operations Readiness must be complete before starting the Trip.'
            );
        }
    }

    $state = tsExecEnsureState($pdo, $bookingId);

    if (!$state) {
        throw new RuntimeException(
            'Unable to prepare Trip Execution state.'
        );
    }

    if ((string)$state['execution_status'] === 'completed') {
        throw new RuntimeException(
            'Trip Execution is already completed.'
        );
    }

    $stmt = $pdo->prepare("\n        UPDATE booking_execution_states\n        SET\n            execution_status = 'in_progress',\n            started_at = COALESCE(started_at, NOW()),\n            started_by_admin_id = COALESCE(started_by_admin_id, ?),\n            updated_at = NOW()\n        WHERE booking_id = ?\n    ");
    $stmt->execute([
        $adminId > 0 ? $adminId : null,
        $bookingId,
    ]);

    tsExecEnsureChecks($pdo, $bookingId);

    $pdo->prepare("\n        INSERT INTO booking_execution_updates\n        (booking_id, update_type, title, details, customer_visible, created_by_admin_id)\n        VALUES (?, 'general', 'Trip execution started', 'The journey has moved into live travel execution.', 1, ?)\n    ")->execute([
        $bookingId,
        $adminId > 0 ? $adminId : null,
    ]);

    $tripLink = tsExecTripLink($pdo, $bookingId);

    if (
        $tripLink
        && !empty($tripLink['trip_id'])
        && tsExecTableExists($pdo, 'trips')
    ) {
        $pdo->prepare("\n            UPDATE trips\n            SET\n                next_action = 'Trip in progress - monitor operations',\n                next_action_date = NULL,\n                updated_at = NOW()\n            WHERE id = ?\n        ")->execute([
            (int)$tripLink['trip_id'],
        ]);
    }

    return tsExecEnsureState($pdo, $bookingId) ?: [];
}


function tsExecAddContact(
    PDO $pdo,
    int $bookingId,
    int $adminId,
    array $input
): int {
    if (!tsExecReady($pdo)) {
        throw new RuntimeException(
            'Travel Execution SQL is not installed yet.'
        );
    }

    $type =
        strtolower(
            trim(
                (string)(
                    $input['execution_contact_type']
                    ?? 'other'
                )
            )
        );

    if (!array_key_exists($type, tsExecContactTypes())) {
        $type = 'other';
    }

    $name =
        trim(
            (string)(
                $input['execution_contact_name']
                ?? ''
            )
        );

    if ($name === '') {
        throw new RuntimeException(
            'Operational contact name is required.'
        );
    }

    $serviceId =
        max(
            0,
            (int)(
                $input['execution_contact_service_id']
                ?? 0
            )
        );

    if ($serviceId > 0 && tsExecTableExists($pdo, 'booking_service_snapshots')) {
        $stmt = $pdo->prepare("\n            SELECT COUNT(*)\n            FROM booking_service_snapshots\n            WHERE id = ?\n              AND booking_id = ?\n        ");
        $stmt->execute([
            $serviceId,
            $bookingId,
        ]);

        if ((int)$stmt->fetchColumn() !== 1) {
            throw new RuntimeException(
                'Selected Booking service is invalid.'
            );
        }
    }

    $stmt = $pdo->prepare("\n        SELECT COALESCE(MAX(sort_order),0)+10\n        FROM booking_execution_contacts\n        WHERE booking_id = ?\n    ");
    $stmt->execute([$bookingId]);
    $sortOrder = (int)$stmt->fetchColumn();

    $stmt = $pdo->prepare("\n        INSERT INTO booking_execution_contacts\n        (\n            booking_id,\n            booking_service_snapshot_id,\n            contact_type,\n            contact_name,\n            organization,\n            mobile,\n            whatsapp,\n            email,\n            details,\n            customer_visible,\n            is_active,\n            sort_order,\n            created_by_admin_id\n        )\n        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)\n    ");

    $stmt->execute([
        $bookingId,
        $serviceId > 0 ? $serviceId : null,
        $type,
        $name,
        trim((string)($input['execution_contact_organization'] ?? '')) ?: null,
        trim((string)($input['execution_contact_mobile'] ?? '')) ?: null,
        trim((string)($input['execution_contact_whatsapp'] ?? '')) ?: null,
        trim((string)($input['execution_contact_email'] ?? '')) ?: null,
        trim((string)($input['execution_contact_details'] ?? '')) ?: null,
        !empty($input['execution_contact_customer_visible']) ? 1 : 0,
        $sortOrder,
        $adminId > 0 ? $adminId : null,
    ]);

    return (int)$pdo->lastInsertId();
}


function tsExecDeactivateContact(
    PDO $pdo,
    int $bookingId,
    int $contactId
): void {
    $stmt = $pdo->prepare("\n        UPDATE booking_execution_contacts\n        SET is_active = 0, updated_at = NOW()\n        WHERE id = ?\n          AND booking_id = ?\n          AND is_active = 1\n    ");
    $stmt->execute([
        $contactId,
        $bookingId,
    ]);

    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException(
            'Operational contact could not be removed.'
        );
    }
}


function tsExecAddUpdate(
    PDO $pdo,
    int $bookingId,
    int $adminId,
    array $input
): int {
    if (!tsExecReady($pdo)) {
        throw new RuntimeException(
            'Travel Execution SQL is not installed yet.'
        );
    }

    $type =
        strtolower(
            trim(
                (string)(
                    $input['execution_update_type']
                    ?? 'general'
                )
            )
        );

    if (!array_key_exists($type, tsExecUpdateTypes())) {
        $type = 'general';
    }

    $title =
        trim(
            (string)(
                $input['execution_update_title']
                ?? ''
            )
        );

    $details =
        trim(
            (string)(
                $input['execution_update_details']
                ?? ''
            )
        );

    if ($title === '') {
        throw new RuntimeException(
            'Execution update title is required.'
        );
    }

    $serviceId =
        max(
            0,
            (int)(
                $input['execution_update_service_id']
                ?? 0
            )
        );

    $stmt = $pdo->prepare("\n        INSERT INTO booking_execution_updates\n        (\n            booking_id,\n            booking_service_snapshot_id,\n            update_type,\n            title,\n            details,\n            customer_visible,\n            created_by_admin_id\n        )\n        VALUES (?, ?, ?, ?, ?, ?, ?)\n    ");
    $stmt->execute([
        $bookingId,
        $serviceId > 0 ? $serviceId : null,
        $type,
        $title,
        $details !== '' ? $details : null,
        !empty($input['execution_update_customer_visible']) ? 1 : 0,
        $adminId > 0 ? $adminId : null,
    ]);

    return (int)$pdo->lastInsertId();
}


function tsExecAddIncident(
    PDO $pdo,
    int $bookingId,
    int $adminId,
    array $input
): int {
    if (!tsExecReady($pdo)) {
        throw new RuntimeException(
            'Travel Execution SQL is not installed yet.'
        );
    }

    $tripLink = tsExecTripLink($pdo, $bookingId);

    $type =
        strtolower(
            trim(
                (string)(
                    $input['execution_incident_type']
                    ?? 'service_issue'
                )
            )
        );

    if (!array_key_exists($type, tsExecIncidentTypes())) {
        $type = 'other';
    }

    $severity =
        strtolower(
            trim(
                (string)(
                    $input['execution_incident_severity']
                    ?? 'medium'
                )
            )
        );

    if (!in_array($severity, ['low','medium','high','critical'], true)) {
        $severity = 'medium';
    }

    $title =
        trim(
            (string)(
                $input['execution_incident_title']
                ?? ''
            )
        );

    $description =
        trim(
            (string)(
                $input['execution_incident_description']
                ?? ''
            )
        );

    if ($title === '' || $description === '') {
        throw new RuntimeException(
            'Incident title and description are required.'
        );
    }

    $serviceId =
        max(
            0,
            (int)(
                $input['execution_incident_service_id']
                ?? 0
            )
        );

    $actualCost =
        round(
            max(
                0,
                (float)(
                    $input['execution_incident_actual_cost']
                    ?? 0
                )
            ),
            2
        );

    $pdo->beginTransaction();

    try {
        $stmt = $pdo->prepare("\n            INSERT INTO booking_execution_incidents\n            (\n                booking_id,\n                trip_id,\n                booking_service_snapshot_id,\n                incident_type,\n                severity,\n                title,\n                description,\n                status,\n                customer_visible,\n                customer_note,\n                actual_cost_amount,\n                opened_by_admin_id\n            )\n            VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?, ?, ?, ?)\n        ");
        $stmt->execute([
            $bookingId,
            $tripLink && !empty($tripLink['trip_id'])
                ? (int)$tripLink['trip_id']
                : null,
            $serviceId > 0 ? $serviceId : null,
            $type,
            $severity,
            $title,
            $description,
            !empty($input['execution_incident_customer_visible']) ? 1 : 0,
            trim((string)($input['execution_incident_customer_note'] ?? '')) ?: null,
            $actualCost,
            $adminId > 0 ? $adminId : null,
        ]);

        $incidentId = (int)$pdo->lastInsertId();

        $directCostId = null;

        if ($actualCost > 0.009) {
            if (
                !function_exists('tsFinReady')
                || !function_exists('tsFinAddDirectCost')
                || !tsFinReady($pdo)
            ) {
                throw new RuntimeException(
                    'Finance module must be installed before posting an incident actual cost.'
                );
            }

            /*
             * We are already inside a transaction. Insert directly into the same
             * authoritative actual-direct-cost table instead of opening another
             * finance transaction or creating a duplicate execution ledger.
             */
            $stmt = $pdo->prepare("\n                SELECT currency\n                FROM bookings\n                WHERE id = ?\n                LIMIT 1\n            ");
            $stmt->execute([$bookingId]);
            $currency = strtoupper(trim((string)($stmt->fetchColumn() ?: 'INR')));

            $stmt = $pdo->prepare("\n                INSERT INTO booking_actual_direct_costs\n                (\n                    booking_id,\n                    trip_id,\n                    cost_type,\n                    description,\n                    amount,\n                    currency,\n                    cost_date,\n                    status,\n                    notes,\n                    created_by_admin_id\n                )\n                VALUES (?, ?, 'emergency', ?, ?, ?, CURRENT_DATE(), 'posted', ?, ?)\n            ");
            $stmt->execute([
                $bookingId,
                $tripLink && !empty($tripLink['trip_id'])
                    ? (int)$tripLink['trip_id']
                    : null,
                'On-tour incident: ' . $title,
                $actualCost,
                $currency !== '' ? $currency : 'INR',
                $description,
                $adminId > 0 ? $adminId : null,
            ]);

            $directCostId = (int)$pdo->lastInsertId();

            $pdo->prepare("\n                UPDATE booking_execution_incidents\n                SET actual_direct_cost_id = ?\n                WHERE id = ?\n            ")->execute([
                $directCostId,
                $incidentId,
            ]);
        }

        $pdo->commit();

        return $incidentId;

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $e;
    }
}


function tsExecSetIncidentStatus(
    PDO $pdo,
    int $bookingId,
    int $incidentId,
    int $adminId,
    string $status,
    string $resolution = ''
): void {
    $status = strtolower(trim($status));

    if (!in_array($status, ['open','monitoring','resolved'], true)) {
        throw new RuntimeException(
            'Invalid incident status.'
        );
    }

    $stmt = $pdo->prepare("\n        UPDATE booking_execution_incidents\n        SET\n            status = ?,\n            internal_resolution = ?,\n            resolved_by_admin_id = ?,\n            resolved_at = ?,\n            updated_at = NOW()\n        WHERE id = ?\n          AND booking_id = ?\n    ");
    $stmt->execute([
        $status,
        trim($resolution) !== ''
            ? trim($resolution)
            : null,
        $status === 'resolved' && $adminId > 0
            ? $adminId
            : null,
        $status === 'resolved'
            ? date('Y-m-d H:i:s')
            : null,
        $incidentId,
        $bookingId,
    ]);

    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException(
            'Incident status could not be updated.'
        );
    }
}


function tsExecSaveChecks(
    PDO $pdo,
    int $bookingId,
    int $adminId,
    array $complete,
    array $notes
): void {
    tsExecEnsureChecks($pdo, $bookingId);

    $stmt = $pdo->prepare("\n        UPDATE booking_execution_checks\n        SET\n            is_complete = ?,\n            note = ?,\n            completed_by_admin_id = ?,\n            completed_at = ?,\n            updated_at = NOW()\n        WHERE booking_id = ?\n          AND check_key = ?\n    ");

    foreach (tsExecCheckDefinitions() as $key => $label) {
        $done = !empty($complete[$key]) ? 1 : 0;
        $note = trim((string)($notes[$key] ?? ''));

        $stmt->execute([
            $done,
            $note !== '' ? $note : null,
            $done && $adminId > 0 ? $adminId : null,
            $done ? date('Y-m-d H:i:s') : null,
            $bookingId,
            $key,
        ]);
    }
}


function tsExecCompletionReadiness(PDO $pdo, int $bookingId): array
{
    $state = tsExecEnsureState($pdo, $bookingId);
    $checks = tsExecChecks($pdo, $bookingId);
    $incidents = tsExecIncidents($pdo, $bookingId, false);

    $required = 0;
    $completed = 0;

    foreach ($checks as $check) {
        if (empty($check['is_required'])) {
            continue;
        }

        $required++;

        if (!empty($check['is_complete'])) {
            $completed++;
        }
    }

    $openIncidents = 0;

    foreach ($incidents as $incident) {
        if ((string)$incident['status'] !== 'resolved') {
            $openIncidents++;
        }
    }

    $inProgress =
        $state
        && (string)$state['execution_status'] === 'in_progress';

    return [
        'state' => $state,
        'required_checks' => $required,
        'completed_checks' => $completed,
        'open_incidents' => $openIncidents,
        'ready' =>
            $inProgress
            && $required > 0
            && $completed === $required
            && $openIncidents === 0,
    ];
}


function tsExecComplete(
    PDO $pdo,
    int $bookingId,
    int $adminId,
    string $completionNote,
    ?string $repeatFollowupDate,
    string $repeatFollowupNote = ''
): array {
    if (!tsExecReady($pdo)) {
        throw new RuntimeException(
            'Travel Execution SQL is not installed yet.'
        );
    }

    $readiness = tsExecCompletionReadiness($pdo, $bookingId);

    if (empty($readiness['ready'])) {
        $missing = [];

        if (
            empty($readiness['state'])
            || (string)$readiness['state']['execution_status'] !== 'in_progress'
        ) {
            $missing[] = 'Trip must be In Progress';
        }

        if (
            (int)$readiness['completed_checks']
            < (int)$readiness['required_checks']
        ) {
            $missing[] = 'complete all execution checks';
        }

        if ((int)$readiness['open_incidents'] > 0) {
            $missing[] = 'resolve all open incidents';
        }

        throw new RuntimeException(
            'Cannot complete Trip Execution: '
            . implode('; ', $missing)
            . '.'
        );
    }

    $repeatFollowupDate =
        $repeatFollowupDate !== null
        && trim($repeatFollowupDate) !== ''
            ? trim($repeatFollowupDate)
            : null;

    $pdo->beginTransaction();

    try {
        $stmt = $pdo->prepare("\n            SELECT booking_status\n            FROM bookings\n            WHERE id = ?\n            LIMIT 1\n            FOR UPDATE\n        ");
        $stmt->execute([$bookingId]);

        $bookingStatus =
            strtolower(
                (string)(
                    $stmt->fetchColumn()
                    ?: ''
                )
            );

        if ($bookingStatus !== 'confirmed') {
            throw new RuntimeException(
                'Only a Confirmed Booking can be completed through Trip Execution.'
            );
        }

        $pdo->prepare("\n            UPDATE booking_execution_states\n            SET\n                execution_status = 'completed',\n                completed_at = NOW(),\n                completion_note = ?,\n                repeat_followup_date = ?,\n                repeat_followup_note = ?,\n                completed_by_admin_id = ?,\n                updated_at = NOW()\n            WHERE booking_id = ?\n        ")->execute([
            trim($completionNote) !== ''
                ? trim($completionNote)
                : null,
            $repeatFollowupDate,
            trim($repeatFollowupNote) !== ''
                ? trim($repeatFollowupNote)
                : null,
            $adminId > 0 ? $adminId : null,
            $bookingId,
        ]);

        $pdo->prepare("\n            UPDATE bookings\n            SET booking_status = 'completed', updated_at = NOW()\n            WHERE id = ?\n        ")->execute([$bookingId]);

        $pdo->prepare("\n            INSERT INTO booking_execution_updates\n            (booking_id, update_type, title, details, customer_visible, created_by_admin_id)\n            VALUES (?, 'completion', 'Trip completed', ?, 1, ?)\n        ")->execute([
            $bookingId,
            trim($completionNote) !== ''
                ? trim($completionNote)
                : 'The journey has been completed.',
            $adminId > 0 ? $adminId : null,
        ]);

        $tripLink = tsExecTripLink($pdo, $bookingId);

        if (
            $tripLink
            && !empty($tripLink['trip_id'])
            && tsExecTableExists($pdo, 'trips')
        ) {
            $pdo->prepare("\n                UPDATE trips\n                SET\n                    next_action = 'Post-trip feedback / repeat travel follow-up',\n                    next_action_date = ?,\n                    updated_at = NOW()\n                WHERE id = ?\n            ")->execute([
                $repeatFollowupDate,
                (int)$tripLink['trip_id'],
            ]);
        }

        $pdo->commit();

        return tsExecEnsureState($pdo, $bookingId) ?: [];

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $e;
    }
}
