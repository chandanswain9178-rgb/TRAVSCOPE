<?php
declare(strict_types=1);
if (is_file(__DIR__.'/location-master-functions.php')) require_once __DIR__.'/location-master-functions.php';

/*
|--------------------------------------------------------------------------
| TRAVSCOPE V22 - Supplier Vehicle Options (NO VEHICLE PRICE)
|--------------------------------------------------------------------------
| Vehicle rows are operational options/rules only. Supplier money remains
| in Supplier Package -> Season -> exact PAX -> package category pricing.
*/

function tsSVOTable(PDO $pdo,string $table):bool{
    if(!preg_match('/^[A-Za-z0-9_]+$/',$table)) return false;
    try{$pdo->query("SELECT 1 FROM `{$table}` LIMIT 0");return true;}catch(Throwable $e){}
    try{$q=$pdo->quote($table);$s=$pdo->query('SHOW TABLES LIKE '.$q);return $s?(bool)$s->fetchColumn():false;}catch(Throwable $e){}
    return false;
}
function tsSVOColumn(PDO $pdo,string $table,string $column):bool{
    if(!preg_match('/^[A-Za-z0-9_]+$/',$table)||!preg_match('/^[A-Za-z0-9_]+$/',$column)) return false;
    try{$pdo->query("SELECT `{$column}` FROM `{$table}` LIMIT 0");return true;}catch(Throwable $e){}
    return false;
}
function tsSVONormalize(string $value):string{
    $value=trim($value); if($value==='') return '';
    if(function_exists('iconv')){$v=@iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$value);if($v!==false)$value=$v;}
    $value=strtolower($value);
    $value=preg_replace('/[^a-z0-9]+/',' ',$value)??$value;
    return trim(preg_replace('/\s+/',' ',$value)??$value);
}
function tsSVOEnsureSchema(PDO $pdo):bool{
    if(tsSVOTable($pdo,'supplier_vehicle_options')) return true;
    $sql="CREATE TABLE IF NOT EXISTS supplier_vehicle_options (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      supplier_id BIGINT UNSIGNED NOT NULL,
      destination_id BIGINT UNSIGNED NOT NULL,
      location_id BIGINT UNSIGNED DEFAULT NULL,
      city VARCHAR(150) NOT NULL DEFAULT '',
      supplier_category VARCHAR(120) NOT NULL DEFAULT 'All',
      pax_min INT UNSIGNED NOT NULL DEFAULT 0,
      pax_max INT UNSIGNED NOT NULL DEFAULT 0,
      vehicle_type VARCHAR(160) NOT NULL,
      vehicle_type_normalized VARCHAR(190) NOT NULL,
      ac_basis VARCHAR(30) NOT NULL DEFAULT 'unspecified',
      route_scope VARCHAR(255) DEFAULT NULL,
      notes TEXT DEFAULT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'active',
      created_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
      updated_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_supplier_vehicle_option (supplier_id,destination_id,city,supplier_category,pax_min,pax_max,vehicle_type_normalized),
      KEY idx_svo_supplier_status (supplier_id,status),
      KEY idx_svo_destination_city (destination_id,city),
      KEY idx_svo_location (location_id),
      KEY idx_svo_pax (pax_min,pax_max)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    try{$pdo->exec($sql);}catch(Throwable $e){return false;}
    return tsSVOTable($pdo,'supplier_vehicle_options');
}
function tsSVOReady(PDO $pdo):bool{return tsSVOTable($pdo,'supplier_vehicle_options');}
function tsSVOSupplier(PDO $pdo,int $supplierId):?array{
    if($supplierId<=0||!tsSVOTable($pdo,'suppliers')) return null;
    $s=$pdo->prepare('SELECT * FROM suppliers WHERE id=? LIMIT 1');$s->execute([$supplierId]);return $s->fetch(PDO::FETCH_ASSOC)?:null;
}
function tsSVOSuppliers(PDO $pdo):array{
    if(!tsSVOTable($pdo,'suppliers')) return [];
    try{
        $cols=['id','supplier_code','company_name'];
        foreach(['supplier_type','priority','status'] as $c) if(tsSVOColumn($pdo,'suppliers',$c)) $cols[]=$c;
        $sql='SELECT '.implode(',',$cols).' FROM suppliers';
        if(tsSVOColumn($pdo,'suppliers','status')) $sql.=" WHERE status='active'";
        $sql.=tsSVOColumn($pdo,'suppliers','priority')?" ORDER BY CASE priority WHEN 'preferred' THEN 1 WHEN 'regular' THEN 2 ELSE 3 END,company_name":" ORDER BY company_name";
        return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $e){return [];}
}
function tsSVODestinations(PDO $pdo):array{
    if(!tsSVOTable($pdo,'destinations')) return [];
    try{
        $hasStatus=tsSVOColumn($pdo,'destinations','status');$hasCountry=tsSVOColumn($pdo,'destinations','country');
        $sql='SELECT id,name,'.($hasCountry?'country':"'' country").($hasStatus?',status':'').' FROM destinations'.($hasStatus?" WHERE status='active'":'').' ORDER BY '.($hasCountry?'country,':'').'name';
        return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $e){return [];}
}
function tsSVOLocations(PDO $pdo):array{
    if(function_exists('tsLocationEnsureSchema')){try{tsLocationEnsureSchema($pdo);}catch(Throwable $ignored){}}
    if(!tsSVOTable($pdo,'destination_locations')) return [];
    try{
        $order=tsSVOColumn($pdo,'destination_locations','sort_order')?'destination_id,sort_order,location_name':'destination_id,location_name';
        $status=tsSVOColumn($pdo,'destination_locations','status')?" WHERE status='active'":'';
        return $pdo->query("SELECT id,destination_id,location_name FROM destination_locations{$status} ORDER BY {$order}")->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $e){return [];}
}
function tsSVOSave(PDO $pdo,array $in,int $adminId):int{
    if(!tsSVOReady($pdo)) throw new RuntimeException('Import the V22 Supplier Vehicle Options SQL first.');
    $supplierId=max(0,(int)($in['supplier_id']??0)); if(!tsSVOSupplier($pdo,$supplierId)) throw new RuntimeException('Choose a valid supplier.');
    $destinationId=max(0,(int)($in['destination_id']??0)); if($destinationId<=0) throw new RuntimeException('Choose a destination/state.');
    $locationId=max(0,(int)($in['location_id']??0)); $city=trim((string)($in['city']??''));
    if($locationId<=0&&$city!==''&&function_exists('tsLocationUpsert')) $locationId=tsLocationUpsert($pdo,$destinationId,$city,'supplier_vehicle_option',$adminId?:null);
    if($locationId>0&&tsSVOTable($pdo,'destination_locations')){
        $q=$pdo->prepare('SELECT location_name FROM destination_locations WHERE id=? AND destination_id=? LIMIT 1');$q->execute([$locationId,$destinationId]);$ln=trim((string)($q->fetchColumn()?:''));if($ln!=='')$city=$ln;
    }
    $supplierCategory=trim((string)($in['supplier_category']??'')); if($supplierCategory==='') $supplierCategory='All';
    $paxMin=max(0,(int)($in['pax_min']??0));$paxMax=max(0,(int)($in['pax_max']??0));
    if($paxMin>0&&$paxMax>0&&$paxMax<$paxMin) throw new RuntimeException('PAX Max cannot be smaller than PAX Min.');
    $vehicleType=trim((string)($in['vehicle_type']??''));if($vehicleType==='')throw new RuntimeException('Enter the vehicle type.');
    $norm=tsSVONormalize($vehicleType);
    $ac=(string)($in['ac_basis']??'unspecified');if(!in_array($ac,['ac','non_ac','unspecified'],true))$ac='unspecified';
    $scope=trim((string)($in['route_scope']??''));$notes=trim((string)($in['notes']??''));$status=(string)($in['status']??'active');if(!in_array($status,['active','inactive'],true))$status='active';
    $id=max(0,(int)($in['option_id']??0));
    if($id>0){
        $s=$pdo->prepare("UPDATE supplier_vehicle_options SET supplier_id=?,destination_id=?,location_id=?,city=?,supplier_category=?,pax_min=?,pax_max=?,vehicle_type=?,vehicle_type_normalized=?,ac_basis=?,route_scope=?,notes=?,status=?,updated_by_admin_id=?,updated_at=NOW() WHERE id=?");
        $s->execute([$supplierId,$destinationId,$locationId?:null,$city,$supplierCategory,$paxMin,$paxMax,$vehicleType,$norm,$ac,$scope?:null,$notes?:null,$status,$adminId?:null,$id]);
    }else{
        $s=$pdo->prepare("INSERT INTO supplier_vehicle_options(supplier_id,destination_id,location_id,city,supplier_category,pax_min,pax_max,vehicle_type,vehicle_type_normalized,ac_basis,route_scope,notes,status,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE location_id=VALUES(location_id),ac_basis=VALUES(ac_basis),route_scope=VALUES(route_scope),notes=VALUES(notes),status=VALUES(status),updated_by_admin_id=VALUES(updated_by_admin_id),updated_at=NOW()");
        $s->execute([$supplierId,$destinationId,$locationId?:null,$city,$supplierCategory,$paxMin,$paxMax,$vehicleType,$norm,$ac,$scope?:null,$notes?:null,$status,$adminId?:null,$adminId?:null]);$id=(int)$pdo->lastInsertId();
        if($id<=0){$q=$pdo->prepare("SELECT id FROM supplier_vehicle_options WHERE supplier_id=? AND destination_id=? AND LOWER(TRIM(city))=LOWER(TRIM(?)) AND LOWER(TRIM(supplier_category))=LOWER(TRIM(?)) AND pax_min=? AND pax_max=? AND vehicle_type_normalized=? LIMIT 1");$q->execute([$supplierId,$destinationId,$city,$supplierCategory,$paxMin,$paxMax,$norm]);$id=(int)($q->fetchColumn()?:0);}
    }
    if(tsSVOTable($pdo,'supplier_destinations')){try{$pdo->prepare('INSERT IGNORE INTO supplier_destinations(supplier_id,destination_id) VALUES(?,?)')->execute([$supplierId,$destinationId]);}catch(Throwable $ignored){}}
    return $id;
}
function tsSVODelete(PDO $pdo,int $id,int $supplierId=0):void{
    if(!tsSVOReady($pdo)||$id<=0)return;$sql='DELETE FROM supplier_vehicle_options WHERE id=?';$p=[$id];if($supplierId>0){$sql.=' AND supplier_id=?';$p[]=$supplierId;}$pdo->prepare($sql)->execute($p);
}
function tsSVOList(PDO $pdo,int $supplierId=0):array{
    if(!tsSVOReady($pdo))return [];
    $sql="SELECT o.*,s.company_name,s.supplier_code,d.name destination_name,d.country destination_country,dl.location_name FROM supplier_vehicle_options o JOIN suppliers s ON s.id=o.supplier_id LEFT JOIN destinations d ON d.id=o.destination_id LEFT JOIN destination_locations dl ON dl.id=o.location_id WHERE 1=1";$p=[];
    if($supplierId>0){$sql.=' AND o.supplier_id=?';$p[]=$supplierId;}
    $sql.=" ORDER BY s.company_name,d.name,COALESCE(dl.location_name,o.city),o.pax_min,o.pax_max,o.vehicle_type";
    $st=$pdo->prepare($sql);$st->execute($p);return $st->fetchAll(PDO::FETCH_ASSOC)?:[];
}
