<?php
/** TRAVSCOPE V25.02: expandable credential library; preserve V25.01 keys. */
declare(strict_types=1);

if (!defined('TS_CREDENTIAL_MAX_SLOTS')) define('TS_CREDENTIAL_MAX_SLOTS', 30);

if (!function_exists('tsCredSetting')) {
function tsCredSetting(PDO $pdo, string $key, string $default = ''): string {
    try {
        if (function_exists('getSetting')) return trim((string)getSetting($pdo, $key, $default));
        $s = $pdo->prepare('SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1');
        $s->execute([$key]);
        $v = $s->fetchColumn();
        return $v === false ? $default : trim((string)$v);
    } catch (Throwable $e) { return $default; }
}
function tsCredSafeLogo(string $logo): string {
    $logo = trim($logo);
    if ($logo === '' || preg_match('/[\x00-\x1f<>"\']/', $logo)) return '';
    if (preg_match('#^https://#i', $logo)) {
        $parts = parse_url($logo);
        if (!is_array($parts) || empty($parts['host']) || isset($parts['user'])) return '';
        return preg_match('/\.(?:png|jpe?g)(?:[?#]|$)/i', $logo) ? $logo : '';
    }
    $path = ltrim(str_replace('\\', '/', $logo), '/');
    if ($path === '' || str_contains($path, '..') || str_contains($path, '?') || str_contains($path, '#')) return '';
    if (!preg_match('#^(?:uploads/settings/branding/|assets/)[a-zA-Z0-9_./-]+\.(?:png|jpe?g)$#i', $path)) return '';
    return $path;
}
function tsCredentialItems(PDO $pdo): array {
    $items = [];
    // V25.02: one settings lookup for the shared footer/PDF renderer instead
    // of 90 queries when the library contains 30 configured slots.
    $all = null;
    try {
        $st = $pdo->query("SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE 'quotation_credential_%'");
        if ($st) {
            $all = [];
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $all[(string)$row['setting_key']] = (string)$row['setting_value'];
            }
        }
    } catch (Throwable $e) { $all = null; }
    $setting = static function (string $key, string $default = '') use ($all, $pdo): string {
        return is_array($all) ? trim((string)($all[$key] ?? $default)) : tsCredSetting($pdo, $key, $default);
    };
    for ($i=1; $i<=TS_CREDENTIAL_MAX_SLOTS; $i++) {
        // Explicit approval is necessary: uploading or typing a logo must never assert an affiliation.
        if ($setting('quotation_credential_verified_'.$i, '0') !== '1') continue;
        $label = $setting('quotation_credential_label_'.$i);
        $logo = tsCredSafeLogo($setting('quotation_credential_logo_'.$i));
        if ($label === '' || $logo === '') continue;
        $items[] = ['label' => (function_exists('mb_substr') ? mb_substr($label, 0, 120) : substr($label, 0, 120)), 'logo' => $logo, 'slot' => $i];
    }
    return $items;
}
function tsCredentialImageUrl(string $logo): string {
    if (preg_match('#^https://#i', $logo)) return $logo;
    return (defined('BASE_URL') ? rtrim((string)BASE_URL, '/') . '/' : '/') . ltrim($logo, '/');
}
function tsCredentialsHtml(PDO $pdo, string $where = 'document'): string {
    $items = tsCredentialItems($pdo);
    if (!$items) return '';
    $heading = tsCredSetting($pdo, 'quotation_credentials_heading', 'Registrations & Credentials');
    $html = '<link rel="stylesheet" href="assets/credentials-v2501.css?v=2502">';
    $html .= '<section class="ts-credentials ts-credentials--'.($where === 'website'?'website':'document').'" aria-label="'.htmlspecialchars($heading,ENT_QUOTES,'UTF-8').'">';
    $html .= '<div class="ts-credentials-heading">'.htmlspecialchars($heading,ENT_QUOTES,'UTF-8').'</div><div class="ts-credentials-items">';
    foreach ($items as $it) {
        $label = htmlspecialchars($it['label'], ENT_QUOTES, 'UTF-8');
        $url = htmlspecialchars(tsCredentialImageUrl($it['logo']), ENT_QUOTES, 'UTF-8');
        $html .= '<div class="ts-credentials-item"><img loading="lazy" src="'.$url.'" alt="'.$label.' logo"><span>'.$label.'</span></div>';
    }
    $html .= '</div><p class="ts-credentials-note">Registration or association marks are displayed as supplied by TRAVSCOPE. No government endorsement is implied.</p></section>';
    return $html;
}
}
