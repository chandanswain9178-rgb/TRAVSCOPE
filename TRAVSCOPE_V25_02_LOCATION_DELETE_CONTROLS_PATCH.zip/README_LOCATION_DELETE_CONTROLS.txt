# TRAVSCOPE V25.02 — Location Delete Controls

This release keeps version V25.02 and includes the approved admin directory improvements plus the earlier small credential-logo and public-file permission fixes.

## What changes

- Cities & Locations adds a Delete button beside each location status action and a Delete all locations button for the selected destination. Delete all includes active, inactive and filtered-out locations.
- Both actions require confirmation and protect linked hotel, supplier and itinerary records. Bulk deletion stops without deleting any locations if one is linked or the saved count has changed. Authentication, CSRF and parent membership remain enforced.
- Filter context is preserved after deletion. Synced cities can be added again by Sync Cities. No SQL migration is required.

- Destination creation adds Use Country and Use Continent alongside Use State / Region. Selecting a region fills the name immediately, and continent destinations save without a country. Canonical continent choices and existing saved custom values are preserved.
- Pending geography responses cannot replace a newer selection; saved country/continent destinations reopen correctly, including when the optional geo service is unavailable.
- A continent destination has no single country. Add its cities manually in Cities & Locations; Sync Cities retains the existing Unavailable result and manual-entry hint for destinations without a country. It does not substitute a country or create a continent-wide city feed.

- Destinations uses six clear columns with package totals, linked location counts, active/featured visibility, and compact Edit, Manage Cities and More actions.
- Country/continent/featured filters retain valid context. Missing destination images show deliberate placeholders, and records needing geography or media attention are identified for administrators.
- Cities & Locations shows counts for the selected destination, a compact Add Location form, and search/status/source filters. Administrators can view inactive locations and explicitly change their status.
- Location discovery and sync preserve saved inactive choices. Add and sync operations report their actual outcome. Destination deletion checks linked packages, locations and hotels.
- Credential logos retain the preceding screen and PDF size constraints. The patch also includes the preceding public CSS/JS permission corrections.

## Install on an existing website

1. Back up the 17 listed product files before replacing them. Keep a normal database and uploads backup.
2. Extract the PATCH ZIP on your computer. Copy its PHP files, site-brand-sync.js and assets files into the actual website document root: the folder containing the live index.php. Overwrite the matching files and retain the assets folder structure.
3. Set replacement files to 0644 and the assets directory to 0755 if your uploader changes permissions. Do not copy this release into a second nested project folder.
4. Refresh browser/cache assets, log out and sign in again if necessary. Open Destinations and Cities & Locations, test an ordinary add/edit/status change, and regenerate a quotation PDF to use the included logo rendering fixes.

No SQL import or migration is required by this patch. It contains no configuration file, SQL dump, uploads, private runtime, development login route or database credentials. Your existing configuration and data remain in place.

The FULL ZIP is the complete 219-entry source archive with two upgraded location files over the previous country/continent selection full release. It preserves the preceding country/continent destination code, original bundled project configuration and nested assets archive. For a fresh installation, unpack assets_2026-09-30_17:12:26.zip first, then copy the outer archive files last so the current PHP and public assets take precedence. Deploy into the document root containing index.php and use your hosting configuration. Installing only this code archive does not import a database.

## Patch files

- TRAVSCOPE_V25_02_LOCATION_DELETE_CONTROLS_FROM_ORIGINAL.patch is a text patch for the five changed PHP files relative to the original V25.02 archive.
- TRAVSCOPE_V25_02_LOCATION_DELETE_CONTROLS_FROM_COUNTRY_CONTINENT.patch is a text patch for the two changed PHP files relative to the preceding country/continent selection full archive.
- PRODUCT_MANIFEST.json records source hashes and the 17 replacement-file hashes and modes.

The replacement-file ZIP is the complete upgrade path from original V25.02: it also carries unchanged V3 CSS/JS files so their public read permissions can be corrected. A text patch changes code only; set public-file permissions separately if using that installation method.

## Product files in the PATCH ZIP

- admin-crm.php
- admin-destination-locations.php
- admin-destinations.php
- assets/credentials-v2501.css
- assets/crm-itinerary-studio-v2497.css
- assets/crm-itinerary-studio-v2497.js
- assets/crm-laptop-workspaces-v2498.css
- assets/crm-laptop-workspaces-v2498.js
- assets/travscope-experience-v2500.css
- assets/travscope-experience-v2500.js
- assets/travscope-responsive-admin-v2499.css
- assets/travscope-responsive-core-v2499.css
- assets/travscope-responsive-public-v2499.css
- assets/travscope-responsive-v2499.js
- credential-display.php
- location-master-functions.php
- site-brand-sync.js

## Validation scope

Release packaging checks verify ZIP CRCs, source hashes, 219 full-archive entries, safe targeted patch contents, exact text-patch application and PHP syntax. The two location source hashes match the reviewed snapshot and final deletion test report. The country/continent destination source retains its preceding release bytes.

The browser/HTTP verification uses an isolated synthetic development database. Real external city-service availability, email delivery and the production server are outside that fixture. Publishing these ZIPs does not deploy the live website.
