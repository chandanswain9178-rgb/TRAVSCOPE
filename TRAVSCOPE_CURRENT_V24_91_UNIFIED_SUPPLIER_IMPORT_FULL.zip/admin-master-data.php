<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/master-data-functions.php';

requireAdmin();

$admin =
    currentAdmin($pdo);

if (
    !$admin
    || strtolower(
        (string)(
            $admin['status']
            ?? ''
        )
    ) !== 'active'
) {
    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_role']
    );

    redirect(
        BASE_URL
        . 'admin-login.php'
    );
}

$adminId =
    (int)$admin['id'];

$canManage =
    function_exists('tsAclCan')
        ? tsAclCan(
            $pdo,
            $adminId,
            'manage_access'
        )
        : true;

if (!$canManage) {
    http_response_code(403);
    exit(
        'Master Data Consolidation requires Manage Permissions authority.'
    );
}

$type =
    (string)(
        $_GET['type']
        ?? $_POST['entity_type']
        ?? 'customer'
    );

if (
    !in_array(
        $type,
        ['customer','supplier'],
        true
    )
) {
    $type = 'customer';
}

$caseStatus =
    (string)(
        $_GET['case_status']
        ?? 'open'
    );

if (
    !in_array(
        $caseStatus,
        ['open','merged','rejected','all'],
        true
    )
) {
    $caseStatus = 'open';
}

if (empty($_SESSION['admin_master_data_csrf'])) {
    $_SESSION['admin_master_data_csrf'] =
        bin2hex(
            random_bytes(32)
        );
}

$csrf =
    (string)$_SESSION['admin_master_data_csrf'];

$error = '';
$success = '';

if (!empty($_SESSION['admin_master_data_success'])) {
    $success =
        (string)$_SESSION['admin_master_data_success'];

    unset(
        $_SESSION['admin_master_data_success']
    );
}

if (
    $_SERVER['REQUEST_METHOD']
    === 'POST'
) {
    $postedToken =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    if (
        $postedToken === ''
        || !hash_equals(
            $csrf,
            $postedToken
        )
    ) {
        $error =
            'Security verification failed. Refresh and try again.';

    } elseif (!tsMasterReady($pdo)) {
        $error =
            'Import TRAVSCOPE_Customer_Supplier_Master_Data_Consolidation.sql first.';

    } else {
        try {
            $action =
                (string)(
                    $_POST['action']
                    ?? ''
                );

            if (
                in_array(
                    $action,
                    [
                        'merge_customer',
                        'merge_supplier',
                    ],
                    true
                )
            ) {
                if (
                    strtoupper(
                        trim(
                            (string)(
                                $_POST['confirm_text']
                                ?? ''
                            )
                        )
                    ) !== 'MERGE'
                ) {
                    throw new RuntimeException(
                        'Type MERGE to confirm this master-data consolidation.'
                    );
                }

                $sourceId =
                    max(
                        0,
                        (int)(
                            $_POST['source_id']
                            ?? 0
                        )
                    );

                $canonicalId =
                    max(
                        0,
                        (int)(
                            $_POST['canonical_id']
                            ?? 0
                        )
                    );

                $score =
                    max(
                        0,
                        min(
                            100,
                            (int)(
                                $_POST['confidence_score']
                                ?? 50
                            )
                        )
                    );

                $reason =
                    trim(
                        (string)(
                            $_POST['match_reason']
                            ?? 'Manual Admin review'
                        )
                    );

                $note =
                    trim(
                        (string)(
                            $_POST['review_note']
                            ?? ''
                        )
                    );

                if ($note === '') {
                    throw new RuntimeException(
                        'Enter an Admin review note explaining why these records are the same master.'
                    );
                }

                if ($action === 'merge_customer') {
                    $result =
                        tsMasterMergeCustomer(
                            $pdo,
                            $sourceId,
                            $canonicalId,
                            $score,
                            $reason,
                            $note,
                            $adminId
                        );

                    $_SESSION['admin_master_data_success'] =
                        'Customer #'
                        . $sourceId
                        . ' consolidated into canonical Customer #'
                        . $canonicalId
                        . '. Source account was deactivated, not deleted.';

                    $type = 'customer';

                } else {
                    $result =
                        tsMasterMergeSupplier(
                            $pdo,
                            $sourceId,
                            $canonicalId,
                            $score,
                            $reason,
                            $note,
                            $adminId
                        );

                    $_SESSION['admin_master_data_success'] =
                        'Supplier #'
                        . $sourceId
                        . ' consolidated into canonical Supplier #'
                        . $canonicalId
                        . '. Historical commercial supplier references were preserved.';

                    $type = 'supplier';
                }

            } elseif ($action === 'reject_candidate') {
                $leftId =
                    max(
                        0,
                        (int)(
                            $_POST['left_id']
                            ?? 0
                        )
                    );

                $rightId =
                    max(
                        0,
                        (int)(
                            $_POST['right_id']
                            ?? 0
                        )
                    );

                $note =
                    trim(
                        (string)(
                            $_POST['review_note']
                            ?? ''
                        )
                    );

                tsMasterRejectCandidate(
                    $pdo,
                    $type,
                    $leftId,
                    $rightId,
                    max(
                        0,
                        min(
                            100,
                            (int)(
                                $_POST['confidence_score']
                                ?? 50
                            )
                        )
                    ),
                    (string)(
                        $_POST['match_reason']
                        ?? 'Admin review'
                    ),
                    $note,
                    $adminId
                );

                $_SESSION['admin_master_data_success'] =
                    'Candidate marked as separate master records and removed from future duplicate suggestions.';

            } elseif ($action === 'reject_case') {
                $caseId =
                    max(
                        0,
                        (int)(
                            $_POST['case_id']
                            ?? 0
                        )
                    );

                tsMasterRejectCase(
                    $pdo,
                    $caseId,
                    (string)(
                        $_POST['review_note']
                        ?? ''
                    ),
                    $adminId
                );

                $_SESSION['admin_master_data_success'] =
                    'Duplicate candidate rejected and preserved as separate masters.';

            } else {
                throw new RuntimeException(
                    'Invalid Master Data action.'
                );
            }

            redirect(
                BASE_URL
                . 'admin-master-data.php?type='
                . urlencode($type)
                . '&case_status='
                . urlencode($caseStatus)
            );

        } catch (RuntimeException $e) {
            $error =
                $e->getMessage();

        } catch (Throwable $e) {
            error_log(
                'Master Data Consolidation: '
                . $e->getMessage()
            );

            $error =
                'Unable to complete master-data action: '
                . $e->getMessage();
        }
    }
}

$candidates =
    $type === 'customer'
        ? tsMasterCustomerCandidates($pdo)
        : tsMasterSupplierCandidates($pdo);

$cases =
    tsMasterCases(
        $pdo,
        $type,
        $caseStatus === 'all'
            ? ''
            : $caseStatus
    );

$aliases =
    tsMasterAliasMap(
        $pdo,
        $type
    );

function mdE(?string $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function mdDate(?string $value): string
{
    if (!$value) {
        return '-';
    }

    $ts =
        strtotime($value);

    return
        $ts
            ? date(
                'd M Y',
                $ts
            )
            : (string)$value;
}

function mdCustomerLabel(array $row): string
{
    return
        trim(
            (string)(
                $row['full_name']
                ?? 'Customer'
            )
        )
        . ' · #'
        . (int)$row['id'];
}

function mdSupplierLabel(array $row): string
{
    return
        trim(
            (string)(
                $row['company_name']
                ?? 'Supplier'
            )
        )
        . ' · #'
        . (int)$row['id'];
}

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Master Data Consolidation | TRAVSCOPE Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:68px;padding:10px 4%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;border-bottom:1px solid #dfe7f0;position:sticky;top:0;z-index:20}.brand{font-weight:900;color:#0f172a}.brand span{color:#2563eb}.btn{display:inline-flex;align-items:center;gap:6px;border:1px solid #cbd5e1;border-radius:9px;padding:8px 10px;background:#fff;color:#334155;text-decoration:none;font-size:9px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.btn.good{background:#059669;border-color:#059669;color:#fff}.btn.danger{background:#fff1f2;border-color:#fecdd3;color:#be123c}.btn.warn{background:#fff7ed;border-color:#fed7aa;color:#c2410c}.wrap{max-width:1400px;margin:20px auto;padding:0 13px}.hero{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;padding:17px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:20px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px;line-height:1.55}.tabs{display:flex;gap:6px;flex-wrap:wrap}.tabs a{padding:7px 10px;border:1px solid #cbd5e1;border-radius:999px;background:#fff;color:#475569;text-decoration:none;font-size:8px;font-weight:900}.tabs a.active{background:#0f172a;border-color:#0f172a;color:#fff}.notice{margin-top:10px;padding:10px 12px;border-radius:10px;font-size:10px}.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#047857}.err{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c}.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:11px}.stat{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.stat span{display:block;color:#64748b;font-size:7.5px;font-weight:900;text-transform:uppercase}.stat strong{display:block;margin-top:4px;font-size:13px}.grid{display:grid;grid-template-columns:1.35fr .65fr;gap:11px;margin-top:11px}.card{background:#fff;border:1px solid #dfe7f0;border-radius:13px;overflow:hidden}.head{padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff;display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.head h2{margin:0;font-size:12px}.head p{margin:4px 0 0;color:#64748b;font-size:8.5px;line-height:1.45}.body{padding:11px}.candidate{padding:10px;border:1px solid #e2e8f0;border-radius:11px;margin-bottom:8px}.candidate:last-child{margin-bottom:0}.score{display:inline-flex;padding:4px 7px;border-radius:999px;background:#ede9fe;color:#6d28d9;font-size:7.5px;font-weight:900}.reasons{display:flex;gap:5px;flex-wrap:wrap;margin-top:6px}.reason{padding:3px 6px;border-radius:999px;background:#eff6ff;color:#1d4ed8;font-size:7.5px;font-weight:900}.pair{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}.entity{padding:9px;border:1px solid #e2e8f0;border-radius:9px;background:#f8fafc}.entity strong{display:block;font-size:10px}.entity small{display:block;margin-top:4px;color:#64748b;font-size:8px;line-height:1.5}.merge-form{margin-top:8px;padding:8px;border:1px dashed #cbd5e1;border-radius:9px;background:#fbfdff}.merge-grid{display:grid;grid-template-columns:1fr 120px;gap:6px}.merge-grid textarea,.merge-grid input,.manual input,.manual select,.manual textarea{width:100%;padding:7px 8px;border:1px solid #cbd5e1;border-radius:8px;font-size:8.5px}.merge-grid textarea{min-height:54px}.history{padding:9px;border:1px solid #e2e8f0;border-radius:9px;margin-bottom:7px}.history strong{font-size:9px}.history small{display:block;margin-top:3px;color:#64748b;font-size:8px;line-height:1.45}.pill{display:inline-flex;padding:4px 7px;border-radius:999px;background:#f1f5f9;color:#64748b;font-size:7.5px;font-weight:900}.pill.merged{background:#dcfce7;color:#166534}.pill.open{background:#fff7ed;color:#c2410c}.pill.rejected{background:#f1f5f9;color:#64748b}.manual{display:grid;grid-template-columns:1fr 1fr;gap:7px}.manual .full{grid-column:1/-1}.warning-box{padding:10px;border:1px solid #fed7aa;border-radius:10px;background:#fff7ed;color:#9a3412;font-size:8.5px;line-height:1.55}.empty{padding:22px;text-align:center;color:#94a3b8;border:1px dashed #cbd5e1;border-radius:10px;font-size:9px}
@media(max-width:1050px){.grid{grid-template-columns:1fr}.stats{grid-template-columns:1fr 1fr}}
@media(max-width:650px){.top,.hero{flex-direction:column;align-items:flex-start}.pair,.manual,.merge-grid,.stats{grid-template-columns:1fr}.manual .full{grid-column:auto}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head>
<body>

<header class="top">
    <div class="brand">
        TRAV<span>SCOPE</span> · MASTER DATA
    </div>

    <div style="display:flex;gap:7px;flex-wrap:wrap;">
        <a class="btn" href="<?= mdE(BASE_URL . 'admin-dashboard.php'); ?>">
            <i class="fa-solid fa-gauge-high"></i>
            Dashboard
        </a>

        <a class="btn" href="<?= mdE(BASE_URL . 'admin-system-health.php'); ?>">
            <i class="fa-solid fa-heart-pulse"></i>
            System Health
        </a>
    </div>
</header>

<main class="wrap">

<section class="hero">
    <div>
        <h1>Customer + Supplier Master Data Consolidation</h1>
        <p>
            Detect likely duplicate masters, choose the exact canonical record, preserve
            Booking/Trip/payment/document/commercial history, deactivate the duplicate,
            and keep a permanent alias + merge audit. Detection never merges automatically.
        </p>
    </div>

    <div class="tabs">
        <a
            class="<?= $type === 'customer' ? 'active' : ''; ?>"
            href="<?= mdE(BASE_URL . 'admin-master-data.php?type=customer'); ?>"
        >
            Customers
        </a>

        <a
            class="<?= $type === 'supplier' ? 'active' : ''; ?>"
            href="<?= mdE(BASE_URL . 'admin-master-data.php?type=supplier'); ?>"
        >
            Suppliers
        </a>
    </div>
</section>

<?php if ($success): ?>
    <div class="notice ok"><?= mdE($success); ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="notice err"><?= mdE($error); ?></div>
<?php endif; ?>

<div class="stats">
    <div class="stat">
        <span>Detected Candidates</span>
        <strong><?= count($candidates); ?></strong>
    </div>

    <div class="stat">
        <span>Canonical Aliases</span>
        <strong><?= count($aliases); ?></strong>
    </div>

    <div class="stat">
        <span>Case History</span>
        <strong><?= count($cases); ?></strong>
    </div>

    <div class="stat">
        <span>Merge Mode</span>
        <strong>MANUAL</strong>
    </div>
</div>

<div class="grid">

<section class="card">
    <div class="head">
        <div>
            <h2><?= $type === 'customer' ? 'Customer' : 'Supplier'; ?> Duplicate Candidates</h2>
            <p>
                High score means stronger matching evidence. Always compare both records
                before choosing which one becomes canonical.
            </p>
        </div>
    </div>

    <div class="body">
        <?php if (!tsMasterReady($pdo)): ?>
            <div class="warning-box">
                Import <strong>TRAVSCOPE_Customer_Supplier_Master_Data_Consolidation.sql</strong>
                before performing a merge. Candidate detection remains visible for review.
            </div>
        <?php endif; ?>

        <?php if (!$candidates): ?>
            <div class="empty">
                No likely duplicate <?= mdE($type); ?> pairs detected.
            </div>
        <?php endif; ?>

        <?php foreach ($candidates as $candidate): ?>
            <?php
            $left =
                (array)$candidate['left'];

            $right =
                (array)$candidate['right'];

            $reasonText =
                implode(
                    ' + ',
                    (array)$candidate['reasons']
                );
            ?>

            <div class="candidate">
                <span class="score">
                    MATCH <?= (int)$candidate['score']; ?>%
                </span>

                <div class="reasons">
                    <?php foreach ((array)$candidate['reasons'] as $reason): ?>
                        <span class="reason"><?= mdE((string)$reason); ?></span>
                    <?php endforeach; ?>
                </div>

                <div class="pair">
                    <div class="entity">
                        <?php if ($type === 'customer'): ?>
                            <strong><?= mdE(mdCustomerLabel($left)); ?></strong>
                            <small>
                                <?= mdE((string)($left['email'] ?? '-')); ?>
                                · <?= mdE((string)($left['mobile'] ?? '-')); ?><br>
                                <?= mdE((string)($left['country'] ?? '-')); ?>
                                · <?= mdE(strtoupper((string)($left['status'] ?? '-'))); ?>
                                · Created <?= mdE(mdDate($left['created_at'] ?? null)); ?>
                            </small>
                        <?php else: ?>
                            <strong><?= mdE(mdSupplierLabel($left)); ?></strong>
                            <small>
                                <?= mdE((string)($left['supplier_code'] ?? '-')); ?>
                                · GST <?= mdE((string)($left['gstin'] ?? '-')); ?><br>
                                <?= mdE((string)($left['city'] ?? '-')); ?>,
                                <?= mdE((string)($left['country'] ?? '-')); ?>
                                · <?= mdE((string)($left['primary_email'] ?? '-')); ?>
                                · <?= mdE(strtoupper((string)($left['status'] ?? '-'))); ?>
                            </small>
                        <?php endif; ?>
                    </div>

                    <div class="entity">
                        <?php if ($type === 'customer'): ?>
                            <strong><?= mdE(mdCustomerLabel($right)); ?></strong>
                            <small>
                                <?= mdE((string)($right['email'] ?? '-')); ?>
                                · <?= mdE((string)($right['mobile'] ?? '-')); ?><br>
                                <?= mdE((string)($right['country'] ?? '-')); ?>
                                · <?= mdE(strtoupper((string)($right['status'] ?? '-'))); ?>
                                · Created <?= mdE(mdDate($right['created_at'] ?? null)); ?>
                            </small>
                        <?php else: ?>
                            <strong><?= mdE(mdSupplierLabel($right)); ?></strong>
                            <small>
                                <?= mdE((string)($right['supplier_code'] ?? '-')); ?>
                                · GST <?= mdE((string)($right['gstin'] ?? '-')); ?><br>
                                <?= mdE((string)($right['city'] ?? '-')); ?>,
                                <?= mdE((string)($right['country'] ?? '-')); ?>
                                · <?= mdE((string)($right['primary_email'] ?? '-')); ?>
                                · <?= mdE(strtoupper((string)($right['status'] ?? '-'))); ?>
                            </small>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="merge-form">
                    <form method="post">
                        <input type="hidden" name="csrf_token" value="<?= mdE($csrf); ?>">
                        <input type="hidden" name="entity_type" value="<?= mdE($type); ?>">
                        <input type="hidden" name="action" value="<?= $type === 'customer' ? 'merge_customer' : 'merge_supplier'; ?>">
                        <input type="hidden" name="confidence_score" value="<?= (int)$candidate['score']; ?>">
                        <input type="hidden" name="match_reason" value="<?= mdE($reasonText); ?>">

                        <div class="manual">
                            <div>
                                <label style="font-size:8px;font-weight:900;">Canonical Master</label>
                                <select name="canonical_id" class="canonical-select" required>
                                    <option value="<?= (int)$left['id']; ?>">
                                        LEFT · #<?= (int)$left['id']; ?>
                                    </option>
                                    <option value="<?= (int)$right['id']; ?>">
                                        RIGHT · #<?= (int)$right['id']; ?>
                                    </option>
                                </select>
                            </div>

                            <div>
                                <label style="font-size:8px;font-weight:900;">Duplicate Source</label>
                                <select name="source_id" class="source-select" required>
                                    <option value="<?= (int)$right['id']; ?>">
                                        RIGHT · #<?= (int)$right['id']; ?>
                                    </option>
                                    <option value="<?= (int)$left['id']; ?>">
                                        LEFT · #<?= (int)$left['id']; ?>
                                    </option>
                                </select>
                            </div>

                            <div class="full">
                                <label style="font-size:8px;font-weight:900;">Admin Review Note *</label>
                                <textarea
                                    name="review_note"
                                    required
                                    placeholder="Why are these the same master? Which record was chosen as canonical and why?"
                                ></textarea>
                            </div>

                            <div>
                                <label style="font-size:8px;font-weight:900;">Type MERGE *</label>
                                <input
                                    name="confirm_text"
                                    autocomplete="off"
                                    required
                                    placeholder="MERGE"
                                >
                            </div>

                            <div style="display:flex;align-items:end;">
                                <button
                                    class="btn danger"
                                    type="submit"

                                    <?= !tsMasterReady($pdo) ? 'disabled' : ''; ?>
                                >
                                    Merge Selected Direction
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

                <form method="post" style="margin-top:7px;">
                    <input type="hidden" name="csrf_token" value="<?= mdE($csrf); ?>">
                    <input type="hidden" name="entity_type" value="<?= mdE($type); ?>">
                    <input type="hidden" name="action" value="reject_candidate">
                    <input type="hidden" name="left_id" value="<?= (int)$left['id']; ?>">
                    <input type="hidden" name="right_id" value="<?= (int)$right['id']; ?>">
                    <input type="hidden" name="confidence_score" value="<?= (int)$candidate['score']; ?>">
                    <input type="hidden" name="match_reason" value="<?= mdE($reasonText); ?>">

                    <div style="display:flex;gap:6px;flex-wrap:wrap;">
                        <input
                            style="flex:1;min-width:220px;padding:7px 8px;border:1px solid #cbd5e1;border-radius:8px;font-size:8.5px;"
                            name="review_note"
                            required
                            placeholder="Why are these separate masters?"
                        >

                        <button
                            class="btn"
                            type="submit"
                            <?= !tsMasterReady($pdo) ? 'disabled' : ''; ?>
                        >
                            Not Duplicate
                        </button>
                    </div>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</section>


<aside>
<section class="card">
    <div class="head">
        <div>
            <h2>Manual Merge by ID</h2>
            <p>Use only after manually verifying two records that were not detected automatically.</p>
        </div>
    </div>

    <div class="body">
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= mdE($csrf); ?>">
            <input type="hidden" name="entity_type" value="<?= mdE($type); ?>">
            <input type="hidden" name="action" value="<?= $type === 'customer' ? 'merge_customer' : 'merge_supplier'; ?>">
            <input type="hidden" name="confidence_score" value="50">
            <input type="hidden" name="match_reason" value="Manual Admin duplicate review">

            <div class="manual">
                <div>
                    <label style="font-size:8px;font-weight:900;">Canonical ID</label>
                    <input type="number" min="1" name="canonical_id" required>
                </div>

                <div>
                    <label style="font-size:8px;font-weight:900;">Duplicate Source ID</label>
                    <input type="number" min="1" name="source_id" required>
                </div>

                <div class="full">
                    <label style="font-size:8px;font-weight:900;">Review Note *</label>
                    <textarea name="review_note" required></textarea>
                </div>

                <div>
                    <label style="font-size:8px;font-weight:900;">Type MERGE *</label>
                    <input name="confirm_text" required>
                </div>

                <div style="display:flex;align-items:end;">
                    <button
                        class="btn danger"
                        type="submit"
                        <?= !tsMasterReady($pdo) ? 'disabled' : ''; ?>
                    >
                        Merge
                    </button>
                </div>
            </div>
        </form>

        <div class="warning-box" style="margin-top:9px;">
            <strong>Safety rule:</strong>
            canonical master must already be Active. Login email/password are never overwritten
            automatically. Supplier RFQs, cost sheets, procurement orders, invoices, payments
            and frozen Booking supplier snapshots keep their original historical Supplier ID.
        </div>
    </div>
</section>


<section class="card" style="margin-top:11px;">
    <div class="head">
        <div>
            <h2>Merge Case History</h2>
            <p>Permanent review trail for <?= mdE($type); ?> consolidation.</p>
        </div>
    </div>

    <div class="body">
        <div class="tabs" style="margin-bottom:8px;">
            <?php foreach ([
                'open' => 'Open',
                'merged' => 'Merged',
                'rejected' => 'Rejected',
                'all' => 'All'
            ] as $key => $label): ?>
                <a
                    class="<?= $caseStatus === $key ? 'active' : ''; ?>"
                    href="<?= mdE(
                        BASE_URL
                        . 'admin-master-data.php?type='
                        . urlencode($type)
                        . '&case_status='
                        . urlencode($key)
                    ); ?>"
                >
                    <?= mdE($label); ?>
                </a>
            <?php endforeach; ?>
        </div>

        <?php if (!$cases): ?>
            <div class="empty">No merge cases in this view.</div>
        <?php endif; ?>

        <?php foreach ($cases as $case): ?>
            <div class="history">
                <div style="display:flex;justify-content:space-between;gap:7px;">
                    <strong>
                        Case #<?= (int)$case['id']; ?>
                        · Source #<?= (int)$case['source_id']; ?>
                        → Canonical #<?= (int)$case['canonical_id']; ?>
                    </strong>

                    <span class="pill <?= mdE((string)$case['status']); ?>">
                        <?= mdE(strtoupper((string)$case['status'])); ?>
                    </span>
                </div>

                <small>
                    Confidence <?= (int)$case['confidence_score']; ?>%
                    · <?= mdE((string)($case['match_reason'] ?? 'Manual review')); ?>
                    <br>
                    <?= mdE((string)($case['review_note'] ?? '')); ?>
                    <br>
                    Updated <?= mdE(mdDate((string)$case['updated_at'])); ?>
                </small>

                <?php if ((string)$case['status'] === 'open'): ?>
                    <form method="post" style="margin-top:7px;">
                        <input type="hidden" name="csrf_token" value="<?= mdE($csrf); ?>">
                        <input type="hidden" name="entity_type" value="<?= mdE($type); ?>">
                        <input type="hidden" name="action" value="reject_case">
                        <input type="hidden" name="case_id" value="<?= (int)$case['id']; ?>">

                        <input
                            style="width:100%;padding:7px;border:1px solid #cbd5e1;border-radius:8px;font-size:8px;"
                            name="review_note"
                            placeholder="Reason these are separate masters"
                            required
                        >

                        <button class="btn" type="submit" style="margin-top:5px;">
                            Reject Duplicate Match
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</section>
</aside>

</div>
</main>
<script>
document.querySelectorAll('.merge-form form').forEach(function(form){
    const canonical = form.querySelector('.canonical-select');
    const source = form.querySelector('.source-select');

    if (!canonical || !source) return;

    canonical.addEventListener('change', function(){
        Array.from(source.options).some(function(option){
            if (option.value !== canonical.value) {
                source.value = option.value;
                return true;
            }
            return false;
        });
    });

    source.addEventListener('change', function(){
        if (source.value === canonical.value) {
            Array.from(canonical.options).some(function(option){
                if (option.value !== source.value) {
                    canonical.value = option.value;
                    return true;
                }
                return false;
            });
        }
    });
});
</script>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
