<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/billing-functions.php';

$id = max(0, (int)($_GET['invoice'] ?? 0));
if ($id <= 0 || !tsBillReady($pdo)) {
    http_response_code(404);
    exit('Invoice not found.');
}

$st = $pdo->prepare("SELECT i.*,b.user_id,b.booking_number,b.customer_name,b.customer_email,b.customer_mobile,b.travel_date FROM booking_invoice_versions i JOIN bookings b ON b.id=i.booking_id WHERE i.id=? LIMIT 1");
$st->execute([$id]);
$i = $st->fetch(PDO::FETCH_ASSOC);
if (!$i) {
    http_response_code(404);
    exit('Invoice not found.');
}

$isAdmin = !empty($_SESSION['admin_id']);
$expires = (int)($_GET['expires'] ?? 0);
$token = trim((string)($_GET['token'] ?? ''));
$signed = function_exists('tsBillInvoiceEmailTokenValid') && tsBillInvoiceEmailTokenValid($id, $expires, $token);
if (!$isAdmin && !$signed) {
    requireLogin();
    $u = currentUser($pdo);
    if (!$u || (int)$i['user_id'] !== (int)$u['id'] || (string)$i['status'] !== 'final') {
        http_response_code(403);
        exit('You do not have permission to view this invoice.');
    }
}

$s = json_decode((string)$i['snapshot_json'], true);
if (!is_array($s)) $s = [];
function ivE($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function ivD($v): string { $x = $v ? strtotime((string)$v) : 0; return $x ? date('d M Y', $x) : '-'; }

$company = is_array($s['company'] ?? null) ? $s['company'] : tsBillTaxDefaults($pdo);
if (function_exists('tsBillInvoiceLogoUrl')) $company['logo_url'] = tsBillInvoiceLogoUrl($pdo);
$companyHeader = trim((string)($company['header_name'] ?? 'Memorable Hospitality Pvt. Ltd.')) ?: 'Memorable Hospitality Pvt. Ltd.';
$ct = is_array($s['customer_tax'] ?? null) ? $s['customer_tax'] : [];
$tax = is_array($s['tax'] ?? null) ? $s['tax'] : [];
$b = is_array($s['booking'] ?? null) ? $s['booking'] : [];
$pkg = is_array($s['package'] ?? null) ? $s['package'] : [];
$services = is_array($s['services'] ?? null) ? $s['services'] : [];
$si = is_array($s['service_invoice'] ?? null) ? $s['service_invoice'] : [];
$isTax = ($s['document'] ?? '') === 'tax_invoice';
$currency = (string)$i['currency'];
$grand = $isTax ? (float)($tax['grand_total'] ?? $i['booking_total']) : (float)$i['booking_total'];
$balanceDue = max(0, (float)($i['balance_due_at_issue'] ?? 0));
$upi = trim((string)($company['upi'] ?? ''));
$upiName = trim((string)($company['upi_name'] ?? $company['trade_name'] ?? 'Travscope')) ?: 'Travscope';
$upiUri = '';
if ($upi !== '' && $balanceDue > 0.009 && strtoupper($currency) === 'INR') {
    $upiUri = 'upi://pay?' . http_build_query([
        'pa' => $upi,
        'pn' => $upiName,
        'am' => number_format($balanceDue, 2, '.', ''),
        'cu' => 'INR',
        'tn' => (string)$i['invoice_code'],
    ], '', '&', PHP_QUERY_RFC3986);
}
$serviceDescription = trim((string)($si['description'] ?? $pkg['title'] ?? 'Tour / Travel Services')) ?: 'Tour / Travel Services';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=ivE($i['invoice_code'])?> · Tax Invoice</title>
<style>
*{box-sizing:border-box}html{-webkit-print-color-adjust:exact;print-color-adjust:exact}body{margin:0;background:#e9eef5;color:#111827;font-family:Arial,sans-serif}.tools{width:210mm;max-width:calc(100% - 24px);margin:14px auto 0;text-align:right}.tools button{border:0;border-radius:8px;padding:10px 14px;background:#111827;color:#fff;font-weight:800;cursor:pointer}.sheet{width:210mm;min-height:297mm;max-width:calc(100% - 24px);margin:10px auto 30px;background:#fff;box-shadow:0 16px 45px rgba(15,23,42,.1);border-radius:12px;overflow:hidden}.page-head{background:#fff}.brandbar{height:4px;background:linear-gradient(90deg,#0f172a,#2563eb,#06b6d4)}.head{padding:13px 15mm 11px;display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:16px;border-bottom:1px solid #dbe3ee}.brandidentity{display:grid;grid-template-columns:3in minmax(140px,1fr);align-items:center;gap:14px;min-width:0}.brandlogo{width:3in;max-width:3in;max-height:1.05in;height:auto;object-fit:contain;object-position:left center;display:block}.legalname{font-size:14px;font-weight:900;line-height:1.2;color:#0f172a}.muted{color:#64748b}.doc{text-align:right;min-width:125px}.doc h1{margin:0;font-size:21px;letter-spacing:.8px}.badge{display:inline-block;margin-top:5px;padding:4px 8px;border-radius:999px;background:#e0f2fe;color:#075985;font-size:8px;font-weight:900}.body{padding:10px 15mm 18mm}.party{display:grid;grid-template-columns:1fr 1fr;gap:10px}.box{border:1px solid #dbe3ee;border-radius:9px;padding:10px;background:#fff}.box h3{margin:0 0 7px;font-size:9px;text-transform:uppercase;color:#64748b;letter-spacing:.6px}.box strong{font-size:11px}.small{font-size:9px;line-height:1.5}.meta{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-top:10px}.meta div{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:8px}.meta span{font-size:7.5px;color:#64748b;text-transform:uppercase;font-weight:800}.meta strong{display:block;font-size:9px;margin-top:3px}.table{width:100%;border-collapse:collapse;margin-top:13px;font-size:9px}.table th{background:#0f172a;color:#fff;padding:8px;text-align:left}.table td{padding:9px 8px;border-bottom:1px solid #e5e7eb;vertical-align:top;line-height:1.45}.num{text-align:right}.totals{margin:12px 0 0 auto;max-width:330px}.tr{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #e5e7eb;font-size:10px}.tr.grand{font-size:13px;font-weight:900;border-top:2px solid #0f172a;border-bottom:0;margin-top:3px;padding-top:9px}.words,.terms{margin-top:11px;background:#f8fafc;border:1px solid #eef2f7;border-radius:8px;padding:9px;font-size:9px;line-height:1.55;white-space:normal}.pay{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:11px}.payment-layout{display:grid;grid-template-columns:minmax(0,1fr) 126px;gap:10px;align-items:start}.qrbox{border:1px solid #cbd5e1;border-radius:9px;padding:8px;text-align:center;background:#fff}.qrbox .qrtitle{font-size:7.5px;text-transform:uppercase;font-weight:900;color:#64748b;margin-bottom:6px}.qrbox #upiQr{width:108px;height:108px;margin:0 auto;display:flex;align-items:center;justify-content:center}.qrbox #upiQr img,.qrbox #upiQr canvas{width:108px!important;height:108px!important;display:block}.qrbox .qramount{font-size:10px;font-weight:900;color:#0f172a;margin-top:6px}.qrbox .qrupi{font-size:7px;color:#64748b;margin-top:3px;word-break:break-all}.sign{text-align:right;margin-top:26px;font-size:9px}.foot{text-align:center;border-top:1px solid #e5e7eb;padding:8px;color:#64748b;font-size:8px}.no-break,.party,.meta,.flightbox,.totals,.pay,.sign{break-inside:avoid;page-break-inside:avoid}.table tr{break-inside:avoid;page-break-inside:avoid}
@media(max-width:760px){.sheet,.tools{width:auto;max-width:calc(100% - 16px)}.party,.pay,.payment-layout{grid-template-columns:1fr}.meta{grid-template-columns:1fr 1fr}.head{grid-template-columns:1fr;padding:14px}.brandidentity{grid-template-columns:1fr}.brandlogo{width:min(3in,100%);max-width:100%}.doc{text-align:left}.body{padding:10px 14px 22px}}
@page{size:A4 portrait;margin:48mm 12mm 15mm 12mm}
@media print{body{background:#fff}.tools{display:none}.sheet{width:auto;max-width:none;min-height:0;margin:0;border-radius:0;box-shadow:none;overflow:visible}.page-head{position:fixed;top:-43mm;left:0;right:0;height:39mm;background:#fff;z-index:999}.head{padding:4mm 2mm 3mm}.brandlogo{max-height:25mm}.body{padding:0}.foot{position:fixed;left:0;right:0;bottom:-10mm;background:#fff;padding:2mm 0}.brandbar{height:1.2mm}.qrbox{break-inside:avoid}.terms{break-inside:auto}.table thead{display:table-header-group}}
</style>
</head>
<body>
<div class="tools"><button onclick="window.print()">Print / Save A4 PDF</button></div>
<main class="sheet">
  <div class="page-head">
    <div class="brandbar"></div>
    <header class="head">
      <div class="brandidentity">
        <?php if(!empty($company['logo_url'])):?><img class="brandlogo" src="<?=ivE($company['logo_url'])?>" alt="Travscope document logo"><?php endif;?>
        <div>
          <div class="legalname"><?=ivE($companyHeader)?></div>
          <div class="small" style="margin-top:3px;font-weight:800">Trade Name: <?=ivE($company['trade_name']??'Travscope')?></div>
          <div class="small muted" style="margin-top:3px"><?=ivE($company['legal_name']??'MEMORABLE HOSPITALITY PRIVATE LIMITED')?></div>
          <div class="small muted" style="margin-top:4px"><?php if(!empty($company['gstin'])):?>GSTIN: <strong><?=ivE($company['gstin'])?></strong><?php endif;?><?php if(!empty($company['pan'])):?> · PAN: <strong><?=ivE($company['pan'])?></strong><?php endif;?></div>
        </div>
      </div>
      <div class="doc">
        <h1><?=$isTax?'TAX INVOICE':'BOOKING INVOICE'?></h1>
        <div class="badge"><?=ivE(strtoupper((string)$i['status']))?></div>
        <div class="small" style="margin-top:6px"><strong><?=ivE($i['invoice_code'])?></strong><br>Date: <?=ivE(ivD($s['invoice_date']??$i['created_at']))?><br>Version: <?=(int)$i['version_number']?></div>
      </div>
    </header>
  </div>

  <div class="body">
    <div class="small muted" style="margin-bottom:9px"><?=nl2br(ivE($company['address']??''))?><?php if(!empty($company['email'])):?> · <?=ivE($company['email'])?><?php endif;?><?php if(!empty($company['phone'])):?> · <?=ivE($company['phone'])?><?php endif;?></div>

    <div class="party">
      <div class="box"><h3>Bill To</h3><strong><?=ivE($ct['name']??$b['customer_name']??$i['customer_name'])?></strong><div class="small muted"><?php if(!empty($ct['address'])):?><?=nl2br(ivE($ct['address']))?><br><?php endif;?><?=ivE($ct['email']??$b['customer_email']??$i['customer_email'])?><?php if(!empty($ct['mobile'])||!empty($b['customer_mobile'])):?><br><?=ivE($ct['mobile']??$b['customer_mobile'])?><?php endif;?><?php if(!empty($ct['gstin'])):?><br>GSTIN: <strong><?=ivE($ct['gstin'])?></strong><?php endif;?><?php if(!empty($ct['pan'])):?><br>PAN: <strong><?=ivE($ct['pan'])?></strong><?php endif;?></div></div>
      <div class="box"><h3>Supply Details</h3><div class="small">Place of Supply: <strong><?=ivE($ct['place_of_supply']??'-')?></strong><?php if(!empty($ct['place_of_supply_code'])):?> (<?=ivE($ct['place_of_supply_code'])?>)<?php endif;?><br>Supplier State: <strong><?=ivE($company['state']??'-')?></strong><?php if(!empty($company['state_code'])):?> (<?=ivE($company['state_code'])?>)<?php endif;?><br>Reverse Charge: <strong>No</strong></div></div>
    </div>

    <div class="meta">
      <div><span>Booking</span><strong><?=ivE($b['booking_number']??$i['booking_number'])?></strong></div>
      <div><span>Package / Service</span><strong><?=ivE($serviceDescription)?></strong></div>
      <div><span>Service Type</span><strong><?=ivE($si['label']??'Tour / Travel Services')?></strong></div>
      <div><span>Travel / Service Date</span><strong><?=ivE(ivD($si['service_date']??$b['travel_date']??$i['travel_date']))?></strong></div>
      <div><span>Travellers / PAX</span><strong><?=ivE((string)($si['pax']??max(0,(int)($b['adults']??0)+(int)($b['children']??0))))?></strong></div>
      <div><span>SAC</span><strong><?=ivE($tax['sac']??'998555')?></strong></div>
    </div>

    <?php if(($si['type']??'')==='flight_commission'):?>
      <div class="box flightbox" style="margin-top:10px"><h3>Flight Details</h3><div class="small"><strong>Flight:</strong> <?=ivE($si['flight_number']??'-')?> · <strong>Date:</strong> <?=ivE(ivD($si['flight_date']??''))?> · <strong>PAX:</strong> <?=ivE((string)($si['flight_pax']??$si['pax']??'-'))?><?php if(!empty($si['flight_route'])):?> · <strong>Route:</strong> <?=ivE($si['flight_route'])?><?php endif;?><?php if(!empty($si['flight_pnr'])):?> · <strong>PNR/Ref:</strong> <?=ivE($si['flight_pnr'])?><?php endif;?></div></div>
    <?php endif;?>

    <table class="table">
      <thead><tr><th style="width:36px">#</th><th>Description</th><th style="width:70px">SAC</th><th class="num" style="width:125px">Taxable Value</th></tr></thead>
      <tbody><tr><td>1</td><td><strong><?=nl2br(ivE($serviceDescription))?></strong><?php if(!empty($si['reference'])):?><div class="muted" style="margin-top:4px">Reference: <?=ivE($si['reference'])?></div><?php elseif($services):?><div class="muted" style="margin-top:4px"><?php $names=[];foreach($services as $sv)$names[]=trim((string)($sv['title']??''));echo ivE(implode(' · ',array_filter($names)));?></div><?php endif;?></td><td><?=ivE($tax['sac']??'998555')?></td><td class="num"><?=$currency?> <?=number_format((float)($tax['taxable_value']??$i['booking_total']),2)?></td></tr></tbody>
    </table>

    <div class="totals">
      <?php if($isTax):?>
        <div class="tr"><span>Taxable Value</span><strong><?=$currency?> <?=number_format((float)$tax['taxable_value'],2)?></strong></div>
        <?php if((float)($tax['cgst']??0)>0):?><div class="tr"><span>CGST <?=number_format((float)$tax['gst_rate']/2,2)?>%</span><strong><?=$currency?> <?=number_format((float)$tax['cgst'],2)?></strong></div><div class="tr"><span>SGST <?=number_format((float)$tax['gst_rate']/2,2)?>%</span><strong><?=$currency?> <?=number_format((float)$tax['sgst'],2)?></strong></div><?php endif;?>
        <?php if((float)($tax['igst']??0)>0):?><div class="tr"><span>IGST <?=number_format((float)$tax['gst_rate'],2)?>%</span><strong><?=$currency?> <?=number_format((float)$tax['igst'],2)?></strong></div><?php endif;?>
        <?php if((float)($tax['tcs_amount']??0)>0):?><div class="tr"><span>TCS <?=number_format((float)$tax['tcs_rate'],2)?>%</span><strong><?=$currency?> <?=number_format((float)$tax['tcs_amount'],2)?></strong></div><?php endif;?>
        <div class="tr grand"><span>Invoice Total</span><strong><?=$currency?> <?=number_format($grand,2)?></strong></div>
      <?php else:?><div class="tr grand"><span>Booking Total</span><strong><?=$currency?> <?=number_format($grand,2)?></strong></div><?php endif;?>
      <div class="tr"><span>Paid at Issue</span><strong><?=$currency?> <?=number_format((float)$i['paid_amount_at_issue'],2)?></strong></div>
      <div class="tr"><span>Balance Due</span><strong><?=$currency?> <?=number_format($balanceDue,2)?></strong></div>
    </div>

    <?php if($isTax&&!empty($tax['rule_note'])):?><div class="terms"><strong>Tax treatment:</strong> <?=ivE($tax['rule_note'])?></div><?php endif;?>
    <?php if($isTax):?><div class="words"><strong>Amount in words:</strong> <?=ivE($tax['amount_words']??tsBillMoneyWords($grand))?></div><?php endif;?>

    <div class="pay">
      <div class="box">
        <h3>Payment Details</h3>
        <div class="payment-layout">
          <div class="small"><?php if(!empty($company['bank_name'])):?>Bank: <strong><?=ivE($company['bank_name'])?></strong><br><?php endif;?><?php if(!empty($company['bank_account'])):?>A/C: <strong><?=ivE($company['bank_account'])?></strong><br><?php endif;?><?php if(!empty($company['bank_ifsc'])):?>IFSC: <strong><?=ivE($company['bank_ifsc'])?></strong><br><?php endif;?><?php if(!empty($company['upi'])):?>UPI: <strong><?=ivE($company['upi'])?></strong><?php endif;?></div>
          <?php if($upiUri!==''):?><div class="qrbox"><div class="qrtitle">Scan to pay balance</div><div id="upiQr" data-upi="<?=ivE($upiUri)?>"></div><div class="qramount">INR <?=number_format($balanceDue,2)?></div><div class="qrupi"><?=ivE($upi)?></div></div><?php endif;?>
        </div>
      </div>
      <div class="box"><h3>Declaration</h3><div class="small">We declare that this invoice shows the actual customer billing recorded in TRAVSCOPE. Tax treatment shown is frozen with this invoice version.</div></div>
    </div>

    <?php if(!empty($tax['note'])):?><div class="terms"><strong>Additional Description / Note:</strong><br><?=nl2br(ivE($tax['note']))?></div><?php endif;?>
    <div class="sign">For <strong><?=ivE($company['legal_name']??'MEMORABLE HOSPITALITY PRIVATE LIMITED')?></strong><br><br><br>Authorised Signatory</div>
  </div>
  <div class="foot">Computer-generated invoice · <?=ivE($i['invoice_code'])?> · Continuation pages repeat the official invoice header</div>
</main>
<?php if($upiUri!==''):?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js" integrity="sha512-CNgIRecGo7nphbeZ04Sc13ka07paqdeTu0WR1IM4kNcpmBAUSHSQX0FslNhTDadL4O5SAGapGt4FodqL8My0mA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
(function(){
  const box=document.getElementById('upiQr'); if(!box) return;
  const uri=box.getAttribute('data-upi')||''; if(!uri) return;
  try{
    if(typeof QRCode==='undefined') throw new Error('QRCode library unavailable');
    new QRCode(box,{text:uri,width:108,height:108,colorDark:'#0f172a',colorLight:'#ffffff',correctLevel:QRCode.CorrectLevel.M});
  }catch(e){
    const img=document.createElement('img');
    img.alt='UPI payment QR';
    img.width=108; img.height=108;
    img.src='https://api.qrserver.com/v1/create-qr-code/?size=220x220&data='+encodeURIComponent(uri);
    box.appendChild(img);
  }
})();
</script>
<?php endif;?>
</body>
</html>
