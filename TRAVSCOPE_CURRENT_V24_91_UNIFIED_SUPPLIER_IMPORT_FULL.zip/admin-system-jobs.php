<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/job-functions.php';

$aclFile =
    __DIR__
    . '/access-control-functions.php';

if (
    is_file($aclFile)
    && !function_exists(
        'tsAclCan'
    )
) {
    require_once
        $aclFile;
}

requireAdmin();

$admin =
    currentAdmin($pdo);

if (
    !$admin
    || strtolower(
        (string)(
            $admin['status']
            ?? ''
        )
    ) !== 'active'
) {
    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_role']
    );

    redirect(
        BASE_URL
        . 'login.php'
    );
}

$adminId =
    (int)$admin['id'];

$canManage =
    function_exists('tsAclCan')
        ? tsAclCan(
            $pdo,
            $adminId,
            'manage_access'
        )
        : in_array(
            strtolower(
                (string)(
                    $admin['role']
                    ?? 'admin'
                )
            ),
            [
                'admin',
                'super_admin',
            ],
            true
        );

if (!$canManage) {
    http_response_code(403);

    exit(
        'System Jobs Control Center requires Manage Permissions authority.'
    );
}

if (
    empty(
        $_SESSION[
            'admin_system_jobs_csrf'
        ]
    )
) {
    $_SESSION[
        'admin_system_jobs_csrf'
    ] =
        bin2hex(
            random_bytes(32)
        );
}

$csrf =
    (string)$_SESSION[
        'admin_system_jobs_csrf'
    ];

$error = '';
$success = '';

if (
    !empty(
        $_SESSION[
            'admin_system_jobs_success'
        ]
    )
) {
    $success =
        (string)$_SESSION[
            'admin_system_jobs_success'
        ];

    unset(
        $_SESSION[
            'admin_system_jobs_success'
        ]
    );
}

if (
    $_SERVER['REQUEST_METHOD']
    === 'POST'
) {
    $postedToken =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    if (
        $postedToken === ''
        || !hash_equals(
            $csrf,
            $postedToken
        )
    ) {
        $error =
            'Security verification failed. Refresh and try again.';

    } else {
        try {
            $action =
                (string)(
                    $_POST['action']
                    ?? ''
                );

            if (
                $action
                === 'save_policy'
            ) {
                $jobKey =
                    trim(
                        (string)(
                            $_POST[
                                'job_key'
                            ]
                            ?? ''
                        )
                    );

                $enabled =
                    !empty(
                        $_POST[
                            'is_enabled'
                        ]
                    );

                $expected =
                    max(
                        1,
                        (int)(
                            $_POST[
                                'expected_interval_minutes'
                            ]
                            ?? 15
                        )
                    );

                $stale =
                    max(
                        $expected,
                        (int)(
                            $_POST[
                                'stale_after_minutes'
                            ]
                            ?? (
                                $expected
                                * 3
                            )
                        )
                    );

                tsJobSetPolicy(
                    $pdo,
                    $jobKey,
                    $enabled,
                    $expected,
                    $stale,
                    $adminId
                );

                $_SESSION[
                    'admin_system_jobs_success'
                ] =
                    'System Job policy updated.';

            } elseif (
                $action
                === 'sync_alerts'
            ) {
                tsJobSyncAlerts(
                    $pdo
                );

                $_SESSION[
                    'admin_system_jobs_success'
                ] =
                    'System Job alert status refreshed.';

            } else {
                throw new RuntimeException(
                    'Invalid System Job action.'
                );
            }

            redirect(
                BASE_URL
                . 'admin-system-jobs.php'
            );

        } catch (RuntimeException $e) {
            $error =
                $e->getMessage();

        } catch (Throwable $e) {
            error_log(
                'TRAVSCOPE System Jobs: '
                . $e->getMessage()
            );

            $error =
                'Unable to complete System Job action: '
                . $e->getMessage();
        }
    }
}

$ready =
    tsJobReady($pdo);

if ($ready) {
    tsJobEnsureCatalog($pdo);

    try {
        tsJobSyncAlerts($pdo);

    } catch (Throwable $e) {
        // Job dashboard remains available even if Notification sync is unavailable.
    }
}

$jobs =
    tsJobRows($pdo);

$runs =
    tsJobRecentRuns(
        $pdo,
        null,
        120
    );

function sjE(?string $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function sjDate(?string $value): string
{
    if (!$value) {
        return '-';
    }

    $ts =
        strtotime($value);

    return
        $ts
            ? date(
                'd M Y · h:i:s A',
                $ts
            )
            : (string)$value;
}

function sjDuration(mixed $ms): string
{
    if (
        $ms === null
        || $ms === ''
    ) {
        return '-';
    }

    $ms =
        max(
            0,
            (int)$ms
        );

    if ($ms < 1000) {
        return
            $ms
            . ' ms';
    }

    return
        number_format(
            $ms / 1000,
            2
        )
        . ' sec';
}

function sjHealthClass(string $health): string
{
    return
        match ($health) {
            'healthy' => 'good',
            'running' => 'info',
            'warning' => 'warn',
            'failure' => 'bad',
            'stale' => 'bad',
            'critical' => 'critical',
            'disabled' => 'neutral',
            default => 'neutral',
        };
}

function sjHealthLabel(string $health): string
{
    return
        match ($health) {
            'healthy' => 'HEALTHY',
            'running' => 'RUNNING',
            'warning' => 'WARNING',
            'failure' => 'FAILED',
            'stale' => 'STALE',
            'critical' => 'STUCK',
            'disabled' => 'DISABLED',
            default => 'NOT RUN YET',
        };
}

function sjRunClass(string $status): string
{
    return
        match ($status) {
            'success' => 'good',
            'warning' => 'warn',
            'failure' => 'bad',
            'running' => 'info',
            default => 'neutral',
        };
}

$healthyCount =
    count(
        array_filter(
            $jobs,
            static fn($job) =>
                (string)$job[
                    'health'
                ]
                === 'healthy'
        )
    );

$attentionCount =
    count(
        array_filter(
            $jobs,
            static fn($job) =>
                in_array(
                    (string)$job[
                        'health'
                    ],
                    [
                        'warning',
                        'failure',
                        'stale',
                        'critical',
                        'never',
                    ],
                    true
                )
        )
    );

$runningCount =
    count(
        array_filter(
            $jobs,
            static fn($job) =>
                (string)$job[
                    'health'
                ]
                === 'running'
        )
    );

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta
    name="viewport"
    content="width=device-width,initial-scale=1"
>
<title>System Jobs | TRAVSCOPE Admin</title>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:68px;padding:10px 4%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;border-bottom:1px solid #dfe7f0;position:sticky;top:0;z-index:20}.brand{font-weight:900}.brand span{color:#2563eb}.actions{display:flex;gap:7px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 10px;border:1px solid #cbd5e1;border-radius:9px;background:#fff;color:#334155;text-decoration:none;font-size:9px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.wrap{max-width:1450px;margin:20px auto;padding:0 13px}.hero{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;padding:17px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:20px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px;line-height:1.55}.notice{margin-top:10px;padding:10px 12px;border-radius:10px;font-size:10px;line-height:1.5}.notice.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#047857}.notice.err{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c}.notice.warn{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412}.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:11px}.stat{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.stat span{display:block;font-size:7px;font-weight:900;color:#64748b;text-transform:uppercase}.stat strong{display:block;margin-top:4px;font-size:13px}.jobs{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:11px}.job{background:#fff;border:1px solid #dfe7f0;border-radius:13px;overflow:hidden}.job-head{padding:11px;border-bottom:1px solid #e8eef5;background:#fbfdff}.job-head h2{margin:0;font-size:11px}.job-head p{margin:4px 0 0;color:#64748b;font-size:8px}.job-body{padding:10px}.pill{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:7px;font-weight:900;background:#f1f5f9;color:#64748b}.pill.good{background:#dcfce7;color:#166534}.pill.warn{background:#fef3c7;color:#92400e}.pill.bad{background:#fee2e2;color:#b91c1c}.pill.critical{background:#7f1d1d;color:#fff}.pill.info{background:#dbeafe;color:#1d4ed8}.pill.neutral{background:#e2e8f0;color:#475569}.meta{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:9px}.meta div{padding:7px;border:1px solid #e2e8f0;border-radius:8px}.meta span{display:block;font-size:6.8px;color:#94a3b8;font-weight:900;text-transform:uppercase}.meta strong{display:block;margin-top:3px;font-size:8.3px}.message{margin-top:8px;padding:8px;border:1px solid #e2e8f0;border-radius:8px;background:#f8fafc;font-size:8px;line-height:1.5;color:#475569}.command{margin-top:8px;padding:8px;border-radius:8px;background:#0f172a;color:#e2e8f0;font-family:monospace;font-size:7.5px;line-height:1.5;word-break:break-all}.policy{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:8px}.field label{display:block;margin-bottom:3px;font-size:7px;color:#64748b;font-weight:900}.field input[type=number]{width:100%;padding:6px;border:1px solid #cbd5e1;border-radius:7px;font-size:8px}.toggle{display:flex;align-items:center;gap:6px;font-size:8px;font-weight:900;margin:7px 0}.card{margin-top:11px;background:#fff;border:1px solid #dfe7f0;border-radius:13px;overflow:hidden}.head{padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff;display:flex;justify-content:space-between;gap:8px;align-items:center}.head h2{margin:0;font-size:12px}.head p{margin:3px 0 0;color:#64748b;font-size:8px}.body{padding:10px}.table-wrap{overflow:auto;border:1px solid #e2e8f0;border-radius:9px}table{width:100%;border-collapse:collapse;min-width:1100px}th,td{padding:7px 8px;border-bottom:1px solid #eef2f7;text-align:left;font-size:7.8px;vertical-align:top}th{background:#f8fafc;color:#64748b;font-size:7px;text-transform:uppercase}.safety{padding:10px;border:1px solid #bfdbfe;border-radius:10px;background:#eff6ff;color:#1e40af;font-size:8.5px;line-height:1.55}
@media(max-width:1100px){.jobs{grid-template-columns:1fr}.stats{grid-template-columns:1fr 1fr}}@media(max-width:600px){.top,.hero{flex-direction:column;align-items:flex-start}.stats,.meta,.policy{grid-template-columns:1fr}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head>

<body>

<header class="top">
    <div class="brand">
        TRAV<span>SCOPE</span>
        · SYSTEM JOBS
    </div>

    <div class="actions">
        <a
            class="btn"
            href="<?= sjE(
                BASE_URL
                . 'admin-dashboard.php'
            ); ?>"
        >
            <i class="fa-solid fa-gauge-high"></i>
            Dashboard
        </a>

        <a
            class="btn"
            href="<?= sjE(
                BASE_URL
                . 'admin-system-health.php'
            ); ?>"
        >
            <i class="fa-solid fa-heart-pulse"></i>
            Health
        </a>

        <a
            class="btn"
            href="<?= sjE(
                BASE_URL
                . 'admin-notifications.php'
            ); ?>"
        >
            <i class="fa-solid fa-bell"></i>
            Notifications
        </a>
    </div>
</header>

<main class="wrap">

<section class="hero">
    <div>
        <h1>System Jobs + Cron Control Center</h1>

        <p>
            Monitor the three existing TRAVSCOPE CLI jobs from one Admin screen:
            Customer Communication, System Notifications and System Health.
            The browser never runs cron business logic. Hosting/CLI remains the
            execution layer; this page only controls policy, shows run history,
            prevents overlap and surfaces stale/failed jobs.
        </p>
    </div>

    <form method="post">
        <input
            type="hidden"
            name="csrf_token"
            value="<?= sjE($csrf); ?>"
        >

        <input
            type="hidden"
            name="action"
            value="sync_alerts"
        >

        <button
            class="btn primary"
            type="submit"
        >
            <i class="fa-solid fa-arrows-rotate"></i>
            Refresh Job Alerts
        </button>
    </form>
</section>

<?php if ($success): ?>
    <div class="notice ok">
        <?= sjE($success); ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="notice err">
        <?= sjE($error); ?>
    </div>
<?php endif; ?>

<?php if (!$ready): ?>
    <div class="notice warn">
        Import
        <strong>TRAVSCOPE_System_Jobs_Cron_Control_Center.sql</strong>
        first. Existing cron scripts can continue in legacy untracked mode
        until the two System Job tables are installed.
    </div>
<?php endif; ?>

<div class="stats">
    <div class="stat">
        <span>Registered Jobs</span>
        <strong><?= count($jobs); ?></strong>
    </div>

    <div class="stat">
        <span>Healthy</span>
        <strong><?= $healthyCount; ?></strong>
    </div>

    <div class="stat">
        <span>Running</span>
        <strong><?= $runningCount; ?></strong>
    </div>

    <div class="stat">
        <span>Needs Attention</span>
        <strong><?= $attentionCount; ?></strong>
    </div>
</div>

<div class="safety" style="margin-top:11px;">
    <strong>Execution safety:</strong>
    this Admin page intentionally has no “Run Now” button.
    Configure the commands below in your hosting Cron Jobs / CLI scheduler.
    MySQL advisory locks prevent overlapping runs of the same job.
</div>

<section class="jobs">

<?php foreach ($jobs as $job): ?>
    <article class="job">
        <div class="job-head">
            <div style="display:flex;justify-content:space-between;gap:7px;align-items:flex-start;">
                <div>
                    <h2><?= sjE(
                        (string)$job[
                            'job_label'
                        ]
                    ); ?></h2>

                    <p>
                        <?= sjE(
                            (string)$job[
                                'script_name'
                            ]
                        ); ?>
                    </p>
                </div>

                <span class="pill <?= sjE(
                    sjHealthClass(
                        (string)$job[
                            'health'
                        ]
                    )
                ); ?>">
                    <?= sjE(
                        sjHealthLabel(
                            (string)$job[
                                'health'
                            ]
                        )
                    ); ?>
                </span>
            </div>
        </div>

        <div class="job-body">

            <div class="meta">
                <div>
                    <span>Last Start</span>
                    <strong><?= sjE(
                        sjDate(
                            $job[
                                'last_started_at'
                            ]
                        )
                    ); ?></strong>
                </div>

                <div>
                    <span>Last Finish</span>
                    <strong><?= sjE(
                        sjDate(
                            $job[
                                'last_finished_at'
                            ]
                        )
                    ); ?></strong>
                </div>

                <div>
                    <span>Duration</span>
                    <strong><?= sjE(
                        sjDuration(
                            $job[
                                'last_duration_ms'
                            ]
                        )
                    ); ?></strong>
                </div>

                <div>
                    <span>Exit Code</span>
                    <strong>
                        <?= $job[
                            'last_exit_code'
                        ] !== null
                            ? (int)$job[
                                'last_exit_code'
                            ]
                            : '-'; ?>
                    </strong>
                </div>
            </div>

            <div class="message">
                <?= sjE(
                    (string)(
                        $job[
                            'last_message'
                        ]
                        ?: 'No tracked run yet.'
                    )
                ); ?>
            </div>

            <div class="command">
                <?= sjE(
                    (string)$job[
                        'command_example'
                    ]
                ); ?>
            </div>

            <form method="post">
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= sjE($csrf); ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="save_policy"
                >

                <input
                    type="hidden"
                    name="job_key"
                    value="<?= sjE(
                        (string)$job[
                            'job_key'
                        ]
                    ); ?>"
                >

                <label class="toggle">
                    <input
                        type="checkbox"
                        name="is_enabled"
                        value="1"
                        <?= (int)$job[
                            'is_enabled'
                        ] === 1
                            ? 'checked'
                            : ''; ?>
                    >
                    Enabled
                </label>

                <div class="policy">
                    <div class="field">
                        <label>
                            Expected Every · Minutes
                        </label>

                        <input
                            type="number"
                            name="expected_interval_minutes"
                            min="1"
                            max="1440"
                            value="<?= (int)$job[
                                'expected_interval_minutes'
                            ]; ?>"
                            required
                        >
                    </div>

                    <div class="field">
                        <label>
                            Stale After · Minutes
                        </label>

                        <input
                            type="number"
                            name="stale_after_minutes"
                            min="<?= max(
                                1,
                                (int)$job[
                                    'expected_interval_minutes'
                                ]
                            ); ?>"
                            max="10080"
                            value="<?= (int)$job[
                                'stale_after_minutes'
                            ]; ?>"
                            required
                        >
                    </div>
                </div>

                <button
                    class="btn"
                    type="submit"
                    style="margin-top:7px;"
                >
                    Save Job Policy
                </button>
            </form>
        </div>
    </article>
<?php endforeach; ?>

</section>


<section class="card">
    <div class="head">
        <div>
            <h2>Recent Job Runs</h2>
            <p>
                Latest 120 tracked CLI executions.
                SKIPPED normally means disabled or overlap prevention.
            </p>
        </div>
    </div>

    <div class="body">
        <?php if (!$runs): ?>
            <div class="safety">
                No tracked cron execution yet.
                Run the configured commands from CLI/hosting cron after installing the SQL.
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th>Started</th>
                        <th>Job</th>
                        <th>Status</th>
                        <th>Finished</th>
                        <th>Duration</th>
                        <th>Exit</th>
                        <th>Summary</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php foreach ($runs as $run): ?>
                        <tr>
                            <td>
                                <?= sjE(
                                    sjDate(
                                        (string)$run[
                                            'started_at'
                                        ]
                                    )
                                ); ?>
                            </td>

                            <td>
                                <?= sjE(
                                    (string)$run[
                                        'job_key'
                                    ]
                                ); ?>
                            </td>

                            <td>
                                <span class="pill <?= sjE(
                                    sjRunClass(
                                        (string)$run[
                                            'status'
                                        ]
                                    )
                                ); ?>">
                                    <?= sjE(
                                        strtoupper(
                                            (string)$run[
                                                'status'
                                            ]
                                        )
                                    ); ?>
                                </span>
                            </td>

                            <td>
                                <?= sjE(
                                    sjDate(
                                        $run[
                                            'finished_at'
                                        ]
                                    )
                                ); ?>
                            </td>

                            <td>
                                <?= sjE(
                                    sjDuration(
                                        $run[
                                            'duration_ms'
                                        ]
                                    )
                                ); ?>
                            </td>

                            <td>
                                <?= $run[
                                    'exit_code'
                                ] !== null
                                    ? (int)$run[
                                        'exit_code'
                                    ]
                                    : '-'; ?>
                            </td>

                            <td>
                                <?= sjE(
                                    (string)(
                                        $run[
                                            'summary'
                                        ]
                                        ?: '-'
                                    )
                                ); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</section>

</main>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
