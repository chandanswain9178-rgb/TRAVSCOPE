<?php
/**
 * TRAVSCOPE verified customer payment receipt PDF (V24.35).
 * Shared by automatic approval emails and admin/customer PDF view.
 * Uses the immutable payment receipt snapshot; no external PDF library is required.
 * A receipt is only created from an already verified/successful payment.
 */
declare(strict_types=1);

function tsReceiptPdfText($value): string
{
    $value = html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $value = str_replace(["\r", "\n", "\t", "\xC2\xA0"], ' ', $value);
    if (function_exists('iconv')) {
        $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if ($ascii !== false) $value = $ascii;
    }
    $value = preg_replace('/[^\x20-\x7E]/', '', $value) ?? '';
    return trim(preg_replace('/\s+/', ' ', $value) ?? '');
}

function tsReceiptPdfEsc(string $value): string
{
    return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], tsReceiptPdfText($value));
}


/** Resolve a General Settings logo URL/path to a local file when possible. */
function tsReceiptPdfLogoPath(string $logo): ?string
{
    $logo = trim($logo);
    if ($logo === '') return null;
    $clean = preg_replace('/[?#].*$/', '', $logo) ?? $logo;
    if (preg_match('#^https?://#i', $clean)) {
        $urlPath = (string)(parse_url($clean, PHP_URL_PATH) ?? '');
        $basePath = defined('BASE_URL') ? (string)(parse_url((string)BASE_URL, PHP_URL_PATH) ?? '/') : '/';
        $basePath = '/' . trim($basePath, '/');
        if ($basePath === '/') $basePath = '';
        if ($basePath !== '' && str_starts_with($urlPath, $basePath . '/')) $urlPath = substr($urlPath, strlen($basePath));
        $clean = ltrim($urlPath, '/');
    } else {
        $clean = ltrim(str_replace('\\', '/', $clean), '/');
    }
    if ($clean === '' || str_contains($clean, '..')) return null;
    $candidate = __DIR__ . '/' . $clean;
    return is_file($candidate) ? $candidate : null;
}
function tsReceiptPdfPaeth(int $a, int $b, int $c): int
{
    $p=$a+$b-$c; $pa=abs($p-$a); $pb=abs($p-$b); $pc=abs($p-$c);
    if ($pa <= $pb && $pa <= $pc) return $a;
    return $pb <= $pc ? $b : $c;
}
function tsReceiptPdfPngRgb(string $bytes): ?array
{
    if (substr($bytes,0,8) !== "\x89PNG\r\n\x1a\n") return null;
    $off=8; $len=strlen($bytes); $w=$h=$bit=$type=$interlace=null; $idat=''; $palette=''; $trans='';
    while ($off+12 <= $len) {
        $chunkLen=(int)(unpack('N',substr($bytes,$off,4))[1]??0); $off+=4;
        $chunkType=substr($bytes,$off,4); $off+=4;
        if ($chunkLen<0 || $off+$chunkLen+4>$len) return null;
        $data=substr($bytes,$off,$chunkLen); $off += $chunkLen + 4;
        if ($chunkType==='IHDR' && strlen($data)>=13) {
            $ih=unpack('Nw/Nh/Cbit/Ctype/Ccomp/Cfilter/Cinterlace',$data);
            $w=(int)$ih['w']; $h=(int)$ih['h']; $bit=(int)$ih['bit']; $type=(int)$ih['type']; $interlace=(int)$ih['interlace'];
        } elseif ($chunkType==='IDAT') $idat.=$data;
        elseif ($chunkType==='PLTE') $palette.=$data;
        elseif ($chunkType==='tRNS') $trans.=$data;
        elseif ($chunkType==='IEND') break;
    }
    if (!$w || !$h || !in_array($bit,[8,16],true) || $interlace!==0 || $idat==='') return null;
    if ($type===3 && $bit!==8) return null;
    $channels=[0=>1,2=>3,3=>1,4=>2,6=>4][$type]??0; if(!$channels)return null;
    $sampleBytes=$bit===16?2:1; $bpp=$channels*$sampleBytes;
    $raw=function_exists('zlib_decode')?@zlib_decode($idat):false; if ($raw===false) $raw=@gzuncompress($idat); if (!is_string($raw)) return null;
    $stride=$w*$bpp; $pos=0; $prev=array_fill(0,$stride,0); $rgb=''; $rawLen=strlen($raw);
    for ($y=0;$y<$h;$y++) {
        if ($pos >= $rawLen) return null; $filter=ord($raw[$pos++]); if ($pos+$stride>$rawLen) return null;
        $src=substr($raw,$pos,$stride); $pos+=$stride; $row=array_fill(0,$stride,0);
        for ($i=0;$i<$stride;$i++) {
            $v=ord($src[$i]); $a=$i>=$bpp?$row[$i-$bpp]:0; $b=$prev[$i]??0; $c=$i>=$bpp?($prev[$i-$bpp]??0):0;
            if ($filter===1) $v=($v+$a)&255; elseif ($filter===2) $v=($v+$b)&255; elseif ($filter===3) $v=($v+intdiv($a+$b,2))&255; elseif ($filter===4) $v=($v+tsReceiptPdfPaeth($a,$b,$c))&255; elseif ($filter!==0) return null;
            $row[$i]=$v;
        }
        $sample = static function(array $row,int $offset,int $sampleBytes):int{return $row[$offset]??0;}; // 16-bit: keep high byte for 8-bit PDF output.
        if ($type===2) for($x=0;$x<$w;$x++){ $i=$x*3*$sampleBytes; $rgb.=chr($sample($row,$i,$sampleBytes)).chr($sample($row,$i+$sampleBytes,$sampleBytes)).chr($sample($row,$i+2*$sampleBytes,$sampleBytes)); }
        elseif ($type===6) for($x=0;$x<$w;$x++){ $i=$x*4*$sampleBytes; $alpha=$sample($row,$i+3*$sampleBytes,$sampleBytes); foreach([$sample($row,$i,$sampleBytes),$sample($row,$i+$sampleBytes,$sampleBytes),$sample($row,$i+2*$sampleBytes,$sampleBytes)] as $cv) $rgb.=chr((int)round(($cv*$alpha+255*(255-$alpha))/255)); }
        elseif ($type===0) for($x=0;$x<$w;$x++){ $g=$sample($row,$x*$sampleBytes,$sampleBytes); $rgb.=chr($g).chr($g).chr($g); }
        elseif ($type===4) for($x=0;$x<$w;$x++){ $i=$x*2*$sampleBytes; $g=$sample($row,$i,$sampleBytes); $alpha=$sample($row,$i+$sampleBytes,$sampleBytes); $v=(int)round(($g*$alpha+255*(255-$alpha))/255); $rgb.=chr($v).chr($v).chr($v); }
        elseif ($type===3) { if($palette==='')return null; for($x=0;$x<$w;$x++){ $idx=$row[$x]; $pi=$idx*3; if($pi+2>=strlen($palette))return null; $alpha=$idx<strlen($trans)?ord($trans[$idx]):255; foreach([ord($palette[$pi]),ord($palette[$pi+1]),ord($palette[$pi+2])] as $cv) $rgb.=chr((int)round(($cv*$alpha+255*(255-$alpha))/255)); } }
        $prev=$row;
    }
    $compressed=gzcompress($rgb,9); if ($compressed===false) return null;
    return ['data'=>$compressed,'width'=>$w,'height'=>$h,'filter'=>'/FlateDecode','color_space'=>'/DeviceRGB'];
}
function tsReceiptPdfLogoImage(string $logo): ?array
{
    $path=tsReceiptPdfLogoPath($logo); if(!$path)return null; $bytes=@file_get_contents($path); if(!is_string($bytes)||$bytes==='')return null;
    $info=@getimagesizefromstring($bytes); if(!$info||empty($info[0])||empty($info[1]))return null;
    if(($info['mime']??'')==='image/jpeg') return ['data'=>$bytes,'width'=>(int)$info[0],'height'=>(int)$info[1],'filter'=>'/DCTDecode','color_space'=>(($info['channels']??3)==4?'/DeviceCMYK':'/DeviceRGB')];
    if(($info['mime']??'')==='image/png'){ $png=tsReceiptPdfPngRgb($bytes); if($png)return $png; }
    if(function_exists('imagecreatefromstring')&&function_exists('imagejpeg')){
        $src=@imagecreatefromstring($bytes); if($src!==false){$w=imagesx($src);$h=imagesy($src);$dst=imagecreatetruecolor($w,$h);$white=imagecolorallocate($dst,255,255,255);imagefill($dst,0,0,$white);imagealphablending($dst,true);imagecopy($dst,$src,0,0,0,0,$w,$h);ob_start();imagejpeg($dst,null,92);$jpg=(string)ob_get_clean();imagedestroy($dst);imagedestroy($src);if($jpg!=='')return ['data'=>$jpg,'width'=>$w,'height'=>$h,'filter'=>'/DCTDecode','color_space'=>'/DeviceRGB'];}
    }
    return null;
}

/** PDF bytes for the very same receipt used by email and on-page PDF preview. */
function tsBillVerifiedReceiptPdf(array $r, ?PDO $pdo = null): string
{
    if (empty($r['receipt_code']) || (int)($r['id'] ?? 0) < 1) {
        throw new InvalidArgumentException('Verified receipt data is required.');
    }
    $s = json_decode((string)($r['snapshot_json'] ?? ''), true);
    if (!is_array($s)) $s = [];
    $company = $pdo instanceof PDO && function_exists('tsBillTaxDefaults') ? tsBillTaxDefaults($pdo) : (function_exists('tsBillVerifiedSellerProfile') ? tsBillVerifiedSellerProfile() : [
        'legal_name'=>'MEMORABLE HOSPITALITY PRIVATE LIMITED','header_name'=>'Memorable Hospitality Pvt. Ltd.','trade_name'=>'Travscope','gstin'=>'21AALCM7012J1ZM','pan'=>'AALCM7012J','address'=>'PLOT NO - 1215/1416, KHANDAGIRI BARI, KHANDAGIRI, BHUBANESWAR, Khordha, Odisha, 751030','state'=>'Odisha','state_code'=>'21','logo_url'=>'assets/travscope-document-logo-wide.png'
    ]);
    $receiptLogo = (string)($company['logo_url'] ?? '');
    if ($pdo instanceof PDO && function_exists('tsBillSetting')) {
        $pdfLogoSetting = trim(tsBillSetting($pdo, 'document_logo_pdf', ''));
        if ($pdfLogoSetting !== '') {
            $receiptLogo = $pdfLogoSetting;
        }
    }
    $logoImage = tsReceiptPdfLogoImage($receiptLogo);
    $currency = strtoupper(tsReceiptPdfText($r['currency'] ?? 'INR')) ?: 'INR';
    $code = tsReceiptPdfText($r['receipt_code']);
    $bookingNumber = tsReceiptPdfText($s['booking_number'] ?? $r['booking_number'] ?? '-');
    $customer = tsReceiptPdfText($s['customer']['name'] ?? $r['customer_name'] ?? 'Customer');
    $email = tsReceiptPdfText($s['customer']['email'] ?? $r['customer_email'] ?? '');
    $amount = max(0, (float)($s['payment']['amount'] ?? $r['amount'] ?? 0));
    $total = max(0, (float)($s['booking_total'] ?? $r['total_amount'] ?? 0));
    $paid = max(0, (float)($s['booking_paid'] ?? $r['paid_amount'] ?? 0));
    $balance = max(0, (float)($s['booking_balance'] ?? ($total - $paid)));
    $method = tsReceiptPdfText($s['payment']['payment_method'] ?? $r['payment_method'] ?? '-');
    $reference = tsReceiptPdfText($s['payment']['transaction_id'] ?? $r['transaction_id'] ?? '-');
    $against = tsReceiptPdfText($r['installment_summary'] ?? 'Booking payment') ?: 'Booking payment';
    $paidRaw = (string)($s['payment']['paid_at'] ?? $r['paid_at'] ?? $r['created_at'] ?? '');
    $date = $paidRaw !== '' && strtotime($paidRaw) ? date('d M Y, h:i A', strtotime($paidRaw)) : '-';
    $cash = static function (float $n) use ($currency): string { return $currency . ' ' . number_format($n, 2); };
    $cut = static function (string $str, int $max): string {
        return strlen($str) > $max ? substr($str, 0, $max - 3) . '...' : $str;
    };
    $commands = [];
    $rect = static function ($x, $y, $w, $h, $rgb) use (&$commands): void {
        $commands[] = sprintf('%.3F %.3F %.3F rg %.2F %.2F %.2F %.2F re f', ...array_merge($rgb, [$x,$y,$w,$h]));
    };
    $line = static function ($x1,$y1,$x2,$y2,$rgb=[0.85,0.89,0.94]) use (&$commands): void {
        $commands[] = sprintf('%.3F %.3F %.3F RG 0.6 w %.2F %.2F m %.2F %.2F l S', ...array_merge($rgb,[$x1,$y1,$x2,$y2]));
    };
    $tx = static function ($x,$y,$value,$size=10,$bold=false,$rgb=[0.09,0.16,0.29]) use (&$commands): void {
        $commands[] = sprintf('BT /%s %.2F Tf %.3F %.3F %.3F rg 1 0 0 1 %.2F %.2F Tm (%s) Tj ET',
            $bold?'F2':'F1', $size, ...array_merge($rgb,[$x,$y,tsReceiptPdfEsc((string)$value)]));
    };
    $navy=[0.055,0.125,0.24]; $blue=[0.145,0.388,0.922]; $green=[0.025,0.43,0.32]; $muted=[0.40,0.46,0.54];

    // International invoice-style A4 header: white canvas, document logo,
    // legal seller identity and document metadata in one clean band.
    $rect(0,837,595,5,$blue);
    if ($logoImage) {
        // 3 inch document logo target: 216pt wide, aspect ratio preserved.
        $iw=max(1,(float)$logoImage['width']); $ih=max(1,(float)$logoImage['height']);
        $scale=min(216/$iw,72/$ih); $dw=$iw*$scale; $dh=$ih*$scale;
        $dx=30; $dy=754+(72-$dh)/2;
        $commands[] = sprintf('q %.2F 0 0 %.2F %.2F %.2F cm /Logo Do Q',$dw,$dh,$dx,$dy);
    }
    $headerName=$cut(tsReceiptPdfText($company['header_name'] ?? 'Memorable Hospitality Pvt. Ltd.'),31);
    $tx(258,812,$headerName,10.3,true,$navy);
    $tx(258,796,'Trade Name: '.$cut(tsReceiptPdfText($company['trade_name'] ?? 'Travscope'),19),7.8,true,$muted);
    $tx(258,780,'GSTIN '.$cut(tsReceiptPdfText($company['gstin'] ?? ''),18).'  |  PAN '.$cut(tsReceiptPdfText($company['pan'] ?? ''),12),7.4,false,$muted);
    $tx(430,812,'MONEY RECEIPT',14.5,true,$navy);
    $tx(430,790,'RECEIPT REF',7.0,true,$muted);
    $tx(430,775,$cut($code,21),8.6,true,$navy);
    $tx(430,759,$date,7.0,false,$muted);
    $address=$cut(tsReceiptPdfText($company['address'] ?? ''),103);
    if($address!=='')$tx(30,728,$address,7.2,false,$muted);
    $line(30,712,565,712,[0.80,0.85,0.91]);

    $rect(40,607,515,82,[0.91,0.985,0.955]);
    $tx(56,666,'VERIFIED AMOUNT RECEIVED',9.5,true,$green);
    $tx(56,630,$cash($amount),27,true,$green);
    $tx(404,664,'APPROVED PAYMENT',7.2,true,$muted);
    $tx(404,647,$date,7.3,false,$navy);

    $tx(40,574,'CUSTOMER & BOOKING',9.5,true,$navy);
    $line(40,564,555,564);
    $tx(40,545,'RECEIVED FROM',7.6,true,$muted);
    $tx(40,528,$cut($customer,36),11.2,true,$navy);
    $tx(316,545,'BOOKING NUMBER',7.6,true,$muted);
    $tx(316,528,$cut($bookingNumber,33),11.2,true,$navy);
    if ($email !== '') $tx(40,510,$cut($email,66),8.5,false,$muted);

    $tx(40,480,'PAYMENT INFORMATION',9.5,true,$navy);
    $line(40,470,555,470);
    $tx(40,451,'PAYMENT DATE',7.6,true,$muted); $tx(40,435,$date,9.4,true,$navy);
    $tx(316,451,'PAYMENT METHOD',7.6,true,$muted); $tx(316,435,$cut($method,36),9.4,true,$navy);
    $tx(40,405,'TRANSACTION / UTR',7.6,true,$muted); $tx(40,389,$cut($reference,44),9.4,true,$navy);
    $tx(316,405,'AGAINST',7.6,true,$muted); $tx(316,389,$cut($against,40),8.8,true,$navy);

    $tx(40,355,'BOOKING PAYMENT SUMMARY',9.5,true,$navy);
    $line(40,345,555,345);
    $items = [
        ['Booking / invoice payable', $cash($total)],
        ['Total verified paid at receipt issue', $cash($paid)],
        ['Outstanding balance at receipt issue', $cash($balance)],
    ];
    $y = 321;
    foreach ($items as $idx => [$key, $val]) {
        if ($idx === 2) $rect(40,$y-10,515,31,[0.94,0.97,1]);
        $tx(52,$y,$key,9.4,$idx===2,$idx===2?$navy:$muted);
        $tx(390,$y,$val,10.4,true,$idx===2?$navy:$green);
        $y -= 38;
    }

    $line(40,157,555,157);
    $tx(40,139,'This receipt acknowledges an APPROVED payment recorded against the booking.',8.6,true,$navy);
    $tx(40,122,'It is not a statutory tax invoice or a ticket/booking confirmation.',7.8,false,$muted);
    $tx(40,100,'Receipt reference: ' . $cut($code,43),7.8,false,$muted);
    $rect(0,0,595,39,[0.965,0.978,0.99]);
    $tx(40,18,$cut(tsReceiptPdfText($company['trade_name'] ?? 'Travscope'),22).'  |  Customer Payment Receipt',7.8,true,$navy);
    $tx(435,18,'Generated electronically',7.8,false,$muted);

    $stream = implode("\n", $commands) . "\n";
    $objects=[];
    $objects[1]='<< /Type /Catalog /Pages 2 0 R >>';
    $objects[2]='<< /Type /Pages /Kids [3 0 R] /Count 1 >>';
    $objects[4]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
    $objects[5]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
    $contentId=$logoImage?7:6; $xObject='';
    if($logoImage){
        $objects[6]='<< /Type /XObject /Subtype /Image /Width '.(int)$logoImage['width'].' /Height '.(int)$logoImage['height'].' /ColorSpace '.$logoImage['color_space'].' /BitsPerComponent 8 /Filter '.$logoImage['filter'].' /Length '.strlen((string)$logoImage['data']).">>\nstream\n".(string)$logoImage['data']."\nendstream";
        $xObject=' /XObject << /Logo 6 0 R >>';
    }
    $objects[3]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >>'.$xObject.' >> /Contents '.$contentId.' 0 R >>';
    $objects[$contentId]='<< /Length '.strlen($stream).">>\nstream\n".$stream.'endstream';
    ksort($objects);
    $pdf = "%PDF-1.4\n%TRAVSCOPE\n";
    $offsets=[0]; $maxObjectId=max(array_keys($objects));
    for($id=1;$id<=$maxObjectId;$id++){$object=$objects[$id]??'';$offsets[$id]=strlen($pdf);$pdf.=$id." 0 obj\n".$object."\nendobj\n";}
    $start=strlen($pdf);
    $pdf.="xref\n0 ".($maxObjectId+1)."\n0000000000 65535 f \n";
    for($id=1;$id<=$maxObjectId;$id++)$pdf.=sprintf("%010d 00000 n \n",$offsets[$id]);
    $pdf.='trailer << /Size '.($maxObjectId+1)." /Root 1 0 R >>\nstartxref\n".$start."\n%%EOF\n";
    return $pdf;
}
