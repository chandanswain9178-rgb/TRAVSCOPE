<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| CUSTOMER DASHBOARD
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';


/*
|--------------------------------------------------------------------------
| CUSTOMER LOGIN REQUIRED
|--------------------------------------------------------------------------
*/

requireLogin();


/*
|--------------------------------------------------------------------------
| CURRENT CUSTOMER
|--------------------------------------------------------------------------
*/

$user = currentUser($pdo);

if (!$user) {

    unset($_SESSION['user_id']);

    session_regenerate_id(true);

    redirect(BASE_URL . 'login.php');
}


/*
|--------------------------------------------------------------------------
| ACCOUNT STATUS
|--------------------------------------------------------------------------
*/

if (
    strtolower((string)$user['status']) !== 'active'
) {

    unset($_SESSION['user_id']);

    session_regenerate_id(true);

    setFlash(
        'error',
        'Your account is currently unavailable.'
    );

    redirect(BASE_URL . 'login.php');
}


/*
|--------------------------------------------------------------------------
| VERIFIED EMAIL REQUIRED
|--------------------------------------------------------------------------
*/

if ((int)$user['email_verified'] !== 1) {

    $_SESSION['pending_verify_user_id'] =
        (int)$user['id'];

    $_SESSION['pending_verify_email'] =
        (string)$user['email'];

    $_SESSION['pending_verify_name'] =
        (string)$user['full_name'];

    unset($_SESSION['user_id']);

    redirect(BASE_URL . 'verify-email.php');
}


/*
|--------------------------------------------------------------------------
| USER DATA
|--------------------------------------------------------------------------
*/

$userId =
    (int)$user['id'];

$fullName =
    trim((string)$user['full_name']);

$firstName =
    trim(
        explode(
            ' ',
            $fullName
        )[0] ?? $fullName
    );

if ($firstName === '') {
    $firstName = 'Traveller';
}

$userInitial =
    strtoupper(
        substr(
            $firstName,
            0,
            1
        )
    );


/*
|--------------------------------------------------------------------------
| CUSTOMER ROLE / SERVICE DASHBOARD
|--------------------------------------------------------------------------
|
| Normal user:
| - Service button hidden
|
| Staff:
| - Service -> staff.php
|
| Manager:
| - Service -> manager.php
|
*/

$userRole =
    strtolower(
        trim(
            (string)(
                $user['role']
                ??
                $_SESSION['user_role']
                ??
                'user'
            )
        )
    );

if (
    !in_array(
        $userRole,
        [
            'user',
            'staff',
            'manager'
        ],
        true
    )
) {

    $userRole =
        'user';
}

$_SESSION['user_role'] =
    $userRole;

$serviceDashboardUrl =
    match ($userRole) {

        'manager' =>
            'manager.php',

        'staff' =>
            'staff.php',

        default =>
            ''
    };


/*
|--------------------------------------------------------------------------
| SETTINGS
|--------------------------------------------------------------------------
*/

$siteName =
    getSetting(
        $pdo,
        'site_name',
        'TRAVSCOPE.COM'
    );

$currencySymbol =
    getSetting(
        $pdo,
        'currency_symbol',
        '₹'
    );


/*
|--------------------------------------------------------------------------
| BOOKING STATISTICS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        COUNT(*) AS total_bookings,

        SUM(
            CASE
                WHEN booking_status = 'pending'
                THEN 1
                ELSE 0
            END
        ) AS pending_bookings,

        SUM(
            CASE
                WHEN booking_status = 'confirmed'
                THEN 1
                ELSE 0
            END
        ) AS confirmed_bookings,

        SUM(
            CASE
                WHEN booking_status = 'completed'
                THEN 1
                ELSE 0
            END
        ) AS completed_bookings,

        COALESCE(
            SUM(total_amount),
            0
        ) AS total_booking_value,

        COALESCE(
            SUM(paid_amount),
            0
        ) AS total_paid

    FROM bookings

    WHERE user_id = ?
");

$stmt->execute([$userId]);

$bookingStats =
    $stmt->fetch() ?: [];


$totalBookings =
    (int)(
        $bookingStats['total_bookings']
        ?? 0
    );

$pendingBookings =
    (int)(
        $bookingStats['pending_bookings']
        ?? 0
    );

$confirmedBookings =
    (int)(
        $bookingStats['confirmed_bookings']
        ?? 0
    );

$completedBookings =
    (int)(
        $bookingStats['completed_bookings']
        ?? 0
    );

$totalBookingValue =
    (float)(
        $bookingStats['total_booking_value']
        ?? 0
    );

$totalPaid =
    (float)(
        $bookingStats['total_paid']
        ?? 0
    );

$amountDue =
    max(
        0,
        $totalBookingValue - $totalPaid
    );


/*
|--------------------------------------------------------------------------
| WISHLIST COUNT
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM wishlists
    WHERE user_id = ?
");

$stmt->execute([$userId]);

$wishlistCount =
    (int)$stmt->fetchColumn();


/*
|--------------------------------------------------------------------------
| NEXT UPCOMING TRIP
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        b.id,
        b.booking_number,
        b.package_id,
        b.travel_date,
        b.adults,
        b.children,
        b.total_amount,
        b.paid_amount,
        b.currency,
        b.booking_status,
        b.payment_status,

        p.title AS package_title,
        p.slug AS package_slug,
        p.main_image,
        p.duration_days,
        p.duration_nights,
        p.package_type

    FROM bookings b

    LEFT JOIN packages p
        ON p.id = b.package_id

    WHERE
        b.user_id = ?
        AND b.travel_date IS NOT NULL
        AND b.travel_date >= CURRENT_DATE()
        AND b.booking_status IN (
            'pending',
            'confirmed'
        )

    ORDER BY
        b.travel_date ASC,
        b.id ASC

    LIMIT 1
");

$stmt->execute([$userId]);

$upcomingTrip =
    $stmt->fetch();


/*
|--------------------------------------------------------------------------
| RECENT BOOKINGS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        b.id,
        b.booking_number,
        b.package_id,
        b.travel_date,
        b.total_amount,
        b.paid_amount,
        b.booking_status,
        b.payment_status,
        b.created_at,

        p.title AS package_title,
        p.slug AS package_slug,
        p.main_image

    FROM bookings b

    LEFT JOIN packages p
        ON p.id = b.package_id

    WHERE b.user_id = ?

    ORDER BY b.id DESC

    LIMIT 5
");

$stmt->execute([$userId]);

$recentBookings =
    $stmt->fetchAll();


/*
|--------------------------------------------------------------------------
| RECOMMENDED PACKAGES
|--------------------------------------------------------------------------
|
| Prioritize:
| 1. Featured
| 2. Bestseller
| 3. Popular/views
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        id,
        destination_id,
        title,
        slug,
        package_code,
        short_description,
        duration_days,
        duration_nights,
        regular_price,
        sale_price,
        currency,
        package_type,
        main_image,
        featured,
        bestseller,
        views

    FROM packages

    WHERE status = 'active'

    ORDER BY
        featured DESC,
        bestseller DESC,
        views DESC,
        id DESC

    LIMIT 6
");

$recommendedPackages =
    $stmt->fetchAll();


/*
|--------------------------------------------------------------------------
| WISHLIST PACKAGE IDS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT package_id
    FROM wishlists
    WHERE user_id = ?
");

$stmt->execute([$userId]);

$wishlistPackageIds =
    array_map(
        'intval',
        $stmt->fetchAll(
            PDO::FETCH_COLUMN
        )
    );


/*
|--------------------------------------------------------------------------
| PAYMENT PROGRESS
|--------------------------------------------------------------------------
*/

$paymentProgress = 0;

if ($totalBookingValue > 0) {

    $paymentProgress =
        min(
            100,
            max(
                0,
                ($totalPaid / $totalBookingValue)
                * 100
            )
        );
}


/*
|--------------------------------------------------------------------------
| UPCOMING TRIP DAYS
|--------------------------------------------------------------------------
*/

$daysToTrip = null;

if (
    $upcomingTrip
    &&
    !empty($upcomingTrip['travel_date'])
) {

    try {

        $today =
            new DateTime('today');

        $travelDate =
            new DateTime(
                $upcomingTrip['travel_date']
            );

        $daysToTrip =
            (int)$today
                ->diff($travelDate)
                ->format('%a');

    } catch (Throwable $e) {

        $daysToTrip = null;
    }
}


/*
|--------------------------------------------------------------------------
| PACKAGE IMAGE HELPER
|--------------------------------------------------------------------------
*/

function dashboardPackageImage(?string $image): string
{
    $image = trim((string)$image);

    if ($image === '') {

        return 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1200&q=85';
    }

    if (
        preg_match(
            '#^https?://#i',
            $image
        )
    ) {

        return $image;
    }

    return BASE_URL
        . ltrim(
            $image,
            '/'
        );
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#07192d"
>

<title>
    My Travel Dashboard | <?= e($siteName); ?>
</title>


<!-- GOOGLE FONTS -->

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>


<!-- FONT AWESOME -->

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

/* =========================================================
   VARIABLES
========================================================= */

:root {

    --navy:#07192d;
    --navy-soft:#0d2743;

    --primary:#0b74ff;
    --primary-dark:#075fd2;

    --cyan:#00b8ff;

    --background:#f5f8fc;

    --white:#ffffff;

    --text:#172033;
    --muted:#778294;

    --border:#e5eaf0;

    --green:#0aa66a;
    --orange:#ed8c21;
    --red:#df4859;
    --purple:#7557d8;

    --shadow:
        0 12px 35px
        rgba(7,25,45,.07);
}


/* =========================================================
   RESET
========================================================= */

* {

    margin:0;
    padding:0;

    box-sizing:border-box;
}


html {

    scroll-behavior:smooth;
}


body {

    min-height:100vh;

    background:
        var(--background);

    color:
        var(--text);

    font-family:
        'DM Sans',
        sans-serif;
}


a {

    color:inherit;

    text-decoration:none;
}


button {

    font-family:inherit;
}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar {

    position:fixed;

    top:0;
    bottom:0;
    left:0;

    width:265px;

    background:
        linear-gradient(
            180deg,
            #07192d,
            #061525
        );

    color:white;

    overflow-y:auto;

    z-index:1200;

    transition:.25s ease;
}


.sidebar-logo {

    height:80px;

    padding:0 23px;

    display:flex;

    align-items:center;

    gap:11px;

    border-bottom:
        1px solid
        rgba(255,255,255,.08);

    font-family:
        'Manrope',
        sans-serif;

    font-size:20px;

    font-weight:800;
}


.logo-icon {

    width:42px;
    height:42px;

    border-radius:12px;

    display:grid;

    place-items:center;

    background:
        linear-gradient(
            135deg,
            var(--primary),
            var(--cyan)
        );

    box-shadow:
        0 9px 25px
        rgba(11,116,255,.25);

    transform:
        rotate(-5deg);
}


.sidebar-logo span {

    color:#63b4ff;
}


/* =========================================================
   CUSTOMER PROFILE
========================================================= */

.sidebar-user {

    padding:22px 18px 17px;

    border-bottom:
        1px solid
        rgba(255,255,255,.07);
}


.sidebar-user-row {

    display:flex;

    align-items:center;

    gap:11px;
}


.sidebar-avatar {

    width:43px;
    height:43px;

    flex:0 0 43px;

    border-radius:50%;

    display:grid;

    place-items:center;

    background:
        rgba(99,180,255,.13);

    border:
        1px solid
        rgba(99,180,255,.2);

    color:#78c0ff;

    font-family:
        'Manrope',
        sans-serif;

    font-size:15px;

    font-weight:800;
}


.sidebar-user strong {

    display:block;

    max-width:150px;

    overflow:hidden;

    text-overflow:ellipsis;

    white-space:nowrap;

    font-size:12px;
}


.sidebar-user span {

    display:block;

    margin-top:3px;

    color:#7f93a9;

    font-size:9px;
}


/* =========================================================
   SIDEBAR MENU
========================================================= */

.sidebar-menu {

    padding:
        17px
        13px
        35px;
}


.menu-title {

    padding:
        15px
        13px
        8px;

    color:#627990;

    font-size:9px;

    font-weight:800;

    letter-spacing:1.4px;
}


.menu-link {

    min-height:47px;

    padding:0 14px;

    margin-bottom:4px;

    border-radius:10px;

    display:flex;

    align-items:center;

    gap:13px;

    color:#aebdcc;

    font-size:12px;

    font-weight:600;

    transition:.2s;
}


.menu-link i {

    width:19px;

    text-align:center;

    font-size:15px;
}


.menu-link:hover {

    color:white;

    background:
        rgba(255,255,255,.06);
}


.menu-link.active {

    color:white;

    background:
        rgba(11,116,255,.18);
}


.menu-link.active i {

    color:#63b4ff;
}


.menu-count {

    margin-left:auto;

    min-width:23px;
    height:23px;

    padding:0 6px;

    border-radius:50px;

    display:grid;

    place-items:center;

    background:
        rgba(99,180,255,.15);

    color:#72bcff;

    font-size:9px;

    font-weight:800;
}


/* =========================================================
   MAIN
========================================================= */

.main {

    margin-left:265px;

    min-height:100vh;

    transition:.25s ease;
}


/* =========================================================
   TOPBAR
========================================================= */

.topbar {

    height:80px;

    padding:0 30px;

    position:sticky;

    top:0;

    z-index:950;

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:20px;

    background:
        rgba(255,255,255,.96);

    backdrop-filter:
        blur(14px);

    border-bottom:
        1px solid
        var(--border);
}


.topbar-left {

    display:flex;

    align-items:center;

    gap:13px;
}


.mobile-menu {

    display:none;

    width:42px;
    height:42px;

    border:0;

    border-radius:10px;

    background:#edf4fb;

    color:var(--navy);

    cursor:pointer;

    font-size:17px;
}


.topbar-title strong {

    display:block;

    color:var(--navy);

    font-size:13px;
}


.topbar-title span {

    display:block;

    margin-top:2px;

    color:var(--muted);

    font-size:9px;
}


.top-actions {

    display:flex;

    align-items:center;

    gap:10px;
}


.explore-button {

    min-height:42px;

    padding:0 15px;

    border-radius:10px;

    display:flex;

    align-items:center;

    gap:8px;

    background:var(--primary);

    color:white;

    font-size:11px;

    font-weight:700;

    box-shadow:
        0 8px 20px
        rgba(11,116,255,.18);
}


.explore-button:hover {

    background:
        var(--primary-dark);
}


.top-icon {

    width:42px;
    height:42px;

    border:
        1px solid
        var(--border);

    border-radius:10px;

    display:grid;

    place-items:center;

    background:white;

    color:#536174;
}


.top-avatar {

    width:42px;
    height:42px;

    border-radius:50%;

    display:grid;

    place-items:center;

    background:#e8f3ff;

    color:var(--primary);

    font-family:
        'Manrope',
        sans-serif;

    font-weight:800;
}


/* =========================================================
   CONTENT
========================================================= */

.content {

    padding:30px;
}


/* =========================================================
   HERO
========================================================= */

.hero {

    min-height:330px;

    padding:42px;

    margin-bottom:24px;

    border-radius:22px;

    position:relative;

    overflow:hidden;

    display:flex;

    align-items:center;

    background:

        linear-gradient(
            90deg,
            rgba(3,20,38,.94) 0%,
            rgba(4,35,64,.83) 47%,
            rgba(4,35,64,.28) 100%
        ),

        url(
            'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1800&q=88'
        )
        center/cover
        no-repeat;

    box-shadow:
        0 18px 50px
        rgba(7,25,45,.12);
}


.hero-content {

    position:relative;

    z-index:2;

    max-width:620px;

    color:white;
}


.hero-kicker {

    display:inline-flex;

    align-items:center;

    gap:7px;

    padding:7px 11px;

    border:
        1px solid
        rgba(255,255,255,.16);

    border-radius:50px;

    background:
        rgba(255,255,255,.08);

    backdrop-filter:
        blur(8px);

    color:#d9edff;

    font-size:10px;

    font-weight:700;
}


.hero h1 {

    margin-top:18px;

    max-width:590px;

    font-family:
        'Manrope',
        sans-serif;

    font-size:
        clamp(
            34px,
            4vw,
            53px
        );

    line-height:1.06;

    letter-spacing:-1.7px;
}


.hero h1 span {

    color:#67bcff;
}


.hero p {

    max-width:520px;

    margin-top:15px;

    color:
        rgba(255,255,255,.75);

    font-size:13px;

    line-height:1.7;
}


.hero-actions {

    margin-top:25px;

    display:flex;

    flex-wrap:wrap;

    gap:10px;
}


.hero-primary,
.hero-secondary {

    min-height:47px;

    padding:0 17px;

    border-radius:10px;

    display:inline-flex;

    align-items:center;

    justify-content:center;

    gap:8px;

    font-size:11px;

    font-weight:800;

    transition:.2s;
}


.hero-primary {

    background:var(--primary);

    color:white;

    box-shadow:
        0 10px 25px
        rgba(11,116,255,.25);
}


.hero-primary:hover {

    background:#1680ff;

    transform:
        translateY(-2px);
}


.hero-secondary {

    border:
        1px solid
        rgba(255,255,255,.22);

    background:
        rgba(255,255,255,.08);

    color:white;

    backdrop-filter:
        blur(8px);
}


.hero-secondary:hover {

    background:
        rgba(255,255,255,.14);
}


/* =========================================================
   STATS
========================================================= */

.stats-grid {

    display:grid;

    grid-template-columns:
        repeat(4,1fr);

    gap:16px;

    margin-bottom:24px;
}


.stat-card {

    min-height:130px;

    padding:19px;

    border:
        1px solid
        var(--border);

    border-radius:15px;

    display:flex;

    align-items:flex-start;

    justify-content:space-between;

    gap:14px;

    background:white;

    box-shadow:
        var(--shadow);
}


.stat-label {

    color:var(--muted);

    font-size:9px;

    font-weight:800;

    letter-spacing:.6px;
}


.stat-number {

    margin-top:10px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:26px;

    font-weight:800;
}


.stat-sub {

    margin-top:4px;

    color:#8a95a4;

    font-size:9px;
}


.stat-icon {

    width:45px;
    height:45px;

    flex:0 0 45px;

    border-radius:12px;

    display:grid;

    place-items:center;

    background:#eaf4ff;

    color:var(--primary);

    font-size:17px;
}


.stat-icon.green {

    background:#eafaf3;

    color:var(--green);
}


.stat-icon.orange {

    background:#fff4e7;

    color:var(--orange);
}


.stat-icon.purple {

    background:#f2edff;

    color:var(--purple);
}


/* =========================================================
   SECTION
========================================================= */

.section-grid {

    display:grid;

    grid-template-columns:
        minmax(0,1.35fr)
        minmax(300px,.65fr);

    gap:20px;

    margin-bottom:24px;
}


.card {

    background:white;

    border:
        1px solid
        var(--border);

    border-radius:17px;

    overflow:hidden;

    box-shadow:
        var(--shadow);
}


.card-header {

    min-height:65px;

    padding:0 20px;

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:15px;

    border-bottom:
        1px solid
        var(--border);
}


.card-header h2 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:15px;
}


.card-header p {

    margin-top:3px;

    color:var(--muted);

    font-size:9px;
}


.view-all {

    color:var(--primary);

    font-size:10px;

    font-weight:800;
}


/* =========================================================
   UPCOMING TRIP
========================================================= */

.trip-card {

    padding:20px;
}


.trip-cover {

    min-height:245px;

    padding:24px;

    position:relative;

    overflow:hidden;

    border-radius:15px;

    display:flex;

    align-items:flex-end;

    background:
        linear-gradient(
            180deg,
            rgba(4,19,35,.05),
            rgba(4,19,35,.88)
        ),
        var(--trip-image)
        center/cover
        no-repeat;
}


.trip-content {

    width:100%;

    position:relative;

    z-index:2;

    color:white;
}


.trip-badge {

    display:inline-flex;

    padding:6px 9px;

    border-radius:50px;

    background:
        rgba(255,255,255,.14);

    backdrop-filter:
        blur(8px);

    font-size:9px;

    font-weight:800;
}


.trip-content h3 {

    margin-top:10px;

    font-family:
        'Manrope',
        sans-serif;

    font-size:24px;
}


.trip-meta {

    margin-top:10px;

    display:flex;

    flex-wrap:wrap;

    gap:15px;

    color:
        rgba(255,255,255,.8);

    font-size:10px;
}


.trip-meta span {

    display:flex;

    align-items:center;

    gap:6px;
}


.trip-footer {

    margin-top:18px;

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:15px;
}


.trip-countdown strong {

    display:block;

    font-family:
        'Manrope',
        sans-serif;

    font-size:22px;
}


.trip-countdown span {

    color:
        rgba(255,255,255,.65);

    font-size:9px;
}


.trip-button {

    min-height:39px;

    padding:0 13px;

    border-radius:9px;

    display:flex;

    align-items:center;

    gap:7px;

    background:white;

    color:var(--navy);

    font-size:10px;

    font-weight:800;
}


/* =========================================================
   NO TRIP
========================================================= */

.no-trip {

    padding:35px 25px;

    text-align:center;
}


.no-trip-icon {

    width:66px;
    height:66px;

    margin:0 auto 16px;

    border-radius:18px;

    display:grid;

    place-items:center;

    background:#eaf4ff;

    color:var(--primary);

    font-size:25px;
}


.no-trip h3 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:18px;
}


.no-trip p {

    max-width:390px;

    margin:8px auto 17px;

    color:var(--muted);

    font-size:11px;

    line-height:1.6;
}


.small-primary {

    min-height:41px;

    padding:0 14px;

    border-radius:9px;

    display:inline-flex;

    align-items:center;

    gap:7px;

    background:var(--primary);

    color:white;

    font-size:10px;

    font-weight:800;
}


/* =========================================================
   PAYMENT SUMMARY
========================================================= */

.payment-body {

    padding:22px;
}


.payment-circle {

    width:115px;
    height:115px;

    margin:0 auto 18px;

    border-radius:50%;

    display:grid;

    place-items:center;

    position:relative;

    background:
        conic-gradient(
            var(--primary)
            calc(var(--progress) * 1%),
            #edf1f5 0
        );
}


.payment-circle::before {

    content:'';

    position:absolute;

    width:87px;
    height:87px;

    border-radius:50%;

    background:white;
}


.payment-circle-inner {

    position:relative;

    z-index:2;

    text-align:center;
}


.payment-circle strong {

    display:block;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:22px;
}


.payment-circle span {

    color:var(--muted);

    font-size:8px;
}


.payment-row {

    padding:11px 0;

    display:flex;

    justify-content:space-between;

    gap:15px;

    border-bottom:
        1px solid
        #eef1f4;

    font-size:10px;
}


.payment-row:last-child {

    border-bottom:0;
}


.payment-row span {

    color:var(--muted);
}


.payment-row strong {

    color:var(--navy);
}


/* =========================================================
   RECOMMENDED PACKAGES
========================================================= */

.packages-section {

    margin-bottom:24px;
}


.section-heading {

    margin-bottom:16px;

    display:flex;

    align-items:flex-end;

    justify-content:space-between;

    gap:20px;
}


.section-heading h2 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:21px;

    letter-spacing:-.4px;
}


.section-heading p {

    margin-top:4px;

    color:var(--muted);

    font-size:10px;
}


.packages-grid {

    display:grid;

    grid-template-columns:
        repeat(3,1fr);

    gap:17px;
}


.package-card {

    overflow:hidden;

    border:
        1px solid
        var(--border);

    border-radius:16px;

    background:white;

    box-shadow:
        var(--shadow);

    transition:
        .25s ease;
}


.package-card:hover {

    transform:
        translateY(-5px);

    box-shadow:
        0 18px 45px
        rgba(7,25,45,.11);
}


.package-image {

    height:190px;

    position:relative;

    overflow:hidden;

    background:#e9eef4;
}


.package-image img {

    width:100%;
    height:100%;

    object-fit:cover;

    transition:
        transform .45s ease;
}


.package-card:hover
.package-image img {

    transform:
        scale(1.06);
}


.package-badges {

    position:absolute;

    top:12px;
    left:12px;

    display:flex;

    flex-wrap:wrap;

    gap:6px;
}


.package-badge {

    padding:5px 8px;

    border-radius:50px;

    background:
        rgba(7,25,45,.78);

    backdrop-filter:
        blur(8px);

    color:white;

    font-size:8px;

    font-weight:800;

    text-transform:uppercase;
}


.package-badge.hot {

    background:
        rgba(231,75,89,.9);
}


.wishlist-heart {

    position:absolute;

    top:11px;
    right:11px;

    width:34px;
    height:34px;

    border-radius:50%;

    display:grid;

    place-items:center;

    background:
        rgba(255,255,255,.92);

    color:#687588;

    box-shadow:
        0 5px 15px
        rgba(0,0,0,.08);
}


.wishlist-heart.active {

    color:#e54759;
}


.package-body {

    padding:17px;
}


.package-type {

    color:var(--primary);

    font-size:8px;

    font-weight:800;

    text-transform:uppercase;

    letter-spacing:.7px;
}


.package-body h3 {

    margin-top:6px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:16px;

    line-height:1.35;
}


.package-description {

    height:33px;

    margin-top:7px;

    overflow:hidden;

    color:var(--muted);

    font-size:9px;

    line-height:1.7;
}


.package-meta {

    margin-top:13px;

    padding-top:12px;

    border-top:
        1px solid
        #edf0f3;

    display:flex;

    align-items:center;

    gap:13px;

    color:#738094;

    font-size:9px;
}


.package-meta span {

    display:flex;

    align-items:center;

    gap:5px;
}


.package-bottom {

    margin-top:15px;

    display:flex;

    align-items:flex-end;

    justify-content:space-between;

    gap:12px;
}


.price-label {

    color:#8b96a5;

    font-size:8px;
}


.regular-price {

    color:#9ba5b3;

    font-size:9px;

    text-decoration:line-through;
}


.sale-price {

    margin-top:2px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:18px;

    font-weight:800;
}


.package-button {

    min-height:38px;

    padding:0 12px;

    border-radius:9px;

    display:flex;

    align-items:center;

    gap:6px;

    background:var(--primary);

    color:white;

    font-size:9px;

    font-weight:800;
}


/* =========================================================
   RECENT BOOKINGS
========================================================= */

.table-wrap {

    overflow-x:auto;
}


table {

    width:100%;

    min-width:720px;

    border-collapse:collapse;
}


thead {

    background:#fafbfc;
}


th {

    padding:12px 18px;

    text-align:left;

    color:#8b96a6;

    font-size:8px;

    font-weight:800;

    letter-spacing:.6px;

    text-transform:uppercase;
}


td {

    padding:14px 18px;

    border-top:
        1px solid
        #f0f2f5;

    font-size:10px;
}


.booking-name {

    color:var(--navy);

    font-weight:700;
}


.booking-number {

    margin-top:3px;

    color:var(--muted);

    font-size:8px;
}


.status {

    display:inline-flex;

    padding:5px 8px;

    border-radius:50px;

    font-size:8px;

    font-weight:800;
}


.status-pending,
.status-unpaid {

    background:#fff3e5;

    color:#b96b12;
}


.status-confirmed,
.status-paid,
.status-completed {

    background:#e9faf2;

    color:#078652;
}


.status-partial {

    background:#eaf4ff;

    color:#086ed9;
}


.status-cancelled,
.status-refunded {

    background:#fff0f2;

    color:#c83347;
}


/* =========================================================
   QUICK ACTIONS
========================================================= */

.quick-grid {

    padding:18px;

    display:grid;

    grid-template-columns:
        repeat(2,1fr);

    gap:11px;
}


.quick-item {

    min-height:105px;

    padding:14px;

    border:
        1px solid
        var(--border);

    border-radius:12px;

    transition:.2s;
}


.quick-item:hover {

    border-color:#b9d9ff;

    background:#f8fbff;

    transform:
        translateY(-2px);
}


.quick-icon {

    width:36px;
    height:36px;

    margin-bottom:10px;

    border-radius:9px;

    display:grid;

    place-items:center;

    background:#eaf4ff;

    color:var(--primary);
}


.quick-item strong {

    display:block;

    color:var(--navy);

    font-size:10px;
}


.quick-item span {

    display:block;

    margin-top:3px;

    color:var(--muted);

    font-size:8px;

    line-height:1.5;
}


/* =========================================================
   CTA
========================================================= */

.cta {

    min-height:190px;

    padding:30px;

    margin-bottom:10px;

    border-radius:18px;

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:30px;

    overflow:hidden;

    position:relative;

    background:
        linear-gradient(
            115deg,
            #07192d,
            #0a3b68
        );

    color:white;
}


.cta::after {

    content:'';

    position:absolute;

    width:300px;
    height:300px;

    right:-90px;
    top:-130px;

    border-radius:50%;

    background:
        rgba(11,116,255,.18);
}


.cta-content {

    position:relative;

    z-index:2;
}


.cta h2 {

    font-family:
        'Manrope',
        sans-serif;

    font-size:25px;
}


.cta p {

    max-width:560px;

    margin-top:7px;

    color:
        rgba(255,255,255,.66);

    font-size:10px;

    line-height:1.7;
}


.cta-button {

    min-height:45px;

    padding:0 16px;

    position:relative;

    z-index:2;

    border-radius:10px;

    display:flex;

    align-items:center;

    gap:8px;

    background:white;

    color:var(--navy);

    font-size:10px;

    font-weight:800;

    white-space:nowrap;
}


/* =========================================================
   OVERLAY
========================================================= */

.sidebar-overlay {

    display:none;

    position:fixed;

    inset:0;

    z-index:1150;

    background:
        rgba(2,10,18,.55);
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:1200px) {

    .stats-grid {

        grid-template-columns:
            repeat(2,1fr);
    }


    .packages-grid {

        grid-template-columns:
            repeat(2,1fr);
    }


    .section-grid {

        grid-template-columns:1fr;
    }
}


@media(max-width:850px) {

    .sidebar {

        transform:
            translateX(-100%);
    }


    .sidebar.open {

        transform:
            translateX(0);
    }


    .sidebar-overlay.show {

        display:block;
    }


    .main {

        margin-left:0;
    }


    .mobile-menu {

        display:grid;

        place-items:center;
    }


    .content {

        padding:20px;
    }


    .hero {

        padding:32px;

        min-height:310px;
    }
}


@media(max-width:650px) {

    .topbar {

        height:70px;

        padding:0 14px;
    }


    .topbar-title {

        display:none;
    }


    .top-icon {

        display:none;
    }


    .explore-button span {

        display:none;
    }


    .content {

        padding:15px;
    }


    .hero {

        min-height:380px;

        padding:26px 22px;

        align-items:flex-end;

        background:

            linear-gradient(
                180deg,
                rgba(3,20,38,.28),
                rgba(3,20,38,.94)
            ),

            url(
                'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1000&q=85'
            )
            center/cover
            no-repeat;
    }


    .hero h1 {

        font-size:34px;
    }


    .hero-actions {

        flex-direction:column;
    }


    .hero-primary,
    .hero-secondary {

        width:100%;
    }


    .stats-grid {

        grid-template-columns:1fr;
    }


    .packages-grid {

        grid-template-columns:1fr;
    }


    .package-image {

        height:220px;
    }


    .quick-grid {

        grid-template-columns:1fr;
    }


    .cta {

        align-items:flex-start;

        flex-direction:column;
    }


    .cta-button {

        width:100%;

        justify-content:center;
    }


    .section-heading {

        align-items:flex-start;

        flex-direction:column;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>


<body>


<!-- =========================================================
     SIDEBAR OVERLAY
========================================================= -->

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>


<!-- =========================================================
     SIDEBAR
========================================================= -->

<aside
    class="sidebar"
    id="sidebar"
>


    <a
        href="<?= e(BASE_URL); ?>"
        class="sidebar-logo"
    >

        <div class="logo-icon">

            <i class="fa-solid fa-plane"></i>

        </div>

        TRAV<span>SCOPE</span>

    </a>


    <!-- CUSTOMER -->

    <div class="sidebar-user">

        <div class="sidebar-user-row">

            <div class="sidebar-avatar">

                <?= e($userInitial); ?>

            </div>


            <div>

                <strong>

                    <?= e($fullName); ?>

                </strong>

                <span>
                    TRAVSCOPE Traveller
                </span>

            </div>

        </div>

    </div>


    <!-- MENU -->

    <nav class="sidebar-menu">


        <div class="menu-title">
            MY TRAVSCOPE
        </div>


        <a
            href="dashboard.php"
            class="menu-link active"
        >

            <i class="fa-solid fa-house"></i>

            Dashboard

        </a>


        <a
            href="packages.php"
            class="menu-link"
        >

            <i class="fa-solid fa-compass"></i>

            Explore Packages

        </a>


        <a
            href="my-bookings.php"
            class="menu-link"
        >

            <i class="fa-solid fa-suitcase-rolling"></i>

            My Bookings

            <?php if ($totalBookings > 0): ?>

                <span class="menu-count">

                    <?= $totalBookings; ?>

                </span>

            <?php endif; ?>

        </a>


        <a
            href="wishlist.php"
            class="menu-link"
        >

            <i class="fa-regular fa-heart"></i>

            Wishlist

            <?php if ($wishlistCount > 0): ?>

                <span class="menu-count">

                    <?= $wishlistCount; ?>

                </span>

            <?php endif; ?>

        </a>


        <div class="menu-title">
            TRIP SUPPORT
        </div>


        <a
            href="my-enquiries.php"
            class="menu-link"
        >

            <i class="fa-regular fa-message"></i>

            My Enquiries

        </a>


        <a
            href="reviews.php"
            class="menu-link"
        >

            <i class="fa-regular fa-star"></i>

            My Reviews

        </a>


        <div class="menu-title">
            ACCOUNT
        </div>


        <a
            href="profile.php"
            class="menu-link"
        >

            <i class="fa-regular fa-user"></i>

            My Profile

        </a>


        <?php if ($serviceDashboardUrl !== ''): ?>

        <a
            href="<?= e($serviceDashboardUrl); ?>"
            class="menu-link"
        >

            <i class="fa-solid fa-briefcase"></i>

            Service

        </a>

        <?php endif; ?>


        <a
            href="logout.php"
            class="menu-link"
        >

            <i class="fa-solid fa-arrow-right-from-bracket"></i>

            Logout

        </a>


    </nav>


</aside>


<!-- =========================================================
     MAIN
========================================================= -->

<main class="main">


    <!-- TOPBAR -->

    <header class="topbar">


        <div class="topbar-left">


            <button
                type="button"
                class="mobile-menu"
                id="mobileMenu"
                aria-label="Open menu"
            >

                <i class="fa-solid fa-bars"></i>

            </button>


            <div class="topbar-title">

                <strong>
                    My Travel Dashboard
                </strong>

                <span>
                    Your journeys, all in one place.
                </span>

            </div>


        </div>


        <div class="top-actions">


            <a
                href="packages.php"
                class="explore-button"
            >

                <i class="fa-solid fa-compass"></i>

                <span>
                    Explore Trips
                </span>

            </a>


            <a
                href="wishlist.php"
                class="top-icon"
                title="Wishlist"
            >

                <i class="fa-regular fa-heart"></i>

            </a>


            <a
                href="profile.php"
                class="top-avatar"
                title="My Profile"
            >

                <?= e($userInitial); ?>

            </a>


        </div>


    </header>


    <!-- =====================================================
         CONTENT
    ====================================================== -->

    <div class="content">


        <!-- =================================================
             HERO
        ================================================== -->

        <section class="hero">


            <div class="hero-content">


                <div class="hero-kicker">

                    <i class="fa-solid fa-earth-americas"></i>

                    YOUR NEXT STORY STARTS HERE

                </div>


                <h1>

                    Welcome,
                    <?= e($firstName); ?>.

                    <span>
                        Where will you go next?
                    </span>

                </h1>


                <p>

                    From peaceful escapes to unforgettable
                    adventures, discover handpicked travel
                    experiences and turn your next holiday
                    into a story worth remembering.

                </p>


                <div class="hero-actions">


                    <a
                        href="packages.php"
                        class="hero-primary"
                    >

                        <i class="fa-solid fa-compass"></i>

                        Explore Holiday Packages

                    </a>


                    <a
                        href="my-bookings.php"
                        class="hero-secondary"
                    >

                        <i class="fa-solid fa-suitcase"></i>

                        View My Trips

                    </a>


                </div>


            </div>


        </section>


        <!-- =================================================
             STATS
        ================================================== -->

        <section class="stats-grid">


            <div class="stat-card">

                <div>

                    <div class="stat-label">
                        MY BOOKINGS
                    </div>

                    <div class="stat-number">

                        <?= number_format($totalBookings); ?>

                    </div>

                    <div class="stat-sub">

                        <?= $confirmedBookings; ?>
                        confirmed trip(s)

                    </div>

                </div>


                <div class="stat-icon">

                    <i class="fa-solid fa-suitcase-rolling"></i>

                </div>

            </div>


            <div class="stat-card">

                <div>

                    <div class="stat-label">
                        UPCOMING / PENDING
                    </div>

                    <div class="stat-number">

                        <?= number_format($pendingBookings); ?>

                    </div>

                    <div class="stat-sub">

                        Awaiting confirmation

                    </div>

                </div>


                <div class="stat-icon orange">

                    <i class="fa-regular fa-clock"></i>

                </div>

            </div>


            <div class="stat-card">

                <div>

                    <div class="stat-label">
                        COMPLETED TRIPS
                    </div>

                    <div class="stat-number">

                        <?= number_format($completedBookings); ?>

                    </div>

                    <div class="stat-sub">

                        Memories made with TRAVSCOPE

                    </div>

                </div>


                <div class="stat-icon green">

                    <i class="fa-solid fa-circle-check"></i>

                </div>

            </div>


            <div class="stat-card">

                <div>

                    <div class="stat-label">
                        MY WISHLIST
                    </div>

                    <div class="stat-number">

                        <?= number_format($wishlistCount); ?>

                    </div>

                    <div class="stat-sub">

                        Saved dream trip(s)

                    </div>

                </div>


                <div class="stat-icon purple">

                    <i class="fa-solid fa-heart"></i>

                </div>

            </div>


        </section>


        <!-- =================================================
             UPCOMING TRIP + PAYMENT
        ================================================== -->

        <div class="section-grid">


            <!-- UPCOMING TRIP -->

            <section class="card">


                <div class="card-header">

                    <div>

                        <h2>
                            Your Next Adventure
                        </h2>

                        <p>
                            Everything you need for your upcoming journey.
                        </p>

                    </div>


                    <a
                        href="my-bookings.php"
                        class="view-all"
                    >

                        All Trips
                        <i class="fa-solid fa-arrow-right"></i>

                    </a>

                </div>


                <?php if ($upcomingTrip): ?>


                    <div class="trip-card">


                        <div
                            class="trip-cover"
                            style="
                                --trip-image:
                                url('<?= e(
                                    dashboardPackageImage(
                                        $upcomingTrip['main_image']
                                    )
                                ); ?>');
                            "
                        >


                            <div class="trip-content">


                                <span class="trip-badge">

                                    <?= e(
                                        ucfirst(
                                            $upcomingTrip['booking_status']
                                        )
                                    ); ?>

                                    Booking

                                </span>


                                <h3>

                                    <?= e(
                                        $upcomingTrip['package_title']
                                        ?: 'Your Custom Journey'
                                    ); ?>

                                </h3>


                                <div class="trip-meta">


                                    <span>

                                        <i class="fa-regular fa-calendar"></i>

                                        <?= date(
                                            'd M Y',
                                            strtotime(
                                                $upcomingTrip['travel_date']
                                            )
                                        ); ?>

                                    </span>


                                    <?php if (
                                        !empty(
                                            $upcomingTrip['duration_days']
                                        )
                                    ): ?>

                                        <span>

                                            <i class="fa-regular fa-clock"></i>

                                            <?= (int)$upcomingTrip['duration_days']; ?>
                                            Days

                                            /

                                            <?= (int)$upcomingTrip['duration_nights']; ?>
                                            Nights

                                        </span>

                                    <?php endif; ?>


                                    <span>

                                        <i class="fa-solid fa-user-group"></i>

                                        <?= (int)$upcomingTrip['adults']; ?>
                                        Adult(s)

                                        <?php if (
                                            (int)$upcomingTrip['children'] > 0
                                        ): ?>

                                            +
                                            <?= (int)$upcomingTrip['children']; ?>
                                            Child

                                        <?php endif; ?>

                                    </span>


                                </div>


                                <div class="trip-footer">


                                    <div class="trip-countdown">

                                        <?php if (
                                            $daysToTrip !== null
                                        ): ?>

                                            <strong>

                                                <?= $daysToTrip; ?>

                                            </strong>

                                            <span>
                                                days until your journey
                                            </span>

                                        <?php endif; ?>

                                    </div>


                                    <a
                                        href="booking-details.php?id=<?= (int)$upcomingTrip['id']; ?>"
                                        class="trip-button"
                                    >

                                        View Booking

                                        <i class="fa-solid fa-arrow-right"></i>

                                    </a>


                                </div>


                            </div>


                        </div>


                    </div>


                <?php else: ?>


                    <div class="no-trip">


                        <div class="no-trip-icon">

                            <i class="fa-solid fa-plane-departure"></i>

                        </div>


                        <h3>
                            Your next adventure is waiting
                        </h3>


                        <p>

                            You don't have an upcoming trip yet.
                            Explore our handpicked holiday experiences
                            and find the destination that feels right
                            for you.

                        </p>


                        <a
                            href="packages.php"
                            class="small-primary"
                        >

                            <i class="fa-solid fa-compass"></i>

                            Find My Next Trip

                        </a>


                    </div>


                <?php endif; ?>


            </section>


            <!-- PAYMENT SUMMARY -->

            <section class="card">


                <div class="card-header">

                    <div>

                        <h2>
                            Travel Payments
                        </h2>

                        <p>
                            Your booking payment summary.
                        </p>

                    </div>

                </div>


                <div class="payment-body">


                    <div
                        class="payment-circle"
                        style="
                            --progress:
                            <?= round($paymentProgress, 2); ?>;
                        "
                    >

                        <div class="payment-circle-inner">

                            <strong>

                                <?= round($paymentProgress); ?>%

                            </strong>

                            <span>
                                PAID
                            </span>

                        </div>

                    </div>


                    <div class="payment-row">

                        <span>
                            Booking Value
                        </span>

                        <strong>

                            <?= e($currencySymbol); ?>
                            <?= number_format(
                                $totalBookingValue,
                                0
                            ); ?>

                        </strong>

                    </div>


                    <div class="payment-row">

                        <span>
                            Amount Paid
                        </span>

                        <strong>

                            <?= e($currencySymbol); ?>
                            <?= number_format(
                                $totalPaid,
                                0
                            ); ?>

                        </strong>

                    </div>


                    <div class="payment-row">

                        <span>
                            Amount Due
                        </span>

                        <strong>

                            <?= e($currencySymbol); ?>
                            <?= number_format(
                                $amountDue,
                                0
                            ); ?>

                        </strong>

                    </div>


                </div>


            </section>


        </div>


        <!-- =================================================
             RECOMMENDED PACKAGES
        ================================================== -->

        <section class="packages-section">


            <div class="section-heading">


                <div>

                    <h2>
                        Handpicked for your next escape
                    </h2>

                    <p>

                        Explore experiences selected from
                        TRAVSCOPE's latest travel collection.

                    </p>

                </div>


                <a
                    href="packages.php"
                    class="view-all"
                >

                    Explore All Packages

                    <i class="fa-solid fa-arrow-right"></i>

                </a>


            </div>


            <?php if ($recommendedPackages): ?>


                <div class="packages-grid">


                    <?php foreach (
                        $recommendedPackages
                        as $package
                    ): ?>


                        <?php

                        $isWishlisted =
                            in_array(
                                (int)$package['id'],
                                $wishlistPackageIds,
                                true
                            );

                        ?>


                        <article class="package-card">


                            <div class="package-image">


                                <img
                                    src="<?= e(
                                        dashboardPackageImage(
                                            $package['main_image']
                                        )
                                    ); ?>"
                                    alt="<?= e($package['title']); ?>"
                                    loading="lazy"
                                >


                                <div class="package-badges">


                                    <?php if (
                                        (int)$package['bestseller'] === 1
                                    ): ?>

                                        <span class="package-badge hot">

                                            <i class="fa-solid fa-fire"></i>

                                            Bestseller

                                        </span>

                                    <?php elseif (
                                        (int)$package['featured'] === 1
                                    ): ?>

                                        <span class="package-badge">

                                            Featured

                                        </span>

                                    <?php endif; ?>


                                </div>


                                <a
                                    href="wishlist.php?package_id=<?= (int)$package['id']; ?>"
                                    class="wishlist-heart <?= $isWishlisted ? 'active' : ''; ?>"
                                    title="Wishlist"
                                >

                                    <i class="<?= $isWishlisted ? 'fa-solid' : 'fa-regular'; ?> fa-heart"></i>

                                </a>


                            </div>


                            <div class="package-body">


                                <div class="package-type">

                                    <?= e(
                                        ucfirst(
                                            $package['package_type']
                                        )
                                    ); ?>

                                    Experience

                                </div>


                                <h3>

                                    <?= e($package['title']); ?>

                                </h3>


                                <div class="package-description">

                                    <?= e(
                                        $package['short_description']
                                        ?: 'An unforgettable journey designed for travellers who want to experience more.'
                                    ); ?>

                                </div>


                                <div class="package-meta">


                                    <span>

                                        <i class="fa-regular fa-clock"></i>

                                        <?= (int)$package['duration_days']; ?>D

                                        /

                                        <?= (int)$package['duration_nights']; ?>N

                                    </span>


                                    <span>

                                        <i class="fa-regular fa-eye"></i>

                                        <?= number_format(
                                            (int)$package['views']
                                        ); ?>

                                        views

                                    </span>


                                </div>


                                <div class="package-bottom">


                                    <div>


                                        <div class="price-label">

                                            Starting from

                                        </div>


                                        <?php if (
                                            !empty($package['regular_price'])
                                            &&
                                            (float)$package['regular_price']
                                                >
                                            (float)$package['sale_price']
                                        ): ?>

                                            <div class="regular-price">

                                                <?= e($currencySymbol); ?>
                                                <?= number_format(
                                                    (float)$package['regular_price'],
                                                    0
                                                ); ?>

                                            </div>

                                        <?php endif; ?>


                                        <div class="sale-price">

                                            <?= e($currencySymbol); ?>
                                            <?= number_format(
                                                (float)$package['sale_price'],
                                                0
                                            ); ?>

                                        </div>


                                    </div>


                                    <a
                                        href="package-details.php?slug=<?= urlencode(
                                            $package['slug']
                                        ); ?>"
                                        class="package-button"
                                    >

                                        View Trip

                                        <i class="fa-solid fa-arrow-right"></i>

                                    </a>


                                </div>


                            </div>


                        </article>


                    <?php endforeach; ?>


                </div>


            <?php else: ?>


                <div class="card">

                    <div class="no-trip">

                        <div class="no-trip-icon">

                            <i class="fa-solid fa-earth-americas"></i>

                        </div>

                        <h3>
                            New adventures are coming
                        </h3>

                        <p>

                            We're preparing more travel experiences.
                            Check back soon for new destinations and
                            holiday packages.

                        </p>

                    </div>

                </div>


            <?php endif; ?>


        </section>


        <!-- =================================================
             BOOKINGS + QUICK ACTIONS
        ================================================== -->

        <div class="section-grid">


            <!-- RECENT BOOKINGS -->

            <section class="card">


                <div class="card-header">

                    <div>

                        <h2>
                            Recent Bookings
                        </h2>

                        <p>
                            Track your latest travel reservations.
                        </p>

                    </div>


                    <a
                        href="my-bookings.php"
                        class="view-all"
                    >

                        View All

                    </a>

                </div>


                <div class="table-wrap">


                    <table>


                        <thead>

                        <tr>

                            <th>Trip</th>

                            <th>Travel Date</th>

                            <th>Amount</th>

                            <th>Booking</th>

                            <th>Payment</th>

                        </tr>

                        </thead>


                        <tbody>


                        <?php if (!$recentBookings): ?>


                            <tr>

                                <td colspan="5">

                                    You haven't booked a trip yet.

                                    <a
                                        href="packages.php"
                                        style="
                                            color:#0b74ff;
                                            font-weight:700;
                                        "
                                    >
                                        Explore packages
                                    </a>

                                </td>

                            </tr>


                        <?php else: ?>


                            <?php foreach (
                                $recentBookings
                                as $booking
                            ): ?>


                                <tr>


                                    <td>

                                        <a
                                            href="booking-details.php?id=<?= (int)$booking['id']; ?>"
                                        >

                                            <div class="booking-name">

                                                <?= e(
                                                    $booking['package_title']
                                                    ?: 'Custom Trip'
                                                ); ?>

                                            </div>

                                            <div class="booking-number">

                                                <?= e(
                                                    $booking['booking_number']
                                                ); ?>

                                            </div>

                                        </a>

                                    </td>


                                    <td>

                                        <?php if (
                                            $booking['travel_date']
                                        ): ?>

                                            <?= date(
                                                'd M Y',
                                                strtotime(
                                                    $booking['travel_date']
                                                )
                                            ); ?>

                                        <?php else: ?>

                                            To be confirmed

                                        <?php endif; ?>

                                    </td>


                                    <td>

                                        <strong>

                                            <?= e($currencySymbol); ?>

                                            <?= number_format(
                                                (float)$booking['total_amount'],
                                                0
                                            ); ?>

                                        </strong>

                                    </td>


                                    <td>

                                        <span
                                            class="status status-<?= e(
                                                $booking['booking_status']
                                            ); ?>"
                                        >

                                            <?= e(
                                                ucfirst(
                                                    $booking['booking_status']
                                                )
                                            ); ?>

                                        </span>

                                    </td>


                                    <td>

                                        <span
                                            class="status status-<?= e(
                                                $booking['payment_status']
                                            ); ?>"
                                        >

                                            <?= e(
                                                ucfirst(
                                                    $booking['payment_status']
                                                )
                                            ); ?>

                                        </span>

                                    </td>


                                </tr>


                            <?php endforeach; ?>


                        <?php endif; ?>


                        </tbody>


                    </table>


                </div>


            </section>


            <!-- QUICK ACTIONS -->

            <section class="card">


                <div class="card-header">

                    <div>

                        <h2>
                            Quick Actions
                        </h2>

                        <p>
                            Everything for your journey.
                        </p>

                    </div>

                </div>


                <div class="quick-grid">


                    <a
                        href="packages.php"
                        class="quick-item"
                    >

                        <div class="quick-icon">

                            <i class="fa-solid fa-compass"></i>

                        </div>

                        <strong>
                            Explore Trips
                        </strong>

                        <span>
                            Discover your next holiday.
                        </span>

                    </a>


                    <a
                        href="my-bookings.php"
                        class="quick-item"
                    >

                        <div class="quick-icon">

                            <i class="fa-solid fa-suitcase"></i>

                        </div>

                        <strong>
                            My Bookings
                        </strong>

                        <span>
                            Manage your travel plans.
                        </span>

                    </a>


                    <a
                        href="wishlist.php"
                        class="quick-item"
                    >

                        <div class="quick-icon">

                            <i class="fa-regular fa-heart"></i>

                        </div>

                        <strong>
                            Wishlist
                        </strong>

                        <span>
                            Revisit your dream escapes.
                        </span>

                    </a>


                    <a
                        href="profile.php"
                        class="quick-item"
                    >

                        <div class="quick-icon">

                            <i class="fa-regular fa-user"></i>

                        </div>

                        <strong>
                            My Profile
                        </strong>

                        <span>
                            Keep your travel details updated.
                        </span>

                    </a>


                </div>


            </section>


        </div>


        <!-- =================================================
             FINAL CTA
        ================================================== -->

        <section class="cta">


            <div class="cta-content">


                <h2>
                    The world is waiting for you.
                </h2>


                <p>

                    Whether you're dreaming of beaches,
                    mountains, culture or adventure,
                    TRAVSCOPE helps you find a journey
                    you'll remember long after you return home.

                </p>


            </div>


            <a
                href="packages.php"
                class="cta-button"
            >

                Start Exploring

                <i class="fa-solid fa-arrow-right"></i>

            </a>


        </section>


    </div>


</main>


<script>

/*
|--------------------------------------------------------------------------
| MOBILE SIDEBAR
|--------------------------------------------------------------------------
*/

const sidebar =
    document.getElementById('sidebar');

const mobileMenu =
    document.getElementById('mobileMenu');

const sidebarOverlay =
    document.getElementById('sidebarOverlay');


function openSidebar() {

    if (!sidebar || !sidebarOverlay) {
        return;
    }

    sidebar.classList.add('open');

    sidebarOverlay.classList.add('show');

    document.body.style.overflow =
        'hidden';
}


function closeSidebar() {

    if (!sidebar || !sidebarOverlay) {
        return;
    }

    sidebar.classList.remove('open');

    sidebarOverlay.classList.remove('show');

    document.body.style.overflow =
        '';
}


if (mobileMenu) {

    mobileMenu.addEventListener(
        'click',
        function () {

            if (
                sidebar.classList.contains('open')
            ) {

                closeSidebar();

            } else {

                openSidebar();
            }
        }
    );
}


if (sidebarOverlay) {

    sidebarOverlay.addEventListener(
        'click',
        closeSidebar
    );
}


window.addEventListener(
    'resize',
    function () {

        if (window.innerWidth > 850) {

            closeSidebar();
        }
    }
);

</script>



<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>