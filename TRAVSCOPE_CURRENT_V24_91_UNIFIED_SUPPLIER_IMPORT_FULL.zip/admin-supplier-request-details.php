<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
require_once __DIR__.'/supplier-functions.php';
$commercialWorkflowFile=__DIR__.'/commercial-workflow-functions.php';
if(is_file($commercialWorkflowFile))require_once $commercialWorkflowFile;
$accessControlFunctionsFile=__DIR__.'/access-control-functions.php';
if(is_file($accessControlFunctionsFile))require_once $accessControlFunctionsFile;
if(empty($_SESSION['admin_id'])){header('Location: '.BASE_URL.'login.php');exit;}
$adminId=(int)$_SESSION['admin_id'];
$id=max(0,(int)($_GET['id']??$_POST['request_id']??0));
$stmt=$pdo->prepare("
SELECT r.*,s.company_name,s.priority,c.contact_name,c.email contact_email,c.whatsapp contact_whatsapp,c.mobile contact_mobile,
       e.name customer_name,e.destination,e.travel_date,e.adults,e.children,
       tsr.service_type linked_service_type,tsr.title linked_service_title,tsr.status linked_service_status,
       tsr.specifications linked_service_specifications,t.trip_code
FROM supplier_requests r
JOIN suppliers s ON s.id=r.supplier_id
JOIN enquiries e ON e.id=r.enquiry_id
LEFT JOIN supplier_contacts c ON c.id=r.supplier_contact_id
LEFT JOIN trip_service_requirements tsr ON tsr.id=r.service_requirement_id
LEFT JOIN trips t ON t.id=r.trip_id
WHERE r.id=? LIMIT 1");
$stmt->execute([$id]);$request=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$request){http_response_code(404);exit('Supplier request not found.');}

if(function_exists('tsAclRequire')){
    try{
        tsAclRequire($pdo,$adminId,'view_supplier_cost','view_supplier_request_cost','supplier_request',$id);
    }catch(RuntimeException $e){
        http_response_code(403);
        exit(htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8'));
    }
}

if(empty($_SESSION['supplier_request_detail_csrf']))$_SESSION['supplier_request_detail_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['supplier_request_detail_csrf'];
$success=(string)($_SESSION['supplier_request_detail_success']??'');$error=(string)($_SESSION['supplier_request_detail_error']??'');
unset($_SESSION['supplier_request_detail_success'],$_SESSION['supplier_request_detail_error']);

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        if(!hash_equals($csrf,(string)($_POST['csrf']??'')))throw new RuntimeException('Security verification failed.');
        $action=(string)($_POST['action']??'');
        if($action==='record_quote'){
            if(function_exists('tsAclRequire'))tsAclRequire($pdo,$adminId,'manage_supplier_procurement','record_supplier_quote','supplier_request',$id);
            $channel=(string)($_POST['response_channel']??'manual');
            if(!in_array($channel,['email','whatsapp','phone','manual'],true))$channel='manual';

            $currency=strtoupper(trim((string)($_POST['currency']??'INR')))?:'INR';
            $mode=tsSupplierQuoteMode(
                (string)($_POST['costing_mode']??(
                    (string)($request['request_type']??'')==='service_quote'
                        ? 'service_wise'
                        : 'complete_package'
                ))
            );

            $packageBase=max(
                0,
                (float)(
                    $_POST['package_base_amount']
                    ?? $_POST['net_amount']
                    ?? 0
                )
            );
            $supplierTax=max(0,(float)($_POST['tax_amount']??0));
            $otherCharges=max(0,(float)($_POST['upgrade_amount']??0));

            $costing=tsSupplierQuoteBuildCosting(
                $mode,
                $packageBase,
                $supplierTax,
                $otherCharges,
                (array)($_POST['item_type']??[]),
                (array)($_POST['item_description']??[]),
                (array)($_POST['item_cost']??[])
            );

            $net=(float)$costing['net_amount'];
            $upgrade=(float)$costing['upgrade_amount'];
            $tax=(float)$costing['tax_amount'];
            $total=(float)$costing['total_supplier_cost'];

            $stmt=$pdo->prepare("SELECT COALESCE(MAX(version_number),0)+1 FROM supplier_quotes WHERE supplier_request_id=?");
            $stmt->execute([$id]);$version=(int)$stmt->fetchColumn();

            $upload=tsSupplierUploadQuote($_FILES['attachment']??[]);
            $pdo->beginTransaction();

            if($version>1){
                $pdo->prepare("UPDATE supplier_quotes SET status='superseded' WHERE supplier_request_id=? AND status='received'")
                    ->execute([$id]);
            }

            if(tsSupplierQuoteModeColumnExists($pdo)){
                $stmt=$pdo->prepare("
                    INSERT INTO supplier_quotes
                    (supplier_request_id,version_number,response_channel,costing_mode,currency,net_amount,upgrade_amount,tax_amount,total_supplier_cost,
                     hotel_summary,transport_summary,inclusions,exclusions,payment_terms,cancellation_terms,validity_until,response_notes,
                     attachment_path,original_filename,status,received_at,created_by_admin_id)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'received',NOW(),?)
                ");
                $stmt->execute([
                    $id,$version,$channel,$mode,$currency,$net,$upgrade,$tax,$total,
                    trim((string)($_POST['hotel_summary']??''))?:null,
                    trim((string)($_POST['transport_summary']??''))?:null,
                    trim((string)($_POST['inclusions']??''))?:null,
                    trim((string)($_POST['exclusions']??''))?:null,
                    trim((string)($_POST['payment_terms']??''))?:null,
                    trim((string)($_POST['cancellation_terms']??''))?:null,
                    trim((string)($_POST['validity_until']??''))?:null,
                    trim((string)($_POST['response_notes']??''))?:null,
                    $upload['path'],$upload['name'],$adminId
                ]);
            }else{
                $stmt=$pdo->prepare("
                    INSERT INTO supplier_quotes
                    (supplier_request_id,version_number,response_channel,currency,net_amount,upgrade_amount,tax_amount,total_supplier_cost,
                     hotel_summary,transport_summary,inclusions,exclusions,payment_terms,cancellation_terms,validity_until,response_notes,
                     attachment_path,original_filename,status,received_at,created_by_admin_id)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'received',NOW(),?)
                ");
                $stmt->execute([
                    $id,$version,$channel,$currency,$net,$upgrade,$tax,$total,
                    trim((string)($_POST['hotel_summary']??''))?:null,
                    trim((string)($_POST['transport_summary']??''))?:null,
                    trim((string)($_POST['inclusions']??''))?:null,
                    trim((string)($_POST['exclusions']??''))?:null,
                    trim((string)($_POST['payment_terms']??''))?:null,
                    trim((string)($_POST['cancellation_terms']??''))?:null,
                    trim((string)($_POST['validity_until']??''))?:null,
                    trim((string)($_POST['response_notes']??''))?:null,
                    $upload['path'],$upload['name'],$adminId
                ]);
            }

            $quoteId=(int)$pdo->lastInsertId();
            $ins=$pdo->prepare("
                INSERT INTO supplier_quote_items
                (supplier_quote_id,item_type,description,quantity,unit_cost,line_cost,is_upgrade,sort_order)
                VALUES (?,?,?,1,?,?,?,?)
            ");

            foreach($costing['items'] as $i=>$item){
                $cost=(float)$item['cost'];
                $ins->execute([
                    $quoteId,
                    (string)$item['item_type'],
                    (string)$item['description'],
                    $cost,
                    $cost,
                    (int)$item['is_upgrade'],
                    $i+1
                ]);
            }

            $pdo->prepare("
                UPDATE supplier_requests
                SET status='response_received',
                    first_response_at=COALESCE(first_response_at,NOW()),
                    last_response_at=NOW(),
                    updated_by_admin_id=?
                WHERE id=?
            ")->execute([$adminId,$id]);

            tsSupplierEvent(
                $pdo,
                $id,
                'response_received',
                $adminId,
                'Supplier quotation V'.$version.' recorded via '.ucfirst($channel).' · '.tsSupplierQuoteModeLabel($mode).'.',
                $channel
            );

            if(!empty($request['service_requirement_id'])){
                $pdo->prepare("UPDATE trip_service_requirements SET status='quoted',updated_at=NOW() WHERE id=?")
                    ->execute([(int)$request['service_requirement_id']]);
            }
            $pdo->commit();
            $_SESSION['supplier_request_detail_success']='Supplier quotation V'.$version.' recorded.';
        }

        if($action==='select_quote'){
            $quoteId=max(0,(int)($_POST['quote_id']??0));
            if(function_exists('tsAclRequire'))tsAclRequire($pdo,$adminId,'select_supplier','select_supplier_quote','supplier_quote',$quoteId,['supplier_request_id'=>$id]);
            $stmt=$pdo->prepare("SELECT id FROM supplier_quotes WHERE id=? AND supplier_request_id=?");$stmt->execute([$quoteId,$id]);
            if(!$stmt->fetchColumn())throw new RuntimeException('Invalid supplier quote.');
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE supplier_quotes SET status=CASE WHEN id=? THEN 'selected' WHEN status='selected' THEN 'received' ELSE status END WHERE supplier_request_id=?")->execute([$quoteId,$id]);
            $pdo->prepare("UPDATE supplier_requests SET selected_quote_id=?,status='selected',updated_by_admin_id=? WHERE id=?")->execute([$quoteId,$adminId,$id]);
            tsSupplierEvent($pdo,$id,'quote_selected',$adminId,'Supplier quotation selected internally.');
            if(!empty($request['service_requirement_id'])){
                $pdo->prepare("UPDATE trip_service_requirements SET status='selected',updated_at=NOW() WHERE id=?")
                    ->execute([(int)$request['service_requirement_id']]);
            }
            $pdo->commit();
            if(function_exists('tsCWMarkSupplierCostChanged') && !empty($request['trip_id'])){
                tsCWMarkSupplierCostChanged(
                    $pdo,
                    (int)$request['trip_id'],
                    (int)$request['enquiry_id'],
                    'Supplier quote ' . $quoteId . ' selected for ' . (string)$request['request_code'] . '. Refresh Trip Cost Sheet / prepare a new customer quotation if pricing changed.',
                    $id,
                    ['supplier_quote_id'=>$quoteId,'supplier_id'=>(int)$request['supplier_id']]
                );
            }
            $_SESSION['supplier_request_detail_success']='Supplier quote selected internally. Commercial status updated; this is NOT supplier booking confirmation.';
        }

        if($action==='record_reply'){
            if(function_exists('tsAclRequire'))tsAclRequire($pdo,$adminId,'manage_supplier_procurement','record_supplier_reply','supplier_request',$id);
            $channel=(string)($_POST['reply_channel']??'email');
            if(!in_array($channel,['email','whatsapp','phone','manual'],true))$channel='manual';
            $reply=trim((string)($_POST['reply_message']??''));
            if($reply==='')throw new RuntimeException('Enter the supplier reply/message first.');
            $pdo->prepare("UPDATE supplier_requests SET status=CASE WHEN status IN ('selected','rejected','cancelled') THEN status ELSE 'partial_response' END,first_response_at=COALESCE(first_response_at,NOW()),last_response_at=NOW(),updated_by_admin_id=? WHERE id=?")->execute([$adminId,$id]);
            tsSupplierEvent($pdo,$id,'supplier_reply',$adminId,$reply,$channel);
            tsSupplierMessage($pdo,$id,'supplier',null,$reply,$channel);
            $_SESSION['supplier_request_detail_success']='Supplier reply recorded in conversation.';
        }

        if($action==='send_message'){
            if(function_exists('tsAclRequire'))tsAclRequire($pdo,$adminId,'manage_supplier_procurement','send_supplier_message','supplier_request',$id);
            $subject=trim((string)($_POST['message_subject']??''));
            $message=trim((string)($_POST['message_body']??''));
            if($subject===''||$message==='')throw new RuntimeException('Subject and message are required.');
            $supplier=['company_name'=>(string)$request['company_name']];
            $contact=['contact_name'=>(string)($request['contact_name']??''),'email'=>(string)($request['contact_email']??'')];
            $result=tsSupplierCustomEmail($supplier,$contact,$subject,$message);
            if(!$result['ok'])throw new RuntimeException($result['message']);
            tsSupplierEvent($pdo,$id,'message_sent',$adminId,$message,'email');
            tsSupplierMessage($pdo,$id,'admin',$adminId,$message,'email');
            $_SESSION['supplier_request_detail_success']='Email sent to supplier and added to conversation.';
        }

        if($action==='set_status'){
            if(function_exists('tsAclRequire'))tsAclRequire($pdo,$adminId,'manage_supplier_procurement','set_supplier_request_status','supplier_request',$id);
            $status=(string)($_POST['status']??'under_review');
            $allowed=['draft','sent','awaiting_response','reminder_sent','partial_response','response_received','under_review','selected','rejected','expired','cancelled'];
            if(!in_array($status,$allowed,true))throw new RuntimeException('Invalid status.');
            $pdo->prepare("UPDATE supplier_requests SET status=?,updated_by_admin_id=? WHERE id=?")->execute([$status,$adminId,$id]);
            tsSupplierEvent($pdo,$id,'status_changed',$adminId,'Status changed to '.str_replace('_',' ',$status).'.');
            $_SESSION['supplier_request_detail_success']='Request status updated.';
        }

        header('Location: admin-supplier-request-details.php?id='.$id);exit;
    }catch(Throwable $e){
        if($pdo->inTransaction())$pdo->rollBack();
        $_SESSION['supplier_request_detail_error']=$e->getMessage();
        header('Location: admin-supplier-request-details.php?id='.$id);exit;
    }
}

$stmt=$pdo->prepare("SELECT * FROM supplier_quotes WHERE supplier_request_id=? ORDER BY version_number DESC,id DESC");
$stmt->execute([$id]);$quotes=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
$items=[];
foreach($quotes as $q){$st=$pdo->prepare("SELECT * FROM supplier_quote_items WHERE supplier_quote_id=? ORDER BY sort_order,id");$st->execute([(int)$q['id']]);$items[(int)$q['id']]=$st->fetchAll(PDO::FETCH_ASSOC)?:[];}
$stmt=$pdo->prepare("SELECT m.*,a.name admin_name FROM supplier_request_messages m LEFT JOIN admins a ON a.id=m.admin_id WHERE m.supplier_request_id=? ORDER BY m.sent_at ASC,m.id ASC");
$stmt->execute([$id]);$messages=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
$stmt=$pdo->prepare("SELECT e.*,a.name admin_name FROM supplier_request_events e LEFT JOIN admins a ON a.id=e.admin_id WHERE e.supplier_request_id=? ORDER BY e.event_at DESC,e.id DESC");
$stmt->execute([$id]);$events=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=tsSupE((string)$request['request_code'])?> | Supplier Workspace</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}
:root{
 --navy:#0b1f36;--blue:#2563eb;--blue2:#eff6ff;--green:#059669;--green2:#ecfdf5;
 --purple:#7c3aed;--purple2:#f5f3ff;--amber:#d97706;--amber2:#fff7ed;--red:#dc2626;
 --text:#172033;--muted:#64748b;--line:#dce5ef;--soft:#f6f8fb;--white:#fff;
}
html,body{height:100%}
body{margin:0;background:#f4f7fb;color:var(--text);font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:1.45}
a{text-decoration:none;color:inherit}
button,input,select,textarea{font:inherit}
.page{max-width:1500px;margin:0 auto;padding:14px}
.alert{padding:10px 13px;border-radius:10px;margin-bottom:10px;font-weight:700}.alert.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#047857}.alert.err{background:#fff1f2;border:1px solid #fecdd3;color:#be123c}
.top{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px}
.back{display:flex;gap:7px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:34px;padding:8px 11px;border:0;border-radius:9px;font-weight:800;font-size:12px;cursor:pointer}.btn.blue{background:var(--blue);color:#fff}.btn.green{background:var(--green);color:#fff}.btn.purple{background:var(--purple);color:#fff}.btn.softblue{background:#eaf2ff;color:#1d4ed8}.btn.softpurple{background:#f3e8ff;color:#6d28d9}.btn.soft{background:#f1f5f9;color:#334155;border:1px solid #e2e8f0}.btn.warn{background:#fff7ed;color:#b45309;border:1px solid #fed7aa}
.hero{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:14px;align-items:center;background:linear-gradient(135deg,#eef6ff,#fbfdff);border:1px solid #cfe1ff;border-radius:14px;padding:13px 15px;margin-bottom:10px}
.hero-main{min-width:0}.eyebrow{font-size:9px;font-weight:900;letter-spacing:.8px;text-transform:uppercase;color:#2563eb}.hero h1{font-size:20px;margin:2px 0 2px;font-weight:900}.sub{font-size:11px;color:var(--muted)}
.status{display:inline-flex;align-items:center;gap:6px;margin-bottom:4px;padding:5px 8px;border-radius:999px;background:#e8f0ff;color:#1d4ed8;font-size:10px;font-weight:900}
.hero-meta{display:flex;gap:7px;flex-wrap:wrap;justify-content:flex-end}.meta-chip{min-width:135px;padding:8px 10px;border:1px solid #dbe5f0;border-radius:10px;background:#fff}.meta-chip span{display:block;font-size:8px;font-weight:900;text-transform:uppercase;color:#94a3b8;letter-spacing:.4px}.meta-chip strong{display:block;margin-top:2px;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px}
.workspace{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(320px,.9fr);gap:10px;height:calc(100vh - 188px);min-height:610px}
.card{background:#fff;border:1px solid var(--line);border-radius:13px;box-shadow:0 3px 12px rgba(15,23,42,.035);overflow:hidden}
.card-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 12px;border-bottom:1px solid #edf1f5}.card-head h2{margin:0;font-size:14px}.card-head .hint{font-size:9px;color:var(--muted)}
.chat-card{display:grid;grid-template-rows:auto 1fr auto;min-height:0}.chat-list{min-height:0;overflow:auto;padding:12px;background:linear-gradient(#fbfdff,#f6f9fc)}
.empty{padding:14px;text-align:center;color:var(--muted);background:#fff;border:1px dashed #cbd5e1;border-radius:10px}
.msg{max-width:84%;margin-bottom:9px;padding:9px 10px;border-radius:12px;border:1px solid #dbe4ee;background:#fff}.msg.admin{margin-left:auto;background:#eaf3ff;border-color:#bfdbfe}.msg.supplier{margin-right:auto;background:#ecfdf5;border-color:#a7f3d0}.msg.system{max-width:96%;margin:7px auto;background:#f8fafc;color:#475569}.msg-top{display:flex;justify-content:space-between;gap:10px;margin-bottom:4px;font-size:9px}.msg-top strong{font-size:10px}.msg-top span{color:#94a3b8;white-space:nowrap}.msg-body{white-space:pre-wrap;font-size:12px;line-height:1.45}.attach{margin-top:6px}.attach .btn{min-height:28px;padding:6px 8px;font-size:10px}
.composer{padding:10px 11px;border-top:1px solid #e7edf4;background:#fff}.compose-tabs{display:flex;gap:6px;margin-bottom:8px}.compose-tab{border:1px solid #dbe5ef;background:#f8fafc;color:#475569;border-radius:8px;padding:7px 9px;font-weight:800;font-size:10px;cursor:pointer}.compose-tab.active{background:#eaf2ff;color:#1d4ed8;border-color:#bfdbfe}.compose-pane{display:none}.compose-pane.active{display:block}.compose-grid{display:grid;grid-template-columns:180px 1fr auto;gap:7px;align-items:end}.compose-grid.reply{grid-template-columns:140px 1fr auto}.input,select,textarea{width:100%;border:1px solid #ccd7e4;border-radius:8px;background:#fff;padding:8px 9px;color:#1e293b}.input:focus,select:focus,textarea:focus{outline:none;border-color:#60a5fa;box-shadow:0 0 0 2px #dbeafe}.composer textarea{min-height:58px;resize:vertical}.small-label{display:block;margin-bottom:4px;font-size:9px;font-weight:900;color:#475569}
.side{display:grid;grid-template-rows:auto minmax(0,1fr);gap:10px;min-height:0}.summary-card{overflow:visible}.summary-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;padding:10px}.summary-item{padding:8px 9px;border-radius:9px;background:#f8fafc;border:1px solid #edf1f5}.summary-item span{display:block;font-size:8px;font-weight:900;color:#94a3b8;text-transform:uppercase}.summary-item strong{display:block;margin-top:2px;font-size:10px}.requirement{padding:0 10px 10px}.req-box{max-height:150px;overflow:auto;padding:9px 10px;background:#f8fafc;border:1px solid #edf1f5;border-radius:9px;white-space:pre-wrap;font-size:10px;line-height:1.45;color:#334155}.req-box .jsonhide{display:none}.req-more{margin-top:6px}.req-more summary{cursor:pointer;color:#2563eb;font-weight:800;font-size:10px}
.side-tabs-card{display:grid;grid-template-rows:auto 1fr;min-height:0}.side-tabs{display:flex;gap:5px;padding:8px;border-bottom:1px solid #edf1f5;background:#fbfdff}.side-tab{flex:1;padding:7px 5px;border:1px solid #dbe5ef;border-radius:8px;background:#fff;color:#64748b;font-weight:900;font-size:9px;cursor:pointer}.side-tab.active{background:#eef4ff;color:#1d4ed8;border-color:#bfdbfe}.side-pane{display:none;min-height:0;overflow:auto;padding:10px}.side-pane.active{display:block}
.quote-card{border:1px solid #ddd6fe;background:#faf8ff;border-radius:10px;padding:10px;margin-bottom:8px}.quote-card.selected{border:2px solid #10b981;background:#f0fdf4}.quote-top{display:flex;align-items:flex-start;justify-content:space-between;gap:8px}.quote-ver{font-size:9px;color:#7c3aed;font-weight:900}.quote-price{font-size:17px;font-weight:900;color:#111827}.quote-meta{font-size:9px;color:#64748b;margin-top:2px}.quote-actions{display:flex;gap:5px;flex-wrap:wrap;margin-top:8px}.quote-actions .btn{min-height:29px;font-size:10px;padding:6px 8px}.quote-details{margin-top:7px}.quote-details summary{font-size:9px;font-weight:800;color:#475569;cursor:pointer}.items{font-size:9px;margin:6px 0 0;padding-left:16px}
.add-quote{border:1px dashed #cbd5e1;border-radius:9px;padding:8px;background:#fff}.add-quote>summary{cursor:pointer;font-size:10px;font-weight:900;color:#475569}.quote-form{margin-top:9px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.grid .full{grid-column:1/-1}.grid textarea{min-height:60px}.cost-items{display:grid;grid-template-columns:95px 1fr 90px;gap:5px;margin-bottom:5px}.cost-items label{font-size:9px}.section-label{margin:9px 0 5px;font-size:10px;font-weight:900}.activity-row{padding:8px 9px;margin-bottom:6px;border:1px solid #e7edf3;border-radius:9px;background:#f8fafc}.activity-row .rowtop{display:flex;justify-content:space-between;gap:8px;font-size:9px}.activity-row strong{font-size:10px}.activity-row span{color:#94a3b8}.activity-row p{margin:3px 0 0;font-size:9px;color:#475569}
@media(max-width:1050px){.workspace{grid-template-columns:1fr;height:auto}.chat-card{min-height:650px}.side{grid-template-rows:auto auto}.side-tabs-card{min-height:560px}.hero{grid-template-columns:1fr}.hero-meta{justify-content:flex-start}}
@media(max-width:680px){body{font-size:12px}.page{padding:8px}.top{align-items:flex-start;flex-direction:column}.hero-meta{display:grid;grid-template-columns:1fr 1fr;width:100%}.meta-chip{min-width:0}.workspace{min-height:0}.chat-card{min-height:600px}.compose-grid,.compose-grid.reply{grid-template-columns:1fr}.summary-grid,.grid{grid-template-columns:1fr}.grid .full{grid-column:auto}.cost-items{grid-template-columns:1fr}.msg{max-width:94%}}

.cost-mode-badge{display:inline-flex;margin-top:5px;padding:4px 7px;border-radius:999px;font-size:9px;font-weight:900;border:1px solid #dbe5f0;background:#f8fafc;color:#475569}
.cost-mode-badge.complete_package{background:#eef6ff;border-color:#bfdbfe;color:#1d4ed8}
.cost-mode-badge.service_wise{background:#ecfdf5;border-color:#a7f3d0;color:#047857}
.cost-mode-badge.hybrid{background:#f5f3ff;border-color:#ddd6fe;color:#6d28d9}
.quote-cost-strip{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;margin:8px 0}
.quote-cost-strip span{padding:7px 8px;border:1px solid #e2e8f0;border-radius:9px;background:#f8fafc}
.quote-cost-strip span.total{background:#ecfdf5;border-color:#a7f3d0}
.quote-cost-strip small{display:block;font-size:7px;font-weight:900;color:#94a3b8;letter-spacing:.35px}
.quote-cost-strip strong{display:block;margin-top:2px;font-size:10px}
.costing-mode-panel{padding:9px;border:1px solid #dbeafe;border-radius:10px;background:#eff6ff;margin-bottom:9px}
.mode-help,.field-help{display:block;margin-top:4px;color:#64748b;font-size:9px;line-height:1.4}
.service-cost-block{margin-top:10px;padding-top:9px;border-top:1px dashed #cbd5e1}
.cost-formula-preview{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 10px;margin-top:9px;border-radius:10px;background:#0f172a;color:#fff}
.cost-formula-preview span{font-size:9px;font-weight:900;text-transform:uppercase;color:#93c5fd}
.cost-formula-preview strong{font-size:11px;text-align:right}
@media(max-width:700px){.quote-cost-strip{grid-template-columns:repeat(2,minmax(0,1fr))}}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head>
<body>
<div class="page">
<?php if($success):?><div class="alert ok"><i class="fa-solid fa-circle-check"></i> <?=tsSupE($success)?></div><?php endif;?>
<?php if($error):?><div class="alert err"><i class="fa-solid fa-circle-exclamation"></i> <?=tsSupE($error)?></div><?php endif;?>

<div class="top">
  <div class="back">
    <a class="btn softblue" href="admin-supplier-requests.php?lead=<?=(int)$request['enquiry_id']?>"><i class="fa-solid fa-arrow-left"></i> Supplier Sourcing</a>
    <a class="btn softpurple" href="admin-crm.php?lead=<?=(int)$request['enquiry_id']?>"><i class="fa-solid fa-briefcase"></i> Trip Workspace</a>
  </div>
  <div class="back">
    <?php if(!empty($request['portal_token'])):?><a class="btn soft" target="_blank" href="<?=tsSupE(BASE_URL.'supplier-response.php?token='.(string)$request['portal_token'])?>"><i class="fa-solid fa-up-right-from-square"></i> Supplier Portal</a><?php endif;?>
  </div>
</div>

<div class="hero">
  <div class="hero-main">
    <div class="eyebrow">Supplier Communication Workspace</div>
    <span class="status"><i class="fa-solid fa-circle"></i> <?=tsSupE(ucwords(str_replace('_',' ',(string)$request['status'])))?></span>
    <h1><?=tsSupE((string)$request['company_name'])?></h1>
    <div class="sub"><?=tsSupE((string)$request['request_code'])?> · #ENQ<?=str_pad((string)$request['enquiry_id'],5,'0',STR_PAD_LEFT)?> · <?=tsSupE((string)$request['destination'])?></div>
    <?php if(!empty($request['linked_service_title'])):?><div style="margin-top:6px;display:inline-flex;gap:6px;align-items:center;padding:5px 8px;border-radius:999px;background:#fff7ed;color:#c2410c;font-size:10px;font-weight:900"><i class="fa-solid fa-link"></i><?=tsSupE((string)$request['linked_service_title'])?> · <?=tsSupE(ucwords(str_replace('_',' ',(string)$request['linked_service_type'])))?></div><?php endif;?>
  </div>
  <div class="hero-meta">
    <div class="meta-chip"><span>Contact</span><strong><?=tsSupE((string)($request['contact_name']?:'Not set'))?></strong></div>
    <div class="meta-chip"><span>Email</span><strong><?=tsSupE((string)($request['contact_email']?:'Not set'))?></strong></div>
    <div class="meta-chip"><span>Customer</span><strong><?=tsSupE((string)$request['customer_name'])?></strong></div>
    <?php if(!empty($request['trip_code'])):?><div class="meta-chip"><span>Trip</span><strong><?=tsSupE((string)$request['trip_code'])?></strong></div><?php endif;?>
  </div>
</div>

<div class="workspace">
  <section class="card chat-card">
    <div class="card-head">
      <div><h2><i class="fa-solid fa-comments" style="color:#2563eb"></i> Conversation</h2><div class="hint">Admin and supplier messages in one place</div></div>
      <span class="status" style="margin:0;background:#ecfdf5;color:#047857"><i class="fa-solid fa-link"></i> Two-way enabled</span>
    </div>

    <div class="chat-list" id="chatList">
      <?php if(!$messages):?>
        <div class="msg admin">
          <div class="msg-top"><strong>TRAVSCOPE → Supplier · Original Request</strong><span><?=tsSupE((string)($request['sent_at']?:$request['created_at']??''))?></span></div>
          <div class="msg-body"><?=nl2br(tsSupE((string)$request['requirement_text']))?></div>
        </div>
      <?php endif;?>
      <?php foreach($messages as $m): $cls=$m['sender_type']==='supplier'?'supplier':($m['sender_type']==='admin'?'admin':'system'); ?>
        <div class="msg <?=$cls?>">
          <div class="msg-top">
            <strong><?= $m['sender_type']==='supplier'?'Supplier → TRAVSCOPE':($m['sender_type']==='admin'?'TRAVSCOPE → Supplier':'System') ?></strong>
            <span><?=tsSupE((string)$m['sent_at'])?> · <?=tsSupE(ucfirst((string)$m['channel']))?></span>
          </div>
          <div class="msg-body"><?=nl2br(tsSupE((string)$m['message']))?></div>
          <?php if(!empty($m['attachment_path'])):?><div class="attach"><a class="btn soft" target="_blank" href="<?=tsSupE(BASE_URL.(string)$m['attachment_path'])?>"><i class="fa-solid fa-paperclip"></i> <?=tsSupE((string)($m['original_filename']?:'Attachment'))?></a></div><?php endif;?>
        </div>
      <?php endforeach;?>
    </div>

    <div class="composer">
      <div class="compose-tabs">
        <button type="button" class="compose-tab active" data-pane="sendPane"><i class="fa-solid fa-paper-plane"></i> Send to Supplier</button>
        <button type="button" class="compose-tab" data-pane="replyPane"><i class="fa-solid fa-inbox"></i> Record External Reply</button>
      </div>

      <form class="compose-pane active" id="sendPane" method="post">
        <input type="hidden" name="csrf" value="<?=tsSupE($csrf)?>"><input type="hidden" name="action" value="send_message"><input type="hidden" name="request_id" value="<?=$id?>">
        <div class="compose-grid">
          <div><label class="small-label">Email Subject</label><input class="input" name="message_subject" value="Re: <?=tsSupE((string)$request['subject'])?>"></div>
          <div><label class="small-label">Message</label><textarea name="message_body" placeholder="Write follow-up or clarification..." required></textarea></div>
          <button class="btn blue"><i class="fa-solid fa-paper-plane"></i> Send Email</button>
        </div>
      </form>

      <form class="compose-pane" id="replyPane" method="post">
        <input type="hidden" name="csrf" value="<?=tsSupE($csrf)?>"><input type="hidden" name="action" value="record_reply"><input type="hidden" name="request_id" value="<?=$id?>">
        <div class="compose-grid reply">
          <div><label class="small-label">Received Via</label><select name="reply_channel"><option value="email">Email</option><option value="whatsapp">WhatsApp</option><option value="phone">Phone</option><option value="manual">Other</option></select></div>
          <div><label class="small-label">Supplier Reply</label><textarea name="reply_message" placeholder="Paste/type supplier's external reply..." required></textarea></div>
          <button class="btn green"><i class="fa-solid fa-floppy-disk"></i> Save Reply</button>
        </div>
      </form>
    </div>
  </section>

  <aside class="side">
    <section class="card summary-card">
      <div class="card-head"><h2><i class="fa-solid fa-route" style="color:#7c3aed"></i> Trip Requirement</h2><span class="hint">Quick view</span></div>
      <div class="summary-grid">
        <div class="summary-item"><span>Destination</span><strong><?=tsSupE((string)$request['destination'])?></strong></div>
        <div class="summary-item"><span>Travel Date</span><strong><?=tsSupE((string)$request['travel_date'])?></strong></div>
        <div class="summary-item"><span>Travellers</span><strong><?=(int)$request['adults']?> Adult<?=((int)$request['adults']===1?'':'s')?> · <?=(int)$request['children']?> Child<?=((int)$request['children']===1?'':'ren')?></strong></div>
        <div class="summary-item"><span>Request</span><strong><?=tsSupE((string)$request['request_code'])?></strong></div>
      </div>
      <div class="requirement">
        <div class="req-box"><?php
          $raw=(string)$request['requirement_text'];
          $clean=preg_replace('/DAY-WISE ITINERARY\s*\[[\s\S]*?\]\s*(?=INCLUSIONS|EXCLUSIONS|CUSTOMER REQUIREMENT|$)/i','DAY-WISE ITINERARY: Included in package',$raw);
          $clean=preg_replace('/\{\"day_number\"[\s\S]*?\}/','',$clean);
          echo nl2br(tsSupE(trim((string)$clean)));
        ?></div>
        <details class="req-more"><summary>View original full request</summary><div class="req-box" style="max-height:220px;margin-top:6px"><?=nl2br(tsSupE((string)$request['requirement_text']))?></div></details>
        <?php if($request['special_requirements']):?><details class="req-more"><summary>Special requirements</summary><div class="req-box" style="margin-top:6px"><?=nl2br(tsSupE((string)$request['special_requirements']))?></div></details><?php endif;?>
      </div>
    </section>

    <section class="card side-tabs-card">
      <div class="side-tabs">
        <button type="button" class="side-tab active" data-side="quotePane"><i class="fa-solid fa-file-invoice-dollar"></i> Quotes <?=count($quotes)?></button>
        <button type="button" class="side-tab" data-side="activityPane"><i class="fa-solid fa-clock-rotate-left"></i> Activity <?=count($events)?></button>
      </div>

      <div class="side-pane active" id="quotePane">
        <?php if(!$quotes):?><div class="empty"><i class="fa-solid fa-file-circle-plus"></i><br><strong>No supplier quote yet</strong><br><span style="font-size:10px">Supplier can submit from portal, or Admin can add a quote version below.</span></div><?php endif;?>
        <?php foreach($quotes as $q):?>
          <?php $quoteMode=tsSupplierQuoteModeFromRow($q,(string)($request['request_type']??'')); ?>
          <div class="quote-card <?=$q['status']==='selected'?'selected':''?>">
            <div class="quote-top">
              <div>
                <div class="quote-ver">VERSION <?=(int)$q['version_number']?> <?=$q['status']==='selected'?'· SELECTED':''?></div>
                <div class="quote-meta"><?=tsSupE((string)$q['received_at'])?> · <?=tsSupE(ucfirst((string)$q['response_channel']))?></div>
                <span class="cost-mode-badge <?=tsSupE($quoteMode)?>"><?=tsSupE(tsSupplierQuoteModeLabel($quoteMode))?></span>
              </div>
              <div class="quote-price"><?=tsSupE((string)$q['currency'])?> <?=number_format((float)$q['total_supplier_cost'],2)?></div>
            </div>
            <div class="quote-cost-strip">
              <span><small>NET / SERVICES</small><strong><?=tsSupE((string)$q['currency'])?> <?=number_format((float)($q['net_amount']??0),2)?></strong></span>
              <span><small>SUPPLIER GST / TAX</small><strong><?=tsSupE((string)$q['currency'])?> <?=number_format((float)($q['tax_amount']??0),2)?></strong></span>
              <span><small>OTHER / UPGRADE</small><strong><?=tsSupE((string)$q['currency'])?> <?=number_format((float)($q['upgrade_amount']??0),2)?></strong></span>
              <span class="total"><small>SUPPLIER PAYABLE</small><strong><?=tsSupE((string)$q['currency'])?> <?=number_format((float)$q['total_supplier_cost'],2)?></strong></span>
            </div>
            <?php if($items[(int)$q['id']]??[]):?><details class="quote-details"><summary>View cost items / breakdown</summary><ul class="items"><?php foreach($items[(int)$q['id']] as $item):?><li><strong><?=tsSupE(ucfirst((string)$item['item_type']))?></strong> · <?=tsSupE((string)$item['description'])?> — <?=tsSupE((string)$q['currency'])?> <?=number_format((float)$item['line_cost'],2)?><?=$item['is_upgrade']?' (Upgrade)':''?></li><?php endforeach;?></ul></details><?php endif;?>
            <div class="quote-actions">
              <?php if($q['attachment_path']):?><a class="btn soft" href="<?=tsSupE(BASE_URL.(string)$q['attachment_path'])?>" target="_blank"><i class="fa-solid fa-paperclip"></i> Attachment</a><?php endif;?>
              <form method="post"><input type="hidden" name="csrf" value="<?=tsSupE($csrf)?>"><input type="hidden" name="action" value="select_quote"><input type="hidden" name="request_id" value="<?=$id?>"><input type="hidden" name="quote_id" value="<?=(int)$q['id']?>"><button class="btn <?=$q['status']==='selected'?'green':'purple'?>"><i class="fa-solid fa-check"></i> <?=$q['status']==='selected'?'Selected':'Use for Costing'?></button></form>
            </div>
          </div>
        <?php endforeach;?>

        <details class="add-quote">
          <summary><i class="fa-solid fa-plus"></i> Add Supplier Quote Version</summary>
          <form class="quote-form supplier-costing-form" method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf" value="<?=tsSupE($csrf)?>">
            <input type="hidden" name="action" value="record_quote">
            <input type="hidden" name="request_id" value="<?=$id?>">

            <div class="costing-mode-panel">
              <label class="small-label">How did the supplier quote?</label>
              <select name="costing_mode" class="input js-costing-mode">
                <option value="complete_package" <?=($request['request_type']??'')!=='service_quote'?'selected':''?>>Complete Package Rate</option>
                <option value="service_wise" <?=($request['request_type']??'')==='service_quote'?'selected':''?>>Service-wise Costing</option>
                <option value="hybrid">Hybrid — Package + Extra Services</option>
              </select>
              <div class="mode-help js-mode-help">
                Complete Package: one supplier NET package rate. Service-wise: Hotel / Transport / Activities etc. Hybrid: package base plus separately charged services.
              </div>
            </div>

            <div class="grid">
              <div>
                <label class="small-label">Channel</label>
                <select name="response_channel">
                  <option value="email">Email</option>
                  <option value="whatsapp">WhatsApp</option>
                  <option value="phone">Phone</option>
                  <option value="manual">Manual</option>
                </select>
              </div>

              <div>
                <label class="small-label">Currency</label>
                <input class="input" name="currency" value="INR">
              </div>

              <div class="js-package-base-field">
                <label class="small-label">Package / Base NET Amount</label>
                <input class="input js-package-base" type="number" min="0" step=".01" name="package_base_amount" placeholder="Supplier NET amount">
              </div>

              <div>
                <label class="small-label">Supplier GST / Tax Amount</label>
                <input class="input js-supplier-tax" type="number" min="0" step=".01" name="tax_amount" value="0">
              </div>

              <div>
                <label class="small-label">Other / Upgrade Charges</label>
                <input class="input js-other-charges" type="number" min="0" step=".01" name="upgrade_amount" value="0">
              </div>

              <div>
                <label class="small-label">Supplier Total Payable</label>
                <input class="input js-supplier-total" type="number" step=".01" value="0" readonly>
                <small class="field-help">NET/services + supplier GST/tax + other charges</small>
              </div>

              <div>
                <label class="small-label">Valid Until</label>
                <input class="input" type="date" name="validity_until">
              </div>

              <div>
                <label class="small-label">Attachment</label>
                <input class="input" type="file" name="attachment">
              </div>

              <div class="full">
                <label class="small-label">Hotel / Room / Meal</label>
                <textarea name="hotel_summary"></textarea>
              </div>

              <div class="full">
                <label class="small-label">Transport / Vehicle</label>
                <textarea name="transport_summary"></textarea>
              </div>

              <div class="full">
                <label class="small-label">Inclusions</label>
                <textarea name="inclusions"></textarea>
              </div>

              <div class="full">
                <label class="small-label">Exclusions</label>
                <textarea name="exclusions"></textarea>
              </div>

              <div class="full">
                <label class="small-label">Payment Terms</label>
                <textarea name="payment_terms"></textarea>
              </div>

              <div class="full">
                <label class="small-label">Cancellation Terms</label>
                <textarea name="cancellation_terms"></textarea>
              </div>

              <div class="full">
                <label class="small-label">Internal Notes</label>
                <textarea name="response_notes"></textarea>
              </div>
            </div>

            <div class="service-cost-block js-service-cost-block">
              <div class="section-label">Service Cost Items</div>
              <div class="mode-help">Used for Service-wise and Hybrid costing. Do not repeat GST here.</div>
              <?php for($i=0;$i<8;$i++):?>
                <div class="cost-items">
                  <select name="item_type[]">
                    <option value="hotel">Hotel</option>
                    <option value="transport">Transport</option>
                    <option value="activity">Activity</option>
                    <option value="sightseeing">Sightseeing</option>
                    <option value="transfer">Transfer</option>
                    <option value="flight">Flight</option>
                    <option value="visa">Visa</option>
                    <option value="insurance">Insurance</option>
                    <option value="upgrade">Upgrade</option>
                    <option value="other">Other</option>
                  </select>
                  <input class="input" name="item_description[]" placeholder="Service description">
                  <input class="input js-item-cost" type="number" min="0" step=".01" name="item_cost[]" placeholder="Cost">
                </div>
              <?php endfor;?>
            </div>

            <div class="cost-formula-preview">
              <span>Supplier Cost Formula</span>
              <strong class="js-cost-formula">Enter supplier cost</strong>
            </div>

            <button class="btn purple" style="width:100%;margin-top:7px">
              <i class="fa-solid fa-code-branch"></i> Save Quote Version
            </button>
          </form>
        </details>
      </div>

      <div class="side-pane" id="activityPane">
        <?php if(!$events):?><div class="empty">No activity yet.</div><?php endif;?>
        <?php foreach($events as $e):?><div class="activity-row"><div class="rowtop"><strong><?=tsSupE(ucwords(str_replace('_',' ',(string)$e['event_type'])))?></strong><span><?=tsSupE((string)$e['event_at'])?></span></div><p><?=tsSupE((string)$e['description'])?></p></div><?php endforeach;?>
      </div>
    </section>
  </aside>
</div>
</div>
<script>
(function(){
  document.querySelectorAll('.compose-tab').forEach(function(btn){btn.addEventListener('click',function(){document.querySelectorAll('.compose-tab').forEach(b=>b.classList.remove('active'));document.querySelectorAll('.compose-pane').forEach(p=>p.classList.remove('active'));this.classList.add('active');document.getElementById(this.dataset.pane)?.classList.add('active');});});
  document.querySelectorAll('.side-tab').forEach(function(btn){btn.addEventListener('click',function(){document.querySelectorAll('.side-tab').forEach(b=>b.classList.remove('active'));document.querySelectorAll('.side-pane').forEach(p=>p.classList.remove('active'));this.classList.add('active');document.getElementById(this.dataset.side)?.classList.add('active');});});
  function setupSupplierCostingForm(form){
    if(!form) return;
    const mode=form.querySelector('.js-costing-mode');
    const packageField=form.querySelector('.js-package-base-field');
    const packageInput=form.querySelector('.js-package-base');
    const tax=form.querySelector('.js-supplier-tax');
    const other=form.querySelector('.js-other-charges');
    const total=form.querySelector('.js-supplier-total');
    const serviceBlock=form.querySelector('.js-service-cost-block');
    const formula=form.querySelector('.js-cost-formula');
    const itemCosts=Array.from(form.querySelectorAll('.js-item-cost'));

    const num=(el)=>Math.max(0,Number(el?.value||0));

    function calculate(){
      const selected=mode?.value||'complete_package';
      const packageBase=num(packageInput);
      const serviceTotal=itemCosts.reduce((sum,input)=>sum+num(input),0);
      const net=selected==='service_wise'
        ? serviceTotal
        : selected==='hybrid'
          ? packageBase+serviceTotal
          : packageBase;
      const taxAmount=num(tax);
      const otherAmount=num(other);
      const finalTotal=net+taxAmount+otherAmount;

      if(packageField) packageField.hidden=selected==='service_wise';
      if(serviceBlock) serviceBlock.hidden=selected==='complete_package';
      if(total) total.value=finalTotal.toFixed(2);

      if(formula){
        const label=selected==='complete_package'
          ? 'Package NET'
          : selected==='service_wise'
            ? 'Service items'
            : 'Package NET + extra services';
        formula.textContent=label+' '+net.toFixed(2)+' + GST/Tax '+taxAmount.toFixed(2)+' + Other '+otherAmount.toFixed(2)+' = '+finalTotal.toFixed(2);
      }
    }

    [mode,packageInput,tax,other,...itemCosts].forEach(function(el){
      el?.addEventListener('input',calculate);
      el?.addEventListener('change',calculate);
    });

    calculate();
  }

  document.querySelectorAll('.supplier-costing-form').forEach(setupSupplierCostingForm);

  const chat=document.getElementById('chatList'); if(chat) chat.scrollTop=chat.scrollHeight;
})();
</script>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
