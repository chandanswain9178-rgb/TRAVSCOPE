<?php
/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM - DYNAMIC PUBLIC PAGE
|--------------------------------------------------------------------------
| Public URLs:
| pages.php?page=about
| pages.php?page=privacy
| pages.php?page=terms
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';

/*
|--------------------------------------------------------------------------
| ALWAYS SHOW LATEST ADMIN-MANAGED PAGE CONTENT
|--------------------------------------------------------------------------
| Legal/company pages are database-driven. Prevent a browser/proxy from
| continuing to show an older saved Privacy/About/Terms version.
*/
if (!headers_sent()) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Cache-Control: post-check=0, pre-check=0', false);
    header('Pragma: no-cache');
}



function publicPageStandardizePrivacyContent(string $html): string
{
    $html = str_replace("\0", '', $html);

    // Remove accidental interactive/browser/editor controls.
    $html = preg_replace(
        '/<(script|style|form|button|select|textarea|iframe|object|embed)\b[^>]*>.*?<\/\1>/is',
        '',
        $html
    );
    $html = preg_replace(
        '/<(input|button|select|textarea|form|iframe|object|embed)\b[^>]*\/?>/is',
        '',
        $html
    );

    // Remove pasted visual/editor attributes.
    $html = preg_replace(
        '/\s+(?:style|class|id|align|width|height|color|face|bgcolor|border|contenteditable|spellcheck|role|aria-[a-z0-9_-]+|data-[a-z0-9_-]+|on[a-z]+)\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)/i',
        '',
        $html
    );

    $html = preg_replace('/<\/?font\b[^>]*>/i', '', $html);
    $html = preg_replace('/<span\b[^>]*>(.*?)<\/span>/is', '$1', $html);

    /*
    |--------------------------------------------------------------------------
    | FIX OVERSIZED / ALL-BOLD PRIVACY CONTENT
    |--------------------------------------------------------------------------
    */

    // Convert any heading containing block elements into normal content.
    $html = preg_replace_callback(
        '/<(h[1-6])\b[^>]*>(.*?)<\/\1>/is',
        static function (array $m): string {
            $inner = trim((string)$m[2]);
            $plain = trim(preg_replace('/\s+/', ' ', strip_tags($inner)));

            $containsBlocks = preg_match(
                '/<(p|div|ul|ol|li|table|blockquote|h[1-6])\b/i',
                $inner
            );

            // A real legal-page heading should be short.
            if (
                $containsBlocks
                || mb_strlen($plain) > 85
                || str_word_count($plain) > 12
            ) {
                return '<p>' . $inner . '</p>';
            }

            $tag = strtolower((string)$m[1]);
            if ($tag === 'h1') {
                $tag = 'h2';
            }

            return '<' . $tag . '>' . $inner . '</' . $tag . '>';
        },
        $html
    );

    // Unwrap strong/b when it contains a whole paragraph, list, heading,
    // or a long sentence. This is the main cause of "everything bold".
    $html = preg_replace_callback(
        '/<(strong|b)\b[^>]*>(.*?)<\/\1>/is',
        static function (array $m): string {
            $inner = trim((string)$m[2]);
            $plain = trim(preg_replace('/\s+/', ' ', strip_tags($inner)));

            $containsBlocks = preg_match(
                '/<(p|div|ul|ol|li|table|blockquote|h[1-6])\b/i',
                $inner
            );

            if (
                $containsBlocks
                || mb_strlen($plain) > 55
                || str_word_count($plain) > 8
            ) {
                return $inner;
            }

            // Keep short emphasis only.
            return '<strong>' . $inner . '</strong>';
        },
        $html
    );

    // Re-run long-heading cleanup after removing bold wrappers.
    $html = preg_replace_callback(
        '/<(h[1-6])\b[^>]*>(.*?)<\/\1>/is',
        static function (array $m): string {
            $inner = trim((string)$m[2]);
            $plain = trim(preg_replace('/\s+/', ' ', strip_tags($inner)));

            if (mb_strlen($plain) > 85 || str_word_count($plain) > 12) {
                return '<p>' . $inner . '</p>';
            }

            $tag = strtolower((string)$m[1]);
            return '<' . ($tag === 'h1' ? 'h2' : $tag) . '>' . $inner . '</' . ($tag === 'h1' ? 'h2' : $tag) . '>';
        },
        $html
    );

    // Remove remnants from mistakenly pasted form/chat controls.
    $html = preg_replace(
        '/(?:Browse\.\.\.|No files selected\.?|Ask anything)/i',
        '',
        $html
    );

    // Clean excessive empty blocks.
    $html = preg_replace('/<p>\s*(?:&nbsp;|\xC2\xA0|\s)*<\/p>/i', '', $html);
    $html = preg_replace('/(?:<br\s*\/?>\s*){3,}/i', '<br><br>', $html);

    return trim((string)$html);
}

$pageKey = strtolower(trim((string)($_GET['page'] ?? 'about')));
$pageKey = preg_replace('/[^a-z0-9\-]/', '', $pageKey);

if ($pageKey === '') {
    $pageKey = 'about';
}

$page = null;

try {
    $stmt = $pdo->prepare("
        SELECT
            id,
            page_key,
            page_title,
            meta_title,
            meta_description,
            hero_title,
            hero_subtitle,
            page_content,
            status,
            updated_at
        FROM website_pages
        WHERE page_key = ?
          AND status = 'active'
        LIMIT 1
    ");

    $stmt->execute([$pageKey]);
    $page = $stmt->fetch(PDO::FETCH_ASSOC);

    if (
        $page
        && strtolower((string)($page['page_key'] ?? '')) === 'privacy'
    ) {
        $page['page_content'] =
            publicPageStandardizePrivacyContent(
                (string)($page['page_content'] ?? '')
            );
    }

} catch (Throwable $e) {
    error_log('TRAVSCOPE public page load error: ' . $e->getMessage());
}

if (!$page) {
    http_response_code(404);

    $page = [
        'page_key' => $pageKey,
        'page_title' => 'Page Not Found',
        'meta_title' => 'Page Not Found',
        'meta_description' => 'The requested page could not be found.',
        'hero_title' => 'Page Not Found',
        'hero_subtitle' => 'The page may be unavailable or currently inactive.',
        'page_content' => '
            <div class="not-found-message">
                <h2>We could not find this page.</h2>
                <p>Please return to the homepage or contact our travel team for assistance.</p>
                <a href="index.php" class="content-button">
                    Return to Homepage
                </a>
            </div>
        ',
        'status' => 'inactive',
        'updated_at' => null,
    ];
}

$siteName = (string)getSetting($pdo, 'site_name', 'TRAVSCOPE.COM');
$siteTagline = (string)getSetting($pdo, 'site_tagline', 'Explore More. Travel Better.');
$supportEmail = trim((string)getSetting($pdo, 'support_email', 'support@travscope.com'));
$supportMobile = trim((string)getSetting($pdo, 'support_mobile', ''));
$officeAddress = trim((string)getSetting($pdo, 'office_address', 'Odisha, India'));
$businessHours = trim((string)getSetting($pdo, 'business_hours', 'Travel Assistance Available'));

$whatsappNumber = preg_replace(
    '/\D+/',
    '',
    (string)getSetting($pdo, 'whatsapp_number', '')
);

$whatsappUrl = trim((string)getSetting($pdo, 'whatsapp_url', ''));
$facebookUrl = trim((string)getSetting($pdo, 'facebook_url', ''));
$instagramUrl = trim((string)getSetting($pdo, 'instagram_url', ''));
$youtubeUrl = trim((string)getSetting($pdo, 'youtube_url', ''));
$twitterUrl = trim((string)getSetting($pdo, 'x_url', ''));

if ($whatsappUrl === '' && $whatsappNumber !== '') {
    $whatsappUrl = 'https://wa.me/' . $whatsappNumber;
}

$isLoggedIn = !empty($_SESSION['user_id']);

$metaTitle = trim((string)($page['meta_title'] ?? ''));
$metaDescription = trim((string)($page['meta_description'] ?? ''));
$heroTitle = trim((string)($page['hero_title'] ?? ''));
$heroSubtitle = trim((string)($page['hero_subtitle'] ?? ''));

if ($metaTitle === '') {
    $metaTitle = (string)$page['page_title'];
}

if ($metaDescription === '') {
    $metaDescription = mb_substr(
        trim(preg_replace('/\s+/', ' ', strip_tags((string)$page['page_content']))),
        0,
        160
    );
}

if ($heroTitle === '') {
    $heroTitle = (string)$page['page_title'];
}

$currentYear = date('Y');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=5">
<meta name="theme-color" content="#07192d">

<title><?= e($metaTitle); ?> | <?= e($siteName); ?></title>

<meta name="description" content="<?= e($metaDescription); ?>">
<meta property="og:title" content="<?= e($metaTitle); ?>">
<meta property="og:description" content="<?= e($metaDescription); ?>">
<meta property="og:type" content="website">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>
:root{
    --navy:#07192d;
    --navy-light:#0b2c4d;
    --blue:#0b74ff;
    --cyan:#00b8ff;
    --bg:#f5f8fc;
    --white:#ffffff;
    --text:#172033;
    --muted:#748196;
    --border:#e4eaf1;
    --shadow:0 18px 55px rgba(7,25,45,.10);
}

*{
    box-sizing:border-box;
    margin:0;
    padding:0;
}

html{
    scroll-behavior:smooth;
}

body{
    background:var(--bg);
    color:var(--text);
    font-family:'DM Sans',sans-serif;
    line-height:1.7;
}

a{
    color:inherit;
    text-decoration:none;
}

button{
    font:inherit;
    cursor:pointer;
}

.container{
    width:min(1180px,calc(100% - 36px));
    margin:auto;
}

.topbar{
    background:var(--navy);
    color:#b9c9d8;
    font-size:12px;
}

.topbar-inner{
    min-height:38px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:20px;
}

.topbar-group{
    display:flex;
    align-items:center;
    gap:20px;
    flex-wrap:wrap;
}

.topbar i{
    margin-right:6px;
    color:#67b4ff;
}

.nav{
    position:sticky;
    top:0;
    z-index:1000;
    background:rgba(255,255,255,.97);
    border-bottom:1px solid var(--border);
    backdrop-filter:blur(14px);
}

.nav-inner{
    min-height:76px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:20px;
}

.logo{
    display:flex;
    align-items:center;
    gap:10px;
    color:var(--navy);
    font:800 21px 'Manrope',sans-serif;
}

.logo-icon{
    width:42px;
    height:42px;
    border-radius:12px;
    display:grid;
    place-items:center;
    color:#fff;
    background:linear-gradient(135deg,var(--blue),var(--cyan));
}

.logo span{
    color:var(--blue);
}

.nav-links{
    display:flex;
    align-items:center;
    gap:26px;
}

.nav-links a{
    color:#405067;
    font-size:14px;
    font-weight:700;
}

.nav-links a:hover,
.nav-links a.active{
    color:var(--blue);
}

.nav-actions{
    display:flex;
    align-items:center;
    gap:9px;
}

.button{
    min-height:43px;
    padding:0 16px;
    border:0;
    border-radius:10px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:7px;
    font-size:12px;
    font-weight:800;
}

.button-blue{
    background:var(--blue);
    color:#fff;
}

.button-light{
    background:#eef5fd;
    color:var(--navy);
}

.menu-button{
    display:none;
    width:43px;
    height:43px;
    border:0;
    border-radius:10px;
    background:#edf3f9;
    color:var(--navy);
}

.mobile-menu{
    display:none;
    position:fixed;
    inset:76px 0 0;
    z-index:999;
    padding:20px;
    overflow-y:auto;
    background:#fff;
}

.mobile-menu.open{
    display:block;
}

.mobile-menu a{
    display:block;
    padding:14px 5px;
    border-bottom:1px solid var(--border);
    color:var(--navy);
    font-weight:700;
}

.hero{
    position:relative;
    overflow:hidden;
    padding:95px 0;
    color:#fff;
    background:
        linear-gradient(120deg,rgba(7,25,45,.97),rgba(11,116,255,.76)),
        url('https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=2000&q=85') center/cover;
}

.hero:after{
    content:"";
    position:absolute;
    inset:auto -160px -210px auto;
    width:500px;
    height:500px;
    border-radius:50%;
    border:85px solid rgba(255,255,255,.06);
}

.hero-content{
    position:relative;
    z-index:2;
    max-width:850px;
    text-align:center;
    margin:auto;
}

.breadcrumb{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:8px;
    margin-bottom:16px;
    padding:7px 12px;
    border:1px solid rgba(255,255,255,.22);
    border-radius:30px;
    background:rgba(255,255,255,.08);
    color:#d9e9f7;
    font-size:12px;
    font-weight:700;
}

.breadcrumb a:hover{
    color:#fff;
}

.hero h1{
    font:800 clamp(38px,6vw,64px)/1.08 'Manrope',sans-serif;
    letter-spacing:-1.5px;
}

.hero p{
    max-width:700px;
    margin:16px auto 0;
    color:#d8e7f4;
    font-size:17px;
}

.page-section{
    padding:72px 0 85px;
}

.page-layout{
    display:grid;
    grid-template-columns:minmax(0,1fr) 290px;
    gap:28px;
    align-items:start;
}

.content-card,
.sidebar-card{
    border:1px solid var(--border);
    border-radius:18px;
    background:#fff;
    box-shadow:var(--shadow);
}

.content-card{
    padding:42px;
}

.page-content{
    color:#46566b;
    font-size:16px;
    overflow-wrap:anywhere;
}

.page-content h1,
.page-content h2,
.page-content h3,
.page-content h4{
    margin:30px 0 12px;
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    line-height:1.3;
}

.page-content h1:first-child,
.page-content h2:first-child,
.page-content h3:first-child{
    margin-top:0;
}

.page-content h1{
    font-size:34px;
}

.page-content h2{
    font-size:27px;
}

.page-content h3{
    font-size:21px;
}

.page-content p{
    margin:0 0 17px;
}

.page-content ul,
.page-content ol{
    margin:0 0 18px;
    padding-left:24px;
}

.page-content li{
    margin-bottom:8px;
}

.page-content a{
    color:var(--blue);
    text-decoration:underline;
}

.page-content blockquote{
    margin:24px 0;
    padding:18px 20px;
    border-left:4px solid var(--blue);
    border-radius:0 10px 10px 0;
    background:#f1f7ff;
    color:#43556b;
}

.page-content table{
    width:100%;
    margin:22px 0;
    border-collapse:collapse;
}

.page-content th,
.page-content td{
    padding:12px;
    border:1px solid var(--border);
    text-align:left;
}

.page-content th{
    background:#f5f8fc;
    color:var(--navy);
}

.page-content img{
    max-width:100%;
    height:auto;
    margin:20px 0;
    border-radius:13px;
}

.not-found-message{
    text-align:center;
    padding:25px 5px;
}

.content-button{
    min-height:43px;
    margin-top:10px;
    padding:0 17px;
    border-radius:10px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    background:var(--blue);
    color:#fff!important;
    text-decoration:none!important;
    font-size:12px;
    font-weight:800;
}

.sidebar-card{
    padding:22px;
    margin-bottom:18px;
}

.sidebar-card h3{
    margin-bottom:13px;
    color:var(--navy);
    font:800 17px 'Manrope',sans-serif;
}

.quick-links{
    display:grid;
    gap:8px;
}

.quick-links a{
    padding:11px 12px;
    border:1px solid var(--border);
    border-radius:9px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    color:#536176;
    font-size:13px;
    font-weight:700;
}

.quick-links a:hover,
.quick-links a.active{
    border-color:#b9d7ff;
    background:#edf5ff;
    color:var(--blue);
}

.contact-line{
    display:flex;
    align-items:flex-start;
    gap:10px;
    margin-bottom:12px;
    color:#627084;
    font-size:13px;
}

.contact-line:last-child{
    margin-bottom:0;
}

.contact-line i{
    width:30px;
    height:30px;
    flex:0 0 30px;
    display:grid;
    place-items:center;
    border-radius:8px;
    background:#edf5ff;
    color:var(--blue);
}

.page-updated{
    margin-top:28px;
    padding-top:18px;
    border-top:1px solid var(--border);
    color:#8a96a5;
    font-size:12px;
}

.footer{
    padding-top:55px;
    background:#051525;
    color:#9db0c2;
}

.footer-grid{
    display:grid;
    grid-template-columns:1.4fr 1fr 1fr 1.2fr;
    gap:35px;
    padding-bottom:40px;
}

.footer .logo{
    color:#fff;
}

.footer-about{
    margin-top:14px;
    font-size:14px;
}

.footer h4{
    margin-bottom:13px;
    color:#fff;
    font-size:16px;
}

.footer-links{
    display:grid;
    gap:8px;
}

.footer a,
.footer p{
    font-size:14px;
}

.footer a:hover{
    color:#fff;
}

.social-buttons{
    display:flex;
    align-items:center;
    gap:9px;
    flex-wrap:wrap;
    margin-top:18px;
}

.social-button{
    width:39px;
    height:39px;
    border-radius:10px;
    display:grid;
    place-items:center;
    color:#fff!important;
    font-size:17px!important;
    transition:.22s;
}

.social-button:hover{
    transform:translateY(-3px);
}

.social-button.whatsapp{background:#25d366}
.social-button.facebook{background:#1877f2}
.social-button.instagram{background:linear-gradient(135deg,#833ab4,#fd1d1d,#fcb045)}
.social-button.youtube{background:#ff0000}
.social-button.twitter{background:#111}

.copyright{
    min-height:60px;
    border-top:1px solid rgba(255,255,255,.08);
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:20px;
    font-size:13px;
}

.floating-whatsapp{
    position:fixed;
    right:20px;
    bottom:20px;
    z-index:900;
    width:54px;
    height:54px;
    border-radius:50%;
    display:grid;
    place-items:center;
    background:#25d366;
    color:#fff;
    font-size:24px;
    box-shadow:0 12px 30px rgba(0,0,0,.2);
}

@media(max-width:1050px){
    .nav-links{
        display:none;
    }

    .menu-button{
        display:grid;
        place-items:center;
    }

    .page-layout{
        grid-template-columns:1fr;
    }

    .sidebar-column{
        display:grid;
        grid-template-columns:1fr 1fr;
        gap:18px;
    }

    .sidebar-card{
        margin:0;
    }
}

@media(max-width:760px){
    .topbar{
        display:none;
    }

    .nav-inner{
        min-height:68px;
    }

    .mobile-menu{
        inset:68px 0 0;
    }

    .nav-actions > .button{
        display:none;
    }

    .hero{
        padding:70px 0;
    }

    .page-section{
        padding:50px 0 65px;
    }

    .content-card{
        padding:27px 22px;
    }

    .sidebar-column{
        grid-template-columns:1fr;
    }

    .footer-grid{
        grid-template-columns:1fr 1fr;
    }
}

@media(max-width:520px){
    .container{
        width:calc(100% - 26px);
    }

    .hero h1{
        font-size:38px;
    }

    .hero p{
        font-size:15px;
    }

    .content-card{
        padding:22px 17px;
    }

    .page-content{
        font-size:15px;
    }

    .page-content h1{
        font-size:29px;
    }

    .page-content h2{
        font-size:24px;
    }

    .footer-grid{
        grid-template-columns:1fr;
    }

    .copyright{
        padding:15px 0;
        flex-direction:column;
        justify-content:center;
        text-align:center;
        gap:4px;
    }
}


/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}



/* Legal/company article safety:
   saved page content should display as article content, never as forms. */
.page-content form,
.page-content input,
.page-content textarea,
.page-content select,
.page-content button{
    display:none !important;
}



/* ============================================================
   PRIVACY POLICY — NORMAL ARTICLE TYPOGRAPHY
   Prevent pasted markup from making all content large/bold.
============================================================ */

.page-content.privacy-content{
    color:#46566b !important;
    font-size:16px !important;
    line-height:1.75 !important;
    font-weight:400 !important;
}

/* Default every ordinary content element to normal text. */
.page-content.privacy-content p,
.page-content.privacy-content div,
.page-content.privacy-content li,
.page-content.privacy-content ul,
.page-content.privacy-content ol,
.page-content.privacy-content blockquote,
.page-content.privacy-content td{
    color:#46566b !important;
    font-family:'DM Sans',sans-serif !important;
    font-size:16px !important;
    line-height:1.75 !important;
    font-weight:400 !important;
}

/* Important: pasted bold wrappers must not make whole paragraphs bold. */
.page-content.privacy-content p strong,
.page-content.privacy-content p b,
.page-content.privacy-content div strong,
.page-content.privacy-content div b,
.page-content.privacy-content li strong,
.page-content.privacy-content li b{
    font-size:inherit !important;
    line-height:inherit !important;
}

/* Only genuine headings are large and bold. */
.page-content.privacy-content h1,
.page-content.privacy-content h2,
.page-content.privacy-content h3,
.page-content.privacy-content h4,
.page-content.privacy-content h5,
.page-content.privacy-content h6{
    color:var(--navy) !important;
    font-family:'Manrope',sans-serif !important;
    font-weight:800 !important;
    line-height:1.3 !important;
}

.page-content.privacy-content h1{
    margin:0 0 18px !important;
    font-size:30px !important;
}

.page-content.privacy-content h2{
    margin:27px 0 10px !important;
    font-size:23px !important;
}

.page-content.privacy-content h3{
    margin:22px 0 9px !important;
    font-size:19px !important;
}

.page-content.privacy-content h4,
.page-content.privacy-content h5,
.page-content.privacy-content h6{
    margin:18px 0 8px !important;
    font-size:17px !important;
}

.page-content.privacy-content p{
    margin:0 0 16px !important;
}

.page-content.privacy-content ul,
.page-content.privacy-content ol{
    margin:4px 0 20px !important;
    padding-left:27px !important;
}

.page-content.privacy-content li{
    margin:7px 0 !important;
}

.page-content.privacy-content a{
    color:var(--blue) !important;
    font-size:inherit !important;
    font-weight:inherit !important;
}

@media(max-width:760px){
    .page-content.privacy-content,
    .page-content.privacy-content p,
    .page-content.privacy-content div,
    .page-content.privacy-content li,
    .page-content.privacy-content ul,
    .page-content.privacy-content ol,
    .page-content.privacy-content blockquote,
    .page-content.privacy-content td{
        font-size:15px !important;
    }

    .page-content.privacy-content h1{font-size:27px !important}
    .page-content.privacy-content h2{font-size:21px !important}
    .page-content.privacy-content h3{font-size:18px !important}
}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>

<body>

<div class="topbar">
    <div class="container topbar-inner">

        <div class="topbar-group">
            <?php if ($supportMobile !== ''): ?>
                <span>
                    <i class="fa-solid fa-phone"></i>
                    <?= e($supportMobile); ?>
                </span>
            <?php endif; ?>

            <?php if ($supportEmail !== ''): ?>
                <span>
                    <i class="fa-solid fa-envelope"></i>
                    <?= e($supportEmail); ?>
                </span>
            <?php endif; ?>
        </div>

        <div class="topbar-group">
            <span>
                <i class="fa-solid fa-headset"></i>
                <?= e($businessHours); ?>
            </span>
        </div>

    </div>
</div>

<nav class="nav">
    <div class="container nav-inner">

        <a href="index.php" class="logo">
            <span class="logo-icon">
                <i class="fa-solid fa-plane"></i>
            </span>
            TRAV<span>SCOPE</span>
        </a>

        <div class="nav-links">
            <a href="index.php">Home</a>

            <a
                href="pages.php?page=about"
                class="<?= $pageKey === 'about' ? 'active' : ''; ?>"
            >
                About Us
            </a>

            <a href="index.php#destinations">Destinations</a>
            <a href="index.php#packages">Packages</a>
            <a href="index.php#new">New Trips</a>
            <a href="index.php#services">Services</a>
            <a href="contact.php">Contact</a>
        </div>

        <div class="nav-actions">
            <?php if ($isLoggedIn): ?>
                <a href="dashboard.php" class="button button-light">
                    <i class="fa-regular fa-user"></i>
                    My Dashboard
                </a>
            <?php else: ?>
                <a href="login.php" class="button button-light">
                    <i class="fa-regular fa-user"></i>
                    Login
                </a>

                <a href="register.php" class="button button-blue">
                    Register
                </a>
            <?php endif; ?>

            <button
                type="button"
                class="menu-button"
                id="menuButton"
                aria-label="Open navigation"
            >
                <i class="fa-solid fa-bars"></i>
            </button>
        </div>

    </div>
</nav>

<div class="mobile-menu" id="mobileMenu">
    <a href="index.php">Home</a>
    <a href="pages.php?page=about">About Us</a>
    <a href="index.php#destinations">Destinations</a>
    <a href="index.php#packages">Packages</a>
    <a href="index.php#new">New Trips</a>
    <a href="index.php#services">Services</a>
    <a href="contact.php">Contact</a>

    <?php if ($isLoggedIn): ?>
        <a href="dashboard.php">My Dashboard</a>
    <?php else: ?>
        <a href="login.php">Login</a>
        <a href="register.php">Create Account</a>
    <?php endif; ?>
</div>

<section class="hero">
    <div class="container hero-content">

        <div class="breadcrumb">
            <a href="index.php">Home</a>
            <i class="fa-solid fa-chevron-right"></i>
            <span><?= e((string)$page['page_title']); ?></span>
        </div>

        <h1><?= e($heroTitle); ?></h1>

        <?php if ($heroSubtitle !== ''): ?>
            <p><?= e($heroSubtitle); ?></p>
        <?php endif; ?>

    </div>
</section>

<section class="page-section">
    <div class="container page-layout">

        <main class="content-card">

            <article class="page-content <?= $pageKey === 'privacy' ? 'privacy-content' : ''; ?>">
                <?= (string)$page['page_content']; ?>
            </article>

            <?php if (!empty($page['updated_at'])): ?>
                <div class="page-updated">
                    Last updated:
                    <?= e(date('d F Y', strtotime((string)$page['updated_at']))); ?>
                </div>
            <?php endif; ?>

        </main>

        <aside class="sidebar-column">

            <div class="sidebar-card">
                <h3>Company Information</h3>

                <div class="quick-links">
                    <a
                        href="pages.php?page=about"
                        class="<?= $pageKey === 'about' ? 'active' : ''; ?>"
                    >
                        About Us
                        <i class="fa-solid fa-chevron-right"></i>
                    </a>

                    <a
                        href="pages.php?page=privacy"
                        class="<?= $pageKey === 'privacy' ? 'active' : ''; ?>"
                    >
                        Privacy Policy
                        <i class="fa-solid fa-chevron-right"></i>
                    </a>

                    <a
                        href="pages.php?page=terms"
                        class="<?= $pageKey === 'terms' ? 'active' : ''; ?>"
                    >
                        Terms &amp; Conditions
                        <i class="fa-solid fa-chevron-right"></i>
                    </a>
                </div>
            </div>

            <div class="sidebar-card">
                <h3>Need Assistance?</h3>

                <?php if ($officeAddress !== ''): ?>
                    <div class="contact-line">
                        <i class="fa-solid fa-location-dot"></i>
                        <span><?= e($officeAddress); ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($supportMobile !== ''): ?>
                    <div class="contact-line">
                        <i class="fa-solid fa-phone"></i>
                        <span><?= e($supportMobile); ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($supportEmail !== ''): ?>
                    <div class="contact-line">
                        <i class="fa-solid fa-envelope"></i>
                        <span><?= e($supportEmail); ?></span>
                    </div>
                <?php endif; ?>

                <div class="contact-line">
                    <i class="fa-solid fa-clock"></i>
                    <span><?= e($businessHours); ?></span>
                </div>
            </div>

        </aside>

    </div>
</section>

<footer class="footer">
    <div class="container">

        <div class="footer-grid">

            <div>
                <a href="index.php" class="logo">
                    <span class="logo-icon">
                        <i class="fa-solid fa-plane"></i>
                    </span>
                    TRAV<span>SCOPE</span>
                </a>

                <p class="footer-about">
                    <?= e($siteName); ?> helps travellers discover destinations,
                    holiday packages and personalized travel experiences.
                </p>

                <?php if (
                    $whatsappUrl !== ''
                    || $facebookUrl !== ''
                    || $instagramUrl !== ''
                    || $youtubeUrl !== ''
                    || $twitterUrl !== ''
                ): ?>
                    <div class="social-buttons">

                        <?php if ($whatsappUrl !== ''): ?>
                            <a
                                href="<?= e($whatsappUrl); ?>"
                                target="_blank"
                                rel="noopener"
                                class="social-button whatsapp"
                                aria-label="WhatsApp"
                            >
                                <i class="fa-brands fa-whatsapp"></i>
                            </a>
                        <?php endif; ?>

                        <?php if ($facebookUrl !== ''): ?>
                            <a
                                href="<?= e($facebookUrl); ?>"
                                target="_blank"
                                rel="noopener"
                                class="social-button facebook"
                                aria-label="Facebook"
                            >
                                <i class="fa-brands fa-facebook-f"></i>
                            </a>
                        <?php endif; ?>

                        <?php if ($instagramUrl !== ''): ?>
                            <a
                                href="<?= e($instagramUrl); ?>"
                                target="_blank"
                                rel="noopener"
                                class="social-button instagram"
                                aria-label="Instagram"
                            >
                                <i class="fa-brands fa-instagram"></i>
                            </a>
                        <?php endif; ?>

                        <?php if ($youtubeUrl !== ''): ?>
                            <a
                                href="<?= e($youtubeUrl); ?>"
                                target="_blank"
                                rel="noopener"
                                class="social-button youtube"
                                aria-label="YouTube"
                            >
                                <i class="fa-brands fa-youtube"></i>
                            </a>
                        <?php endif; ?>

                        <?php if ($twitterUrl !== ''): ?>
                            <a
                                href="<?= e($twitterUrl); ?>"
                                target="_blank"
                                rel="noopener"
                                class="social-button twitter"
                                aria-label="X"
                            >
                                <i class="fa-brands fa-x-twitter"></i>
                            </a>
                        <?php endif; ?>

                    </div>
                <?php endif; ?>
            </div>

            <div>
                <h4>Explore</h4>

                <div class="footer-links">
                    <a href="index.php#destinations">Destinations</a>
                    <a href="index.php#packages">Holiday Packages</a>
                    <a href="index.php#new">New Trips</a>
                    <a href="index.php#services">Services</a>
                </div>
            </div>

            <div>
                <h4>Company</h4>

                <div class="footer-links">
                    <a href="pages.php?page=about">About Us</a>
                    <a href="contact.php">Contact Us</a>
                    <a href="pages.php?page=privacy">Privacy Policy</a>
                    <a href="pages.php?page=terms">Terms &amp; Conditions</a>
                </div>
            </div>

            <div>
                <h4>Contact</h4>

                <?php if ($officeAddress !== ''): ?>
                    <p><?= e($officeAddress); ?></p>
                <?php endif; ?>

                <?php if ($supportMobile !== ''): ?>
                    <p><?= e($supportMobile); ?></p>
                <?php endif; ?>

                <?php if ($supportEmail !== ''): ?>
                    <p><?= e($supportEmail); ?></p>
                <?php endif; ?>

                <p><?= e($businessHours); ?></p>
            </div>

        </div>

        <div class="copyright">
            <span>
                © <?= e($currentYear); ?> <?= e($siteName); ?>.
                All rights reserved.
            </span>

            <span><?= e($siteTagline); ?></span>
        </div>

    </div>
</footer>

<?php if ($whatsappUrl !== ''): ?>
    <a
        href="<?= e($whatsappUrl); ?>"
        target="_blank"
        rel="noopener"
        class="floating-whatsapp"
        aria-label="Chat on WhatsApp"
    >
        <i class="fa-brands fa-whatsapp"></i>
    </a>
<?php endif; ?>

<script>
const menuButton = document.getElementById('menuButton');
const mobileMenu = document.getElementById('mobileMenu');

menuButton?.addEventListener('click', () => {
    mobileMenu?.classList.toggle('open');

    const icon = menuButton.querySelector('i');

    if (mobileMenu?.classList.contains('open')) {
        icon?.classList.remove('fa-bars');
        icon?.classList.add('fa-xmark');
        document.body.style.overflow = 'hidden';
    } else {
        icon?.classList.remove('fa-xmark');
        icon?.classList.add('fa-bars');
        document.body.style.overflow = '';
    }
});

mobileMenu?.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
        mobileMenu.classList.remove('open');
        document.body.style.overflow = '';

        const icon = menuButton?.querySelector('i');
        icon?.classList.remove('fa-xmark');
        icon?.classList.add('fa-bars');
    });
});

window.addEventListener('resize', () => {
    if (window.innerWidth > 1050) {
        mobileMenu?.classList.remove('open');
        document.body.style.overflow = '';

        const icon = menuButton?.querySelector('i');
        icon?.classList.remove('fa-xmark');
        icon?.classList.add('fa-bars');
    }
});
</script>


<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
