<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/billing-functions.php';

$id = max(0, (int)($_GET['receipt'] ?? 0));
if ($id <= 0 || !tsBillReady($pdo)) { http_response_code(404); exit('Payment receipt not found.'); }
$st = $pdo->prepare("SELECT r.*,b.user_id,b.booking_number,b.customer_name,b.customer_email,b.total_amount,b.paid_amount FROM booking_payment_receipts r JOIN bookings b ON b.id=r.booking_id WHERE r.id=? LIMIT 1");
$st->execute([$id]);
$r = $st->fetch(PDO::FETCH_ASSOC);
if (!$r) { http_response_code(404); exit('Payment receipt not found.'); }
$isAdmin = !empty($_SESSION['admin_id']);
$expires = (int)($_GET['expires'] ?? 0);
$token = trim((string)($_GET['token'] ?? ''));
$signed = tsBillReceiptEmailTokenValid($id, $expires, $token);
if (!$isAdmin && !$signed) {
    requireLogin();
    $u = currentUser($pdo);
    if (!$u || (int)$r['user_id'] !== (int)$u['id']) { http_response_code(403); exit('Access denied.'); }
}
if (strtolower((string)($_GET['format'] ?? '')) === 'pdf') {
    require_once __DIR__ . '/receipt-pdf-functions.php';
    try { $pdfBytes = tsBillVerifiedReceiptPdf($r, $pdo); }
    catch (Throwable $pdfError) { error_log('Payment receipt PDF render: '.$pdfError->getMessage()); http_response_code(500); exit('Unable to display the payment receipt PDF.'); }
    $receiptFileName = 'TRAVSCOPE-' . (preg_replace('/[^A-Za-z0-9_-]/', '-', (string)$r['receipt_code']) ?: ('receipt-' . $id)) . '.pdf';
    header('Content-Type: application/pdf');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store, max-age=0');
    header('Content-Disposition: ' . (!empty($_GET['download']) ? 'attachment' : 'inline') . '; filename="' . $receiptFileName . '"');
    header('Content-Length: ' . strlen($pdfBytes));
    echo $pdfBytes; exit;
}
$s = json_decode((string)$r['snapshot_json'], true); if(!is_array($s)) $s=[];
$company = tsBillTaxDefaults($pdo);
$companyHeader = trim((string)($company['header_name'] ?? 'Memorable Hospitality Pvt. Ltd.')) ?: 'Memorable Hospitality Pvt. Ltd.';
$ix = $pdo->prepare("SELECT id,invoice_code FROM booking_invoice_versions WHERE booking_id=? AND status='final' ORDER BY version_number DESC,id DESC LIMIT 1");
$ix->execute([(int)$r['booking_id']]); $inv=$ix->fetch(PDO::FETCH_ASSOC)?:[];
function mrE($v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function mrD($v): string { $x=$v?strtotime((string)$v):0; return $x?date('d M Y, h:i A',$x):'-'; }
$bal=isset($s['booking_balance'])?(float)$s['booking_balance']:max(0,(float)$r['total_amount']-(float)$r['paid_amount']);
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=mrE($r['receipt_code'])?> · Money Receipt</title>
<style>
*{box-sizing:border-box}html{-webkit-print-color-adjust:exact;print-color-adjust:exact}body{margin:0;background:#e9eef5;color:#111827;font-family:Arial,sans-serif}.tools{width:210mm;max-width:calc(100% - 24px);margin:14px auto 0;text-align:right}.tools button{border:0;border-radius:8px;padding:10px 14px;background:#0f172a;color:#fff;font-weight:800}.sheet{width:210mm;min-height:297mm;max-width:calc(100% - 24px);margin:10px auto 30px;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 16px 40px rgba(15,23,42,.1)}.bar{height:4px;background:linear-gradient(90deg,#0f172a,#2563eb,#06b6d4)}.head{padding:13px 15mm 11px;display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:16px;border-bottom:1px solid #dbe3ee}.brandidentity{display:grid;grid-template-columns:3in minmax(140px,1fr);align-items:center;gap:14px;min-width:0}.brandlogo{display:block;width:3in;max-width:3in;height:auto;max-height:1.05in;object-fit:contain;object-position:left center}.brand{font-size:14px;font-weight:900;line-height:1.2;color:#0f172a}.doc{text-align:right;min-width:130px}.doc h1{margin:0;font-size:21px;letter-spacing:.6px}.body{padding:10px 15mm 18mm}.small{font-size:9px;line-height:1.5}.muted{color:#64748b}.received{margin:8px 0 14px;padding:15px 18px;border:1px solid #a7f3d0;background:#ecfdf5;border-radius:10px;display:flex;justify-content:space-between;align-items:end;gap:16px}.received span{font-size:8px;text-transform:uppercase;color:#047857;font-weight:900}.received strong{display:block;color:#047857;font-size:26px;margin-top:4px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.box{padding:10px;border:1px solid #dbe3ee;border-radius:9px;background:#fff}.box span{font-size:7.5px;color:#64748b;text-transform:uppercase;font-weight:900}.box strong{display:block;font-size:10px;margin-top:3px}.section-title{font-size:9px;text-transform:uppercase;letter-spacing:.6px;font-weight:900;color:#0f172a;margin:14px 0 7px;padding-bottom:6px;border-bottom:1px solid #dbe3ee}.summary{margin-top:12px;border-top:1px solid #e5e7eb}.row{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #e5e7eb;font-size:10px}.row.balance{font-size:12px;font-weight:900;background:#f8fafc;padding:9px}.words{margin-top:12px;padding:9px;background:#f8fafc;border-radius:8px;font-size:9px}.links{margin-top:12px;display:flex;gap:8px;flex-wrap:wrap}.link{padding:8px 11px;border-radius:7px;background:#0f172a;color:#fff;text-decoration:none;font-size:9px;font-weight:800}.link.blue{background:#2563eb}.sign{text-align:right;margin-top:28px;font-size:9px}.foot{text-align:center;border-top:1px solid #e5e7eb;padding:8px;color:#64748b;font-size:8px}@media(max-width:720px){.sheet,.tools{width:auto;max-width:calc(100% - 16px)}.brandidentity{grid-template-columns:1fr}.brandlogo{width:min(3in,100%);max-width:100%}.head{grid-template-columns:1fr;padding:14px}.doc{text-align:left}.grid{grid-template-columns:1fr}.body{padding:10px 14px 22px}.received{display:block}}@page{size:A4 portrait;margin:12mm}@media print{body{background:#fff}.tools,.links{display:none}.sheet{width:auto;max-width:none;min-height:273mm;margin:0;border-radius:0;box-shadow:none}.head{padding:4mm 2mm 3mm}.body{padding:4mm 2mm 12mm}.foot{position:fixed;left:0;right:0;bottom:0;background:#fff}.bar{height:1.2mm}}
</style>
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head><body>
<div class="tools"><button onclick="window.print()">Print / Save A4 PDF</button></div>
<main class="sheet"><div class="bar"></div>
<header class="head"><div class="brandidentity"><?php if(!empty($company['logo_url'])):?><img class="brandlogo" src="<?=mrE($company['logo_url'])?>" alt="Travscope document logo"><?php endif;?><div><div class="brand"><?=mrE($companyHeader)?></div><div class="small" style="font-weight:800;margin-top:3px">Trade Name: <?=mrE($company['trade_name']??'Travscope')?></div><div class="small muted" style="margin-top:3px"><?=mrE($company['legal_name']??'MEMORABLE HOSPITALITY PRIVATE LIMITED')?></div><div class="small muted" style="margin-top:4px"><?php if(!empty($company['gstin'])):?>GSTIN: <strong><?=mrE($company['gstin'])?></strong><?php endif;?><?php if(!empty($company['pan'])):?> · PAN: <strong><?=mrE($company['pan'])?></strong><?php endif;?></div></div></div><div class="doc"><h1>MONEY RECEIPT</h1><div class="small" style="margin-top:6px"><strong><?=mrE($r['receipt_code'])?></strong><br><?=mrE(mrD($r['paid_at']))?></div></div></header>
<div class="body"><div class="small muted" style="margin-bottom:8px"><?=mrE($company['address']??'')?><?php if(!empty($company['email'])):?> · <?=mrE($company['email'])?><?php endif;?><?php if(!empty($company['phone'])):?> · <?=mrE($company['phone'])?><?php endif;?></div>
<div class="received"><div><span>Verified Amount Received</span><strong><?=mrE($r['currency'])?> <?=number_format((float)$r['amount'],2)?></strong></div><div class="small muted">Approved customer payment<br><?=mrE(mrD($r['paid_at']))?></div></div>
<div class="section-title">Customer & Booking</div><div class="grid"><div class="box"><span>Received From</span><strong><?=mrE($r['customer_name'])?></strong><div class="small muted" style="margin-top:3px"><?=mrE($r['customer_email']??'')?></div></div><div class="box"><span>Booking Number</span><strong><?=mrE($r['booking_number'])?></strong><?php if(!empty($inv['invoice_code'])):?><div class="small muted" style="margin-top:3px">Invoice: <?=mrE($inv['invoice_code'])?></div><?php endif;?></div></div>
<div class="section-title">Payment Information</div><div class="grid"><div class="box"><span>Payment Mode</span><strong><?=mrE($r['payment_method']?:'-')?></strong></div><div class="box"><span>Transaction / UTR</span><strong><?=mrE($r['transaction_id']?:'-')?></strong></div><div class="box"><span>Against</span><strong><?=mrE($r['installment_summary']?:'Booking Payment')?></strong></div><div class="box"><span>Receipt Date</span><strong><?=mrE(mrD($r['paid_at']))?></strong></div></div>
<div class="section-title">Booking Payment Summary</div><div class="summary"><div class="row"><span>Current Booking / Invoice Payable</span><strong><?=mrE($r['currency'])?> <?=number_format((float)$r['total_amount'],2)?></strong></div><div class="row"><span>Total Verified Paid</span><strong><?=mrE($r['currency'])?> <?=number_format((float)$r['paid_amount'],2)?></strong></div><div class="row balance"><span>Outstanding Balance</span><strong><?=mrE($r['currency'])?> <?=number_format($bal,2)?></strong></div></div>
<div class="words"><strong>Received amount in words:</strong> <?=mrE(tsBillMoneyWords((float)$r['amount']))?></div><div class="links"><?php if(!empty($inv['id'])):?><a class="link blue" href="<?=mrE(tsBillInvoiceEmailUrl((int)$inv['id'],90))?>">View Tax Invoice</a><?php endif;?></div><div class="sign">For <strong><?=mrE($company['legal_name']??'MEMORABLE HOSPITALITY PRIVATE LIMITED')?></strong><br><br><br>Authorised Signatory</div></div>
<div class="foot">This money receipt confirms a verified payment recorded against the booking. It is not a substitute for a statutory tax invoice.</div></main>
<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script></body></html>
