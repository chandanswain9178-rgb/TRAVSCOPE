<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
if (is_file(__DIR__ . '/supplier-functions.php')) require_once __DIR__ . '/supplier-functions.php';
if (is_file(__DIR__ . '/location-master-functions.php')) require_once __DIR__ . '/location-master-functions.php';
if (is_file(__DIR__ . '/hotel-google-places-functions.php')) require_once __DIR__ . '/hotel-google-places-functions.php';

if (empty($_SESSION['admin_id'])) redirect(BASE_URL . 'admin-login.php');
$adminId = (int)$_SESSION['admin_id'];
$stmt = $pdo->prepare("SELECT id,name,email,role,status FROM admins WHERE id=? LIMIT 1");
$stmt->execute([$adminId]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$admin || (string)($admin['status'] ?? '') !== 'active') {
    unset($_SESSION['admin_id']);
    redirect(BASE_URL . 'admin-login.php');
}

if (!function_exists('e')) {
    function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
}

function hmTable(PDO $pdo, string $table): bool {
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
    try {
        $st=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");
        $st->execute([$table]);
        if ((int)$st->fetchColumn()>0) return true;
    } catch (Throwable $ignored) {}
    try { $pdo->query('SELECT 1 FROM `'.$table.'` LIMIT 0'); return true; } catch (Throwable $ignored) {}
    return false;
}
function hmColumn(PDO $pdo, string $table, string $column): bool {
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) return false;
    try {
        $st=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?");
        $st->execute([$table,$column]);
        if ((int)$st->fetchColumn()>0) return true;
    } catch (Throwable $ignored) {}
    try {
        $pdo->query("SELECT `{$column}` FROM `{$table}` LIMIT 0");
        return true;
    } catch (Throwable $ignored) { return false; }
}
function hmIndex(PDO $pdo, string $table, string $index): bool {
    try {
        $st=$pdo->prepare("SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name=? AND index_name=?");
        $st->execute([$table,$index]);
        return (int)$st->fetchColumn()>0;
    } catch (Throwable $ignored) { return false; }
}
function hmAddColumn(PDO $pdo, string $name, string $sql): void {
    if (!hmColumn($pdo,'hotels',$name)) $pdo->exec("ALTER TABLE hotels ADD COLUMN {$sql}");
}
function hmEnsureProSchema(PDO $pdo): void {
    if (function_exists('tsLocationEnsureSchema')) tsLocationEnsureSchema($pdo);
    if (!hmTable($pdo,'hotels')) {
        $pdo->exec("CREATE TABLE hotels (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            destination_id BIGINT UNSIGNED NOT NULL,
            location_id BIGINT UNSIGNED DEFAULT NULL,
            hotel_name VARCHAR(190) NOT NULL,
            city VARCHAR(120) DEFAULT NULL,
            star_category TINYINT UNSIGNED NOT NULL,
            default_room_type VARCHAR(120) DEFAULT NULL,
            default_meal_plan VARCHAR(120) DEFAULT NULL,
            preferred_supplier_id BIGINT UNSIGNED DEFAULT NULL,
            source_rate_card_id BIGINT UNSIGNED DEFAULT NULL,
            is_preferred TINYINT(1) NOT NULL DEFAULT 0,
            priority_order INT NOT NULL DEFAULT 100,
            status ENUM('active','inactive') NOT NULL DEFAULT 'active',
            source ENUM('manual','supplier_rate') NOT NULL DEFAULT 'manual',
            notes TEXT DEFAULT NULL,
            created_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
            updated_by_admin_id BIGINT UNSIGNED DEFAULT NULL,
            created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(id),
            UNIQUE KEY uq_hotel_destination_location_name_star(destination_id,location_id,hotel_name,star_category),
            KEY idx_hotel_destination_star(destination_id,star_category,status,is_preferred,priority_order),
            KEY idx_hotel_location(destination_id,location_id,star_category,status,is_preferred)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    hmAddColumn($pdo,'primary_image',"primary_image VARCHAR(255) DEFAULT NULL AFTER default_meal_plan");
    hmAddColumn($pdo,'address',"address VARCHAR(255) DEFAULT NULL AFTER primary_image");
    hmAddColumn($pdo,'area',"area VARCHAR(150) DEFAULT NULL AFTER address");
    hmAddColumn($pdo,'pincode',"pincode VARCHAR(20) DEFAULT NULL AFTER area");
    hmAddColumn($pdo,'phone',"phone VARCHAR(50) DEFAULT NULL AFTER pincode");
    hmAddColumn($pdo,'email',"email VARCHAR(190) DEFAULT NULL AFTER phone");
    hmAddColumn($pdo,'website',"website VARCHAR(255) DEFAULT NULL AFTER email");
    hmAddColumn($pdo,'google_maps_url',"google_maps_url VARCHAR(1000) DEFAULT NULL AFTER website");
    hmAddColumn($pdo,'latitude',"latitude DECIMAL(10,7) DEFAULT NULL AFTER google_maps_url");
    hmAddColumn($pdo,'longitude',"longitude DECIMAL(10,7) DEFAULT NULL AFTER latitude");
    hmAddColumn($pdo,'description',"description TEXT DEFAULT NULL AFTER longitude");
    hmAddColumn($pdo,'geo_country',"geo_country VARCHAR(150) DEFAULT NULL AFTER description");
    hmAddColumn($pdo,'geo_state',"geo_state VARCHAR(150) DEFAULT NULL AFTER geo_country");
    hmAddColumn($pdo,'geo_city',"geo_city VARCHAR(150) DEFAULT NULL AFTER geo_state");
    hmAddColumn($pdo,'check_in_time',"check_in_time TIME DEFAULT NULL AFTER geo_city");
    hmAddColumn($pdo,'check_out_time',"check_out_time TIME DEFAULT NULL AFTER check_in_time");
    hmAddColumn($pdo,'google_place_id',"google_place_id VARCHAR(255) DEFAULT NULL AFTER check_out_time");
    hmAddColumn($pdo,'google_rating',"google_rating DECIMAL(3,2) DEFAULT NULL AFTER google_place_id");
    hmAddColumn($pdo,'google_user_ratings_total',"google_user_ratings_total INT UNSIGNED DEFAULT NULL AFTER google_rating");
    hmAddColumn($pdo,'google_place_synced_at',"google_place_synced_at DATETIME DEFAULT NULL AFTER google_user_ratings_total");
    if (!hmIndex($pdo,'hotels','idx_hotel_name_search')) {
        try {$pdo->exec("ALTER TABLE hotels ADD KEY idx_hotel_name_search (hotel_name,city,status)");} catch(Throwable $ignored) {}
    }
    if (!hmIndex($pdo,'hotels','idx_hotel_geo')) {
        try {$pdo->exec("ALTER TABLE hotels ADD KEY idx_hotel_geo (geo_country,geo_state,geo_city,status)");} catch(Throwable $ignored) {}
    }
    if (!hmIndex($pdo,'hotels','idx_hotel_google_place')) {
        try {$pdo->exec("ALTER TABLE hotels ADD UNIQUE KEY idx_hotel_google_place (google_place_id)");} catch(Throwable $ignored) {}
    }
    $pdo->exec("CREATE TABLE IF NOT EXISTS hotel_images (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        hotel_id BIGINT UNSIGNED NOT NULL,
        image_path VARCHAR(255) NOT NULL,
        alt_text VARCHAR(255) DEFAULT NULL,
        is_primary TINYINT(1) NOT NULL DEFAULT 0,
        sort_order INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(id),
        UNIQUE KEY uq_hotel_image(hotel_id,image_path),
        KEY idx_hotel_images(hotel_id,is_primary,sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}
function hmStar(string $v): int {
    $v=strtolower(trim($v));
    if (preg_match('/(?:^|\D)([345])\s*(?:star|\*|★)?/u',$v,$m)) return (int)$m[1];
    if (preg_match('/\b([345])\b/u',$v,$m)) return (int)$m[1];
    return 0;
}
function hmPriority(string $p): int { return match(strtolower(trim($p))){'preferred'=>10,'regular'=>50,'backup'=>90,default=>100}; }
function hmRebuildPreferred(PDO $pdo): void {
    if (!hmTable($pdo,'hotels')) return;
    $groups=$pdo->query("SELECT DISTINCT destination_id,COALESCE(location_id,0) location_key,TRIM(COALESCE(city,'')) city,star_category FROM hotels WHERE status='active'")->fetchAll(PDO::FETCH_ASSOC)?:[];
    foreach($groups as $g){
        if((int)$g['location_key']>0){
            $pdo->prepare("UPDATE hotels SET is_preferred=0 WHERE destination_id=? AND location_id=? AND star_category=?")->execute([(int)$g['destination_id'],(int)$g['location_key'],(int)$g['star_category']]);
            $q=$pdo->prepare("SELECT id FROM hotels WHERE destination_id=? AND location_id=? AND star_category=? AND status='active' ORDER BY priority_order,id LIMIT 1");
            $q->execute([(int)$g['destination_id'],(int)$g['location_key'],(int)$g['star_category']]);
        }else{
            $pdo->prepare("UPDATE hotels SET is_preferred=0 WHERE destination_id=? AND LOWER(TRIM(COALESCE(city,'')))=LOWER(TRIM(?)) AND star_category=?")->execute([(int)$g['destination_id'],(string)$g['city'],(int)$g['star_category']]);
            $q=$pdo->prepare("SELECT id FROM hotels WHERE destination_id=? AND LOWER(TRIM(COALESCE(city,'')))=LOWER(TRIM(?)) AND star_category=? AND status='active' ORDER BY priority_order,id LIMIT 1");
            $q->execute([(int)$g['destination_id'],(string)$g['city'],(int)$g['star_category']]);
        }
        $id=(int)($q->fetchColumn()?:0);
        if($id>0)$pdo->prepare("UPDATE hotels SET is_preferred=1 WHERE id=?")->execute([$id]);
    }
}
function hmMakePreferred(PDO $pdo, int $hotelId, int $adminId): void {
    $st=$pdo->prepare("SELECT destination_id,location_id,city,star_category FROM hotels WHERE id=? LIMIT 1");
    $st->execute([$hotelId]);$h=$st->fetch(PDO::FETCH_ASSOC);
    if(!$h) return;
    if((int)($h['location_id']??0)>0){
        $pdo->prepare("UPDATE hotels SET is_preferred=0 WHERE destination_id=? AND location_id=? AND star_category=?")->execute([(int)$h['destination_id'],(int)$h['location_id'],(int)$h['star_category']]);
    }else{
        $pdo->prepare("UPDATE hotels SET is_preferred=0 WHERE destination_id=? AND LOWER(TRIM(COALESCE(city,'')))=LOWER(TRIM(?)) AND star_category=?")->execute([(int)$h['destination_id'],(string)$h['city'],(int)$h['star_category']]);
    }
    $pdo->prepare("UPDATE hotels SET is_preferred=1,priority_order=0,updated_by_admin_id=?,updated_at=NOW() WHERE id=?")->execute([$adminId,$hotelId]);
}
function hmUpsertSupplier(PDO $pdo,array $r,int $adminId):array{
    $star=(int)($r['star']??0);$name=trim((string)($r['hotel_name']??''));$supplierId=(int)($r['supplier_id']??0);$city=trim((string)($r['city']??''));$dest=(int)($r['destination_id']??0);
    if($dest<=0||$name===''||$city===''||!in_array($star,[3,4,5],true))return['id'=>0,'created'=>0,'updated'=>0];
    $priority=hmPriority((string)($r['supplier_priority']??''));
    $locationId=function_exists('tsLocationUpsert')?tsLocationUpsert($pdo,$dest,$city,'supplier',$adminId):0;
    $f=$pdo->prepare("SELECT id,priority_order,source FROM hotels WHERE destination_id=? AND COALESCE(location_id,0)=? AND LOWER(TRIM(hotel_name))=LOWER(TRIM(?)) AND star_category=? LIMIT 1");
    $f->execute([$dest,$locationId,$name,$star]);$ex=$f->fetch(PDO::FETCH_ASSOC);
    if($ex){
        $id=(int)$ex['id'];
        $pdo->prepare("UPDATE hotels SET city=COALESCE(NULLIF(?,''),city),location_id=COALESCE(?,location_id),default_room_type=COALESCE(NULLIF(?,''),default_room_type),default_meal_plan=COALESCE(NULLIF(?,''),default_meal_plan),preferred_supplier_id=CASE WHEN ?<=priority_order THEN ? ELSE preferred_supplier_id END,priority_order=LEAST(priority_order,?),status='active',source=IF(source='manual','manual','supplier_rate'),notes=COALESCE(notes,?),updated_by_admin_id=? WHERE id=?")
            ->execute([$city,$locationId?:null,trim((string)($r['room_type']??'')),trim((string)($r['meal_plan']??'')),$priority,$supplierId?:null,$priority,'Synchronized from supplier location-wise inventory.',$adminId,$id]);
        return['id'=>$id,'created'=>0,'updated'=>1];
    }
    $pdo->prepare("INSERT INTO hotels(destination_id,location_id,hotel_name,city,star_category,default_room_type,default_meal_plan,preferred_supplier_id,source_rate_card_id,is_preferred,priority_order,status,source,notes,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,0,?,'active','supplier_rate',?,?,?)")
        ->execute([$dest,$locationId?:null,$name,$city,$star,trim((string)($r['room_type']??''))?:null,trim((string)($r['meal_plan']??''))?:null,$supplierId?:null,!empty($r['rate_card_id'])?(int)$r['rate_card_id']:null,$priority,'Synchronized from supplier location-wise inventory.',$adminId,$adminId]);
    return['id'=>(int)$pdo->lastInsertId(),'created'=>1,'updated'=>0];
}
function hmSync(PDO $pdo,int $adminId):array{
    $out=['created'=>0,'updated'=>0,'mapped'=>0,'skipped'=>0];
    if(hmTable($pdo,'supplier_hotel_options')){
        try{
            $rows=$pdo->query("SELECT o.*,s.priority supplier_priority FROM supplier_hotel_options o JOIN suppliers s ON s.id=o.supplier_id WHERE o.status='active' AND o.mapped_star_category IN(3,4,5) AND TRIM(COALESCE(o.hotel_name,''))<>'' ORDER BY o.id")->fetchAll(PDO::FETCH_ASSOC)?:[];
            foreach($rows as $r){
                $x=hmUpsertSupplier($pdo,['star'=>(int)$r['mapped_star_category'],'hotel_name'=>$r['hotel_name'],'supplier_id'=>$r['supplier_id'],'supplier_priority'=>$r['supplier_priority'],'city'=>$r['city'],'destination_id'=>$r['destination_id'],'room_type'=>$r['room_type'],'meal_plan'=>$r['meal_plan']],$adminId);
                if(!$x['id']){$out['skipped']++;continue;}$out['created']+=$x['created'];$out['updated']+=$x['updated'];
                if((int)($r['hotel_id']??0)!==$x['id']){try{$pdo->prepare("UPDATE supplier_hotel_options SET hotel_id=?,updated_by_admin_id=?,updated_at=NOW() WHERE id=?")->execute([$x['id'],$adminId,(int)$r['id']]);$out['mapped']++;}catch(Throwable $ignored){}}
            }
        }catch(Throwable $ignored){}
    }
    if(hmTable($pdo,'supplier_contract_hotel_inventory')){
        try{
            $rows=$pdo->query("SELECT h.*,s.priority supplier_priority FROM supplier_contract_hotel_inventory h JOIN suppliers s ON s.id=h.supplier_id WHERE h.mapped_star_category IN(3,4,5) AND TRIM(COALESCE(h.hotel_name,''))<>'' ORDER BY h.id")->fetchAll(PDO::FETCH_ASSOC)?:[];
            foreach($rows as $r){
                $x=hmUpsertSupplier($pdo,['star'=>(int)$r['mapped_star_category'],'hotel_name'=>$r['hotel_name'],'supplier_id'=>$r['supplier_id'],'supplier_priority'=>$r['supplier_priority'],'city'=>$r['city'],'destination_id'=>$r['destination_id'],'room_type'=>$r['room_type'],'meal_plan'=>$r['meal_plan']],$adminId);
                if(!$x['id']){$out['skipped']++;continue;}$out['created']+=$x['created'];$out['updated']+=$x['updated'];
                if((int)($r['hotel_id']??0)!==$x['id']){try{$pdo->prepare("UPDATE supplier_contract_hotel_inventory SET hotel_id=?,mapping_status=CASE WHEN hotel_id IS NULL THEN 'created' ELSE 'matched' END,updated_by_admin_id=?,updated_at=NOW() WHERE id=?")->execute([$x['id'],$adminId,(int)$r['id']]);$out['mapped']++;}catch(Throwable $ignored){}}
            }
        }catch(Throwable $ignored){}
    }
    if(hmTable($pdo,'supplier_rate_cards')){
        try{
            $hasRateCity=hmColumn($pdo,'supplier_rate_cards','location_city');
            $cityExpr=$hasRateCity?"COALESCE(NULLIF(rc.location_city,''),s.city)":"s.city";
            $rows=$pdo->query("SELECT rc.id rate_card_id,rc.destination_id,rc.supplier_id,rc.property_name hotel_name,rc.hotel_category,rc.room_type,rc.meal_plan,s.priority supplier_priority,{$cityExpr} rate_city FROM supplier_rate_cards rc JOIN suppliers s ON s.id=rc.supplier_id WHERE rc.status='active' AND s.status='active' AND rc.destination_id IS NOT NULL AND TRIM(COALESCE(rc.property_name,''))<>'' ORDER BY rc.id")->fetchAll(PDO::FETCH_ASSOC)?:[];
            foreach($rows as $r){$star=hmStar((string)$r['hotel_category']);if(!$star){$out['skipped']++;continue;}$x=hmUpsertSupplier($pdo,['star'=>$star,'hotel_name'=>$r['hotel_name'],'supplier_id'=>$r['supplier_id'],'supplier_priority'=>$r['supplier_priority'],'city'=>$r['rate_city'],'destination_id'=>$r['destination_id'],'room_type'=>$r['room_type'],'meal_plan'=>$r['meal_plan'],'rate_card_id'=>$r['rate_card_id']],$adminId);$out['created']+=$x['created'];$out['updated']+=$x['updated'];}
        }catch(Throwable $ignored){}
    }
    hmRebuildPreferred($pdo);return$out;
}
function hmUploadOne(array $file): ?string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) throw new RuntimeException('Hotel photo upload failed.');
    if ((int)($file['size'] ?? 0) <= 0 || (int)$file['size'] > 8*1024*1024) throw new RuntimeException('Each hotel photo must be below 8 MB.');
    $tmp=(string)($file['tmp_name']??'');
    $finfo=new finfo(FILEINFO_MIME_TYPE);$mime=(string)$finfo->file($tmp);
    $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if(!isset($allowed[$mime])) throw new RuntimeException('Hotel photos must be JPG, PNG or WEBP.');
    $dir=__DIR__.'/uploads/hotels/';if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Unable to create hotel photo folder.');
    $name='hotel-'.date('Ymd-His').'-'.bin2hex(random_bytes(5)).'.'.$allowed[$mime];
    if(!move_uploaded_file($tmp,$dir.$name))throw new RuntimeException('Unable to save hotel photo.');
    return 'uploads/hotels/'.$name;
}
function hmUploadMany(array $files): array {
    $saved=[];
    if(empty($files['name'])||!is_array($files['name'])) return $saved;
    $count=min(count($files['name']),10);
    for($i=0;$i<$count;$i++){
        $file=['name'=>$files['name'][$i]??'','type'=>$files['type'][$i]??'','tmp_name'=>$files['tmp_name'][$i]??'','error'=>$files['error'][$i]??UPLOAD_ERR_NO_FILE,'size'=>$files['size'][$i]??0];
        $p=hmUploadOne($file);if($p)$saved[]=$p;
    }
    return $saved;
}
function hmAttachImages(PDO $pdo,int $hotelId,array $paths,string $hotelName):void{
    if(!$paths)return;
    $mx=$pdo->prepare("SELECT COALESCE(MAX(sort_order),0) FROM hotel_images WHERE hotel_id=?");$mx->execute([$hotelId]);$sort=(int)$mx->fetchColumn();
    $q=$pdo->prepare("SELECT COUNT(*) FROM hotel_images WHERE hotel_id=? AND is_primary=1");$q->execute([$hotelId]);$primaryExists=(int)$q->fetchColumn()>0;
    $ins=$pdo->prepare("INSERT INTO hotel_images(hotel_id,image_path,alt_text,is_primary,sort_order) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE alt_text=VALUES(alt_text)");
    foreach($paths as $idx=>$path){$isPrimary=(!$primaryExists && $idx===0)?1:0;$ins->execute([$hotelId,$path,$hotelName,$isPrimary,++$sort]);if($isPrimary){$pdo->prepare("UPDATE hotels SET primary_image=? WHERE id=?")->execute([$path,$hotelId]);$primaryExists=true;}}
}
function hmSafeDeleteImageFile(string $path): void {
    $path=ltrim(trim($path),'/');
    if(!str_starts_with($path,'uploads/hotels/')) return;
    $full=__DIR__.'/'.$path;
    if(is_file($full)) @unlink($full);
}

if(empty($_SESSION['admin_hotel_csrf']))$_SESSION['admin_hotel_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['admin_hotel_csrf'];
$success=(string)($_SESSION['admin_hotel_success']??'');
$error=(string)($_SESSION['admin_hotel_error']??'');
unset($_SESSION['admin_hotel_success'],$_SESSION['admin_hotel_error']);

try { hmEnsureProSchema($pdo); } catch(Throwable $e) { $error='Hotel Master setup failed: '.$e->getMessage(); }

if ($_SERVER['REQUEST_METHOD']==='POST' && hmTable($pdo,'hotels')) {
    try {
        if(!hash_equals($csrf,(string)($_POST['csrf_token']??'')))throw new RuntimeException('Security verification failed. Refresh and try again.');
        $action=(string)($_POST['action']??'');
        if($action==='sync_supplier_rates'){
            $r=hmSync($pdo,$adminId);$_SESSION['admin_hotel_success']="Supplier hotel refresh complete: {$r['created']} added, {$r['updated']} refreshed, {$r['mapped']} inventory rows linked.";redirect(BASE_URL.'admin-hotels.php');
        }
        if(in_array($action,['create_hotel','update_hotel'],true)){
            $hotelId=$action==='update_hotel'?max(0,(int)($_POST['hotel_id']??0)):0;
            $destinationId=max(0,(int)($_POST['destination_id']??0));
            $locationId=0;
            $geoCountry=trim((string)($_POST['geo_country']??''));
            $geoState=trim((string)($_POST['geo_state']??''));
            $geoCity=trim((string)($_POST['geo_city']??''));
            $hotelName=trim((string)($_POST['hotel_name']??''));
            $googlePlaceId=trim((string)($_POST['google_place_id']??''));
            $googleRatingRaw=trim((string)($_POST['google_rating']??''));
            $googleRating=($googleRatingRaw!==''&&is_numeric($googleRatingRaw))?max(0,min(5,(float)$googleRatingRaw)):null;
            $googleRatingsTotal=max(0,(int)($_POST['google_user_ratings_total']??0));
            $star=(int)($_POST['star_category']??0);
            if($destinationId<=0)throw new RuntimeException('Choose a destination from Destination Master.');
            if($hotelName==='')throw new RuntimeException('Enter hotel name.');
            if(!in_array($star,[3,4,5],true))throw new RuntimeException('Choose 3, 4 or 5 star category.');

            /*
             * V20.4: the selected Hotel City is automatically registered as a
             * child location of the matched Destination. There is still no
             * separate "Add Location" step in Hotel Master: choosing the city
             * once is enough. This keeps Hotel Master -> Package Master ->
             * Quotation on the same destination/location IDs.
             */
            $locationName=$geoCity;
            if($locationName===''){
                $ds=$pdo->prepare("SELECT name FROM destinations WHERE id=? LIMIT 1");
                $ds->execute([$destinationId]);
                $locationName=trim((string)($ds->fetchColumn()?:''));
            }

            if($geoCity!=='' && function_exists('tsLocationUpsert')){
                try {
                    $locationId=tsLocationUpsert($pdo,$destinationId,$geoCity,'hotel_auto',$adminId);
                } catch (Throwable $ignored) {
                    $locationId=0;
                }
            }

            if($locationId<=0 && $geoCity!==''){
                try {
                    $ls=$pdo->prepare("SELECT id,location_name FROM destination_locations WHERE destination_id=? AND status='active' AND LOWER(TRIM(location_name))=LOWER(TRIM(?)) ORDER BY id LIMIT 1");
                    $ls->execute([$destinationId,$geoCity]);
                    if($matchedLocation=$ls->fetch(PDO::FETCH_ASSOC)){
                        $locationId=(int)$matchedLocation['id'];
                        $locationName=trim((string)$matchedLocation['location_name']);
                    }
                } catch (Throwable $ignored) {}
            } elseif($locationId>0) {
                try {
                    $ls=$pdo->prepare("SELECT location_name FROM destination_locations WHERE id=? LIMIT 1");
                    $ls->execute([$locationId]);
                    $savedName=trim((string)($ls->fetchColumn()?:''));
                    if($savedName!=='')$locationName=$savedName;
                } catch (Throwable $ignored) {}
            }

            $locationDbId=$locationId>0?$locationId:null;

            if($googlePlaceId!==''){
                $gpDup=$pdo->prepare("SELECT id FROM hotels WHERE google_place_id=? AND id<>? LIMIT 1");
                $gpDup->execute([$googlePlaceId,$hotelId]);
                $existingGoogleHotel=(int)($gpDup->fetchColumn()?:0);
                if($existingGoogleHotel>0)throw new RuntimeException('This Google hotel is already in Hotel Master. Open the existing hotel instead of adding a duplicate.');
            }
            $dup=$pdo->prepare("SELECT id FROM hotels WHERE destination_id=? AND COALESCE(location_id,0)=? AND LOWER(TRIM(hotel_name))=LOWER(TRIM(?)) AND star_category=? AND id<>? LIMIT 1");
            $dup->execute([$destinationId,$locationId,$hotelName,$star,$hotelId]);
            if((int)($dup->fetchColumn()?:0)>0)throw new RuntimeException('This hotel already exists for the same destination/city and category.');
            $fields=[
                'city'=>$locationName,
                'default_room_type'=>trim((string)($_POST['default_room_type']??'')),
                'default_meal_plan'=>trim((string)($_POST['default_meal_plan']??'')),
                'address'=>trim((string)($_POST['address']??'')),
                'area'=>trim((string)($_POST['area']??'')),
                'pincode'=>trim((string)($_POST['pincode']??'')),
                'phone'=>trim((string)($_POST['phone']??'')),
                'email'=>trim((string)($_POST['email']??'')),
                'website'=>trim((string)($_POST['website']??'')),
                'google_maps_url'=>trim((string)($_POST['google_maps_url']??'')),
                'description'=>trim((string)($_POST['description']??'')),
                'notes'=>trim((string)($_POST['notes']??'')),
                'check_in_time'=>trim((string)($_POST['check_in_time']??'')),
                'check_out_time'=>trim((string)($_POST['check_out_time']??'')),
            ];
            foreach(['check_in_time','check_out_time'] as $timeKey){if($fields[$timeKey]!==''&&!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/',$fields[$timeKey]))throw new RuntimeException('Use HH:MM format for hotel check-in/check-out time.');}
            $latitude=trim((string)($_POST['latitude']??''));$longitude=trim((string)($_POST['longitude']??''));
            if($latitude!==''&&(!is_numeric($latitude)||(float)$latitude<-90||(float)$latitude>90))throw new RuntimeException('Latitude must be between -90 and 90.');
            if($longitude!==''&&(!is_numeric($longitude)||(float)$longitude<-180||(float)$longitude>180))throw new RuntimeException('Longitude must be between -180 and 180.');
            $supplierId=max(0,(int)($_POST['preferred_supplier_id']??0));
            $priority=max(0,min(999,(int)($_POST['priority_order']??50)));
            $status=in_array((string)($_POST['status']??'active'),['active','inactive'],true)?(string)$_POST['status']:'active';
            if($hotelId>0){
                $st=$pdo->prepare("UPDATE hotels SET destination_id=?,location_id=?,hotel_name=?,city=?,star_category=?,default_room_type=?,default_meal_plan=?,address=?,area=?,pincode=?,phone=?,email=?,website=?,google_maps_url=?,latitude=?,longitude=?,description=?,geo_country=?,geo_state=?,geo_city=?,check_in_time=?,check_out_time=?,preferred_supplier_id=?,priority_order=?,status=?,source='manual',notes=?,updated_by_admin_id=?,updated_at=NOW() WHERE id=?");
                $st->execute([$destinationId,$locationDbId,$hotelName,$fields['city'],$star,$fields['default_room_type']?:null,$fields['default_meal_plan']?:null,$fields['address']?:null,$fields['area']?:null,$fields['pincode']?:null,$fields['phone']?:null,$fields['email']?:null,$fields['website']?:null,$fields['google_maps_url']?:null,$latitude!==''?(float)$latitude:null,$longitude!==''?(float)$longitude:null,$fields['description']?:null,$geoCountry?:null,$geoState?:null,$geoCity?:null,$fields['check_in_time']?:null,$fields['check_out_time']?:null,$supplierId?:null,$priority,$status,$fields['notes']?:null,$adminId,$hotelId]);
            }else{
                $st=$pdo->prepare("INSERT INTO hotels(destination_id,location_id,hotel_name,city,star_category,default_room_type,default_meal_plan,address,area,pincode,phone,email,website,google_maps_url,latitude,longitude,description,geo_country,geo_state,geo_city,check_in_time,check_out_time,preferred_supplier_id,is_preferred,priority_order,status,source,notes,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,'manual',?,?,?)");
                $st->execute([$destinationId,$locationDbId,$hotelName,$fields['city'],$star,$fields['default_room_type']?:null,$fields['default_meal_plan']?:null,$fields['address']?:null,$fields['area']?:null,$fields['pincode']?:null,$fields['phone']?:null,$fields['email']?:null,$fields['website']?:null,$fields['google_maps_url']?:null,$latitude!==''?(float)$latitude:null,$longitude!==''?(float)$longitude:null,$fields['description']?:null,$geoCountry?:null,$geoState?:null,$geoCity?:null,$fields['check_in_time']?:null,$fields['check_out_time']?:null,$supplierId?:null,$priority,$status,$fields['notes']?:null,$adminId,$adminId]);
                $hotelId=(int)$pdo->lastInsertId();
            }
            $gUpdate=$pdo->prepare("UPDATE hotels SET google_place_id=?,google_rating=?,google_user_ratings_total=?,google_place_synced_at=? WHERE id=?");
            $gUpdate->execute([$googlePlaceId!==''?$googlePlaceId:null,$googleRating,$googleRatingsTotal>0?$googleRatingsTotal:null,$googlePlaceId!==''?date('Y-m-d H:i:s'):null,$hotelId]);
            $paths=hmUploadMany($_FILES['hotel_photos']??[]);hmAttachImages($pdo,$hotelId,$paths,$hotelName);
            if(!empty($_POST['make_preferred']))hmMakePreferred($pdo,$hotelId,$adminId);else hmRebuildPreferred($pdo);
            $_SESSION['admin_hotel_success']=$action==='create_hotel'?'Hotel added to Hotel Master.':'Hotel details updated.';
            redirect(BASE_URL.'admin-hotels.php?edit='.$hotelId);
        }
        if($action==='set_preferred'){
            $id=max(0,(int)($_POST['hotel_id']??0));hmMakePreferred($pdo,$id,$adminId);$_SESSION['admin_hotel_success']='Preferred hotel updated for this destination/city/category.';redirect(BASE_URL.'admin-hotels.php');
        }
        if($action==='toggle_status'){
            $id=max(0,(int)($_POST['hotel_id']??0));$pdo->prepare("UPDATE hotels SET status=IF(status='active','inactive','active'),updated_by_admin_id=?,updated_at=NOW() WHERE id=?")->execute([$adminId,$id]);hmRebuildPreferred($pdo);$_SESSION['admin_hotel_success']='Hotel status updated.';redirect(BASE_URL.'admin-hotels.php');
        }
        if($action==='set_primary_photo'){
            $imageId=max(0,(int)($_POST['image_id']??0));$st=$pdo->prepare("SELECT hotel_id,image_path FROM hotel_images WHERE id=? LIMIT 1");$st->execute([$imageId]);$im=$st->fetch(PDO::FETCH_ASSOC);if(!$im)throw new RuntimeException('Hotel photo not found.');
            $pdo->prepare("UPDATE hotel_images SET is_primary=0 WHERE hotel_id=?")->execute([(int)$im['hotel_id']]);$pdo->prepare("UPDATE hotel_images SET is_primary=1 WHERE id=?")->execute([$imageId]);$pdo->prepare("UPDATE hotels SET primary_image=?,updated_by_admin_id=? WHERE id=?")->execute([(string)$im['image_path'],$adminId,(int)$im['hotel_id']]);$_SESSION['admin_hotel_success']='Primary hotel photo updated.';redirect(BASE_URL.'admin-hotels.php?edit='.(int)$im['hotel_id']);
        }
        if($action==='delete_photo'){
            $imageId=max(0,(int)($_POST['image_id']??0));$st=$pdo->prepare("SELECT hotel_id,image_path,is_primary FROM hotel_images WHERE id=? LIMIT 1");$st->execute([$imageId]);$im=$st->fetch(PDO::FETCH_ASSOC);if(!$im)throw new RuntimeException('Hotel photo not found.');$hid=(int)$im['hotel_id'];$pdo->prepare("DELETE FROM hotel_images WHERE id=?")->execute([$imageId]);hmSafeDeleteImageFile((string)$im['image_path']);
            if((int)$im['is_primary']===1){$n=$pdo->prepare("SELECT id,image_path FROM hotel_images WHERE hotel_id=? ORDER BY sort_order,id LIMIT 1");$n->execute([$hid]);$next=$n->fetch(PDO::FETCH_ASSOC);$path=$next?(string)$next['image_path']:null;if($next)$pdo->prepare("UPDATE hotel_images SET is_primary=1 WHERE id=?")->execute([(int)$next['id']]);$pdo->prepare("UPDATE hotels SET primary_image=? WHERE id=?")->execute([$path,$hid]);}
            $_SESSION['admin_hotel_success']='Hotel photo removed.';redirect(BASE_URL.'admin-hotels.php?edit='.$hid);
        }
        if($action==='delete_hotel'){
            $id=max(0,(int)($_POST['hotel_id']??0));
            if($id<=0)throw new RuntimeException('Hotel not found.');
            $st=$pdo->prepare("SELECT id,hotel_name,source FROM hotels WHERE id=? LIMIT 1");
            $st->execute([$id]);$hotel=$st->fetch(PDO::FETCH_ASSOC);
            if(!$hotel)throw new RuntimeException('Hotel not found.');
            if((string)($hotel['source']??'manual')!=='manual')throw new RuntimeException('Supplier-synced hotels cannot be permanently deleted here. Deactivate the hotel instead.');

            $paths=[];
            $im=$pdo->prepare("SELECT image_path FROM hotel_images WHERE hotel_id=?");
            $im->execute([$id]);$paths=array_values(array_filter(array_map('strval',$im->fetchAll(PDO::FETCH_COLUMN)?:[])));

            $pdo->beginTransaction();
            try {
                /* Keep historical package / quotation snapshots, but detach the Hotel Master ID. */
                if(hmTable($pdo,'package_hotels')){try{$pdo->prepare("UPDATE package_hotels SET hotel_id=NULL WHERE hotel_id=?")->execute([$id]);}catch(Throwable $ignored){}}
                if(hmTable($pdo,'trip_hotel_allocations')){try{$pdo->prepare("UPDATE trip_hotel_allocations SET hotel_id=NULL WHERE hotel_id=?")->execute([$id]);}catch(Throwable $ignored){}}
                if(hmTable($pdo,'supplier_contract_hotel_inventory')){try{$pdo->prepare("UPDATE supplier_contract_hotel_inventory SET hotel_id=NULL,mapping_status='review' WHERE hotel_id=?")->execute([$id]);}catch(Throwable $ignored){}}
                if(hmTable($pdo,'supplier_hotel_options')){try{$pdo->prepare("UPDATE supplier_hotel_options SET hotel_id=NULL,updated_at=NOW() WHERE hotel_id=?")->execute([$id]);}catch(Throwable $ignored){}}
                if(hmTable($pdo,'supplier_hotel_aliases')){try{$pdo->prepare("DELETE FROM supplier_hotel_aliases WHERE hotel_id=?")->execute([$id]);}catch(Throwable $ignored){}}
                $pdo->prepare("DELETE FROM hotel_images WHERE hotel_id=?")->execute([$id]);
                $pdo->prepare("DELETE FROM hotels WHERE id=?")->execute([$id]);
                $pdo->commit();
            } catch(Throwable $deleteError) {
                if($pdo->inTransaction())$pdo->rollBack();
                throw $deleteError;
            }
            foreach($paths as $path)hmSafeDeleteImageFile($path);
            hmRebuildPreferred($pdo);
            $_SESSION['admin_hotel_success']='Hotel deleted from Hotel Master.';
            redirect(BASE_URL.'admin-hotels.php');
        }
    } catch(Throwable $e){
        $_SESSION['admin_hotel_error']=$e->getMessage();$return='admin-hotels.php';if(!empty($_POST['hotel_id']))$return.='?edit='.(int)$_POST['hotel_id'];redirect(BASE_URL.$return);
    }
}

try { if(hmTable($pdo,'hotels')) hmSync($pdo,$adminId); } catch(Throwable $ignored) {}

$destinations=hmTable($pdo,'destinations')?($pdo->query("SELECT id,name,country FROM destinations WHERE status='active' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC)?:[]):[];
$suppliers=hmTable($pdo,'suppliers')?($pdo->query("SELECT id,company_name FROM suppliers WHERE status='active' ORDER BY company_name")->fetchAll(PDO::FETCH_ASSOC)?:[]):[];
$editId=max(0,(int)($_GET['edit']??0));$editHotel=null;$editImages=[];
if($editId>0){$st=$pdo->prepare("SELECT h.*,d.name destination_name,d.country destination_country,dl.location_name FROM hotels h JOIN destinations d ON d.id=h.destination_id LEFT JOIN destination_locations dl ON dl.id=h.location_id WHERE h.id=? LIMIT 1");$st->execute([$editId]);$editHotel=$st->fetch(PDO::FETCH_ASSOC)?:null;if($editHotel){$im=$pdo->prepare("SELECT * FROM hotel_images WHERE hotel_id=? ORDER BY is_primary DESC,sort_order,id");$im->execute([$editId]);$editImages=$im->fetchAll(PDO::FETCH_ASSOC)?:[];}}

$q=trim((string)($_GET['q']??''));$destinationFilter=max(0,(int)($_GET['destination']??0));$locationFilter=max(0,(int)($_GET['location_id']??0));$starFilter=max(0,(int)($_GET['star']??0));
$where=['1=1'];$params=[];
if($q!==''){$where[]="(h.hotel_name LIKE ? OR h.city LIKE ? OR h.area LIKE ? OR h.address LIKE ? OR h.geo_city LIKE ? OR h.geo_state LIKE ? OR d.name LIKE ? OR s.company_name LIKE ?)";$like='%'.$q.'%';array_push($params,$like,$like,$like,$like,$like,$like,$like,$like);}
if($destinationFilter>0){$where[]='h.destination_id=?';$params[]=$destinationFilter;}
if($locationFilter>0){$where[]='h.location_id=?';$params[]=$locationFilter;}
if(in_array($starFilter,[3,4,5],true)){$where[]='h.star_category=?';$params[]=$starFilter;}
$supplierOfferExpr=hmTable($pdo,'supplier_hotel_options')?"(SELECT GROUP_CONCAT(DISTINCT sx.company_name ORDER BY sx.company_name SEPARATOR ', ') FROM supplier_hotel_options hi JOIN suppliers sx ON sx.id=hi.supplier_id WHERE hi.hotel_id=h.id AND hi.status='active')":(hmTable($pdo,'supplier_contract_hotel_inventory')?"(SELECT GROUP_CONCAT(DISTINCT sx.company_name ORDER BY sx.company_name SEPARATOR ', ') FROM supplier_contract_hotel_inventory hi JOIN suppliers sx ON sx.id=hi.supplier_id WHERE hi.hotel_id=h.id)":"NULL");
$sql="SELECT h.*,d.name destination_name,d.country,dl.location_name,s.company_name preferred_supplier_name,{$supplierOfferExpr} supplier_offers FROM hotels h JOIN destinations d ON d.id=h.destination_id LEFT JOIN destination_locations dl ON dl.id=h.location_id LEFT JOIN suppliers s ON s.id=h.preferred_supplier_id WHERE ".implode(' AND ',$where)." ORDER BY d.name,COALESCE(dl.location_name,h.city),h.star_category DESC,h.is_preferred DESC,h.priority_order,h.hotel_name";
$st=$pdo->prepare($sql);$st->execute($params);$hotels=$st->fetchAll(PDO::FETCH_ASSOC)?:[];
$hmTotalMatches=count($hotels);
$hmPerPage=18;
$hmPageCount=max(1,(int)ceil($hmTotalMatches/$hmPerPage));
$hmPage=max(1,min($hmPageCount,(int)($_GET['page']??1)));
$hmPageStart=($hmPage-1)*$hmPerPage;
$hotels=array_slice($hotels,$hmPageStart,$hmPerPage);
$hmPageUrl=static function(int $page) use ($q,$destinationFilter,$locationFilter,$starFilter): string {
    return 'admin-hotels.php?'.http_build_query(['q'=>$q,'destination'=>$destinationFilter,'location_id'=>$locationFilter,'star'=>$starFilter,'page'=>$page]).'#hotelDirectory';
};
$stats=hmTable($pdo,'hotels')?($pdo->query("SELECT COUNT(*) total,SUM(status='active') active,SUM(is_preferred=1 AND status='active') preferred,SUM(source='manual') manual,SUM(source='supplier_rate') synced FROM hotels")->fetch(PDO::FETCH_ASSOC)?:[]):[];
$filterLocations=[];if($destinationFilter>0&&function_exists('tsLocationList'))$filterLocations=tsLocationList($pdo,$destinationFilter);

function hmAsset(?string $path): string { $path=trim((string)$path); if($path==='')return ''; if(preg_match('~^https?://~i',$path))return $path; return rtrim(BASE_URL,'/').'/'.ltrim($path,'/'); }
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Hotel Master Pro | TRAVSCOPE Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><script>document.documentElement.classList.add('ts-pro-preload');</script><link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260919-v18-1">
<style>
.hm-wrap{max-width:1500px;margin:auto}.hero-actions{display:flex;gap:8px;flex-wrap:wrap}.stats{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin:14px 0}.stat,.panel{background:#fff;border:1px solid #dde7f0;border-radius:15px;box-shadow:0 5px 20px rgba(15,45,75,.04)}.stat{padding:14px}.stat b{display:block;font-size:23px;color:#102b47}.stat span{font-size:9px;letter-spacing:.7px;text-transform:uppercase;color:#718297;font-weight:900}.panel{padding:16px;margin-bottom:14px}.panel-title{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}.panel-title h2{margin:0;font-size:16px}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:11px}.field{display:flex;flex-direction:column;gap:5px}.field.w2{grid-column:span 2}.field.w4{grid-column:1/-1}.field label{font-size:9px;text-transform:uppercase;font-weight:900;color:#68798c}.control{width:100%;border:1px solid #d7e2ed;border-radius:10px;padding:10px 11px;background:#fff;min-height:39px}.control:focus{outline:0;border-color:#1680ef;box-shadow:0 0 0 3px rgba(22,128,239,.10)}textarea.control{min-height:86px;resize:vertical}.btn{border:0;border-radius:10px;padding:10px 13px;font-weight:900;text-decoration:none;cursor:pointer;display:inline-flex;gap:7px;align-items:center;justify-content:center}.primary{background:#1578f6;color:#fff}.green{background:#0c9968;color:#fff}.soft{background:#eef4fa;color:#37546e}.danger{background:#fff0f1;color:#b3293b}.alerts{margin:10px 0}.ok,.err{padding:11px 13px;border-radius:10px;font-size:11px;font-weight:800}.ok{background:#eaf9f0;color:#08784b}.err{background:#fff0f1;color:#a82a3a}.hotel-form-head{display:flex;align-items:center;justify-content:space-between;gap:10px}.hint{font-size:10px;color:#6f8092;line-height:1.5}.photo-upload{border:1px dashed #b9cad9;border-radius:12px;padding:12px;background:#f8fbfe}.photo-preview{display:flex;flex-wrap:wrap;gap:8px;margin-top:9px}.photo{position:relative;width:120px;height:82px;border-radius:10px;overflow:hidden;border:1px solid #dce6ef;background:#edf2f7}.photo img{width:100%;height:100%;object-fit:cover}.photo .tag{position:absolute;left:6px;bottom:6px;background:rgba(5,25,45,.82);color:#fff;font-size:8px;font-weight:900;padding:3px 6px;border-radius:999px}.photo-actions{display:flex;gap:5px;margin-top:5px}.toolbar{display:grid;grid-template-columns:2fr 1fr 1fr 1fr auto;gap:8px}.hotel-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.hotel-card{border:1px solid #e0e8ef;border-radius:14px;overflow:hidden;background:#fff;display:grid;grid-template-columns:128px 1fr;min-height:132px}.hotel-thumb{background:#edf3f8;display:flex;align-items:center;justify-content:center;overflow:hidden}.hotel-thumb img{width:100%;height:100%;object-fit:cover}.hotel-thumb i{font-size:30px;color:#91a3b6}.hotel-body{padding:11px}.hotel-title{display:flex;justify-content:space-between;gap:8px}.hotel-title strong{font-size:13px;color:#12304d}.stars{color:#b97700;font-weight:900;font-size:11px}.meta{font-size:10px;color:#62758b;margin-top:5px;line-height:1.5}.pills{display:flex;gap:5px;flex-wrap:wrap;margin-top:7px}.pill{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:8px;font-weight:900;background:#eef4fb;color:#396383}.pill.good{background:#e6f8ef;color:#08794d}.pill.manual{background:#fff6e6;color:#9a6400}.card-actions{display:flex;gap:5px;flex-wrap:wrap;margin-top:8px}.card-actions .btn{padding:7px 9px;font-size:9px}.empty{text-align:center;padding:32px;color:#7b8999}.section-note{padding:11px 12px;background:#eef7ff;border:1px solid #d3e8fa;border-radius:11px;color:#315876;font-size:10px;margin-bottom:12px}.dest-search-wrap{position:relative}.dest-search{margin-bottom:5px}.inline-check{display:flex;align-items:center;gap:7px;font-size:11px;color:#435b70}.map-link{color:#126bd3;text-decoration:none;font-weight:800}.group-heading{grid-column:1/-1;font-size:11px;text-transform:uppercase;letter-spacing:.8px;color:#5f7285;font-weight:900;padding-top:4px}.smart-location{grid-column:1/-1;border:1px solid #dce8f4;border-radius:18px;padding:15px;background:#fff;box-shadow:0 10px 30px rgba(31,73,125,.06)}.smart-head{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;margin-bottom:12px}.smart-head strong{font-size:14px;color:#163958}.smart-head span{font-size:9px;font-weight:900;color:#087a53;background:#e8f8f1;border:1px solid #c9eddd;border-radius:999px;padding:6px 9px}.smart-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.smart-grid-five{grid-template-columns:repeat(5,minmax(0,1fr));align-items:stretch}.smart-box{border-radius:14px;padding:11px;border:1px solid transparent;min-width:0}.smart-box label{display:flex;justify-content:space-between;align-items:center;color:#243b53}.smart-box small{display:block;margin-top:5px;font-size:8px;line-height:1.35;color:#6d7f91;font-weight:700;text-transform:none}.smart-box .control{background:rgba(255,255,255,.88);border-color:rgba(113,139,166,.28)}.smart-blue{background:linear-gradient(145deg,#eef8ff,#f7fcff);border-color:#bfe2fa}.smart-purple{background:linear-gradient(145deg,#f6f0ff,#fbf8ff);border-color:#dbc9fb}.smart-orange{background:linear-gradient(145deg,#fff5e8,#fffaf2);border-color:#f2d1a2}.smart-green{background:linear-gradient(145deg,#edfbf4,#f7fdf9);border-color:#bce8cf}.smart-teal{background:linear-gradient(145deg,#ecfbfb,#f6ffff);border-color:#b9e4e3}.smart-blue .smart-step{background:#fff;color:#1671ca;border:1px solid #c6e3fb}.smart-purple .smart-step{background:#fff;color:#7442c8;border:1px solid #decffa}.smart-orange .smart-step{background:#fff;color:#bc6900;border:1px solid #f2d4aa}.smart-green .smart-step{background:#fff;color:#168457;border:1px solid #c5ead5}.smart-teal .smart-step{background:#fff;color:#0b7c7b;border:1px solid #c1e6e5}.smart-step{display:inline-grid;place-items:center;width:21px;height:21px;border-radius:50%;font-size:9px}.smart-result{margin-top:11px;padding:11px 12px;border-radius:12px;background:linear-gradient(90deg,#eef8ff,#f4fbff);border:1px solid #cfe7f8;color:#315b7c;font-size:10px;font-weight:700}.smart-result i{margin-right:6px;color:#1578f6}.dest-search{margin-bottom:6px}.new-location-wrap{margin-top:6px}.location-status{margin-top:6px;font-size:9px;color:#607789;line-height:1.35}.location-status.ok{color:#08794d;background:transparent;padding:0}.location-status.warn{color:#a05d00}.time-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.hotel-search-input{display:grid;grid-template-columns:1fr 38px;gap:6px}.hotel-search-btn{border:0;border-radius:10px;background:#0e8b8a;color:#fff;cursor:pointer}.hotel-search-btn:disabled{opacity:.45;cursor:not-allowed}.hotel-search-panel{margin-top:12px;border:1px solid #cfe7e7;border-radius:14px;padding:12px;background:linear-gradient(145deg,#f7ffff,#fff)}.hotel-search-panel-head{display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:9px}.hotel-search-panel-head b{font-size:11px;color:#184d5b}.hotel-search-panel-head small{display:block;font-size:9px;color:#69808c;margin-top:3px}.source-badge{font-size:8px;font-weight:900;padding:5px 8px;border-radius:999px;background:#e8f8f1;color:#08794d;border:1px solid #c8eadb}.hotel-search-results{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.hotel-search-card{display:grid;grid-template-columns:84px 1fr auto;gap:10px;align-items:center;border:1px solid #dde8ef;border-radius:12px;padding:8px;background:#fff;min-height:86px}.hotel-search-card.existing{background:#f7fbff;border-color:#cfe3f4}.hotel-search-thumb{width:84px;height:68px;border-radius:9px;overflow:hidden;background:#edf3f8;display:flex;align-items:center;justify-content:center}.hotel-search-thumb img{width:100%;height:100%;object-fit:cover}.hotel-search-thumb i{font-size:23px;color:#93a7b7}.hotel-search-copy{min-width:0}.hotel-search-copy strong{display:block;color:#163957;font-size:11px}.hotel-search-copy .addr{font-size:9px;line-height:1.35;color:#657b8e;margin-top:3px}.hotel-search-copy .rating{font-size:9px;color:#9c6b00;margin-top:4px;font-weight:800}.hotel-search-actions{display:flex;flex-direction:column;gap:5px}.hotel-search-actions .btn{padding:7px 8px;font-size:8px;white-space:nowrap}.google-place-readonly{font-size:9px;color:#516b7e;display:flex;align-items:center;gap:7px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.search-empty{grid-column:1/-1;padding:15px;text-align:center;border:1px dashed #d9e4eb;border-radius:10px;color:#718496;font-size:10px}.google-note{grid-column:1/-1;font-size:8px;color:#758694;padding:4px 2px}
@media(max-width:1350px){.smart-grid-five{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(max-width:1100px){.grid{grid-template-columns:repeat(2,1fr)}.hotel-cards{grid-template-columns:repeat(2,1fr)}.stats{grid-template-columns:repeat(3,1fr)}.toolbar{grid-template-columns:1fr 1fr}.smart-grid-five{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:700px){.grid,.hotel-cards,.stats,.toolbar,.smart-grid,.smart-grid-five,.location-choice,.time-grid,.hotel-search-results{grid-template-columns:1fr}.field.w2{grid-column:auto}.hotel-card{grid-template-columns:100px 1fr}.hero-actions{width:100%}}

/* TRAVSCOPE V24.44 — scoped hotel-inventory enterprise UX */
.hm-wrap{max-width:1640px;padding-bottom:36px;color:#18324f;scroll-behavior:smooth}
.hm-wrap *{box-sizing:border-box}
.hm-wrap .hm-hero{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;background:linear-gradient(112deg,#fff 0%,#f0f7ff 75%,#eaf9f7);border:1px solid #d9e6f5;border-left:4px solid #1979fa;padding:21px 23px;border-radius:17px;box-shadow:0 8px 28px rgba(19,47,84,.035);margin-bottom:17px}
.hm-wrap .hm-hero h1{font-size:clamp(23px,2vw,31px);letter-spacing:-.045em;color:#102e51;margin:3px 0 6px;line-height:1.17}
.hm-wrap .hm-hero h1 em{font-style:normal;color:#136ee7}
.hm-wrap .hm-eyebrow,.hm-wrap .hm-section-kicker{font-size:11px;letter-spacing:.10em;font-weight:850;color:#2465ac;text-transform:uppercase}
.hm-wrap .hm-hero p{font-size:13px;line-height:1.55;color:#62758b;max-width:800px;margin:0}
.hm-wrap .hero-actions .btn{font-size:12px;min-height:42px;padding:10px 14px;box-shadow:0 4px 12px rgba(14,63,105,.06)}
.hm-wrap .hero-actions form{display:inline-flex;margin:0}
.hm-wrap .hm-add-cta{background:#1579ed;color:white}
.hm-wrap .stats{gap:12px;margin:0 0 16px}
.hm-wrap .stat{position:relative;display:flex;align-items:center;gap:12px;min-height:91px;padding:17px;border-radius:15px;overflow:hidden;border:1px solid #e1eaf4}
.hm-wrap .stat:before{content:'';width:4px;background:var(--hm-accent,#247af0);position:absolute;top:0;bottom:0;left:0}
.hm-wrap .stat .hm-stat-icon{width:42px;height:42px;flex:0 0 42px;display:grid;place-items:center;border-radius:12px;background:var(--hm-pale,#e7f1ff);color:var(--hm-accent,#247af0);font-size:19px}
.hm-wrap .stat span:not(.hm-stat-icon){font-size:11px;letter-spacing:.035em;color:#536782;text-transform:none;font-weight:800}
.hm-wrap .stat b{font-size:27px;line-height:1.2;letter-spacing:-.035em;margin-top:3px}
.hm-wrap .stat small{display:block;margin-top:3px;font-size:10px;color:#75889b}
.hm-stat-active{--hm-accent:#05a77c;--hm-pale:#e5faf2}.hm-stat-preferred{--hm-accent:#d49b12;--hm-pale:#fff7e6}.hm-stat-manual{--hm-accent:#8759d5;--hm-pale:#f3edff}.hm-stat-synced{--hm-accent:#108aaf;--hm-pale:#e7f7fa}
.hm-wrap .panel{border-radius:16px;border-color:#dfe8f3;box-shadow:0 6px 22px rgba(19,45,86,.037);padding:19px;margin-bottom:15px}
.hm-wrap .hint{font-size:12px;line-height:1.55;color:#75879a}
.hm-wrap .panel-title h2{font-size:21px;letter-spacing:-.025em;color:#152e4c;margin:5px 0 3px}
.hm-wrap .hm-editor-panel{padding:0;overflow:hidden;scroll-margin-top:85px}
.hm-wrap .hm-editor-panel>summary{list-style:none;cursor:pointer;padding:17px 20px;display:flex;gap:14px;align-items:center;justify-content:space-between;background:linear-gradient(95deg,#f7fbff,#fff);user-select:none}
.hm-wrap .hm-editor-panel>summary::-webkit-details-marker{display:none}
.hm-wrap .hm-editor-panel[open]>summary{border-bottom:1px solid #e1eaf3}
.hm-editor-title{display:flex;align-items:center;gap:12px}
.hm-editor-mark{display:grid;place-items:center;width:43px;height:43px;border-radius:13px;background:#e6f0ff;color:#146ee0;font-size:19px}
.hm-wrap .hm-editor-title h2{font-size:17px;color:#132e4b;font-weight:850}
.hm-wrap .hm-editor-title .hint{margin-top:3px}
.hm-editor-toggle{display:inline-flex;align-items:center;gap:10px;font-size:12px;color:#136de0;background:#eaf2ff;border-radius:10px;padding:10px 13px;font-weight:800;white-space:nowrap}
.hm-editor-toggle i{transition:transform .2s}.hm-editor-panel[open] .hm-editor-toggle i{transform:rotate(180deg)}
.hm-editor-content{padding:18px 20px 20px}
.hm-wrap .section-note{font-size:12px;line-height:1.6;margin-bottom:17px;background:#f2f8ff;border-color:#d5e7fb}
.hm-wrap .grid{gap:13px}
.hm-wrap .field{gap:7px;min-width:0}
.hm-wrap .field label{font-size:11px;letter-spacing:.025em;color:#344b65;text-transform:none;font-weight:800}
.hm-wrap .control{min-height:43px;border-color:#d2dfed;font-size:13px;line-height:1.4;color:#18344f;padding:10px 12px;border-radius:10px;min-width:0}
.hm-wrap textarea.control{min-height:90px;line-height:1.55}
.hm-wrap .btn{font-size:12px;font-weight:800;min-height:36px}
.hm-wrap .hm-field-heading{grid-column:1/-1;display:flex;align-items:center;gap:8px;font-size:13px;color:#153b68;font-weight:850;border-bottom:1px solid #e4ecf5;padding:10px 1px 9px;margin:3px 0 1px}
.hm-wrap .hm-field-heading i{color:#2177dc}
.hm-wrap .hm-field-heading span{font-size:11px;font-weight:500;color:#8493a7;margin-left:auto}
.hm-wrap .smart-location{padding:16px;border-radius:14px;background:linear-gradient(145deg,#f9fcff,#fff);box-shadow:none}
.hm-wrap .smart-head{margin-bottom:14px}
.hm-wrap .smart-head strong{font-size:16px}
.hm-wrap .smart-head span,.hm-wrap .source-badge{font-size:10px}
.hm-wrap .smart-box{padding:12px;border-radius:12px}
.hm-wrap .smart-box small{font-size:10px;line-height:1.48;font-weight:500}
.hm-wrap .smart-step{font-size:10px;width:23px;height:23px}
.hm-wrap .smart-result{font-size:12px;line-height:1.5}
.hm-wrap .hotel-search-panel-head b{font-size:14px}.hm-wrap .hotel-search-panel-head small{font-size:11px}
.hm-wrap .hotel-search-copy strong{font-size:13px}.hm-wrap .hotel-search-copy .addr,.hm-wrap .hotel-search-copy .rating{font-size:11px}
.hm-wrap .hotel-search-actions .btn{font-size:11px;padding:8px 10px}
.hm-wrap .hotel-search-card{grid-template-columns:90px minmax(0,1fr) auto;min-height:100px;padding:10px}
.hm-wrap .hotel-search-thumb{width:90px;height:75px}
.hm-wrap .hotel-search-btn{min-width:40px;font-size:14px}.hm-wrap .hotel-search-input{grid-template-columns:minmax(0,1fr) 40px}
.hm-wrap .hm-form-footer{display:flex;gap:15px;justify-content:space-between;align-items:center;flex-wrap:wrap;margin-top:19px;border-top:1px solid #e3ebf5;padding-top:16px}
.hm-wrap .hm-form-footer>span{font-size:11px;color:#637994}.hm-wrap .hm-form-footer>span i{color:#098d68;margin-right:4px}
.hm-wrap .hm-form-footer .btn{min-height:44px;padding:11px 23px}
.hm-wrap .photo-upload{padding:19px;border:1.5px dashed #a8c7e8;background:linear-gradient(145deg,#f5faff,#fff);border-radius:13px}
.hm-wrap .photo-upload input[type=file]{font-size:13px;width:100%}.hm-wrap .photo{width:142px;height:95px}.hm-wrap .photo .tag{font-size:10px}
.hm-wrap .inline-check{font-size:12px;line-height:1.5}
.hm-wrap .hm-directory{scroll-margin-top:88px}
.hm-wrap .panel-title{align-items:center}
.hm-count-tag{white-space:nowrap;background:#edf5ff;color:#1767c4;font-size:12px;font-weight:800;padding:8px 12px;border-radius:999px}
.hm-wrap .toolbar{grid-template-columns:minmax(210px,2.2fr) repeat(3,minmax(130px,1fr)) auto;gap:10px;padding:12px;background:#f6f9fd;border:1px solid #e5edf6;border-radius:13px}
.hm-wrap .toolbar .control{background:#fff;font-size:12px}
.hm-wrap .hm-results-meta{display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;padding:15px 1px 12px;font-size:12px;color:#657b92}
.hm-wrap .hm-results-meta b{color:#173b67}.hm-wrap .hm-results-aside a{color:#1d6fc3;font-weight:800;text-decoration:none}
.hm-wrap .hotel-cards{grid-template-columns:repeat(3,minmax(0,1fr));gap:13px}
.hm-wrap .group-heading{font-size:11px;background:#f1f6fc;padding:9px 12px;border-radius:9px;color:#42668c;letter-spacing:.06em;margin-top:3px}
.hm-wrap .hotel-card{grid-template-columns:116px minmax(0,1fr);min-height:173px;border:1px solid #dce5ee;border-radius:13px;transition:border-color .16s,box-shadow .16s}
.hm-wrap .hotel-card:hover{border-color:#b4d3f7;box-shadow:0 6px 17px rgba(29,76,134,.08)}
.hm-wrap .hotel-thumb{background:linear-gradient(145deg,#e9f4ff,#dbeef7)}.hm-wrap .hotel-thumb i{color:#5f95bf;font-size:27px}
.hm-wrap .hotel-body{padding:13px 12px;min-width:0;display:flex;flex-direction:column}
.hm-wrap .hotel-title{align-items:start}.hm-wrap .hotel-title strong{font-size:14px;line-height:1.4;font-weight:850;color:#163655}
.hm-wrap .stars{font-size:12px;flex-shrink:0}.hm-wrap .meta{font-size:11px;line-height:1.48;color:#657b90;margin-top:7px;overflow-wrap:anywhere}
.hm-wrap .pills{margin-top:8px}.hm-wrap .pill{font-size:9px;padding:4px 7px;letter-spacing:.015em}
.hm-wrap .card-actions{border-top:1px solid #edf1f5;padding-top:9px;margin-top:auto;gap:6px}
.hm-wrap .card-actions .btn{font-size:11px;min-height:30px;padding:6px 10px}
.hm-wrap .card-actions form{margin:0}.hm-wrap .card-actions .btn:focus-visible{outline:2px solid #2563eb;outline-offset:2px}
.hm-wrap .hm-pagination{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:10px;margin-top:18px;padding-top:17px;border-top:1px solid #e5edf5;color:#657d92;font-size:12px}
.hm-page-btn,.hm-page-number{color:#2368af;text-decoration:none;border:1px solid #dbe7f4;background:#fff;border-radius:9px;padding:9px 12px;font-weight:800;display:inline-flex;align-items:center;justify-content:center;gap:7px;min-height:36px}
.hm-page-number{min-width:36px}.hm-page-number.is-current{background:#1479ed;color:#fff;border-color:#1479ed}
.hm-page-btn.is-disabled{pointer-events:none;opacity:.42}.hm-page-numbers{display:flex;gap:4px}
@media(max-width:1470px){.hm-wrap .hotel-cards{grid-template-columns:repeat(2,minmax(0,1fr))}.hm-wrap .stats{grid-template-columns:repeat(3,minmax(0,1fr))}.hm-wrap .smart-grid-five{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media(max-width:1100px){.hm-wrap .toolbar{grid-template-columns:repeat(2,minmax(0,1fr))}.hm-wrap .stats{grid-template-columns:repeat(2,minmax(0,1fr))}.hm-wrap .smart-grid-five{grid-template-columns:repeat(2,minmax(0,1fr))}.hm-wrap .hotel-search-results{grid-template-columns:1fr}}
@media(max-width:730px){.hm-wrap .hotel-cards,.hm-wrap .stats,.hm-wrap .toolbar,.hm-wrap .smart-grid-five,.hm-wrap .grid{grid-template-columns:1fr}.hm-wrap .hm-hero{padding:16px}.hm-wrap .hero-actions{width:100%}.hm-wrap .hero-actions .btn{flex:1}.hm-wrap .hm-editor-panel>summary{align-items:flex-start;flex-wrap:wrap}.hm-wrap .hm-editor-title .hint{max-width:250px}.hm-wrap .hm-field-heading{align-items:flex-start;flex-wrap:wrap}.hm-wrap .hm-field-heading span{margin-left:0}.hm-wrap .hotel-card{grid-template-columns:100px minmax(0,1fr)}.hm-wrap .field.w2{grid-column:auto}.hm-wrap .hotel-search-card{grid-template-columns:68px minmax(0,1fr)}.hm-wrap .hotel-search-thumb{width:68px;height:68px}.hm-wrap .hotel-search-actions{grid-column:1/-1;flex-direction:row}}

/* V24.45: Hotel Directory – one property per row, professional management table. */
.hm-wrap .hm-table-scroll{width:100%;max-width:100%;overflow-x:auto;overscroll-behavior-x:contain;border:1px solid #dce7f2;border-radius:13px;background:#fff;scrollbar-color:#c0d4e9 #f5f8fc;}
.hm-wrap .hm-table-scroll:focus-visible{outline:2px solid #2379e3;outline-offset:3px}
.hm-wrap .hm-hotel-table{width:100%;min-width:1100px;border-collapse:separate;border-spacing:0;table-layout:fixed;color:#223a55;font-size:12px}
.hm-wrap .hm-hotel-table th,.hm-wrap .hm-hotel-table td{text-align:left;vertical-align:middle}
.hm-wrap .hm-hotel-table thead th{position:sticky;top:0;background:#eaf2fc;color:#4a6682;font-size:10px;text-transform:uppercase;letter-spacing:.055em;font-weight:850;padding:14px 12px;border-bottom:1px solid #cbdced;white-space:normal;z-index:1}
.hm-wrap .hm-hotel-table thead th:nth-child(1){width:22%}.hm-wrap .hm-hotel-table thead th:nth-child(2){width:18%}.hm-wrap .hm-hotel-table thead th:nth-child(3){width:8%}.hm-wrap .hm-hotel-table thead th:nth-child(4){width:16%}.hm-wrap .hm-hotel-table thead th:nth-child(5){width:14%}.hm-wrap .hm-hotel-table thead th:nth-child(6){width:10%}.hm-wrap .hm-hotel-table thead th:nth-child(7){width:12%}
.hm-wrap .hm-property-row td{padding:13px 12px;border-bottom:1px solid #e9eff6;overflow-wrap:anywhere}
.hm-wrap .hm-property-row:nth-of-type(2n){background:#fbfdff}.hm-wrap .hm-property-row:hover{background:#f0f7ff}
.hm-wrap .hm-property-row:last-child td{border-bottom:none}
.hm-wrap .hm-group-row th{padding:9px 13px;background:#f0f5fb;color:#355f8b;font-size:11px;font-weight:850;letter-spacing:.025em;border-bottom:1px solid #e0e9f4}
.hm-wrap .hm-group-row i{margin-right:6px;color:#2484df}
.hm-wrap .hm-property-id{display:flex;align-items:center;gap:11px;min-width:0}
.hm-wrap .hm-row-photo{width:64px;height:54px;flex:none;display:grid;place-items:center;background:linear-gradient(145deg,#e4f0fc,#f0f7fb);border:1px solid #e0eaf4;border-radius:9px;overflow:hidden;color:#79a1c7;font-size:19px}
.hm-wrap .hm-row-photo img{width:100%;height:100%;object-fit:cover;display:block}
.hm-wrap .hm-property-info{min-width:0;display:flex;flex-direction:column;gap:4px}
.hm-wrap .hm-property-info strong{font-size:12px;line-height:1.4;color:#153b64;font-weight:850}
.hm-wrap .hm-property-info small{font-size:10px;color:#71849a;line-height:1.4}
.hm-wrap .hm-cell-main{font-size:12px;line-height:1.45;font-weight:750;color:#23445f}
.hm-wrap .hm-cell-sub{font-size:10.5px;line-height:1.45;margin-top:4px;color:#6d7e93}
.hm-wrap .hm-address{max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;overflow-wrap:normal}
.hm-wrap .hm-star-category{display:inline-flex;gap:4px;align-items:center;font-size:12px;font-weight:850;color:#a86d00;background:#fff7e6;border:1px solid #f5dfab;padding:5px 8px;border-radius:8px}
.hm-wrap .hm-supplier-label{font-size:11px;line-height:1.45;margin-bottom:6px;font-weight:650}
.hm-wrap .hm-hotel-table .pill{font-size:9px;line-height:1.4}
.hm-wrap .hm-status-chip{display:inline-flex;gap:5px;align-items:center;font-size:10px;font-weight:850;padding:6px 9px;border-radius:999px;white-space:nowrap}
.hm-wrap .hm-status-chip i{font-size:6px}.hm-wrap .hm-status-chip.is-active{color:#087c52;background:#e6f9ef}.hm-wrap .hm-status-chip.is-inactive{color:#9b4d28;background:#fff1e5}
.hm-wrap .hm-preferred-text{color:#ad7800!important;font-weight:800}
.hm-wrap .hm-row-actions{display:flex;gap:5px;align-items:center;flex-wrap:wrap}
.hm-wrap .hm-row-actions form{margin:0;display:inline-flex}
.hm-wrap .hm-row-actions .btn{border-radius:8px;min-height:31px;padding:6px 8px;font-size:10px;white-space:nowrap;font-weight:800}
.hm-wrap .hm-row-actions .btn:not(.hm-edit-action){min-width:32px}
.hm-wrap .hm-row-actions .btn:focus-visible{outline:2px solid #1b76dd;outline-offset:2px}
.hm-wrap .hm-table-empty{text-align:center;padding:42px 16px!important;color:#72859a}
.hm-wrap .hm-table-empty i{font-size:28px;display:block;margin-bottom:9px;color:#8facc7}
.hm-wrap .hm-table-empty strong{display:block;font-size:14px;color:#385775}.hm-wrap .hm-table-empty span{display:block;margin-top:6px;font-size:12px}
@media(max-width:1250px){.hm-wrap .hm-hotel-table{min-width:1120px}.hm-wrap .hm-table-scroll{box-shadow:inset -8px 0 8px -10px rgba(20,65,110,.3)}}
@media(max-width:730px){.hm-wrap .hm-hotel-table{min-width:1070px}.hm-wrap .hm-table-scroll:before{content:'Swipe horizontally to see all hotel details →';display:block;padding:9px 12px;color:#4c7293;font-size:11px;font-weight:750;background:#f4f9ff}}


/* V24.48 – directory-first Hotel Master, without redundant hero/editor stripes. */
.hm-wrap{max-width:none;width:100%;min-width:0}
.hm-wrap .stats{margin:0 0 12px;gap:10px}
.hm-wrap .hm-directory{scroll-margin-top:80px}
.hm-wrap .hm-directory-top{align-items:center;gap:15px;margin-bottom:15px}
.hm-wrap .hm-directory-heading{flex:1;min-width:0}
.hm-wrap .hm-directory-heading h1{margin:3px 0 2px;color:#163552;font-size:21px;line-height:1.25;font-weight:850;letter-spacing:-.035em}
.hm-wrap .hm-directory-heading .hint{margin-top:3px;font-size:11px}
.hm-wrap .hm-directory-actions{display:flex;align-items:center;justify-content:flex-end;flex-wrap:wrap;gap:8px}
.hm-wrap .hm-directory-actions .btn{min-height:36px;white-space:nowrap;font-size:12px;padding:9px 12px}
.hm-wrap .hm-directory-actions .hm-count-tag{font-size:11px;padding:9px 11px}
.hm-directory-tools{position:relative;z-index:8}
.hm-directory-tools>summary{list-style:none;cursor:pointer}
.hm-directory-tools>summary::-webkit-details-marker{display:none}
.hm-directory-tools[open]>summary{background:#dfedff;color:#115eaa}
.hm-directory-tools-menu{position:absolute;top:calc(100% + 7px);right:0;z-index:30;width:245px;display:grid;gap:6px;background:#fff;border:1px solid #dbe6f2;border-radius:12px;padding:9px;box-shadow:0 14px 35px rgba(20,46,79,.16)}
.hm-directory-tools-menu form{margin:0}
.hm-directory-tools-menu .btn{width:100%;justify-content:flex-start!important;white-space:normal!important;background:#f4f8fc;color:#254c72}
.hm-directory-tools-menu .btn:hover{background:#e8f2fd}
.hm-wrap .hm-directory .hm-editor-panel:not([open]){display:none}
.hm-wrap .hm-directory .hm-editor-panel[open]{display:block;margin:2px 0 16px;background:#fff;border:1px solid #dce7f2;box-shadow:none;border-radius:13px;scroll-margin-top:82px}
.hm-wrap .hm-directory .hm-editor-panel[open]>summary{background:#f3f8ff}
@media(max-width:800px){
 .hm-wrap .hm-directory-top{align-items:flex-start;flex-direction:column}
 .hm-wrap .hm-directory-actions{width:100%;justify-content:flex-start}
 .hm-wrap .hm-directory-heading h1{font-size:20px}
 .hm-wrap .hm-directory-tools-menu{right:auto;left:0}
}


/* V24.49 — diagram-matched, single-row inventory summary. No duplicated KPI cards. */
.hm-wrap .hm-directory{margin-top:0}
.hm-wrap .hm-directory-top{display:flex;align-items:center;justify-content:space-between;gap:15px;margin-bottom:12px;padding:2px 0 12px;border-bottom:1px solid #e7edf5}
.hm-wrap .hm-directory-heading{flex:1 1 auto;min-width:0}
.hm-wrap .hm-directory-headline{display:flex;gap:12px;align-items:center;min-width:0}
.hm-wrap .hm-directory-symbol{width:44px;height:44px;flex:0 0 44px;display:grid;place-items:center;border-radius:12px;background:#e9f3ff;color:#136fd7;font-size:19px}
.hm-wrap .hm-directory-label{min-width:0}
.hm-wrap .hm-directory-label h1{display:flex;align-items:center;flex-wrap:wrap;gap:9px;margin:3px 0 4px;line-height:1.2}
.hm-wrap .hm-directory-total{display:inline-flex;align-items:baseline;gap:4px;white-space:nowrap;font-size:14px;line-height:1.4;color:#135fb4;background:#eaf4ff;border:1px solid #d6e8fd;border-radius:9px;padding:2px 9px;vertical-align:middle;letter-spacing:0}
.hm-wrap .hm-directory-total small{font-size:10px;font-weight:700;color:#6a83a2}
.hm-wrap .hm-directory-mini-stats{display:flex;align-items:center;gap:5px 14px;flex-wrap:wrap;color:#677e94;font-size:11px;line-height:1.6}
.hm-wrap .hm-directory-mini-stats span{display:inline-flex;align-items:center;gap:5px;white-space:nowrap}
.hm-wrap .hm-directory-mini-stats span:nth-child(1) i{color:#0a976e}
.hm-wrap .hm-directory-mini-stats span:nth-child(2) i{color:#cb980e}
.hm-wrap .hm-directory-mini-stats span:nth-child(3) i{color:#8057c8}
.hm-wrap .hm-directory-mini-stats strong{font-weight:850;color:#183b5a}
.hm-wrap .hm-directory-actions{display:flex;align-items:center;justify-content:flex-end;flex:0 0 auto;gap:8px;flex-wrap:wrap}
.hm-wrap .hm-directory-synced{display:inline-flex;align-items:center;gap:7px;white-space:nowrap;border:1px solid #cde8eb;border-radius:10px;background:#eefbfc;padding:8px 11px;color:#147589;font-weight:750;font-size:11px;min-height:36px}
.hm-wrap .hm-directory-synced strong{font-size:14px;color:#09617b}
.hm-wrap .hm-directory .hm-editor-panel[open]{margin-top:0}
@media(max-width:1130px){
 .hm-wrap .hm-directory-top{flex-wrap:wrap}
 .hm-wrap .hm-directory-heading{flex-basis:100%}
 .hm-wrap .hm-directory-actions{width:100%;justify-content:flex-end}
}
@media(max-width:600px){
 .hm-wrap .hm-directory-headline{align-items:flex-start}
 .hm-wrap .hm-directory-mini-stats{gap:5px 10px}
 .hm-wrap .hm-directory-actions{justify-content:flex-start}
 .hm-wrap .hm-directory-synced{font-size:10px;padding:8px}
 .hm-wrap .hm-directory-actions .btn{font-size:11px;padding:8px 10px}
}

</style></head><body><main class="main"><div class="content hm-wrap">
<?php if($success):?><div class="alerts"><div class="ok"><?=e($success)?></div></div><?php endif;?><?php if($error):?><div class="alerts"><div class="err"><?=e($error)?></div></div><?php endif;?>
<section class="panel hm-directory" id="hotelDirectory">
<div class="panel-title hm-directory-top">
  <div class="hm-directory-heading">
    <div class="hm-directory-headline">
      <span class="hm-directory-symbol" aria-hidden="true"><i class="fa-solid fa-hotel"></i></span>
      <div class="hm-directory-label">
        <span class="hm-section-kicker">PROPERTY INVENTORY</span>
        <h1>Hotel Directory <span class="hm-directory-total"><?=number_format((int)($stats['total']??0))?> <small>total</small></span></h1>
        <div class="hm-directory-mini-stats" aria-label="Hotel inventory summary">
          <span><i class="fa-solid fa-circle-check" aria-hidden="true"></i> Active <strong><?=number_format((int)($stats['active']??0))?></strong></span>
          <span><i class="fa-solid fa-star" aria-hidden="true"></i> Preferred <strong><?=number_format((int)($stats['preferred']??0))?></strong></span>
          <span><i class="fa-solid fa-user-pen" aria-hidden="true"></i> Admin added <strong><?=number_format((int)($stats['manual']??0))?></strong></span>
        </div>
      </div>
    </div>
  </div>
  <div class="hm-directory-actions">
    <span class="hm-directory-synced" title="Properties sourced through supplier sync"><i class="fa-solid fa-arrows-rotate" aria-hidden="true"></i> Supplier synced <strong><?=number_format((int)($stats['synced']??0))?></strong></span>
    <details class="hm-directory-tools">
      <summary class="btn soft" aria-label="More hotel management tools"><i class="fa-solid fa-ellipsis"></i> Tools <i class="fa-solid fa-chevron-down"></i></summary>
      <div class="hm-directory-tools-menu">
        <a class="btn soft" href="admin-destination-locations.php"><i class="fa-solid fa-location-dot"></i> Location Master</a>
        <form method="post"><input type="hidden" name="csrf_token" value="<?=e($csrf)?>"><input type="hidden" name="action" value="sync_supplier_rates"><button class="btn soft" type="submit"><i class="fa-solid fa-rotate"></i> Refresh Supplier Links</button></form>
      </div>
    </details>
    <a class="btn primary hm-add-cta" href="admin-hotels.php?create=1#hotelForm"><i class="fa-solid fa-plus"></i> Add Hotel</a>
  </div>
</div>
<details class="panel hm-editor-panel" id="hotelForm" <?=($editHotel || isset($_GET['create']) || $error)?'open':''?>>
<summary class="hotel-form-head"><div class="hm-editor-title"><span class="hm-editor-mark"><i class="fa-solid <?=$editHotel?'fa-pen-to-square':'fa-square-plus'?>"></i></span><div><h2 style="margin:0"><?= $editHotel?'Edit Hotel · '.e($editHotel['hotel_name']):'Add New Hotel'; ?></h2><div class="hint">5-step property matching · Full details, photos and supplier preference</div></div></div><span class="hm-editor-toggle"><i class="fa-solid fa-chevron-down"></i><span><?= $editHotel?'Edit property':'Open hotel form' ?></span></span></summary>
<div class="hm-editor-content">
<div class="section-note"><i class="fa-solid fa-circle-info"></i> Select Country → State → District/City → Destination, then search the hotel. Existing Hotel Master matches are checked first; Google Places search is available when configured. This form never creates a new Location Master record. Upload only photos you own or are authorised to use.</div>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=e($csrf)?>"><input type="hidden" name="action" value="<?=$editHotel?'update_hotel':'create_hotel'?>"><?php if($editHotel):?><input type="hidden" name="hotel_id" value="<?=(int)$editHotel['id']?>"><?php endif;?>
<input type="hidden" name="google_place_id" id="googlePlaceId" value="<?=e($editHotel['google_place_id']??'')?>"><input type="hidden" name="google_rating" id="googleRating" value="<?=e($editHotel['google_rating']??'')?>"><input type="hidden" name="google_user_ratings_total" id="googleRatingsTotal" value="<?=e($editHotel['google_user_ratings_total']??'')?>">
<div class="grid">
<div class="smart-location">
  <div class="smart-head">
    <div><strong><i class="fa-solid fa-location-crosshairs"></i> Smart Hotel Location</strong><div class="hint">Choose the travel place first, then add the hotel directly. There is no separate “Add new location” step.</div></div>
    <span><i class="fa-solid fa-bolt"></i> AUTO MATCH</span>
  </div>
  <div class="smart-grid smart-grid-five">
    <div class="smart-box smart-blue field">
      <label>Country <b class="smart-step">1</b></label>
      <select class="control" id="hotelGeoCountry" name="geo_country" data-current="<?=e($editHotel['geo_country']??$editHotel['destination_country']??'')?>"><option value="">Select Country</option></select>
      <small>Start with the country.</small>
    </div>
    <div class="smart-box smart-purple field">
      <label>State / Region <b class="smart-step">2</b></label>
      <select class="control" id="hotelGeoState" name="geo_state" data-current="<?=e($editHotel['geo_state']??'')?>" disabled><option value="">Select State / Region</option></select>
      <small>Only matching states are shown.</small>
    </div>
    <div class="smart-box smart-orange field">
      <label>District / City <b class="smart-step">3</b></label>
      <select class="control" id="hotelGeoCity" name="geo_city" data-current="<?=e($editHotel['geo_city']??$editHotel['location_name']??$editHotel['city']??'')?>" disabled><option value="">Select District / City</option></select>
      <small>Used to find the correct destination.</small>
    </div>
    <div class="smart-box smart-green field">
      <label>Destination / Tour Area <b class="smart-step">4</b></label>
      <select class="control" name="destination_id" id="hotelDestination" required><option value="">Select destination</option><?php foreach($destinations as $d):?><option value="<?=(int)$d['id']?>" data-name="<?=e(strtolower(trim((string)$d['name'])))?>" data-country="<?=e(strtolower(trim((string)($d['country']??''))))?>" <?=((int)($editHotel['destination_id']??0)===(int)$d['id'])?'selected':''?>><?=e($d['name'])?><?=!empty($d['country'])?' · '.e($d['country']):''?></option><?php endforeach;?></select>
      <small>Auto-matched when possible; manual selection is always available.</small>
    </div>
    <div class="smart-box smart-teal field">
      <label>Search Hotel <b class="smart-step">5</b></label>
      <div class="hotel-search-input"><input class="control" name="hotel_name" id="hotelNameSmart" value="<?=e($editHotel['hotel_name']??'')?>" placeholder="Type hotel name after choosing city" autocomplete="off" required><button type="button" class="hotel-search-btn" id="hotelSearchBtn" title="Search hotel"><i class="fa-solid fa-magnifying-glass"></i></button></div>
      <small>Search existing Hotel Master first; Google hotel search is used when configured.</small>
    </div>
  </div>
  <div class="smart-result" id="hotelGeoMatch"><i class="fa-solid fa-route"></i> Select Country → State → District/City. TRAVSCOPE will auto-match the Destination / Tour Area; then search the Hotel in step 5.</div>
  <div class="hotel-search-panel" id="hotelSearchPanel" hidden>
    <div class="hotel-search-panel-head"><div><b><i class="fa-solid fa-hotel"></i> Hotel Search Results</b><small id="hotelSearchStatus">Type at least 2 letters of the hotel name.</small></div><span class="source-badge" id="googleSearchBadge">TRAVSCOPE</span></div>
    <div class="hotel-search-results" id="hotelSearchResults"></div>
  </div>
</div>
<div class="hm-field-heading"><i class="fa-solid fa-bed"></i> Property Essentials <span>Required category, room and meal defaults</span></div>
<div class="field"><label>Category *</label><select class="control" name="star_category" required><option value="">Choose</option><?php foreach([3,4,5] as $s):?><option value="<?=$s?>" <?=((int)($editHotel['star_category']??0)===$s)?'selected':''?>><?=$s?> Star</option><?php endforeach;?></select></div>
<div class="field"><label>Status</label><select class="control" name="status"><option value="active" <?=($editHotel['status']??'active')==='active'?'selected':''?>>Active</option><option value="inactive" <?=($editHotel['status']??'')==='inactive'?'selected':''?>>Inactive</option></select></div>
<div class="field"><label>Default Room Type</label><input class="control" name="default_room_type" value="<?=e($editHotel['default_room_type']??'')?>" placeholder="Deluxe / Executive"></div>
<div class="field"><label>Default Meal Plan</label><input class="control" name="default_meal_plan" value="<?=e($editHotel['default_meal_plan']??'')?>" placeholder="CP / MAP / AP"></div>
<div class="hm-field-heading"><i class="fa-solid fa-address-card"></i> Property Details & Contact <span>Helpful information for quotation and hotel allocation</span></div>
<div class="field"><label>Check-in Time</label><input class="control" type="time" name="check_in_time" value="<?=e(substr((string)($editHotel['check_in_time']??''),0,5))?>"></div>
<div class="field"><label>Check-out Time</label><input class="control" type="time" name="check_out_time" value="<?=e(substr((string)($editHotel['check_out_time']??''),0,5))?>"></div>
<div class="field w2"><label>Address</label><input class="control" name="address" value="<?=e($editHotel['address']??'')?>" placeholder="Full property address"></div>
<div class="field"><label>Area / Landmark</label><input class="control" name="area" value="<?=e($editHotel['area']??'')?>" placeholder="Police Bazar / Beach Road"></div>
<div class="field"><label>Pincode</label><input class="control" name="pincode" value="<?=e($editHotel['pincode']??'')?>" placeholder="000000"></div>
<div class="field"><label>Hotel Phone</label><input class="control" name="phone" value="<?=e($editHotel['phone']??'')?>" placeholder="+91..."></div>
<div class="field"><label>Hotel Email</label><input class="control" type="email" name="email" value="<?=e($editHotel['email']??'')?>" placeholder="reservations@hotel.com"></div>
<div class="field"><label>Website</label><input class="control" type="url" name="website" value="<?=e($editHotel['website']??'')?>" placeholder="https://..."></div>
<div class="field"><label>Google Maps URL</label><input class="control" type="url" name="google_maps_url" value="<?=e($editHotel['google_maps_url']??'')?>" placeholder="Paste Google Maps place link"></div><?php if(!empty($editHotel['google_place_id'])):?><div class="field"><label>Google Place Match</label><div class="control google-place-readonly"><i class="fa-brands fa-google"></i> Linked · <?=e((string)$editHotel['google_place_id'])?></div></div><?php endif;?>
<div class="field"><label>Latitude</label><input class="control" name="latitude" value="<?=e($editHotel['latitude']??'')?>" placeholder="25.5788"></div>
<div class="field"><label>Longitude</label><input class="control" name="longitude" value="<?=e($editHotel['longitude']??'')?>" placeholder="91.8933"></div>
<div class="field"><label>Preferred Supplier (optional)</label><select class="control" name="preferred_supplier_id"><option value="0">No fixed supplier</option><?php foreach($suppliers as $s):?><option value="<?=(int)$s['id']?>" <?=((int)($editHotel['preferred_supplier_id']??0)===(int)$s['id'])?'selected':''?>><?=e($s['company_name'])?></option><?php endforeach;?></select></div>
<div class="field"><label>Priority</label><input class="control" type="number" min="0" max="999" name="priority_order" value="<?=e($editHotel['priority_order']??50)?>"><small class="hint">Lower number = higher priority.</small></div>
<div class="hm-field-heading"><i class="fa-solid fa-images"></i> Description & Media <span>Customer-safe details and hotel gallery</span></div>
<div class="field w4"><label>Hotel Description</label><textarea class="control" name="description" placeholder="Short internal/customer-safe hotel description"><?=e($editHotel['description']??'')?></textarea></div>
<div class="field w4"><label>Internal Notes</label><textarea class="control" name="notes" placeholder="Internal notes only"><?=e($editHotel['notes']??'')?></textarea></div>
<div class="field w4"><label>Hotel Photos</label><div class="photo-upload"><input type="file" name="hotel_photos[]" id="hotelPhotos" accept="image/jpeg,image/png,image/webp" multiple><div class="hint">Upload up to 10 JPG/PNG/WEBP photos, max 8 MB each. The first photo becomes primary if no primary photo exists.</div><div class="photo-preview" id="newPhotoPreview"></div></div></div>
<div class="field w4"><label class="inline-check"><input type="checkbox" name="make_preferred" value="1" <?=!empty($editHotel['is_preferred'])?'checked':''?>> Make this the preferred <?=$editHotel?e((string)$editHotel['star_category']).'★':''?> hotel for its destination/city/category</label></div>
</div>
<div class="hm-form-footer"><span><i class="fa-solid fa-shield-halved"></i> Existing hotels and supplier links are checked before saving.</span><button class="btn primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> <?=$editHotel?'Save Hotel Changes':'Save New Hotel'?></button></div></form>
<?php if($editHotel && (string)($editHotel['source']??'manual')==='manual'):?><div style="display:flex;justify-content:flex-end;margin-top:8px"><form method="post"><input type="hidden" name="csrf_token" value="<?=e($csrf)?>"><input type="hidden" name="action" value="delete_hotel"><input type="hidden" name="hotel_id" value="<?=(int)$editHotel['id']?>"><button class="btn danger" type="submit"><i class="fa-solid fa-trash-can"></i> Delete Hotel</button></form></div><?php endif;?>
<?php if($editHotel&&$editImages):?><div style="margin-top:16px;border-top:1px solid #e4ebf2;padding-top:13px"><b style="font-size:12px">Current Hotel Photos</b><div class="photo-preview"><?php foreach($editImages as $im):?><div><div class="photo"><img src="<?=e(hmAsset((string)$im['image_path']))?>" alt="<?=e((string)($im['alt_text']??$editHotel['hotel_name']))?>"><?php if((int)$im['is_primary']===1):?><span class="tag">PRIMARY</span><?php endif;?></div><div class="photo-actions"><?php if((int)$im['is_primary']!==1):?><form method="post"><input type="hidden" name="csrf_token" value="<?=e($csrf)?>"><input type="hidden" name="action" value="set_primary_photo"><input type="hidden" name="image_id" value="<?=(int)$im['id']?>"><button class="btn soft" type="submit" title="Set primary"><i class="fa-solid fa-star"></i></button></form><?php endif;?><form method="post"><input type="hidden" name="csrf_token" value="<?=e($csrf)?>"><input type="hidden" name="action" value="delete_photo"><input type="hidden" name="image_id" value="<?=(int)$im['id']?>"><button class="btn danger" type="submit" title="Delete photo"><i class="fa-solid fa-trash"></i></button></form></div></div><?php endforeach;?></div></div><?php endif;?>
</div></details>
<form class="toolbar" method="get" role="search" aria-label="Filter hotels"><input class="control" name="q" value="<?=e($q)?>" placeholder="Search hotel / city / area / address / supplier"><select class="control" name="destination" id="filterDestination"><option value="0">All destinations</option><?php foreach($destinations as $d):?><option value="<?=(int)$d['id']?>" <?=$destinationFilter===(int)$d['id']?'selected':''?>><?=e($d['name'])?></option><?php endforeach;?></select><select class="control" name="location_id" id="filterLocation"><option value="0">All locations</option><?php foreach($filterLocations as $loc):?><option value="<?=(int)$loc['id']?>" <?=$locationFilter===(int)$loc['id']?'selected':''?>><?=e($loc['location_name'])?></option><?php endforeach;?></select><select class="control" name="star"><option value="0">All categories</option><?php foreach([3,4,5] as $s):?><option value="<?=$s?>" <?=$starFilter===$s?'selected':''?>><?=$s?> Star</option><?php endforeach;?></select><button class="btn primary" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Search</button></form>
<div class="hm-results-meta"><span>Showing <b><?=$hmTotalMatches?number_format($hmPageStart+1):'0'?>–<?=number_format(min($hmTotalMatches,$hmPageStart+$hmPerPage))?></b> of <b><?=number_format($hmTotalMatches)?></b> hotels</span><span class="hm-results-aside"><a href="admin-hotels.php#hotelDirectory"><i class="fa-solid fa-rotate-left"></i> Clear filters</a> · <?=number_format($hmPerPage)?> per page</span></div>
<div class="hm-table-scroll" role="region" aria-label="Available hotels, row-wise directory" tabindex="0">
<table class="hm-hotel-table">
  <thead><tr>
    <th scope="col" class="hm-col-hotel">Hotel / Property</th>
    <th scope="col">Destination &amp; Location</th>
    <th scope="col">Category</th>
    <th scope="col">Room &amp; Meal Plan</th>
    <th scope="col">Supplier / Source</th>
    <th scope="col">Availability</th>
    <th scope="col" class="hm-col-actions">Manage Hotel</th>
  </tr></thead>
  <tbody>
  <?php if (!$hotels): ?>
    <tr><td colspan="7" class="hm-table-empty"><i class="fa-solid fa-hotel"></i><strong>No hotels found</strong><span>Try clearing the filters, adding a hotel, or refreshing supplier hotels.</span></td></tr>
  <?php endif; ?>
  <?php $lastGroup=''; foreach($hotels as $h):
    $group=(string)$h['destination_name'].' · '.((string)($h['location_name']?:$h['city']));
    if ($group!==$lastGroup): $lastGroup=$group; ?>
    <tr class="hm-group-row"><th colspan="7" scope="rowgroup"><i class="fa-solid fa-location-dot"></i> <?=e($group)?></th></tr>
    <?php endif; ?>
    <tr class="hm-property-row">
      <td>
        <div class="hm-property-id">
          <span class="hm-row-photo">
            <?php if(!empty($h['primary_image'])): ?>
              <img src="<?=e(hmAsset((string)$h['primary_image']))?>" alt="<?=e($h['hotel_name'])?>" loading="lazy">
            <?php else: ?><i class="fa-solid fa-hotel" aria-hidden="true"></i><?php endif; ?>
          </span>
          <span class="hm-property-info"><strong><?=e($h['hotel_name'])?></strong>
            <small>Hotel ID #<?=(int)$h['id']?><?php if((int)$h['is_preferred']===1): ?> · <span class="hm-preferred-text"><i class="fa-solid fa-star"></i> Preferred</span><?php endif; ?></small>
          </span>
        </div>
      </td>
      <td><div class="hm-cell-main"><?=e((string)($h['location_name']?:$h['city']))?></div>
          <div class="hm-cell-sub"><?=e($h['destination_name'])?><?php if(!empty($h['area'])): ?> · <?=e($h['area'])?><?php endif; ?></div>
          <?php if(!empty($h['address'])): ?><div class="hm-cell-sub hm-address" title="<?=e($h['address'])?>"><?=e($h['address'])?></div><?php endif; ?></td>
      <td><span class="hm-star-category"><?=(int)$h['star_category']?> <i class="fa-solid fa-star" aria-hidden="true"></i></span></td>
      <td><div class="hm-cell-main"><?=e($h['default_room_type']?:'Room not set')?></div>
          <div class="hm-cell-sub">Meal: <?=e($h['default_meal_plan']?:'Not set')?></div>
          <?php if(!empty($h['check_in_time'])||!empty($h['check_out_time'])): ?>
            <div class="hm-cell-sub">In <?=e(substr((string)($h['check_in_time']??''),0,5)?:'—')?> · Out <?=e(substr((string)($h['check_out_time']??''),0,5)?:'—')?></div>
          <?php endif; ?></td>
      <td><div class="hm-cell-main hm-supplier-label"><?=e($h['supplier_offers']?:($h['preferred_supplier_name']?:'Not linked'))?></div>
          <span class="pill <?=($h['source']==='manual'?'manual':'')?>"><?=($h['source']==='manual'?'ADMIN ADDED':'SUPPLIER SYNCED')?></span></td>
      <td>
        <span class="hm-status-chip <?=((string)$h['status']==='active'?'is-active':'is-inactive')?>"><i class="fa-solid fa-circle" aria-hidden="true"></i> <?=e(ucfirst((string)$h['status']))?></span>
        <?php if((int)$h['is_preferred']===1): ?><div class="hm-cell-sub hm-preferred-text"><i class="fa-solid fa-star"></i> Preferred Hotel</div><?php endif; ?>
      </td>
      <td><div class="hm-row-actions">
        <a class="btn primary hm-edit-action" href="admin-hotels.php?edit=<?=(int)$h['id']?>#hotelForm"><i class="fa-solid fa-pen"></i> Edit</a>
        <?php if(!empty($h['google_maps_url'])): ?><a class="btn soft" target="_blank" rel="noopener noreferrer" href="<?=e($h['google_maps_url'])?>" title="Open map for <?=e($h['hotel_name'])?>"><i class="fa-solid fa-map-location-dot"></i><span class="hm-action-label"> Map</span></a><?php endif; ?>
        <?php if((int)$h['is_preferred']!==1): ?><form method="post"><input type="hidden" name="csrf_token" value="<?=e($csrf)?>"><input type="hidden" name="action" value="set_preferred"><input type="hidden" name="hotel_id" value="<?=(int)$h['id']?>"><button class="btn soft" type="submit" title="Make preferred" aria-label="Make <?=e($h['hotel_name'])?> preferred"><i class="fa-regular fa-star"></i></button></form><?php endif; ?>
        <form method="post"><input type="hidden" name="csrf_token" value="<?=e($csrf)?>"><input type="hidden" name="action" value="toggle_status"><input type="hidden" name="hotel_id" value="<?=(int)$h['id']?>"><button class="btn soft" type="submit" title="Toggle active/inactive" aria-label="Toggle status for <?=e($h['hotel_name'])?>"><i class="fa-solid fa-power-off"></i></button></form>
        <?php if((string)($h['source']??'manual')==='manual'): ?><form method="post"><input type="hidden" name="csrf_token" value="<?=e($csrf)?>"><input type="hidden" name="action" value="delete_hotel"><input type="hidden" name="hotel_id" value="<?=(int)$h['id']?>"><button class="btn danger" type="submit" title="Delete hotel" aria-label="Delete <?=e($h['hotel_name'])?>"><i class="fa-solid fa-trash-can"></i></button></form><?php endif; ?>
      </div></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php if($hmPageCount>1):?>
<nav class="hm-pagination" aria-label="Hotel directory pages">
  <a class="hm-page-btn <?=$hmPage===1?'is-disabled':''?>" <?=$hmPage===1?'aria-disabled="true" tabindex="-1"':''?> href="<?=e($hmPageUrl(max(1,$hmPage-1)))?>"><i class="fa-solid fa-chevron-left"></i> Previous</a>
  <span>Page <b><?=number_format($hmPage)?></b> of <?=number_format($hmPageCount)?></span>
  <div class="hm-page-numbers"><?php for($pi=max(1,$hmPage-2);$pi<=min($hmPageCount,$hmPage+2);$pi++):?><a class="hm-page-number <?=$pi===$hmPage?'is-current':''?>" href="<?=e($hmPageUrl($pi))?>" <?=$pi===$hmPage?'aria-current="page"':''?>><?=$pi?></a><?php endfor;?></div>
  <a class="hm-page-btn <?=$hmPage===$hmPageCount?'is-disabled':''?>" <?=$hmPage===$hmPageCount?'aria-disabled="true" tabindex="-1"':''?> href="<?=e($hmPageUrl(min($hmPageCount,$hmPage+1)))?>">Next <i class="fa-solid fa-chevron-right"></i></a>
</nav>
<?php endif;?>
</section>
</div></main>
<script>
(function(){
 const dest=document.getElementById('hotelDestination'), destSearch=document.getElementById('hotelDestinationSearch');
 const country=document.getElementById('hotelGeoCountry'), state=document.getElementById('hotelGeoState'), city=document.getElementById('hotelGeoCity'), match=document.getElementById('hotelGeoMatch');
 const hotelName=document.getElementById('hotelNameSmart'), searchBtn=document.getElementById('hotelSearchBtn'), searchPanel=document.getElementById('hotelSearchPanel'), searchResults=document.getElementById('hotelSearchResults'), searchStatus=document.getElementById('hotelSearchStatus'), googleBadge=document.getElementById('googleSearchBadge');
 const placeId=document.getElementById('googlePlaceId'), googleRating=document.getElementById('googleRating'), googleRatingsTotal=document.getElementById('googleRatingsTotal');
 const original=dest?[...dest.options].map(o=>({value:o.value,text:o.text,name:o.dataset.name||'',country:o.dataset.country||'',selected:o.selected})) : [];
 let searchTimer=null, searchSerial=0, resultStore={internal:[],google:[]};
 function norm(v){return (v||'').toString().trim().toLowerCase().replace(/\s+/g,' ');}
 function esc(v){return (v??'').toString().replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
 function setOptions(el,items,placeholder,current=''){if(!el)return;el.innerHTML='';el.add(new Option(placeholder,''));(items||[]).forEach(v=>el.add(new Option(v,v)));if(current&&[...el.options].some(o=>o.value===current))el.value=current;}
 async function geoGet(action,params={}){const url=new URL('<?=e(BASE_URL.'admin-destinations.php')?>',window.location.href);url.searchParams.set('geo_ajax',action);Object.entries(params).forEach(([k,v])=>url.searchParams.set(k,v));const r=await fetch(url,{credentials:'same-origin',headers:{'Accept':'application/json'}});const d=await r.json();if(!r.ok||!d.success)throw new Error(d.message||'Geo data unavailable');return d.data||[];}
 async function initCountries(){try{const rows=await geoGet('countries');const current=country.dataset.current||'';setOptions(country,rows,'Select Country',current);if(country.value)await loadStates(true);}catch(e){if(match)match.textContent='Geo list unavailable. Destination/Hotel can still be entered manually.';} updateHotelSearchState();}
 async function loadStates(keep=false){const c=country.value;setOptions(state,[],'Loading...');state.disabled=true;setOptions(city,[],'Select District / City');city.disabled=true;clearHotelSearch(false);if(!c){updateHotelSearchState();return;}try{const rows=await geoGet('states',{country:c});const cur=keep?(state.dataset.current||''):'';setOptions(state,rows,'Select State / Region',cur);state.disabled=false;if(state.value)await loadCities(true);autoMatch();}catch(e){setOptions(state,[],'State list unavailable');}updateHotelSearchState();}
 async function loadCities(keep=false){const c=country.value,s=state.value;setOptions(city,[],'Loading city list...');city.disabled=true;clearHotelSearch(false);if(!c||!s){autoMatch();updateHotelSearchState();return;}try{const rows=await geoGet('cities',{country:c,state:s});const cur=keep?(city.dataset.current||''):'';setOptions(city,rows,rows.length?'Select District / City':'No saved city yet',cur);city.disabled=rows.length===0;if(!keep&&rows.length)city.value='';autoMatch();}catch(e){setOptions(city,[],'Unable to load city list');city.disabled=true;autoMatch();}updateHotelSearchState();}
 function destinationOptionBy(name,countryName){const n=norm(name),c=norm(countryName);if(!n)return null;return [...dest.options].find(o=>o.value&&norm(o.dataset.name)===n&&(!c||!o.dataset.country||norm(o.dataset.country)===c))||null;}
 function autoMatch(){if(!dest)return;const c=country?.value||'',s=state?.value||'',ci=city?.value||'';let option=null,matchedBy='';if(ci){option=destinationOptionBy(ci,c);if(option)matchedBy='city';}if(!option&&s){option=destinationOptionBy(s,c);if(option)matchedBy='state';}if(option){dest.value=option.value;if(match){const cityText=ci?' · Hotel City: '+esc(ci):'';const via=matchedBy==='state'&&ci?' <span style="color:#587087">(tour area auto-matched)</span>':'';match.innerHTML='<b>Auto-matched Destination:</b> '+esc(option.text)+cityText+via+' · Search the hotel in step 5.';}}else{dest.value='';if(match)match.innerHTML=(ci||s)?'<b>No matching Destination Master record found.</b> Add the destination once in Destination Master, then Hotel Search will activate.':'Select Country → State → District/City and Destination / Tour Area will auto-fetch.';}clearHotelSearch(false);updateHotelSearchState();}
 function filterDest(){if(!dest)return;const term=norm(destSearch?.value||''),current=dest.value;dest.innerHTML='';original.forEach(o=>{if(!term||!o.value||norm(o.text).includes(term)){const n=new Option(o.text,o.value,false,o.value===current);n.dataset.name=o.name;n.dataset.country=o.country;dest.add(n);}});updateHotelSearchState();}
 function updateHotelSearchState(){const ready=!!(dest?.value&&city?.value);if(searchBtn)searchBtn.disabled=!ready;if(hotelName){hotelName.placeholder=ready?'Search hotel in '+city.value:'Choose city first, then search hotel';}if(!ready&&searchPanel)searchPanel.hidden=true;}
 function clearHotelSearch(clearGoogle=true){if(searchResults)searchResults.innerHTML='';if(searchPanel)searchPanel.hidden=true;resultStore={internal:[],google:[]};if(clearGoogle){if(placeId)placeId.value='';if(googleRating)googleRating.value='';if(googleRatingsTotal)googleRatingsTotal.value='';}}
 function ratingText(row){if(row.rating===null||row.rating===undefined||row.rating==='')return '';return '★ '+Number(row.rating).toFixed(1)+(row.rating_count?' · '+Number(row.rating_count).toLocaleString()+' reviews':'');}
 function renderCard(row,source,index){const existing=Number(row.existing_id||0)>0;const photo=row.image||row.photo_url||'';const addr=row.address||[row.area,row.city].filter(Boolean).join(', ');return '<article class="hotel-search-card '+(existing?'existing':'')+'"><div class="hotel-search-thumb">'+(photo?'<img src="'+esc(photo)+'" alt="">':'<i class="fa-solid fa-hotel"></i>')+'</div><div class="hotel-search-copy"><strong>'+esc(row.name||'Hotel')+'</strong><div class="addr">'+esc(addr||city?.value||'')+'</div>'+(ratingText(row)?'<div class="rating">'+esc(ratingText(row))+'</div>':'')+(source==='internal'?'<div class="rating">TRAVSCOPE Hotel Master'+(row.star?' · '+esc(row.star)+'★':'')+'</div>':'<div class="rating"><i class="fa-brands fa-google"></i> Google Places'+(row.photo_attribution?' · Photo: '+esc(row.photo_attribution):'')+'</div>')+'</div><div class="hotel-search-actions">'+(existing?'<a class="btn soft" href="admin-hotels.php?edit='+encodeURIComponent(row.existing_id)+'#hotelForm"><i class="fa-solid fa-pen"></i> Open Existing</a>':'<button type="button" class="btn primary choose-hotel" data-source="'+source+'" data-index="'+index+'"><i class="fa-solid fa-plus"></i> Use Hotel</button>')+(row.google_maps_url?'<a class="btn soft" href="'+esc(row.google_maps_url)+'" target="_blank" rel="noopener"><i class="fa-solid fa-map-location-dot"></i> Map</a>':'')+'</div></article>';}
 function renderResults(data){resultStore={internal:data.internal||[],google:data.google||[]};const chunks=[];resultStore.internal.forEach((r,i)=>chunks.push(renderCard(r,'internal',i)));resultStore.google.forEach((r,i)=>chunks.push(renderCard(r,'google',i)));if(!chunks.length)chunks.push('<div class="search-empty"><i class="fa-solid fa-magnifying-glass"></i> No matching hotel found. You can still type the hotel name manually and complete the form below.</div>');if(!data.google_configured)chunks.push('<div class="google-note"><i class="fa-brands fa-google"></i> Google hotel search is not configured. TRAVSCOPE Hotel Master search is working; add GOOGLE_PLACES_API_KEY in config.php to enable live Google Places results.</div>');else if(data.google_error)chunks.push('<div class="google-note"><i class="fa-solid fa-triangle-exclamation"></i> Google search temporarily unavailable: '+esc(data.google_error)+'</div>');if(searchResults)searchResults.innerHTML=chunks.join('');if(searchPanel)searchPanel.hidden=false;if(googleBadge){googleBadge.textContent=data.google_configured?'TRAVSCOPE + GOOGLE':'TRAVSCOPE';}if(searchStatus){searchStatus.textContent=(resultStore.internal.length+' master match'+(resultStore.internal.length===1?'':'es')+' · '+resultStore.google.length+' Google result'+(resultStore.google.length===1?'':'s'));}}
 async function searchHotels(){const q=(hotelName?.value||'').trim();if(!dest?.value||!city?.value){updateHotelSearchState();return;}if(q.length<2){if(searchPanel)searchPanel.hidden=false;if(searchResults)searchResults.innerHTML='<div class="search-empty">Type at least 2 letters of the hotel name.</div>';return;}const serial=++searchSerial;if(searchPanel)searchPanel.hidden=false;if(searchResults)searchResults.innerHTML='<div class="search-empty"><i class="fa-solid fa-spinner fa-spin"></i> Searching '+esc(city.value)+' hotels…</div>';if(searchStatus)searchStatus.textContent='Searching Hotel Master and Google Places…';try{const u=new URL('<?=e(BASE_URL.'hotel-search-api.php')?>',window.location.href);u.searchParams.set('destination_id',dest.value);u.searchParams.set('city',city.value||'');u.searchParams.set('state',state?.value||'');u.searchParams.set('country',country?.value||'');u.searchParams.set('q',q);const r=await fetch(u,{credentials:'same-origin',headers:{'Accept':'application/json'}});const d=await r.json();if(serial!==searchSerial)return;if(!r.ok||!d.success)throw new Error(d.message||'Hotel search failed');renderResults(d);}catch(e){if(serial!==searchSerial)return;if(searchResults)searchResults.innerHTML='<div class="search-empty">'+esc(e.message||'Hotel search unavailable')+'</div>';if(searchStatus)searchStatus.textContent='Search unavailable';}}
 function setField(name,value){const el=document.querySelector('[name="'+name+'"]');if(el&&value!==undefined&&value!==null&&String(value)!=='')el.value=String(value);}
 function chooseHotel(row,source){if(!row)return;hotelName.value=row.name||hotelName.value;if(source==='google'){if(placeId)placeId.value=row.place_id||'';if(googleRating)googleRating.value=row.rating??'';if(googleRatingsTotal)googleRatingsTotal.value=row.rating_count||'';setField('address',row.address||'');setField('pincode',row.pincode||'');setField('phone',row.phone||'');setField('website',row.website||'');setField('google_maps_url',row.google_maps_url||'');setField('latitude',row.latitude??'');setField('longitude',row.longitude??'');if(searchStatus)searchStatus.textContent='Google hotel selected. Details auto-filled below; choose the TRAVSCOPE hotel category and review before saving.';}else{if(placeId)placeId.value=row.place_id||'';if(googleRating)googleRating.value=row.rating??'';if(googleRatingsTotal)googleRatingsTotal.value=row.rating_count||'';setField('address',row.address||'');setField('area',row.area||'');setField('pincode',row.pincode||'');setField('phone',row.phone||'');setField('email',row.email||'');setField('website',row.website||'');setField('google_maps_url',row.google_maps_url||'');setField('latitude',row.latitude??'');setField('longitude',row.longitude??'');}if(searchResults)searchResults.querySelectorAll('.hotel-search-card').forEach(x=>x.style.opacity='.55');const star=document.querySelector('[name="star_category"]');if(source==='internal'&&star&&row.star&&[...star.options].some(o=>o.value==String(row.star)))star.value=String(row.star);document.querySelector('[name="star_category"]')?.focus();}
 if(searchResults)searchResults.addEventListener('click',e=>{const btn=e.target.closest('.choose-hotel');if(!btn)return;const source=btn.dataset.source||'';const idx=Number(btn.dataset.index||0);chooseHotel((resultStore[source]||[])[idx],source);});
 if(searchBtn)searchBtn.addEventListener('click',searchHotels);
 if(hotelName)hotelName.addEventListener('input',()=>{if(placeId)placeId.value='';if(googleRating)googleRating.value='';if(googleRatingsTotal)googleRatingsTotal.value='';clearTimeout(searchTimer);if((hotelName.value||'').trim().length>=2&&dest?.value&&city?.value)searchTimer=setTimeout(searchHotels,450);});
 if(destSearch)destSearch.addEventListener('input',filterDest);
 if(country)country.addEventListener('change',()=>loadStates(false));
 if(state)state.addEventListener('change',()=>loadCities(false));
 if(city)city.addEventListener('change',autoMatch);
 if(dest)dest.addEventListener('change',()=>{const o=dest.options[dest.selectedIndex];if(match&&o&&o.value)match.innerHTML='<b>Selected Destination:</b> '+esc(o.text)+(city?.value?' · City: '+esc(city.value):'')+' · Search the hotel in step 5.';clearHotelSearch(false);updateHotelSearchState();});
 initCountries();
 const photos=document.getElementById('hotelPhotos'),preview=document.getElementById('newPhotoPreview');if(photos&&preview){photos.addEventListener('change',()=>{preview.innerHTML='';[...photos.files].slice(0,10).forEach(file=>{const box=document.createElement('div');box.className='photo';const img=document.createElement('img');img.src=URL.createObjectURL(file);box.appendChild(img);preview.appendChild(box);});});}
 const fd=document.getElementById('filterDestination'),fl=document.getElementById('filterLocation');if(fd&&fl){fd.addEventListener('change',async()=>{const id=parseInt(fd.value||'0',10)||0;fl.innerHTML='<option value="0">All locations</option>';if(!id)return;try{const r=await fetch('<?=e(BASE_URL.'hotel-master-api.php')?>?destination_id='+id,{credentials:'same-origin'});const d=await r.json();(d.locations||[]).forEach(x=>fl.add(new Option(x.name+(x.hotel_count?' ('+x.hotel_count+')':''),x.id)));}catch(e){}});}
})();

</script><script src="assets/travscope-pro-admin.js?v=20260919-v18-1" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script></body></html>
