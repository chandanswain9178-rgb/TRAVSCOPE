<?php
/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| ADMIN - CANCELLATIONS
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/cancellation-workflow-functions.php';
require_once __DIR__ . '/cancellation-mail-functions.php';
require_once __DIR__ . '/cancellation-costing-functions.php';
require_once __DIR__ . '/billing-functions.php';

$amendmentFunctionsFile = __DIR__ . '/amendment-functions.php';
if (is_file($amendmentFunctionsFile)) { require_once $amendmentFunctionsFile; }

requireAdmin();

$admin = currentAdmin($pdo);

if (!$admin) {
    unset($_SESSION[ADMIN_SESSION_KEY]);
    redirect(BASE_URL . 'login.php');
}

/*
|--------------------------------------------------------------------------
| SETTINGS
|--------------------------------------------------------------------------
*/

$siteName = 'TRAVSCOPE.COM';
$currencySymbol = '₹';

try {
    $siteName = getSetting($pdo, 'site_name', 'TRAVSCOPE.COM');
    $currencySymbol = getSetting($pdo, 'currency_symbol', '₹');
} catch (Throwable $e) {
    error_log('Admin cancellations settings error: ' . $e->getMessage());
}

/*
|--------------------------------------------------------------------------
| FLASH
|--------------------------------------------------------------------------
*/

$success = '';
$error = '';

if (!empty($_SESSION['admin_cancellation_success'])) {
    $success = (string)$_SESSION['admin_cancellation_success'];
    unset($_SESSION['admin_cancellation_success']);
}

if (!empty($_SESSION['admin_cancellation_error'])) {
    $error = (string)$_SESSION['admin_cancellation_error'];
    unset($_SESSION['admin_cancellation_error']);
}

if (!empty($_SESSION['admin_cancellation_mail_notice'])) {
    $mailNotice = (string)$_SESSION['admin_cancellation_mail_notice'];
    unset($_SESSION['admin_cancellation_mail_notice']);
} else { $mailNotice=''; }

/*
|--------------------------------------------------------------------------
| PROCESS APPROVE / REJECT
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCsrf((string)($_POST['csrf_token'] ?? ''))) {
        $_SESSION['admin_cancellation_error'] =
            'Security validation failed. Please refresh and try again.';
        redirect(BASE_URL . 'admin-cancellations.php');
    }

    $cancellationId = (int)($_POST['cancellation_id'] ?? 0);
    $action = strtolower(trim((string)($_POST['action'] ?? '')));

    // Cancelled bookings created by the former Bookings/Booking Details buttons
    // are listed read-only until an administrator creates their missing case.
    if ($action === 'open_legacy_case') {
        try {
            $bookingId = max(0,(int)($_POST['booking_id'] ?? 0));
            $caseId = tsCancelOpenLegacyCase($pdo,$bookingId,(int)($admin['id'] ?? 0));
            $_SESSION['admin_cancellation_success'] = 'Historical cancelled booking linked to cancellation case #'.$caseId.'. Please record the financial/refund assessment.';
            redirect(BASE_URL . 'admin-cancellations.php?search=' . urlencode((string)($_POST['booking_number'] ?? '')));
        } catch (Throwable $e) {
            error_log('Cancellation legacy case: '.$e->getMessage());
            $_SESSION['admin_cancellation_error'] = $e instanceof RuntimeException ? $e->getMessage() : 'Unable to open the old cancellation case.';
            redirect(BASE_URL . 'admin-cancellations.php');
        }
    }

    if ($action === 'send_cancellation_mail') {
        $result=tsCancelSendMail($pdo,$cancellationId,'update',(int)($admin['id']??0),true);
        $_SESSION[$result['ok'] ? 'admin_cancellation_success' : 'admin_cancellation_error']=(string)$result['message'];
        redirect(BASE_URL . 'admin-cancellations.php?case='.$cancellationId.'#case-'.$cancellationId);
    }

    if ($action === 'record_financial') {
        try {
            if ($cancellationId <= 0 || !tsAmendCancellationFinanceReady($pdo)) throw new RuntimeException('Cancellation finance is not available.');
            $pdo->beginTransaction();
            $s=$pdo->prepare("SELECT bc.booking_id,bc.status,b.booking_status,b.total_amount,b.paid_amount FROM booking_cancellations bc JOIN bookings b ON b.id=bc.booking_id WHERE bc.id=? LIMIT 1 FOR UPDATE");
            $s->execute([$cancellationId]);
            $r=$s->fetch(PDO::FETCH_ASSOC);
            if (!$r || $r['status'] !== 'approved' || $r['booking_status'] !== 'cancelled') throw new RuntimeException('This cancellation case must already be approved and the booking cancelled.');
            if (tsAmendCancellationFinancial($pdo,$cancellationId)) throw new RuntimeException('A finance assessment already exists. Use the refund payment actions below.');
            [$supplierPaid] = tsCancelSupplierPaid($pdo, (int)$r['booking_id']);
            // Do not trust posted financial totals, retained paid balance or proposed refund.
            $assessment = tsCancelComputeAssessment((float)$r['total_amount'], (float)$r['paid_amount'], $supplierPaid, $_POST);
            tsAmendSaveCancellationFinancial($pdo,$cancellationId,(int)$r['booking_id'],(int)$admin['id'],(float)$r['paid_amount'],$assessment);
            $pdo->commit();
            $financeSynced=false;
            // Safe and idempotent: a pending refund is created only if the amount is > 0.
            // Keep the already-committed assessment visible even if ledger sync fails.
            try {
                if (tsBillReady($pdo)) {
                    tsBillSyncRefundObligations($pdo,(int)$r['booking_id'],(int)$admin['id']);
                    $financeSynced=true;
                    $_SESSION['admin_cancellation_success'] = 'Cancellation financial impact recorded. Any customer refund is PENDING until a transfer is verified.';
                } else {
                    $_SESSION['admin_cancellation_success'] = 'Assessment recorded. Billing tables could not be verified; pending refund ledger requires review in Booking Billing.';
                }
            } catch (Throwable $syncError) {
                error_log('Cancellation refund ledger sync: '.$syncError->getMessage());
                $_SESSION['admin_cancellation_success'] = 'Assessment saved. Refund ledger sync needs attention; reopen this case or check Booking Billing before making a transfer.';
            }
            if ($financeSynced) {
                $notice=tsCancelSendMail($pdo,$cancellationId,'assessment',(int)$admin['id']);
                if (!$notice['ok']) $_SESSION['admin_cancellation_mail_notice']=(string)$notice['message'];
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('Cancellation financial review: '.$e->getMessage());
            $_SESSION['admin_cancellation_error'] = $e instanceof RuntimeException ? $e->getMessage() : 'Could not record cancellation finance.';
        }
        redirect(BASE_URL . 'admin-cancellations.php?status=approved&case='.$cancellationId.'#case-'.$cancellationId);
    }

    if ($action === 'mark_refund_paid') {
        try {
            $refundId=max(0,(int)($_POST['customer_refund_id'] ?? 0));
            $method=trim((string)($_POST['refund_method'] ?? ''));
            $reference=trim((string)($_POST['refund_reference'] ?? ''));
            if ($cancellationId <= 0 || $refundId <= 0 || $reference === '' || mb_strlen($reference)>190) throw new RuntimeException('Select a refund and enter the actual bank/UPI refund reference.');
            if (!in_array($method,['bank_transfer','upi','cash','other'],true)) throw new RuntimeException('Select a valid refund method.');
            $s=$pdo->prepare("SELECT r.booking_id FROM booking_customer_refunds r JOIN booking_cancellations bc ON bc.id=r.source_id AND bc.booking_id=r.booking_id WHERE r.id=? AND r.source_type='cancellation' AND r.source_id=? AND r.status='pending' AND bc.status='approved' LIMIT 1");
            $s->execute([$refundId,$cancellationId]);
            $bookingId=(int)($s->fetchColumn()?:0);
            if (!$bookingId) throw new RuntimeException('This pending refund does not belong to the selected cancellation.');
            tsBillMarkRefundPaid($pdo,$bookingId,$refundId,(int)$admin['id'],$method,$reference,trim((string)($_POST['refund_notes'] ?? '')));
            $notice=tsCancelSendMail($pdo,$cancellationId,'refund_paid',(int)$admin['id']);
            if (!$notice['ok']) $_SESSION['admin_cancellation_mail_notice']=(string)$notice['message'];
            $_SESSION['admin_cancellation_success'] = 'Customer refund recorded as PAID. Booking net-paid amount and cancellation finance have been updated.';
        } catch (Throwable $e) {
            error_log('Mark cancellation refund paid: '.$e->getMessage());
            $_SESSION['admin_cancellation_error'] = $e instanceof RuntimeException ? $e->getMessage() : 'Unable to verify the refund.';
        }
        redirect(BASE_URL . 'admin-cancellations.php?status=approved&case='.$cancellationId.'#case-'.$cancellationId);
    }

    if ($action === 'supplier_refund_received') {
        try {
            if ($cancellationId <= 0 || !tsAmendCancellationFinanceReady($pdo)) throw new RuntimeException('Cancellation finance is unavailable.');
            $reference=trim((string)($_POST['supplier_refund_reference'] ?? ''));
            if ($reference === '' || mb_strlen($reference)>190) throw new RuntimeException('Enter a supplier refund receipt reference.');
            $s=$pdo->prepare("UPDATE booking_cancellation_financials f INNER JOIN booking_cancellations bc ON bc.id=f.booking_cancellation_id SET f.supplier_refund_status='received', f.supplier_finance_note=CONCAT_WS(CHAR(10),NULLIF(f.supplier_finance_note,''),?),f.updated_at=NOW() WHERE f.booking_cancellation_id=? AND bc.status='approved' AND f.supplier_refund_status='pending' AND f.supplier_refund_expected>0");
            $s->execute(['Supplier refund received. Ref: '.$reference,$cancellationId]);
            if ($s->rowCount()<1) throw new RuntimeException('No pending supplier refund for this cancellation.');
            $_SESSION['admin_cancellation_success']='Supplier refund marked received with its reference.';
        } catch (Throwable $e) {
            error_log('Supplier cancellation refund: '.$e->getMessage());
            $_SESSION['admin_cancellation_error'] = $e instanceof RuntimeException ? $e->getMessage() : 'Unable to record supplier refund.';
        }
        redirect(BASE_URL . 'admin-cancellations.php?status=approved&case='.$cancellationId.'#case-'.$cancellationId);
    }
    $adminNotes = trim((string)($_POST['admin_notes'] ?? ''));

    if ($cancellationId <= 0 || !in_array($action, ['approve', 'reject'], true)) {
        $_SESSION['admin_cancellation_error'] = 'Invalid cancellation action.';
        redirect(BASE_URL . 'admin-cancellations.php');
    }

    if (mb_strlen($adminNotes) > 3000) {
        $_SESSION['admin_cancellation_error'] = 'Admin notes are too long.';
        redirect(BASE_URL . 'admin-cancellations.php');
    }

    try {

        $pdo->beginTransaction();

        $stmt = $pdo->prepare("
            SELECT
                bc.id,
                bc.booking_id,
                bc.status,
                b.booking_status,
                b.payment_status,
                b.paid_amount,
                b.total_amount
            FROM booking_cancellations bc
            INNER JOIN bookings b
                ON b.id = bc.booking_id
            WHERE bc.id = ?
            LIMIT 1
            FOR UPDATE
        ");

        $stmt->execute([$cancellationId]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$request) {
            throw new RuntimeException('Cancellation request not found.');
        }

        if (strtolower((string)$request['status']) !== 'pending') {
            throw new RuntimeException('This cancellation request has already been processed.');
        }

        if ($action === 'approve') {

            if (function_exists('tsAmendCancellationFinanceReady') && tsAmendCancellationFinanceReady($pdo)) {
                [$supplierPaid] = tsCancelSupplierPaid($pdo, (int)$request['booking_id']);
                $assessment = tsCancelComputeAssessment((float)$request['total_amount'], (float)$request['paid_amount'], $supplierPaid, $_POST);
                tsAmendSaveCancellationFinancial($pdo,$cancellationId,(int)$request['booking_id'],(int)($admin['id'] ?? 0),(float)$request['paid_amount'],$assessment);
            }

            $stmt = $pdo->prepare("
                UPDATE booking_cancellations
                SET
                    status = 'approved',
                    admin_notes = ?,
                    processed_at = NOW()
                WHERE id = ?
                  AND status = 'pending'
            ");
            $stmt->execute([
                $adminNotes !== '' ? $adminNotes : null,
                $cancellationId
            ]);

            $stmt = $pdo->prepare("
                UPDATE bookings
                SET booking_status = 'cancelled'
                WHERE id = ?
            ");
            $stmt->execute([(int)$request['booking_id']]);

            $paidAmount = (float)$request['paid_amount'];
            $paymentStatus = strtolower((string)$request['payment_status']);

            if ($paidAmount > 0 || in_array($paymentStatus, ['paid', 'partial'], true)) {
                $_SESSION['admin_cancellation_success'] =
                    'Cancellation approved. Booking marked cancelled. Payment exists, so review the refund separately before marking it refunded.';
            } else {
                $_SESSION['admin_cancellation_success'] =
                    'Cancellation approved and booking marked cancelled.';
            }

        } else {

            $stmt = $pdo->prepare("
                UPDATE booking_cancellations
                SET
                    status = 'rejected',
                    admin_notes = ?,
                    processed_at = NOW()
                WHERE id = ?
                  AND status = 'pending'
            ");
            $stmt->execute([
                $adminNotes !== '' ? $adminNotes : null,
                $cancellationId
            ]);

            $_SESSION['admin_cancellation_success'] =
                'Cancellation request rejected. The booking status was not changed.';
        }

        $pdo->commit();
        $notice=tsCancelSendMail($pdo,$cancellationId,$action==='approve'?'approved':'rejected',(int)($admin['id']??0));
        if (!$notice['ok']) $_SESSION['admin_cancellation_mail_notice']=(string)$notice['message'];

    } catch (Throwable $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        error_log('Admin cancellation processing error: ' . $e->getMessage());

        $_SESSION['admin_cancellation_error'] =
            $e instanceof RuntimeException
                ? $e->getMessage()
                : 'Unable to process this cancellation request.';
    }

    redirect(BASE_URL . 'admin-cancellations.php?case='.$cancellationId.'#case-'.$cancellationId);
}

/*
|--------------------------------------------------------------------------
| FILTER / SEARCH
|--------------------------------------------------------------------------
*/

$statusFilter = strtolower(trim((string)($_GET['status'] ?? 'all')));

if (!in_array($statusFilter, ['all', 'pending', 'approved', 'rejected'], true)) {
    $statusFilter = 'all';
}

$search = trim((string)($_GET['search'] ?? ''));
$focusCase = max(0,(int)($_GET['case'] ?? 0));

/*
|--------------------------------------------------------------------------
| COUNTS
|--------------------------------------------------------------------------
*/

$counts = [
    'all' => 0,
    'pending' => 0,
    'approved' => 0,
    'rejected' => 0
];

try {

    $stmt = $pdo->query("
        SELECT status, COUNT(*) AS total
        FROM booking_cancellations
        GROUP BY status
    ");

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $status = strtolower((string)$row['status']);
        $total = (int)$row['total'];
        $counts['all'] += $total;

        if (isset($counts[$status])) {
            $counts[$status] = $total;
        }
    }

} catch (Throwable $e) {
    error_log('Admin cancellation counts error: ' . $e->getMessage());
}

/*
|--------------------------------------------------------------------------
| FETCH REQUESTS
|--------------------------------------------------------------------------
*/

$requests = [];

try {

    $where = ['1=1'];
    $params = [];

    if ($statusFilter !== 'all') {
        $where[] = 'bc.status = ?';
        $params[] = $statusFilter;
    }

    if ($search !== '') {
        $where[] = "(
            b.booking_number LIKE ?
            OR b.customer_name LIKE ?
            OR b.customer_email LIKE ?
            OR b.customer_mobile LIKE ?
            OR p.title LIKE ?
        )";

        $term = '%' . $search . '%';

        for ($i = 0; $i < 5; $i++) {
            $params[] = $term;
        }
    }

    $sql = "
        SELECT
            bc.id AS cancellation_id,
            bc.booking_id,
            bc.user_id,
            bc.reason,
            bc.status AS cancellation_status,
            bc.admin_notes,
            bc.requested_at,
            bc.processed_at,
            bc.created_at,

            b.booking_number,
            b.customer_name,
            b.customer_email,
            b.customer_mobile,
            b.travel_date,
            b.total_amount,
            b.paid_amount,
            b.currency,
            b.booking_status,
            b.payment_status,

            p.title AS package_title,

            d.name AS destination_name,
            d.country AS destination_country

        FROM booking_cancellations bc

        INNER JOIN bookings b
            ON b.id = bc.booking_id

        LEFT JOIN packages p
            ON p.id = b.package_id

        LEFT JOIN destinations d
            ON d.id = p.destination_id

        WHERE " . implode(' AND ', $where) . "

        ORDER BY
            CASE bc.status
                WHEN 'pending' THEN 1
                WHEN 'approved' THEN 2
                WHEN 'rejected' THEN 3
                ELSE 4
            END,
            bc.id DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    error_log('Admin cancellations fetch error: ' . $e->getMessage());
    $error = $error ?: 'Unable to load cancellation requests.';
}

/*
|--------------------------------------------------------------------------
| LEGACY ADMIN-DIRECT CANCELLATIONS (READ-ONLY DISCOVERY)
|--------------------------------------------------------------------------
| Older cancellation buttons changed bookings.booking_status directly; they
| never inserted booking_cancellations. Show them without mutating on GET.
| A CSRF-protected action creates the case, then the refund review becomes live.
*/
$legacyTotal = 0;
try {
    $orphanCondition = "b.booking_status='cancelled' AND NOT EXISTS (SELECT 1 FROM booking_cancellations bc2 WHERE bc2.booking_id=b.id AND bc2.status IN ('pending','approved'))";
    $legacyTotal = (int)$pdo->query("SELECT COUNT(*) FROM bookings b WHERE ".$orphanCondition)->fetchColumn();
    $counts['all'] += $legacyTotal;
    $counts['approved'] += $legacyTotal;
    if (in_array($statusFilter,['all','approved'],true)) {
        $legacyWhere = [$orphanCondition];
        $legacyParams = [];
        if ($search !== '') {
            $legacyWhere[] = '(b.booking_number LIKE ? OR b.customer_name LIKE ? OR b.customer_email LIKE ? OR b.customer_mobile LIKE ? OR p.title LIKE ?)';
            $legacyParams = array_fill(0,5,'%'.$search.'%');
        }
        $legacyQuery = "SELECT 0 AS cancellation_id,b.id AS booking_id,b.user_id,
            'Administrative cancellation; review refund and supplier charges' AS reason,
            'approved' AS cancellation_status,
            'Historical booking cancelled directly; open a finance case to assess refunds' AS admin_notes,
            b.updated_at AS requested_at,b.updated_at AS processed_at,b.created_at,
            b.booking_number,b.customer_name,b.customer_email,b.customer_mobile,
            b.travel_date,b.total_amount,b.paid_amount,b.currency,b.booking_status,b.payment_status,
            p.title AS package_title,d.name AS destination_name,d.country AS destination_country
            FROM bookings b LEFT JOIN packages p ON p.id=b.package_id
            LEFT JOIN destinations d ON d.id=p.destination_id WHERE ".implode(' AND ',$legacyWhere)." ORDER BY b.updated_at DESC,b.id DESC";
        $legacyStmt=$pdo->prepare($legacyQuery);
        $legacyStmt->execute($legacyParams);
        foreach (($legacyStmt->fetchAll(PDO::FETCH_ASSOC) ?: []) as $legacyRow) {
            $legacyRow['legacy_case'] = true;
            $requests[] = $legacyRow;
        }
    }
} catch (Throwable $e) {
    error_log('Legacy cancellation discovery: '.$e->getMessage());
    $error = $error ?: 'Unable to display earlier direct-cancelled bookings.';
}

/*
|--------------------------------------------------------------------------
| ADMIN DISPLAY
|--------------------------------------------------------------------------
*/

$adminName = trim((string)($admin['name'] ?? 'Administrator'));

if ($adminName === '') {
    $adminName = 'Administrator';
}

$adminInitial = strtoupper(substr($adminName, 0, 1));

function cancellationStatusClass($status)
{
    switch (strtolower((string)$status)) {
        case 'approved':
            return 'green';
        case 'rejected':
            return 'red';
        default:
            return 'orange';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#07192d">

<title>Cancellations | <?= e($siteName); ?> Admin</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>
:root{
    --navy:#07192d;
    --navy2:#0b2948;
    --blue:#0b74ff;
    --blue-dark:#075fd2;
    --green:#07966a;
    --orange:#dc8618;
    --red:#dc4356;
    --bg:#f5f7fb;
    --white:#fff;
    --text:#172235;
    --muted:#788496;
    --border:#e4e9ef;
    --shadow:0 10px 35px rgba(7,25,45,.06);
}
*{margin:0;padding:0;box-sizing:border-box}
body{min-height:100vh;background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif}
a{text-decoration:none;color:inherit}
button,input,textarea{font:inherit}
.layout{display:grid;grid-template-columns:230px minmax(0,1fr);min-height:100vh}

/* SIDEBAR */
.sidebar{
    background:var(--navy);
    color:#fff;
    padding:22px 14px;
    position:sticky;
    top:0;
    height:100vh;
    overflow:auto
}
.logo{display:flex;align-items:center;gap:10px;padding:0 9px 22px;font:800 18px 'Manrope'}
.logo-icon{width:38px;height:38px;border-radius:11px;display:grid;place-items:center;background:linear-gradient(135deg,#0b74ff,#00b8ff)}
.logo span{color:#43b5ff}
.nav-title{padding:13px 10px 7px;color:#69829c;font-size:7px;font-weight:800;text-transform:uppercase;letter-spacing:1px}
.side-nav{display:flex;flex-direction:column;gap:4px}
.side-nav a{min-height:39px;padding:0 11px;border-radius:8px;display:flex;align-items:center;gap:10px;color:#a9bdd2;font-size:9px;font-weight:700}
.side-nav a i{width:17px;text-align:center}
.side-nav a:hover,.side-nav a.active{background:#102f50;color:#fff}
.side-nav a.active{box-shadow:inset 3px 0 var(--blue)}
.sidebar-bottom{margin-top:25px;padding:14px 10px;border-top:1px solid rgba(255,255,255,.08)}
.admin-mini{display:flex;align-items:center;gap:9px}
.admin-avatar{width:34px;height:34px;border-radius:9px;display:grid;place-items:center;background:var(--blue);font-size:10px;font-weight:800}
.admin-mini strong{display:block;font-size:9px}.admin-mini span{display:block;margin-top:2px;color:#7890a9;font-size:7px}

/* MAIN */
.main{min-width:0}
.topbar{height:68px;padding:0 28px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;background:#fff;position:sticky;top:0;z-index:50}
.topbar h1{font:800 17px 'Manrope';color:var(--navy)}
.topbar p{margin-top:2px;color:#8994a3;font-size:8px}
.view-site{min-height:34px;padding:0 11px;border:1px solid var(--border);border-radius:7px;display:inline-flex;align-items:center;gap:6px;color:#607086;font-size:8px;font-weight:800}

.content{padding:25px;max-width:1450px;margin:auto}
.alert{margin-bottom:16px;padding:12px 14px;border-radius:9px;font-size:9px;line-height:1.5}
.alert.success{background:#e9f9f2;color:#087d55;border:1px solid #c5eadb}
.alert.error{background:#fff0f2;color:#b33145;border:1px solid #f0c5cb}

/* STATS */
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:13px}
.stat{padding:16px;border:1px solid var(--border);border-radius:12px;background:#fff;box-shadow:var(--shadow);display:flex;align-items:center;gap:12px}
.stat-icon{width:41px;height:41px;border-radius:10px;display:grid;place-items:center;background:#edf5ff;color:var(--blue)}
.stat:nth-child(2) .stat-icon{background:#fff3e3;color:var(--orange)}
.stat:nth-child(3) .stat-icon{background:#e8f8f1;color:var(--green)}
.stat:nth-child(4) .stat-icon{background:#ffedef;color:var(--red)}
.stat span{display:block;color:#8a95a3;font-size:7px;font-weight:800;text-transform:uppercase}
.stat strong{display:block;margin-top:4px;font:800 19px 'Manrope';color:var(--navy)}

/* TOOLBAR */
.toolbar{margin-top:18px;padding:13px;border:1px solid var(--border);border-radius:11px;background:#fff;display:flex;align-items:center;justify-content:space-between;gap:12px}
.filters{display:flex;gap:6px;flex-wrap:wrap}
.filter{min-height:33px;padding:0 10px;border:1px solid var(--border);border-radius:7px;display:inline-flex;align-items:center;gap:5px;color:#69768a;font-size:8px;font-weight:800}
.filter.active{border-color:var(--blue);background:#edf5ff;color:var(--blue)}
.count{min-width:17px;height:17px;padding:0 4px;border-radius:15px;background:#edf0f4;display:grid;place-items:center;font-size:7px}
.filter.active .count{background:var(--blue);color:#fff}
.search{display:flex;gap:6px}.search input{width:240px;height:34px;padding:0 10px;border:1px solid var(--border);border-radius:7px;outline:none;font-size:8px}.search button{width:35px;border:0;border-radius:7px;background:var(--blue);color:#fff;cursor:pointer}

/* CARDS */
.list{margin-top:17px;display:flex;flex-direction:column;gap:13px}
.request{border:1px solid var(--border);border-radius:13px;background:#fff;box-shadow:var(--shadow);overflow:hidden}
.request-top{padding:12px 15px;border-bottom:1px solid var(--border);background:#fbfcfd;display:flex;align-items:center;justify-content:space-between;gap:12px}
.reference{font-size:8px;color:#7e8998}.reference strong{margin-left:4px;color:var(--navy);font-size:9px}
.status{padding:6px 9px;border-radius:20px;font-size:7px;font-weight:800;text-transform:uppercase}
.status.orange{background:#fff3e3;color:#ad680c}.status.green{background:#e8f8f1;color:#087d55}.status.red{background:#ffedef;color:#bd3447}
.request-body{padding:16px;display:grid;grid-template-columns:minmax(0,1.3fr) minmax(270px,.7fr);gap:20px}
.package h2{font:800 15px 'Manrope';color:var(--navy)}
.destination{margin-top:4px;color:#7c8999;font-size:8px}
.customer-grid{margin-top:13px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
.info{padding:9px;border-radius:7px;background:#f7f9fb}.info span{display:block;color:#8c97a5;font-size:6px;font-weight:800;text-transform:uppercase}.info strong{display:block;margin-top:3px;color:#465367;font-size:8px;word-break:break-word}
.reason{margin-top:11px;padding:11px;border-left:3px solid var(--orange);border-radius:0 7px 7px 0;background:#fff9ee;color:#675b48;font-size:8px;line-height:1.65}
.reason strong{display:block;margin-bottom:3px;color:#493f31}
.payment{padding-left:18px;border-left:1px solid var(--border)}
.money{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #edf0f3;font-size:8px}.money span{color:#8490a0}.money strong{color:#455267}
.refund-warning{margin-top:10px;padding:9px;border-radius:7px;background:#fff3e3;color:#9a620e;font-size:7px;line-height:1.5}
.processed{margin-top:10px;padding:10px;border-radius:7px;background:#f7f9fb;font-size:8px;color:#68768a;line-height:1.6}
.actions{margin-top:12px;display:flex;gap:6px;flex-wrap:wrap}
.btn{min-height:33px;padding:0 10px;border:0;border-radius:7px;display:inline-flex;align-items:center;justify-content:center;gap:5px;font-size:7px;font-weight:800;cursor:pointer}
.btn-primary{background:linear-gradient(135deg,var(--blue),var(--blue-dark));color:#fff}.btn-secondary{background:#fff;color:#607086;border:1px solid var(--border)}.btn-green{background:#e8f8f1;color:#087d55}.btn-red{background:#ffedef;color:#bd3447}
.process-form{margin-top:12px;padding-top:12px;border-top:1px solid var(--border)}
.process-form textarea{width:100%;min-height:68px;padding:9px;border:1px solid var(--border);border-radius:7px;outline:none;resize:vertical;font-size:8px}
.process-buttons{display:flex;gap:6px;margin-top:7px}
.empty{margin-top:17px;padding:60px 20px;border:1px solid var(--border);border-radius:13px;background:#fff;text-align:center;box-shadow:var(--shadow)}
.empty i{font-size:26px;color:var(--blue)}.empty h2{margin-top:12px;font:800 17px 'Manrope'}.empty p{margin-top:5px;color:#8490a0;font-size:9px}


/* V24.38 — compact case summary; expand only the case staff are working on. */
.ts-case-summary{display:grid;grid-template-columns:minmax(210px,1.7fr) minmax(140px,.9fr) repeat(3,minmax(105px,.65fr)) auto;gap:13px;align-items:center;padding:15px 17px;background:#fff}
.ts-case-summary .ts-primary strong{display:block;font:800 13px 'Manrope',sans-serif;color:#102d52;line-height:1.35}
.ts-case-summary .ts-primary small{display:block;margin-top:5px;color:#728198;font-size:10px;line-height:1.45}
.ts-case-summary .ts-cell small{display:block;color:#8491a4;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.3px;margin-bottom:5px}
.ts-case-summary .ts-cell b{display:block;font-size:12px;color:#273d59;overflow-wrap:anywhere}
.ts-case-summary .ts-cell.refund b{color:#047857}
.ts-case-pill{display:inline-flex;align-items:center;gap:5px;padding:5px 9px;border-radius:999px;font-size:10px;font-weight:800;white-space:nowrap}
.ts-case-pill.approved,.ts-case-pill.paid{background:#dff8ee;color:#047857}
.ts-case-pill.pending,.ts-case-pill.review{background:#fff3d9;color:#92400e}
.ts-case-pill.rejected{background:#ffe5e8;color:#b4233b}
.ts-case-buttons{display:flex;align-items:center;justify-content:flex-end;gap:7px;flex-wrap:wrap}
.ts-case-toggle{border:1px solid #cbdcf7;border-radius:9px;background:#eff6ff;color:#1d4ed8;font-size:11px;font-weight:800;cursor:pointer;padding:10px 12px;white-space:nowrap}
.ts-case-toggle[aria-expanded=true]{background:#1d4ed8;color:#fff}
.ts-case-detail[hidden]{display:none!important}
.ts-case-detail{border-top:1px solid #e6edf5;background:#fbfdff}
.ts-case-detail .request-top{display:none}
.ts-case-detail .request-body{padding:16px;gap:16px}
.ts-case-detail .reason{font-size:11px;margin-top:10px}
.ts-case-detail .info strong,.ts-case-detail .processed,.ts-case-detail .money,.ts-case-detail .destination{font-size:11px}
.ts-case-detail .info span{font-size:9px}
.ts-case-detail .money strong{font-size:12px}
.ts-case-detail .process-form label{display:block;font-size:11px;font-weight:750;margin:8px 0 4px}
.ts-case-detail .process-form input,.ts-case-detail .process-form select,.ts-case-detail .process-form textarea{padding:8px 10px;border:1px solid #ced9e9;border-radius:8px;font-size:12px;color:#132b49;background:#fff}
.ts-case-detail .btn{font-size:11px;min-height:36px}
.ts-case-detail .processed{line-height:1.6}
.ts-cancel-email{margin:12px 16px 15px;border:1px solid #cbdcf7;border-radius:11px;background:white;overflow:hidden}
.ts-cancel-email summary{cursor:pointer;list-style:none;padding:12px 14px;color:#143f73;font-weight:800;font-size:12px;display:flex;gap:7px;align-items:center;justify-content:space-between;background:#eff6ff}
.ts-cancel-email summary::-webkit-details-marker{display:none}
.ts-cancel-email .email-body{padding:12px 14px;font-size:11px;color:#39516d;line-height:1.6}
.ts-cancel-email pre{white-space:pre-wrap;word-wrap:break-word;margin:10px 0;padding:12px;border-radius:8px;background:#f6f8fc;border:1px solid #e4eaf4;font:11px/1.7 Arial,sans-serif;max-height:300px;overflow:auto}
.ts-cancel-email .email-body .btn{font-size:11px;min-height:36px}
@media(max-width:1160px){.ts-case-summary{grid-template-columns:minmax(190px,1.5fr) repeat(3,minmax(110px,.8fr)) auto}.ts-case-summary .ts-customer{display:none}}
@media(max-width:760px){.ts-case-summary{grid-template-columns:1fr 1fr;gap:12px}.ts-case-summary .ts-primary{grid-column:1/-1}.ts-case-buttons{grid-column:1/-1;justify-content:stretch}.ts-case-buttons>*{flex:1;text-align:center}.ts-case-summary .ts-customer{display:block}}

@media(max-width:1000px){
    .layout{grid-template-columns:72px minmax(0,1fr)}
    .sidebar{padding:18px 9px}.logo{padding:0 7px 20px}.logo-text,.nav-title,.side-nav a span,.admin-mini div:last-child{display:none}.side-nav a{justify-content:center;padding:0}.side-nav a i{width:auto}.admin-mini{justify-content:center}
    .request-body{grid-template-columns:1fr}.payment{padding:14px 0 0;border-left:0;border-top:1px solid var(--border)}
}
@media(max-width:700px){
    .layout{display:block}.sidebar{position:static;height:auto;padding:10px}.logo{justify-content:center;padding:4px 0 10px}.side-nav{display:grid;grid-template-columns:repeat(4,1fr)}.side-nav a{min-height:37px}.sidebar-bottom,.nav-title{display:none}
    .topbar{height:auto;padding:13px 14px}.content{padding:13px}.stats{grid-template-columns:1fr 1fr}.toolbar{align-items:stretch;flex-direction:column}.search{width:100%}.search input{width:auto;flex:1}.customer-grid{grid-template-columns:1fr}.request-top{align-items:flex-start;flex-direction:column}.process-buttons{flex-direction:column}.process-buttons .btn{width:100%}
}
</style>

<style>
/* READABILITY + RESPONSIVE UPGRADE — functionality unchanged */
html{font-size:16px}
body{font-size:15px;line-height:1.5}
.logo{font-size:20px}
.nav-title{font-size:11px}
.side-nav a{min-height:46px;padding:0 14px;gap:11px;font-size:14px;line-height:1.25}
.side-nav a i{font-size:15px;width:20px}
.admin-avatar{font-size:14px}.admin-mini strong{font-size:13px}.admin-mini span{font-size:11px}
.topbar{min-height:72px;height:auto}.topbar h1{font-size:21px}.topbar p{font-size:13px}
.view-site{min-height:42px;padding:0 15px;font-size:13px}
.alert{font-size:13px}
.stat span{font-size:11px}.stat strong{font-size:23px}.stat-icon{font-size:16px}
.filter{min-height:40px;padding:0 13px;font-size:13px}
.count{min-width:21px;height:21px;font-size:11px}
.search input{width:280px;height:40px;padding:0 12px;font-size:13px}
.search button{width:42px;min-height:40px;font-size:14px}
.reference{font-size:12px}.reference strong{font-size:13px}
.status{padding:7px 11px;font-size:11px}
.package h2{font-size:18px}.destination{font-size:13px}
.info{padding:11px}.info span{font-size:10px}.info strong{font-size:13px}
.reason{padding:13px;font-size:13px;line-height:1.65}
.money{font-size:13px}.refund-warning{font-size:12px}.processed{font-size:13px}
.btn{min-height:40px;padding:0 14px;gap:7px;font-size:12px}
.process-form textarea{min-height:90px;padding:11px;font-size:13px}
.empty p{font-size:13px}

@media(max-width:1000px){
 .layout{grid-template-columns:84px minmax(0,1fr)}
 .side-nav a{min-height:46px}.side-nav a i{font-size:17px}
}
@media(max-width:700px){
 .layout{display:block}
 .sidebar{position:relative;top:auto;height:auto;overflow:visible;padding:10px}
 .side-nav{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px}
 .side-nav a{min-height:48px;padding:6px;justify-content:center;font-size:12px}
 .side-nav a i{font-size:17px}
 .topbar{padding:14px}.topbar h1{font-size:19px}.topbar p{font-size:12px}
 .view-site{font-size:12px}.content{padding:13px}
 .stats{grid-template-columns:1fr 1fr}
 .toolbar{align-items:stretch;flex-direction:column}
 .filters{display:grid;grid-template-columns:1fr 1fr;gap:7px}
 .filter{justify-content:center}
 .search{width:100%}.search input{width:auto;min-width:0;flex:1}
 .request-body{grid-template-columns:1fr}.customer-grid{grid-template-columns:1fr}
 .request-top{align-items:flex-start;flex-direction:column}
 .payment{padding:14px 0 0;border-left:0;border-top:1px solid var(--border)}
 .process-buttons{flex-direction:column}.process-buttons .btn{width:100%}
}
@media(max-width:430px){
 .stats{grid-template-columns:1fr}
 .side-nav{grid-template-columns:repeat(3,minmax(0,1fr))}
 .topbar{align-items:flex-start;gap:10px;flex-direction:column}
 .view-site{width:100%;justify-content:center}
 .request-body{padding:13px}
}


/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.layout{
    display:block!important;
    grid-template-columns:none!important;
    min-height:100vh!important;
}
.main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
    padding:16px 18px 20px!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
<style>
/* V24.37 cancellation review: accurate, independent customer/supplier maths */
.ts-cancel-assessment{margin:12px 0;padding:16px;border:1px solid #bed3f8;background:linear-gradient(135deg,#f7faff,#fff);border-radius:16px;color:#142c52;font-size:13px}
.ts-cancel-assessment h4{font-size:15px;font-weight:850;color:#124b8a;margin:0 0 12px;display:flex;align-items:center;gap:8px}
.ts-ca-metrics,.ts-ca-result{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin:11px 0}
.ts-ca-metrics div,.ts-ca-result div{border:1px solid #dbe6f5;border-radius:11px;background:white;padding:11px 12px;min-width:0}
.ts-ca-metrics small,.ts-ca-result small{display:block;font-size:11px;color:#57708f;font-weight:750;margin-bottom:5px}
.ts-ca-metrics strong,.ts-ca-result strong{font-weight:850;font-size:16px;color:#123767;display:block;font-variant-numeric:tabular-nums}
.ts-ca-result .ts-ca-highlight{background:#ecfdf5;border-color:#86efac}.ts-ca-highlight strong{color:#087a56;font-size:19px}
.ts-ca-row{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:12px 0}
.ts-cancel-assessment label{font-size:12px;font-weight:800;color:#24446b;display:block;margin:6px 0}
.ts-cancel-assessment input[type=number],.ts-cancel-assessment select,.ts-cancel-assessment textarea{width:100%;min-height:42px;border:1px solid #cad8e9;border-radius:9px;background:white;padding:9px 11px;color:#18365b;box-sizing:border-box;font-size:13px;font-family:inherit}
.ts-cancel-assessment textarea{min-height:68px;resize:vertical}
.ts-ca-help,.ts-ca-equation{display:block;font-size:11px;line-height:1.5;color:#60758e;margin:5px 0}
.ts-ca-warning{background:#fff7ed;border:1px solid #fdba74;border-radius:9px;padding:9px;color:#9a3412;font-weight:650;font-size:12px}
.ts-ca-supplier{border:1px solid #ded4fb;border-radius:11px;background:#faf8ff;margin:14px 0;padding:11px}
.ts-ca-supplier>summary{cursor:pointer;color:#5b21b6;font-weight:800;font-size:13px;list-style:disclosure-closed}
.ts-ca-supplier p{font-size:11px;line-height:1.6;color:#574d76;margin:10px 0}
.ts-ca-check{display:flex!important;align-items:flex-start;gap:8px;line-height:1.5;padding:9px;background:#f0fdf4;border-radius:8px}
.ts-ca-check input{margin-top:3px}
.ts-ca-supplier[open]>summary{margin-bottom:9px}
@media(max-width:650px){.ts-ca-metrics,.ts-ca-result,.ts-ca-row{grid-template-columns:1fr}}

/* ============================================================
   V24.72 — INTERNATIONAL CANCELLATION / REFUND WORKSPACE
============================================================ */
.v2472-cancel-head{height:auto!important;min-height:0!important;position:relative!important;top:auto!important;z-index:1!important;margin:0!important;padding:16px 18px!important;display:grid!important;grid-template-columns:minmax(300px,1.3fr) minmax(520px,1fr)!important;gap:18px!important;align-items:center!important;border:1px solid #dbe6f4!important;border-left:5px solid #0b74ff!important;border-radius:16px!important;background:linear-gradient(135deg,#fff 0%,#f5f9ff 100%)!important;box-shadow:0 10px 30px rgba(15,42,73,.05)!important}
.v2472-cancel-title h1{font-size:24px!important;line-height:1.12!important;margin:2px 0 4px!important;color:#10233f!important}.v2472-cancel-title p{font-size:12px!important;margin:0!important;color:#6f8096!important}.v2472-cancel-eyebrow{display:block;color:#0b74ff;font-size:10px;font-weight:900;letter-spacing:.95px;text-transform:uppercase}
.v2472-cancel-metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}.v2472-cmetric{position:relative;padding:10px 11px;border:1px solid #e2e9f2;border-radius:11px;background:#fff;min-width:0;overflow:hidden}.v2472-cmetric:before{content:"";position:absolute;left:0;top:0;bottom:0;width:3px;background:#0b74ff}.v2472-cmetric.amber:before{background:#f59e0b}.v2472-cmetric.green:before{background:#10b981}.v2472-cmetric.red:before{background:#ef4444}.v2472-cmetric span{display:block;font-size:9px;font-weight:850;text-transform:uppercase;color:#7a899c;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.v2472-cmetric strong{display:block;margin-top:3px;font-size:18px;color:#10233f;font-weight:900}
.content{padding-top:14px!important}.v2472-cancel-notice{padding:9px 12px;margin:0 0 10px;border:1px solid #bfdbfe;border-left:4px solid #2563eb;border-radius:10px;background:#eff6ff;color:#27476d;font-size:11px;line-height:1.5}.v2472-cancel-notice strong{color:#173d70}
.v2472-cancel-directory-head{margin-top:10px;display:flex;align-items:flex-end;justify-content:space-between;gap:12px;padding:10px 12px 8px}.v2472-cancel-directory-head strong{display:block;font-size:15px;color:#153453}.v2472-cancel-directory-head>span{font-size:10px;color:#7d8c9f}
.v2472-cancel-toolbar{margin-top:0!important;padding:9px 10px!important;border-radius:12px!important;box-shadow:0 6px 20px rgba(15,42,73,.035)!important}.v2472-cancel-toolbar .filters{gap:5px!important}.v2472-cancel-toolbar .filter{min-height:32px!important;padding:0 10px!important;border-radius:999px!important;font-size:11px!important}.v2472-cancel-toolbar .count{min-width:18px!important;height:18px!important;font-size:9px!important}.v2472-cancel-toolbar .search input{height:34px!important;width:250px!important;font-size:11px!important;border-radius:9px!important}.v2472-cancel-toolbar .search button{height:34px!important;min-height:34px!important;width:38px!important;border-radius:9px!important}
.list{margin-top:10px!important;gap:9px!important}.request{border-radius:12px!important;box-shadow:0 5px 18px rgba(15,42,73,.035)!important}.ts-case-summary{grid-template-columns:minmax(230px,1.8fr) minmax(130px,.85fr) repeat(3,minmax(110px,.7fr)) auto!important;gap:10px!important;padding:11px 13px!important}.ts-case-summary .ts-primary strong{font-size:12px!important}.ts-case-summary .ts-primary small{margin-top:3px!important;font-size:9px!important}.ts-case-summary .ts-cell small{font-size:8px!important;margin-bottom:3px!important}.ts-case-summary .ts-cell b{font-size:11px!important}.ts-case-pill{padding:4px 8px!important;font-size:9px!important}.ts-case-toggle{padding:8px 10px!important;border-radius:8px!important;font-size:10px!important}.ts-case-detail .request-body{padding:14px!important}.ts-case-detail .package h2{font-size:16px!important}.ts-cancel-email{margin:10px 14px 12px!important}
@media(max-width:1180px){.v2472-cancel-head{grid-template-columns:1fr!important}.v2472-cancel-metrics{grid-template-columns:repeat(4,minmax(110px,1fr))}.ts-case-summary{grid-template-columns:minmax(190px,1.5fr) repeat(3,minmax(105px,.75fr)) auto!important}.ts-case-summary .ts-customer{display:none!important}}
@media(max-width:760px){.v2472-cancel-head{padding:14px!important}.v2472-cancel-metrics{grid-template-columns:1fr 1fr}.v2472-cancel-directory-head{align-items:flex-start;flex-direction:column}.v2472-cancel-toolbar{align-items:stretch!important;flex-direction:column!important}.v2472-cancel-toolbar .search{width:100%!important}.v2472-cancel-toolbar .search input{width:auto!important;flex:1!important}.ts-case-summary{grid-template-columns:1fr 1fr!important}.ts-case-summary .ts-primary{grid-column:1/-1}.ts-case-buttons{grid-column:1/-1;justify-content:stretch!important}}
</style>
</head>
<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->






<div class="layout">

<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->



<div class="main">

<header class="topbar v2472-cancel-head">
    <div class="v2472-cancel-title">
        <span class="v2472-cancel-eyebrow">FINANCE / REFUND CONTROL</span>
        <h1>Cancellation & Refund Review</h1>
        <p>Assess customer refunds, supplier impact and cancellation communication from one finance workspace.</p>
    </div>
    <div class="v2472-cancel-metrics" aria-label="Cancellation summary">
        <div class="v2472-cmetric blue"><span>Total Cases</span><strong><?= number_format($counts['all']); ?></strong></div>
        <div class="v2472-cmetric amber"><span>Pending</span><strong><?= number_format($counts['pending']); ?></strong></div>
        <div class="v2472-cmetric green"><span>Approved</span><strong><?= number_format($counts['approved']); ?></strong></div>
        <div class="v2472-cmetric red"><span>Rejected</span><strong><?= number_format($counts['rejected']); ?></strong></div>
    </div>
</header>

<main class="content">

<?php if ($success !== ''): ?>
    <div class="alert success">
        <i class="fa-solid fa-circle-check"></i>
        <?= e($success); ?>
    </div>
<?php endif; ?>

<?php if ($error !== ''): ?>
    <div class="alert error">
        <i class="fa-solid fa-triangle-exclamation"></i>
        <?= e($error); ?>
    </div>
<?php endif; ?>

<?php if ($mailNotice !== ''): ?>
<div class="alert error"><i class="fa-solid fa-envelope-circle-check"></i> <?= e($mailNotice); ?> Open the case to review and resend.</div>
<?php endif; ?>

<div class="v2472-cancel-notice">
    <strong><i class="fa-solid fa-scale-balanced"></i> Booking cancellation → Refund review</strong><br>
    Customer cancellation requests and administrator-cancelled bookings are shown together. Cancelling a booking does not automatically issue a refund. Assess customer charge/refund and supplier impact, then record the actual refund transfer separately.
    <?php if ($legacyTotal > 0): ?><br><strong><?= (int)$legacyTotal; ?> earlier direct-cancelled booking(s) need their finance case opened.</strong><?php endif; ?>
</div>

<div class="v2472-cancel-directory-head">
    <div>
        <span class="v2472-cancel-eyebrow">REFUND CASE DIRECTORY</span>
        <strong>Cancellation Cases</strong>
    </div>
    <span>Open a case only when detailed financial assessment is required.</span>
</div>

<section class="toolbar v2472-cancel-toolbar">

    <div class="filters">
        <?php
        $labels = [
            'all' => 'All',
            'pending' => 'Pending',
            'approved' => 'Approved',
            'rejected' => 'Rejected'
        ];
        ?>

        <?php foreach ($labels as $key => $label): ?>
            <a
                href="<?= e(BASE_URL . 'admin-cancellations.php?status=' . urlencode($key)); ?>"
                class="filter <?= $statusFilter === $key ? 'active' : ''; ?>"
            >
                <?= e($label); ?>
                <span class="count"><?= number_format($counts[$key]); ?></span>
            </a>
        <?php endforeach; ?>
    </div>

    <form method="get" class="search">
        <?php if ($statusFilter !== 'all'): ?>
            <input type="hidden" name="status" value="<?= e($statusFilter); ?>">
        <?php endif; ?>

        <input
            type="text"
            name="search"
            value="<?= e($search); ?>"
            placeholder="Booking, customer, email..."
        >

        <button type="submit" aria-label="Search">
            <i class="fa-solid fa-magnifying-glass"></i>
        </button>
    </form>

</section>

<?php if (!$requests): ?>

<section class="empty">
    <i class="fa-solid fa-circle-check"></i>
    <h2>No cancellation requests found</h2>
    <p>Customer requests and administrator-cancelled bookings will appear here. Refunds require a separate commercial review.</p>
</section>

<?php else: ?>

<section class="list">

<?php foreach ($requests as $row): ?>

<?php
$cancellationId = (int)$row['cancellation_id'];
$bookingId = (int)$row['booking_id'];
$cStatus = strtolower((string)$row['cancellation_status']);
$statusClass = cancellationStatusClass($cStatus);
$totalAmount = max(0, (float)$row['total_amount']);
$paidAmount = max(0, (float)$row['paid_amount']);
$hasPayment = $paidAmount > 0 || in_array(
    strtolower((string)$row['payment_status']),
    ['paid', 'partial'],
    true
);
$supplierPaid = 0.0;
$supplierKnown = false;
if ($cancellationId > 0 && in_array($cStatus, ['pending', 'approved'], true)) {
    [$supplierPaid, $supplierKnown] = tsCancelSupplierPaid($pdo, $bookingId);
}

$cancelFinance = null;
if ($cancellationId > 0 && function_exists('tsAmendCancellationFinanceReady') && tsAmendCancellationFinanceReady($pdo)) {
    try { $cancelFinance = tsAmendCancellationFinancial($pdo,$cancellationId); }
    catch (Throwable $e) { $cancelFinance = null; }
}
$cancelRefund = null;
if ($cancelFinance && tsBillReady($pdo)) {
    try {
        tsBillSyncRefundObligations($pdo,$bookingId);
        $refundStmt=$pdo->prepare("SELECT * FROM booking_customer_refunds WHERE source_type='cancellation' AND source_id=? AND booking_id=? LIMIT 1");
        $refundStmt->execute([$cancellationId,$bookingId]);
        $cancelRefund=$refundStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) { error_log('Cancellation refund display: '.$e->getMessage()); }
}
$refundSummary = 'Review required';
$refundChip = 'review';
$refundAmount = $cancelFinance ? (float)$cancelFinance['customer_refund_amount'] : 0.0;
if ($cStatus==='rejected') { $refundSummary='Not applicable'; $refundChip='rejected'; }
elseif ($cancelRefund && $cancelRefund['status']==='paid') { $refundSummary='Refund paid'; $refundChip='paid'; }
elseif ($cancelFinance) { $refundSummary=$refundAmount > .009 ? 'Refund pending' : 'No refund due'; $refundChip=$refundAmount > .009 ? 'pending' : 'approved'; }
$mailDelivery = null;
if ($cancellationId > 0) {
    try {
        $ms=$pdo->prepare("SELECT delivery_status,sent_at,subject FROM booking_communications WHERE booking_id=? AND template_key IN (?,?,?,?,?) ORDER BY id DESC LIMIT 1");
        $ms->execute([$bookingId,'ts_cancellation_approved_'.$cancellationId,'ts_cancellation_rejected_'.$cancellationId,'ts_cancellation_assessment_'.$cancellationId,'ts_cancellation_refund_paid_'.$cancellationId,'ts_cancellation_update_'.$cancellationId]); $mailDelivery=$ms->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) { /* Optional communication module. */ }
}
$open = ($focusCase > 0 && $focusCase===$cancellationId);
?>

<article class="request" id="case-<?= $cancellationId > 0 ? $cancellationId : 'legacy-'.$bookingId; ?>">
  <div class="ts-case-summary">
      <div class="ts-primary">
          <strong><?= e($row['package_title'] ?: 'Travel Package'); ?></strong>
          <small>#<?= e((string)$row['booking_number']); ?> · <?= e($row['customer_name']); ?> · <?= !empty($row['travel_date']) ? e(date('d M Y',strtotime((string)$row['travel_date']))):'Date not set'; ?></small>
      </div>
      <div class="ts-cell ts-customer"><small>Case</small><b><?= $cancellationId ? '#'.$cancellationId : 'Historical'; ?> <span class="ts-case-pill <?= e($statusClass); ?>"><?= e(ucfirst($cStatus)); ?></span></b></div>
      <div class="ts-cell"><small>Booking total</small><b><?= e($currencySymbol); ?><?= number_format($totalAmount,2); ?></b></div>
      <div class="ts-cell"><small>Paid at cancellation</small><b><?= e($currencySymbol); ?><?= number_format($cancelFinance ? (float)$cancelFinance['customer_paid_at_cancellation'] : $paidAmount,2); ?></b></div>
      <div class="ts-cell refund"><small><?= e($refundSummary); ?></small><b><?= ($cancelFinance && $refundAmount>.009) ? e($currencySymbol).number_format($refundAmount,2) : '—'; ?></b></div>
      <div class="ts-case-buttons">
        <?php if ($cancellationId>0 && $cStatus!=='pending'): ?>
        <span class="ts-case-pill <?= $mailDelivery && ($mailDelivery['delivery_status']??'')==='sent' ? 'paid':'review'; ?>"><i class="fa-solid fa-envelope"></i> <?= $mailDelivery && ($mailDelivery['delivery_status']??'')==='sent' ? 'Email sent':'Email review'; ?></span>
        <?php endif; ?>
        <button type="button" class="ts-case-toggle" data-cancel-toggle aria-controls="case-body-<?= $cancellationId > 0 ? $cancellationId : 'legacy-'.$bookingId; ?>" aria-expanded="<?= $open ? 'true' : 'false'; ?>"><i class="fa-solid fa-chevron-down"></i> <?= $open ? 'Close details':'Open details'; ?></button></div>
  </div>
  <div class="ts-case-detail" id="case-body-<?= $cancellationId > 0 ? $cancellationId : 'legacy-'.$bookingId; ?>" <?= $open ? '' : 'hidden'; ?>>

    <div class="request-top">

        <div class="reference">
            <?= $cancellationId > 0 ? 'Cancellation #' . number_format($cancellationId) : 'Earlier direct booking cancellation — not yet linked'; ?>
            <strong><?= e($row['booking_number']); ?></strong>
            &nbsp; • &nbsp;
            Requested
            <?= !empty($row['requested_at'])
                ? e(date('d M Y, h:i A', strtotime($row['requested_at'])))
                : '-'; ?>
        </div>

        <span class="status <?= e($statusClass); ?>">
            <?= e(ucfirst($cStatus)); ?>
        </span>

    </div>

    <div class="request-body">

        <div class="package">

            <h2><?= e($row['package_title'] ?: 'Travel Package'); ?></h2>

            <div class="destination">
                <i class="fa-solid fa-location-dot"></i>
                <?= e($row['destination_name'] ?: 'Destination'); ?>
                <?php if (!empty($row['destination_country'])): ?>
                    , <?= e($row['destination_country']); ?>
                <?php endif; ?>
            </div>

            <div class="customer-grid">

                <div class="info">
                    <span>Customer</span>
                    <strong><?= e($row['customer_name']); ?></strong>
                </div>

                <div class="info">
                    <span>Travel Date</span>
                    <strong>
                        <?= !empty($row['travel_date'])
                            ? e(date('d M Y', strtotime($row['travel_date'])))
                            : 'Not Set'; ?>
                    </strong>
                </div>

                <div class="info">
                    <span>Email</span>
                    <strong><?= e($row['customer_email']); ?></strong>
                </div>

                <div class="info">
                    <span>Mobile</span>
                    <strong><?= e($row['customer_mobile']); ?></strong>
                </div>

            </div>

            <div class="reason">
                <strong>Customer cancellation reason</strong>
                <?= nl2br(e((string)$row['reason'])); ?>
            </div>

            <div class="actions">

                <a
                    href="<?= e(BASE_URL . 'admin-booking-details.php?id=' . $bookingId); ?>"
                    class="btn btn-primary"
                >
                    <i class="fa-solid fa-eye"></i>
                    Booking Details
                </a>

                <?php if ($hasPayment): ?>
                    <a
                        href="<?= e(BASE_URL . 'admin-payments.php?search=' . urlencode((string)$row['booking_number'])); ?>"
                        class="btn btn-secondary"
                    >
                        <i class="fa-solid fa-credit-card"></i>
                        Payment
                    </a>
                <?php endif; ?>

            </div>

        </div>

        <div class="payment">

            <div class="money">
                <span>Booking Total</span>
                <strong><?= e($currencySymbol); ?><?= number_format($totalAmount, 2); ?></strong>
            </div>

            <div class="money">
                <span>Paid Amount</span>
                <strong><?= e($currencySymbol); ?><?= number_format($paidAmount, 2); ?></strong>
            </div>

            <div class="money">
                <span>Payment Status</span>
                <strong><?= e(ucfirst((string)$row['payment_status'])); ?></strong>
            </div>

            <div class="money">
                <span>Booking Status</span>
                <strong><?= e(ucfirst((string)$row['booking_status'])); ?></strong>
            </div>

            <?php if ($hasPayment && $cStatus === 'pending'): ?>
                <div class="refund-warning">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                    This booking has payment recorded. Approving cancellation does not automatically issue a refund.
                </div>
            <?php endif; ?>

            <?php if ($cancellationId === 0): ?>
                <div class="refund-warning"><strong>Historical cancelled booking detected.</strong><br>The booking was cancelled using the older direct button. Open its finance case to assess payments, supplier charges and any refund. No refund has been authorised automatically.</div>
                <form method="post" class="process-form" style="margin-top:11px;">
                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()); ?>">
                    <input type="hidden" name="action" value="open_legacy_case">
                    <input type="hidden" name="booking_id" value="<?= $bookingId; ?>">
                    <input type="hidden" name="booking_number" value="<?= e((string)$row['booking_number']); ?>">
                    <button type="submit" class="btn btn-primary" onclick="return confirm('Open a finance review case for this cancelled booking?');"><i class="fa-solid fa-file-circle-plus"></i> Open Cancellation / Refund Review</button>
                </form>
            <?php elseif ($cStatus === 'pending'): ?>

                <form method="post" class="process-form">

                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()); ?>">
                    <input type="hidden" name="cancellation_id" value="<?= $cancellationId; ?>">

                    <?php if (function_exists('tsAmendCancellationFinanceReady') && tsAmendCancellationFinanceReady($pdo)): ?>
                        <?php tsCancelRenderAssessment($row, $supplierPaid, $supplierKnown, $currencySymbol); ?>
                    <?php endif; ?>

                    <textarea
                        name="admin_notes"
                        maxlength="3000"
                        placeholder="Admin note to customer (optional)..."
                    ></textarea>

                    <div class="process-buttons">

                        <button
                            type="submit"
                            name="action"
                            value="approve"
                            class="btn btn-green"
                            onclick="return confirm('Approve this cancellation and mark the booking as cancelled?');"
                        >
                            <i class="fa-solid fa-check"></i>
                            Approve
                        </button>

                        <button
                            type="submit"
                            name="action"
                            value="reject"
                            class="btn btn-red"
                            onclick="return confirm('Reject this cancellation request?');"
                        >
                            <i class="fa-solid fa-xmark"></i>
                            Reject
                        </button>

                    </div>

                </form>

            <?php else: ?>

                <div class="processed">

                    <strong>
                        <?= $cStatus === 'approved'
                            ? 'Cancellation Approved'
                            : 'Cancellation Rejected'; ?>
                    </strong>

                    <?php if (!empty($row['processed_at'])): ?>
                        <br>
                        <?= e(date('d M Y, h:i A', strtotime($row['processed_at']))); ?>
                    <?php endif; ?>

                    <?php if (!empty($row['admin_notes'])): ?>
                        <br><br>
                        <strong>Admin Note:</strong><br>
                        <?= nl2br(e((string)$row['admin_notes'])); ?>
                    <?php endif; ?>

                    <?php if ($cStatus === 'approved' && !$cancelFinance && function_exists('tsAmendCancellationFinanceReady') && tsAmendCancellationFinanceReady($pdo)): ?>
                        <div class="refund-warning"><strong>Financial review required.</strong> Booking cancellation has been recorded, but customer/supplier cancellation amounts are not yet assessed. The refund below is only a proposed amount until saved.</div>
                        <form method="post" class="process-form" style="margin-top:12px;">
                            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()); ?>">
                            <input type="hidden" name="action" value="record_financial">
                            <input type="hidden" name="cancellation_id" value="<?= $cancellationId; ?>">
                            <?php tsCancelRenderAssessment($row, $supplierPaid, $supplierKnown, $currencySymbol); ?>
                            <button type="submit" class="btn btn-primary" onclick="return confirm('Record this cancellation finance assessment? Refund will remain PENDING until separately marked as paid.');"><i class="fa-solid fa-floppy-disk"></i> Save Cancellation & Refund Assessment</button>
                        </form>
                    <?php endif; ?>

                    <?php if ($cancelFinance): ?>
                        <div style="margin-top:10px;padding:9px;border-radius:9px;background:#f8fafc;border:1px solid #e2e8f0;">
                            <strong>Commercial Impact</strong><br>
                            Customer Charge: <?= e($currencySymbol); ?><?= number_format((float)$cancelFinance['customer_cancellation_charge'],2); ?> · Customer Refund: <?= e($currencySymbol); ?><?= number_format((float)$cancelFinance['customer_refund_amount'],2); ?> (<?= e(ucfirst((string)$cancelFinance['customer_refund_status'])); ?>)<br>
                            Supplier Penalty: <?= e($currencySymbol); ?><?= number_format((float)$cancelFinance['supplier_penalty_amount'],2); ?> · Supplier Refund Expected: <?= e($currencySymbol); ?><?= number_format((float)$cancelFinance['supplier_refund_expected'],2); ?><br>
                            Customer charge less supplier penalty (indicative, excludes other booking costs): <?= e($currencySymbol); ?><?= number_format((float)$cancelFinance['net_margin_impact'],2); ?>
                        </div>
                        <?php if ($cancelRefund && $cancelRefund['status'] === 'pending'): ?>
                            <form method="post" class="process-form" style="margin-top:10px;border:1px solid #a7f3d0;background:#f0fdf4;padding:10px;border-radius:10px;">
                                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()); ?>">
                                <input type="hidden" name="action" value="mark_refund_paid">
                                <input type="hidden" name="cancellation_id" value="<?= $cancellationId; ?>">
                                <input type="hidden" name="customer_refund_id" value="<?= (int)$cancelRefund['id']; ?>">
                                <strong style="display:block;margin-bottom:8px;font-size:12px;">Customer refund PENDING: <?= e($currencySymbol); ?><?= number_format((float)$cancelRefund['amount'],2); ?></strong>
                                <label>Refund transfer method</label>
                                <select name="refund_method" required style="width:100%;min-height:36px;"><option value="bank_transfer">Bank Transfer</option><option value="upi">UPI</option><option value="cash">Cash</option><option value="other">Other</option></select>
                                <label>Actual UTR / Refund Reference</label>
                                <input name="refund_reference" required maxlength="190" placeholder="Enter verified transfer reference" style="width:100%;min-height:36px;">
                                <textarea name="refund_notes" placeholder="Optional payment note" style="width:100%;min-height:55px;margin:7px 0;"></textarea>
                                <button class="btn btn-green" type="submit" onclick="return confirm('Confirm that the refund has actually been sent? This reduces Booking net paid balance.');"><i class="fa-solid fa-money-bill-transfer"></i> Mark Customer Refund Paid</button>
                            </form>
                        <?php elseif ($cancelRefund && $cancelRefund['status'] === 'paid'): ?>
                            <div style="margin-top:9px;padding:10px;border:1px solid #86efac;border-radius:9px;background:#f0fdf4;font-size:11px;color:#166534;">Customer refund PAID: <?= e($currencySymbol); ?><?= number_format((float)$cancelRefund['amount'],2); ?> · Method: <?= e((string)$cancelRefund['payment_method']); ?> · Ref: <?= e((string)$cancelRefund['reference_number']); ?></div>
                        <?php elseif ((float)$cancelFinance['customer_refund_amount'] < .01): ?>
                            <div class="refund-warning">No customer refund was approved in this cancellation assessment.</div>
                        <?php endif; ?>
                        <?php if ((string)$cancelFinance['supplier_refund_status'] === 'pending'): ?>
                            <form method="post" class="process-form" style="margin-top:10px;">
                                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()); ?>">
                                <input type="hidden" name="action" value="supplier_refund_received">
                                <input type="hidden" name="cancellation_id" value="<?= $cancellationId; ?>">
                                <strong style="display:block;font-size:11px;">Supplier refund expected: <?= e($currencySymbol); ?><?= number_format((float)$cancelFinance['supplier_refund_expected'],2); ?></strong>
                                <input name="supplier_refund_reference" maxlength="190" required placeholder="Supplier refund credit reference" style="width:100%;min-height:35px;margin:7px 0;">
                                <button type="submit" class="btn btn-primary" onclick="return confirm('Confirm supplier refund was received?');">Mark Supplier Refund Received</button>
                            </form>
                        <?php elseif ((string)$cancelFinance['supplier_refund_status'] === 'received'): ?>
                            <div style="margin-top:8px;padding:9px;background:#eff6ff;border-radius:8px;">Supplier refund marked received. Refer to supplier finance notes.</div>
                        <?php endif; ?>
                    <?php endif; ?>

                </div>

            <?php endif; ?>

        </div>

    </div>

    <?php if ($cancellationId > 0 && in_array($cStatus,['approved','rejected'],true)): ?>
    <?php
        $emailDraft=null; $emailDraftError='';
        try { $emailDraft=tsCancelMailDraft($pdo,$cancellationId,'update'); }
        catch (Throwable $e) { $emailDraftError=$e->getMessage(); }
    ?>
    <details class="ts-cancel-email">
      <summary><span><i class="fa-solid fa-envelope"></i> Customer cancellation email · Preview &amp; send</span>
        <span><?= $mailDelivery && ($mailDelivery['delivery_status']??'')==='sent' ? 'Last sent '.e(date('d M Y, h:i A',strtotime((string)$mailDelivery['sent_at']))) : 'Not sent / resend available'; ?> <i class="fa-solid fa-chevron-down"></i></span></summary>
      <div class="email-body">
        <?php if ($emailDraft): ?>
            <div><strong>To:</strong> <?= e($emailDraft['email'] ?: 'Email missing'); ?></div>
            <div><strong>Subject:</strong> <?= e($emailDraft['subject']); ?></div>
            <pre><?= e($emailDraft['body']); ?></pre>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()); ?>">
                <input type="hidden" name="cancellation_id" value="<?= $cancellationId; ?>">
                <input type="hidden" name="action" value="send_cancellation_mail">
                <button type="submit" class="btn btn-primary" <?= filter_var($emailDraft['email'],FILTER_VALIDATE_EMAIL) ? '' : 'disabled'; ?> onclick="return confirm('Send the displayed cancellation/refund status email to this customer?');"><i class="fa-solid fa-paper-plane"></i> <?= $mailDelivery && ($mailDelivery['delivery_status']??'')==='sent' ? 'Resend status email' : 'Send status email'; ?></button>
                <a class="btn btn-secondary" href="<?= e(BASE_URL.'admin-booking-communications.php?id='.$bookingId); ?>">View communication history</a>
            </form>
        <?php else: ?>
           <p><?= e($emailDraftError); ?></p>
        <?php endif; ?>
        <p style="margin-top:9px;color:#64748b;">A cancellation notice is not proof that a refund was transferred. Refund confirmation is sent only after actual payment is recorded.</p>
      </div>
    </details>
    <?php endif; ?>
  </div>
</article>

<?php endforeach; ?>

</section>

<?php endif; ?>

</main>
</div>
</div>







<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<script>
(function(){
  const money = cents => new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',minimumFractionDigits:2,maximumFractionDigits:2}).format(cents/100);
  const cents = n => Math.max(0, Math.round((Number(n) || 0)*100));
  document.querySelectorAll('.ts-cancel-assessment').forEach(panel=>{
    const $ = selector => panel.querySelector(selector);
    const total = cents(panel.dataset.total), held = cents(panel.dataset.retained), supplierPaid = cents(panel.dataset.supplierPaid);
    const customerMode=$('[data-ca-mode]'), customerValue=$('[data-ca-value]');
    const supplierMode=$('[data-ca-supplier-mode]'),supplierValue=$('[data-ca-supplier-value]'),projection=$('[data-ca-supplier-projection]');
    function refresh(){
      const mode=customerMode.value, value=Math.max(0,Number(customerValue.value)||0);
      customerValue.max=mode==='percentage'?'100':'1000000000';
      $('[data-ca-value-help]').textContent=mode==='percentage'?'Percentage applies to the full booking total; only funds already paid can be retained.':'Enter the fixed charge in rupees, capped to customer funds actually held.';
      const policy=mode==='percentage'?Math.round(total*Math.min(100,value)/100):cents(value);
      const charge=Math.min(held,policy),refund=held-charge;
      $('[data-ca-policy]').textContent=money(policy);
      $('[data-ca-charge]').textContent=money(charge);
      $('[data-ca-refund]').textContent=money(refund);
      const warning=$('[data-ca-warning]');
      warning.hidden=policy<=held;
      warning.textContent=policy>held?'Policy charge exceeds payments held by '+money(policy-held)+'. Only '+money(held)+' can be retained in this assessment; no extra invoice is created.':'';
      const smode=supplierMode.value,sv=Math.max(0,Number(supplierValue.value)||0);
      supplierValue.max=smode==='percentage'?'100':'1000000000';
      const penalty=smode==='percentage'?Math.round(supplierPaid*Math.min(100,sv)/100):cents(sv);
      $('[data-ca-supplier-penalty]').textContent=money(penalty);
      $('[data-ca-supplier-refund]').textContent=money(projection.checked?Math.max(0,supplierPaid-penalty):0);
    }
    [customerMode,customerValue,supplierMode,supplierValue,projection].forEach(el=>el.addEventListener(el===projection?'change':'input',refresh));
    panel.closest('form')?.addEventListener('submit',event=>{
      const p=Number(customerValue.value),sp=Number(supplierValue.value);
      if(!Number.isFinite(p)||p<0||(customerMode.value==='percentage'&&p>100)||!Number.isFinite(sp)||sp<0||(supplierMode.value==='percentage'&&sp>100)){
        event.preventDefault();window.alert('Enter valid fixed amounts or a percentage between 0 and 100.');return;
      }
      if(projection.checked && (supplierMode.value==='percentage'?Math.round(supplierPaid*sp/100):cents(sp))>supplierPaid){event.preventDefault();window.alert('Supplier penalty exceeds confirmed supplier payments. Correct it or turn off supplier refund projection.');}
    });
    refresh();
  });
})();
</script>
<script>
document.querySelectorAll('[data-cancel-toggle]').forEach(function(btn){
    btn.addEventListener('click',function(){
        const detail=document.getElementById(btn.getAttribute('aria-controls'));
        if (!detail) return;
        const opening=detail.hidden;
        // Keep the list short: expand a single case at a time.
        document.querySelectorAll('.ts-case-detail').forEach(function(el){
            if(el!==detail) el.hidden=true;
        });
        document.querySelectorAll('[data-cancel-toggle]').forEach(function(other){
            if(other!==btn){other.setAttribute('aria-expanded','false');other.innerHTML='<i class="fa-solid fa-chevron-down"></i> Open details';}
        });
        detail.hidden=!opening;
        btn.setAttribute('aria-expanded',opening?'true':'false');
        btn.innerHTML=opening?'<i class="fa-solid fa-chevron-up"></i> Close details':'<i class="fa-solid fa-chevron-down"></i> Open details';
    });
});
</script>
<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
