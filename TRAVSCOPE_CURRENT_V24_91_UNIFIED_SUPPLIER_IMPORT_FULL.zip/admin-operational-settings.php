<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/system-settings-functions.php';

requireAdmin();

$admin = currentAdmin($pdo);

if (
    !$admin
    || strtolower((string)($admin['status'] ?? '')) !== 'active'
) {
    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_role']
    );

    redirect(BASE_URL . 'admin-login.php');
}

$adminId = (int)$admin['id'];

$canManage =
    function_exists('tsAclCan')
        ? tsAclCan(
            $pdo,
            $adminId,
            'manage_access'
        )
        : true;

if (!$canManage) {
    http_response_code(403);
    exit(
        'Operational Master Settings require Manage Permissions authority.'
    );
}

if (empty($_SESSION['admin_operational_settings_csrf'])) {
    $_SESSION['admin_operational_settings_csrf'] =
        bin2hex(random_bytes(32));
}

$csrf =
    (string)$_SESSION['admin_operational_settings_csrf'];

$success = '';
$error = '';

if (!empty($_SESSION['admin_operational_settings_success'])) {
    $success =
        (string)$_SESSION['admin_operational_settings_success'];

    unset(
        $_SESSION['admin_operational_settings_success']
    );
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedToken =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    if (
        $postedToken === ''
        || !hash_equals(
            $csrf,
            $postedToken
        )
    ) {
        $error =
            'Security verification failed. Refresh and try again.';

    } else {
        try {
            $changed =
                tsSystemSaveSettings(
                    $pdo,
                    $_POST,
                    $adminId
                );

            $_SESSION['admin_operational_settings_success'] =
                $changed
                    ? (
                        count($changed)
                        . ' operational setting'
                        . (
                            count($changed) === 1
                                ? ''
                                : 's'
                        )
                        . ' updated.'
                    )
                    : 'No operational setting values changed.';

            redirect(
                BASE_URL
                . 'admin-operational-settings.php'
            );

        } catch (RuntimeException $e) {
            $error = $e->getMessage();

        } catch (Throwable $e) {
            error_log(
                'Operational Master Settings: '
                . $e->getMessage()
            );

            $error =
                'Unable to save operational settings: '
                . $e->getMessage();
        }
    }
}

$catalog =
    tsSystemSettingsCatalog();

$values = [];

foreach ($catalog as $group) {
    foreach ((array)$group['fields'] as $key => $field) {
        $values[$key] =
            tsSystemSettingRaw(
                $pdo,
                $key
            );
    }
}

function osE(?string $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Operational Master Settings | TRAVSCOPE Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:68px;padding:10px 4%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;border-bottom:1px solid #dfe7f0;position:sticky;top:0;z-index:20}.brand{font-weight:900}.brand span{color:#2563eb}.actions{display:flex;gap:7px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 10px;border:1px solid #cbd5e1;border-radius:9px;background:#fff;color:#334155;text-decoration:none;font-size:9px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.wrap{max-width:1250px;margin:20px auto;padding:0 13px}.hero{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;padding:17px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:20px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px;line-height:1.55}.tag{display:inline-flex;padding:5px 8px;border-radius:999px;background:#e0f2fe;color:#0369a1;font-size:7.5px;font-weight:900}.notice{margin-top:10px;padding:10px 12px;border-radius:10px;font-size:10px;line-height:1.5}.notice.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#047857}.notice.err{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c}.notice.warn{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412}.layout{display:grid;grid-template-columns:230px minmax(0,1fr);gap:11px;margin-top:11px}.nav{position:sticky;top:79px;align-self:start;padding:9px;border:1px solid #dfe7f0;border-radius:12px;background:#fff}.nav a{display:flex;align-items:center;gap:7px;padding:8px;border-radius:8px;text-decoration:none;color:#64748b;font-size:8.5px;font-weight:900}.nav a:hover{background:#eff6ff;color:#1d4ed8}.content{display:grid;gap:10px}.card{background:#fff;border:1px solid #dfe7f0;border-radius:13px;overflow:hidden;scroll-margin-top:85px}.head{padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff;display:flex;gap:9px;align-items:flex-start}.head i{width:34px;height:34px;border-radius:9px;display:grid;place-items:center;background:#eff6ff;color:#2563eb}.head h2{margin:0;font-size:12px}.head p{margin:4px 0 0;color:#64748b;font-size:8.5px;line-height:1.45}.body{padding:11px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.field{padding:9px;border:1px solid #e2e8f0;border-radius:10px;background:#fff}.field label{display:block;font-size:8px;font-weight:900;color:#475569;text-transform:uppercase;letter-spacing:.35px}.field small{display:block;margin-top:5px;color:#94a3b8;font-size:7.5px;line-height:1.4}.field .used{display:inline-flex;margin-top:5px;padding:3px 6px;border-radius:999px;background:#f1f5f9;color:#64748b;font-size:7px;font-weight:900}.control{width:100%;margin-top:6px;min-height:36px;padding:7px 8px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;color:#172033;font-size:9px}.toggle{margin-top:8px;display:flex;align-items:center;gap:7px;font-size:9px}.toggle input{width:17px;height:17px}.footer{position:sticky;bottom:0;margin-top:11px;padding:10px;border:1px solid #bfdbfe;border-radius:11px;background:rgba(239,246,255,.96);display:flex;justify-content:space-between;gap:10px;align-items:center}.footer span{font-size:8.5px;color:#1e40af;line-height:1.45}
@media(max-width:850px){.layout{grid-template-columns:1fr}.nav{position:static;display:flex;overflow:auto}.nav a{flex:0 0 auto}.grid{grid-template-columns:1fr}.top,.hero,.footer{flex-direction:column;align-items:flex-start}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head>
<body>

<header class="top">
    <div class="brand">
        TRAV<span>SCOPE</span> · OPERATIONAL SETTINGS
    </div>

    <div class="actions">
        <a class="btn" href="<?= osE(BASE_URL . 'admin-dashboard.php'); ?>">
            <i class="fa-solid fa-gauge-high"></i>
            Dashboard
        </a>

        <a class="btn" href="<?= osE(BASE_URL . 'admin-settings.php'); ?>">
            <i class="fa-solid fa-gear"></i>
            Website Settings
        </a>

        <a class="btn" href="<?= osE(BASE_URL . 'admin-system-health.php'); ?>">
            <i class="fa-solid fa-heart-pulse"></i>
            Health
        </a>
    </div>
</header>

<main class="wrap">

<section class="hero">
    <div>
        <h1>System Configuration + Master Settings Center</h1>
        <p>
            One typed control center for commercial defaults, customer automation,
            supplier response SLA, departure risk, traveller document thresholds and
            Repeat Sales timing. It reuses the existing website <strong>settings</strong>
            table and does not create a competing configuration store.
        </p>
    </div>

    <span class="tag">
        MANAGE PERMISSIONS
    </span>
</section>

<?php if ($success): ?>
    <div class="notice ok"><?= osE($success); ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="notice err"><?= osE($error); ?></div>
<?php endif; ?>

<?php if (!tsSystemSettingsTableReady($pdo)): ?>
    <div class="notice err">
        Existing website settings table is unavailable. No operational settings can be saved.
    </div>
<?php endif; ?>

<div class="notice warn">
    <strong>History protection:</strong>
    these are defaults and future automation thresholds. Existing quotation versions,
    accepted Booking snapshots, sent communication records, supplier invoices and closed
    profitability are never recalculated when a setting changes.
</div>

<form method="post">
<input type="hidden" name="csrf_token" value="<?= osE($csrf); ?>">

<div class="layout">

<nav class="nav">
    <?php foreach ($catalog as $groupKey => $group): ?>
        <a href="#<?= osE($groupKey); ?>">
            <i class="<?= osE((string)$group['icon']); ?>"></i>
            <?= osE((string)$group['title']); ?>
        </a>
    <?php endforeach; ?>
</nav>

<div class="content">
    <?php foreach ($catalog as $groupKey => $group): ?>
        <section class="card" id="<?= osE($groupKey); ?>">
            <div class="head">
                <i class="<?= osE((string)$group['icon']); ?>"></i>
                <div>
                    <h2><?= osE((string)$group['title']); ?></h2>
                    <p><?= osE((string)$group['description']); ?></p>
                </div>
            </div>

            <div class="body">
                <div class="grid">
                    <?php foreach ((array)$group['fields'] as $key => $field): ?>
                        <div class="field">
                            <label for="<?= osE($key); ?>">
                                <?= osE((string)$field['label']); ?>
                            </label>

                            <?php if ((string)$field['type'] === 'select'): ?>
                                <select
                                    class="control"
                                    id="<?= osE($key); ?>"
                                    name="<?= osE($key); ?>"
                                >
                                    <?php foreach ((array)$field['options'] as $optionValue => $optionLabel): ?>
                                        <option
                                            value="<?= osE((string)$optionValue); ?>"
                                            <?= (string)$values[$key] === (string)$optionValue ? 'selected' : ''; ?>
                                        >
                                            <?= osE((string)$optionLabel); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>

                            <?php elseif ((string)$field['type'] === 'toggle'): ?>
                                <label class="toggle">
                                    <input
                                        id="<?= osE($key); ?>"
                                        type="checkbox"
                                        name="<?= osE($key); ?>"
                                        value="1"
                                        <?= tsSystemSettingBool($pdo, $key) ? 'checked' : ''; ?>
                                    >
                                    Enabled
                                </label>

                            <?php else: ?>
                                <input
                                    class="control"
                                    id="<?= osE($key); ?>"
                                    name="<?= osE($key); ?>"
                                    type="number"
                                    value="<?= osE((string)$values[$key]); ?>"
                                    min="<?= osE((string)($field['min'] ?? '')); ?>"
                                    max="<?= osE((string)($field['max'] ?? '')); ?>"
                                    step="<?= osE((string)($field['step'] ?? '1')); ?>"
                                    required
                                >
                            <?php endif; ?>

                            <?php if (!empty($field['help'])): ?>
                                <small><?= osE((string)$field['help']); ?></small>
                            <?php endif; ?>

                            <?php if (!empty($field['used_by'])): ?>
                                <span class="used">
                                    LIVE · <?= osE((string)$field['used_by']); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endforeach; ?>
</div>

</div>

<div class="footer">
    <span>
        Saving changes affects new/default operational decisions only.
        Protected Action Audit records authorized settings changes when ACL is installed.
    </span>

    <button
        class="btn primary"
        type="submit"
        <?= !tsSystemSettingsTableReady($pdo) ? 'disabled' : ''; ?>
    >
        <i class="fa-solid fa-floppy-disk"></i>
        Save Operational Settings
    </button>
</div>

</form>

</main>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
