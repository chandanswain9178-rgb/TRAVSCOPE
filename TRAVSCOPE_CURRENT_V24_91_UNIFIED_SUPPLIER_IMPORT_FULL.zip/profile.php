<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| CUSTOMER PROFILE
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';

requireLogin();

$user = currentUser($pdo);

if (!$user) {
    unset($_SESSION['user_id']);
    redirect(BASE_URL . 'login.php');
}

$userId = (int)$user['id'];


/*
|--------------------------------------------------------------------------
| SETTINGS
|--------------------------------------------------------------------------
*/

$siteName = 'TRAVSCOPE.COM';

try {
    $siteName = getSetting(
        $pdo,
        'site_name',
        'TRAVSCOPE.COM'
    );
} catch (Throwable $e) {
    error_log('Profile settings error: ' . $e->getMessage());
}


/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['profile_csrf'])) {
    $_SESSION['profile_csrf'] = bin2hex(
        random_bytes(32)
    );
}

$csrfToken = $_SESSION['profile_csrf'];


/*
|--------------------------------------------------------------------------
| FLASH MESSAGES
|--------------------------------------------------------------------------
*/

$success = '';
$error = '';

if (!empty($_SESSION['profile_success'])) {
    $success = (string)$_SESSION['profile_success'];
    unset($_SESSION['profile_success']);
}


/*
|--------------------------------------------------------------------------
| PROFILE IMAGE URL
|--------------------------------------------------------------------------
*/

function profileImageUrl($image)
{
    $image = trim((string)$image);

    if ($image === '') {
        return '';
    }

    if (preg_match('#^https?://#i', $image)) {
        return $image;
    }

    return BASE_URL . ltrim($image, '/');
}



function ensureTravelProfileTables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_family_members (
        id INT AUTO_INCREMENT PRIMARY KEY,
        owner_user_id INT NOT NULL,
        member_code VARCHAR(40) NOT NULL UNIQUE,
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NULL,
        relationship VARCHAR(50) NOT NULL,
        date_of_birth DATE NULL,
        mobile VARCHAR(30) NULL,
        email VARCHAR(190) NULL,
        relationship_notes VARCHAR(500) NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_family_owner_user (owner_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS user_family_links (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        linked_user_id INT NOT NULL,
        relationship VARCHAR(50) NOT NULL,
        relationship_notes VARCHAR(500) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_family_link (user_id, linked_user_id),
        INDEX idx_family_link_user (user_id),
        INDEX idx_family_linked_user (linked_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS user_travel_profiles (
        user_id INT PRIMARY KEY,
        preferred_language VARCHAR(50) NULL,
        city_state VARCHAR(150) NULL,
        lead_source VARCHAR(100) NULL,
        date_of_birth DATE NULL,
        anniversary_date DATE NULL,
        spouse_partner_name VARCHAR(150) NULL,
        occupation VARCHAR(150) NULL,
        preferred_destination_type VARCHAR(255) NULL,
        travel_style VARCHAR(255) NULL,
        preferred_hotel_category VARCHAR(100) NULL,
        relationship_notes TEXT NULL,
        birthday_wishes TINYINT(1) NOT NULL DEFAULT 1,
        anniversary_wishes TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS user_travel_documents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        document_category VARCHAR(30) NOT NULL,
        document_type VARCHAR(80) NOT NULL,
        document_number VARCHAR(150) NULL,
        issuing_country VARCHAR(100) NULL,
        issue_date DATE NULL,
        expiry_date DATE NULL,
        file_path VARCHAR(500) NOT NULL,
        original_name VARCHAR(255) NOT NULL,
        mime_type VARCHAR(100) NULL,
        file_size INT NOT NULL DEFAULT 0,
        notes VARCHAR(1000) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_travel_documents_user (user_id),
        INDEX idx_travel_documents_type (document_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function familyNormalizeMobile(string $mobile): string {
    $digits = preg_replace('/[^0-9]/', '', $mobile);
    return is_string($digits) ? (strlen($digits) >= 10 ? substr($digits, -10) : $digits) : '';
}

function familyReverseRelationship(string $relationship): string {
    return match ($relationship) {
        'Child' => 'Parent',
        'Parent' => 'Child',
        'Grandparent' => 'Grandchild',
        'Grandchild' => 'Grandparent',
        default => $relationship
    };
}

function familyFindCustomer(PDO $pdo, int $ownerUserId, string $email, string $mobile): ?array {
    $email = strtolower(trim($email));
    $mobileLast10 = familyNormalizeMobile($mobile);
    $parts = [];
    $params = [$ownerUserId];

    if ($email !== '') {
        $parts[] = "LOWER(TRIM(email)) = ?";
        $params[] = $email;
    }
    if ($mobileLast10 !== '') {
        $parts[] = "RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(TRIM(COALESCE(mobile,'')),' ',''),'-',''),'(',''),')',''),'+',''),10) = ?";
        $params[] = $mobileLast10;
    }
    if (!$parts) return null;

    $stmt = $pdo->prepare(
        "SELECT id, full_name, email, mobile, country, status
         FROM users
         WHERE id <> ? AND (" . implode(" OR ", $parts) . ")
         ORDER BY id ASC LIMIT 1"
    );
    $stmt->execute($params);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function familyLinkExists(PDO $pdo, int $userA, int $userB): bool {
    $stmt = $pdo->prepare(
        "SELECT id FROM user_family_links
         WHERE (user_id=? AND linked_user_id=?)
            OR (user_id=? AND linked_user_id=?)
         LIMIT 1"
    );
    $stmt->execute([$userA,$userB,$userB,$userA]);
    return (bool)$stmt->fetchColumn();
}

function familyCreateCustomer(PDO $pdo, int $ownerUserId, string $first, string $last, string $email, string $mobile, string $country): int {
    $name = trim($first . ' ' . $last);
    $email = strtolower(trim($email));
    if ($email === '') {
        $email = 'family.' . $ownerUserId . '.' . bin2hex(random_bytes(8)) . '@travscope.local';
    }

    $hash = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);
    if ($hash === false) throw new RuntimeException('Unable to create family customer account.');

    $stmt = $pdo->prepare(
        "INSERT INTO users(full_name,email,mobile,password,profile_image,country,email_verified,status)
         VALUES(?,?,?,?,NULL,?,0,'active')"
    );
    $stmt->execute([
        $name !== '' ? $name : 'Family Traveller',
        $email,
        trim($mobile) !== '' ? trim($mobile) : null,
        $hash,
        trim($country) !== '' ? trim($country) : 'India'
    ]);

    $id = (int)$pdo->lastInsertId();
    if ($id <= 0) throw new RuntimeException('Unable to create family customer account.');
    return $id;
}

function travelDocumentTypes(): array {
    return [
        'identity' => [
            'Aadhaar Card',
            'PAN Card',
            'Voter ID',
            'Driving Licence',
            'National ID',
            'Birth Certificate'
        ],
        'travel' => [
            'Passport',
            'Visa',
            'Travel Insurance',
            'Flight Ticket',
            'Hotel Voucher',
            'Vaccination Certificate',
            'Other Travel Document'
        ]
    ];
}

function travelDocumentCategoryForType(string $type): ?string {
    foreach (travelDocumentTypes() as $category => $types) {
        if (in_array($type, $types, true)) {
            return $category;
        }
    }
    return null;
}

function saveTravellerDocumentUpload(array $file, int $userId): array {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        throw new RuntimeException('Please choose a document file to upload.');
    }
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Document upload failed.');
    }
    if ((int)($file['size'] ?? 0) <= 0 || (int)$file['size'] > 8 * 1024 * 1024) {
        throw new RuntimeException('Document file must be 8 MB or smaller.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string)$finfo->file($file['tmp_name']);
    $allowed = [
        'application/pdf' => 'pdf',
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp'
    ];
    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Only PDF, JPG, PNG and WEBP document files are allowed.');
    }

    $uploadDirectory = __DIR__ . '/uploads/traveller-documents/user_' . $userId . '/';
    if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true)) {
        throw new RuntimeException('Unable to create the traveller document upload folder.');
    }

    $extension = $allowed[$mime];
    $fileName = 'doc_' . $userId . '_' . bin2hex(random_bytes(12)) . '.' . $extension;
    $destination = $uploadDirectory . $fileName;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        throw new RuntimeException('Unable to save the uploaded document.');
    }

    return [
        'path' => 'uploads/traveller-documents/user_' . $userId . '/' . $fileName,
        'original_name' => mb_substr((string)($file['name'] ?? 'document.' . $extension), 0, 255),
        'mime_type' => $mime,
        'file_size' => (int)$file['size']
    ];
}

function deleteTravellerDocumentFile(string $relativePath, int $userId): void {
    $relativePath = ltrim(trim($relativePath), '/');
    if ($relativePath === '') return;

    $allowedPrefix = 'uploads/traveller-documents/user_' . $userId . '/';
    if (!str_starts_with($relativePath, $allowedPrefix)) return;

    $fullPath = __DIR__ . '/' . $relativePath;
    if (is_file($fullPath)) {
        @unlink($fullPath);
    }
}

function profileDateOrNull(string $v): ?string {
    $v=trim($v); if($v==='') return null;
    $d=DateTime::createFromFormat('Y-m-d',$v);
    return ($d && $d->format('Y-m-d')===$v)?$v:null;
}
function newFamilyCode(int $uid): string {
    return 'TRV-FAM-'.$uid.'-'.strtoupper(substr(bin2hex(random_bytes(5)),0,8));
}
try { ensureTravelProfileTables($pdo); } catch(Throwable $e) { error_log('Travel profile schema: '.$e->getMessage()); }

/*
|--------------------------------------------------------------------------
| HANDLE FORM
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
    |--------------------------------------------------------------------------
    | CSRF CHECK
    |--------------------------------------------------------------------------
    */

    $postedToken = (string)(
        $_POST['csrf_token'] ?? ''
    );

    if (
        $postedToken === ''
        ||
        !hash_equals(
            $_SESSION['profile_csrf'] ?? '',
            $postedToken
        )
    ) {
        $error = 'Security verification failed. Please refresh the page and try again.';
    }


    /*
    |--------------------------------------------------------------------------
    | UPDATE BASIC PROFILE
    |--------------------------------------------------------------------------
    */

    elseif (
        isset($_POST['action'])
        &&
        $_POST['action'] === 'update_profile'
    ) {

        $fullName = trim(
            (string)($_POST['full_name'] ?? '')
        );

        $mobile = trim(
            (string)($_POST['mobile'] ?? '')
        );

        $country = trim(
            (string)($_POST['country'] ?? '')
        );


        /*
        | NAME VALIDATION
        */

        if (
            mb_strlen($fullName) < 2
            ||
            mb_strlen($fullName) > 150
        ) {
            $error = 'Please enter a valid full name.';
        }


        /*
        | MOBILE VALIDATION
        */

        elseif (
            $mobile !== ''
            &&
            !preg_match('/^[0-9+\-\s()]{7,20}$/', $mobile)
        ) {
            $error = 'Please enter a valid mobile number.';
        }


        elseif (
            mb_strlen($country) > 100
        ) {
            $error = 'Country name is too long.';
        }


        else {

            try {

                /*
                |--------------------------------------------------------------------------
                | UNIQUE MOBILE CHECK
                |--------------------------------------------------------------------------
                */

                if ($mobile !== '') {

                    $stmt = $pdo->prepare("
                        SELECT id
                        FROM users
                        WHERE mobile = ?
                        AND id != ?
                        LIMIT 1
                    ");

                    $stmt->execute([
                        $mobile,
                        $userId
                    ]);

                    if ($stmt->fetch()) {
                        throw new RuntimeException(
                            'This mobile number is already registered with another account.'
                        );
                    }
                }


                /*
                |--------------------------------------------------------------------------
                | CURRENT IMAGE
                |--------------------------------------------------------------------------
                */

                $profileImage = $user['profile_image'] ?? null;


                /*
                |--------------------------------------------------------------------------
                | REMOVE PROFILE PHOTO
                |--------------------------------------------------------------------------
                */

                if (
                    !empty($_POST['remove_photo'])
                    &&
                    $profileImage
                ) {

                    $oldPath =
                        __DIR__
                        . '/'
                        . ltrim(
                            (string)$profileImage,
                            '/'
                        );

                    /*
                    | Only delete files from our profile upload folder.
                    */

                    $profileDirectory =
                        realpath(
                            __DIR__ . '/uploads/profiles'
                        );

                    $oldRealPath =
                        is_file($oldPath)
                            ? realpath($oldPath)
                            : false;

                    if (
                        $profileDirectory
                        &&
                        $oldRealPath
                        &&
                        str_starts_with(
                            $oldRealPath,
                            $profileDirectory
                        )
                    ) {
                        @unlink($oldRealPath);
                    }

                    $profileImage = null;
                }


                /*
                |--------------------------------------------------------------------------
                | PROFILE IMAGE UPLOAD
                |--------------------------------------------------------------------------
                */

                if (
                    isset($_FILES['profile_image'])
                    &&
                    $_FILES['profile_image']['error']
                        !== UPLOAD_ERR_NO_FILE
                ) {

                    $file = $_FILES['profile_image'];

                    if (
                        $file['error']
                        !== UPLOAD_ERR_OK
                    ) {
                        throw new RuntimeException(
                            'Profile image upload failed.'
                        );
                    }


                    /*
                    | 5 MB maximum
                    */

                    if (
                        (int)$file['size']
                        > 5 * 1024 * 1024
                    ) {
                        throw new RuntimeException(
                            'Profile image must be smaller than 5 MB.'
                        );
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | VERIFY REAL MIME TYPE
                    |--------------------------------------------------------------------------
                    */

                    $finfo = new finfo(
                        FILEINFO_MIME_TYPE
                    );

                    $mime = $finfo->file(
                        $file['tmp_name']
                    );

                    $allowed = [
                        'image/jpeg' => 'jpg',
                        'image/png'  => 'png',
                        'image/webp' => 'webp'
                    ];

                    if (
                        !isset($allowed[$mime])
                    ) {
                        throw new RuntimeException(
                            'Only JPG, PNG and WEBP profile images are allowed.'
                        );
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | VERIFY IMAGE CONTENT
                    |--------------------------------------------------------------------------
                    */

                    if (
                        @getimagesize(
                            $file['tmp_name']
                        ) === false
                    ) {
                        throw new RuntimeException(
                            'The uploaded file is not a valid image.'
                        );
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | CREATE DIRECTORY
                    |--------------------------------------------------------------------------
                    */

                    $uploadDirectory =
                        __DIR__
                        . '/uploads/profiles/';

                    if (
                        !is_dir($uploadDirectory)
                    ) {

                        if (
                            !mkdir(
                                $uploadDirectory,
                                0755,
                                true
                            )
                        ) {
                            throw new RuntimeException(
                                'Unable to create profile upload directory.'
                            );
                        }
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | RANDOM SAFE FILE NAME
                    |--------------------------------------------------------------------------
                    */

                    $extension =
                        $allowed[$mime];

                    $fileName =
                        'profile_'
                        . $userId
                        . '_'
                        . bin2hex(
                            random_bytes(12)
                        )
                        . '.'
                        . $extension;

                    $destination =
                        $uploadDirectory
                        . $fileName;


                    if (
                        !move_uploaded_file(
                            $file['tmp_name'],
                            $destination
                        )
                    ) {
                        throw new RuntimeException(
                            'Unable to save profile image.'
                        );
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | DELETE PREVIOUS IMAGE
                    |--------------------------------------------------------------------------
                    */

                    if (
                        !empty($profileImage)
                    ) {

                        $oldPath =
                            __DIR__
                            . '/'
                            . ltrim(
                                (string)$profileImage,
                                '/'
                            );

                        if (
                            is_file($oldPath)
                        ) {
                            @unlink($oldPath);
                        }
                    }


                    $profileImage =
                        'uploads/profiles/'
                        . $fileName;
                }


                /*
                |--------------------------------------------------------------------------
                | UPDATE DATABASE
                |--------------------------------------------------------------------------
                */

                $stmt = $pdo->prepare("
                    UPDATE users
                    SET
                        full_name = ?,
                        mobile = ?,
                        country = ?,
                        profile_image = ?
                    WHERE id = ?
                    LIMIT 1
                ");

                $stmt->execute([
                    $fullName,
                    $mobile !== '' ? $mobile : null,
                    $country !== '' ? $country : null,
                    $profileImage,
                    $userId
                ]);


                $_SESSION['profile_success'] =
                    'Your profile has been updated successfully.';

                redirect(
                    BASE_URL . 'profile.php'
                );


            } catch (RuntimeException $e) {

                $error = $e->getMessage();

            } catch (Throwable $e) {

                error_log(
                    'Profile update error: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to update your profile right now. Please try again.';
            }
        }
    }




    elseif (isset($_POST['action']) && $_POST['action'] === 'add_travel_document') {
        try {
            $documentType = trim((string)($_POST['document_type'] ?? ''));
            $documentCategory = travelDocumentCategoryForType($documentType);
            if ($documentCategory === null) {
                throw new RuntimeException('Please select a valid identity or traveller document type.');
            }

            $documentNumber = trim((string)($_POST['document_number'] ?? ''));
            $issuingCountry = trim((string)($_POST['issuing_country'] ?? ''));
            $issueRaw = trim((string)($_POST['document_issue_date'] ?? ''));
            $expiryRaw = trim((string)($_POST['document_expiry_date'] ?? ''));
            $notes = trim((string)($_POST['document_notes'] ?? ''));

            $issueDate = profileDateOrNull($issueRaw);
            $expiryDate = profileDateOrNull($expiryRaw);

            if ($issueRaw !== '' && $issueDate === null) {
                throw new RuntimeException('Please enter a valid document issue date.');
            }
            if ($expiryRaw !== '' && $expiryDate === null) {
                throw new RuntimeException('Please enter a valid document expiry date.');
            }
            if ($issueDate && $expiryDate && $expiryDate < $issueDate) {
                throw new RuntimeException('Document expiry date cannot be before the issue date.');
            }
            if (mb_strlen($documentNumber) > 150 || mb_strlen($issuingCountry) > 100 || mb_strlen($notes) > 1000) {
                throw new RuntimeException('One or more document details are too long.');
            }

            $upload = saveTravellerDocumentUpload($_FILES['document_file'] ?? [], $userId);

            $stmt = $pdo->prepare("
                INSERT INTO user_travel_documents
                (user_id, document_category, document_type, document_number,
                 issuing_country, issue_date, expiry_date, file_path,
                 original_name, mime_type, file_size, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $userId,
                $documentCategory,
                $documentType,
                $documentNumber !== '' ? $documentNumber : null,
                $issuingCountry !== '' ? $issuingCountry : null,
                $issueDate,
                $expiryDate,
                $upload['path'],
                $upload['original_name'],
                $upload['mime_type'],
                $upload['file_size'],
                $notes !== '' ? $notes : null
            ]);

            $_SESSION['profile_success'] = $documentType . ' uploaded successfully.';
            redirect(BASE_URL . 'profile.php#documents');

        } catch (RuntimeException $e) {
            $error = $e->getMessage();
        } catch (Throwable $e) {
            error_log('Traveller document upload error: ' . $e->getMessage());
            $error = 'Unable to upload the traveller document right now.';
        }
    }

    elseif (isset($_POST['action']) && $_POST['action'] === 'delete_travel_document') {
        try {
            $documentId = (int)($_POST['document_id'] ?? 0);
            if ($documentId <= 0) {
                throw new RuntimeException('Invalid document.');
            }

            $stmt = $pdo->prepare("
                SELECT id, file_path, document_type
                FROM user_travel_documents
                WHERE id = ? AND user_id = ?
                LIMIT 1
            ");
            $stmt->execute([$documentId, $userId]);
            $document = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$document) {
                throw new RuntimeException('Document was not found.');
            }

            $pdo->prepare("DELETE FROM user_travel_documents WHERE id = ? AND user_id = ? LIMIT 1")
                ->execute([$documentId, $userId]);

            deleteTravellerDocumentFile((string)$document['file_path'], $userId);

            $_SESSION['profile_success'] = $document['document_type'] . ' deleted successfully.';
            redirect(BASE_URL . 'profile.php#documents');

        } catch (RuntimeException $e) {
            $error = $e->getMessage();
        } catch (Throwable $e) {
            error_log('Traveller document delete error: ' . $e->getMessage());
            $error = 'Unable to delete the traveller document right now.';
        }
    }

    elseif (isset($_POST['action']) && $_POST['action']==='update_travel_profile') {
        try {
            $f=[
                'preferred_language'=>trim((string)($_POST['preferred_language']??'')),
                'city_state'=>trim((string)($_POST['city_state']??'')),
                'lead_source'=>trim((string)($_POST['lead_source']??'')),
                'spouse_partner_name'=>trim((string)($_POST['spouse_partner_name']??'')),
                'occupation'=>trim((string)($_POST['occupation']??'')),
                'preferred_destination_type'=>trim((string)($_POST['preferred_destination_type']??'')),
                'travel_style'=>trim((string)($_POST['travel_style']??'')),
                'preferred_hotel_category'=>trim((string)($_POST['preferred_hotel_category']??'')),
                'relationship_notes'=>trim((string)($_POST['relationship_notes']??''))
            ];
            $dobRaw=trim((string)($_POST['date_of_birth']??'')); $annRaw=trim((string)($_POST['anniversary_date']??''));
            $dob=profileDateOrNull($dobRaw); $ann=profileDateOrNull($annRaw);
            if($dobRaw!=='' && $dob===null) throw new RuntimeException('Please enter a valid date of birth.');
            if($annRaw!=='' && $ann===null) throw new RuntimeException('Please enter a valid anniversary date.');
            $stmt=$pdo->prepare("INSERT INTO user_travel_profiles
                (user_id,preferred_language,city_state,lead_source,date_of_birth,anniversary_date,spouse_partner_name,occupation,
                 preferred_destination_type,travel_style,preferred_hotel_category,relationship_notes,birthday_wishes,anniversary_wishes)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON DUPLICATE KEY UPDATE preferred_language=VALUES(preferred_language),city_state=VALUES(city_state),lead_source=VALUES(lead_source),
                date_of_birth=VALUES(date_of_birth),anniversary_date=VALUES(anniversary_date),spouse_partner_name=VALUES(spouse_partner_name),
                occupation=VALUES(occupation),preferred_destination_type=VALUES(preferred_destination_type),travel_style=VALUES(travel_style),
                preferred_hotel_category=VALUES(preferred_hotel_category),relationship_notes=VALUES(relationship_notes),
                birthday_wishes=VALUES(birthday_wishes),anniversary_wishes=VALUES(anniversary_wishes)");
            $stmt->execute([$userId,$f['preferred_language']?:null,$f['city_state']?:null,$f['lead_source']?:null,$dob,$ann,
                $f['spouse_partner_name']?:null,$f['occupation']?:null,$f['preferred_destination_type']?:null,$f['travel_style']?:null,
                $f['preferred_hotel_category']?:null,$f['relationship_notes']?:null,!empty($_POST['birthday_wishes'])?1:0,!empty($_POST['anniversary_wishes'])?1:0]);
            $_SESSION['profile_success']='Your travel profile has been updated successfully.';
            redirect(BASE_URL.'profile.php#travel-profile');
        } catch(RuntimeException $e){$error=$e->getMessage();} catch(Throwable $e){error_log('Travel profile: '.$e->getMessage());$error='Unable to update travel profile.';}
    }

    elseif (isset($_POST['action']) && $_POST['action']==='add_family_member') {
        try {
            $first=trim((string)($_POST['family_first_name']??''));
            $last=trim((string)($_POST['family_last_name']??''));
            $rel=trim((string)($_POST['family_relationship']??''));
            $dobRaw=trim((string)($_POST['family_date_of_birth']??''));
            $mob=trim((string)($_POST['family_mobile']??''));
            $mail=strtolower(trim((string)($_POST['family_email']??'')));
            $notes=trim((string)($_POST['family_notes']??''));
            $allowed=['Spouse','Partner','Child','Parent','Sibling','Grandparent','Grandchild','Relative','Friend','Other'];

            if($first==='' || !in_array($rel,$allowed,true))
                throw new RuntimeException('First name and valid relationship are required.');

            $dob=profileDateOrNull($dobRaw);
            if($dobRaw!=='' && $dob===null)
                throw new RuntimeException('Please enter a valid date of birth.');

            if($mail!=='' && !filter_var($mail,FILTER_VALIDATE_EMAIL))
                throw new RuntimeException('Please enter a valid email address or leave email blank.');

            if($mob!=='' && !preg_match('/^[0-9+\-\s()]{7,30}$/',$mob))
                throw new RuntimeException('Please enter a valid mobile number or leave mobile blank.');

            $existing=familyFindCustomer($pdo,$userId,$mail,$mob);

            if($existing){
                $linkedId=(int)$existing['id'];
                if(familyLinkExists($pdo,$userId,$linkedId))
                    throw new RuntimeException('This user is already linked as a family member.');

                $stmt=$pdo->prepare("INSERT INTO user_family_links(user_id,linked_user_id,relationship,relationship_notes) VALUES(?,?,?,?)");
                $stmt->execute([$userId,$linkedId,$rel,$notes!==''?$notes:null]);

                $_SESSION['profile_success']='Existing TRAVSCOPE customer found and linked to your family.';
                redirect(BASE_URL.'profile.php#family');
            }

            $newId=familyCreateCustomer(
                $pdo,$userId,$first,$last,$mail,$mob,(string)($user['country']??'India')
            );

            $stmt=$pdo->prepare("INSERT INTO user_family_links(user_id,linked_user_id,relationship,relationship_notes) VALUES(?,?,?,?)");
            $stmt->execute([$userId,$newId,$rel,$notes!==''?$notes:null]);

            $_SESSION['profile_success']='Family member added and customer record created and linked successfully.';
            redirect(BASE_URL.'profile.php#family');

        } catch(RuntimeException $e){
            $error=$e->getMessage();
        } catch(Throwable $e){
            error_log('Family add: '.$e->getMessage());
            $error='Unable to add family member.';
        }
    }

    elseif (isset($_POST['action']) && $_POST['action']==='link_existing_customer') {
        try {
            $linked=(int)($_POST['linked_user_id']??0);
            $rel=trim((string)($_POST['link_relationship']??''));
            $notes=trim((string)($_POST['link_notes']??''));
            $allowed=['Spouse','Partner','Child','Parent','Sibling','Grandparent','Grandchild','Relative','Friend','Other'];

            if($linked<=0 || $linked===$userId || !in_array($rel,$allowed,true))
                throw new RuntimeException('Please select a valid customer and relationship.');

            if(familyLinkExists($pdo,$userId,$linked))
                throw new RuntimeException('This user is already linked as a family member.');

            $stmt=$pdo->prepare("INSERT INTO user_family_links(user_id,linked_user_id,relationship,relationship_notes) VALUES(?,?,?,?)");
            $stmt->execute([$userId,$linked,$rel,$notes!==''?$notes:null]);

            $_SESSION['profile_success']='Existing customer linked successfully.';
            redirect(BASE_URL.'profile.php#family');

        } catch(RuntimeException $e){
            $error=$e->getMessage();
        } catch(Throwable $e){
            error_log('Family link: '.$e->getMessage());
            $error='Unable to link customer.';
        }
    }

    elseif (isset($_POST['action']) && in_array($_POST['action'],['remove_family_member','remove_family_link'],true)) {
        try {
            if($_POST['action']==='remove_family_member'){
                $pdo->prepare("DELETE FROM user_family_members WHERE id=? AND owner_user_id=? LIMIT 1")->execute([(int)($_POST['family_id']??0),$userId]);
            } else {
                $pdo->prepare("DELETE FROM user_family_links WHERE id=? AND (user_id=? OR linked_user_id=?) LIMIT 1")->execute([(int)($_POST['link_id']??0),$userId,$userId]);
            }
            $_SESSION['profile_success']='Family record removed successfully.'; redirect(BASE_URL.'profile.php#family');
        } catch(Throwable $e){error_log('Family remove: '.$e->getMessage());$error='Unable to remove family record.';}
    }

    /*
    |--------------------------------------------------------------------------
    | CHANGE PASSWORD
    |--------------------------------------------------------------------------
    */

    elseif (
        isset($_POST['action'])
        &&
        $_POST['action'] === 'change_password'
    ) {

        $currentPassword =
            (string)(
                $_POST['current_password']
                ?? ''
            );

        $newPassword =
            (string)(
                $_POST['new_password']
                ?? ''
            );

        $confirmPassword =
            (string)(
                $_POST['confirm_password']
                ?? ''
            );


        if ($currentPassword === '') {

            $error =
                'Please enter your current password.';
        }

        elseif (
            !password_verify(
                $currentPassword,
                $user['password']
            )
        ) {

            $error =
                'Your current password is incorrect.';
        }

        elseif (
            strlen($newPassword) < 8
        ) {

            $error =
                'New password must contain at least 8 characters.';
        }

        elseif (
            strlen($newPassword) > 72
        ) {

            $error =
                'New password is too long.';
        }

        elseif (
            !preg_match('/[A-Za-z]/', $newPassword)
            ||
            !preg_match('/[0-9]/', $newPassword)
        ) {

            $error =
                'New password must contain at least one letter and one number.';
        }

        elseif (
            $newPassword !== $confirmPassword
        ) {

            $error =
                'New password and confirmation do not match.';
        }

        elseif (
            password_verify(
                $newPassword,
                $user['password']
            )
        ) {

            $error =
                'Your new password must be different from your current password.';
        }

        else {

            try {

                $newHash =
                    password_hash(
                        $newPassword,
                        PASSWORD_DEFAULT
                    );

                $stmt = $pdo->prepare("
                    UPDATE users
                    SET password = ?
                    WHERE id = ?
                    LIMIT 1
                ");

                $stmt->execute([
                    $newHash,
                    $userId
                ]);

                $_SESSION['profile_success'] =
                    'Your password has been changed successfully.';

                /*
                | Rotate session ID after security change.
                */

                session_regenerate_id(true);

                /*
                | Rotate CSRF token.
                */

                $_SESSION['profile_csrf'] =
                    bin2hex(
                        random_bytes(32)
                    );

                redirect(
                    BASE_URL . 'profile.php'
                );

            } catch (Throwable $e) {

                error_log(
                    'Password update error: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to change your password right now.';
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| REFRESH USER AFTER ANY PROCESS
|--------------------------------------------------------------------------
*/

$user = currentUser($pdo);

if (!$user) {
    redirect(BASE_URL . 'login.php');
}



$travelProfile=['preferred_language'=>'English','city_state'=>'','lead_source'=>'','date_of_birth'=>'','anniversary_date'=>'',
'spouse_partner_name'=>'','occupation'=>'','preferred_destination_type'=>'','travel_style'=>'','preferred_hotel_category'=>'',
'relationship_notes'=>'','birthday_wishes'=>1,'anniversary_wishes'=>1];
$familyMembers=[]; $linkedCustomers=[]; $availableCustomers=[];
try{
    $s=$pdo->prepare("SELECT * FROM user_travel_profiles WHERE user_id=? LIMIT 1");
    $s->execute([$userId]);
    if($r=$s->fetch(PDO::FETCH_ASSOC)) $travelProfile=array_merge($travelProfile,$r);

    $s=$pdo->prepare("SELECT * FROM user_family_members WHERE owner_user_id=? AND status='active' ORDER BY id DESC");
    $s->execute([$userId]);
    $familyMembers=$s->fetchAll(PDO::FETCH_ASSOC);

    $s=$pdo->prepare("
        SELECT l.id AS link_id,l.user_id AS link_owner_id,l.linked_user_id,
               l.relationship,l.relationship_notes,
               u.id,u.full_name,u.email,u.mobile,u.country,u.profile_image
        FROM user_family_links l
        JOIN users u ON u.id = CASE WHEN l.user_id=? THEN l.linked_user_id ELSE l.user_id END
        WHERE l.user_id=? OR l.linked_user_id=?
        ORDER BY l.id DESC
    ");
    $s->execute([$userId,$userId,$userId]);
    $linkedCustomers=$s->fetchAll(PDO::FETCH_ASSOC);

    foreach($linkedCustomers as &$familyLink){
        if((int)$familyLink['link_owner_id']!==$userId){
            $familyLink['relationship']=familyReverseRelationship((string)$familyLink['relationship']);
        }
    }
    unset($familyLink);

    $s=$pdo->prepare("
        SELECT id,full_name,email,mobile
        FROM users
        WHERE id!=?
          AND status='active'
          AND id NOT IN(
              SELECT linked_user_id FROM user_family_links WHERE user_id=?
              UNION
              SELECT user_id FROM user_family_links WHERE linked_user_id=?
          )
        ORDER BY full_name
        LIMIT 250
    ");
    $s->execute([$userId,$userId,$userId]);
    $availableCustomers=$s->fetchAll(PDO::FETCH_ASSOC);

}catch(Throwable $e){
    error_log('Travel/family load: '.$e->getMessage());
}
$familyCount=count($familyMembers)+count($linkedCustomers);


$travelDocuments = [];
try {
    $stmt = $pdo->prepare("
        SELECT *
        FROM user_travel_documents
        WHERE user_id = ?
        ORDER BY
            CASE WHEN document_category = 'identity' THEN 0 ELSE 1 END,
            document_type ASC,
            created_at DESC
    ");
    $stmt->execute([$userId]);
    $travelDocuments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('Traveller documents load error: ' . $e->getMessage());
}
$identityDocumentCount = count(array_filter($travelDocuments, static fn($d) => ($d['document_category'] ?? '') === 'identity'));
$travellerDocumentCount = count(array_filter($travelDocuments, static fn($d) => ($d['document_category'] ?? '') === 'travel'));



/*
|--------------------------------------------------------------------------
| BOOKING STATISTICS
|--------------------------------------------------------------------------
*/

$stats = [
    'total'     => 0,
    'confirmed' => 0,
    'completed' => 0
];

try {

    $stmt = $pdo->prepare("
        SELECT
            COUNT(*) AS total,

            SUM(
                booking_status = 'confirmed'
            ) AS confirmed,

            SUM(
                booking_status = 'completed'
            ) AS completed

        FROM bookings

        WHERE user_id = ?
    ");

    $stmt->execute([
        $userId
    ]);

    $row = $stmt->fetch();

    if ($row) {

        $stats['total'] =
            (int)($row['total'] ?? 0);

        $stats['confirmed'] =
            (int)($row['confirmed'] ?? 0);

        $stats['completed'] =
            (int)($row['completed'] ?? 0);
    }

} catch (Throwable $e) {

    error_log(
        'Profile stats error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| DISPLAY VARIABLES
|--------------------------------------------------------------------------
*/

$fullName = trim(
    (string)$user['full_name']
);

$email = trim(
    (string)$user['email']
);

$mobile = trim(
    (string)($user['mobile'] ?? '')
);

$country = trim(
    (string)($user['country'] ?? '')
);

$profileImage = profileImageUrl(
    $user['profile_image']
    ?? ''
);

$emailVerified =
    (int)$user['email_verified'] === 1;

$status = strtolower(
    (string)$user['status']
);

$initial = strtoupper(
    mb_substr(
        $fullName !== ''
            ? $fullName
            : $email,
        0,
        1
    )
);

$memberSince = !empty(
    $user['created_at']
)
    ? date(
        'M Y',
        strtotime(
            $user['created_at']
        )
    )
    : '';

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#07192d"
>

<title>
My Profile | <?= e($siteName); ?>
</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>

:root {

    --navy:#07192d;
    --navy2:#102d4c;

    --blue:#0b74ff;
    --blue2:#075ed0;
    --cyan:#00b8ff;

    --green:#07966a;
    --orange:#d98112;
    --red:#d94455;

    --bg:#f4f7fb;
    --white:#ffffff;

    --text:#172235;
    --muted:#7b8798;

    --border:#e3e9ef;

    --shadow:
        0 15px 45px
        rgba(7,25,45,.07);
}

* {
    margin:0;
    padding:0;
    box-sizing:border-box;
}

html {
    scroll-behavior:smooth;
}

body {

    min-height:100vh;

    background:var(--bg);

    color:var(--text);

    font-family:
        'DM Sans',
        sans-serif;
}

a {
    color:inherit;
    text-decoration:none;
}

input,
select,
button {
    font:inherit;
}


/* ============================================================
   HEADER
============================================================ */

.header {

    height:72px;

    padding:0 5%;

    position:sticky;
    top:0;

    z-index:1000;

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:25px;

    background:
        rgba(255,255,255,.97);

    border-bottom:
        1px solid
        var(--border);

    backdrop-filter:blur(12px);
}

.logo {

    display:flex;
    align-items:center;

    gap:9px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:20px;
    font-weight:800;
}

.logo-icon {

    width:40px;
    height:40px;

    border-radius:12px;

    display:grid;
    place-items:center;

    color:white;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--cyan)
        );

    box-shadow:
        0 8px 20px
        rgba(11,116,255,.22);
}

.logo span {
    color:var(--blue);
}

.nav {

    display:flex;
    align-items:center;

    gap:5px;
}

.nav a {

    padding:9px 11px;

    border-radius:8px;

    color:#687589;

    font-size:13px;
    font-weight:700;

    transition:.2s;
}

.nav a:hover,
.nav a.active {

    color:var(--blue);

    background:#edf5ff;
}

.header-user {

    display:flex;
    align-items:center;

    gap:9px;
}

.header-avatar {

    width:38px;
    height:38px;

    border-radius:11px;

    overflow:hidden;

    display:grid;
    place-items:center;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--cyan)
        );

    color:white;

    font-weight:800;
}

.header-avatar img {

    width:100%;
    height:100%;

    object-fit:cover;
}

.header-user strong {

    display:block;

    color:var(--navy);

    font-size:13px;
}

.header-user span {

    display:block;

    margin-top:1px;

    color:#929dab;

    font-size:11px;
}


/* ============================================================
   HERO
============================================================ */

.hero {

    min-height:255px;

    padding:
        38px 5%
        80px;

    position:relative;

    overflow:hidden;

    color:white;

    background:
        radial-gradient(
            circle at 85% 15%,
            rgba(0,184,255,.28),
            transparent 25%
        ),
        radial-gradient(
            circle at 65% 90%,
            rgba(11,116,255,.25),
            transparent 30%
        ),
        linear-gradient(
            135deg,
            #07192d,
            #0a2c4e
        );
}

.hero:before {

    content:"";

    width:280px;
    height:280px;

    position:absolute;

    right:-70px;
    top:-110px;

    border:
        1px solid
        rgba(255,255,255,.08);

    border-radius:50%;
}

.hero-inner {

    max-width:1180px;

    margin:auto;

    position:relative;

    z-index:2;
}

.breadcrumb {

    display:flex;
    align-items:center;

    gap:7px;

    color:#a8bdd1;

    font-size:12px;
}

.hero h1 {

    margin-top:22px;

    font-family:
        'Manrope',
        sans-serif;

    font-size:34px;

    line-height:1.2;
}

.hero p {

    max-width:560px;

    margin-top:8px;

    color:#afc1d2;

    font-size:13px;

    line-height:1.7;
}


/* ============================================================
   MAIN
============================================================ */

.container {

    max-width:1180px;

    margin:
        -48px auto
        0;

    padding:
        0 20px
        70px;

    position:relative;

    z-index:5;
}

.layout {

    display:grid;

    grid-template-columns:
        310px
        minmax(0,1fr);

    gap:22px;
}


/* ============================================================
   CARD
============================================================ */

.card {

    border:
        1px solid
        var(--border);

    border-radius:16px;

    background:white;

    box-shadow:var(--shadow);
}


/* ============================================================
   PROFILE SIDEBAR
============================================================ */

.profile-card {

    padding:25px 20px;

    text-align:center;
}

.profile-avatar {

    width:112px;
    height:112px;

    margin:
        0 auto
        15px;

    position:relative;

    border-radius:28px;

    display:grid;
    place-items:center;

    overflow:hidden;

    color:white;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--cyan)
        );

    font-family:
        'Manrope',
        sans-serif;

    font-size:38px;
    font-weight:800;

    box-shadow:
        0 14px 35px
        rgba(11,116,255,.22);
}

.profile-avatar img {

    width:100%;
    height:100%;

    object-fit:cover;
}

.profile-card h2 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:18px;
}

.profile-email {

    margin-top:4px;

    color:#8290a1;

    font-size:12px;

    word-break:break-word;
}

.verified {

    margin-top:10px;

    padding:6px 9px;

    border-radius:30px;

    display:inline-flex;
    align-items:center;

    gap:5px;

    background:#e8f8f1;

    color:var(--green);

    font-size:11px;
    font-weight:800;
}

.not-verified {

    background:#fff3e3;

    color:var(--orange);
}

.member {

    margin-top:10px;

    color:#99a3b0;

    font-size:11px;
}


/* STATS */

.stats {

    margin-top:22px;

    padding-top:20px;

    border-top:
        1px solid
        var(--border);

    display:grid;

    grid-template-columns:
        repeat(3,1fr);
}

.stat {

    border-right:
        1px solid
        var(--border);
}

.stat:last-child {
    border-right:0;
}

.stat strong {

    display:block;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:18px;
}

.stat span {

    display:block;

    margin-top:2px;

    color:#929dab;

    font-size:11px;
    font-weight:700;

    text-transform:uppercase;
}


/* SIDE MENU */

.side-menu {

    margin-top:15px;

    padding:9px;
}

.side-menu a {

    min-height:44px;

    padding:0 12px;

    border-radius:9px;

    display:flex;
    align-items:center;

    gap:10px;

    color:#637186;

    font-size:12px;
    font-weight:700;

    transition:.2s;
}

.side-menu a i {

    width:18px;

    text-align:center;
}

.side-menu a:hover {

    background:#f3f7fc;

    color:var(--blue);
}

.side-menu a.active {

    background:#edf5ff;

    color:var(--blue);
}


/* ============================================================
   CONTENT
============================================================ */

.content {

    display:flex;
    flex-direction:column;

    gap:18px;
}


/* ALERT */

.alert {

    padding:13px 15px;

    border-radius:10px;

    display:flex;
    align-items:flex-start;

    gap:9px;

    font-size:12px;

    line-height:1.5;
}

.alert-success {

    border:
        1px solid
        #bce8d6;

    background:#ebfaf4;

    color:#08724f;
}

.alert-error {

    border:
        1px solid
        #f1c8ce;

    background:#fff0f2;

    color:#b53647;
}


/* SECTION */

.section {

    overflow:hidden;
}

.section-header {

    min-height:65px;

    padding:0 22px;

    border-bottom:
        1px solid
        var(--border);

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:15px;
}

.section-title {

    display:flex;
    align-items:center;

    gap:10px;
}

.section-icon {

    width:35px;
    height:35px;

    border-radius:9px;

    display:grid;
    place-items:center;

    background:#edf5ff;

    color:var(--blue);
}

.section-title h2 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:13px;
}

.section-title p {

    margin-top:2px;

    color:#909baa;

    font-size:11px;
}

.section-body {
    padding:22px;
}


/* ============================================================
   PHOTO UPLOAD
============================================================ */

.photo-area {

    padding:17px;

    border:
        1px dashed
        #cbd8e6;

    border-radius:12px;

    display:flex;
    align-items:center;

    gap:17px;

    background:#fafcff;
}

.preview {

    width:82px;
    height:82px;

    flex:0 0 82px;

    border-radius:20px;

    overflow:hidden;

    display:grid;
    place-items:center;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--cyan)
        );

    color:white;

    font-size:27px;
    font-weight:800;
}

.preview img {

    width:100%;
    height:100%;

    object-fit:cover;
}

.photo-info {
    flex:1;
}

.photo-info strong {

    display:block;

    color:var(--navy);

    font-size:13px;
}

.photo-info p {

    margin-top:4px;

    color:#8995a5;

    font-size:11px;

    line-height:1.5;
}

.photo-actions {

    margin-top:9px;

    display:flex;

    gap:7px;

    flex-wrap:wrap;
}

.upload-btn {

    min-height:32px;

    padding:0 10px;

    border-radius:7px;

    display:inline-flex;
    align-items:center;

    gap:5px;

    background:#edf5ff;

    color:var(--blue);

    font-size:11px;
    font-weight:800;

    cursor:pointer;
}

.upload-btn input {
    display:none;
}

.remove-photo {

    min-height:32px;

    padding:0 10px;

    border:
        1px solid
        #f0d1d5;

    border-radius:7px;

    display:flex;
    align-items:center;

    gap:5px;

    background:#fff6f7;

    color:var(--red);

    font-size:11px;
    font-weight:800;
}


/* ============================================================
   FORMS
============================================================ */

.form-grid {

    margin-top:20px;

    display:grid;

    grid-template-columns:
        repeat(2,1fr);

    gap:17px;
}

.form-group.full {
    grid-column:1 / -1;
}

.form-group label {

    margin-bottom:6px;

    display:block;

    color:#526075;

    font-size:11px;
    font-weight:800;
}

.required {
    color:var(--red);
}

.input-wrap {

    position:relative;
}

.input-icon {

    position:absolute;

    left:13px;
    top:50%;

    transform:translateY(-50%);

    color:#9ba6b4;

    font-size:13px;

    pointer-events:none;
}

.form-control {

    width:100%;
    height:45px;

    padding:
        0 13px
        0 38px;

    border:
        1px solid
        #dfe5ec;

    border-radius:9px;

    outline:none;

    background:white;

    color:#29374a;

    font-size:13px;

    transition:.2s;
}

.form-control:focus {

    border-color:#86baff;

    box-shadow:
        0 0 0 3px
        rgba(11,116,255,.07);
}

.form-control[readonly] {

    background:#f5f7fa;

    color:#7d8998;

    cursor:not-allowed;
}

.input-badge {

    position:absolute;

    right:11px;
    top:50%;

    transform:translateY(-50%);

    padding:4px 7px;

    border-radius:20px;

    background:#e8f8f1;

    color:var(--green);

    font-size:11px;
    font-weight:800;
}

.helper {

    margin-top:5px;

    color:#9aa5b3;

    font-size:11px;

    line-height:1.5;
}


/* BUTTON */

.form-footer {

    margin-top:22px;

    padding-top:18px;

    border-top:
        1px solid
        var(--border);

    display:flex;
    align-items:center;
    justify-content:flex-end;

    gap:8px;
}

.btn {

    min-height:41px;

    padding:0 15px;

    border:0;

    border-radius:8px;

    display:inline-flex;
    align-items:center;
    justify-content:center;

    gap:6px;

    cursor:pointer;

    font-size:12px;
    font-weight:800;

    transition:.2s;
}

.btn:hover {
    transform:translateY(-1px);
}

.btn-primary {

    color:white;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--blue2)
        );

    box-shadow:
        0 7px 18px
        rgba(11,116,255,.18);
}

.btn-secondary {

    border:
        1px solid
        var(--border);

    background:white;

    color:#647286;
}


/* ============================================================
   SECURITY
============================================================ */

.security-note {

    margin-bottom:18px;

    padding:13px;

    border:
        1px solid
        #d9e7fa;

    border-radius:9px;

    display:flex;

    gap:9px;

    background:#f4f8ff;

    color:#61758d;

    font-size:11px;

    line-height:1.6;
}

.security-note i {
    color:var(--blue);
}


/* PASSWORD STRENGTH */

.password-strength {

    margin-top:7px;

    height:4px;

    border-radius:10px;

    overflow:hidden;

    background:#edf0f3;
}

.password-strength div {

    width:0;
    height:100%;

    border-radius:10px;

    background:var(--red);

    transition:.25s;
}

.strength-text {

    margin-top:5px;

    color:#909baa;

    font-size:11px;
}


/* ============================================================
   ACCOUNT INFORMATION
============================================================ */

.account-grid {

    display:grid;

    grid-template-columns:
        repeat(3,1fr);

    gap:10px;
}

.account-item {

    padding:14px;

    border:
        1px solid
        var(--border);

    border-radius:10px;

    background:#fafbfd;
}

.account-item span {

    display:block;

    color:#929dab;

    font-size:11px;

    text-transform:uppercase;

    font-weight:800;
}

.account-item strong {

    display:block;

    margin-top:5px;

    color:#354358;

    font-size:12px;

    word-break:break-word;
}


/* ============================================================
   RESPONSIVE
============================================================ */

@media(max-width:950px) {

    .layout {
        grid-template-columns:1fr;
    }

    .left-column {

        display:grid;

        grid-template-columns:
            1fr 1fr;

        gap:15px;
    }

    .side-menu {
        margin-top:0;
    }
}


@media(max-width:760px) {

    .nav {
        display:none;
    }

    .form-grid {
        grid-template-columns:1fr;
    }

    .form-group.full {
        grid-column:auto;
    }

    .account-grid {
        grid-template-columns:1fr;
    }
}


@media(max-width:600px) {

    .header {

        height:64px;

        padding:0 13px;
    }

    .logo {
        font-size:17px;
    }

    .header-user > div:last-child {
        display:none;
    }

    .hero {

        min-height:220px;

        padding:
            29px 15px
            70px;
    }

    .hero h1 {
        font-size:27px;
    }

    .container {

        padding:
            0 12px
            50px;
    }

    .left-column {
        grid-template-columns:1fr;
    }

    .section-header {

        min-height:60px;

        padding:0 15px;
    }

    .section-body {
        padding:15px;
    }

    .photo-area {

        align-items:flex-start;

        flex-direction:column;
    }

    .form-footer {
        flex-direction:column-reverse;
    }

    .form-footer .btn {
        width:100%;
    }
}


.travel-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.travel-grid .full{grid-column:1/-1}
.travel-grid label,.family-form label{display:block;margin-bottom:6px;color:#526075;font-size:12px;font-weight:800}
.travel-control{width:100%;min-height:43px;padding:0 12px;border:1px solid #dfe5ec;border-radius:9px;outline:none;background:#fff;color:#29374a;font-size:11px}
textarea.travel-control{min-height:100px;padding:11px;resize:vertical;line-height:1.5}
.profile-checks{display:flex;gap:20px;flex-wrap:wrap}.profile-checks label{display:flex;align-items:center;gap:7px;font-size:13px}
.family-list{display:grid;gap:10px;margin-bottom:18px}.family-row{padding:13px;border:1px solid var(--border);border-radius:10px;background:#fbfcfe;display:flex;justify-content:space-between;gap:12px}
.family-row h3{font-size:13px;color:var(--navy)}.family-row p{margin-top:4px;color:#8190a0;font-size:12px;line-height:1.5}.family-tag{display:inline-block;margin-top:6px;padding:4px 7px;border-radius:20px;background:#edf5ff;color:var(--blue);font-size:11px;font-weight:800}
.remove-family{border:1px solid #f0d1d5;background:#fff6f7;color:var(--red);border-radius:7px;padding:7px 9px;font-size:11px;font-weight:800;cursor:pointer}
.sub-title{margin:20px 0 5px;color:var(--navy);font-size:15px}.sub-text{color:#8995a5;font-size:13px;line-height:1.5;margin-bottom:12px}
.family-form{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}.family-form .full{grid-column:1/-1}
@media(max-width:760px){.travel-grid,.family-form{grid-template-columns:1fr}.travel-grid .full,.family-form .full{grid-column:auto}}


.document-stats{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:18px}
.document-stat{padding:14px;border:1px solid var(--border);border-radius:10px;background:#fafbfd}
.document-stat span{display:block;color:#7b8798;font-size:12px;font-weight:700}
.document-stat strong{display:block;margin-top:5px;color:var(--navy);font-size:18px;font-weight:800}
.document-upload-box{padding:16px;border:1px dashed #bfd0e4;border-radius:12px;background:#fafcff;margin-bottom:20px}
.document-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}
.document-grid .full{grid-column:1/-1}
.document-grid label{display:block;margin-bottom:6px;color:#526075;font-size:12px;font-weight:800}
.document-control{width:100%;min-height:44px;padding:0 12px;border:1px solid #dfe5ec;border-radius:9px;background:#fff;color:#29374a;font-size:13px;outline:none}
textarea.document-control{min-height:90px;padding:11px 12px;resize:vertical;line-height:1.5}
.document-control:focus{border-color:#86baff;box-shadow:0 0 0 3px rgba(11,116,255,.07)}
.document-file-wrap{padding:12px;border:1px solid #dfe5ec;border-radius:9px;background:#fff}
.document-file-wrap input[type=file]{width:100%;font-size:13px}
.document-file-note{margin-top:6px;color:#7b8798;font-size:11px;line-height:1.5}
.document-list{display:grid;gap:12px}
.document-card{padding:15px;border:1px solid var(--border);border-radius:11px;background:#fff;display:flex;justify-content:space-between;align-items:flex-start;gap:14px}
.document-card h3{color:var(--navy);font-size:15px;font-weight:800}
.document-category{display:inline-flex;margin-top:6px;padding:5px 8px;border-radius:20px;background:#edf5ff;color:var(--blue);font-size:11px;font-weight:800}
.document-meta{display:grid;grid-template-columns:repeat(2,minmax(120px,1fr));gap:7px 16px;margin-top:10px}
.document-meta div{color:#667487;font-size:12px;line-height:1.45}
.document-meta strong{color:#344357}
.document-notes{margin-top:9px;color:#667487;font-size:12px;line-height:1.5}
.document-actions{display:flex;gap:7px;flex-wrap:wrap;justify-content:flex-end}
.document-action{min-height:34px;padding:0 10px;border-radius:7px;border:1px solid var(--border);display:inline-flex;align-items:center;gap:5px;background:#fff;color:#516176;font-size:11px;font-weight:800}
.document-action.view{background:#edf5ff;color:var(--blue);border-color:#d9eaff}
.document-action.delete{background:#fff0f2;color:var(--red);border-color:#f0c8ce;cursor:pointer}
.document-empty{padding:18px;border:1px dashed #cbd8e6;border-radius:10px;background:#fafcff;color:#728095;font-size:12px;line-height:1.6}
@media(max-width:760px){.document-grid,.document-stats{grid-template-columns:1fr}.document-grid .full{grid-column:auto}.document-card{flex-direction:column}.document-actions{justify-content:flex-start}.document-meta{grid-template-columns:1fr}}



/* ============================================================
   PROFESSIONAL ONE-PAGE PROFILE WORKSPACE
   Presentation only. Existing PHP/data/forms remain unchanged.
============================================================ */

html,body{
    width:100%;
    min-height:100%;
}

body{
    overflow:hidden;
}

/* Compact global header */
.header{
    height:62px;
    padding:0 clamp(14px,2vw,28px);
}

.logo{
    font-size:18px;
}

.logo-icon{
    width:36px;
    height:36px;
    border-radius:10px;
}

.nav a{
    padding:8px 9px;
    font-size:12px;
}

.header-user strong{font-size:12px}
.header-user span{font-size:10px}

/* Compact hero */
.hero{
    min-height:118px;
    padding:20px clamp(16px,2.5vw,34px) 22px;
}

.hero-inner{
    max-width:none;
    margin:0;
}

.breadcrumb{font-size:11px}

.hero h1{
    margin-top:8px;
    font-size:27px;
}

.hero p{
    margin-top:4px;
    max-width:760px;
    font-size:12px;
    line-height:1.5;
}

/* Full browser width workspace */
.container{
    width:100%;
    max-width:none;
    height:calc(100vh - 62px - 118px);
    margin:0;
    padding:12px clamp(12px,1.8vw,24px) 14px;
    overflow:hidden;
}

.layout{
    width:100%;
    height:100%;
    min-height:0;
    display:grid;
    grid-template-columns:290px minmax(0,1fr);
    gap:12px;
    align-items:stretch;
}

.left-column{
    min-width:0;
    height:100%;
    display:flex;
    flex-direction:column;
    gap:10px;
    overflow:hidden;
}

.content{
    min-width:0;
    height:100%;
    overflow:hidden;
    display:flex;
    flex-direction:column;
    gap:8px;
}

/* Compact profile summary */
.profile-card{
    padding:14px;
    display:grid;
    grid-template-columns:68px minmax(0,1fr);
    grid-template-rows:auto auto auto;
    column-gap:11px;
    text-align:left;
    align-items:center;
}

.profile-avatar{
    width:68px;
    height:68px;
    margin:0;
    grid-row:1/4;
    border-radius:18px;
    font-size:24px;
}

.profile-card h2{
    font-size:15px;
}

.profile-email{
    margin-top:2px;
    font-size:10px;
}

.verified,
.member{
    margin-top:4px;
    font-size:10px;
}

.profile-card .stats{
    grid-column:1/-1;
    margin-top:9px;
    padding-top:9px;
}

.profile-card .stat strong{
    font-size:14px;
}

.profile-card .stat span{
    font-size:9px;
}

/* Side menu as compact vertical tab rail */
.side-menu{
    flex:1 1 auto;
    min-height:0;
    margin:0;
    padding:7px;
    overflow:auto;
}

.side-menu a{
    min-height:38px;
    padding:0 10px;
    font-size:11px;
}

.side-menu a[data-profile-tab]{
    border:1px solid transparent;
}

.side-menu a[data-profile-tab].active{
    background:#edf5ff;
    color:var(--blue);
    border-color:#d9e9ff;
}

/* Alerts do not consume excess space */
.content > .alert{
    flex:0 0 auto;
    margin:0;
    padding:9px 11px;
    font-size:11px;
}

/* Tabs: only selected section shown */
.profile-tab-panel{
    display:none !important;
    width:100%;
    height:100%;
    min-height:0;
    margin:0 !important;
    overflow:hidden;
}

.profile-tab-panel.is-active{
    display:flex !important;
    flex-direction:column;
}

/* Main panel */
.profile-tab-panel.section{
    border-radius:12px;
    box-shadow:0 8px 24px rgba(7,25,45,.05);
}

.profile-tab-panel .section-header{
    min-height:54px;
    flex:0 0 54px;
    padding:0 15px;
}

.profile-tab-panel .section-body{
    flex:1 1 auto;
    min-height:0;
    padding:14px 15px;
    overflow:auto;
    scrollbar-width:thin;
}

.section-title h2{
    font-size:14px;
}

.section-title p{
    font-size:10px;
}

.section-icon{
    width:32px;
    height:32px;
}

/* Readable but compact default text */
.form-group label,
.document-grid label{
    font-size:11px;
}

.form-control,
.document-control{
    min-height:40px;
    font-size:12px;
}

textarea.form-control,
textarea.document-control{
    min-height:78px;
}

.helper,
.security-note,
.strength-text,
.subsection-text,
.document-file-note{
    font-size:10px;
}

.btn{
    min-height:36px;
    font-size:11px;
}

.form-grid,
.document-grid{
    margin-top:12px;
    gap:11px 14px;
}

.form-footer{
    margin-top:12px;
    padding-top:11px;
}

/* Compact photo/profile controls */
.photo-area{
    padding:12px;
    gap:12px;
}

.preview{
    width:62px;
    height:62px;
    flex:0 0 62px;
    border-radius:15px;
}

.photo-info strong{font-size:12px}
.photo-info p{font-size:10px}

/* Travel / account / document layouts use available width */
.account-grid{
    grid-template-columns:repeat(3,minmax(0,1fr));
    gap:9px;
}

.profile-summary-grid{
    grid-template-columns:repeat(3,minmax(0,1fr));
    gap:9px;
}

.document-stats{
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:9px;
}

.document-grid{
    grid-template-columns:repeat(2,minmax(0,1fr));
}

.document-upload-box{
    padding:12px;
    margin-bottom:12px;
}

.document-list,
.family-list{
    gap:8px;
}

.document-card,
.family-person{
    padding:11px 12px;
}

.document-card h3,
.family-person h3{
    font-size:13px;
}

.document-meta{
    grid-template-columns:repeat(3,minmax(120px,1fr));
    gap:6px 14px;
}

.document-meta div,
.document-notes,
.family-person p{
    font-size:10px;
}

.subsection-title{
    margin:14px 0 3px;
    font-size:13px;
}

/* Tablet */
@media(max-width:1000px){
    body{
        overflow:auto;
    }

    .container{
        height:auto;
        min-height:calc(100vh - 62px - 118px);
        overflow:visible;
    }

    .layout{
        height:auto;
        grid-template-columns:1fr;
    }

    .left-column{
        height:auto;
        display:grid;
        grid-template-columns:minmax(260px,.75fr) minmax(0,1.25fr);
        overflow:visible;
    }

    .side-menu{
        display:flex;
        align-items:flex-start;
        gap:5px;
        overflow-x:auto;
        overflow-y:hidden;
        white-space:nowrap;
    }

    .side-menu a{
        flex:0 0 auto;
    }

    .content{
        height:auto;
        overflow:visible;
    }

    .profile-tab-panel{
        height:auto;
        overflow:visible;
    }

    .profile-tab-panel .section-body{
        overflow:visible;
    }
}

/* Mobile */
@media(max-width:700px){
    .header{
        height:58px;
        padding:0 10px;
    }

    .nav{
        display:none;
    }

    .header-user > div:last-child{
        display:none;
    }

    .hero{
        min-height:96px;
        padding:14px 12px 16px;
    }

    .hero h1{
        margin-top:5px;
        font-size:22px;
    }

    .hero p{
        display:none;
    }

    .container{
        min-height:calc(100vh - 58px - 96px);
        padding:8px 8px 14px;
    }

    .left-column{
        grid-template-columns:1fr;
    }

    .profile-card{
        grid-template-columns:54px minmax(0,1fr);
        padding:10px;
    }

    .profile-avatar{
        width:54px;
        height:54px;
        border-radius:14px;
        font-size:20px;
    }

    .profile-card .stats{
        margin-top:7px;
        padding-top:7px;
    }

    .side-menu{
        padding:5px;
    }

    .side-menu a{
        min-height:34px;
        padding:0 8px;
        font-size:10px;
    }

    .profile-tab-panel .section-header{
        min-height:50px;
        flex-basis:50px;
        padding:0 11px;
    }

    .profile-tab-panel .section-body{
        padding:11px;
    }

    .section-title p{
        display:none;
    }

    .form-grid,
    .document-grid,
    .account-grid,
    .profile-summary-grid,
    .document-stats{
        grid-template-columns:1fr;
    }

    .form-group.full,
    .document-grid .full{
        grid-column:auto;
    }

    .document-card,
    .family-person{
        flex-direction:column;
    }

    .document-meta{
        grid-template-columns:1fr;
    }
}



/* ============================================================
   INTERNATIONAL STANDARD COMPACT UI/UX UPGRADE
   Presentation only. Existing PHP/data/forms/actions unchanged.
============================================================ */

:root{
    --ui-radius:12px;
    --ui-shadow:0 8px 24px rgba(7,25,45,.06);
    --ui-shadow-hover:0 10px 26px rgba(7,25,45,.09);
    --ui-focus:0 0 0 3px rgba(11,116,255,.16);
    --ui-surface:#ffffff;
    --ui-surface-soft:#f8fafc;
    --ui-border:#dfe6ee;
    --ui-text:#1d2939;
    --ui-muted:#667085;
}

body{
    color:var(--ui-text);
    font-size:14px;
    line-height:1.5;
    text-rendering:optimizeLegibility;
}

button,input,select,textarea{font-family:inherit}
button,a,input,select,textarea{-webkit-tap-highlight-color:transparent}

a:focus-visible,
button:focus-visible,
input:focus-visible,
select:focus-visible,
textarea:focus-visible{
    outline:none;
    box-shadow:var(--ui-focus);
}

.header{
    border-bottom:1px solid var(--ui-border);
    box-shadow:0 1px 0 rgba(16,24,40,.02);
}

.logo{letter-spacing:-.3px}

.nav a{
    min-height:36px;
    display:inline-flex;
    align-items:center;
    border-radius:8px;
}

.nav a:hover,.nav a.active{background:#eef5ff}

.hero{
    background:
        radial-gradient(circle at 86% 18%,rgba(0,184,255,.18),transparent 25%),
        linear-gradient(135deg,#07192d,#0c3158);
}

.hero h1{letter-spacing:-.6px}
.hero p{color:#c0cfdd}

.layout{gap:14px}

.card{
    border:1px solid var(--ui-border);
    border-radius:var(--ui-radius);
    background:var(--ui-surface);
    box-shadow:var(--ui-shadow);
}

.profile-avatar{box-shadow:0 8px 22px rgba(11,116,255,.18)}

.side-menu a{
    min-height:40px;
    border-radius:8px;
    color:#526277;
    font-weight:700;
    transition:background .15s ease,color .15s ease,border-color .15s ease;
}

.side-menu a:hover{
    background:#f4f7fb;
    color:var(--navy);
}

.side-menu a[data-profile-tab].active{
    background:#eaf3ff;
    border-color:#d2e6ff;
    color:#075ed0;
}

.profile-tab-panel.section{
    border-radius:var(--ui-radius);
    box-shadow:var(--ui-shadow);
}

.profile-tab-panel .section-header{
    background:#fff;
    border-bottom:1px solid var(--ui-border);
}

.section-title h2{
    color:#12263f;
    font-size:15px;
    line-height:1.3;
    letter-spacing:-.15px;
}

.section-title p{
    color:var(--ui-muted);
    font-size:11px;
    line-height:1.45;
}

.section-icon{
    background:#eef5ff;
    color:#075ed0;
    border:1px solid #dbeaff;
}

.form-grid,.document-grid{gap:13px 16px}

.form-group label,.document-grid label{
    color:#344054;
    font-size:12px;
    font-weight:700;
}

.form-control,.document-control,.travel-control{
    min-height:42px;
    border:1px solid #d7e0ea;
    border-radius:8px;
    background:#fff;
    color:#101828;
    font-size:13px;
    transition:border-color .15s ease,box-shadow .15s ease,background .15s ease;
}

.form-control:hover,.document-control:hover,.travel-control:hover{border-color:#b9c8d8}

.form-control:focus,.document-control:focus,.travel-control:focus{
    border-color:#6aa7ff;
    box-shadow:var(--ui-focus);
}

.form-control::placeholder,.document-control::placeholder,.travel-control::placeholder{color:#98a2b3}

textarea.form-control,textarea.document-control,textarea.travel-control{line-height:1.55}

.btn,.upload-btn,.document-action,.family-remove{
    border-radius:8px;
    font-weight:700;
    transition:transform .12s ease,box-shadow .12s ease,background .12s ease;
}

.btn:hover,.upload-btn:hover,.document-action:hover,.family-remove:hover{transform:translateY(-1px)}

.btn-primary{
    background:#0b74ff;
    box-shadow:0 4px 12px rgba(11,116,255,.18);
}

.btn-primary:hover{
    background:#0867e4;
    box-shadow:0 6px 16px rgba(11,116,255,.22);
}

.account-item,.profile-summary,.document-stat{
    border:1px solid var(--ui-border);
    border-radius:9px;
    background:var(--ui-surface-soft);
}

.account-item span,.profile-summary span,.document-stat span{
    color:#667085;
    font-size:10px;
    font-weight:700;
    letter-spacing:.3px;
}

.account-item strong,.profile-summary strong,.document-stat strong{color:#1d2939}

.family-person,.document-card{
    border:1px solid var(--ui-border);
    border-radius:10px;
    background:#fff;
    transition:box-shadow .15s ease,border-color .15s ease;
}

.family-person:hover,.document-card:hover{
    border-color:#cdd8e5;
    box-shadow:var(--ui-shadow-hover);
}

.family-tag,.document-category{
    border:1px solid #dceaff;
    background:#eef5ff;
    color:#075ed0;
}

.alert{
    border-radius:9px;
    font-size:12px;
}

.alert-success{
    background:#ecfdf3;
    border-color:#abefc6;
    color:#067647;
}

.alert-error{
    background:#fef3f2;
    border-color:#fecdca;
    color:#b42318;
}

.photo-area,.document-upload-box{
    border:1px dashed #bfcbd8;
    background:#fafcff;
    border-radius:10px;
}

.profile-tab-panel .section-body{
    scrollbar-width:thin;
    scrollbar-color:#c4cfdb transparent;
}

.form-footer{
    display:flex;
    align-items:center;
    justify-content:flex-end;
    gap:8px;
}

.btn,.upload-btn,.document-action,.family-remove,.side-menu a{min-height:38px}

@media(min-width:1200px){
    .layout{grid-template-columns:280px minmax(0,1fr)}
    .profile-tab-panel .section-body{padding:16px 18px}
    .form-grid,.document-grid{gap:14px 18px}
}

@media(max-width:1000px){
    .side-menu{
        background:#fff;
        border:1px solid var(--ui-border);
    }
    .side-menu a{
        border:1px solid var(--ui-border);
        background:#fff;
    }
    .side-menu a[data-profile-tab].active{border-color:#bdd9ff}
}

@media(max-width:700px){
    body{font-size:14px}

    .form-control,.document-control,.travel-control{
        min-height:44px;
        font-size:14px;
    }

    .btn,.upload-btn,.document-action,.family-remove{
        min-height:42px;
        font-size:12px;
    }

    .section-title h2{font-size:14px}
    .profile-tab-panel .section-body{padding:12px}

    .form-footer{align-items:stretch}
    .form-footer .btn{
        width:100%;
        justify-content:center;
    }
}

@media(max-width:420px){
    .container{padding-left:6px;padding-right:6px}
    .profile-card{padding:9px}
    .side-menu{gap:4px}
    .side-menu a{padding:0 7px}
    .document-card,.family-person{padding:10px}
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>

<body>


<!-- ============================================================
     HEADER
============================================================ -->

<header class="header">

<a
    href="<?= e(BASE_URL); ?>"
    class="logo"
>

    <div class="logo-icon">
        <i class="fa-solid fa-plane"></i>
    </div>

    TRAV<span>SCOPE</span>

</a>


<nav class="nav">

    <a href="<?= e(BASE_URL . 'dashboard.php'); ?>">
        Dashboard
    </a>

    <a href="<?= e(BASE_URL . 'packages.php'); ?>">
        Packages
    </a>

    
<a href="#account-info" data-profile-tab="account-info" role="tab" aria-controls="account-info">
    <i class="fa-solid fa-circle-info"></i>
    Account Information
</a>

<a href="<?= e(BASE_URL . 'my-bookings.php'); ?>">
        My Bookings
    </a>

    <a
        href="<?= e(BASE_URL . 'profile.php'); ?>"
        class="active"
    >
        Profile
    </a>

</nav>


<div class="header-user">

    <div class="header-avatar">

        <?php if ($profileImage !== ''): ?>

            <img
                src="<?= e($profileImage); ?>"
                alt="Profile"
            >

        <?php else: ?>

            <?= e($initial); ?>

        <?php endif; ?>

    </div>


    <div>

        <strong>
            <?= e($fullName); ?>
        </strong>

        <span>
            My Account
        </span>

    </div>

</div>

</header>


<!-- ============================================================
     HERO
============================================================ -->

<section class="hero">

<div class="hero-inner">

    <div class="breadcrumb">

        <a href="<?= e(BASE_URL . 'dashboard.php'); ?>">
            Dashboard
        </a>

        <i class="fa-solid fa-chevron-right"></i>

        My Profile

    </div>


    <h1>
        My Profile
    </h1>

    <p>
        Manage your personal information, profile photo and account
        security from one secure place.
    </p>

</div>

</section>


<!-- ============================================================
     MAIN
============================================================ -->

<main class="container">

<div class="layout">


<!-- ============================================================
     LEFT
============================================================ -->

<aside class="left-column">


<!-- PROFILE CARD -->

<section class="card profile-card">

    <div class="profile-avatar">

        <?php if ($profileImage !== ''): ?>

            <img
                src="<?= e($profileImage); ?>"
                alt="<?= e($fullName); ?>"
            >

        <?php else: ?>

            <?= e($initial); ?>

        <?php endif; ?>

    </div>


    <h2>
        <?= e($fullName); ?>
    </h2>


    <div class="profile-email">
        <?= e($email); ?>
    </div>


    <?php if ($emailVerified): ?>

        <div class="verified">

            <i class="fa-solid fa-circle-check"></i>

            Verified Account

        </div>

    <?php else: ?>

        <div class="verified not-verified">

            <i class="fa-solid fa-triangle-exclamation"></i>

            Email Not Verified

        </div>

    <?php endif; ?>


    <?php if ($memberSince !== ''): ?>

        <div class="member">

            <i class="fa-regular fa-calendar"></i>

            Member since
            <?= e($memberSince); ?>

        </div>

    <?php endif; ?>


    <div class="stats">

        <div class="stat">

            <strong>
                <?= number_format(
                    $stats['total']
                ); ?>
            </strong>

            <span>
                Trips
            </span>

        </div>


        <div class="stat">

            <strong>
                <?= number_format(
                    $stats['confirmed']
                ); ?>
            </strong>

            <span>
                Confirmed
            </span>

        </div>


        <div class="stat">

            <strong>
                <?= number_format(
                    $stats['completed']
                ); ?>
            </strong>

            <span>
                Completed
            </span>

        </div>

    </div>

</section>


<!-- SIDE MENU -->

<section class="card side-menu">

    <a
        href="#personal"
        class="active"
     data-profile-tab="personal" role="tab" aria-controls="personal">

        <i class="fa-regular fa-user"></i>

        Personal Information

    </a>


    <a href="#documents" data-profile-tab="documents" role="tab" aria-controls="documents"><i class="fa-solid fa-passport"></i> Identity & Travel Documents</a>

    <a href="#travel-profile" data-profile-tab="travel-profile" role="tab" aria-controls="travel-profile"><i class="fa-solid fa-route"></i> Travel Profile</a>
    <a href="#family" data-profile-tab="family" role="tab" aria-controls="family"><i class="fa-solid fa-people-roof"></i> Family & Travellers</a>

    <a href="#security" data-profile-tab="security" role="tab" aria-controls="security">

        <i class="fa-solid fa-shield-halved"></i>

        Password & Security

    </a>


    <a href="<?= e(BASE_URL . 'my-bookings.php'); ?>">

        <i class="fa-solid fa-suitcase-rolling"></i>

        My Bookings

    </a>


    <a href="<?= e(BASE_URL . 'packages.php'); ?>">

        <i class="fa-solid fa-compass"></i>

        Explore Packages

    </a>


    <a href="<?= e(BASE_URL . 'dashboard.php'); ?>">

        <i class="fa-solid fa-house"></i>

        Dashboard

    </a>


    <a
        href="<?= e(BASE_URL . 'logout.php'); ?>"
        style="color:#d94455;"
    >

        <i class="fa-solid fa-right-from-bracket"></i>

        Sign Out

    </a>

</section>


</aside>


<!-- ============================================================
     RIGHT CONTENT
============================================================ -->

<div class="content">


<?php if ($success !== ''): ?>

<div class="alert alert-success">

    <i class="fa-solid fa-circle-check"></i>

    <div>
        <?= e($success); ?>
    </div>

</div>

<?php endif; ?>


<?php if ($error !== ''): ?>

<div class="alert alert-error">

    <i class="fa-solid fa-circle-exclamation"></i>

    <div>
        <?= e($error); ?>
    </div>

</div>

<?php endif; ?>


<!-- ============================================================
     PERSONAL INFORMATION
============================================================ -->

<section
    class="profile-tab-panel card section"
    id="personal"
 role="tabpanel">


<div class="section-header">

    <div class="section-title">

        <div class="section-icon">
            <i class="fa-regular fa-user"></i>
        </div>

        <div>

            <h2>
                Personal Information
            </h2>

            <p>
                Keep your traveller details up to date.
            </p>

        </div>

    </div>

</div>


<div class="section-body">


<form
    method="post"
    enctype="multipart/form-data"
    id="profileForm"
>


<input
    type="hidden"
    name="csrf_token"
    value="<?= e($csrfToken); ?>"
>

<input
    type="hidden"
    name="action"
    value="update_profile"
>


<!-- PHOTO -->

<div class="photo-area">


<div class="preview" id="photoPreview">

    <?php if ($profileImage !== ''): ?>

        <img
            src="<?= e($profileImage); ?>"
            alt="Profile"
            id="previewImage"
        >

    <?php else: ?>

        <span id="previewInitial">
            <?= e($initial); ?>
        </span>

    <?php endif; ?>

</div>


<div class="photo-info">

    <strong>
        Profile Photo
    </strong>

    <p>
        Upload a clear JPG, PNG or WEBP image.
        Maximum file size is 5 MB.
    </p>


    <div class="photo-actions">

        <label class="upload-btn">

            <i class="fa-solid fa-camera"></i>

            Choose Photo

            <input
                type="file"
                name="profile_image"
                id="profileImageInput"
                accept="image/jpeg,image/png,image/webp"
            >

        </label>


        <?php if ($profileImage !== ''): ?>

            <label class="remove-photo">

                <input
                    type="checkbox"
                    name="remove_photo"
                    value="1"
                    style="width:auto;"
                >

                <i class="fa-regular fa-trash-can"></i>

                Remove

            </label>

        <?php endif; ?>

    </div>

</div>


</div>


<!-- FORM -->

<div class="form-grid">


<!-- FULL NAME -->

<div class="form-group">

    <label>
        Full Name
        <span class="required">*</span>
    </label>

    <div class="input-wrap">

        <i class="fa-regular fa-user input-icon"></i>

        <input
            type="text"
            name="full_name"
            class="form-control"
            value="<?= e($fullName); ?>"
            maxlength="150"
            required
            autocomplete="name"
        >

    </div>

</div>


<!-- EMAIL -->

<div class="form-group">

    <label>
        Email Address
    </label>

    <div class="input-wrap">

        <i class="fa-regular fa-envelope input-icon"></i>

        <input
            type="email"
            class="form-control"
            value="<?= e($email); ?>"
            readonly
        >

        <?php if ($emailVerified): ?>

            <span class="input-badge">

                <i class="fa-solid fa-check"></i>

                Verified

            </span>

        <?php endif; ?>

    </div>

    <div class="helper">
        Your verified login email cannot be changed from this page.
    </div>

</div>


<!-- MOBILE -->

<div class="form-group">

    <label>
        Mobile Number
    </label>

    <div class="input-wrap">

        <i class="fa-solid fa-phone input-icon"></i>

        <input
            type="tel"
            name="mobile"
            class="form-control"
            value="<?= e($mobile); ?>"
            maxlength="20"
            autocomplete="tel"
            placeholder="+91 9876543210"
        >

    </div>

</div>


<!-- COUNTRY -->

<div class="form-group">

    <label>
        Country
    </label>

    <div class="input-wrap">

        <i class="fa-solid fa-earth-asia input-icon"></i>

        <input
            type="text"
            name="country"
            class="form-control"
            value="<?= e($country); ?>"
            maxlength="100"
            autocomplete="country-name"
            placeholder="India"
        >

    </div>

</div>


</div>


<div class="form-footer">

    <a
        href="<?= e(BASE_URL . 'dashboard.php'); ?>"
        class="btn btn-secondary"
    >
        Cancel
    </a>


    <button
        type="submit"
        class="btn btn-primary"
    >

        <i class="fa-solid fa-floppy-disk"></i>

        Save Profile

    </button>

</div>


</form>

</div>

</section>




<section class="profile-tab-panel card section" id="documents" role="tabpanel">

<div class="section-header">
    <div class="section-title">
        <div class="section-icon"><i class="fa-solid fa-passport"></i></div>
        <div>
            <h2>Identity & Traveller Documents</h2>
            <p>Save identity, passport, visa and other journey documents securely with their details.</p>
        </div>
    </div>
</div>

<div class="section-body">

<div class="document-stats">
    <div class="document-stat">
        <span>Identity Documents</span>
        <strong><?= number_format($identityDocumentCount); ?></strong>
    </div>
    <div class="document-stat">
        <span>Traveller Documents</span>
        <strong><?= number_format($travellerDocumentCount); ?></strong>
    </div>
</div>

<div class="document-upload-box">

<form method="post" enctype="multipart/form-data" id="travelDocumentForm">
<input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
<input type="hidden" name="action" value="add_travel_document">

<div class="document-grid">

    <div class="full">
        <label for="documentType">Choose Document Type *</label>
        <select class="document-control" name="document_type" id="documentType" required>
            <option value="">Select identity or traveller document</option>
            <optgroup label="Identity Documents">
                <?php foreach (travelDocumentTypes()['identity'] as $docType): ?>
                    <option value="<?= e($docType); ?>"><?= e($docType); ?></option>
                <?php endforeach; ?>
            </optgroup>
            <optgroup label="Traveller Documents">
                <?php foreach (travelDocumentTypes()['travel'] as $docType): ?>
                    <option value="<?= e($docType); ?>"><?= e($docType); ?></option>
                <?php endforeach; ?>
            </optgroup>
        </select>
    </div>

    <div>
        <label id="documentNumberLabel">Document Number / Reference</label>
        <input class="document-control" name="document_number" id="documentNumber"
               maxlength="150" placeholder="Enter document number or reference">
    </div>

    <div>
        <label>Issuing Country</label>
        <input class="document-control" name="issuing_country" maxlength="100"
               placeholder="e.g. India">
    </div>

    <div>
        <label>Issue Date</label>
        <input class="document-control" type="date" name="document_issue_date">
    </div>

    <div>
        <label>Expiry / Valid Until</label>
        <input class="document-control" type="date" name="document_expiry_date">
    </div>

    <div class="full">
        <label id="documentFileLabel">Upload Document File *</label>
        <div class="document-file-wrap">
            <input type="file" name="document_file" id="documentFile"
                   accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp"
                   required>
            <div class="document-file-note" id="documentFileNote">
                First choose a document type, then choose the respective PDF/JPG/PNG/WEBP file. Maximum 8 MB.
            </div>
        </div>
    </div>

    <div class="full">
        <label>Document Notes</label>
        <textarea class="document-control" name="document_notes" maxlength="1000"
                  placeholder="Optional notes, visa type, passport remarks, policy details or other useful information"></textarea>
    </div>

</div>

<div class="form-footer">
    <button type="submit" class="btn btn-primary">
        <i class="fa-solid fa-cloud-arrow-up"></i>
        Save Document
    </button>
</div>

</form>
</div>

<?php if ($travelDocuments): ?>

<div class="document-list">
<?php foreach ($travelDocuments as $document): ?>
    <div class="document-card">
        <div>
            <h3><?= e($document['document_type']); ?></h3>
            <span class="document-category">
                <?= ($document['document_category'] ?? '') === 'identity' ? 'Identity Document' : 'Traveller Document'; ?>
            </span>

            <div class="document-meta">
                <div><strong>Number:</strong> <?= e($document['document_number'] ?: 'Not entered'); ?></div>
                <div><strong>Country:</strong> <?= e($document['issuing_country'] ?: 'Not entered'); ?></div>
                <div><strong>Issue:</strong> <?= e(!empty($document['issue_date']) ? date('d M Y', strtotime($document['issue_date'])) : 'Not entered'); ?></div>
                <div><strong>Expiry:</strong> <?= e(!empty($document['expiry_date']) ? date('d M Y', strtotime($document['expiry_date'])) : 'Not entered'); ?></div>
                <div><strong>File:</strong> <?= e($document['original_name']); ?></div>
                <div><strong>Size:</strong> <?= number_format(((int)$document['file_size']) / 1024, 0); ?> KB</div>
            </div>

            <?php if (!empty($document['notes'])): ?>
                <div class="document-notes"><?= nl2br(e($document['notes'])); ?></div>
            <?php endif; ?>
        </div>

        <div class="document-actions">
            <a class="document-action view"
               href="<?= e(BASE_URL . ltrim((string)$document['file_path'], '/')); ?>"
               target="_blank" rel="noopener">
                <i class="fa-regular fa-eye"></i> View File
            </a>

            <form method="post" onsubmit="return confirm('Delete this saved document and its uploaded file?');">
                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                <input type="hidden" name="action" value="delete_travel_document">
                <input type="hidden" name="document_id" value="<?= (int)$document['id']; ?>">
                <button type="submit" class="document-action delete">
                    <i class="fa-regular fa-trash-can"></i> Delete
                </button>
            </form>
        </div>
    </div>
<?php endforeach; ?>
</div>

<?php else: ?>

<div class="document-empty">
    No identity or traveller documents are saved yet. Choose a document type above, enter its details and upload the respective file.
</div>

<?php endif; ?>

</div>
</section>


<section class="profile-tab-panel card section" id="travel-profile" role="tabpanel">
<div class="section-header"><div class="section-title"><div class="section-icon"><i class="fa-solid fa-route"></i></div><div><h2>Travel Profile</h2><p>Personal preferences for better travel planning and service.</p></div></div></div>
<div class="section-body">
<form method="post"><input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>"><input type="hidden" name="action" value="update_travel_profile">
<div class="travel-grid">
<div><label>Date of Birth</label><input class="travel-control" type="date" name="date_of_birth" value="<?= e((string)$travelProfile['date_of_birth']); ?>"></div>
<div><label>Anniversary Date</label><input class="travel-control" type="date" name="anniversary_date" value="<?= e((string)$travelProfile['anniversary_date']); ?>"></div>
<div><label>Preferred Language</label><input class="travel-control" name="preferred_language" maxlength="50" value="<?= e((string)$travelProfile['preferred_language']); ?>" placeholder="English"></div>
<div><label>City / State</label><input class="travel-control" name="city_state" maxlength="150" value="<?= e((string)$travelProfile['city_state']); ?>" placeholder="Bhubaneswar, Odisha"></div>
<div><label>Lead Source</label><input class="travel-control" name="lead_source" maxlength="100" value="<?= e((string)$travelProfile['lead_source']); ?>" placeholder="Referral"></div>
<div><label>Spouse / Partner Name</label><input class="travel-control" name="spouse_partner_name" maxlength="150" value="<?= e((string)$travelProfile['spouse_partner_name']); ?>"></div>
<div><label>Occupation</label><input class="travel-control" name="occupation" maxlength="150" value="<?= e((string)$travelProfile['occupation']); ?>"></div>
<div><label>Preferred Destination Type</label><input class="travel-control" name="preferred_destination_type" maxlength="255" value="<?= e((string)$travelProfile['preferred_destination_type']); ?>" placeholder="Beach, heritage, wildlife, spiritual..."></div>
<div><label>Travel Style</label><input class="travel-control" name="travel_style" maxlength="255" value="<?= e((string)$travelProfile['travel_style']); ?>" placeholder="Luxury, premium, family, leisure..."></div>
<div><label>Preferred Hotel Category</label><input class="travel-control" name="preferred_hotel_category" maxlength="100" value="<?= e((string)$travelProfile['preferred_hotel_category']); ?>" placeholder="3 Star, 4 Star, 5 Star, Boutique..."></div>
<div class="full"><label>Important Relationship Notes</label><textarea class="travel-control" name="relationship_notes" maxlength="5000" placeholder="Important preferences, family details, special occasions, service preferences..."><?= e((string)$travelProfile['relationship_notes']); ?></textarea></div>
<div class="full profile-checks"><label><input type="checkbox" name="birthday_wishes" value="1" <?= !empty($travelProfile['birthday_wishes'])?'checked':''; ?>> Birthday wishes</label><label><input type="checkbox" name="anniversary_wishes" value="1" <?= !empty($travelProfile['anniversary_wishes'])?'checked':''; ?>> Anniversary wishes</label></div>
</div>
<div class="form-footer"><button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save Travel Profile</button></div>
</form></div></section>

<section class="profile-tab-panel card section" id="family" role="tabpanel">
<div class="section-header"><div class="section-title"><div class="section-icon"><i class="fa-solid fa-people-roof"></i></div><div><h2>Family & Travellers</h2><p><?= number_format($familyCount); ?> linked traveller record(s).</p></div></div></div>
<div class="section-body">
<?php if($linkedCustomers||$familyMembers): ?><div class="family-list">
<?php foreach($linkedCustomers as $f): ?><div class="family-row"><div><h3><?= e($f['full_name']); ?></h3><span class="family-tag"><?= e($f['relationship']); ?> · Customer #<?= (int)$f['id']; ?></span><p><?= e($f['mobile']?:'Phone not provided'); ?><?php if(!empty($f['email']) && !str_ends_with((string)$f['email'],'@travscope.local')): ?> · <?= e($f['email']); ?><?php endif; ?></p></div><form method="post" onsubmit="return confirm('Remove this family link?');"><input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>"><input type="hidden" name="action" value="remove_family_link"><input type="hidden" name="link_id" value="<?= (int)$f['link_id']; ?>"><button class="remove-family">Remove Link</button></form></div><?php endforeach; ?>
<?php foreach($familyMembers as $f): ?><div class="family-row"><div><h3><?= e(trim($f['first_name'].' '.($f['last_name']??''))); ?></h3><span class="family-tag"><?= e($f['relationship']); ?> · <?= e($f['member_code']); ?></span><p><?= e($f['mobile']?:'Phone not provided'); ?><?php if(!empty($f['email'])): ?> · <?= e($f['email']); ?><?php endif; ?></p></div><form method="post" onsubmit="return confirm('Remove this family member?');"><input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>"><input type="hidden" name="action" value="remove_family_member"><input type="hidden" name="family_id" value="<?= (int)$f['id']; ?>"><button class="remove-family">Remove</button></form></div><?php endforeach; ?>
</div><?php endif; ?>

<h3 class="sub-title">+ Add New Family Member</h3><p class="sub-text">Create a separate traveller record and keep relationship details with your profile.</p>
<form method="post"><input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>"><input type="hidden" name="action" value="add_family_member">
<div class="family-form">
<div><label>First Name *</label><input class="travel-control" name="family_first_name" required maxlength="100"></div><div><label>Last Name</label><input class="travel-control" name="family_last_name" maxlength="100"></div>
<div><label>Relationship *</label><select class="travel-control" name="family_relationship" required><option value="">Select Relationship</option><?php foreach(['Spouse','Partner','Child','Parent','Sibling','Grandparent','Grandchild','Relative','Friend','Other'] as $r): ?><option value="<?= e($r); ?>"><?= e($r); ?></option><?php endforeach; ?></select></div>
<div><label>Date of Birth</label><input class="travel-control" type="date" name="family_date_of_birth"></div>
<div><label>Phone / WhatsApp</label><input class="travel-control" name="family_mobile" maxlength="30" placeholder="Optional"></div><div><label>Email (Optional)</label><input class="travel-control" type="email" name="family_email" maxlength="190" placeholder="Optional"></div>
<div class="full"><label>Relationship Notes</label><input class="travel-control" name="family_notes" maxlength="500" placeholder="Optional note"></div></div>
<div class="form-footer"><button class="btn btn-primary"><i class="fa-solid fa-user-plus"></i> Create & Link Family Member</button></div></form>

<?php if($availableCustomers): ?><h3 class="sub-title">+ Link Existing Customer</h3><p class="sub-text">Link an existing TRAVSCOPE account without creating a duplicate.</p>
<form method="post"><input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>"><input type="hidden" name="action" value="link_existing_customer"><div class="family-form">
<div class="full"><label>Existing Customer *</label><select class="travel-control" name="linked_user_id" required><option value="">Select customer</option><?php foreach($availableCustomers as $u): ?><option value="<?= (int)$u['id']; ?>"><?= e($u['full_name']); ?> · <?= e($u['email']); ?></option><?php endforeach; ?></select></div>
<div><label>Relationship *</label><select class="travel-control" name="link_relationship" required><?php foreach(['Spouse','Partner','Child','Parent','Sibling','Grandparent','Grandchild','Relative','Friend','Other'] as $r): ?><option value="<?= e($r); ?>"><?= e($r); ?></option><?php endforeach; ?></select></div>
<div><label>Relationship Notes</label><input class="travel-control" name="link_notes" maxlength="500" placeholder="Optional note"></div></div><div class="form-footer"><button class="btn btn-primary"><i class="fa-solid fa-link"></i> Link Customer</button></div></form><?php endif; ?>
</div></section>

<!-- ============================================================
     PASSWORD SECURITY
============================================================ -->

<section
    class="profile-tab-panel card section"
    id="security"
 role="tabpanel">


<div class="section-header">

    <div class="section-title">

        <div class="section-icon">
            <i class="fa-solid fa-shield-halved"></i>
        </div>

        <div>

            <h2>
                Password & Security
            </h2>

            <p>
                Keep your TRAVSCOPE account protected.
            </p>

        </div>

    </div>

</div>


<div class="section-body">


<div class="security-note">

    <i class="fa-solid fa-lock"></i>

    <div>
        For your security, you must enter your current password before
        setting a new password.
    </div>

</div>


<form
    method="post"
    id="passwordForm"
>


<input
    type="hidden"
    name="csrf_token"
    value="<?= e($csrfToken); ?>"
>

<input
    type="hidden"
    name="action"
    value="change_password"
>


<div class="form-grid">


<!-- CURRENT -->

<div class="form-group full">

    <label>
        Current Password
        <span class="required">*</span>
    </label>

    <div class="input-wrap">

        <i class="fa-solid fa-lock input-icon"></i>

        <input
            type="password"
            name="current_password"
            id="currentPassword"
            class="form-control"
            autocomplete="current-password"
            required
        >

    </div>

</div>


<!-- NEW -->

<div class="form-group">

    <label>
        New Password
        <span class="required">*</span>
    </label>

    <div class="input-wrap">

        <i class="fa-solid fa-key input-icon"></i>

        <input
            type="password"
            name="new_password"
            id="newPassword"
            class="form-control"
            minlength="8"
            maxlength="72"
            autocomplete="new-password"
            required
        >

    </div>


    <div class="password-strength">

        <div id="strengthBar"></div>

    </div>

    <div
        class="strength-text"
        id="strengthText"
    >
        Use at least 8 characters with letters and numbers.
    </div>

</div>


<!-- CONFIRM -->

<div class="form-group">

    <label>
        Confirm New Password
        <span class="required">*</span>
    </label>

    <div class="input-wrap">

        <i class="fa-solid fa-key input-icon"></i>

        <input
            type="password"
            name="confirm_password"
            id="confirmPassword"
            class="form-control"
            minlength="8"
            maxlength="72"
            autocomplete="new-password"
            required
        >

    </div>

</div>


</div>


<div class="form-footer">

    <button
        type="reset"
        class="btn btn-secondary"
    >
        Clear
    </button>


    <button
        type="submit"
        class="btn btn-primary"
    >

        <i class="fa-solid fa-shield-halved"></i>

        Change Password

    </button>

</div>


</form>

</div>

</section>


<!-- ============================================================
     ACCOUNT INFORMATION
============================================================ -->

<section class="profile-tab-panel card section" id="account-info" role="tabpanel">


<div class="section-header">

    <div class="section-title">

        <div class="section-icon">
            <i class="fa-solid fa-circle-info"></i>
        </div>

        <div>

            <h2>
                Account Information
            </h2>

            <p>
                Basic information about your account.
            </p>

        </div>

    </div>

</div>


<div class="section-body">

<div class="account-grid">


<div class="account-item">

    <span>
        Account ID
    </span>

    <strong>
        #<?= (int)$userId; ?>
    </strong>

</div>


<div class="account-item">

    <span>
        Account Status
    </span>

    <strong>

        <?php if ($status === 'active'): ?>

            <i
                class="fa-solid fa-circle-check"
                style="color:#07966a;"
            ></i>

        <?php endif; ?>

        <?= e(
            ucfirst($status)
        ); ?>

    </strong>

</div>


<div class="account-item">

    <span>
        Email Verification
    </span>

    <strong>

        <?php if ($emailVerified): ?>

            <i
                class="fa-solid fa-circle-check"
                style="color:#07966a;"
            ></i>

            Verified

        <?php else: ?>

            Not Verified

        <?php endif; ?>

    </strong>

</div>


<div class="account-item">

    <span>
        Member Since
    </span>

    <strong>
        <?= e(
            !empty($user['created_at'])
                ? date(
                    'd M Y',
                    strtotime(
                        $user['created_at']
                    )
                )
                : '—'
        ); ?>
    </strong>

</div>


<div class="account-item">

    <span>
        Last Login
    </span>

    <strong>

        <?= e(
            !empty($user['last_login'])
                ? date(
                    'd M Y, h:i A',
                    strtotime(
                        $user['last_login']
                    )
                )
                : 'Not available'
        ); ?>

    </strong>

</div>


<div class="account-item">

    <span>
        Total Bookings
    </span>

    <strong>
        <?= number_format(
            $stats['total']
        ); ?>
    </strong>

</div>


</div>

</div>

</section>


</div>

</div>

</main>


<script>

/*
|--------------------------------------------------------------------------
| PROFILE IMAGE PREVIEW
|--------------------------------------------------------------------------
*/

const imageInput =
    document.getElementById(
        'profileImageInput'
    );

if (imageInput) {

    imageInput.addEventListener(
        'change',
        function () {

            const file =
                this.files[0];

            if (!file) {
                return;
            }

            const allowedTypes = [
                'image/jpeg',
                'image/png',
                'image/webp'
            ];

            if (
                !allowedTypes.includes(
                    file.type
                )
            ) {

                alert(
                    'Please choose a JPG, PNG or WEBP image.'
                );

                this.value = '';

                return;
            }

            if (
                file.size
                >
                5 * 1024 * 1024
            ) {

                alert(
                    'Profile image must be smaller than 5 MB.'
                );

                this.value = '';

                return;
            }


            const reader =
                new FileReader();


            reader.onload =
                function (event) {

                    const preview =
                        document.getElementById(
                            'photoPreview'
                        );

                    preview.innerHTML = '';

                    const image =
                        document.createElement(
                            'img'
                        );

                    image.src =
                        event.target.result;

                    image.alt =
                        'Profile preview';

                    preview.appendChild(
                        image
                    );
                };


            reader.readAsDataURL(
                file
            );
        }
    );
}


/*
|--------------------------------------------------------------------------
| PASSWORD STRENGTH
|--------------------------------------------------------------------------
*/

const password =
    document.getElementById(
        'newPassword'
    );

const strengthBar =
    document.getElementById(
        'strengthBar'
    );

const strengthText =
    document.getElementById(
        'strengthText'
    );


if (password) {

    password.addEventListener(
        'input',
        function () {

            const value =
                this.value;

            let score = 0;


            if (value.length >= 8) {
                score++;
            }

            if (
                /[a-z]/.test(value)
                &&
                /[A-Z]/.test(value)
            ) {
                score++;
            }

            if (
                /[0-9]/.test(value)
            ) {
                score++;
            }

            if (
                /[^A-Za-z0-9]/.test(value)
            ) {
                score++;
            }


            const widths = [
                '0%',
                '25%',
                '50%',
                '75%',
                '100%'
            ];

            strengthBar.style.width =
                widths[score];


            if (value === '') {

                strengthBar.style.background =
                    '#d94455';

                strengthText.textContent =
                    'Use at least 8 characters with letters and numbers.';

            } else if (score <= 1) {

                strengthBar.style.background =
                    '#d94455';

                strengthText.textContent =
                    'Weak password';

            } else if (score === 2) {

                strengthBar.style.background =
                    '#d98112';

                strengthText.textContent =
                    'Fair password';

            } else if (score === 3) {

                strengthBar.style.background =
                    '#0b74ff';

                strengthText.textContent =
                    'Good password';

            } else {

                strengthBar.style.background =
                    '#07966a';

                strengthText.textContent =
                    'Strong password';
            }
        }
    );
}


/*
|--------------------------------------------------------------------------
| PASSWORD MATCH CHECK
|--------------------------------------------------------------------------
*/

const passwordForm =
    document.getElementById(
        'passwordForm'
    );

if (passwordForm) {

    passwordForm.addEventListener(
        'submit',
        function (event) {

            const newPassword =
                document.getElementById(
                    'newPassword'
                ).value;

            const confirmPassword =
                document.getElementById(
                    'confirmPassword'
                ).value;


            if (
                newPassword
                !==
                confirmPassword
            ) {

                event.preventDefault();

                alert(
                    'New password and confirmation do not match.'
                );
            }
        }
    );
}

</script>


<script>
(function () {
    const type = document.getElementById('documentType');
    const fileLabel = document.getElementById('documentFileLabel');
    const fileNote = document.getElementById('documentFileNote');
    const numberLabel = document.getElementById('documentNumberLabel');
    const numberInput = document.getElementById('documentNumber');

    if (!type || !fileLabel || !fileNote) return;

    const labels = {
        'Aadhaar Card': ['Aadhaar Number', 'Upload Aadhaar Card File', 'Choose the Aadhaar PDF/image file.'],
        'PAN Card': ['PAN Number', 'Upload PAN Card File', 'Choose the PAN card PDF/image file.'],
        'Voter ID': ['Voter ID Number', 'Upload Voter ID File', 'Choose the Voter ID PDF/image file.'],
        'Driving Licence': ['Driving Licence Number', 'Upload Driving Licence File', 'Choose the driving licence PDF/image file.'],
        'National ID': ['National ID Number', 'Upload National ID File', 'Choose the National ID PDF/image file.'],
        'Birth Certificate': ['Certificate Number', 'Upload Birth Certificate File', 'Choose the birth certificate PDF/image file.'],
        'Passport': ['Passport Number', 'Upload Passport File', 'Choose the passport bio-page PDF/image file.'],
        'Visa': ['Visa Number / Reference', 'Upload Visa File', 'Choose the visa PDF/image file.'],
        'Travel Insurance': ['Policy Number', 'Upload Travel Insurance File', 'Choose the insurance policy PDF/image file.'],
        'Flight Ticket': ['PNR / Ticket Number', 'Upload Flight Ticket File', 'Choose the flight ticket PDF/image file.'],
        'Hotel Voucher': ['Booking / Voucher Number', 'Upload Hotel Voucher File', 'Choose the hotel voucher PDF/image file.'],
        'Vaccination Certificate': ['Certificate Number', 'Upload Vaccination Certificate File', 'Choose the vaccination certificate PDF/image file.'],
        'Other Travel Document': ['Document Number / Reference', 'Upload Travel Document File', 'Choose the respective travel document PDF/image file.']
    };

    function refreshDocumentLabels() {
        const selected = type.value;
        const data = labels[selected] || ['Document Number / Reference', 'Upload Document File *', 'Choose the respective PDF/JPG/PNG/WEBP file.'];
        if (numberLabel) numberLabel.textContent = data[0];
        if (numberInput) numberInput.placeholder = 'Enter ' + data[0].toLowerCase();
        fileLabel.textContent = data[1] + ' *';
        fileNote.textContent = data[2] + ' Maximum 8 MB. PDF, JPG, PNG or WEBP.';
    }

    type.addEventListener('change', refreshDocumentLabels);
    refreshDocumentLabels();
})();
</script>


<script>
(function () {
    const links = Array.from(document.querySelectorAll('[data-profile-tab]'));
    const panels = Array.from(document.querySelectorAll('.profile-tab-panel'));

    if (!links.length || !panels.length) return;

    function openProfileTab(tabId, updateHash) {
        const panel = document.getElementById(tabId);
        if (!panel || !panel.classList.contains('profile-tab-panel')) return;

        panels.forEach(function (item) {
            item.classList.remove('is-active');
        });

        links.forEach(function (link) {
            const isActive = link.getAttribute('data-profile-tab') === tabId;
            link.classList.toggle('active', isActive);
            link.setAttribute('aria-selected', isActive ? 'true' : 'false');
            link.setAttribute('tabindex', isActive ? '0' : '-1');
        });

        panel.classList.add('is-active');

        if (updateHash) {
            history.replaceState(null, '', '#' + tabId);
        }

        const body = panel.querySelector('.section-body');
        if (body) body.scrollTop = 0;
    }

    links.forEach(function (link) {
        link.addEventListener('click', function (event) {
            const tabId = this.getAttribute('data-profile-tab');
            if (!tabId) return;
            event.preventDefault();
            openProfileTab(tabId, true);
        });
    });

    const requested = window.location.hash.replace('#', '');
    const valid = panels.some(function (panel) {
        return panel.id === requested;
    });

    openProfileTab(valid ? requested : 'personal', false);

    window.addEventListener('hashchange', function () {
        const tabId = window.location.hash.replace('#', '');
        if (tabId) openProfileTab(tabId, false);
    });
})();
</script>


<script>
(function(){
    const tabs = Array.from(document.querySelectorAll('[data-profile-tab]'));
    if (!tabs.length) return;

    tabs.forEach(function(tab,index){
        tab.addEventListener('keydown',function(event){
            let next=null;
            if(event.key==='ArrowRight'||event.key==='ArrowDown'){
                next=tabs[(index+1)%tabs.length];
            }else if(event.key==='ArrowLeft'||event.key==='ArrowUp'){
                next=tabs[(index-1+tabs.length)%tabs.length];
            }else if(event.key==='Home'){
                next=tabs[0];
            }else if(event.key==='End'){
                next=tabs[tabs.length-1];
            }

            if(next){
                event.preventDefault();
                next.focus();
                next.click();
            }
        });
    });
})();
</script>


<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>