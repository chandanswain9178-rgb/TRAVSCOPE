<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| BOOK PACKAGE / CHECKOUT PAGE
| DATE-WISE 3/4/5 STAR PRICE VERSION: 2026-08-04-R1
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';


/* STEP 10 - DIRECT BOOKING SERVICE AUTOMATION */
$packageServicesFunctionsFile = __DIR__ . '/package-services-functions.php';
if (is_file($packageServicesFunctionsFile)) {
    require_once $packageServicesFunctionsFile;
}
$supplierFunctionsFile = __DIR__ . '/supplier-functions.php';
if (is_file($supplierFunctionsFile)) {
    require_once $supplierFunctionsFile;
}


/*
|--------------------------------------------------------------------------
| REQUIRE USER LOGIN
|--------------------------------------------------------------------------
*/

if (!isLoggedIn()) {

    $_SESSION['login_redirect'] =
        $_SERVER['REQUEST_URI'] ?? 'packages.php';

    setFlash(
        'error',
        'Please login to continue your booking.'
    );

    redirect(BASE_URL . 'login.php');
}


/*
|--------------------------------------------------------------------------
| CURRENT USER
|--------------------------------------------------------------------------
*/

$user = currentUser($pdo);

if (
    !$user
    || strtolower((string)$user['status']) !== 'active'
) {

    unset($_SESSION['user_id']);

    setFlash(
        'error',
        'Your account is not available. Please login again.'
    );

    redirect(BASE_URL . 'login.php');
}

$userId = (int)$user['id'];


/*
|--------------------------------------------------------------------------
| SETTINGS
|--------------------------------------------------------------------------
*/

$siteName = getSetting(
    $pdo,
    'site_name',
    'TRAVSCOPE.COM'
);

$currencySymbol = getSetting(
    $pdo,
    'currency_symbol',
    '₹'
);


/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function bookingImage(?string $image): string
{
    $image = trim((string)$image);

    if ($image === '') {
        return 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1200&q=85';
    }

    if (preg_match('#^https?://#i', $image)) {
        return $image;
    }

    return BASE_URL . ltrim($image, '/');
}


function cleanBookingText(string $value): string
{
    return trim(
        preg_replace('/\s+/', ' ', $value)
    );
}

function ensureBookingHotelColumns(PDO $pdo): void
{
    try{$pdo->exec("ALTER TABLE bookings ADD COLUMN hotel_category ENUM('3_star','4_star','5_star') NULL AFTER package_id");}catch(Throwable $e){}
    try{$pdo->exec("ALTER TABLE bookings ADD COLUMN hotel_price DECIMAL(12,2) NULL AFTER hotel_category");}catch(Throwable $e){}
}
ensureBookingHotelColumns($pdo);


/*
|--------------------------------------------------------------------------
| COUPON VALIDATION
|--------------------------------------------------------------------------
|
| Expected coupons columns:
| id, code, description, discount_type, discount_value, minimum_amount,
| maximum_discount, usage_limit, used_count, start_date, expiry_date, status
|--------------------------------------------------------------------------
*/

function validateBookingCoupon(
    PDO $pdo,
    string $couponCode,
    float $subtotal,
    bool $lock = false
): array {

    $couponCode = strtoupper(trim($couponCode));

    if ($couponCode === '') {
        return [
            'valid' => false,
            'message' => '',
            'coupon' => null,
            'discount' => 0.00
        ];
    }

    $sql = "
        SELECT
            id,
            code,
            description,
            discount_type,
            discount_value,
            minimum_amount,
            maximum_discount,
            usage_limit,
            used_count,
            start_date,
            expiry_date,
            status
        FROM coupons
        WHERE UPPER(code) = ?
        LIMIT 1
    ";

    if ($lock) {
        $sql .= " FOR UPDATE";
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$couponCode]);

    $coupon = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$coupon) {
        return [
            'valid' => false,
            'message' => 'Invalid coupon code.',
            'coupon' => null,
            'discount' => 0.00
        ];
    }

    if (strtolower((string)$coupon['status']) !== 'active') {
        return [
            'valid' => false,
            'message' => 'This coupon is inactive.',
            'coupon' => null,
            'discount' => 0.00
        ];
    }

    $now = time();

    if (
        !empty($coupon['start_date'])
        && strtotime($coupon['start_date']) > $now
    ) {
        return [
            'valid' => false,
            'message' => 'This coupon is not active yet.',
            'coupon' => null,
            'discount' => 0.00
        ];
    }

    if (
        !empty($coupon['expiry_date'])
        && strtotime($coupon['expiry_date']) < $now
    ) {
        return [
            'valid' => false,
            'message' => 'This coupon has expired.',
            'coupon' => null,
            'discount' => 0.00
        ];
    }

    if (
        $coupon['usage_limit'] !== null
        && (int)$coupon['usage_limit'] > 0
        && (int)$coupon['used_count'] >= (int)$coupon['usage_limit']
    ) {
        return [
            'valid' => false,
            'message' => 'This coupon has reached its usage limit.',
            'coupon' => null,
            'discount' => 0.00
        ];
    }

    $minimumAmount = max(
        0,
        (float)$coupon['minimum_amount']
    );

    if ($subtotal < $minimumAmount) {
        return [
            'valid' => false,
            'message' =>
                'Minimum booking amount for this coupon is '
                . number_format($minimumAmount, 2)
                . '.',
            'coupon' => null,
            'discount' => 0.00
        ];
    }

    $discountValue = max(
        0,
        (float)$coupon['discount_value']
    );

    $discount = 0.00;

    if (
        strtolower((string)$coupon['discount_type'])
        === 'percentage'
    ) {

        $discount =
            ($subtotal * $discountValue) / 100;

        if (
            $coupon['maximum_discount'] !== null
            && (float)$coupon['maximum_discount'] > 0
        ) {
            $discount = min(
                $discount,
                (float)$coupon['maximum_discount']
            );
        }

    } else {

        $discount = $discountValue;
    }

    $discount = round(
        min($discount, $subtotal),
        2
    );

    if ($discount <= 0) {
        return [
            'valid' => false,
            'message' => 'This coupon does not provide a valid discount.',
            'coupon' => null,
            'discount' => 0.00
        ];
    }

    return [
        'valid' => true,
        'message' =>
            'Coupon ' . $coupon['code']
            . ' applied successfully.',
        'coupon' => $coupon,
        'discount' => $discount
    ];
}


/*
|--------------------------------------------------------------------------
| GET PACKAGE ID
|--------------------------------------------------------------------------
*/

$packageId = (int)(
    $_POST['package_id']
    ?? $_GET['package']
    ?? 0
);

if ($packageId <= 0) {

    setFlash(
        'error',
        'Please select a valid travel package.'
    );

    redirect(BASE_URL . 'packages.php');
}


/*
|--------------------------------------------------------------------------
| FETCH PACKAGE
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT

        p.*,

        d.name AS destination_name,
        d.country AS destination_country

    FROM packages p

    LEFT JOIN destinations d
        ON d.id = p.destination_id

    WHERE
        p.id = ?
        AND p.status = 'active'

    LIMIT 1
");

$stmt->execute([$packageId]);

$package = $stmt->fetch();

if (!$package) {

    setFlash(
        'error',
        'This package is currently unavailable.'
    );

    redirect(BASE_URL . 'packages.php');
}


/*
|--------------------------------------------------------------------------
| DEFAULT VALUES FROM PACKAGE DETAILS / PACKAGES PAGE
|--------------------------------------------------------------------------
*/

$travelDate = trim(
    (string)(
        $_POST['travel_date']
        ?? $_GET['travel_date']
        ?? ''
    )
);

$adults = (int)(
    $_POST['adults']
    ?? $_GET['adults']
    ?? 2
);

$children = (int)(
    $_POST['children']
    ?? $_GET['children']
    ?? 0
);


$childAgesRaw =
    $_POST['child_ages']
    ?? $_GET['child_ages']
    ?? [];

$childAges = [];

if (is_array($childAgesRaw)) {
    foreach ($childAgesRaw as $age) {
        $age = trim((string)$age);

        if ($age !== '' && ctype_digit($age)) {
            $childAges[] = max(0, min(17, (int)$age));
        }
    }
}

$childBedTypesRaw =
    $_POST['child_bed_types']
    ?? $_GET['child_bed_types']
    ?? [];

$childBedTypes = [];

if (is_array($childBedTypesRaw)) {
    foreach ($childBedTypesRaw as $type) {
        $type = strtolower(trim((string)$type));

        $childBedTypes[] =
            in_array($type, ['with_bed','without_bed','infant','legacy'], true)
                ? $type
                : 'with_bed';
    }
}


/*
|--------------------------------------------------------------------------
| DATE-WISE HOTEL CATEGORY PRICE
|--------------------------------------------------------------------------
*/

$hotelCategoryRaw =
    trim(
        (string)(
            $_POST['hotel_category']
            ?? $_POST['hotel_type']
            ?? $_GET['hotel_category']
            ?? $_GET['hotel_type']
            ?? ''
        )
    );

$hotelCategoryRaw =
    strtolower(
        str_replace(
            ['_star', ' star', 'star'],
            '',
            $hotelCategoryRaw
        )
    );

$hotelCategory =
    in_array(
        $hotelCategoryRaw,
        ['3', '4', '5'],
        true
    )
        ? $hotelCategoryRaw
        : '';

$occupancyType =
    strtolower(
        trim(
            (string)(
                $_POST['occupancy_type']
                ?? $_GET['occupancy_type']
                ?? 'twin'
            )
        )
    );

$occupancyType =
    in_array($occupancyType, ['twin','triple','single'], true)
        ? $occupancyType
        : 'twin';

$pricingDate =
    preg_match('/^\d{4}-\d{2}-\d{2}$/', $travelDate)
        ? $travelDate
        : date('Y-m-d');

$packagePriceRows = [];

try {
    $stmt = $pdo->prepare("
        SELECT
            valid_from,
            valid_to,
            price_3_star,
            price_4_star,
            price_5_star
        FROM package_date_prices
        WHERE package_id = ?
        ORDER BY
            valid_from ASC,
            sort_order ASC,
            id ASC
    ");

    $stmt->execute([
        $packageId
    ]);

    $packagePriceRows =
        $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    error_log(
        'Booking package price rows error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| STEP 08 - SMART OCCUPANCY PRICING
|--------------------------------------------------------------------------
*/

$packageOccupancyPrices = [];

try {
    $stmt = $pdo->prepare("
        SELECT
            valid_from,
            valid_to,
            star_category,
            twin_price,
            triple_price,
            single_price,
            child_with_bed_price,
            child_without_bed_price,
            infant_price,
            infant_age_to
        FROM package_occupancy_prices
        WHERE package_id = ?
        ORDER BY valid_from ASC, star_category ASC, sort_order ASC, id ASC
    ");
    $stmt->execute([$packageId]);
    $packageOccupancyPrices = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $packageOccupancyPrices = [];
}

function bookingOccupancyRowForDate(
    array $rows,
    string $date,
    string $star
): ?array {
    foreach ($rows as $row) {
        if (
            (string)(int)($row['star_category'] ?? 0) === (string)$star
            && $date >= (string)($row['valid_from'] ?? '')
            && $date <= (string)($row['valid_to'] ?? '')
        ) {
            return $row;
        }
    }
    return null;
}

function bookingOccupancyAdultPrice(
    ?array $row,
    string $type
): float {
    if (!$row) return 0.0;

    $field = [
        'twin' => 'twin_price',
        'triple' => 'triple_price',
        'single' => 'single_price',
    ][$type] ?? 'twin_price';

    return isset($row[$field]) && $row[$field] !== null
        ? max(0, (float)$row[$field])
        : 0.0;
}

function bookingFirstOccupancyType(?array $row): string
{
    if (!$row) return 'twin';

    foreach (['twin','triple','single'] as $type) {
        if (bookingOccupancyAdultPrice($row, $type) > 0) {
            return $type;
        }
    }

    return 'twin';
}

function bookingPriceRowForDate(
    array $rows,
    string $date
): ?array {
    foreach ($rows as $row) {
        if (
            $date >= (string)$row['valid_from']
            && $date <= (string)$row['valid_to']
        ) {
            return $row;
        }
    }

    return null;
}

function bookingFirstAvailableCategory(?array $row): string
{
    if (!$row) {
        return '';
    }

    foreach (['3', '4', '5'] as $star) {
        $field = 'price_' . $star . '_star';

        if (
            isset($row[$field])
            && $row[$field] !== null
            && (float)$row[$field] > 0
        ) {
            return $star;
        }
    }

    return '';
}

$currentPriceRow =
    bookingPriceRowForDate(
        $packagePriceRows,
        $pricingDate
    );

if (
    $hotelCategory === ''
    || (
        $currentPriceRow
        && (float)(
            $currentPriceRow[
                'price_' . $hotelCategory . '_star'
            ]
            ?? 0
        ) <= 0
        && !bookingOccupancyRowForDate(
            $packageOccupancyPrices,
            $pricingDate,
            $hotelCategory
        )
    )
) {
    $hotelCategory =
        bookingFirstAvailableCategory(
            $currentPriceRow
        );
}

if ($hotelCategory === '' && $packageOccupancyPrices) {
    foreach (['3','4','5'] as $star) {
        $occRow =
            bookingOccupancyRowForDate(
                $packageOccupancyPrices,
                $pricingDate,
                $star
            );

        if (!$occRow) continue;

        $candidateType = $occupancyType;

        if (
            bookingOccupancyAdultPrice(
                $occRow,
                $candidateType
            ) <= 0
        ) {
            $candidateType =
                bookingFirstOccupancyType(
                    $occRow
                );
        }

        if (
            bookingOccupancyAdultPrice(
                $occRow,
                $candidateType
            ) > 0
        ) {
            $hotelCategory = $star;

            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $occupancyType = $candidateType;
            }

            break;
        }
    }
}

$adultPrice = 0.0;

if (
    $currentPriceRow
    && $hotelCategory !== ''
) {
    $adultPrice =
        (float)(
            $currentPriceRow[
                'price_' . $hotelCategory . '_star'
            ]
            ?? 0
        );
}

/*
| Legacy fallback for old packages without date-wise pricing rows.
*/
if (
    $adultPrice <= 0
    && !$packagePriceRows
) {
    $adultPrice =
        (float)(
            $package['sale_price']
            ?: $package['regular_price']
            ?: 0
        );
}

$adultPrice =
    max(
        0,
        $adultPrice
    );

$currentOccupancyPriceRow =
    $hotelCategory !== ''
        ? bookingOccupancyRowForDate(
            $packageOccupancyPrices,
            $pricingDate,
            $hotelCategory
        )
        : null;

if ($currentOccupancyPriceRow) {
    if (
        $_SERVER['REQUEST_METHOD'] !== 'POST'
        && bookingOccupancyAdultPrice(
            $currentOccupancyPriceRow,
            $occupancyType
        ) <= 0
    ) {
        $occupancyType =
            bookingFirstOccupancyType(
                $currentOccupancyPriceRow
            );
    }

    $smartAdultPrice =
        bookingOccupancyAdultPrice(
            $currentOccupancyPriceRow,
            $occupancyType
        );

    if ($smartAdultPrice > 0) {
        $adultPrice = $smartAdultPrice;
    }
}

$occupancyPrice = $adultPrice;

$bookingHotelCategory =
    $hotelCategory !== ''
        ? $hotelCategory . '_star'
        : null;


/*
|--------------------------------------------------------------------------
| CHILD AGE PRICE ROWS
|--------------------------------------------------------------------------
| Uses the independent Admin child pricing rows created for packages.
| Falls back to the original package child fields for older packages.
*/

$packageChildPrices = [];

try {
    $stmt = $pdo->prepare("
        SELECT
            age_from,
            age_to,
            price,
            sort_order
        FROM package_child_prices
        WHERE package_id = ?
        ORDER BY
            sort_order ASC,
            age_from ASC,
            id ASC
    ");

    $stmt->execute([$packageId]);

    $packageChildPrices =
        $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    error_log(
        'Booking child pricing rows error: '
        . $e->getMessage()
    );

    $packageChildPrices = [];
}

if (!$packageChildPrices) {
    $legacyChildAgeMin =
        max(
            0,
            (int)($package['child_age_min'] ?? 0)
        );

    $legacyChildAgeMax =
        max(
            0,
            (int)($package['child_age_max'] ?? 0)
        );

    $legacyChildPrice =
        max(
            0,
            (float)($package['child_price'] ?? 0)
        );

    if (
        $legacyChildAgeMax >= $legacyChildAgeMin
        && (
            $legacyChildAgeMax > 0
            || $legacyChildAgeMin > 0
            || $legacyChildPrice > 0
        )
    ) {
        $packageChildPrices[] = [
            'age_from' => $legacyChildAgeMin,
            'age_to' => $legacyChildAgeMax,
            'price' => $legacyChildPrice,
            'sort_order' => 1
        ];
    }
}

function bookingChildPriceForAge(
    array $rows,
    int $age
): ?float {
    foreach ($rows as $row) {
        $from = max(0, (int)($row['age_from'] ?? 0));
        $to = max(0, (int)($row['age_to'] ?? 0));

        if ($age >= $from && $age <= $to) {
            return max(
                0,
                (float)($row['price'] ?? 0)
            );
        }
    }

    return null;
}

function bookingChildPriceTotal(
    array $rows,
    array $ages
): float {
    $total = 0.0;

    foreach ($ages as $age) {
        $price =
            bookingChildPriceForAge(
                $rows,
                (int)$age
            );

        if ($price !== null) {
            $total += $price;
        }
    }

    return round($total, 2);
}


function bookingSmartChildPrice(
    array $legacyRows,
    ?array $occupancyRow,
    int $age,
    string $bedType
): ?float {
    if ($occupancyRow) {
        $infantAgeTo = max(
            0,
            (int)($occupancyRow['infant_age_to'] ?? 2)
        );

        if (
            $age <= $infantAgeTo
            && array_key_exists('infant_price', $occupancyRow)
            && $occupancyRow['infant_price'] !== null
        ) {
            return max(
                0,
                (float)$occupancyRow['infant_price']
            );
        }

        if (
            $bedType === 'with_bed'
            && array_key_exists('child_with_bed_price', $occupancyRow)
            && $occupancyRow['child_with_bed_price'] !== null
        ) {
            return max(
                0,
                (float)$occupancyRow['child_with_bed_price']
            );
        }

        if (
            $bedType === 'without_bed'
            && array_key_exists('child_without_bed_price', $occupancyRow)
            && $occupancyRow['child_without_bed_price'] !== null
        ) {
            return max(
                0,
                (float)$occupancyRow['child_without_bed_price']
            );
        }
    }

    return bookingChildPriceForAge(
        $legacyRows,
        $age
    );
}

function bookingSmartChildPriceTotal(
    array $legacyRows,
    ?array $occupancyRow,
    array $ages,
    array $bedTypes
): float {
    $total = 0.0;

    foreach ($ages as $index => $age) {
        $bedType =
            (string)($bedTypes[$index] ?? 'with_bed');

        $price =
            bookingSmartChildPrice(
                $legacyRows,
                $occupancyRow,
                (int)$age,
                $bedType
            );

        if ($price !== null) {
            $total += $price;
        }
    }

    return round($total, 2);
}

function bookingSmartChildBreakdown(
    array $legacyRows,
    ?array $occupancyRow,
    array $ages,
    array $bedTypes
): array {
    $out = [];

    foreach ($ages as $index => $age) {
        $age = (int)$age;
        $bedType = (string)($bedTypes[$index] ?? 'with_bed');

        if (
            $occupancyRow
            && $age <= max(0, (int)($occupancyRow['infant_age_to'] ?? 2))
        ) {
            $bedType = 'infant';
        }

        $out[] = [
            'child' => $index + 1,
            'age' => $age,
            'basis' => $bedType,
            'price' => bookingSmartChildPrice(
                $legacyRows,
                $occupancyRow,
                $age,
                $bedType
            ),
        ];
    }

    return $out;
}

$childAgeMin = 0;
$childAgeMax = 17;

if ($packageChildPrices) {
    $childAgeMin = min(
        array_map(
            static fn(array $row): int =>
                max(0, (int)($row['age_from'] ?? 0)),
            $packageChildPrices
        )
    );

    $childAgeMax = max(
        array_map(
            static fn(array $row): int =>
                max(0, (int)($row['age_to'] ?? 0)),
            $packageChildPrices
        )
    );
}

/*
|--------------------------------------------------------------------------
| LIMIT TRAVELLER COUNTS
|--------------------------------------------------------------------------
*/

$adults = max(
    1,
    min(20, $adults)
);

$children = max(
    0,
    min(20, $children)
);


if ($children <= 0) {
    $childAges = [];
    $childBedTypes = [];
} else {
    $childAges = array_slice(
        $childAges,
        0,
        $children
    );

    $childBedTypes = array_slice(
        $childBedTypes,
        0,
        $children
    );

    while (count($childBedTypes) < $children) {
        $childBedTypes[] = 'with_bed';
    }
}


/*
|--------------------------------------------------------------------------
| FORM DEFAULTS
|--------------------------------------------------------------------------
*/

$customerName = trim(
    (string)(
        $_POST['customer_name']
        ?? $user['full_name']
        ?? ''
    )
);

$customerEmail = trim(
    (string)(
        $_POST['customer_email']
        ?? $user['email']
        ?? ''
    )
);

$customerMobile = trim(
    (string)(
        $_POST['customer_mobile']
        ?? $user['mobile']
        ?? ''
    )
);

$specialRequest = trim(
    (string)(
        $_POST['special_request']
        ?? ''
    )
);


/*
|--------------------------------------------------------------------------
| COUPON DEFAULTS
|--------------------------------------------------------------------------
*/

$couponCode = strtoupper(
    trim(
        (string)(
            $_POST['coupon_code']
            ?? ''
        )
    )
);

$couponMessage = '';
$couponMessageType = '';
$appliedCoupon = null;
$discountAmount = 0.00;


/*
|--------------------------------------------------------------------------
| SERVER SIDE PRICE CALCULATION
|--------------------------------------------------------------------------
| Adult hotel-category pricing and Admin-set child age pricing are calculated
| separately and then combined into the booking subtotal.
|--------------------------------------------------------------------------
*/

$adultSubtotal =
    round(
        $adultPrice * $adults,
        2
    );

$childSubtotal =
    bookingSmartChildPriceTotal(
        $packageChildPrices,
        $currentOccupancyPriceRow,
        $childAges,
        $childBedTypes
    );

$subtotal =
    round(
        $adultSubtotal + $childSubtotal,
        2
    );

$totalAmount = $subtotal;


/*
|--------------------------------------------------------------------------
| PREVIEW COUPON
|--------------------------------------------------------------------------
*/

if ($couponCode !== '') {

    try {

        $couponResult =
            validateBookingCoupon(
                $pdo,
                $couponCode,
                $subtotal
            );

        if ($couponResult['valid']) {

            $appliedCoupon =
                $couponResult['coupon'];

            $discountAmount =
                (float)$couponResult['discount'];

            $totalAmount =
                max(
                    0,
                    round(
                        $subtotal - $discountAmount,
                        2
                    )
                );

            $couponMessage =
                $couponResult['message'];

            $couponMessageType =
                'success';

        } else {

            $couponMessage =
                $couponResult['message'];

            $couponMessageType =
                'error';
        }

    } catch (Throwable $e) {

        error_log(
            'Coupon preview failed: '
            . $e->getMessage()
        );

        $couponMessage =
            'Coupon could not be checked right now.';

        $couponMessageType =
            'error';
    }
}


/*
|--------------------------------------------------------------------------
| VALIDATE AND CREATE BOOKING
|--------------------------------------------------------------------------
*/

$errors = [];

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && !isset($_POST['apply_coupon'])
) {

    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */

    $csrf =
        $_POST['csrf_token']
        ?? '';

    if (!verifyCsrf($csrf)) {

        $errors[] =
            'Your session expired. Please refresh the page and try again.';
    }


    /*
    |--------------------------------------------------------------------------
    | CUSTOMER NAME
    |--------------------------------------------------------------------------
    */

    $customerName =
        cleanBookingText($customerName);

    if (
        $customerName === ''
        || mb_strlen($customerName) < 2
    ) {

        $errors[] =
            'Please enter the traveller name.';
    }

    if (mb_strlen($customerName) > 150) {

        $errors[] =
            'Traveller name is too long.';
    }


    /*
    |--------------------------------------------------------------------------
    | EMAIL
    |--------------------------------------------------------------------------
    */

    $customerEmail =
        strtolower(
            trim($customerEmail)
        );

    if (
        !filter_var(
            $customerEmail,
            FILTER_VALIDATE_EMAIL
        )
    ) {

        $errors[] =
            'Please enter a valid email address.';
    }


    /*
    |--------------------------------------------------------------------------
    | MOBILE
    |--------------------------------------------------------------------------
    */

    $customerMobile =
        preg_replace(
            '/[^0-9+]/',
            '',
            $customerMobile
        );

    if (
        strlen($customerMobile) < 8
        || strlen($customerMobile) > 20
    ) {

        $errors[] =
            'Please enter a valid mobile number.';
    }


    /*
    |--------------------------------------------------------------------------
    | TRAVEL DATE
    |--------------------------------------------------------------------------
    */

    if ($travelDate === '') {

        $errors[] =
            'Please select your travel date.';

    } else {

        $dateObject =
            DateTime::createFromFormat(
                'Y-m-d',
                $travelDate
            );

        $dateValid =
            $dateObject
            &&
            $dateObject->format('Y-m-d')
            ===
            $travelDate;

        if (!$dateValid) {

            $errors[] =
                'Please select a valid travel date.';

        } else {

            $today =
                new DateTime('today');

            if ($dateObject <= $today) {

                $errors[] =
                    'Travel date must be a future date.';
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | REVALIDATE DATE-WISE HOTEL PRICE
    |--------------------------------------------------------------------------
    */

    if ($travelDate !== '') {
        $currentPriceRow =
            bookingPriceRowForDate(
                $packagePriceRows,
                $travelDate
            );

        if (!$currentPriceRow && $packagePriceRows) {
            $errors[] =
                'No package price is available for the selected travel date.';
        } else {
            if ($hotelCategory === '') {
                $hotelCategory =
                    bookingFirstAvailableCategory(
                        $currentPriceRow
                    );
            }

            if (
                $currentPriceRow
                && $hotelCategory !== ''
            ) {
                $adultPrice =
                    (float)(
                        $currentPriceRow[
                            'price_' . $hotelCategory . '_star'
                        ]
                        ?? 0
                    );
            }

            $currentOccupancyPriceRow =
                $hotelCategory !== ''
                    ? bookingOccupancyRowForDate(
                        $packageOccupancyPrices,
                        $travelDate,
                        $hotelCategory
                    )
                    : null;

            if ($currentOccupancyPriceRow) {
                $smartAdultPrice =
                    bookingOccupancyAdultPrice(
                        $currentOccupancyPriceRow,
                        $occupancyType
                    );

                if ($smartAdultPrice > 0) {
                    $adultPrice = $smartAdultPrice;
                } else {
                    $errors[] =
                        'The selected occupancy is not available for this travel date and hotel category.';
                }
            }

            if (
                $packagePriceRows
                && $adultPrice <= 0
            ) {
                $errors[] =
                    'The selected hotel category is not available for this travel date.';
            }
        }
    }

    $occupancyPrice = max(0, (float)$adultPrice);

    $bookingHotelCategory =
        $hotelCategory !== ''
            ? $hotelCategory . '_star'
            : null;


    /*
    |--------------------------------------------------------------------------
    | TRAVELLERS
    |--------------------------------------------------------------------------
    */

    $adults = (int)(
        $_POST['adults']
        ?? 1
    );

    $children = (int)(
        $_POST['children']
        ?? 0
    );

    if (
        $adults < 1
        || $adults > 20
    ) {

        $errors[] =
            'Please select between 1 and 20 adults.';
    }

    if (
        $children < 0
        || $children > 20
    ) {

        $errors[] =
            'Please select a valid number of children.';
    }


    /*
    |--------------------------------------------------------------------------
    | CHILD AGES + ADMIN CHILD PRICING
    |--------------------------------------------------------------------------
    */

    $postedChildAges =
        is_array($_POST['child_ages'] ?? null)
            ? $_POST['child_ages']
            : [];

    $postedChildBedTypes =
        is_array($_POST['child_bed_types'] ?? null)
            ? $_POST['child_bed_types']
            : [];

    $childAges = [];
    $childBedTypes = [];

    foreach ($postedChildAges as $age) {
        $age = trim((string)$age);

        if ($age !== '' && ctype_digit($age)) {
            $childAges[] =
                max(
                    0,
                    min(17, (int)$age)
                );
        }
    }

    foreach ($postedChildBedTypes as $type) {
        $type = strtolower(trim((string)$type));

        $childBedTypes[] =
            in_array($type, ['with_bed','without_bed','infant','legacy'], true)
                ? $type
                : 'with_bed';
    }

    if ($children > 0) {
        if (count($childAges) !== $children) {
            $errors[] =
                'Please select the age of every child.';
        } else {
            while (count($childBedTypes) < $children) {
                $childBedTypes[] = 'with_bed';
            }

            $childBedTypes =
                array_slice(
                    $childBedTypes,
                    0,
                    $children
                );

            foreach ($childAges as $index => $childAge) {
                $bedType =
                    (string)($childBedTypes[$index] ?? 'with_bed');

                $matchedChildPrice =
                    bookingSmartChildPrice(
                        $packageChildPrices,
                        $currentOccupancyPriceRow,
                        $childAge,
                        $bedType
                    );

                if ($matchedChildPrice === null) {
                    $errors[] =
                        'No child fare is configured for Child '
                        . ($index + 1)
                        . ' age '
                        . $childAge
                        . '.';
                }
            }
        }
    } else {
        $childAges = [];
        $childBedTypes = [];
    }


    /*
    |--------------------------------------------------------------------------
    | SPECIAL REQUEST
    |--------------------------------------------------------------------------
    */

    if (
        mb_strlen($specialRequest) > 2000
    ) {

        $errors[] =
            'Special request must be below 2000 characters.';
    }


    /*
    |--------------------------------------------------------------------------
    | RECALCULATE TOTAL ON SERVER
    |--------------------------------------------------------------------------
    */

    $adultSubtotal =
        round(
            $adultPrice * $adults,
            2
        );

    $childSubtotal =
        bookingSmartChildPriceTotal(
            $packageChildPrices,
            $currentOccupancyPriceRow,
            $childAges,
            $childBedTypes
        );

    $childPricingBreakdown =
        bookingSmartChildBreakdown(
            $packageChildPrices,
            $currentOccupancyPriceRow,
            $childAges,
            $childBedTypes
        );

    $subtotal =
        round(
            $adultSubtotal + $childSubtotal,
            2
        );

    $totalAmount = $subtotal;
    $discountAmount = 0.00;
    $couponId = null;
    $couponCodeForBooking = null;


    /*
    |--------------------------------------------------------------------------
    | CREATE BOOKING
    |--------------------------------------------------------------------------
    */

    if (!$errors) {

        try {

            $pdo->beginTransaction();


            /*
            |--------------------------------------------------------------------------
            | REVALIDATE COUPON INSIDE TRANSACTION
            |--------------------------------------------------------------------------
            */

            if ($couponCode !== '') {

                $couponResult =
                    validateBookingCoupon(
                        $pdo,
                        $couponCode,
                        $subtotal,
                        true
                    );

                if (!$couponResult['valid']) {
                    throw new RuntimeException(
                        $couponResult['message']
                    );
                }

                $appliedCoupon =
                    $couponResult['coupon'];

                $discountAmount =
                    (float)$couponResult['discount'];

                $totalAmount =
                    max(
                        0,
                        round(
                            $subtotal - $discountAmount,
                            2
                        )
                    );

                $couponId =
                    (int)$appliedCoupon['id'];

                $couponCodeForBooking =
                    (string)$appliedCoupon['code'];
            }


            /*
            |--------------------------------------------------------------------------
            | GENERATE UNIQUE BOOKING NUMBER
            |--------------------------------------------------------------------------
            */

            do {

                $bookingNumber =
                    'TS'
                    . date('ymd')
                    . strtoupper(
                        bin2hex(
                            random_bytes(3)
                        )
                    );

                $check = $pdo->prepare("
                    SELECT id
                    FROM bookings
                    WHERE booking_number = ?
                    LIMIT 1
                ");

                $check->execute([
                    $bookingNumber
                ]);

                $exists =
                    $check->fetchColumn();

            } while ($exists);


            /*
            |--------------------------------------------------------------------------
            | INSERT BOOKING
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare("
                INSERT INTO bookings
                (
                    booking_number,
                    user_id,
                    package_id,
                    hotel_category,
                    hotel_price,
                    occupancy_type,
                    occupancy_price,
                    child_pricing_json,
                    coupon_id,
                    coupon_code,
                    customer_name,
                    customer_email,
                    customer_mobile,
                    travel_date,
                    adults,
                    children,
                    total_amount,
                    discount_amount,
                    paid_amount,
                    currency,
                    booking_status,
                    payment_status,
                    special_request
                )
                VALUES
                (
                    :booking_number,
                    :user_id,
                    :package_id,
                    :hotel_category,
                    :hotel_price,
                    :occupancy_type,
                    :occupancy_price,
                    :child_pricing_json,
                    :coupon_id,
                    :coupon_code,
                    :customer_name,
                    :customer_email,
                    :customer_mobile,
                    :travel_date,
                    :adults,
                    :children,
                    :total_amount,
                    :discount_amount,
                    0.00,
                    :currency,
                    'pending',
                    'unpaid',
                    :special_request
                )
            ");

            $stmt->execute([

                ':booking_number' =>
                    $bookingNumber,

                ':user_id' =>
                    $userId,

                ':package_id' => $packageId,
                ':hotel_category' => $bookingHotelCategory,
                ':hotel_price' => $adultPrice,
                ':occupancy_type' => $occupancyType,
                ':occupancy_price' => $occupancyPrice,
                ':child_pricing_json' =>
                    $childPricingBreakdown
                        ? json_encode(
                            $childPricingBreakdown,
                            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                        )
                        : null,

                ':coupon_id' =>
                    $couponId,

                ':coupon_code' =>
                    $couponCodeForBooking,

                ':customer_name' =>
                    $customerName,

                ':customer_email' =>
                    $customerEmail,

                ':customer_mobile' =>
                    $customerMobile,

                ':travel_date' =>
                    $travelDate,

                ':adults' =>
                    $adults,

                ':children' =>
                    $children,

                ':total_amount' =>
                    $totalAmount,

                ':discount_amount' =>
                    $discountAmount,

                ':currency' =>
                    $package['currency']
                    ?: 'INR',

                ':special_request' =>
                    $specialRequest !== ''
                        ? $specialRequest
                        : null
            ]);


            $bookingId =
                (int)$pdo->lastInsertId();


            $pdo->commit();


            /*
            |--------------------------------------------------------------------------
            | STEP 10 - FREEZE PACKAGE SERVICES FOR DIRECT WEBSITE BOOKING
            |--------------------------------------------------------------------------
            | CRM quotation bookings are handled by crm-functions.php. Direct website
            | bookings have no CRM Trip yet, so freeze the active Package Service
            | templates directly into booking_service_snapshots and prepare mapped
            | supplier orders as DRAFT only. Never email a supplier automatically.
            */
            if (function_exists('tsPackageSnapshotDirectBookingServices')) {
                try {
                    tsPackageSnapshotDirectBookingServices($pdo, $bookingId, 0);
                    if (function_exists('tsSupplierAutoPrepareBookingOrders')) {
                        tsSupplierAutoPrepareBookingOrders($pdo, $bookingId, 0);
                    }
                } catch (Throwable $serviceAutomationError) {
                    error_log(
                        'Direct booking Package Services automation: '
                        . $serviceAutomationError->getMessage()
                    );
                }
            }


            /*
            |--------------------------------------------------------------------------
            | SAVE LAST BOOKING
            |--------------------------------------------------------------------------
            */

            $_SESSION['last_booking_id'] =
                $bookingId;


            /*
            |--------------------------------------------------------------------------
            | NEXT STEP
            |--------------------------------------------------------------------------
            |
            | We will create payment.php next.
            |--------------------------------------------------------------------------
            */

            redirect(
                BASE_URL
                . 'payment.php?booking='
                . $bookingId
            );


        } catch (Throwable $e) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log(
                'Booking creation failed: '
                . $e->getMessage()
            );

            if ($e instanceof RuntimeException) {

                $errors[] =
                    $e->getMessage();

            } else {

                $errors[] =
                    'We could not create your booking right now. Please try again.';
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| DISPLAY PRICE
|--------------------------------------------------------------------------
*/

$adultSubtotal =
    round(
        $adultPrice * $adults,
        2
    );

$childSubtotal =
    bookingChildPriceTotal(
        $packageChildPrices,
        $childAges
    );

$subtotal =
    round(
        $adultSubtotal + $childSubtotal,
        2
    );

$totalAmount = $subtotal;
$discountAmount = 0.00;
$appliedCoupon = null;

if ($couponCode !== '') {

    try {

        $couponResult =
            validateBookingCoupon(
                $pdo,
                $couponCode,
                $subtotal
            );

        if ($couponResult['valid']) {

            $appliedCoupon =
                $couponResult['coupon'];

            $discountAmount =
                (float)$couponResult['discount'];

            $totalAmount =
                max(
                    0,
                    round(
                        $subtotal - $discountAmount,
                        2
                    )
                );

            $couponMessage =
                $couponResult['message'];

            $couponMessageType =
                'success';

        } else {

            $couponMessage =
                $couponResult['message'];

            $couponMessageType =
                'error';
        }

    } catch (Throwable $e) {

        error_log(
            'Coupon display failed: '
            . $e->getMessage()
        );
    }
}

?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#07192d"
>

<title>
Book <?= e($package['title']); ?>
| <?= e($siteName); ?>
</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

:root{
    --navy:#07192d;
    --blue:#0b74ff;
    --blue-dark:#075ed0;
    --green:#079669;
    --red:#dc3e52;
    --bg:#f5f7fa;
    --white:#fff;
    --text:#182235;
    --muted:#788496;
    --border:#e2e8ef;
    --shadow:0 18px 50px rgba(7,25,45,.09);
}

*{
    box-sizing:border-box;
    margin:0;
    padding:0;
}

body{
    background:var(--bg);
    color:var(--text);
    font-family:'DM Sans',sans-serif;
}

a{
    color:inherit;
    text-decoration:none;
}

button,
input,
select,
textarea{
    font:inherit;
}


/* HEADER */

.header{
    height:74px;
    padding:0 5%;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:20px;
    background:white;
    border-bottom:1px solid var(--border);
}

.logo{
    display:flex;
    align-items:center;
    gap:10px;
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:20px;
    font-weight:800;
}

.logo-icon{
    width:40px;
    height:40px;
    display:grid;
    place-items:center;
    border-radius:12px;
    color:white;
    background:linear-gradient(135deg,#0b74ff,#00b8ff);
}

.logo span{
    color:var(--blue);
}

.secure-header{
    display:flex;
    align-items:center;
    gap:7px;
    color:#687587;
    font-size:10px;
    font-weight:600;
}

.secure-header i{
    color:var(--green);
}


/* PROGRESS */

.progress-wrap{
    background:white;
    border-bottom:1px solid var(--border);
}

.progress{
    max-width:800px;
    min-height:70px;
    margin:auto;
    padding:12px 20px;
    display:flex;
    align-items:center;
    justify-content:center;
}

.step{
    display:flex;
    align-items:center;
    gap:7px;
    color:#9aa4b1;
    font-size:9px;
    font-weight:700;
}

.step-circle{
    width:27px;
    height:27px;
    border-radius:50%;
    display:grid;
    place-items:center;
    background:#edf1f5;
    color:#8994a2;
}

.step.active{
    color:var(--blue);
}

.step.active .step-circle{
    background:var(--blue);
    color:white;
}

.step-line{
    width:65px;
    height:1px;
    margin:0 10px;
    background:#dce2e8;
}


/* PAGE */

.container{
    max-width:1180px;
    margin:auto;
    padding:35px 20px 70px;
}

.page-heading{
    margin-bottom:25px;
}

.page-heading h1{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:30px;
}

.page-heading p{
    margin-top:6px;
    color:var(--muted);
    font-size:10px;
}

.layout{
    display:grid;
    grid-template-columns:minmax(0,1fr) 360px;
    gap:25px;
}


/* CARD */

.card{
    margin-bottom:18px;
    padding:24px;
    border:1px solid var(--border);
    border-radius:15px;
    background:white;
    box-shadow:0 8px 30px rgba(7,25,45,.035);
}

.card-title{
    margin-bottom:20px;
    display:flex;
    align-items:center;
    gap:10px;
}

.card-icon{
    width:37px;
    height:37px;
    flex:0 0 37px;
    border-radius:10px;
    display:grid;
    place-items:center;
    background:#eaf4ff;
    color:var(--blue);
}

.card-title h2{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:17px;
}

.card-title p{
    margin-top:2px;
    color:var(--muted);
    font-size:8px;
}


/* FORM */

.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:15px;
}

.form-group{
    margin-bottom:15px;
}

.form-group.full{
    grid-column:1 / -1;
}

label{
    display:block;
    margin-bottom:7px;
    color:#5f6c7e;
    font-size:9px;
    font-weight:800;
}

.required{
    color:var(--red);
}

.form-control{
    width:100%;
    height:47px;
    padding:0 13px;
    border:1px solid var(--border);
    border-radius:9px;
    outline:none;
    background:white;
    color:var(--navy);
    font-size:10px;
    font-weight:600;
    transition:.2s;
}

textarea.form-control{
    height:110px;
    padding:12px 13px;
    resize:vertical;
    line-height:1.6;
}

.form-control:focus{
    border-color:#8bc0ff;
    box-shadow:0 0 0 3px rgba(11,116,255,.07);
}

.help{
    margin-top:5px;
    color:#98a1ae;
    font-size:8px;
}



/* CHILD AGE PRICING */

.checkout-child-price-guide{
    margin-bottom:10px;
    display:flex;
    flex-wrap:wrap;
    gap:7px;
}

.checkout-child-price-guide span{
    padding:7px 9px;
    border:1px solid #dbeafe;
    border-radius:8px;
    background:#eff6ff;
    color:#475569;
    font-size:9px;
    font-weight:700;
}

.checkout-child-price-guide strong{
    color:var(--blue);
}

.checkout-child-age-grid{
    display:grid;
    grid-template-columns:repeat(3,minmax(0,1fr));
    gap:9px;
}

.checkout-child-age-item label{
    margin-bottom:5px;
}

@media(max-width:700px){
    .checkout-child-age-grid{
        grid-template-columns:repeat(2,minmax(0,1fr));
    }
}

@media(max-width:420px){
    .checkout-child-age-grid{
        grid-template-columns:1fr;
    }
}


/* COUPON */

.coupon-row{
    display:flex;
    gap:9px;
}

.coupon-row .form-control{
    flex:1;
}

.coupon-btn{
    min-width:120px;
    height:47px;
    padding:0 16px;
    border:0;
    border-radius:9px;
    background:var(--navy);
    color:white;
    cursor:pointer;
    font-size:9px;
    font-weight:800;
}

.coupon-message{
    margin-top:9px;
    padding:10px 12px;
    border-radius:8px;
    font-size:8px;
    font-weight:700;
    line-height:1.5;
}

.coupon-message.success{
    background:#eafaf3;
    color:#087b56;
}

.coupon-message.error{
    background:#fff0f2;
    color:#aa2d3e;
}

.discount-row,
.discount-row strong{
    color:var(--green);
}


/* ERROR */

.error-box{
    margin-bottom:20px;
    padding:14px;
    border:1px solid #f0bec5;
    border-radius:10px;
    background:#fff0f2;
    color:#a92d3e;
    font-size:9px;
    line-height:1.7;
}

.error-box strong{
    display:block;
    margin-bottom:5px;
}

.error-box ul{
    padding-left:17px;
}


/* SUMMARY */

.summary{
    position:sticky;
    top:20px;
    overflow:hidden;
    border:1px solid var(--border);
    border-radius:16px;
    background:white;
    box-shadow:var(--shadow);
}

.package-image{
    height:190px;
    position:relative;
    overflow:hidden;
}

.package-image img{
    width:100%;
    height:100%;
    object-fit:cover;
}

.package-badge{
    position:absolute;
    top:12px;
    left:12px;
    padding:6px 9px;
    border-radius:50px;
    background:rgba(255,255,255,.94);
    color:var(--blue);
    font-size:7px;
    font-weight:800;
}

.summary-body{
    padding:20px;
}

.summary-body h2{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:17px;
    line-height:1.4;
}

.destination{
    margin-top:7px;
    color:#7b8797;
    font-size:9px;
}

.destination i{
    color:var(--blue);
}

.trip-meta{
    margin-top:15px;
    display:flex;
    gap:8px;
}

.meta-item{
    flex:1;
    padding:10px;
    border-radius:8px;
    background:#f6f8fb;
}

.meta-item small{
    display:block;
    color:#929ca9;
    font-size:7px;
}

.meta-item strong{
    display:block;
    margin-top:3px;
    color:var(--navy);
    font-size:9px;
}


/* PRICE */

.price-box{
    margin-top:17px;
    padding-top:16px;
    border-top:1px solid var(--border);
}

.price-row{
    padding:5px 0;
    display:flex;
    justify-content:space-between;
    gap:10px;
    color:#718093;
    font-size:9px;
}

.price-row strong{
    color:var(--navy);
}

.child-note{
    margin-top:7px;
    padding:8px;
    border-radius:7px;
    background:#fff8e8;
    color:#8d6818;
    font-size:7px;
    line-height:1.5;
}

.total-row{
    margin-top:10px;
    padding-top:13px;
    border-top:1px solid var(--border);
    display:flex;
    align-items:center;
    justify-content:space-between;
}

.total-row span{
    color:var(--navy);
    font-size:10px;
    font-weight:800;
}

.total-price{
    color:var(--blue);
    font-family:'Manrope',sans-serif;
    font-size:22px;
    font-weight:800;
}


/* BUTTON */

.submit-btn{
    width:100%;
    min-height:52px;
    margin-top:20px;
    border:0;
    border-radius:10px;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:8px;
    background:linear-gradient(135deg,var(--blue),var(--blue-dark));
    color:white;
    cursor:pointer;
    font-size:10px;
    font-weight:800;
    box-shadow:0 10px 25px rgba(11,116,255,.2);
}

.submit-btn:hover{
    transform:translateY(-1px);
}

.security{
    margin-top:12px;
    display:flex;
    justify-content:center;
    align-items:center;
    gap:6px;
    color:#8b95a2;
    font-size:8px;
}

.security i{
    color:var(--green);
}

.back-link{
    margin-top:12px;
    display:block;
    text-align:center;
    color:var(--blue);
    font-size:8px;
    font-weight:700;
}


/* TRUST */

.trust{
    padding:0 20px 18px;
}

.trust-item{
    padding:9px 0;
    border-top:1px solid #edf0f3;
    display:flex;
    align-items:center;
    gap:9px;
    color:#6b7788;
    font-size:8px;
}

.trust-item i{
    width:26px;
    height:26px;
    border-radius:7px;
    display:grid;
    place-items:center;
    background:#ecf6ff;
    color:var(--blue);
}


/* RESPONSIVE */

@media(max-width:900px){

    .layout{
        grid-template-columns:1fr;
    }

    .summary{
        position:static;
    }
}

@media(max-width:600px){

    .header{
        height:65px;
        padding:0 15px;
    }

    .logo{
        font-size:17px;
    }

    .secure-header span{
        display:none;
    }

    .progress{
        padding:10px;
    }

    .step span{
        display:none;
    }

    .step-line{
        width:40px;
    }

    .container{
        padding:25px 13px 50px;
    }

    .page-heading h1{
        font-size:25px;
    }

    .card{
        padding:17px;
    }

    .form-grid{
        grid-template-columns:1fr;
    }

    .form-group.full{
        grid-column:auto;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>

<body>


<!-- HEADER -->

<header class="header">

<a
    href="<?= e(BASE_URL); ?>"
    class="logo"
>

    <div class="logo-icon">
        <i class="fa-solid fa-plane"></i>
    </div>

    TRAV<span>SCOPE</span>

</a>


<div class="secure-header">

    <i class="fa-solid fa-lock"></i>

    <span>
        Secure Booking
    </span>

</div>

</header>


<!-- PROGRESS -->

<div class="progress-wrap">

<div class="progress">

    <div class="step active">

        <div class="step-circle">
            1
        </div>

        <span>
            Traveller Details
        </span>

    </div>


    <div class="step-line"></div>


    <div class="step">

        <div class="step-circle">
            2
        </div>

        <span>
            Payment
        </span>

    </div>


    <div class="step-line"></div>


    <div class="step">

        <div class="step-circle">
            3
        </div>

        <span>
            Confirmation
        </span>

    </div>

</div>

</div>


<!-- PAGE -->

<main class="container">


<div class="page-heading">

    <h1>
        Complete your booking
    </h1>

    <p>
        You're just a few steps away from your next journey.
    </p>

</div>


<?php if ($errors): ?>

<div class="error-box">

    <strong>
        Please check the following:
    </strong>

    <ul>

        <?php foreach ($errors as $error): ?>

            <li>
                <?= e($error); ?>
            </li>

        <?php endforeach; ?>

    </ul>

</div>

<?php endif; ?>


<form
    method="post"
    action=""
    id="bookingForm"
>


<input
    type="hidden"
    name="csrf_token"
    value="<?= e(csrfToken()); ?>"
>

<input type="hidden" name="package_id" value="<?= $packageId; ?>">
<input type="hidden" name="hotel_category" id="hotel_category" value="<?= e($hotelCategory); ?>">


<div class="layout">


<!-- LEFT -->

<div>


    <!-- CONTACT DETAILS -->

    <section class="card">

        <div class="card-title">

            <div class="card-icon">
                <i class="fa-regular fa-user"></i>
            </div>

            <div>

                <h2>
                    Lead traveller details
                </h2>

                <p>
                    We'll send your booking information to these details.
                </p>

            </div>

        </div>


        <div class="form-grid">


            <div class="form-group full">

                <label for="customer_name">

                    FULL NAME
                    <span class="required">*</span>

                </label>

                <input
                    type="text"
                    name="customer_name"
                    id="customer_name"
                    class="form-control"
                    value="<?= e($customerName); ?>"
                    maxlength="150"
                    autocomplete="name"
                    required
                >

            </div>


            <div class="form-group">

                <label for="customer_email">

                    EMAIL ADDRESS
                    <span class="required">*</span>

                </label>

                <input
                    type="email"
                    name="customer_email"
                    id="customer_email"
                    class="form-control"
                    value="<?= e($customerEmail); ?>"
                    maxlength="190"
                    autocomplete="email"
                    required
                >

                <div class="help">
                    Booking confirmation will be sent here.
                </div>

            </div>


            <div class="form-group">

                <label for="customer_mobile">

                    MOBILE NUMBER
                    <span class="required">*</span>

                </label>

                <input
                    type="tel"
                    name="customer_mobile"
                    id="customer_mobile"
                    class="form-control"
                    value="<?= e($customerMobile); ?>"
                    maxlength="20"
                    autocomplete="tel"
                    required
                >

                <div class="help">
                    Used for important booking updates.
                </div>

            </div>


        </div>

    </section>


    <!-- TRIP DETAILS -->

    <section class="card">

        <div class="card-title">

            <div class="card-icon">
                <i class="fa-regular fa-calendar"></i>
            </div>

            <div>

                <h2>
                    Trip details
                </h2>

                <p>
                    Confirm your travel date and number of travellers.
                </p>

            </div>

        </div>


        <div class="form-grid">


            <div class="form-group full">

                <label for="travel_date">

                    TRAVEL DATE
                    <span class="required">*</span>

                </label>

                <input
                    type="date"
                    name="travel_date"
                    id="travel_date"
                    class="form-control"
                    value="<?= e($travelDate); ?>"
                    min="<?= e(
                        date(
                            'Y-m-d',
                            strtotime('+1 day')
                        )
                    ); ?>"
                    required
                >

            </div>


            <div class="form-group full">

                <label for="hotel_category_select">

                    HOTEL CATEGORY
                    <span class="required">*</span>

                </label>

                <select
                    id="hotel_category_select"
                    class="form-control"
                    required
                >
                    <option value="">Select hotel category</option>

                    <option
                        value="3"
                        <?= $hotelCategory === '3' ? 'selected' : ''; ?>
                    >
                        3 Star Hotel
                    </option>

                    <option
                        value="4"
                        <?= $hotelCategory === '4' ? 'selected' : ''; ?>
                    >
                        4 Star Hotel
                    </option>

                    <option
                        value="5"
                        <?= $hotelCategory === '5' ? 'selected' : ''; ?>
                    >
                        5 Star Hotel
                    </option>
                </select>

                <div class="help">
                    Available categories and prices change according to the selected travel date.
                </div>

            </div>


            <?php if ($packageOccupancyPrices): ?>
            <div class="form-group full">

                <label for="occupancy_type">
                    ROOM / OCCUPANCY
                    <span class="required">*</span>
                </label>

                <select
                    name="occupancy_type"
                    id="occupancy_type"
                    class="form-control"
                    required
                >
                    <option value="twin" <?= $occupancyType === 'twin' ? 'selected' : ''; ?>>
                        Twin / Double Sharing
                    </option>
                    <option value="triple" <?= $occupancyType === 'triple' ? 'selected' : ''; ?>>
                        Triple Sharing
                    </option>
                    <option value="single" <?= $occupancyType === 'single' ? 'selected' : ''; ?>>
                        Single Occupancy
                    </option>
                </select>

                <div class="help">
                    Adult price is calculated automatically for the selected occupancy.
                </div>

            </div>
            <?php else: ?>
            <input type="hidden" name="occupancy_type" id="occupancy_type" value="twin">
            <?php endif; ?>


            <div class="form-group">

                <label for="adults">

                    ADULTS
                    <span class="required">*</span>

                </label>

                <select
                    name="adults"
                    id="adults"
                    class="form-control"
                    required
                >

                    <?php for (
                        $i = 1;
                        $i <= 20;
                        $i++
                    ): ?>

                        <option
                            value="<?= $i; ?>"
                            <?= $adults === $i
                                ? 'selected'
                                : ''; ?>
                        >
                            <?= $i; ?>
                        </option>

                    <?php endfor; ?>

                </select>

            </div>


            <div class="form-group">

                <label for="children">

                    CHILDREN

                </label>

                <select
                    name="children"
                    id="children"
                    class="form-control"
                >

                    <?php for (
                        $i = 0;
                        $i <= 20;
                        $i++
                    ): ?>

                        <option
                            value="<?= $i; ?>"
                            <?= $children === $i
                                ? 'selected'
                                : ''; ?>
                        >
                            <?= $i; ?>
                        </option>

                    <?php endfor; ?>

                </select>

                <div class="help">
                    Child fare is calculated automatically from age and, when configured, With Bed / Without Bed pricing.
                </div>

            </div>


            <div
                class="form-group full"
                id="checkoutChildAgeSection"
                <?= $children <= 0
                    ? 'style="display:none;"'
                    : ''; ?>
            >
                <label>
                    CHILD AGES
                    <span class="required">*</span>
                </label>

                <?php if ($packageChildPrices): ?>
                    <div class="checkout-child-price-guide">
                        <?php foreach ($packageChildPrices as $childPriceRow): ?>
                            <span>
                                Age
                                <?= (int)($childPriceRow['age_from'] ?? 0); ?>
                                –
                                <?= (int)($childPriceRow['age_to'] ?? 0); ?>:
                                <strong>
                                    <?= e($currencySymbol); ?>
                                    <?= number_format(
                                        max(0, (float)($childPriceRow['price'] ?? 0)),
                                        0
                                    ); ?>
                                </strong>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div
                    class="checkout-child-age-grid"
                    id="checkoutChildAgeFields"
                ></div>

                <div class="help">
                    Select each child's age and fare basis. Infants are detected automatically from the configured infant age.
                </div>
            </div>


        </div>

    </section>


    <!-- COUPON -->

    <section class="card">

        <div class="card-title">

            <div class="card-icon">
                <i class="fa-solid fa-ticket"></i>
            </div>

            <div>

                <h2>
                    Coupon code
                </h2>

                <p>
                    Apply a valid promotional coupon to this booking.
                </p>

            </div>

        </div>


        <div class="form-group">

            <label for="coupon_code">
                COUPON CODE
            </label>

            <div class="coupon-row">

                <input
                    type="text"
                    name="coupon_code"
                    id="coupon_code"
                    class="form-control"
                    value="<?= e($couponCode); ?>"
                    maxlength="50"
                    placeholder="Enter coupon code"
                    autocomplete="off"
                >

                <button
                    type="submit"
                    name="apply_coupon"
                    value="1"
                    class="coupon-btn"
                    formnovalidate
                >
                    Apply Coupon
                </button>

            </div>


            <?php if ($couponMessage !== ''): ?>

                <div
                    class="coupon-message <?= e($couponMessageType); ?>"
                >

                    <i class="fa-solid <?= $couponMessageType === 'success'
                        ? 'fa-circle-check'
                        : 'fa-circle-exclamation'; ?>"></i>

                    <?= e($couponMessage); ?>

                </div>

            <?php endif; ?>

        </div>

    </section>


    <!-- SPECIAL REQUEST -->

    <section class="card">

        <div class="card-title">

            <div class="card-icon">
                <i class="fa-regular fa-message"></i>
            </div>

            <div>

                <h2>
                    Anything we should know?
                </h2>

                <p>
                    Optional requests or information for your trip.
                </p>

            </div>

        </div>


        <div class="form-group">

            <label for="special_request">
                SPECIAL REQUEST
            </label>

            <textarea
                name="special_request"
                id="special_request"
                class="form-control"
                maxlength="2000"
                placeholder="For example: hotel preference, dietary request, accessibility requirement or anything else you'd like us to know."
            ><?= e($specialRequest); ?></textarea>

        </div>

    </section>


</div>


<!-- RIGHT SUMMARY -->

<aside>


<div class="summary">


    <div class="package-image">

        <img
            src="<?= e(
                bookingImage(
                    $package['main_image']
                )
            ); ?>"
            alt="<?= e(
                $package['title']
            ); ?>"
        >

        <div class="package-badge">

            <?= e(
                ucwords(
                    str_replace(
                        '_',
                        ' ',
                        $package['package_type']
                    )
                )
            ); ?>

        </div>

    </div>


    <div class="summary-body">


        <h2>
            <?= e($package['title']); ?>
        </h2>


        <div class="destination">

            <i class="fa-solid fa-location-dot"></i>

            <?= e(
                $package['destination_name']
                ?: 'Travel Package'
            ); ?>

            <?php if (
                !empty(
                    $package['destination_country']
                )
            ): ?>

                ,
                <?= e(
                    $package['destination_country']
                ); ?>

            <?php endif; ?>

        </div>


        <div class="trip-meta">


            <div class="meta-item">

                <small>
                    DURATION
                </small>

                <strong>

                    <?= (int)$package['duration_days']; ?>
                    D /
                    <?= (int)$package['duration_nights']; ?>
                    N

                </strong>

            </div>


            <div class="meta-item">

                <small>
                    TRAVEL DATE
                </small>

                <strong id="summaryDate">

                    <?= $travelDate
                        ? e(
                            date(
                                'd M Y',
                                strtotime($travelDate)
                            )
                        )
                        : 'Select date'; ?>

                </strong>

            </div>


        </div>


        
<div style="margin-top:12px;padding:10px;border-radius:8px;background:#fff7df;color:#8a5b00;font-size:10px;font-weight:800">
    <i class="fa-solid fa-hotel"></i>
    Hotel Category:
    <span id="summaryHotelCategory">
        <?= $hotelCategory !== ''
            ? e($hotelCategory . ' Star')
            : 'Not available'; ?>
    </span>
</div>

<div style="margin-top:7px;padding:10px;border-radius:8px;background:#eef6ff;color:#24527d;font-size:10px;font-weight:800">
    <i class="fa-solid fa-bed"></i>
    Occupancy:
    <span id="summaryOccupancy">
        <?= e(
            $occupancyType === 'single'
                ? 'Single Occupancy'
                : ($occupancyType === 'triple' ? 'Triple Sharing' : 'Twin / Double Sharing')
        ); ?>
    </span>
</div>

<div class="price-box">


            <div class="price-row">

                <span id="adultDescription">

                    <?= $adults; ?>
                    Adult<?= $adults === 1 ? '' : 's'; ?>
                    ×
                    <?= e($currencySymbol); ?>
                    <?= number_format(
                        $adultPrice,
                        0
                    ); ?>

                </span>

                <strong id="adultTotal">

                    <?= e($currencySymbol); ?>

                    <?= number_format(
                        $adultPrice * $adults,
                        0
                    ); ?>

                </strong>

            </div>


            <div
                class="price-row"
                id="childrenRow"
                <?= $children <= 0
                    ? 'style="display:none;"'
                    : ''; ?>
            >

                <span id="childrenDescription">

                    <?= $children; ?>
                    Child<?= $children === 1 ? '' : 'ren'; ?>

                </span>

                <strong id="childrenTotal">
                    <?= e($currencySymbol); ?>
                    <?= number_format(
                        $childSubtotal,
                        0
                    ); ?>
                </strong>

            </div>


            <div
                class="child-note"
                id="childNote"
                <?= $children <= 0
                    ? 'style="display:none;"'
                    : ''; ?>
            >

                <i class="fa-solid fa-circle-info"></i>

                Child fare is calculated from each selected child's age and fare basis using the pricing configured by Admin.

            </div>


            <?php if ($discountAmount > 0): ?>

            <div class="price-row discount-row">

                <span>

                    Coupon Discount

                    <?php if ($appliedCoupon): ?>

                        (<?= e($appliedCoupon['code']); ?>)

                    <?php endif; ?>

                </span>

                <strong>

                    -<?= e($currencySymbol); ?>

                    <?= number_format(
                        $discountAmount,
                        0
                    ); ?>

                </strong>

            </div>

            <?php endif; ?>


            <div class="total-row">

                <span>
                    Estimated Total
                </span>

                <div
                    class="total-price"
                    id="totalPrice"
                >

                    <?= e($currencySymbol); ?>

                    <?= number_format(
                        $totalAmount,
                        0
                    ); ?>

                </div>

            </div>


            <button
                type="submit"
                class="submit-btn"
                id="submitButton"
            >

                Continue to Payment

                <i class="fa-solid fa-arrow-right"></i>

            </button>


            <div class="security">

                <i class="fa-solid fa-shield-halved"></i>

                Secure booking information

            </div>


            <a
                href="package-details.php?<?= e(http_build_query([
                    'slug' => $package['slug'],
                    'travel_date' => $travelDate,
                    'hotel_category' => $hotelCategory,
                    'occupancy_type' => $occupancyType
                ])); ?>"
                class="back-link"
            >

                <i class="fa-solid fa-arrow-left"></i>

                Back to package details

            </a>


        </div>


    </div>


    <div class="trust">


        <div class="trust-item">

            <i class="fa-solid fa-lock"></i>

            Secure checkout

        </div>


        <div class="trust-item">

            <i class="fa-solid fa-headset"></i>

            Booking assistance

        </div>


        <div class="trust-item">

            <i class="fa-regular fa-envelope"></i>

            Confirmation sent to your email

        </div>


    </div>


</div>


</aside>


</div>


</form>


</main>


<script>

/*
|--------------------------------------------------------------------------
| LIVE BOOKING SUMMARY
|--------------------------------------------------------------------------
*/

const packageDatePrices =
<?= json_encode(
    array_map(
        function ($row) {
            return [
                'valid_from' => (string)$row['valid_from'],
                'valid_to' => (string)$row['valid_to'],
                '3' => $row['price_3_star'] !== null
                    ? (float)$row['price_3_star']
                    : null,
                '4' => $row['price_4_star'] !== null
                    ? (float)$row['price_4_star']
                    : null,
                '5' => $row['price_5_star'] !== null
                    ? (float)$row['price_5_star']
                    : null
            ];
        },
        $packagePriceRows
    ),
    JSON_UNESCAPED_SLASHES
); ?>;

const packageOccupancyPrices =
<?= json_encode(
    array_map(
        static function(array $row): array {
            return [
                'valid_from' => (string)($row['valid_from'] ?? ''),
                'valid_to' => (string)($row['valid_to'] ?? ''),
                'star' => (string)($row['star_category'] ?? ''),
                'twin_price' => $row['twin_price'] !== null ? (float)$row['twin_price'] : null,
                'triple_price' => $row['triple_price'] !== null ? (float)$row['triple_price'] : null,
                'single_price' => $row['single_price'] !== null ? (float)$row['single_price'] : null,
                'child_with_bed_price' => $row['child_with_bed_price'] !== null ? (float)$row['child_with_bed_price'] : null,
                'child_without_bed_price' => $row['child_without_bed_price'] !== null ? (float)$row['child_without_bed_price'] : null,
                'infant_price' => $row['infant_price'] !== null ? (float)$row['infant_price'] : null,
                'infant_age_to' => max(0, (int)($row['infant_age_to'] ?? 2)),
            ];
        },
        $packageOccupancyPrices
    ),
    JSON_UNESCAPED_SLASHES
); ?>;



const packageChildPrices =
<?= json_encode(
    array_map(
        static function (array $row): array {
            return [
                'age_from' => max(0, (int)($row['age_from'] ?? 0)),
                'age_to' => max(0, (int)($row['age_to'] ?? 0)),
                'price' => max(0, (float)($row['price'] ?? 0))
            ];
        },
        $packageChildPrices
    ),
    JSON_UNESCAPED_SLASHES
); ?>;

const initialChildAges =
<?= json_encode(
    array_values($childAges),
    JSON_UNESCAPED_SLASHES
); ?>;

const initialChildBedTypes =
<?= json_encode(
    array_values($childBedTypes),
    JSON_UNESCAPED_SLASHES
); ?>;

function checkoutChildPriceForAge(age) {
    const numericAge = Number(age);

    const row =
        packageChildPrices.find(function(item) {
            return numericAge >= Number(item.age_from)
                && numericAge <= Number(item.age_to);
        });

    return row
        ? Number(row.price || 0)
        : 0;
}


function checkoutOccupancyRowFor(dateValue, star) {
    if (!dateValue || !star) return null;

    return packageOccupancyPrices.find(function(row) {
        return String(row.star) === String(star)
            && dateValue >= row.valid_from
            && dateValue <= row.valid_to;
    }) || null;
}

function checkoutOccupancyType() {
    const value =
        String(
            document.getElementById('occupancy_type')?.value
            || 'twin'
        );

    return ['twin','triple','single'].includes(value)
        ? value
        : 'twin';
}

function checkoutOccupancyAdultPrice(row, type) {
    if (!row) return 0;

    const field = {
        twin:'twin_price',
        triple:'triple_price',
        single:'single_price'
    }[type] || 'twin_price';

    return row[field] === null || row[field] === undefined
        ? 0
        : Number(row[field] || 0);
}

function checkoutSmartChildPrice(age, bedType, row) {
    const numericAge = Number(age);

    if (row) {
        const infantAgeTo =
            Number(row.infant_age_to ?? 2);

        if (
            numericAge <= infantAgeTo
            && row.infant_price !== null
            && row.infant_price !== undefined
        ) {
            return Number(row.infant_price || 0);
        }

        if (
            bedType === 'with_bed'
            && row.child_with_bed_price !== null
            && row.child_with_bed_price !== undefined
        ) {
            return Number(row.child_with_bed_price || 0);
        }

        if (
            bedType === 'without_bed'
            && row.child_without_bed_price !== null
            && row.child_without_bed_price !== undefined
        ) {
            return Number(row.child_without_bed_price || 0);
        }
    }

    return checkoutChildPriceForAge(numericAge);
}

const legacyAdultPrice =
    <?= json_encode((float)$adultPrice); ?>;

let adultPrice =
    legacyAdultPrice;

const currencySymbol =
    <?= json_encode($currencySymbol); ?>;

/*
|--------------------------------------------------------------------------
| SERVER-VALIDATED COUPON PREVIEW
|--------------------------------------------------------------------------
|
| These values come from PHP after Apply Coupon is clicked. This keeps the
| visible Estimated Total consistent with the server-side coupon calculation.
|--------------------------------------------------------------------------
*/

const appliedCouponDiscount =
    <?= json_encode((float)$discountAmount); ?>;

const appliedCouponSubtotal =
    <?= json_encode((float)$subtotal); ?>;

const hasAppliedCoupon =
    <?= $discountAmount > 0 ? 'true' : 'false'; ?>;


const adults =
    document.getElementById(
        'adults'
    );

const children =
    document.getElementById(
        'children'
    );


const checkoutChildAgeSection =
    document.getElementById(
        'checkoutChildAgeSection'
    );

const checkoutChildAgeFields =
    document.getElementById(
        'checkoutChildAgeFields'
    );

const childrenTotal =
    document.getElementById(
        'childrenTotal'
    );

const travelDate =
    document.getElementById(
        'travel_date'
    );

const hotelCategorySelect =
    document.getElementById(
        'hotel_category_select'
    );

const hotelCategoryHidden =
    document.getElementById(
        'hotel_category'
    );

const occupancyTypeSelect =
    document.getElementById(
        'occupancy_type'
    );

const summaryOccupancy =
    document.getElementById(
        'summaryOccupancy'
    );

const summaryHotelCategory =
    document.getElementById(
        'summaryHotelCategory'
    );


const adultDescription =
    document.getElementById(
        'adultDescription'
    );

const adultTotal =
    document.getElementById(
        'adultTotal'
    );

const childrenRow =
    document.getElementById(
        'childrenRow'
    );

const childrenDescription =
    document.getElementById(
        'childrenDescription'
    );

const childNote =
    document.getElementById(
        'childNote'
    );

const totalPrice =
    document.getElementById(
        'totalPrice'
    );

const summaryDate =
    document.getElementById(
        'summaryDate'
    );


function money(amount) {

    return currencySymbol
        +
        Number(amount).toLocaleString(
            'en-IN',
            {
                maximumFractionDigits:0
            }
        );
}



function priceRowForDate(dateValue) {
    return packageDatePrices.find(function (row) {
        return dateValue >= row.valid_from
            && dateValue <= row.valid_to;
    }) || null;
}


function availableCheckoutAdultPrice(row, dateValue, star) {
    const smartRow =
        checkoutOccupancyRowFor(
            dateValue,
            star
        );

    const smartPrice =
        checkoutOccupancyAdultPrice(
            smartRow,
            checkoutOccupancyType()
        );

    if (smartRow) {
        return smartPrice;
    }

    return row
        ? Number(row[star] || 0)
        : 0;
}

function firstAvailableCategory(row, dateValue) {
    for (const star of ['3', '4', '5']) {
        if (
            availableCheckoutAdultPrice(
                row,
                dateValue,
                star
            ) > 0
        ) {
            return star;
        }
    }

    return '';
}


let activeCheckoutOccupancyRow = null;

function refreshHotelPricing() {
    const dateValue =
        travelDate?.value || '';

    const row =
        dateValue
            ? priceRowForDate(dateValue)
            : null;

    let selectedCategory =
        hotelCategorySelect?.value || '';

    if (
        !selectedCategory
        || availableCheckoutAdultPrice(
            row,
            dateValue,
            selectedCategory
        ) <= 0
    ) {
        selectedCategory =
            firstAvailableCategory(
                row,
                dateValue
            );
    }

    ['3', '4', '5'].forEach(function (star) {
        const option =
            hotelCategorySelect?.querySelector(
                'option[value="' + star + '"]'
            );

        if (!option) {
            return;
        }

        const price =
            availableCheckoutAdultPrice(
                row,
                dateValue,
                star
            );

        option.disabled =
            price <= 0;

        option.textContent =
            price > 0
                ? star + ' Star Hotel — ' + money(price)
                : star + ' Star Hotel — Unavailable';
    });

    if (hotelCategorySelect) {
        hotelCategorySelect.value =
            selectedCategory;
    }

    if (hotelCategoryHidden) {
        hotelCategoryHidden.value =
            selectedCategory;
    }

    if (summaryHotelCategory) {
        summaryHotelCategory.textContent =
            selectedCategory
                ? selectedCategory + ' Star'
                : 'Not available';
    }

    activeCheckoutOccupancyRow =
        selectedCategory && dateValue
            ? checkoutOccupancyRowFor(
                dateValue,
                selectedCategory
            )
            : null;

    const smartAdult =
        checkoutOccupancyAdultPrice(
            activeCheckoutOccupancyRow,
            checkoutOccupancyType()
        );

    const legacyAdult =
        row
        && selectedCategory
            ? Number(row[selectedCategory] || 0)
            : 0;

    if (activeCheckoutOccupancyRow) {
        adultPrice = smartAdult;
    } else if (legacyAdult > 0) {
        adultPrice = legacyAdult;
    } else if (!packageDatePrices.length && !packageOccupancyPrices.length) {
        adultPrice = legacyAdultPrice;
    } else {
        adultPrice = 0;
    }

    if (summaryOccupancy) {
        summaryOccupancy.textContent =
            checkoutOccupancyType() === 'single'
                ? 'Single Occupancy'
                : (
                    checkoutOccupancyType() === 'triple'
                        ? 'Triple Sharing'
                        : 'Twin / Double Sharing'
                );
    }

    updateSummary();
}



function renderCheckoutChildAgeFields() {
    const childCount =
        parseInt(
            children?.value || 0,
            10
        );

    const section =
        document.getElementById(
            'checkoutChildAgeSection'
        );

    const fields =
        document.getElementById(
            'checkoutChildAgeFields'
        );

    if (!section || !fields) {
        return;
    }

    if (childCount <= 0) {
        section.style.display = 'none';
        fields.innerHTML = '';
        return;
    }

    section.style.display = 'block';

    const previousAges =
        Array.from(
            fields.querySelectorAll(
                'select[name="child_ages[]"]'
            )
        ).map(function(select) {
            return String(select.value || '');
        });

    const previousBeds =
        Array.from(
            fields.querySelectorAll(
                'select[name="child_bed_types[]"]'
            )
        ).map(function(select) {
            return String(select.value || '');
        });

    fields.innerHTML = '';

    let minimumAge = 0;
    let maximumAge = 17;

    if (!packageOccupancyPrices.length && packageChildPrices.length) {
        minimumAge =
            Math.min(
                ...packageChildPrices.map(
                    row => Number(row.age_from)
                )
            );

        maximumAge =
            Math.max(
                ...packageChildPrices.map(
                    row => Number(row.age_to)
                )
            );
    }

    for (let index = 0; index < childCount; index++) {
        const item =
            document.createElement('div');

        item.className =
            'checkout-child-age-item';

        item.style.display = 'grid';
        item.style.gridTemplateColumns = '1fr 1fr';
        item.style.gap = '8px';

        const ageWrap =
            document.createElement('div');

        const label =
            document.createElement('label');

        label.textContent =
            'Child '
            + (index + 1)
            + ' Age';

        const select =
            document.createElement('select');

        select.name = 'child_ages[]';
        select.className = 'form-control';
        select.required = true;

        for (let age = minimumAge; age <= maximumAge; age++) {
            const option =
                document.createElement('option');

            option.value = String(age);
            option.textContent =
                age
                + (age === 1 ? ' year' : ' years');

            select.appendChild(option);
        }

        const savedAge =
            previousAges[index]
            ?? initialChildAges[index]
            ?? '';

        if (savedAge !== '') {
            select.value = String(savedAge);
        }

        const bedWrap =
            document.createElement('div');

        const bedLabel =
            document.createElement('label');

        bedLabel.textContent = 'Fare Basis';

        const bedSelect =
            document.createElement('select');

        bedSelect.name = 'child_bed_types[]';
        bedSelect.className = 'form-control';
        bedSelect.required = true;

        function rebuildBedOptions() {
            const age =
                Number(select.value || 0);

            const savedBed =
                previousBeds[index]
                ?? initialChildBedTypes[index]
                ?? bedSelect.value
                ?? 'with_bed';

            bedSelect.innerHTML = '';

            if (activeCheckoutOccupancyRow) {
                const infantAgeTo =
                    Number(
                        activeCheckoutOccupancyRow.infant_age_to
                        ?? 2
                    );

                if (age <= infantAgeTo) {
                    const infant =
                        document.createElement('option');

                    infant.value = 'infant';
                    infant.textContent =
                        'Infant'
                        + (
                            activeCheckoutOccupancyRow.infant_price !== null
                            && activeCheckoutOccupancyRow.infant_price !== undefined
                                ? ' — ' + money(activeCheckoutOccupancyRow.infant_price)
                                : ''
                        );

                    bedSelect.appendChild(infant);
                    bedSelect.value = 'infant';
                    return;
                }

                [
                    ['with_bed','With Bed','child_with_bed_price'],
                    ['without_bed','Without Bed','child_without_bed_price']
                ].forEach(function(entry) {
                    const option =
                        document.createElement('option');

                    option.value = entry[0];

                    const configured =
                        activeCheckoutOccupancyRow[entry[2]] !== null
                        && activeCheckoutOccupancyRow[entry[2]] !== undefined;

                    option.textContent =
                        entry[1]
                        + (
                            configured
                                ? ' — ' + money(activeCheckoutOccupancyRow[entry[2]])
                                : ' — age fare'
                        );

                    bedSelect.appendChild(option);
                });

                if (
                    ['with_bed','without_bed'].includes(savedBed)
                ) {
                    bedSelect.value = savedBed;
                }

            } else {
                const legacy =
                    document.createElement('option');

                legacy.value = 'legacy';
                legacy.textContent = 'Age-based fare';
                bedSelect.appendChild(legacy);
            }
        }

        select.addEventListener(
            'change',
            function() {
                rebuildBedOptions();
                updateSummary();
            }
        );

        bedSelect.addEventListener(
            'change',
            updateSummary
        );

        ageWrap.appendChild(label);
        ageWrap.appendChild(select);

        bedWrap.appendChild(bedLabel);
        bedWrap.appendChild(bedSelect);

        item.appendChild(ageWrap);
        item.appendChild(bedWrap);

        fields.appendChild(item);

        rebuildBedOptions();
    }
}

function updateSummary() {
    const adultCount =
        parseInt(
            adults.value || 1,
            10
        );

    const childCount =
        parseInt(
            children.value || 0,
            10
        );

    renderCheckoutChildAgeFields();

    const childAgeSelects =
        Array.from(
            document.querySelectorAll(
                'select[name="child_ages[]"]'
            )
        );

    const childBedSelects =
        Array.from(
            document.querySelectorAll(
                'select[name="child_bed_types[]"]'
            )
        );

    const liveChildTotal =
        childAgeSelects.reduce(
            function(total, select, index) {
                return total
                    + checkoutSmartChildPrice(
                        select.value,
                        childBedSelects[index]?.value || 'legacy',
                        activeCheckoutOccupancyRow
                    );
            },
            0
        );

    const adultDescription =
        document.getElementById(
            'adultDescription'
        );

    const adultTotal =
        document.getElementById(
            'adultTotal'
        );

    const childrenRow =
        document.getElementById(
            'childrenRow'
        );

    const childrenDescription =
        document.getElementById(
            'childrenDescription'
        );

    const childrenTotalBox =
        document.getElementById(
            'childrenTotal'
        );

    const childNote =
        document.getElementById(
            'childNote'
        );

    const totalPrice =
        document.getElementById(
            'totalPrice'
        );

    adultDescription.textContent =
        adultCount
        + (adultCount === 1 ? ' Adult × ' : ' Adults × ')
        + money(adultPrice);

    adultTotal.textContent =
        money(
            adultPrice * adultCount
        );

    if (childCount > 0) {
        childrenRow.style.display = 'flex';
        childNote.style.display = 'block';

        childrenDescription.textContent =
            childCount
            + (
                childCount === 1
                    ? ' Child'
                    : ' Children'
            );

        if (childrenTotalBox) {
            childrenTotalBox.textContent =
                money(liveChildTotal);
        }
    } else {
        childrenRow.style.display = 'none';
        childNote.style.display = 'none';
    }

    const liveSubtotal =
        (adultPrice * adultCount)
        + liveChildTotal;

    let finalAmount =
        liveSubtotal;

    /*
    | Reuse a coupon discount only while the live adult + child subtotal
    | is still the same subtotal that PHP validated.
    */
    if (
        hasAppliedCoupon
        && Math.abs(
            liveSubtotal
            - appliedCouponSubtotal
        ) < 0.01
    ) {
        finalAmount =
            Math.max(
                0,
                liveSubtotal
                - appliedCouponDiscount
            );
    }

    totalPrice.textContent =
        money(finalAmount);
}


function updateDate() {

    if (!travelDate.value) {

        summaryDate.textContent =
            'Select date';

        return;
    }

    const parts =
        travelDate.value.split('-');

    const date =
        new Date(
            Number(parts[0]),
            Number(parts[1]) - 1,
            Number(parts[2])
        );

    summaryDate.textContent =
        date.toLocaleDateString(
            'en-IN',
            {
                day:'2-digit',
                month:'short',
                year:'numeric'
            }
        );
}


adults.addEventListener(
    'change',
    updateSummary
);

children.addEventListener(
    'change',
    updateSummary
);

travelDate.addEventListener(
    'change',
    function () {
        updateDate();
        refreshHotelPricing();
    }
);

hotelCategorySelect?.addEventListener(
    'change',
    refreshHotelPricing
);

occupancyTypeSelect?.addEventListener(
    'change',
    refreshHotelPricing
);


renderCheckoutChildAgeFields();
refreshHotelPricing();
updateDate();


/*
|--------------------------------------------------------------------------
| COUPON INPUT
|--------------------------------------------------------------------------
*/

const couponInput =
    document.getElementById(
        'coupon_code'
    );

if (couponInput) {

    couponInput.addEventListener(
        'input',
        function() {

            this.value =
                this.value
                .toUpperCase()
                .replace(
                    /[^A-Z0-9_-]/g,
                    ''
                );
        }
    );
}


/*
|--------------------------------------------------------------------------
| PREVENT DOUBLE SUBMIT
|--------------------------------------------------------------------------
*/

document
.getElementById(
    'bookingForm'
)
.addEventListener(
    'submit',
    function(event) {

        const submitter =
            event.submitter;

        if (
            submitter
            &&
            submitter.name === 'apply_coupon'
        ) {
            return;
        }

        const button =
            document.getElementById(
                'submitButton'
            );

        if (button.disabled) {
            event.preventDefault();
            return;
        }

        if (Number(adultPrice || 0) <= 0) {
            event.preventDefault();

            alert(
                'No package price is available for the selected date and hotel category.'
            );

            return;
        }

        const selectedChildren =
            parseInt(
                children?.value || 0,
                10
            );

        const childAgeInputs =
            document.querySelectorAll(
                'select[name="child_ages[]"]'
            );

        if (
            selectedChildren > 0
            && childAgeInputs.length !== selectedChildren
        ) {
            event.preventDefault();

            alert(
                'Please select the age of every child.'
            );

            return;
        }

        if (selectedChildren > 0 && packageOccupancyPrices.length) {
            const childBedInputs =
                document.querySelectorAll(
                    'select[name="child_bed_types[]"]'
                );

            if (childBedInputs.length !== selectedChildren) {
                event.preventDefault();

                alert(
                    'Please select the fare basis for every child.'
                );

                return;
            }
        }

        button.disabled = true;

        button.innerHTML =
            '<i class="fa-solid fa-spinner fa-spin"></i> Creating Booking...';

    }
);

</script>



<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>