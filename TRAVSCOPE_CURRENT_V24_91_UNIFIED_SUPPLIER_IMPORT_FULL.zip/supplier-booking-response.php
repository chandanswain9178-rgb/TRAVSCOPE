<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/supplier-functions.php';

$token =
    trim(
        (string)(
            $_GET['token']
            ?? $_POST['token']
            ?? ''
        )
    );

if ($token === '' || strlen($token) < 40) {
    http_response_code(404);
    exit('Invalid supplier booking confirmation link.');
}

if (!tsSupplierBookingProcurementReady($pdo)) {
    http_response_code(503);
    exit('Supplier booking confirmation module is not installed.');
}

$hash = hash('sha256', $token);

$stmt = $pdo->prepare("
    SELECT
        tk.id AS token_id,
        tk.supplier_booking_order_id,
        o.*,
        b.booking_number,
        b.currency,
        t.trip_code,
        s.company_name,
        c.contact_name
    FROM supplier_booking_order_tokens tk
    JOIN supplier_booking_orders o
        ON o.id = tk.supplier_booking_order_id
    JOIN bookings b
        ON b.id = o.booking_id
    JOIN trips t
        ON t.id = o.trip_id
    JOIN suppliers s
        ON s.id = o.supplier_id
    LEFT JOIN supplier_contacts c
        ON c.id = o.supplier_contact_id
    WHERE tk.token_hash = ?
      AND tk.revoked_at IS NULL
      AND (
            tk.expires_at IS NULL
            OR tk.expires_at > NOW()
      )
    LIMIT 1
");
$stmt->execute([$hash]);
$order =
    $stmt->fetch(PDO::FETCH_ASSOC)
    ?: null;

if (!$order) {
    http_response_code(404);
    exit('This supplier booking confirmation link is invalid or expired.');
}

$orderId =
    (int)$order['supplier_booking_order_id'];

$pdo->prepare("
    UPDATE supplier_booking_order_tokens
    SET last_used_at = NOW()
    WHERE id = ?
")->execute([
    (int)$order['token_id']
]);

if (empty($_SESSION['supplier_booking_portal_csrf'])) {
    $_SESSION['supplier_booking_portal_csrf'] =
        bin2hex(random_bytes(32));
}

$csrf =
    (string)$_SESSION['supplier_booking_portal_csrf'];

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $postedCsrf =
            (string)(
                $_POST['csrf']
                ?? ''
            );

        if (
            $postedCsrf === ''
            || !hash_equals(
                $csrf,
                $postedCsrf
            )
        ) {
            throw new RuntimeException(
                'Security verification failed. Refresh and try again.'
            );
        }

        $action =
            (string)(
                $_POST['action']
                ?? ''
            );

        if ($action === 'message') {
            $message =
                trim(
                    (string)(
                        $_POST['message']
                        ?? ''
                    )
                );

            if ($message === '') {
                throw new RuntimeException(
                    'Write a message first.'
                );
            }

            $upload =
                tsSupplierBookingUpload(
                    $_FILES['attachment']
                    ?? []
                );

            tsSupplierBookingMessage(
                $pdo,
                $orderId,
                'supplier',
                null,
                $message,
                'portal',
                $upload['path'],
                $upload['name']
            );

            $pdo->prepare("
                UPDATE supplier_booking_orders
                SET
                    first_response_at = COALESCE(first_response_at, NOW()),
                    last_response_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ")->execute([$orderId]);

            $success =
                'Message sent to TRAVSCOPE.';
        }

        if ($action === 'confirm_services') {
            $statuses =
                (array)(
                    $_POST['item_status']
                    ?? []
                );

            $references =
                (array)(
                    $_POST['item_reference']
                    ?? []
                );

            $notes =
                (array)(
                    $_POST['item_note']
                    ?? []
                );

            $allowed = [
                'confirmed',
                'alternative_required',
                'rejected'
            ];

            $stmt = $pdo->prepare("
                SELECT *
                FROM supplier_booking_order_items
                WHERE supplier_booking_order_id = ?
                ORDER BY sort_order ASC, id ASC
            ");
            $stmt->execute([$orderId]);
            $items =
                $stmt->fetchAll(PDO::FETCH_ASSOC)
                ?: [];

            if (!$items) {
                throw new RuntimeException(
                    'No Booking services are attached to this supplier order.'
                );
            }

            $pdo->beginTransaction();

            $update = $pdo->prepare("
                UPDATE supplier_booking_order_items
                SET
                    status = ?,
                    supplier_confirmation_ref = ?,
                    supplier_note = ?,
                    updated_at = NOW()
                WHERE id = ?
                  AND supplier_booking_order_id = ?
            ");

            foreach ($items as $item) {
                $itemId =
                    (int)$item['id'];

                $status =
                    strtolower(
                        trim(
                            (string)(
                                $statuses[$itemId]
                                ?? ''
                            )
                        )
                    );

                if (!in_array($status, $allowed, true)) {
                    $status =
                        (string)$item['status'];
                }

                $reference =
                    trim(
                        (string)(
                            $references[$itemId]
                            ?? ''
                        )
                    );

                $note =
                    trim(
                        (string)(
                            $notes[$itemId]
                            ?? ''
                        )
                    );

                $update->execute([
                    $status,
                    $reference !== ''
                        ? $reference
                        : null,
                    $note !== ''
                        ? $note
                        : null,
                    $itemId,
                    $orderId
                ]);
            }

            $orderReference =
                trim(
                    (string)(
                        $_POST['order_confirmation_ref']
                        ?? ''
                    )
                );

            $orderNote =
                trim(
                    (string)(
                        $_POST['order_confirmation_note']
                        ?? ''
                    )
                );

            $attachment =
                tsSupplierBookingUpload(
                    $_FILES['confirmation_attachment']
                    ?? []
                );

            $pdo->prepare("
                UPDATE supplier_booking_orders
                SET
                    supplier_confirmation_ref = ?,
                    supplier_confirmation_note = ?,
                    first_response_at = COALESCE(first_response_at, NOW()),
                    last_response_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ")->execute([
                $orderReference !== ''
                    ? $orderReference
                    : null,
                $orderNote !== ''
                    ? $orderNote
                    : null,
                $orderId
            ]);

            tsSupplierBookingSyncServiceStatuses(
                $pdo,
                $orderId
            );

            $newStatus =
                tsSupplierBookingRefreshOrderStatus(
                    $pdo,
                    $orderId
                );

            $summary =
                'Supplier service confirmation submitted: '
                . ucwords(
                    str_replace(
                        '_',
                        ' ',
                        $newStatus
                    )
                );

            if ($orderReference !== '') {
                $summary .=
                    ' · Ref '
                    . $orderReference;
            }

            if ($orderNote !== '') {
                $summary .=
                    "\n"
                    . $orderNote;
            }

            tsSupplierBookingMessage(
                $pdo,
                $orderId,
                'supplier',
                null,
                $summary,
                'portal',
                $attachment['path'],
                $attachment['name']
            );

            $pdo->commit();

            $success =
                'Thank you. Your Booking service confirmation has been sent to TRAVSCOPE.';
        }

        if ($action === 'submit_invoice') {
            if (
                !tsSupplierTableExists($pdo, 'supplier_invoices')
                || !tsSupplierTableExists($pdo, 'supplier_invoice_items')
            ) {
                throw new RuntimeException(
                    'Supplier invoice module is not installed.'
                );
            }

            $invoiceNumber = trim((string)($_POST['invoice_number'] ?? ''));
            $invoiceDate = trim((string)($_POST['invoice_date'] ?? ''));
            $dueDate = trim((string)($_POST['invoice_due_date'] ?? ''));
            $netAmount = round(max(0, (float)($_POST['invoice_net_amount'] ?? 0)), 2);
            $taxAmount = round(max(0, (float)($_POST['invoice_tax_amount'] ?? 0)), 2);
            $otherAmount = round(max(0, (float)($_POST['invoice_other_amount'] ?? 0)), 2);
            $totalAmount = round($netAmount + $taxAmount + $otherAmount, 2);
            $invoiceNotes = trim((string)($_POST['invoice_notes'] ?? ''));

            if ($invoiceNumber === '') {
                throw new RuntimeException('Invoice number is required.');
            }

            if (
                $invoiceDate === ''
                || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $invoiceDate)
                || strtotime($invoiceDate) === false
            ) {
                throw new RuntimeException('Enter a valid invoice date.');
            }

            if (
                $dueDate !== ''
                && (
                    !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dueDate)
                    || strtotime($dueDate) === false
                )
            ) {
                throw new RuntimeException('Enter a valid invoice due date.');
            }

            if ($totalAmount <= 0) {
                throw new RuntimeException('Invoice total must be greater than zero.');
            }

            $stmt = $pdo->prepare("
                SELECT id
                FROM supplier_invoices
                WHERE supplier_id = ?
                  AND invoice_number = ?
                LIMIT 1
            ");
            $stmt->execute([
                (int)$order['supplier_id'],
                $invoiceNumber,
            ]);

            if ((int)$stmt->fetchColumn() > 0) {
                throw new RuntimeException(
                    'This invoice number has already been submitted.'
                );
            }

            $upload = tsSupplierBookingInvoiceUpload(
                $_FILES['invoice_attachment'] ?? []
            );

            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                INSERT INTO supplier_invoices
                (
                    booking_id, trip_id, supplier_id, supplier_booking_order_id,
                    invoice_number, invoice_date, due_date, currency,
                    net_amount, tax_amount, other_amount, total_amount,
                    status, notes, attachment_path, original_filename,
                    created_by_admin_id
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'received', ?, ?, ?, NULL)
            ");
            $stmt->execute([
                (int)$order['booking_id'],
                (int)$order['trip_id'],
                (int)$order['supplier_id'],
                $orderId,
                $invoiceNumber,
                $invoiceDate,
                $dueDate !== '' ? $dueDate : null,
                strtoupper((string)($order['currency'] ?? 'INR')),
                $netAmount,
                $taxAmount,
                $otherAmount,
                $totalAmount,
                trim(
                    "Submitted by supplier portal."
                    . ($invoiceNotes !== '' ? "\n" . $invoiceNotes : '')
                ),
                $upload['path'],
                $upload['name'],
            ]);

            $invoiceId = (int)$pdo->lastInsertId();

            if ($netAmount > 0) {
                $stmt = $pdo->prepare("
                    INSERT INTO supplier_invoice_items
                    (
                        supplier_invoice_id, booking_service_snapshot_id,
                        description, quantity, unit_cost, line_cost, sort_order
                    )
                    VALUES (?, NULL, ?, 1, ?, ?, 10)
                ");
                $stmt->execute([
                    $invoiceId,
                    'Supplier invoice ' . $invoiceNumber
                        . ' for ' . (string)$order['order_code'],
                    $netAmount,
                    $netAmount,
                ]);
            }

            tsSupplierBookingMessage(
                $pdo,
                $orderId,
                'supplier',
                null,
                'Supplier invoice submitted: '
                    . $invoiceNumber
                    . ' · '
                    . strtoupper((string)($order['currency'] ?? 'INR'))
                    . ' '
                    . number_format($totalAmount, 2)
                    . '. Awaiting TRAVSCOPE approval.',
                'portal',
                $upload['path'],
                $upload['name']
            );

            $pdo->prepare("
                UPDATE supplier_booking_orders
                SET
                    first_response_at = COALESCE(first_response_at, NOW()),
                    last_response_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ")->execute([$orderId]);

            $pdo->commit();

            $success =
                'Invoice ' . $invoiceNumber
                . ' submitted successfully. TRAVSCOPE will review it before payment.';
        }

    } catch (RuntimeException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        $error =
            $e->getMessage();

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        error_log(
            'Supplier booking response portal: '
            . $e->getMessage()
        );

        $error =
            'Unable to save your response. Please try again.';
    }
}

$stmt = $pdo->prepare("
    SELECT *
    FROM supplier_booking_order_items
    WHERE supplier_booking_order_id = ?
    ORDER BY sort_order ASC, id ASC
");
$stmt->execute([$orderId]);
$items =
    $stmt->fetchAll(PDO::FETCH_ASSOC)
    ?: [];

$stmt = $pdo->prepare("
    SELECT *
    FROM supplier_booking_order_messages
    WHERE supplier_booking_order_id = ?
    ORDER BY sent_at ASC, id ASC
");
$stmt->execute([$orderId]);
$messages =
    $stmt->fetchAll(PDO::FETCH_ASSOC)
    ?: [];

$stmt = $pdo->prepare("
    SELECT *
    FROM supplier_booking_orders
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$orderId]);
$latestOrder =
    $stmt->fetch(PDO::FETCH_ASSOC)
    ?: $order;

$supplierInvoices = [];
if (tsSupplierTableExists($pdo, 'supplier_invoices')) {
    $paymentJoin = tsSupplierTableExists($pdo, 'supplier_payments')
        ? "
            LEFT JOIN (
                SELECT supplier_invoice_id, COALESCE(SUM(amount),0) AS paid_amount
                FROM supplier_payments
                WHERE status = 'paid'
                GROUP BY supplier_invoice_id
            ) pay ON pay.supplier_invoice_id = i.id
        "
        : '';

    $paymentSelect = tsSupplierTableExists($pdo, 'supplier_payments')
        ? 'COALESCE(pay.paid_amount,0) AS paid_amount'
        : '0 AS paid_amount';

    $stmt = $pdo->prepare("
        SELECT i.*, $paymentSelect
        FROM supplier_invoices i
        $paymentJoin
        WHERE i.supplier_booking_order_id = ?
          AND i.supplier_id = ?
        ORDER BY i.created_at DESC, i.id DESC
    ");
    $stmt->execute([
        $orderId,
        (int)$order['supplier_id'],
    ]);
    $supplierInvoices = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function sbpE(?string $value): string {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function sbpDate(?string $value): string {
    if (!$value) {
        return '-';
    }

    $ts = strtotime($value);

    return
        $ts
            ? date('d M Y', $ts)
            : $value;
}

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= sbpE((string)$order['order_code']); ?> · Supplier Booking Confirmation</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}
:root{--navy:#0f172a;--blue:#2563eb;--green:#059669;--line:#e2e8f0;--muted:#64748b}
body{margin:0;background:#f6f8fc;color:#172033;font-family:Inter,Arial,sans-serif}
.shell{max-width:1280px;margin:auto;padding:14px;min-height:100vh;display:grid;grid-template-rows:auto 1fr;gap:12px}
.top{display:flex;justify-content:space-between;gap:14px;align-items:center;padding:14px 16px;border-radius:15px;background:linear-gradient(135deg,#0f172a,#1e3a8a);color:#fff}
.top h1{margin:0;font-size:17px}.top p{margin:4px 0 0;font-size:10px;color:#cbd5e1}
.badge{display:inline-flex;padding:5px 8px;border-radius:999px;background:#dcfce7;color:#166534;font-size:9px;font-weight:900}
.grid{min-height:0;display:grid;grid-template-columns:minmax(0,1fr) minmax(360px,.72fr);gap:12px}
.panel{background:#fff;border:1px solid var(--line);border-radius:15px;box-shadow:0 4px 16px rgba(15,23,42,.04);overflow:hidden}
.head{padding:12px 14px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;gap:10px;align-items:center;background:#fbfdff}
.head h2{margin:0;font-size:14px;color:var(--navy)}.body{padding:13px}
.service{padding:11px;border:1px solid #dbe3ee;border-radius:12px;background:#fbfdff;margin-bottom:9px}
.service-top{display:flex;justify-content:space-between;gap:10px}.service strong{font-size:12px}.service small{display:block;margin-top:4px;color:var(--muted);font-size:9px;line-height:1.5}
.money{font-size:12px;font-weight:900;color:#047857;white-space:nowrap}
.status-select{margin-top:9px;display:grid;grid-template-columns:160px 1fr;gap:7px}
input,select,textarea{width:100%;padding:9px;border:1px solid #cbd5e1;border-radius:9px;background:#fff;font:inherit;font-size:10px}
textarea{min-height:58px;resize:vertical}.full{grid-column:1/-1}
.btn{border:0;border-radius:9px;padding:10px 12px;font-weight:900;font-size:10px;cursor:pointer}.green{background:var(--green);color:#fff}.blue{background:var(--blue);color:#fff}
.notice{padding:10px 12px;border-radius:10px;margin-bottom:10px;font-size:11px}.success{background:#ecfdf5;color:#047857;border:1px solid #a7f3d0}.error{background:#fef2f2;color:#b91c1c;border:1px solid #fecaca}
.conversation{display:grid;grid-template-rows:auto 1fr auto;min-height:620px}
.messages{padding:13px;overflow:auto;display:flex;flex-direction:column;gap:8px;background:linear-gradient(180deg,#fbfdff,#f8fafc)}
.msg{max-width:82%;padding:9px 10px;border-radius:12px;font-size:10px;line-height:1.5}.msg.admin{align-self:flex-start;background:#eff6ff}.msg.supplier{align-self:flex-end;background:#ecfdf5}.msg small{display:block;margin-top:4px;color:var(--muted);font-size:8px}
.compose{padding:11px;border-top:1px solid var(--line);background:#fff}.compose form{display:grid;grid-template-columns:1fr auto;gap:7px}.compose textarea{min-height:56px}.compose .attach{grid-column:1/-1}
.order-note{padding:9px 10px;border-radius:10px;background:#fff7ed;color:#9a3412;font-size:10px;line-height:1.5;margin-bottom:10px}
.invoice-zone{margin-top:14px;padding-top:14px;border-top:1px solid var(--line)}
.invoice-zone h3{margin:0 0 9px;font-size:12px;color:var(--navy)}
.invoice-form{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:11px;border:1px solid #dbe3ee;border-radius:12px;background:#f8fafc}
.invoice-list{display:grid;gap:7px;margin-top:10px}.invoice-card{padding:9px 10px;border:1px solid #dbe3ee;border-radius:10px;background:#fff;font-size:9px;line-height:1.55}.invoice-card strong{font-size:10px}.invoice-status{display:inline-flex;padding:3px 6px;border-radius:999px;background:#eff6ff;color:#1d4ed8;font-weight:900;font-size:8px}.invoice-money{font-weight:900;color:#047857}
@media(max-width:900px){.grid{grid-template-columns:1fr}.conversation{min-height:600px}}
@media(max-width:560px){.shell{padding:8px}.top{align-items:flex-start;flex-direction:column}.status-select{grid-template-columns:1fr}.compose form{grid-template-columns:1fr}.btn{width:100%}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>
<body>
<div class="shell">
    <div class="top">
        <div>
            <h1>TRAVSCOPE Supplier Booking Confirmation</h1>
            <p><?= sbpE((string)$order['order_code']); ?> · Booking <?= sbpE((string)$order['booking_number']); ?> · Trip <?= sbpE((string)$order['trip_code']); ?></p>
        </div>
        <span class="badge"><?= sbpE(strtoupper(str_replace('_',' ',(string)$latestOrder['status']))); ?></span>
    </div>

    <div class="grid">
        <section class="panel">
            <div class="head">
                <h2><i class="fa-solid fa-list-check"></i> Confirm Booked Services</h2>
                <strong><?= sbpE((string)$order['company_name']); ?></strong>
            </div>

            <div class="body">
                <?php if ($success): ?><div class="notice success"><?= sbpE($success); ?></div><?php endif; ?>
                <?php if ($error): ?><div class="notice error"><?= sbpE($error); ?></div><?php endif; ?>

                <div class="order-note">
                    This is a <strong>post-booking confirmation request</strong>. Please confirm the booked services at the agreed supplier rates, or mark an item as Alternative Required / Rejected.
                </div>

                <?php if (!empty($latestOrder['request_text'])): ?>
                    <div style="margin-bottom:11px;font-size:10px;line-height:1.55;color:#475569;">
                        <?= nl2br(sbpE((string)$latestOrder['request_text'])); ?>
                    </div>
                <?php endif; ?>

                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="token" value="<?= sbpE($token); ?>">
                    <input type="hidden" name="csrf" value="<?= sbpE($csrf); ?>">
                    <input type="hidden" name="action" value="confirm_services">

                    <?php foreach ($items as $item): ?>
                        <div class="service">
                            <div class="service-top">
                                <div>
                                    <strong><?= sbpE((string)$item['title']); ?></strong>
                                    <small>
                                        <?= sbpE(ucwords(str_replace('_',' ',(string)$item['service_type']))); ?>
                                        · <?= sbpE(sbpDate($item['service_date_from'])); ?>
                                        <?php if (!empty($item['service_date_to']) && $item['service_date_to'] !== $item['service_date_from']): ?>
                                            – <?= sbpE(sbpDate($item['service_date_to'])); ?>
                                        <?php endif; ?>
                                        · Qty <?= sbpE((string)$item['quantity']); ?>
                                    </small>
                                </div>
                                <div class="money"><?= sbpE((string)$order['currency']); ?> <?= number_format((float)$item['agreed_supplier_cost'], 2); ?></div>
                            </div>

                            <?php if (!empty($item['specifications'])): ?>
                                <small style="margin-top:7px;white-space:pre-wrap;"><?= sbpE((string)$item['specifications']); ?></small>
                            <?php endif; ?>

                            <div class="status-select">
                                <select name="item_status[<?= (int)$item['id']; ?>]">
                                    <option value="confirmed" <?= $item['status']==='confirmed'?'selected':''; ?>>Confirmed</option>
                                    <option value="alternative_required" <?= $item['status']==='alternative_required'?'selected':''; ?>>Alternative Required</option>
                                    <option value="rejected" <?= $item['status']==='rejected'?'selected':''; ?>>Rejected / Unable</option>
                                </select>

                                <input
                                    name="item_reference[<?= (int)$item['id']; ?>]"
                                    value="<?= sbpE((string)($item['supplier_confirmation_ref'] ?? '')); ?>"
                                    placeholder="Confirmation / voucher / hotel ref"
                                >

                                <textarea class="full" name="item_note[<?= (int)$item['id']; ?>]" placeholder="Optional service note"><?= sbpE((string)($item['supplier_note'] ?? '')); ?></textarea>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:11px;">
                        <input
                            name="order_confirmation_ref"
                            value="<?= sbpE((string)($latestOrder['supplier_confirmation_ref'] ?? '')); ?>"
                            placeholder="Overall supplier confirmation reference"
                        >

                        <input type="file" name="confirmation_attachment">

                        <textarea
                            class="full"
                            name="order_confirmation_note"
                            placeholder="Overall supplier confirmation note"
                        ><?= sbpE((string)($latestOrder['supplier_confirmation_note'] ?? '')); ?></textarea>

                        <button class="btn green full" type="submit">
                            <i class="fa-solid fa-circle-check"></i>
                            Submit Booking Confirmation
                        </button>
                    </div>
                </form>

                <div class="invoice-zone">
                    <h3><i class="fa-solid fa-file-invoice-dollar"></i> Supplier Invoice & Payment Status</h3>
                    <div class="order-note" style="background:#eff6ff;color:#1e40af;">
                        Submit your invoice here after confirming the booked services. Every invoice is reviewed by TRAVSCOPE before it becomes payable.
                    </div>

                    <form method="post" enctype="multipart/form-data" class="invoice-form">
                        <input type="hidden" name="token" value="<?= sbpE($token); ?>">
                        <input type="hidden" name="csrf" value="<?= sbpE($csrf); ?>">
                        <input type="hidden" name="action" value="submit_invoice">

                        <input name="invoice_number" placeholder="Invoice number" required>
                        <input type="date" name="invoice_date" value="<?= sbpE(date('Y-m-d')); ?>" required>
                        <input type="date" name="invoice_due_date" placeholder="Due date">
                        <input type="number" step="0.01" min="0" name="invoice_net_amount" placeholder="Net amount" required>
                        <input type="number" step="0.01" min="0" name="invoice_tax_amount" value="0" placeholder="Tax amount">
                        <input type="number" step="0.01" min="0" name="invoice_other_amount" value="0" placeholder="Other amount">
                        <input class="full" type="file" name="invoice_attachment" accept=".pdf,.jpg,.jpeg,.png,.webp" required>
                        <textarea class="full" name="invoice_notes" placeholder="Optional invoice / bank / payment note"></textarea>

                        <button class="btn blue full" type="submit" onclick="return confirm('Submit this supplier invoice to TRAVSCOPE for review?');">
                            <i class="fa-solid fa-upload"></i>
                            Submit Invoice for Approval
                        </button>
                    </form>

                    <?php if ($supplierInvoices): ?>
                        <div class="invoice-list">
                            <?php foreach ($supplierInvoices as $supplierInvoice): ?>
                                <?php
                                    $paid = max(0, (float)($supplierInvoice['paid_amount'] ?? 0));
                                    $total = max(0, (float)($supplierInvoice['total_amount'] ?? 0));
                                    $outstanding = max(0, $total - $paid);
                                ?>
                                <div class="invoice-card">
                                    <div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start;">
                                        <div>
                                            <strong><?= sbpE((string)$supplierInvoice['invoice_number']); ?></strong>
                                            <div><?= sbpE(sbpDate((string)$supplierInvoice['invoice_date'])); ?><?php if (!empty($supplierInvoice['due_date'])): ?> · Due <?= sbpE(sbpDate((string)$supplierInvoice['due_date'])); ?><?php endif; ?></div>
                                        </div>
                                        <span class="invoice-status"><?= sbpE(strtoupper((string)$supplierInvoice['status'])); ?></span>
                                    </div>
                                    <div style="margin-top:5px;display:flex;gap:12px;flex-wrap:wrap;">
                                        <span>Total <span class="invoice-money"><?= sbpE((string)$supplierInvoice['currency']); ?> <?= number_format($total,2); ?></span></span>
                                        <span>Paid <?= sbpE((string)$supplierInvoice['currency']); ?> <?= number_format($paid,2); ?></span>
                                        <span>Balance <?= sbpE((string)$supplierInvoice['currency']); ?> <?= number_format($outstanding,2); ?></span>
                                    </div>
                                    <?php if (!empty($supplierInvoice['attachment_path'])): ?>
                                        <a href="<?= sbpE(BASE_URL . ltrim((string)$supplierInvoice['attachment_path'], '/')); ?>" target="_blank" style="display:inline-block;margin-top:5px;">
                                            <i class="fa-solid fa-paperclip"></i>
                                            <?= sbpE((string)($supplierInvoice['original_filename'] ?: 'Invoice attachment')); ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <section class="panel conversation">
            <div class="head">
                <div>
                    <h2><i class="fa-regular fa-comments"></i> TRAVSCOPE ↔ Supplier</h2>
                    <small style="color:#64748b;font-size:9px;">Booking confirmation conversation</small>
                </div>
            </div>

            <div class="messages" id="messageFeed">
                <?php if (!$messages): ?>
                    <div style="margin:auto;color:#94a3b8;font-size:11px;">No messages yet.</div>
                <?php endif; ?>

                <?php foreach ($messages as $message): ?>
                    <div class="msg <?= $message['sender_type']==='supplier'?'supplier':'admin'; ?>">
                        <strong><?= sbpE(ucfirst((string)$message['sender_type'])); ?></strong>
                        <div style="margin-top:4px;"><?= nl2br(sbpE((string)$message['message'])); ?></div>

                        <?php if (!empty($message['attachment_path'])): ?>
                            <a
                                href="<?= sbpE(BASE_URL . ltrim((string)$message['attachment_path'], '/')); ?>"
                                target="_blank"
                                style="display:inline-block;margin-top:5px;"
                            >
                                <i class="fa-solid fa-paperclip"></i>
                                <?= sbpE((string)($message['original_filename'] ?: 'Attachment')); ?>
                            </a>
                        <?php endif; ?>

                        <small><?= sbpE((string)$message['sent_at']); ?> · <?= sbpE((string)$message['channel']); ?></small>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="compose">
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="token" value="<?= sbpE($token); ?>">
                    <input type="hidden" name="csrf" value="<?= sbpE($csrf); ?>">
                    <input type="hidden" name="action" value="message">

                    <textarea name="message" placeholder="Write a message to TRAVSCOPE..." required></textarea>

                    <button class="btn blue" type="submit">
                        <i class="fa-solid fa-paper-plane"></i>
                        Send
                    </button>

                    <input class="attach" type="file" name="attachment">
                </form>
            </div>
        </section>
    </div>
</div>

<script>
window.addEventListener('load',function(){
    var feed=document.getElementById('messageFeed');
    if(feed) feed.scrollTop=feed.scrollHeight;
});
</script>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
