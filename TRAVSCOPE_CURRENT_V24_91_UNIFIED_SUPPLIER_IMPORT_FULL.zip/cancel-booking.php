<?php
require_once __DIR__ . '/config.php';
$amendmentFunctionsFile = __DIR__ . '/amendment-functions.php';
if (is_file($amendmentFunctionsFile)) { require_once $amendmentFunctionsFile; }
requireLogin();

$user = currentUser($pdo);
if (!$user) {
    unset($_SESSION['user_id']);
    redirect(BASE_URL . 'login.php');
}

$userId = (int)$user['id'];
$bookingId = (int)($_GET['booking'] ?? 0);

if ($bookingId <= 0) {
    redirect(BASE_URL . 'my-bookings.php');
}

$siteName = getSetting($pdo, 'site_name', 'TRAVSCOPE.COM');
$currencySymbol = getSetting($pdo, 'currency_symbol', '₹');
$cancellationPolicy = getSetting($pdo, 'cancellation_policy', '');

$stmt = $pdo->prepare("
    SELECT b.*, p.title AS package_title,
           p.duration_days, p.duration_nights,
           d.name AS destination_name,
           d.country AS destination_country
    FROM bookings b
    LEFT JOIN packages p ON p.id = b.package_id
    LEFT JOIN destinations d ON d.id = p.destination_id
    WHERE b.id = ? AND b.user_id = ?
    LIMIT 1
");
$stmt->execute([$bookingId, $userId]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    http_response_code(404);
    exit('Booking not found.');
}

$stmt = $pdo->prepare("
    SELECT *
    FROM booking_cancellations
    WHERE booking_id = ? AND user_id = ?
    ORDER BY id DESC
    LIMIT 1
");
$stmt->execute([$bookingId, $userId]);
$existing = $stmt->fetch(PDO::FETCH_ASSOC);

$cancellationFinancial = null;
if ($existing && function_exists('tsAmendCancellationFinanceReady') && tsAmendCancellationFinanceReady($pdo)) {
    try { $cancellationFinancial = tsAmendCancellationFinancial($pdo,(int)$existing['id']); }
    catch (Throwable $e) { $cancellationFinancial = null; }
}

$bookingStatus = strtolower((string)$booking['booking_status']);
$canRequest = !in_array($bookingStatus, ['cancelled', 'completed'], true);

if ($existing && strtolower((string)$existing['status']) === 'pending') {
    $canRequest = false;
}

$error = '';
$success = '';

if (!empty($_SESSION['cancel_booking_success'])) {
    $success = (string)$_SESSION['cancel_booking_success'];
    unset($_SESSION['cancel_booking_success']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf((string)($_POST['csrf_token'] ?? ''))) {
        $error = 'Security validation failed. Please refresh and try again.';
    } elseif (!$canRequest) {
        $error = 'This booking cannot accept a new cancellation request.';
    } else {
        $reason = trim((string)($_POST['reason'] ?? ''));

        if (mb_strlen($reason) < 10) {
            $error = 'Please enter a cancellation reason of at least 10 characters.';
        } elseif (mb_strlen($reason) > 3000) {
            $error = 'Cancellation reason is too long.';
        } else {
            try {
                $pdo->beginTransaction();

                $stmt = $pdo->prepare("
                    SELECT booking_status
                    FROM bookings
                    WHERE id = ? AND user_id = ?
                    LIMIT 1 FOR UPDATE
                ");
                $stmt->execute([$bookingId, $userId]);
                $locked = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$locked) {
                    throw new RuntimeException('Booking not found.');
                }

                if (in_array(strtolower((string)$locked['booking_status']), ['cancelled','completed'], true)) {
                    throw new RuntimeException('This booking can no longer be cancelled.');
                }

                $stmt = $pdo->prepare("
                    SELECT id
                    FROM booking_cancellations
                    WHERE booking_id = ? AND status = 'pending'
                    LIMIT 1 FOR UPDATE
                ");
                $stmt->execute([$bookingId]);

                if ($stmt->fetch()) {
                    throw new RuntimeException('A cancellation request is already pending for this booking.');
                }

                $stmt = $pdo->prepare("
                    INSERT INTO booking_cancellations
                    (booking_id, user_id, reason, status)
                    VALUES (?, ?, ?, 'pending')
                ");
                $stmt->execute([$bookingId, $userId, $reason]);

                $pdo->commit();

                $_SESSION['cancel_booking_success'] =
                    'Cancellation request submitted successfully.';

                redirect(BASE_URL . 'cancel-booking.php?booking=' . $bookingId);

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                error_log('Cancel booking error: ' . $e->getMessage());
                $error = $e instanceof RuntimeException
                    ? $e->getMessage()
                    : 'Unable to submit the cancellation request right now.';
            }
        }
    }
}

if ($success !== '') {
    $stmt = $pdo->prepare("
        SELECT * FROM booking_cancellations
        WHERE booking_id = ? AND user_id = ?
        ORDER BY id DESC LIMIT 1
    ");
    $stmt->execute([$bookingId, $userId]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($existing && function_exists('tsAmendCancellationFinanceReady') && tsAmendCancellationFinanceReady($pdo)) {
        try { $cancellationFinancial = tsAmendCancellationFinancial($pdo,(int)$existing['id']); }
        catch (Throwable $e) { $cancellationFinancial = null; }
    }
    $canRequest = false;
}

$fullName = trim((string)($user['full_name'] ?? 'Traveller'));
$userInitial = strtoupper(substr($fullName ?: 'T', 0, 1));
$totalAmount = max(0, (float)$booking['total_amount']);
$paidAmount = max(0, (float)$booking['paid_amount']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Cancel Booking | <?= e($siteName); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
:root{--navy:#07192d;--blue:#0b74ff;--red:#dc4356;--bg:#f5f7fb;--text:#172235;--muted:#788496;--border:#e4e9ef;--shadow:0 10px 35px rgba(7,25,45,.06)}
*{box-sizing:border-box;margin:0;padding:0}body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif}a{text-decoration:none;color:inherit}button,textarea{font:inherit}
.header{height:74px;padding:0 5%;display:flex;align-items:center;justify-content:space-between;background:#fff;border-bottom:1px solid var(--border)}
.logo{display:flex;align-items:center;gap:10px;font:800 20px 'Manrope';color:var(--navy)}.logo span{color:var(--blue)}.logo-icon{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;background:linear-gradient(135deg,#0b74ff,#00b8ff);color:#fff}
.user{display:flex;align-items:center;gap:9px}.avatar{width:39px;height:39px;border-radius:11px;display:grid;place-items:center;background:var(--blue);color:#fff;font-weight:800}.user strong{font-size:10px}
.hero{padding:42px 5% 68px;background:linear-gradient(135deg,#07192d,#0b2948);color:#fff}.hero-inner{max-width:1050px;margin:auto}.breadcrumb{font-size:9px;color:#a9bdd2;margin-bottom:12px}.hero h1{font:800 31px 'Manrope'}.hero p{margin-top:8px;color:#afc0d0;font-size:10px}
.container{max-width:1050px;margin:-34px auto 0;padding:0 20px 60px;position:relative}.grid{display:grid;grid-template-columns:minmax(0,1.25fr) minmax(300px,.75fr);gap:18px}
.card{background:#fff;border:1px solid var(--border);border-radius:14px;box-shadow:var(--shadow);overflow:hidden}.card-head{padding:17px 19px;border-bottom:1px solid var(--border)}.card-head h2{font:800 15px 'Manrope'}.card-head p{margin-top:4px;color:var(--muted);font-size:8px}.card-body{padding:19px}
.alert{margin-bottom:15px;padding:12px 14px;border-radius:9px;font-size:9px}.success{background:#eaf9f3;color:#087d55}.error{background:#fff0f2;color:#b33145}
.detail{padding:10px 0;border-bottom:1px solid #edf0f3;display:flex;justify-content:space-between;gap:15px;font-size:9px}.detail span{color:var(--muted)}.detail strong{text-align:right}.price{font:800 21px 'Manrope'}
label{display:block;margin-bottom:7px;font-size:8px;font-weight:800;text-transform:uppercase;color:#617084}textarea{width:100%;min-height:145px;padding:12px;border:1px solid var(--border);border-radius:9px;outline:none;resize:vertical;font-size:10px}
.help{margin-top:6px;color:#8c97a5;font-size:8px}.actions{margin-top:15px;display:flex;gap:8px;flex-wrap:wrap}.btn{min-height:39px;padding:0 14px;border:0;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;gap:7px;font-size:9px;font-weight:800;cursor:pointer}.btn-danger{background:var(--red);color:#fff}.btn-secondary{background:#fff;color:#607086;border:1px solid var(--border)}
.status-box{padding:16px;border-radius:10px;background:#f7f9fb}.status-title{font:800 13px 'Manrope'}.status-value{display:inline-flex;margin-top:9px;padding:6px 9px;border-radius:20px;background:#fff3e3;color:#ad680c;font-size:8px;font-weight:800;text-transform:uppercase}.status-box p{margin-top:10px;color:#758295;font-size:9px;line-height:1.65}.policy{margin-top:15px;padding:13px;border-radius:9px;background:#fff9ee;border:1px solid #f0dfbd;color:#725f40;font-size:8px;line-height:1.65}
@media(max-width:760px){.grid{grid-template-columns:1fr}.header{height:65px;padding:0 14px}.user strong{display:none}.hero{padding:32px 15px 60px}.container{padding:0 12px 45px}.actions{flex-direction:column}.btn{width:100%}}


/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>
<body>
<header class="header">
<a href="<?= e(BASE_URL); ?>" class="logo"><div class="logo-icon"><i class="fa-solid fa-plane"></i></div>TRAV<span>SCOPE</span></a>
<div class="user"><div class="avatar"><?= e($userInitial); ?></div><strong><?= e($fullName ?: 'Traveller'); ?></strong></div>
</header>
<section class="hero"><div class="hero-inner"><div class="breadcrumb"><a href="<?= e(BASE_URL); ?>">Home</a> / <a href="<?= e(BASE_URL . 'my-bookings.php'); ?>">My Bookings</a> / Cancellation</div><h1>Cancel Booking</h1><p>Submit a cancellation request for <?= e($booking['booking_number']); ?>.</p></div></section>
<main class="container">
<?php if ($success): ?><div class="alert success"><i class="fa-solid fa-circle-check"></i> <?= e($success); ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert error"><i class="fa-solid fa-triangle-exclamation"></i> <?= e($error); ?></div><?php endif; ?>
<div class="grid">
<section class="card"><div class="card-head"><h2>Cancellation Request</h2><p>Your booking is not cancelled until TRAVSCOPE approves the request.</p></div><div class="card-body">
<?php if ($existing): ?>
<div class="status-box"><div class="status-title">Latest Cancellation Request</div><div class="status-value"><?= e(ucfirst((string)$existing['status'])); ?></div><p><strong>Reason:</strong><br><?= nl2br(e((string)$existing['reason'])); ?></p><?php if (!empty($existing['admin_notes'])): ?><p><strong>TRAVSCOPE response:</strong><br><?= nl2br(e((string)$existing['admin_notes'])); ?></p><?php endif; ?><?php if ($cancellationFinancial && strtolower((string)$existing['status']) === 'approved'): ?><p><strong>Cancellation Financial Summary:</strong><br>Cancellation charge: <?= e($currencySymbol); ?><?= number_format((float)$cancellationFinancial['customer_cancellation_charge'],2); ?><br>Refund due: <?= e($currencySymbol); ?><?= number_format((float)$cancellationFinancial['customer_refund_amount'],2); ?> · <?= e(ucfirst((string)$cancellationFinancial['customer_refund_status'])); ?></p><?php endif; ?></div>
<?php endif; ?>
<?php if ($canRequest): ?>
<form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrfToken()); ?>"><label for="reason">Reason for cancellation</label><textarea name="reason" id="reason" maxlength="3000" required placeholder="Please explain why you want to cancel this booking..."><?= e((string)($_POST['reason'] ?? '')); ?></textarea><div class="help">Minimum 10 characters. Admin approval is required.</div><div class="actions"><button type="submit" class="btn btn-danger"><i class="fa-solid fa-ban"></i> Submit Cancellation Request</button><a href="<?= e(BASE_URL . 'my-bookings.php'); ?>" class="btn btn-secondary"><i class="fa-solid fa-arrow-left"></i> Back</a></div></form>
<?php else: ?><div class="actions"><a href="<?= e(BASE_URL . 'my-bookings.php'); ?>" class="btn btn-secondary"><i class="fa-solid fa-arrow-left"></i> Back to My Bookings</a></div><?php endif; ?>
<?php if ($cancellationPolicy !== ''): ?><div class="policy"><strong>Cancellation Policy</strong><br><?= nl2br(e($cancellationPolicy)); ?></div><?php endif; ?>
</div></section>
<aside class="card"><div class="card-head"><h2>Booking Summary</h2><p>Review the booking before submitting.</p></div><div class="card-body">
<div class="detail"><span>Booking Number</span><strong><?= e($booking['booking_number']); ?></strong></div>
<div class="detail"><span>Package</span><strong><?= e($booking['package_title'] ?: 'Travel Package'); ?></strong></div>
<div class="detail"><span>Destination</span><strong><?= e($booking['destination_name'] ?: 'Destination'); ?><?= !empty($booking['destination_country']) ? ', '.e($booking['destination_country']) : ''; ?></strong></div>
<div class="detail"><span>Travel Date</span><strong><?= !empty($booking['travel_date']) ? e(date('d M Y', strtotime($booking['travel_date']))) : 'Not Set'; ?></strong></div>
<div class="detail"><span>Booking Status</span><strong><?= e(ucfirst($bookingStatus)); ?></strong></div>
<div class="detail"><span>Payment Status</span><strong><?= e(ucfirst((string)$booking['payment_status'])); ?></strong></div>
<div class="detail"><span>Total</span><strong class="price"><?= e($currencySymbol); ?><?= number_format($totalAmount,2); ?></strong></div>
<div class="detail"><span>Paid</span><strong><?= e($currencySymbol); ?><?= number_format($paidAmount,2); ?></strong></div>
</div></aside>
</div>
</main>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
