<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| BOOKING SUCCESS / CONFIRMATION
| HOTEL CATEGORY + PER-PERSON PRICE VERSION: 2026-08-04-R1
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';

requireLogin();

$user = currentUser($pdo);

if (!$user) {
    unset($_SESSION['user_id']);
    redirect(BASE_URL . 'login.php');
}

$userId = (int)$user['id'];


/*
|--------------------------------------------------------------------------
| SETTINGS
|--------------------------------------------------------------------------
*/

$siteName = 'TRAVSCOPE.COM';
$currencySymbol = '₹';

try {

    $siteName = getSetting(
        $pdo,
        'site_name',
        'TRAVSCOPE.COM'
    );

    $currencySymbol = getSetting(
        $pdo,
        'currency_symbol',
        '₹'
    );

} catch (Throwable $e) {

    error_log(
        'Booking success settings error: '
        . $e->getMessage()
    );
}



function successHotelCategoryLabel(?string $category): string
{
    $category = strtolower(trim((string)$category));

    return match ($category) {
        '3_star', '3' => '3 Star Hotel',
        '4_star', '4' => '4 Star Hotel',
        '5_star', '5' => '5 Star Hotel',
        default => 'Not specified'
    };
}


/*
|--------------------------------------------------------------------------
| BOOKING ID
|--------------------------------------------------------------------------
*/

$bookingId = (int)(
    $_GET['booking']
    ?? 0
);

if ($bookingId <= 0) {
    redirect(BASE_URL . 'dashboard.php');
}


/*
|--------------------------------------------------------------------------
| FETCH BOOKING
|--------------------------------------------------------------------------
*/

try {

    $stmt = $pdo->prepare("
        SELECT

            b.*,

            p.title AS package_title,
            p.package_code,
            p.main_image AS package_image,
            p.duration_days,
            p.duration_nights,
            p.package_type,

            d.name AS destination_name,
            d.country AS destination_country

        FROM bookings b

        LEFT JOIN packages p
            ON p.id = b.package_id

        LEFT JOIN destinations d
            ON d.id = p.destination_id

        WHERE
            b.id = ?
            AND b.user_id = ?

        LIMIT 1
    ");

    $stmt->execute([
        $bookingId,
        $userId
    ]);

    $booking = $stmt->fetch();

} catch (Throwable $e) {

    error_log(
        'Booking success fetch error: '
        . $e->getMessage()
    );

    $booking = false;
}


if (!$booking) {

    http_response_code(404);

    exit('Booking not found.');
}


/*
|--------------------------------------------------------------------------
| PAYMENT STATUS CHECK
|--------------------------------------------------------------------------
|
| Do not allow a user to manually open success.php before payment approval.
|--------------------------------------------------------------------------
*/

$paymentStatus = strtolower(
    (string)$booking['payment_status']
);

if ($paymentStatus !== 'paid') {

    /*
    | Check whether a pending payment exists.
    */

    try {

        $stmt = $pdo->prepare("
            SELECT status
            FROM payments
            WHERE booking_id = ?
            ORDER BY id DESC
            LIMIT 1
        ");

        $stmt->execute([
            $bookingId
        ]);

        $latestPaymentStatus = strtolower(
            (string)$stmt->fetchColumn()
        );

    } catch (Throwable $e) {

        $latestPaymentStatus = '';
    }


    if ($latestPaymentStatus === 'pending') {

        redirect(
            BASE_URL
            . 'payment-pending.php?booking='
            . $bookingId
        );
    }


    redirect(
        BASE_URL
        . 'payment.php?booking='
        . $bookingId
    );
}


/*
|--------------------------------------------------------------------------
| SUCCESSFUL PAYMENTS
|--------------------------------------------------------------------------
*/

$payments = [];

$totalVerifiedPayment = 0.00;

$latestPayment = null;

try {

    $stmt = $pdo->prepare("
        SELECT
            id,
            transaction_id,
            payment_gateway,
            amount,
            currency,
            payment_method,
            status,
            paid_at,
            created_at

        FROM payments

        WHERE
            booking_id = ?
            AND status = 'success'

        ORDER BY id DESC
    ");

    $stmt->execute([
        $bookingId
    ]);

    $payments = $stmt->fetchAll();


    foreach ($payments as $row) {

        $totalVerifiedPayment +=
            (float)$row['amount'];
    }


    if (!empty($payments)) {

        $latestPayment =
            $payments[0];
    }

} catch (Throwable $e) {

    error_log(
        'Booking success payment error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| AMOUNTS
|--------------------------------------------------------------------------
*/

$totalAmount = max(
    0,
    (float)$booking['total_amount']
);

$paidAmount = max(
    0,
    (float)$booking['paid_amount']
);

$remainingAmount = max(
    0,
    $totalAmount - $paidAmount
);

$hotelCategoryLabel =
    successHotelCategoryLabel(
        $booking['hotel_category']
        ?? ''
    );

$hotelPricePerAdult =
    max(
        0,
        (float)(
            $booking['hotel_price']
            ?? 0
        )
    );

$adultCount =
    max(
        1,
        (int)(
            $booking['adults']
            ?? 1
        )
    );

$adultPackageSubtotal =
    round(
        $hotelPricePerAdult
        * $adultCount,
        2
    );

$discountAmount =
    max(
        0,
        (float)(
            $booking['discount_amount']
            ?? 0
        )
    );


/*
|--------------------------------------------------------------------------
| PACKAGE IMAGE
|--------------------------------------------------------------------------
*/

$packageImage = '';

if (!empty($booking['package_image'])) {

    $packageImage =
        trim(
            (string)$booking['package_image']
        );

    if (
        !preg_match(
            '#^https?://#i',
            $packageImage
        )
    ) {

        $packageImage =
            BASE_URL
            . ltrim(
                $packageImage,
                '/'
            );
    }
}


/*
|--------------------------------------------------------------------------
| CUSTOMER NAME
|--------------------------------------------------------------------------
*/

$customerName = trim(
    (string)$booking['customer_name']
);

if ($customerName === '') {

    $customerName =
        trim(
            (string)$user['full_name']
        );
}


/*
|--------------------------------------------------------------------------
| CONFIRMATION DATE
|--------------------------------------------------------------------------
*/

$confirmationDate = '';

if (
    $latestPayment &&
    !empty($latestPayment['paid_at'])
) {

    $confirmationDate =
        $latestPayment['paid_at'];

} else {

    $confirmationDate =
        $booking['updated_at']
        ?? $booking['created_at'];
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#07192d"
>

<title>
Booking Confirmed |
<?= e($booking['booking_number']); ?>
| <?= e($siteName); ?>
</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>

:root {

    --navy:#07192d;
    --blue:#0b74ff;
    --blue-dark:#075fd2;

    --green:#07966a;
    --green-light:#eafaf3;

    --background:#f5f7fa;
    --white:#ffffff;

    --text:#172235;
    --muted:#788496;

    --border:#e3e8ee;

    --shadow:
        0 18px 60px
        rgba(7,25,45,.09);
}

* {
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body {

    min-height:100vh;

    background:
        linear-gradient(
            180deg,
            #eff8f5 0,
            #f6f8fb 430px
        );

    color:var(--text);

    font-family:
        'DM Sans',
        sans-serif;
}

a {
    color:inherit;
    text-decoration:none;
}


/* HEADER */

.header {

    height:74px;

    padding:0 5%;

    display:flex;
    align-items:center;
    justify-content:space-between;

    background:white;

    border-bottom:
        1px solid
        var(--border);
}

.logo {

    display:flex;
    align-items:center;

    gap:10px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:20px;
    font-weight:800;
}

.logo-icon {

    width:40px;
    height:40px;

    border-radius:12px;

    display:grid;
    place-items:center;

    color:white;

    background:
        linear-gradient(
            135deg,
            #0b74ff,
            #00b8ff
        );
}

.logo span {
    color:var(--blue);
}

.header-right {

    display:flex;
    align-items:center;

    gap:8px;

    color:#667487;

    font-size:10px;
    font-weight:700;
}

.header-right i {
    color:var(--green);
}


/* PROGRESS */

.progress-wrap {

    background:white;

    border-bottom:
        1px solid
        var(--border);
}

.progress {

    min-height:68px;

    display:flex;
    align-items:center;
    justify-content:center;
}

.step {

    display:flex;
    align-items:center;

    gap:7px;

    color:var(--green);

    font-size:9px;
    font-weight:700;
}

.step-circle {

    width:28px;
    height:28px;

    border-radius:50%;

    display:grid;
    place-items:center;

    background:var(--green);

    color:white;
}

.step-line {

    width:70px;
    height:1px;

    margin:0 10px;

    background:#bcdccc;
}


/* PAGE */

.container {

    max-width:1080px;

    margin:auto;

    padding:
        42px 20px
        70px;
}


/* SUCCESS HERO */

.success-card {

    padding:
        38px 30px;

    border:
        1px solid
        #cfe8dc;

    border-radius:18px;

    background:white;

    box-shadow:var(--shadow);

    text-align:center;
}

.success-icon {

    width:86px;
    height:86px;

    margin:
        0 auto
        19px;

    border-radius:50%;

    display:grid;
    place-items:center;

    background:var(--green-light);

    color:var(--green);

    font-size:38px;
}

.success-card h1 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:29px;
}

.success-card > p {

    max-width:600px;

    margin:
        9px auto
        0;

    color:var(--muted);

    font-size:11px;

    line-height:1.7;
}

.booking-number {

    margin:
        21px auto
        0;

    padding:
        11px 16px;

    border:
        1px dashed
        #9cccb6;

    border-radius:9px;

    display:inline-flex;
    align-items:center;

    gap:8px;

    background:#f3fcf8;

    color:#166c50;

    font-size:10px;
}

.booking-number strong {

    font-family:
        'Manrope',
        sans-serif;

    font-size:14px;
}


/* MAIN GRID */

.grid {

    margin-top:24px;

    display:grid;

    grid-template-columns:
        minmax(0,1fr)
        355px;

    gap:22px;
}


/* CARD */

.card {

    border:
        1px solid
        var(--border);

    border-radius:15px;

    background:white;

    box-shadow:
        0 10px 35px
        rgba(7,25,45,.05);

    overflow:hidden;
}

.card-header {

    min-height:59px;

    padding:0 20px;

    border-bottom:
        1px solid
        var(--border);

    display:flex;
    align-items:center;

    gap:9px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:13px;
    font-weight:800;
}

.card-header i {
    color:var(--blue);
}

.card-body {
    padding:20px;
}


/* PACKAGE */

.package {

    display:flex;

    gap:17px;

    align-items:center;
}

.package-image {

    width:130px;
    height:100px;

    flex:0 0 130px;

    border-radius:11px;

    overflow:hidden;

    display:grid;
    place-items:center;

    background:
        linear-gradient(
            135deg,
            #0d2946,
            #0b74ff
        );

    color:white;

    font-size:26px;
}

.package-image img {

    width:100%;
    height:100%;

    object-fit:cover;
}

.package-info h2 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:18px;

    line-height:1.4;
}

.destination {

    margin-top:6px;

    color:var(--muted);

    font-size:9px;
}

.destination i {

    margin-right:4px;

    color:var(--blue);
}

.package-meta {

    margin-top:10px;

    display:flex;

    gap:7px;

    flex-wrap:wrap;
}

.meta {

    padding:5px 8px;

    border-radius:5px;

    background:#f1f5f9;

    color:#607085;

    font-size:8px;
    font-weight:700;
}


/* DETAILS */

.details-card {
    margin-top:20px;
}

.details-grid {

    display:grid;

    grid-template-columns:
        repeat(2,1fr);

    gap:0 25px;
}

.detail {

    min-height:61px;

    padding:11px 0;

    border-bottom:
        1px solid
        #edf0f3;
}

.detail span {

    display:block;

    color:#8994a3;

    font-size:8px;

    text-transform:uppercase;

    letter-spacing:.4px;
}

.detail strong {

    display:block;

    margin-top:5px;

    color:var(--navy);

    font-size:10px;

    line-height:1.5;
}


/* PAYMENT */

.payment-status {

    padding:14px;

    border-radius:10px;

    display:flex;
    align-items:center;

    gap:11px;

    background:var(--green-light);
}

.payment-status-icon {

    width:38px;
    height:38px;

    flex:0 0 38px;

    border-radius:50%;

    display:grid;
    place-items:center;

    background:var(--green);

    color:white;
}

.payment-status strong {

    display:block;

    color:#086c4a;

    font-size:10px;
}

.payment-status span {

    display:block;

    margin-top:3px;

    color:#47836d;

    font-size:8px;
}

.amounts {

    margin-top:17px;
}

.amount-row {

    padding:10px 0;

    border-bottom:
        1px solid
        #edf0f3;

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:15px;
}

.amount-row span {

    color:#7b8797;

    font-size:9px;
}

.amount-row strong {

    color:var(--navy);

    font-size:10px;
}

.amount-row.total {

    margin-top:3px;

    border-bottom:0;
}

.amount-row.total strong {

    color:var(--green);

    font-family:
        'Manrope',
        sans-serif;

    font-size:20px;
}


/* UTR */

.transaction-box {

    margin-top:15px;

    padding:12px;

    border-radius:8px;

    background:#f6f8fb;
}

.transaction-box span {

    display:block;

    color:#8792a1;

    font-size:8px;
}

.transaction-box strong {

    display:block;

    margin-top:5px;

    color:var(--blue);

    font-family:monospace;

    font-size:11px;

    word-break:break-all;
}


/* NOTICE */

.notice {

    margin-top:18px;

    padding:13px;

    border:
        1px solid
        #dce8ff;

    border-radius:9px;

    display:flex;

    gap:9px;

    background:#f3f7ff;

    color:#56708f;

    font-size:8px;

    line-height:1.6;
}

.notice i {

    margin-top:2px;

    color:var(--blue);
}


/* ACTIONS */

.actions {

    margin-top:25px;

    display:flex;
    justify-content:center;

    gap:10px;

    flex-wrap:wrap;
}

.btn {

    min-height:46px;

    padding:0 19px;

    border-radius:9px;

    display:inline-flex;
    align-items:center;
    justify-content:center;

    gap:7px;

    font-size:10px;
    font-weight:800;

    transition:.2s;
}

.btn:hover {
    transform:translateY(-1px);
}

.btn-primary {

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--blue-dark)
        );

    color:white;

    box-shadow:
        0 8px 22px
        rgba(11,116,255,.18);
}

.btn-secondary {

    border:
        1px solid
        var(--border);

    background:white;

    color:#627084;
}


/* CONFIRMATION INFO */

.confirmation {

    margin-top:18px;

    color:#8b95a3;

    text-align:center;

    font-size:8px;
}


/* MOBILE */

@media(max-width:850px) {

    .grid {
        grid-template-columns:1fr;
    }
}

@media(max-width:600px) {

    .header {

        height:64px;

        padding:0 14px;
    }

    .header-right span {
        display:none;
    }

    .logo {
        font-size:17px;
    }

    .container {

        padding:
            27px 13px
            50px;
    }

    .success-card {

        padding:
            30px 17px;
    }

    .success-card h1 {
        font-size:23px;
    }

    .step span {
        display:none;
    }

    .step-line {
        width:35px;
    }

    .package {

        align-items:flex-start;
        flex-direction:column;
    }

    .package-image {

        width:100%;
        height:170px;
    }

    .details-grid {
        grid-template-columns:1fr;
    }

    .actions {
        flex-direction:column;
    }

    .btn {
        width:100%;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>

<body>


<!-- HEADER -->

<header class="header">

<a
    href="<?= e(BASE_URL); ?>"
    class="logo"
>

    <div class="logo-icon">
        <i class="fa-solid fa-plane"></i>
    </div>

    TRAV<span>SCOPE</span>

</a>

<div class="header-right">

    <i class="fa-solid fa-shield-check"></i>

    <span>
        Booking Confirmed & Secure
    </span>

</div>

</header>


<!-- PROGRESS -->

<div class="progress-wrap">

<div class="progress">

    <div class="step">

        <div class="step-circle">
            <i class="fa-solid fa-check"></i>
        </div>

        <span>Traveller Details</span>

    </div>

    <div class="step-line"></div>

    <div class="step">

        <div class="step-circle">
            <i class="fa-solid fa-check"></i>
        </div>

        <span>Payment</span>

    </div>

    <div class="step-line"></div>

    <div class="step">

        <div class="step-circle">
            <i class="fa-solid fa-check"></i>
        </div>

        <span>Confirmed</span>

    </div>

</div>

</div>


<main class="container">


<!-- SUCCESS -->

<section class="success-card">

    <div class="success-icon">
        <i class="fa-solid fa-circle-check"></i>
    </div>

    <h1>
        Your Booking is Confirmed!
    </h1>

    <p>
        Thank you, <?= e($customerName); ?>.
        Your payment has been verified successfully and your TRAVSCOPE travel booking is now confirmed.
        Keep your booking number for future reference.
    </p>

    <div class="booking-number">

        <i class="fa-solid fa-ticket"></i>

        Booking ID

        <strong>
            <?= e($booking['booking_number']); ?>
        </strong>

    </div>

</section>


<div class="grid">


<!-- LEFT -->

<div>


<!-- PACKAGE -->

<section class="card">

    <div class="card-header">

        <i class="fa-solid fa-suitcase-rolling"></i>

        Your Trip

    </div>

    <div class="card-body">

        <div class="package">

            <div class="package-image">

                <?php if ($packageImage !== ''): ?>

                    <img
                        src="<?= e($packageImage); ?>"
                        alt="<?= e(
                            $booking['package_title']
                            ?: 'Travel Package'
                        ); ?>"
                    >

                <?php else: ?>

                    <i class="fa-solid fa-mountain-sun"></i>

                <?php endif; ?>

            </div>


            <div class="package-info">

                <h2>
                    <?= e(
                        $booking['package_title']
                        ?: 'Travel Package'
                    ); ?>
                </h2>


                <div class="destination">

                    <i class="fa-solid fa-location-dot"></i>

                    <?= e(
                        $booking['destination_name']
                        ?: 'Destination'
                    ); ?>

                    <?php if (
                        !empty(
                            $booking['destination_country']
                        )
                    ): ?>

                        ,
                        <?= e(
                            $booking['destination_country']
                        ); ?>

                    <?php endif; ?>

                </div>


                <div class="package-meta">

                    <div class="meta">

                        <i class="fa-regular fa-clock"></i>

                        <?= (int)$booking['duration_days']; ?>
                        Days /

                        <?= (int)$booking['duration_nights']; ?>
                        Nights

                    </div>


                    <?php if (
                        !empty(
                            $booking['package_code']
                        )
                    ): ?>

                        <div class="meta">

                            <?= e(
                                $booking['package_code']
                            ); ?>

                        </div>

                    <?php endif; ?>


                    <?php if (
                        !empty(
                            $booking['package_type']
                        )
                    ): ?>

                        <div class="meta">

                            <?= e(
                                ucfirst(
                                    $booking['package_type']
                                )
                            ); ?>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- BOOKING DETAILS -->

<section class="card details-card">

    <div class="card-header">

        <i class="fa-regular fa-calendar-check"></i>

        Booking Details

    </div>


    <div class="card-body">

        <div class="details-grid">


            <div class="detail">

                <span>
                    Booking Number
                </span>

                <strong>
                    <?= e(
                        $booking['booking_number']
                    ); ?>
                </strong>

            </div>


            <div class="detail">

                <span>
                    Booking Status
                </span>

                <strong>
                    <?= e(
                        ucfirst(
                            $booking['booking_status']
                        )
                    ); ?>
                </strong>

            </div>


            <div class="detail">

                <span>
                    Travel Date
                </span>

                <strong>

                    <?php if (
                        !empty(
                            $booking['travel_date']
                        )
                    ): ?>

                        <?= e(
                            date(
                                'd M Y',
                                strtotime(
                                    $booking['travel_date']
                                )
                            )
                        ); ?>

                    <?php else: ?>

                        To be confirmed

                    <?php endif; ?>

                </strong>

            </div>


            <div class="detail">

                <span>
                    Hotel Category
                </span>

                <strong>
                    <?= e($hotelCategoryLabel); ?>
                </strong>

            </div>


            <div class="detail">

                <span>
                    Price Per Adult
                </span>

                <strong>
                    <?= e($currencySymbol); ?>
                    <?= number_format(
                        $hotelPricePerAdult,
                        2
                    ); ?>
                </strong>

            </div>


            <div class="detail">

                <span>
                    Adult Package Amount
                </span>

                <strong>
                    <?= e($currencySymbol); ?>
                    <?= number_format(
                        $adultPackageSubtotal,
                        2
                    ); ?>
                </strong>

            </div>


            <div class="detail">

                <span>
                    Travellers
                </span>

                <strong>

                    <?= (int)$booking['adults']; ?>
                    Adult<?= (int)$booking['adults'] !== 1 ? 's' : ''; ?>

                    <?php if (
                        (int)$booking['children'] > 0
                    ): ?>

                        +
                        <?= (int)$booking['children']; ?>

                        Child<?= (int)$booking['children'] !== 1 ? 'ren' : ''; ?>

                    <?php endif; ?>

                </strong>

            </div>


            <div class="detail">

                <span>
                    Traveller Name
                </span>

                <strong>
                    <?= e(
                        $booking['customer_name']
                    ); ?>
                </strong>

            </div>


            <div class="detail">

                <span>
                    Mobile
                </span>

                <strong>
                    <?= e(
                        $booking['customer_mobile']
                    ); ?>
                </strong>

            </div>


            <div class="detail">

                <span>
                    Email
                </span>

                <strong>
                    <?= e(
                        $booking['customer_email']
                    ); ?>
                </strong>

            </div>


            <div class="detail">

                <span>
                    Confirmed On
                </span>

                <strong>

                    <?= e(
                        date(
                            'd M Y, h:i A',
                            strtotime(
                                $confirmationDate
                            )
                        )
                    ); ?>

                </strong>

            </div>


            <?php if (
                !empty(
                    $booking['special_request']
                )
            ): ?>

                <div class="detail">

                    <span>
                        Special Request
                    </span>

                    <strong>
                        <?= e(
                            $booking['special_request']
                        ); ?>
                    </strong>

                </div>

            <?php endif; ?>


        </div>

    </div>

</section>


</div>


<!-- RIGHT PAYMENT -->

<aside>

<section class="card">

    <div class="card-header">

        <i class="fa-solid fa-receipt"></i>

        Payment Summary

    </div>


    <div class="card-body">


        <div class="payment-status">

            <div class="payment-status-icon">

                <i class="fa-solid fa-check"></i>

            </div>

            <div>

                <strong>
                    Payment Verified
                </strong>

                <span>
                    Your date-wise hotel package price and payment have been approved.
                </span>

            </div>

        </div>


        <div class="amounts">


            <div class="amount-row">

                <span>
                    Hotel Category
                </span>

                <strong>
                    <?= e($hotelCategoryLabel); ?>
                </strong>

            </div>


            <div class="amount-row">

                <span>
                    <?= $adultCount; ?>
                    Adult<?= $adultCount === 1 ? '' : 's'; ?>
                    ×
                    <?= e($currencySymbol); ?>
                    <?= number_format(
                        $hotelPricePerAdult,
                        2
                    ); ?>
                </span>

                <strong>
                    <?= e($currencySymbol); ?>
                    <?= number_format(
                        $adultPackageSubtotal,
                        2
                    ); ?>
                </strong>

            </div>


            <?php if ($discountAmount > 0): ?>

            <div class="amount-row">

                <span>
                    Coupon Discount
                    <?php if (!empty($booking['coupon_code'])): ?>
                        (<?= e($booking['coupon_code']); ?>)
                    <?php endif; ?>
                </span>

                <strong style="color:#07966a;">
                    -<?= e($currencySymbol); ?>
                    <?= number_format(
                        $discountAmount,
                        2
                    ); ?>
                </strong>

            </div>

            <?php endif; ?>


            <div class="amount-row">

                <span>
                    Booking Total
                </span>

                <strong>

                    <?= e($currencySymbol); ?>

                    <?= number_format(
                        $totalAmount,
                        2
                    ); ?>

                </strong>

            </div>


            <div class="amount-row">

                <span>
                    Amount Paid
                </span>

                <strong>

                    <?= e($currencySymbol); ?>

                    <?= number_format(
                        $paidAmount,
                        2
                    ); ?>

                </strong>

            </div>


            <div class="amount-row">

                <span>
                    Remaining
                </span>

                <strong>

                    <?= e($currencySymbol); ?>

                    <?= number_format(
                        $remainingAmount,
                        2
                    ); ?>

                </strong>

            </div>


            <div class="amount-row total">

                <span>
                    Payment Status
                </span>

                <strong>
                    PAID
                </strong>

            </div>


        </div>


        <?php if (
            $latestPayment &&
            !empty(
                $latestPayment['transaction_id']
            )
        ): ?>

            <div class="transaction-box">

                <span>
                    Transaction ID / UTR
                </span>

                <strong>
                    <?= e(
                        $latestPayment['transaction_id']
                    ); ?>
                </strong>

            </div>

        <?php endif; ?>


        <?php if (
            $latestPayment &&
            !empty(
                $latestPayment['payment_method']
            )
        ): ?>

            <div class="transaction-box">

                <span>
                    Payment Method
                </span>

                <strong
                    style="
                        font-family:inherit;
                        color:#172235;
                    "
                >
                    <?= e(
                        $latestPayment['payment_method']
                    ); ?>
                </strong>

            </div>

        <?php endif; ?>


        <div class="notice">

            <i class="fa-solid fa-circle-info"></i>

            <div>
                Keep your booking number and transaction reference safe. TRAVSCOPE may request these details when assisting you with this booking.
            </div>

        </div>


    </div>

</section>

</aside>


</div>


<!-- ACTIONS -->

<div class="actions">


    <a
        href="<?= e(
            BASE_URL
            . 'dashboard.php'
        ); ?>"
        class="btn btn-primary"
    >

        <i class="fa-solid fa-house"></i>

        Go to Dashboard

    </a>


    <a
        href="<?= e(
            BASE_URL
            . 'my-bookings.php'
        ); ?>"
        class="btn btn-secondary"
    >

        <i class="fa-solid fa-suitcase"></i>

        My Bookings

    </a>


    <a
        href="<?= e(
            BASE_URL
            . 'packages.php'
        ); ?>"
        class="btn btn-secondary"
    >

        <i class="fa-solid fa-compass"></i>

        Explore More Trips

    </a>


</div>


<div class="confirmation">

    Confirmation reference:
    <?= e($booking['booking_number']); ?>
    • <?= e($siteName); ?>

</div>


</main>


<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>