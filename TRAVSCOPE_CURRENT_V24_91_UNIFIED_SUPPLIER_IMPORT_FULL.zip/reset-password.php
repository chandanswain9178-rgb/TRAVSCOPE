<?php
require_once __DIR__ . '/config.php';

if (isLoggedIn()) redirect(BASE_URL . 'dashboard.php');

$email=normalizeEmail((string)($_SESSION['password_reset_email'] ?? ''));
$userId=(int)($_SESSION['password_reset_user_id'] ?? 0);
$verified=!empty($_SESSION['password_reset_verified']);
$verifiedAt=(int)($_SESSION['password_reset_verified_at'] ?? 0);

if (!$verified || !$email || !$userId || !$verifiedAt || (time()-$verifiedAt)>900) {
    unset($_SESSION['password_reset_verified'],$_SESSION['password_reset_verified_at']);
    setFlash('error','Please verify your email before resetting your password.');
    redirect(BASE_URL.'forgot-password.php');
}

$error='';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $password=(string)($_POST['password'] ?? '');
    $confirm=(string)($_POST['confirm_password'] ?? '');
    $min=defined('PASSWORD_MIN_LENGTH')?(int)PASSWORD_MIN_LENGTH:8;

    if (strlen($password)<$min) $error="Password must be at least {$min} characters.";
    elseif ($password!==$confirm) $error='New password and confirm password do not match.';
    elseif (!preg_match('/[A-Za-z]/',$password) || !preg_match('/[0-9]/',$password)) $error='Use at least one letter and one number in your password.';
    else {
        $stmt=$pdo->prepare("SELECT id FROM users WHERE id=? AND email=? LIMIT 1");
        $stmt->execute([$userId,$email]);
        if (!$stmt->fetch()) {
            $error='Account could not be verified. Please restart password recovery.';
        } else {
            $hash=password_hash($password,PASSWORD_DEFAULT);
            $pdo->beginTransaction();
            try {
                $stmt=$pdo->prepare("UPDATE users SET password=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND email=?");
                $stmt->execute([$hash,$userId,$email]);
                $stmt=$pdo->prepare("UPDATE email_otps SET used_at=COALESCE(used_at,NOW()) WHERE email=? AND purpose='password_reset' AND used_at IS NULL");
                $stmt->execute([$email]);
                $pdo->commit();
                unset($_SESSION['password_reset_email'],$_SESSION['password_reset_user_id'],$_SESSION['password_reset_verified'],$_SESSION['password_reset_verified_at']);
                session_regenerate_id(true);
                setFlash('success','Password changed successfully. You can now log in with your new password.');
                redirect(BASE_URL.'login.php');
            } catch(Throwable $e) {
                if($pdo->inTransaction()) $pdo->rollBack();
                error_log('Password reset error: '.$e->getMessage());
                $error='Unable to reset your password right now. Please try again.';
            }
        }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reset Password | TRAVSCOPE.COM</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;font-family:Arial,sans-serif;background:linear-gradient(135deg,#061525,#0a3b68);display:grid;place-items:center;padding:24px;color:#172033}
.card{width:min(100%,470px);background:#fff;border-radius:22px;padding:32px;box-shadow:0 25px 70px rgba(0,0,0,.25)}
.logo{display:flex;align-items:center;gap:10px;font-size:21px;font-weight:800;color:#07192d;margin-bottom:28px}.logo b{color:#0b74ff}.icon{width:46px;height:46px;border-radius:13px;display:grid;place-items:center;background:#eaf4ff;color:#0b74ff;font-size:20px}
h1{margin:0;color:#07192d;font-size:27px}p{color:#778294;font-size:13px;line-height:1.65}
label{display:block;margin:18px 0 7px;font-size:12px;font-weight:700}.input{width:100%;height:50px;border:1px solid #dfe6ee;border-radius:11px;padding:0 14px;font-size:14px;outline:none}.input:focus{border-color:#0b74ff;box-shadow:0 0 0 3px rgba(11,116,255,.1)}
.btn{width:100%;height:50px;border:0;border-radius:11px;background:#0b74ff;color:#fff;font-weight:800;cursor:pointer;margin-top:18px}.btn:disabled{opacity:.55;cursor:not-allowed}
.alert{padding:12px 14px;border-radius:10px;margin:15px 0;font-size:12px}.error{background:#fff0f2;color:#bd3044}.success{background:#e9faf2;color:#087b4d}
.back{text-align:center;margin-top:20px;font-size:12px}.back a{color:#0b74ff;text-decoration:none;font-weight:700}
.otp-row{display:flex;gap:9px}.otp-row .input{flex:1;text-align:center;font-size:20px;letter-spacing:7px;font-weight:700}.resend{border:0;background:transparent;color:#0b74ff;font-weight:700;cursor:pointer;padding:8px 0;margin-top:10px}.resend:disabled{color:#9aa5b2}
.note{padding:11px 13px;border-radius:10px;background:#f5f8fc;color:#667386;font-size:11px;margin-top:14px}
.password-wrap{position:relative}.password-wrap .input{padding-right:48px}.eye{position:absolute;right:10px;top:7px;width:36px;height:36px;border:0;background:transparent;cursor:pointer;color:#657386}


/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head><body>
<div class="card">
<div class="logo"><span class="icon">✈</span>TRAV<b>SCOPE</b></div>
<h1>Create new password</h1>
<p>Your email has been verified. Create a strong new password for your TRAVSCOPE account.</p>
<?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif;?>
<div class="note">Resetting password for <strong><?=e($email)?></strong></div>
<form method="post" autocomplete="off">
<label>New Password</label>
<div class="password-wrap"><input class="input" id="password" type="password" name="password" minlength="<?=defined('PASSWORD_MIN_LENGTH')?(int)PASSWORD_MIN_LENGTH:8?>" required autocomplete="new-password" placeholder="Enter new password"><button type="button" class="eye" onclick="toggle('password',this)">👁</button></div>
<label>Confirm New Password</label>
<div class="password-wrap"><input class="input" id="confirm" type="password" name="confirm_password" required autocomplete="new-password" placeholder="Re-enter new password"><button type="button" class="eye" onclick="toggle('confirm',this)">👁</button></div>
<div class="note">Use at least <?=defined('PASSWORD_MIN_LENGTH')?(int)PASSWORD_MIN_LENGTH:8?> characters with at least one letter and one number.</div>
<button class="btn" type="submit">Reset Password</button>
</form>
<div class="back"><a href="login.php">← Back to Login</a></div>
</div>
<script>function toggle(id,b){const x=document.getElementById(id);x.type=x.type==='password'?'text':'password';}</script>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>