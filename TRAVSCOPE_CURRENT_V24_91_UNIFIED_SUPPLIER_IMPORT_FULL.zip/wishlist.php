<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| CUSTOMER WISHLIST
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';

requireLogin();

$user = currentUser($pdo);

if (!$user) {
    unset($_SESSION['user_id']);
    redirect(BASE_URL . 'login.php');
}

$userId = (int)$user['id'];


/*
|--------------------------------------------------------------------------
| SETTINGS
|--------------------------------------------------------------------------
*/

$siteName = 'TRAVSCOPE.COM';
$currencySymbol = '₹';

try {

    $siteName = getSetting(
        $pdo,
        'site_name',
        'TRAVSCOPE.COM'
    );

    $currencySymbol = getSetting(
        $pdo,
        'currency_symbol',
        '₹'
    );

} catch (Throwable $e) {

    error_log(
        'Wishlist settings error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['wishlist_csrf'])) {

    $_SESSION['wishlist_csrf'] =
        bin2hex(
            random_bytes(32)
        );
}

$csrfToken =
    $_SESSION['wishlist_csrf'];


/*
|--------------------------------------------------------------------------
| FLASH MESSAGE
|--------------------------------------------------------------------------
*/

$success = '';
$error = '';

if (!empty($_SESSION['wishlist_success'])) {

    $success =
        (string)$_SESSION['wishlist_success'];

    unset(
        $_SESSION['wishlist_success']
    );
}


/*
|--------------------------------------------------------------------------
| REMOVE FROM WISHLIST
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    ($_POST['action'] ?? '') === 'remove'
) {

    $postedToken =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    $wishlistId =
        (int)(
            $_POST['wishlist_id']
            ?? 0
        );


    if (
        $postedToken === ''
        ||
        !hash_equals(
            $_SESSION['wishlist_csrf'] ?? '',
            $postedToken
        )
    ) {

        $error =
            'Security verification failed. Please refresh and try again.';

    } elseif ($wishlistId <= 0) {

        $error =
            'Invalid wishlist item.';

    } else {

        try {

            /*
            |--------------------------------------------------------------------------
            | IMPORTANT SECURITY
            |--------------------------------------------------------------------------
            |
            | user_id condition prevents a user from deleting another
            | customer's wishlist item.
            |
            */

            $stmt = $pdo->prepare("
                DELETE FROM wishlists

                WHERE
                    id = ?
                    AND user_id = ?

                LIMIT 1
            ");

            $stmt->execute([
                $wishlistId,
                $userId
            ]);


            if (
                $stmt->rowCount() > 0
            ) {

                $_SESSION['wishlist_success'] =
                    'Package removed from your wishlist.';

            } else {

                $_SESSION['wishlist_success'] =
                    'Wishlist item was already removed.';
            }


            redirect(
                BASE_URL . 'wishlist.php'
            );


        } catch (Throwable $e) {

            error_log(
                'Wishlist remove error: '
                . $e->getMessage()
            );

            $error =
                'Unable to remove this package right now.';
        }
    }
}


/*
|--------------------------------------------------------------------------
| FETCH WISHLIST
|--------------------------------------------------------------------------
*/

$wishlist = [];

try {

    $stmt = $pdo->prepare("
        SELECT

            w.id AS wishlist_id,
            w.created_at AS wishlist_created_at,

            p.id AS package_id,
            p.destination_id,
            p.title,
            p.slug,
            p.package_code,
            p.short_description,
            p.duration_days,
            p.duration_nights,
            p.regular_price,
            p.sale_price,
            p.currency,
            p.package_type,
            p.main_image,
            p.featured,
            p.bestseller,
            p.views,
            p.status,

            d.name AS destination_name,
            d.country AS destination_country,
            d.continent AS destination_continent,
            d.image AS destination_image

        FROM wishlists w

        INNER JOIN packages p
            ON p.id = w.package_id

        LEFT JOIN destinations d
            ON d.id = p.destination_id

        WHERE
            w.user_id = ?
            AND p.status = 'active'

        ORDER BY
            w.id DESC
    ");

    $stmt->execute([
        $userId
    ]);

    $wishlist =
        $stmt->fetchAll();

} catch (Throwable $e) {

    error_log(
        'Wishlist fetch error: '
        . $e->getMessage()
    );

    $error =
        'Unable to load your wishlist right now.';
}


/*
|--------------------------------------------------------------------------
| TOTAL WISHLIST
|--------------------------------------------------------------------------
*/

$totalWishlist =
    count($wishlist);


/*
|--------------------------------------------------------------------------
| IMAGE FUNCTION
|--------------------------------------------------------------------------
*/

function wishlistImageUrl($image)
{
    $image =
        trim(
            (string)$image
        );

    if ($image === '') {
        return '';
    }

    if (
        preg_match(
            '#^https?://#i',
            $image
        )
    ) {
        return $image;
    }

    return
        BASE_URL
        . ltrim(
            $image,
            '/'
        );
}


/*
|--------------------------------------------------------------------------
| PRICE CALCULATION
|--------------------------------------------------------------------------
*/

function packagePrice($package)
{
    $sale =
        (float)(
            $package['sale_price']
            ?? 0
        );

    $regular =
        (float)(
            $package['regular_price']
            ?? 0
        );

    if ($sale > 0) {
        return $sale;
    }

    return max(
        0,
        $regular
    );
}


/*
|--------------------------------------------------------------------------
| DISCOUNT
|--------------------------------------------------------------------------
*/

function packageDiscount($regular, $sale)
{
    $regular =
        (float)$regular;

    $sale =
        (float)$sale;

    if (
        $regular <= 0
        ||
        $sale <= 0
        ||
        $sale >= $regular
    ) {
        return 0;
    }

    return (int)round(
        (
            ($regular - $sale)
            /
            $regular
        )
        * 100
    );
}


/*
|--------------------------------------------------------------------------
| USER DISPLAY
|--------------------------------------------------------------------------
*/

$fullName =
    trim(
        (string)(
            $user['full_name']
            ?? 'Traveller'
        )
    );

$profileImage =
    wishlistImageUrl(
        $user['profile_image']
        ?? ''
    );

$initial =
    strtoupper(
        mb_substr(
            $fullName !== ''
                ? $fullName
                : 'T',
            0,
            1
        )
    );

?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#07192d"
>

<title>
My Wishlist | <?= e($siteName); ?>
</title>


<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

:root {

    --navy:#07192d;
    --navy2:#0d2a49;

    --blue:#0b74ff;
    --blue2:#075fd2;

    --cyan:#00b8ff;

    --red:#e43f55;
    --green:#07966a;
    --orange:#e48a18;

    --background:#f5f7fa;

    --white:#ffffff;

    --text:#172235;
    --muted:#7c899a;

    --border:#e2e8ef;

    --shadow:
        0 15px 45px
        rgba(7,25,45,.07);
}


* {
    margin:0;
    padding:0;
    box-sizing:border-box;
}


html {
    scroll-behavior:smooth;
}


body {

    min-height:100vh;

    background:
        var(--background);

    color:
        var(--text);

    font-family:
        'DM Sans',
        sans-serif;
}


a {
    color:inherit;
    text-decoration:none;
}


button,
input {
    font:inherit;
}


/* =========================================================
   HEADER
========================================================= */

.header {

    height:72px;

    padding:
        0 5%;

    position:sticky;

    top:0;

    z-index:1000;

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:20px;

    border-bottom:
        1px solid
        var(--border);

    background:
        rgba(255,255,255,.97);

    backdrop-filter:
        blur(12px);
}


.logo {

    display:flex;
    align-items:center;

    gap:9px;

    color:
        var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:20px;
    font-weight:800;
}


.logo-icon {

    width:40px;
    height:40px;

    border-radius:12px;

    display:grid;
    place-items:center;

    color:white;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--cyan)
        );

    box-shadow:
        0 8px 20px
        rgba(11,116,255,.20);
}


.logo span {
    color:var(--blue);
}


.nav {

    display:flex;
    align-items:center;

    gap:5px;
}


.nav a {

    padding:
        9px 11px;

    border-radius:8px;

    color:#687589;

    font-size:10px;
    font-weight:700;

    transition:.2s;
}


.nav a:hover,
.nav a.active {

    color:var(--blue);

    background:#edf5ff;
}


.header-user {

    display:flex;
    align-items:center;

    gap:9px;
}


.avatar {

    width:38px;
    height:38px;

    border-radius:11px;

    overflow:hidden;

    display:grid;
    place-items:center;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--cyan)
        );

    color:white;

    font-size:12px;
    font-weight:800;
}


.avatar img {

    width:100%;
    height:100%;

    object-fit:cover;
}


.header-user strong {

    display:block;

    color:var(--navy);

    font-size:10px;
}


.header-user span {

    display:block;

    margin-top:1px;

    color:#929dab;

    font-size:8px;
}


/* =========================================================
   HERO
========================================================= */

.hero {

    min-height:290px;

    padding:
        42px 5%
        90px;

    position:relative;

    overflow:hidden;

    color:white;

    background:

        radial-gradient(
            circle at 85% 20%,
            rgba(0,184,255,.30),
            transparent 27%
        ),

        radial-gradient(
            circle at 60% 100%,
            rgba(11,116,255,.22),
            transparent 35%
        ),

        linear-gradient(
            135deg,
            #07192d,
            #0b2e50
        );
}


.hero:before {

    content:"";

    position:absolute;

    width:350px;
    height:350px;

    right:-110px;
    top:-150px;

    border-radius:50%;

    border:
        1px solid
        rgba(255,255,255,.08);
}


.hero:after {

    content:"";

    position:absolute;

    width:230px;
    height:230px;

    right:70px;
    top:-90px;

    border-radius:50%;

    border:
        1px solid
        rgba(255,255,255,.06);
}


.hero-inner {

    max-width:1180px;

    margin:auto;

    position:relative;

    z-index:2;
}


.breadcrumb {

    display:flex;
    align-items:center;

    gap:7px;

    color:#a9bfd3;

    font-size:9px;
}


.hero-content {

    margin-top:27px;

    display:flex;
    justify-content:space-between;
    align-items:flex-end;

    gap:30px;
}


.hero h1 {

    font-family:
        'Manrope',
        sans-serif;

    font-size:36px;

    line-height:1.2;
}


.hero p {

    max-width:590px;

    margin-top:9px;

    color:#afc2d4;

    font-size:10px;

    line-height:1.75;
}


.hero-count {

    min-width:150px;

    padding:
        14px 18px;

    border:
        1px solid
        rgba(255,255,255,.13);

    border-radius:13px;

    background:
        rgba(255,255,255,.08);

    backdrop-filter:
        blur(8px);
}


.hero-count strong {

    display:block;

    font-family:
        'Manrope',
        sans-serif;

    font-size:27px;
}


.hero-count span {

    display:block;

    margin-top:2px;

    color:#b8cadb;

    font-size:8px;
    font-weight:700;

    text-transform:uppercase;
}


/* =========================================================
   PAGE
========================================================= */

.container {

    max-width:1180px;

    margin:
        -50px auto
        0;

    padding:
        0 20px
        70px;

    position:relative;

    z-index:5;
}


/* =========================================================
   ALERT
========================================================= */

.alert {

    margin-bottom:17px;

    padding:
        13px 15px;

    border-radius:10px;

    display:flex;
    align-items:center;

    gap:8px;

    font-size:9px;

    line-height:1.5;

    box-shadow:
        0 8px 25px
        rgba(7,25,45,.05);
}


.alert-success {

    border:
        1px solid
        #bde9d7;

    background:#ebfaf4;

    color:#087650;
}


.alert-error {

    border:
        1px solid
        #f0c7cd;

    background:#fff0f2;

    color:#b63748;
}


/* =========================================================
   TOP BAR
========================================================= */

.top-bar {

    min-height:66px;

    margin-bottom:19px;

    padding:
        0 20px;

    border:
        1px solid
        var(--border);

    border-radius:14px;

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:15px;

    background:white;

    box-shadow:
        var(--shadow);
}


.top-title {

    display:flex;
    align-items:center;

    gap:10px;
}


.top-icon {

    width:37px;
    height:37px;

    border-radius:10px;

    display:grid;
    place-items:center;

    color:var(--red);

    background:#fff0f2;
}


.top-title h2 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:13px;
}


.top-title p {

    margin-top:2px;

    color:#909cab;

    font-size:8px;
}


.explore-btn {

    min-height:37px;

    padding:
        0 13px;

    border-radius:8px;

    display:inline-flex;
    align-items:center;

    gap:6px;

    color:white;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--blue2)
        );

    font-size:8px;
    font-weight:800;

    box-shadow:
        0 7px 17px
        rgba(11,116,255,.16);

    transition:.2s;
}


.explore-btn:hover {
    transform:translateY(-1px);
}


/* =========================================================
   PACKAGE GRID
========================================================= */

.package-grid {

    display:grid;

    grid-template-columns:
        repeat(3,1fr);

    gap:19px;
}


/* =========================================================
   PACKAGE CARD
========================================================= */

.package-card {

    position:relative;

    overflow:hidden;

    border:
        1px solid
        var(--border);

    border-radius:16px;

    background:white;

    box-shadow:
        0 12px 35px
        rgba(7,25,45,.06);

    transition:
        transform .25s,
        box-shadow .25s;
}


.package-card:hover {

    transform:
        translateY(-5px);

    box-shadow:
        0 20px 45px
        rgba(7,25,45,.11);
}


/* IMAGE */

.package-image {

    height:215px;

    position:relative;

    overflow:hidden;

    display:grid;
    place-items:center;

    color:white;

    background:
        linear-gradient(
            135deg,
            #12385f,
            var(--blue)
        );
}


.package-image img {

    width:100%;
    height:100%;

    object-fit:cover;

    transition:
        transform .45s;
}


.package-card:hover
.package-image img {

    transform:
        scale(1.055);
}


.package-image:after {

    content:"";

    position:absolute;

    inset:0;

    background:
        linear-gradient(
            to bottom,
            transparent 45%,
            rgba(5,20,36,.50)
        );

    pointer-events:none;
}


/* BADGES */

.badges {

    position:absolute;

    top:13px;
    left:13px;

    z-index:5;

    display:flex;

    gap:6px;

    flex-wrap:wrap;
}


.badge {

    padding:
        6px 8px;

    border-radius:6px;

    color:white;

    font-size:7px;
    font-weight:800;

    text-transform:uppercase;

    letter-spacing:.3px;

    backdrop-filter:
        blur(7px);
}


.badge-featured {
    background:#0b74ff;
}


.badge-best {

    background:
        linear-gradient(
            135deg,
            #f4a019,
            #e77812
        );
}


.badge-type {

    background:
        rgba(7,25,45,.76);
}


/* REMOVE HEART */

.remove-form {

    position:absolute;

    right:13px;
    top:13px;

    z-index:10;
}


.heart-button {

    width:37px;
    height:37px;

    border:0;

    border-radius:50%;

    display:grid;
    place-items:center;

    cursor:pointer;

    background:white;

    color:var(--red);

    font-size:13px;

    box-shadow:
        0 6px 18px
        rgba(7,25,45,.18);

    transition:.2s;
}


.heart-button:hover {

    transform:scale(1.08);

    background:var(--red);

    color:white;
}


/* IMAGE DESTINATION */

.image-location {

    position:absolute;

    left:14px;
    bottom:13px;

    z-index:5;

    display:flex;
    align-items:center;

    gap:5px;

    color:white;

    font-size:8px;
    font-weight:700;
}


/* CONTENT */

.package-body {

    padding:
        17px 17px
        18px;
}


.package-code {

    margin-bottom:6px;

    color:var(--blue);

    font-size:7px;
    font-weight:800;

    text-transform:uppercase;

    letter-spacing:.6px;
}


.package-title {

    min-height:43px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:16px;

    line-height:1.35;
}


.package-description {

    height:43px;

    margin-top:7px;

    overflow:hidden;

    color:#7e8a99;

    font-size:8px;

    line-height:1.7;
}


/* META */

.package-meta {

    margin-top:13px;

    padding:
        11px 0;

    border-top:
        1px solid
        #edf0f3;

    border-bottom:
        1px solid
        #edf0f3;

    display:flex;
    align-items:center;

    gap:12px;

    flex-wrap:wrap;
}


.meta {

    display:flex;
    align-items:center;

    gap:5px;

    color:#718094;

    font-size:8px;
}


.meta i {
    color:var(--blue);
}


/* PRICE */

.price-area {

    margin-top:14px;

    display:flex;
    align-items:flex-end;
    justify-content:space-between;

    gap:10px;
}


.price-label {

    display:block;

    margin-bottom:2px;

    color:#929dab;

    font-size:7px;
}


.price {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:20px;
    font-weight:800;
}


.old-price {

    margin-left:4px;

    color:#a4adb9;

    font-size:9px;

    text-decoration:line-through;
}


.discount {

    padding:
        5px 7px;

    border-radius:5px;

    background:#e9f9f2;

    color:var(--green);

    font-size:7px;
    font-weight:800;
}


/* BUTTONS */

.card-actions {

    margin-top:15px;

    display:grid;

    grid-template-columns:
        1fr 1fr;

    gap:7px;
}


.btn {

    min-height:39px;

    padding:
        0 10px;

    border-radius:8px;

    display:flex;
    align-items:center;
    justify-content:center;

    gap:5px;

    font-size:8px;
    font-weight:800;

    transition:.2s;
}


.btn:hover {
    transform:translateY(-1px);
}


.btn-details {

    border:
        1px solid
        #dfe6ed;

    color:#566579;

    background:white;
}


.btn-book {

    color:white;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--blue2)
        );

    box-shadow:
        0 7px 17px
        rgba(11,116,255,.16);
}


/* SAVED DATE */

.saved-date {

    margin-top:11px;

    text-align:center;

    color:#9aa4b1;

    font-size:7px;
}


/* =========================================================
   EMPTY WISHLIST
========================================================= */

.empty {

    padding:
        65px 25px;

    border:
        1px solid
        var(--border);

    border-radius:17px;

    text-align:center;

    background:white;

    box-shadow:
        var(--shadow);
}


.empty-icon {

    width:90px;
    height:90px;

    margin:
        0 auto
        20px;

    border-radius:28px;

    display:grid;
    place-items:center;

    color:var(--red);

    background:
        linear-gradient(
            135deg,
            #fff0f2,
            #fff7f8
        );

    font-size:33px;
}


.empty h2 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:22px;
}


.empty p {

    max-width:470px;

    margin:
        8px auto
        20px;

    color:#8591a1;

    font-size:9px;

    line-height:1.7;
}


.empty .explore-btn {

    min-height:42px;

    padding:
        0 17px;
}


/* =========================================================
   FOOT NOTE
========================================================= */

.note {

    margin-top:20px;

    padding:14px;

    border:
        1px solid
        #dbe8f7;

    border-radius:10px;

    display:flex;
    align-items:flex-start;

    gap:9px;

    background:#f5f9ff;

    color:#6a7d94;

    font-size:8px;

    line-height:1.6;
}


.note i {

    margin-top:2px;

    color:var(--blue);
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:1000px) {

    .package-grid {
        grid-template-columns:
            repeat(2,1fr);
    }
}


@media(max-width:760px) {

    .nav {
        display:none;
    }

    .hero-content {

        align-items:flex-start;

        flex-direction:column;
    }

    .hero-count {
        min-width:130px;
    }
}


@media(max-width:620px) {

    .header {

        height:64px;

        padding:
            0 13px;
    }

    .logo {
        font-size:17px;
    }

    .header-user > div:last-child {
        display:none;
    }

    .hero {

        min-height:260px;

        padding:
            30px 15px
            80px;
    }

    .hero h1 {
        font-size:28px;
    }

    .container {

        padding:
            0 12px
            50px;
    }

    .top-bar {

        padding:
            12px 13px;

        align-items:flex-start;

        flex-direction:column;
    }

    .package-grid {
        grid-template-columns:1fr;
    }

    .package-image {
        height:230px;
    }
}


@media(max-width:400px) {

    .card-actions {
        grid-template-columns:1fr;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>

<body>


<!-- =========================================================
     HEADER
========================================================= -->

<header class="header">


<a
    href="<?= e(BASE_URL); ?>"
    class="logo"
>

    <div class="logo-icon">

        <i class="fa-solid fa-plane"></i>

    </div>

    TRAV<span>SCOPE</span>

</a>


<nav class="nav">

    <a href="<?= e(BASE_URL . 'dashboard.php'); ?>">
        Dashboard
    </a>

    <a href="<?= e(BASE_URL . 'packages.php'); ?>">
        Packages
    </a>

    <a href="<?= e(BASE_URL . 'my-bookings.php'); ?>">
        My Bookings
    </a>

    <a
        href="<?= e(BASE_URL . 'wishlist.php'); ?>"
        class="active"
    >
        Wishlist
    </a>

    <a href="<?= e(BASE_URL . 'profile.php'); ?>">
        Profile
    </a>

</nav>


<div class="header-user">


<div class="avatar">

<?php if ($profileImage !== ''): ?>

    <img
        src="<?= e($profileImage); ?>"
        alt="Profile"
    >

<?php else: ?>

    <?= e($initial); ?>

<?php endif; ?>

</div>


<div>

    <strong>
        <?= e($fullName); ?>
    </strong>

    <span>
        My Account
    </span>

</div>


</div>


</header>


<!-- =========================================================
     HERO
========================================================= -->

<section class="hero">

<div class="hero-inner">


<div class="breadcrumb">

    <a href="<?= e(BASE_URL . 'dashboard.php'); ?>">
        Dashboard
    </a>

    <i class="fa-solid fa-chevron-right"></i>

    My Wishlist

</div>


<div class="hero-content">


<div>

    <h1>
        Your Dream Trips
        <i class="fa-solid fa-heart"></i>
    </h1>

    <p>
        Keep all your favourite destinations and travel packages
        together. When you're ready for your next adventure,
        your dream trip is only a click away.
    </p>

</div>


<div class="hero-count">

    <strong>
        <?= number_format(
            $totalWishlist
        ); ?>
    </strong>

    <span>

        Saved
        <?= $totalWishlist === 1
            ? 'Package'
            : 'Packages'; ?>

    </span>

</div>


</div>

</div>

</section>


<!-- =========================================================
     MAIN
========================================================= -->

<main class="container">


<?php if ($success !== ''): ?>

<div class="alert alert-success">

    <i class="fa-solid fa-circle-check"></i>

    <?= e($success); ?>

</div>

<?php endif; ?>


<?php if ($error !== ''): ?>

<div class="alert alert-error">

    <i class="fa-solid fa-circle-exclamation"></i>

    <?= e($error); ?>

</div>

<?php endif; ?>


<!-- =========================================================
     TOP BAR
========================================================= -->

<div class="top-bar">


<div class="top-title">


<div class="top-icon">

    <i class="fa-solid fa-heart"></i>

</div>


<div>

    <h2>
        Saved Travel Packages
    </h2>

    <p>

        <?= number_format(
            $totalWishlist
        ); ?>

        <?= $totalWishlist === 1
            ? 'package'
            : 'packages'; ?>

        waiting for you

    </p>

</div>


</div>


<a
    href="<?= e(BASE_URL . 'packages.php'); ?>"
    class="explore-btn"
>

    <i class="fa-solid fa-compass"></i>

    Explore More

</a>


</div>


<!-- =========================================================
     WISHLIST
========================================================= -->

<?php if ($wishlist): ?>


<div class="package-grid">


<?php foreach ($wishlist as $package): ?>


<?php

$price =
    packagePrice(
        $package
    );

$regularPrice =
    (float)(
        $package['regular_price']
        ?? 0
    );

$salePrice =
    (float)(
        $package['sale_price']
        ?? 0
    );

$discount =
    packageDiscount(
        $regularPrice,
        $salePrice
    );


$image =
    wishlistImageUrl(
        $package['main_image']
        ?? ''
    );


/*
|--------------------------------------------------------------------------
| DESTINATION IMAGE FALLBACK
|--------------------------------------------------------------------------
*/

if (
    $image === ''
    &&
    !empty(
        $package['destination_image']
    )
) {

    $image =
        wishlistImageUrl(
            $package['destination_image']
        );
}


$destination =
    trim(
        (string)(
            $package['destination_name']
            ?? ''
        )
    );

$country =
    trim(
        (string)(
            $package['destination_country']
            ?? ''
        )
    );


$location = '';

if ($destination !== '') {

    $location =
        $destination;

    if (
        $country !== ''
        &&
        strcasecmp(
            $destination,
            $country
        ) !== 0
    ) {

        $location .=
            ', '
            . $country;
    }
}


$detailsUrl =
    BASE_URL
    . 'package-details.php?slug='
    . urlencode(
        $package['slug']
    );


$bookUrl =
    BASE_URL
    . 'book-package.php?package='
    . (int)$package['package_id'];

?>


<article class="package-card">


<!-- =====================================================
     IMAGE
===================================================== -->

<div class="package-image">


<?php if ($image !== ''): ?>

    <img
        src="<?= e($image); ?>"
        alt="<?= e(
            $package['title']
        ); ?>"
        loading="lazy"
    >

<?php else: ?>

    <i
        class="fa-solid fa-mountain-sun"
        style="font-size:40px;"
    ></i>

<?php endif; ?>


<!-- BADGES -->

<div class="badges">


<?php if (
    (int)$package['featured'] === 1
): ?>

    <span class="badge badge-featured">

        <i class="fa-solid fa-star"></i>

        Featured

    </span>

<?php endif; ?>


<?php if (
    (int)$package['bestseller'] === 1
): ?>

    <span class="badge badge-best">

        <i class="fa-solid fa-fire"></i>

        Bestseller

    </span>

<?php endif; ?>


<?php if (
    !empty(
        $package['package_type']
    )
): ?>

    <span class="badge badge-type">

        <?= e(
            ucfirst(
                $package['package_type']
            )
        ); ?>

    </span>

<?php endif; ?>


</div>


<!-- REMOVE -->

<form
    method="post"
    class="remove-form"
    onsubmit="
        return confirm(
            'Remove this package from your wishlist?'
        );
    "
>

    <input
        type="hidden"
        name="csrf_token"
        value="<?= e($csrfToken); ?>"
    >

    <input
        type="hidden"
        name="action"
        value="remove"
    >

    <input
        type="hidden"
        name="wishlist_id"
        value="<?= (int)$package['wishlist_id']; ?>"
    >


    <button
        type="submit"
        class="heart-button"
        title="Remove from wishlist"
        aria-label="Remove from wishlist"
    >

        <i class="fa-solid fa-heart"></i>

    </button>

</form>


<?php if ($location !== ''): ?>

<div class="image-location">

    <i class="fa-solid fa-location-dot"></i>

    <?= e($location); ?>

</div>

<?php endif; ?>


</div>


<!-- =====================================================
     CONTENT
===================================================== -->

<div class="package-body">


<?php if (
    !empty(
        $package['package_code']
    )
): ?>

<div class="package-code">

    <?= e(
        $package['package_code']
    ); ?>

</div>

<?php endif; ?>


<h2 class="package-title">

    <a href="<?= e($detailsUrl); ?>">

        <?= e(
            $package['title']
        ); ?>

    </a>

</h2>


<div class="package-description">

<?php if (
    !empty(
        $package['short_description']
    )
): ?>

    <?= e(
        $package['short_description']
    ); ?>

<?php else: ?>

    Discover this carefully selected travel experience
    and create memories that last a lifetime.

<?php endif; ?>

</div>


<!-- META -->

<div class="package-meta">


<div class="meta">

    <i class="fa-regular fa-calendar"></i>

    <?= (int)$package['duration_days']; ?>
    Days

</div>


<div class="meta">

    <i class="fa-regular fa-moon"></i>

    <?= (int)$package['duration_nights']; ?>
    Nights

</div>


<?php if (
    !empty(
        $package['package_type']
    )
): ?>

<div class="meta">

    <i class="fa-solid fa-suitcase"></i>

    <?= e(
        ucfirst(
            $package['package_type']
        )
    ); ?>

</div>

<?php endif; ?>


</div>


<!-- =====================================================
     PRICE
===================================================== -->

<div class="price-area">


<div>

    <span class="price-label">
        Starting from
    </span>


    <span class="price">

        <?= e($currencySymbol); ?>

        <?= number_format(
            $price,
            0
        ); ?>

    </span>


    <?php if (
        $regularPrice > 0
        &&
        $salePrice > 0
        &&
        $salePrice < $regularPrice
    ): ?>

        <span class="old-price">

            <?= e($currencySymbol); ?>

            <?= number_format(
                $regularPrice,
                0
            ); ?>

        </span>

    <?php endif; ?>


</div>


<?php if ($discount > 0): ?>

<span class="discount">

    <?= (int)$discount; ?>%
    OFF

</span>

<?php endif; ?>


</div>


<!-- =====================================================
     ACTIONS
===================================================== -->

<div class="card-actions">


<a
    href="<?= e($detailsUrl); ?>"
    class="btn btn-details"
>

    <i class="fa-regular fa-eye"></i>

    View Details

</a>


<a
    href="<?= e($bookUrl); ?>"
    class="btn btn-book"
>

    <i class="fa-solid fa-plane-departure"></i>

    Book Now

</a>


</div>


<div class="saved-date">

    <i class="fa-regular fa-heart"></i>

    Saved

    <?= e(
        date(
            'd M Y',
            strtotime(
                $package['wishlist_created_at']
            )
        )
    ); ?>

</div>


</div>


</article>


<?php endforeach; ?>


</div>


<!-- INFO -->

<div class="note">

    <i class="fa-solid fa-circle-info"></i>

    <div>
        Saving a package does not reserve its price or availability.
        Package prices and availability may change before booking.
    </div>

</div>


<?php else: ?>


<!-- =========================================================
     EMPTY
========================================================= -->

<section class="empty">


<div class="empty-icon">

    <i class="fa-regular fa-heart"></i>

</div>


<h2>
    Your wishlist is waiting
</h2>


<p>
    You haven't saved any travel packages yet.
    Explore our destinations and tap the heart icon on the
    packages you love. They'll appear here for easy access.
</p>


<a
    href="<?= e(BASE_URL . 'packages.php'); ?>"
    class="explore-btn"
>

    <i class="fa-solid fa-compass"></i>

    Explore Travel Packages

</a>


</section>


<?php endif; ?>


</main>



<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>

</html>