<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| PROFESSIONAL COMMON LOGIN
|--------------------------------------------------------------------------
|
| ADMIN:
| Email / Mobile + Password
| → admin-dashboard.php
|
| CUSTOMER:
| Email / Mobile + Password
| → dashboard.php
|
*/

require_once __DIR__ . '/config.php';

/* V24.65: logo uploaded from Admin > General Settings. */
$siteName = trim((string)getSetting($pdo, 'site_name', 'TRAVSCOPE.COM'));
$siteLogo = trim((string)getSetting($pdo, 'site_logo', ''));
$siteLogoUrl = '';
if ($siteLogo !== '') {
    $siteLogoUrl = preg_match('#^https?://#i', $siteLogo)
        ? $siteLogo
        : rtrim((string)BASE_URL, '/') . '/' . ltrim($siteLogo, '/');
}

/*
|--------------------------------------------------------------------------
| CUSTOMER ROLE DASHBOARD
|--------------------------------------------------------------------------
|
| USER:
| → dashboard.php
|
| STAFF:
| → staff.php
|
| MANAGER:
| → manager.php
|
*/

function loginRoleDashboard(string $role): string
{
    return match (
        strtolower(
            trim($role)
        )
    ) {
        'manager' =>
            'manager.php',

        'staff' =>
            'staff.php',

        default =>
            'dashboard.php'
    };
}


/*
|--------------------------------------------------------------------------
| CHECK USERS ROLE COLUMN
|--------------------------------------------------------------------------
|
| Keeps this login compatible while the role upgrade is being deployed.
|
*/

function loginUserRoleColumnExists(PDO $pdo): bool
{
    try {

        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = DATABASE()
              AND table_name = 'users'
              AND column_name = 'role'
        ");

        $stmt->execute();

        return
            (int)$stmt->fetchColumn() > 0;

    } catch (Throwable $e) {

        error_log(
            'TRAVSCOPE user role column check error: '
            . $e->getMessage()
        );

        return false;
    }
}


$userRoleColumnExists =
    loginUserRoleColumnExists(
        $pdo
    );



/*
|--------------------------------------------------------------------------
| ALREADY LOGGED IN
|--------------------------------------------------------------------------
*/

if (isAdminLoggedIn()) {
    redirect(BASE_URL . 'admin-dashboard.php');
}

if (isLoggedIn()) {

    if (defined('MAINTENANCE_MODE_ACTIVE') && MAINTENANCE_MODE_ACTIVE) {

        /*
        | Customer sessions are not allowed during maintenance.
        | Clear the customer session but keep the shared login page available
        | so an administrator can sign in using the same form.
        */
        unset(
            $_SESSION['user_id'],
            $_SESSION['user_name'],
            $_SESSION['user_email'],
            $_SESSION['user_mobile'],
            $_SESSION['user_role']
        );

    } else {

        /*
        |--------------------------------------------------------------------------
        | ALREADY LOGGED-IN CUSTOMER ROLE
        |--------------------------------------------------------------------------
        */

        $currentRole =
            strtolower(
                (string)(
                    $_SESSION['user_role']
                    ?? ''
                )
            );


        /*
        | Older customer sessions may not yet contain user_role.
        | Read the role from the database when needed.
        */

        if (
            $currentRole === ''
            &&
            $userRoleColumnExists
        ) {

            try {

                $stmt = $pdo->prepare("
                    SELECT role
                    FROM users
                    WHERE id = ?
                    LIMIT 1
                ");

                $stmt->execute([
                    (int)(
                        $_SESSION['user_id']
                        ?? 0
                    )
                ]);

                $currentRole =
                    strtolower(
                        (string)(
                            $stmt->fetchColumn()
                            ?: 'user'
                        )
                    );

                $_SESSION['user_role'] =
                    $currentRole;

            } catch (Throwable $e) {

                error_log(
                    'TRAVSCOPE logged-in role lookup error: '
                    . $e->getMessage()
                );

                $currentRole =
                    'user';
            }
        }


        if ($currentRole === '') {

            $currentRole =
                'user';
        }


        redirect(
            BASE_URL .
            loginRoleDashboard(
                $currentRole
            )
        );
    }
}


/*
|--------------------------------------------------------------------------
| VARIABLES
|--------------------------------------------------------------------------
*/

$error = '';
$success = '';
$login = '';
$remember = false;

if (!empty($_SESSION['google_auth_error'])) {
    $error = (string)$_SESSION['google_auth_error'];
    unset($_SESSION['google_auth_error']);
}

/*
|--------------------------------------------------------------------------
| PASSWORD RESET SUCCESS MESSAGE
|--------------------------------------------------------------------------
*/

if (
    !empty($_SESSION['flash'])
    &&
    is_array($_SESSION['flash'])
    &&
    (string)($_SESSION['flash']['type'] ?? '') === 'success'
) {
    $success =
        (string)(
            $_SESSION['flash']['message']
            ?? ''
        );

    unset($_SESSION['flash']);
}


/*
|--------------------------------------------------------------------------
| LOGIN REQUEST
|--------------------------------------------------------------------------
*/

if (isPost()) {

    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */

    if (!verifyCsrf($_POST['csrf_token'] ?? null)) {

        $error =
            'Security verification failed. Please refresh the page and try again.';

    } else {

        /*
        |--------------------------------------------------------------------------
        | INPUT
        |--------------------------------------------------------------------------
        */

        $login = trim(
            (string)($_POST['login'] ?? '')
        );

        $password =
            (string)($_POST['password'] ?? '');

        $remember =
            isset($_POST['remember']);


        /*
        |--------------------------------------------------------------------------
        | BASIC VALIDATION
        |--------------------------------------------------------------------------
        */

        if ($login === '' || $password === '') {

            $error =
                'Please enter your email/mobile number and password.';

        } else {

            /*
            |--------------------------------------------------------------------------
            | EMAIL OR MOBILE
            |--------------------------------------------------------------------------
            */

            $isEmail =
                validEmail($login);

            $normalizedMobile =
                normalizeMobile($login);

            $isMobile =
                validMobile($normalizedMobile);


            if (!$isEmail && !$isMobile) {

                $error =
                    'Please enter a valid email address or 10-digit mobile number.';

            } else {

                /*
                |--------------------------------------------------------------------------
                | NORMALIZE VALUE
                |--------------------------------------------------------------------------
                */

                if ($isEmail) {

                    $loginValue =
                        normalizeEmail($login);

                } else {

                    $loginValue =
                        $normalizedMobile;
                }


                /*
                |--------------------------------------------------------------------------
                | CHECK ADMIN FIRST
                |--------------------------------------------------------------------------
                */

                $admin = null;

                try {

                    if ($isEmail) {

                        $stmt = $pdo->prepare("
                            SELECT
                                id,
                                name,
                                email,
                                mobile,
                                password,
                                role,
                                status
                            FROM admins
                            WHERE email = ?
                            LIMIT 1
                        ");

                    } else {

                        $stmt = $pdo->prepare("
                            SELECT
                                id,
                                name,
                                email,
                                mobile,
                                password,
                                role,
                                status
                            FROM admins
                            WHERE mobile = ?
                            LIMIT 1
                        ");
                    }

                    $stmt->execute([
                        $loginValue
                    ]);

                    $admin =
                        $stmt->fetch();

                } catch (Throwable $e) {

                    error_log(
                        'TRAVSCOPE admin login lookup error: '
                        . $e->getMessage()
                    );

                    $admin = null;
                }


                /*
                |--------------------------------------------------------------------------
                | ADMIN FOUND
                |--------------------------------------------------------------------------
                */

                if ($admin) {

                    /*
                    |--------------------------------------------------------------------------
                    | ADMIN STATUS
                    |--------------------------------------------------------------------------
                    */

                    if (
                        strtolower(
                            (string)$admin['status']
                        ) !== 'active'
                    ) {

                        $error =
                            'Your administrator account is currently inactive.';

                    /*
                    |--------------------------------------------------------------------------
                    | ADMIN PASSWORD
                    |--------------------------------------------------------------------------
                    */

                    } elseif (
                        !password_verify(
                            $password,
                            (string)$admin['password']
                        )
                    ) {

                        $error =
                            'The email/mobile number or password you entered is incorrect.';

                    } else {

                        /*
                        |--------------------------------------------------------------------------
                        | ADMIN LOGIN SUCCESS
                        |--------------------------------------------------------------------------
                        */

                        session_regenerate_id(true);


                        /*
                        |--------------------------------------------------------------------------
                        | REMOVE CUSTOMER SESSION
                        |--------------------------------------------------------------------------
                        */

                        unset(
                            $_SESSION['user_id'],
                            $_SESSION['user_name'],
                            $_SESSION['user_email'],
                            $_SESSION['user_mobile']
                        );


                        /*
                        |--------------------------------------------------------------------------
                        | ADMIN SESSION
                        |--------------------------------------------------------------------------
                        */

                        $_SESSION['admin_id'] =
                            (int)$admin['id'];

                        $_SESSION['admin_name'] =
                            (string)$admin['name'];

                        $_SESSION['admin_email'] =
                            (string)$admin['email'];

                        $_SESSION['admin_mobile'] =
                            (string)($admin['mobile'] ?? '');

                        $_SESSION['admin_role'] =
                            (string)$admin['role'];


                        /*
                        |--------------------------------------------------------------------------
                        | ADMIN LAST LOGIN
                        |--------------------------------------------------------------------------
                        */

                        try {

                            $update = $pdo->prepare("
                                UPDATE admins
                                SET last_login = NOW()
                                WHERE id = ?
                            ");

                            $update->execute([
                                (int)$admin['id']
                            ]);

                        } catch (Throwable $e) {

                            error_log(
                                'TRAVSCOPE admin last login error: '
                                . $e->getMessage()
                            );
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | GO TO ADMIN DASHBOARD
                        |--------------------------------------------------------------------------
                        */

                        redirect(
                            BASE_URL .
                            'admin-dashboard.php'
                        );
                    }
                }


                /*
                |--------------------------------------------------------------------------
                | CHECK CUSTOMER
                |--------------------------------------------------------------------------
                */

                if (!$admin && $error === '') {

                    $user = null;

                    /*
                    |--------------------------------------------------------------------------
                    | CUSTOMER ROLE SELECT
                    |--------------------------------------------------------------------------
                    |
                    | If the role column exists, load the real role.
                    | Otherwise treat the account as a normal user.
                    |
                    */

                    $customerRoleSelect =
                        $userRoleColumnExists
                            ? ", role"
                            : ", 'user' AS role";

                    try {

                        if ($isEmail) {

                            $stmt = $pdo->prepare("
                                SELECT
                                    id,
                                    full_name,
                                    email,
                                    mobile,
                                    password,
                                    status,
                                    email_verified
                                    {$customerRoleSelect}
                                FROM users
                                WHERE email = ?
                                LIMIT 1
                            ");

                        } else {

                            $stmt = $pdo->prepare("
                                SELECT
                                    id,
                                    full_name,
                                    email,
                                    mobile,
                                    password,
                                    status,
                                    email_verified
                                    {$customerRoleSelect}
                                FROM users
                                WHERE mobile = ?
                                LIMIT 1
                            ");
                        }

                        $stmt->execute([
                            $loginValue
                        ]);

                        $user =
                            $stmt->fetch();

                    } catch (Throwable $e) {

                        error_log(
                            'TRAVSCOPE customer login lookup error: '
                            . $e->getMessage()
                        );

                        $user = null;
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | CUSTOMER NOT FOUND
                    |--------------------------------------------------------------------------
                    */

                    if (!$user) {

                        $error =
                            'The email/mobile number or password you entered is incorrect.';


                    /*
                    |--------------------------------------------------------------------------
                    | CUSTOMER STATUS
                    |--------------------------------------------------------------------------
                    */

                    } elseif (
                        strtolower(
                            (string)$user['status']
                        ) !== 'active'
                    ) {

                        $error =
                            'Your account is currently inactive or blocked. Please contact support.';


                    /*
                    |--------------------------------------------------------------------------
                    | EMAIL VERIFICATION
                    |--------------------------------------------------------------------------
                    |
                    | YOUR DATABASE COLUMN:
                    | email_verified TINYINT(1)
                    |
                    | 0 = Not verified
                    | 1 = Verified
                    |
                    */

                    } elseif (
                        defined(
                            'EMAIL_VERIFICATION_REQUIRED'
                        )
                        &&
                        EMAIL_VERIFICATION_REQUIRED
                        &&
                        (int)$user['email_verified'] !== 1
                    ) {

                        /*
                        | Save details so verify-email.php
                        | can identify this account.
                        */

                        $_SESSION['pending_verify_user_id'] =
                            (int)$user['id'];

                        $_SESSION['pending_verify_email'] =
                            (string)$user['email'];

                        $error =
                            'Your email address has not been verified. Please verify your email before signing in.';


                    /*
                    |--------------------------------------------------------------------------
                    | CUSTOMER PASSWORD
                    |--------------------------------------------------------------------------
                    */

                    } elseif (
                        !password_verify(
                            $password,
                            (string)$user['password']
                        )
                    ) {

                        $error =
                            'The email/mobile number or password you entered is incorrect.';


                    /*
                    |--------------------------------------------------------------------------
                    | CUSTOMER LOGIN SUCCESS
                    |--------------------------------------------------------------------------
                    */

                    } elseif (
                        defined('MAINTENANCE_MODE_ACTIVE')
                        && MAINTENANCE_MODE_ACTIVE
                    ) {

                        /*
                        |--------------------------------------------------------------------------
                        | CUSTOMER LOGIN BLOCKED DURING MAINTENANCE
                        |--------------------------------------------------------------------------
                        |
                        | The same login form is used by admin and customer.
                        | Admin authentication is checked first above and remains
                        | fully available. Only customer authentication stops here.
                        |
                        */

                        $error =
                            'Website is currently under maintenance. Customer login is temporarily unavailable. Administrators can still sign in using their administrator credentials.';

                    } else {

                        session_regenerate_id(true);


                        /*
                        |--------------------------------------------------------------------------
                        | REMOVE ADMIN SESSION
                        |--------------------------------------------------------------------------
                        */

                        unset(
                            $_SESSION['admin_id'],
                            $_SESSION['admin_name'],
                            $_SESSION['admin_email'],
                            $_SESSION['admin_mobile'],
                            $_SESSION['admin_role']
                        );


                        /*
                        |--------------------------------------------------------------------------
                        | CUSTOMER SESSION
                        |--------------------------------------------------------------------------
                        */

                        $_SESSION['user_id'] =
                            (int)$user['id'];

                        $_SESSION['user_name'] =
                            (string)$user['full_name'];

                        $_SESSION['user_email'] =
                            (string)$user['email'];

                        $_SESSION['user_mobile'] =
                            (string)($user['mobile'] ?? '');


                        /*
                        |--------------------------------------------------------------------------
                        | CUSTOMER ROLE SESSION
                        |--------------------------------------------------------------------------
                        */

                        $_SESSION['user_role'] =
                            strtolower(
                                (string)(
                                    $user['role']
                                    ?? 'user'
                                )
                            );


                        /*
                        |--------------------------------------------------------------------------
                        | REMOVE VERIFICATION SESSION
                        |--------------------------------------------------------------------------
                        */

                        unset(
                            $_SESSION['pending_verify_user_id'],
                            $_SESSION['pending_verify_email']
                        );


                        /*
                        |--------------------------------------------------------------------------
                        | REDIRECT AFTER LOGIN
                        |--------------------------------------------------------------------------
                        */


                        /*
                        |--------------------------------------------------------------------------
                        | ROLE DASHBOARD
                        |--------------------------------------------------------------------------
                        |
                        | user    -> dashboard.php
                        | staff   -> staff.php
                        | manager -> manager.php
                        |
                        */

                        $customerRole =
                            strtolower(
                                (string)(
                                    $user['role']
                                    ?? 'user'
                                )
                            );

                        $roleDashboard =
                            BASE_URL .
                            loginRoleDashboard(
                                $customerRole
                            );


                        /*
                        |--------------------------------------------------------------------------
                        | STAFF / MANAGER DASHBOARD
                        |--------------------------------------------------------------------------
                        |
                        | Staff and Manager always enter their own dashboard.
                        |
                        */

                        if (
                            in_array(
                                $customerRole,
                                [
                                    'staff',
                                    'manager'
                                ],
                                true
                            )
                        ) {

                            unset(
                                $_SESSION[
                                    'redirect_after_login'
                                ]
                            );

                            redirect(
                                $roleDashboard
                            );
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | NORMAL USER REDIRECT
                        |--------------------------------------------------------------------------
                        |
                        | Keep your existing customer return URL behavior intact.
                        |
                        */

                        $redirectAfterLogin =
                            $_SESSION['redirect_after_login']
                            ??
                            $roleDashboard;

                        unset(
                            $_SESSION['redirect_after_login']
                        );


                        /*
                        |--------------------------------------------------------------------------
                        | SAFE REDIRECT
                        |--------------------------------------------------------------------------
                        */

                        $isSafeRedirect = false;

                        if (
                            str_starts_with(
                                $redirectAfterLogin,
                                BASE_URL
                            )
                        ) {

                            $isSafeRedirect = true;

                        } elseif (
                            str_starts_with(
                                $redirectAfterLogin,
                                '/'
                            )
                            &&
                            !str_starts_with(
                                $redirectAfterLogin,
                                '//'
                            )
                        ) {

                            $isSafeRedirect = true;
                        }


                        if (!$isSafeRedirect) {

                            $redirectAfterLogin =
                                $roleDashboard;
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | CUSTOMER / ROLE DASHBOARD
                        |--------------------------------------------------------------------------
                        */

                        redirect(
                            $redirectAfterLogin
                        );
                    }
                }
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

$csrfToken =
    csrfToken();

?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#071a2f"
>

<meta
    name="robots"
    content="noindex,nofollow"
>

<title>
    Sign In | <?= e($siteName); ?>
</title>


<!-- GOOGLE FONTS -->

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap"
    rel="stylesheet"
>


<!-- FONT AWESOME -->

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

:root {

    --primary:#0b74ff;
    --primary-dark:#075ed1;

    --navy:#071a2f;

    --text:#172033;
    --muted:#6d7889;

    --border:#e3e8ef;

    --background:#f5f8fc;

    --white:#ffffff;

    --danger:#c92a42;

    --success:#169b62;
}


* {

    margin:0;
    padding:0;

    box-sizing:border-box;
}


html,
body {

    min-height:100%;
}


body {

    font-family:
        'DM Sans',
        sans-serif;

    background:
        var(--background);

    color:
        var(--text);
}


a {

    color:inherit;

    text-decoration:none;
}


button,
input {

    font-family:inherit;
}


/*
|--------------------------------------------------------------------------
| MAIN PAGE
|--------------------------------------------------------------------------
*/

.login-page {

    min-height:100vh;

    display:grid;

    grid-template-columns:
        minmax(450px,1.08fr)
        minmax(440px,.92fr);
}


/*
|--------------------------------------------------------------------------
| LEFT TRAVEL VISUAL
|--------------------------------------------------------------------------
*/

.login-visual {

    min-height:100vh;

    padding:52px 58px;

    position:relative;

    overflow:hidden;

    display:flex;

    flex-direction:column;

    justify-content:space-between;

    color:white;

    background:

        linear-gradient(
            120deg,
            rgba(3,18,34,.94),
            rgba(4,30,56,.66)
        ),

        url(
            'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1800&q=90'
        )

        center/cover
        no-repeat;
}


.login-visual::after {

    content:"";

    position:absolute;

    width:500px;
    height:500px;

    border-radius:50%;

    right:-220px;
    bottom:-240px;

    background:
        rgba(11,116,255,.17);

    pointer-events:none;
}


/*
|--------------------------------------------------------------------------
| LOGO
|--------------------------------------------------------------------------
*/

.logo {

    display:inline-flex;

    align-items:center;

    gap:11px;

    width:max-content;

    position:relative;

    z-index:2;

    font-family:
        'Manrope',
        sans-serif;

    font-weight:800;

    font-size:23px;

    letter-spacing:-.4px;
}


.logo-icon {

    width:45px;
    height:45px;

    display:grid;

    place-items:center;

    border-radius:13px;

    color:white;

    background:
        linear-gradient(
            135deg,
            #0b74ff,
            #00b6ff
        );

    box-shadow:
        0 10px 28px
        rgba(11,116,255,.25);

    transform:
        rotate(-5deg);
}


.logo span {

    color:#62b5ff;
}


/*
|--------------------------------------------------------------------------
| VISUAL CONTENT
|--------------------------------------------------------------------------
*/

.visual-content {

    max-width:650px;

    position:relative;

    z-index:2;
}


.visual-badge {

    display:inline-flex;

    align-items:center;

    gap:8px;

    padding:8px 13px;

    margin-bottom:20px;

    border-radius:50px;

    border:
        1px solid
        rgba(255,255,255,.18);

    background:
        rgba(255,255,255,.1);

    backdrop-filter:
        blur(8px);

    font-size:12px;

    font-weight:700;
}


.visual-content h1 {

    max-width:650px;

    margin-bottom:20px;

    font-family:
        'Manrope',
        sans-serif;

    font-size:
        clamp(
            42px,
            5vw,
            66px
        );

    line-height:1.07;

    letter-spacing:-2.2px;
}


.visual-content h1 span {

    display:block;

    color:#63b6ff;
}


.visual-content p {

    max-width:560px;

    color:
        rgba(
            255,
            255,
            255,
            .78
        );

    font-size:16px;

    line-height:1.75;
}


/*
|--------------------------------------------------------------------------
| VISUAL FEATURES
|--------------------------------------------------------------------------
*/

.visual-features {

    display:flex;

    flex-wrap:wrap;

    gap:10px;

    margin-top:27px;
}


.visual-feature {

    display:flex;

    align-items:center;

    gap:7px;

    padding:8px 11px;

    border-radius:9px;

    background:
        rgba(255,255,255,.08);

    border:
        1px solid
        rgba(255,255,255,.11);

    color:
        rgba(255,255,255,.83);

    font-size:11px;

    font-weight:600;
}


.visual-feature i {

    color:#6fc1ff;
}


.visual-footer {

    position:relative;

    z-index:2;

    color:
        rgba(
            255,
            255,
            255,
            .58
        );

    font-size:11px;
}


/*
|--------------------------------------------------------------------------
| LOGIN SIDE
|--------------------------------------------------------------------------
*/

.login-area {

    min-height:100vh;

    display:grid;

    place-items:center;

    padding:42px;

    background:white;
}


.login-container {

    width:100%;

    max-width:445px;
}


.mobile-logo {

    display:none;

    margin-bottom:40px;

    color:
        var(--navy);
}


.mobile-logo span {

    color:
        var(--primary);
}


/*
|--------------------------------------------------------------------------
| LOGIN HEADER
|--------------------------------------------------------------------------
*/

.login-header {

    margin-bottom:28px;
}


.login-header h2 {

    margin-bottom:8px;

    color:
        var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:35px;

    letter-spacing:-1.2px;
}


.login-header p {

    color:
        var(--muted);

    font-size:14px;

    line-height:1.65;
}


/*
|--------------------------------------------------------------------------
| LOGIN TYPE INFO
|--------------------------------------------------------------------------
*/

.login-info {

    display:flex;

    align-items:center;

    gap:9px;

    margin-bottom:20px;

    padding:10px 12px;

    border:
        1px solid
        #dcecff;

    border-radius:10px;

    background:#f5faff;

    color:#50647c;

    font-size:11px;

    line-height:1.5;
}


.login-info i {

    color:
        var(--primary);
}


/*
|--------------------------------------------------------------------------
| ERROR
|--------------------------------------------------------------------------
*/

.alert {

    display:flex;

    align-items:flex-start;

    gap:10px;

    padding:13px 14px;

    margin-bottom:20px;

    border:
        1px solid
        #ffd8de;

    border-radius:11px;

    background:#fff1f3;

    color:
        var(--danger);

    font-size:13px;

    line-height:1.5;
}

.alert.success {

    border-color:#b7ebcf;

    background:#ecfbf3;

    color:#087b4d;
}


/*
|--------------------------------------------------------------------------
| FORM
|--------------------------------------------------------------------------
*/

.field {

    margin-bottom:18px;
}


.field label {

    display:block;

    margin-bottom:8px;

    color:#344054;

    font-size:13px;

    font-weight:700;
}


.input-wrap {

    position:relative;
}


.input-icon {

    position:absolute;

    left:16px;
    top:50%;

    transform:
        translateY(-50%);

    color:#8a96a7;

    pointer-events:none;
}


.input-wrap input {

    width:100%;

    height:56px;

    padding:
        0
        48px
        0
        46px;

    border:
        1px solid
        var(--border);

    border-radius:12px;

    outline:none;

    background:white;

    color:
        var(--text);

    font-size:15px;

    transition:.2s;
}


.input-wrap input:hover {

    border-color:#ccd5e1;
}


.input-wrap input:focus {

    border-color:
        var(--primary);

    box-shadow:
        0
        0
        0
        3px
        rgba(
            11,
            116,
            255,
            .09
        );
}


.password-button {

    position:absolute;

    right:12px;
    top:50%;

    transform:
        translateY(-50%);

    width:38px;
    height:38px;

    display:grid;

    place-items:center;

    border:0;

    border-radius:8px;

    background:transparent;

    color:#778294;

    cursor:pointer;
}


.password-button:hover {

    background:#f4f7fa;

    color:
        var(--primary);
}


/*
|--------------------------------------------------------------------------
| OPTIONS
|--------------------------------------------------------------------------
*/

.form-options {

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:15px;

    margin-bottom:22px;

    font-size:13px;
}


.remember {

    display:flex;

    align-items:center;

    gap:8px;

    color:#596577;

    cursor:pointer;
}


.remember input {

    width:16px;
    height:16px;

    accent-color:
        var(--primary);
}


.forgot {

    color:
        var(--primary);

    font-weight:700;
}


.forgot:hover {

    color:
        var(--primary-dark);
}


/*
|--------------------------------------------------------------------------
| LOGIN BUTTON
|--------------------------------------------------------------------------
*/

.login-button {

    width:100%;

    min-height:56px;

    border:0;

    border-radius:12px;

    display:flex;

    align-items:center;

    justify-content:center;

    gap:9px;

    background:
        var(--primary);

    color:white;

    font-size:15px;

    font-weight:700;

    cursor:pointer;

    box-shadow:
        0
        12px
        28px
        rgba(
            11,
            116,
            255,
            .22
        );

    transition:.2s;
}


.login-button:hover {

    background:
        var(--primary-dark);

    transform:
        translateY(-1px);
}


.login-button:active {

    transform:
        translateY(0);
}


/*
|--------------------------------------------------------------------------
| DIVIDER
|--------------------------------------------------------------------------
*/

.divider {

    display:flex;

    align-items:center;

    gap:14px;

    margin:27px 0 21px;

    color:#98a2b3;

    font-size:10px;

    font-weight:700;

    letter-spacing:.6px;
}


.divider::before,
.divider::after {

    content:"";

    height:1px;

    flex:1;

    background:
        var(--border);
}


/*
|--------------------------------------------------------------------------
| REGISTER
|--------------------------------------------------------------------------
*/

.register-text {

    text-align:center;

    color:#687386;

    font-size:13px;
}


.register-text a {

    color:
        var(--primary);

    font-weight:700;
}


.register-text a:hover {

    color:
        var(--primary-dark);
}


/*
|--------------------------------------------------------------------------
| SECONDARY ACTIONS
|--------------------------------------------------------------------------
*/

.secondary-actions {

    display:grid;

    grid-template-columns:
        repeat(2,1fr);

    gap:10px;

    margin-top:22px;
}


.secondary-action {

    min-height:45px;

    padding:0 12px;

    display:flex;

    align-items:center;

    justify-content:center;

    gap:7px;

    border:
        1px solid
        var(--border);

    border-radius:10px;

    background:white;

    color:#5d6879;

    font-size:11px;

    font-weight:700;

    transition:.2s;
}


.secondary-action:hover {

    border-color:#b9d7ff;

    background:#f8fbff;

    color:
        var(--primary);
}


/*
|--------------------------------------------------------------------------
| SECURITY
|--------------------------------------------------------------------------
*/

.security {

    display:flex;

    justify-content:center;

    align-items:center;

    gap:7px;

    margin-top:25px;

    color:#98a2b3;

    font-size:10px;
}


.security i {

    color:
        var(--success);
}


/*
|--------------------------------------------------------------------------
| RESPONSIVE
|--------------------------------------------------------------------------
*/

@media(max-width:950px) {

    .login-page {

        grid-template-columns:1fr;
    }


    .login-visual {

        display:none;
    }


    .login-area {

        min-height:100vh;

        padding:
            35px
            25px;
    }


    .mobile-logo {

        display:flex;
    }
}


@media(max-width:500px) {

    .login-area {

        display:block;

        padding:
            26px
            19px
            35px;
    }


    .login-container {

        max-width:none;
    }


    .mobile-logo {

        margin-bottom:48px;
    }


    .login-header h2 {

        font-size:30px;
    }


    .form-options {

        align-items:flex-start;
    }


    .secondary-actions {

        grid-template-columns:1fr;
    }
}


/* GOOGLE OAUTH 2.0 BUTTON */
.google-oauth-wrap{
    margin-top:18px;
}
.google-oauth-divider{
    display:flex;
    align-items:center;
    gap:12px;
    margin:20px 0 14px;
    color:#98a2b3;
    font-size:11px;
    font-weight:700;
    letter-spacing:.5px;
}
.google-oauth-divider::before,
.google-oauth-divider::after{
    content:"";
    height:1px;
    flex:1;
    background:var(--border);
}
.google-oauth-button{
    width:100%;
    min-height:54px;
    border:1px solid #ea4335;
    border-radius:12px;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:10px;
    background:#ea4335;
    color:#fff;
    font-size:14px;
    font-weight:700;
    transition:.2s;
}
.google-oauth-button:hover{
    border-color:#c9342a;
    background:#c9342a;
    transform:translateY(-1px);
}
.google-oauth-button .google-g{
    width:22px;
    height:22px;
    border-radius:50%;
    display:grid;
    place-items:center;
    font-weight:800;
    color:#4285f4;
    background:#fff;
    box-shadow:0 0 0 1px #e2e7ee;
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}



/* V24.65: General Settings logo in the marked login brand area only. */
.logo.has-uploaded-logo{
    min-height:48px;
}
.logo .ts-login-brand-logo{
    display:block;
    width:auto;
    height:auto;
    max-width:255px;
    max-height:58px;
    object-fit:contain;
    object-position:left center;
}
.mobile-logo .ts-login-brand-logo{
    max-width:210px;
    max-height:48px;
}
</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>


<body>


<div class="login-page">


    <!-- =====================================================
         LEFT TRAVEL SECTION
    ====================================================== -->

    <section class="login-visual">


        <a
            href="<?= e(BASE_URL); ?>"
            class="logo<?= $siteLogoUrl !== '' ? ' has-uploaded-logo' : ''; ?>"
        >

            <?php if ($siteLogoUrl !== ''): ?>
                <img
                    src="<?= e($siteLogoUrl); ?>"
                    alt="<?= e($siteName); ?>"
                    class="ts-login-brand-logo"
                >
            <?php else: ?>
                <div class="logo-icon">
                    <i class="fa-solid fa-plane"></i>
                </div>
                TRAV<span>SCOPE</span>
            <?php endif; ?>

        </a>


        <div class="visual-content">


            <div class="visual-badge">

                <i class="fa-solid fa-earth-americas"></i>

                Explore • Experience • Discover

            </div>


            <h1>

                Your world of travel

                <span>
                    starts here.
                </span>

            </h1>


            <p>

                Sign in to manage your journeys,
                bookings and travel plans while discovering
                unforgettable destinations around the world.

            </p>


            <div class="visual-features">


                <div class="visual-feature">

                    <i class="fa-solid fa-shield-halved"></i>

                    Secure Account

                </div>


                <div class="visual-feature">

                    <i class="fa-solid fa-calendar-check"></i>

                    Manage Bookings

                </div>


                <div class="visual-feature">

                    <i class="fa-solid fa-earth-asia"></i>

                    Worldwide Travel

                </div>


            </div>


        </div>


        <div class="visual-footer">

            © <?= date('Y'); ?>
            TRAVSCOPE.COM —
            Worldwide Travel Experiences

        </div>


    </section>


    <!-- =====================================================
         LOGIN SECTION
    ====================================================== -->

    <section class="login-area">


        <div class="login-container">


            <!-- MOBILE LOGO -->

            <a
                href="<?= e(BASE_URL); ?>"
                class="logo mobile-logo<?= $siteLogoUrl !== '' ? ' has-uploaded-logo' : ''; ?>"
            >

                <?php if ($siteLogoUrl !== ''): ?>
                    <img
                        src="<?= e($siteLogoUrl); ?>"
                        alt="<?= e($siteName); ?>"
                        class="ts-login-brand-logo"
                    >
                <?php else: ?>
                    <div class="logo-icon">
                        <i class="fa-solid fa-plane"></i>
                    </div>
                    TRAV<span>SCOPE</span>
                <?php endif; ?>

            </a>


            <!-- HEADER -->

            <div class="login-header">

                <h2>
                    Welcome back
                </h2>

                <p>
                    Sign in securely to continue to your
                    TRAVSCOPE account.
                </p>

            </div>


            <!-- LOGIN INFO -->

            <div class="login-info">

                <i class="fa-solid fa-circle-info"></i>

                <span>
                    <?php if (defined('MAINTENANCE_MODE_ACTIVE') && MAINTENANCE_MODE_ACTIVE): ?>
                        Maintenance mode is active. Customer access is temporarily unavailable.
                        Administrators can sign in here with their administrator email/mobile and password.
                    <?php else: ?>
                        Use your registered email address or mobile number to sign in.
                    <?php endif; ?>
                </span>

            </div>


            <!-- ERROR -->

            <?php if ($error !== ''): ?>

                <div
                    class="alert"
                    role="alert"
                >

                    <i class="fa-solid fa-circle-exclamation"></i>

                    <span>
                        <?= e($error); ?>
                    </span>

                </div>

            <?php endif; ?>


            <?php if ($success !== ''): ?>

                <div
                    class="alert success"
                    role="status"
                >

                    <i class="fa-solid fa-circle-check"></i>

                    <span>
                        <?= e($success); ?>
                    </span>

                </div>

            <?php endif; ?>


            <div class="google-oauth-wrap">

                <a
                    href="<?= e(BASE_URL . 'google-auth.php'); ?>"
                    class="google-oauth-button"
                >
                    <span class="google-g">G</span>
                    Continue with Google
                </a>

                <div class="google-oauth-divider">
                    OR SIGN IN WITH EMAIL / MOBILE
                </div>

            </div>


            <!-- =================================================
                 LOGIN FORM
            ================================================== -->

            <form
                method="POST"
                action=""
                autocomplete="on"
            >


                <!-- CSRF -->

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e($csrfToken); ?>"
                >


                <!-- EMAIL / MOBILE -->

                <div class="field">

                    <label for="login">

                        Email Address or Mobile Number

                    </label>


                    <div class="input-wrap">


                        <i
                            class="fa-solid fa-user input-icon"
                        ></i>


                        <input
                            type="text"
                            id="login"
                            name="login"
                            value="<?= e($login); ?>"
                            placeholder="Email or 10-digit mobile number"
                            autocomplete="username"
                            maxlength="190"
                            inputmode="text"
                            required
                            autofocus
                        >


                    </div>

                </div>


                <!-- PASSWORD -->

                <div class="field">

                    <label for="password">

                        Password

                    </label>


                    <div class="input-wrap">


                        <i
                            class="fa-solid fa-lock input-icon"
                        ></i>


                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                            minlength="8"
                            required
                        >


                        <button
                            type="button"
                            class="password-button"
                            id="passwordToggle"
                            aria-label="Show password"
                            title="Show password"
                        >

                            <i
                                class="fa-regular fa-eye"
                                id="passwordIcon"
                            ></i>

                        </button>


                    </div>

                </div>


                <!-- OPTIONS -->

                <div class="form-options">


                    <label class="remember">

                        <input
                            type="checkbox"
                            name="remember"
                            value="1"
                            <?= $remember ? 'checked' : ''; ?>
                        >

                        Remember me

                    </label>


                    <a
                        href="<?= e(BASE_URL); ?>forgot-password.php"
                        class="forgot"
                    >

                        Forgot password?

                    </a>


                </div>


                <!-- SIGN IN -->

                <button
                    type="submit"
                    class="login-button"
                    id="loginButton"
                >

                    <span>
                        Sign In
                    </span>

                    <i class="fa-solid fa-arrow-right"></i>

                </button>


            </form>



<!-- REGISTER -->

            <div class="divider">

                NEW TO TRAVSCOPE?

            </div>


            <p class="register-text">

                Don't have an account?

                <a
                    href="<?= e(BASE_URL); ?>register.php"
                >

                    Create your account

                </a>

            </p>


            <!-- OTHER ACTIONS -->

            <div class="secondary-actions">


                <a
                    href="<?= e(BASE_URL); ?>"
                    class="secondary-action"
                >

                    <i class="fa-solid fa-house"></i>

                    Home

                </a>


                <a
                    href="<?= e(BASE_URL); ?>contact.php"
                    class="secondary-action"
                >

                    <i class="fa-solid fa-headset"></i>

                    Need Help?

                </a>


            </div>


            <!-- SECURITY -->

            <div class="security">

                <i class="fa-solid fa-shield-halved"></i>

                Secure login protected by TRAVSCOPE.COM

            </div>


        </div>


    </section>


</div>


<script>

/*
|--------------------------------------------------------------------------
| PASSWORD SHOW / HIDE
|--------------------------------------------------------------------------
*/

const passwordToggle =
    document.getElementById(
        'passwordToggle'
    );

const password =
    document.getElementById(
        'password'
    );

const passwordIcon =
    document.getElementById(
        'passwordIcon'
    );


if (
    passwordToggle
    &&
    password
    &&
    passwordIcon
) {

    passwordToggle.addEventListener(
        'click',
        function () {

            const showing =
                password.type ===
                'text';


            password.type =
                showing
                    ? 'password'
                    : 'text';


            passwordIcon.classList.toggle(
                'fa-eye',
                showing
            );


            passwordIcon.classList.toggle(
                'fa-eye-slash',
                !showing
            );


            passwordToggle.setAttribute(
                'aria-label',
                showing
                    ? 'Show password'
                    : 'Hide password'
            );
        }
    );
}


/*
|--------------------------------------------------------------------------
| PREVENT DOUBLE SUBMISSION
|--------------------------------------------------------------------------
*/

const loginForm =
    document.querySelector(
        'form'
    );

const loginButton =
    document.getElementById(
        'loginButton'
    );


if (
    loginForm
    &&
    loginButton
) {

    loginForm.addEventListener(
        'submit',
        function () {

            loginButton.disabled =
                true;


            loginButton.innerHTML =
                '<i class="fa-solid fa-circle-notch fa-spin"></i> Signing In...';
        }
    );
}

</script>



<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>

</html>