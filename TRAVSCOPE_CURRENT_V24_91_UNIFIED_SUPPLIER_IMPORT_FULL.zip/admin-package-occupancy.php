<?php
/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| STEP 08 - SMART OCCUPANCY PRICING
|--------------------------------------------------------------------------
| Per travel-date + 3/4/5-star pricing for:
| Twin/Double, Triple, Single, Child With Bed, Child Without Bed, Infant.
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';

if (empty($_SESSION['admin_id'])) {
    redirect(BASE_URL . 'admin-login.php');
}

$adminId = (int)$_SESSION['admin_id'];

$stmt = $pdo->prepare("
    SELECT id,name,email,role,status
    FROM admins
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$adminId]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin || strtolower((string)$admin['status']) !== 'active') {
    unset($_SESSION['admin_id']);
    redirect(BASE_URL . 'admin-login.php');
}

if (empty($_SESSION['package_occupancy_csrf'])) {
    $_SESSION['package_occupancy_csrf'] = bin2hex(random_bytes(32));
}
$csrfToken = (string)$_SESSION['package_occupancy_csrf'];

$packageId = max(0, (int)($_GET['package_id'] ?? $_POST['package_id'] ?? 0));

if ($packageId <= 0) {
    http_response_code(400);
    exit('Package ID is required.');
}

$stmt = $pdo->prepare("
    SELECT
        p.*,
        d.name AS destination_name,
        d.country AS destination_country
    FROM packages p
    LEFT JOIN destinations d ON d.id = p.destination_id
    WHERE p.id = ?
    LIMIT 1
");
$stmt->execute([$packageId]);
$package = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$package) {
    http_response_code(404);
    exit('Package not found.');
}

function occMoneyValue($value): string
{
    if ($value === null || $value === '') return '';
    return number_format((float)$value, 2, '.', '');
}

function occNullablePrice($raw, string $label): ?float
{
    $raw = trim((string)$raw);
    if ($raw === '') return null;

    if (!is_numeric($raw)) {
        throw new RuntimeException($label . ' must be a valid number.');
    }

    $value = round((float)$raw, 2);

    if ($value < 0) {
        throw new RuntimeException($label . ' cannot be negative.');
    }

    return $value;
}

function normalizeOccupancyRows(array $source): array
{
    $fields = [
        'occ_valid_from',
        'occ_valid_to',
        'occ_star',
        'occ_twin',
        'occ_triple',
        'occ_single',
        'occ_child_with_bed',
        'occ_child_without_bed',
        'occ_infant',
        'occ_infant_age_to',
    ];

    $arrays = [];
    $count = 0;

    foreach ($fields as $field) {
        $arrays[$field] = is_array($source[$field] ?? null)
            ? $source[$field]
            : [];
        $count = max($count, count($arrays[$field]));
    }

    $rows = [];

    for ($i = 0; $i < $count; $i++) {
        $from = trim((string)($arrays['occ_valid_from'][$i] ?? ''));
        $to = trim((string)($arrays['occ_valid_to'][$i] ?? ''));
        $starRaw = trim((string)($arrays['occ_star'][$i] ?? ''));

        $hasAny = $from !== ''
            || $to !== ''
            || $starRaw !== ''
            || trim((string)($arrays['occ_twin'][$i] ?? '')) !== ''
            || trim((string)($arrays['occ_triple'][$i] ?? '')) !== ''
            || trim((string)($arrays['occ_single'][$i] ?? '')) !== ''
            || trim((string)($arrays['occ_child_with_bed'][$i] ?? '')) !== ''
            || trim((string)($arrays['occ_child_without_bed'][$i] ?? '')) !== ''
            || trim((string)($arrays['occ_infant'][$i] ?? '')) !== '';

        if (!$hasAny) continue;

        $star = (int)$starRaw;
        if (!in_array($star, [3,4,5], true)) {
            throw new RuntimeException('Every occupancy row must use 3, 4 or 5 Star.');
        }

        if (
            $from === ''
            || $to === ''
            || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)
            || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)
        ) {
            throw new RuntimeException('Every occupancy row needs valid From and To dates.');
        }

        if ($from > $to) {
            throw new RuntimeException('Occupancy pricing Valid From cannot be after Valid To.');
        }

        $infantAgeTo = max(0, min(5, (int)($arrays['occ_infant_age_to'][$i] ?? 2)));

        $row = [
            'valid_from' => $from,
            'valid_to' => $to,
            'star_category' => $star,
            'twin_price' => occNullablePrice($arrays['occ_twin'][$i] ?? '', 'Twin/Double price'),
            'triple_price' => occNullablePrice($arrays['occ_triple'][$i] ?? '', 'Triple price'),
            'single_price' => occNullablePrice($arrays['occ_single'][$i] ?? '', 'Single price'),
            'child_with_bed_price' => occNullablePrice($arrays['occ_child_with_bed'][$i] ?? '', 'Child With Bed price'),
            'child_without_bed_price' => occNullablePrice($arrays['occ_child_without_bed'][$i] ?? '', 'Child Without Bed price'),
            'infant_price' => occNullablePrice($arrays['occ_infant'][$i] ?? '', 'Infant price'),
            'infant_age_to' => $infantAgeTo,
        ];

        $hasAdult = false;
        foreach (['twin_price','triple_price','single_price'] as $field) {
            if ($row[$field] !== null && (float)$row[$field] > 0) {
                $hasAdult = true;
                break;
            }
        }

        if (!$hasAdult) {
            throw new RuntimeException(
                $star . ' Star row ' . $from . ' to ' . $to
                . ': enter at least one adult occupancy price.'
            );
        }

        $rows[] = $row;
    }

    usort($rows, static function(array $a, array $b): int {
        $cmp = strcmp($a['valid_from'], $b['valid_from']);
        if ($cmp !== 0) return $cmp;
        return $a['star_category'] <=> $b['star_category'];
    });

    // Do not allow overlapping periods within the same star category.
    foreach ([3,4,5] as $star) {
        $starRows = array_values(array_filter(
            $rows,
            static fn(array $row): bool => (int)$row['star_category'] === $star
        ));

        usort($starRows, static fn(array $a, array $b): int =>
            strcmp($a['valid_from'], $b['valid_from'])
        );

        for ($i = 1; $i < count($starRows); $i++) {
            if ($starRows[$i]['valid_from'] <= $starRows[$i-1]['valid_to']) {
                throw new RuntimeException(
                    $star . ' Star occupancy date periods cannot overlap.'
                );
            }
        }
    }

    return $rows;
}

function loadOccupancyRows(PDO $pdo, int $packageId): array
{
    $stmt = $pdo->prepare("
        SELECT *
        FROM package_occupancy_prices
        WHERE package_id = ?
        ORDER BY valid_from ASC, star_category ASC, sort_order ASC, id ASC
    ");
    $stmt->execute([$packageId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function buildOccupancySeed(PDO $pdo, int $packageId): array
{
    $legacy = $pdo->prepare("
        SELECT valid_from,valid_to,price_3_star,price_4_star,price_5_star
        FROM package_date_prices
        WHERE package_id = ?
        ORDER BY valid_from ASC,sort_order ASC,id ASC
    ");
    $legacy->execute([$packageId]);

    $child = $pdo->prepare("
        SELECT price
        FROM package_child_prices
        WHERE package_id = ?
        ORDER BY sort_order ASC,id ASC
        LIMIT 1
    ");
    $child->execute([$packageId]);
    $fallbackChild = $child->fetchColumn();
    $fallbackChild = $fallbackChild === false ? null : max(0, (float)$fallbackChild);

    $rows = [];

    foreach ($legacy->fetchAll(PDO::FETCH_ASSOC) as $period) {
        foreach ([3,4,5] as $star) {
            $field = 'price_' . $star . '_star';
            $base = $period[$field] ?? null;

            if ($base === null || (float)$base <= 0) continue;

            $rows[] = [
                'valid_from' => (string)$period['valid_from'],
                'valid_to' => (string)$period['valid_to'],
                'star_category' => $star,
                'twin_price' => (float)$base,
                'triple_price' => (float)$base,
                'single_price' => (float)$base,
                'child_with_bed_price' => $fallbackChild,
                'child_without_bed_price' => $fallbackChild,
                'infant_price' => 0.0,
                'infant_age_to' => 2,
            ];
        }
    }

    return $rows;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = (string)($_POST['csrf_token'] ?? '');

    if (!hash_equals($csrfToken, $token)) {
        $error = 'Security token expired. Refresh and try again.';
    } else {
        $action = (string)($_POST['action'] ?? 'save');

        if ($action === 'save') {
            try {
                $rows = normalizeOccupancyRows($_POST);

                if (!$rows) {
                    throw new RuntimeException(
                        'Add at least one occupancy pricing row before saving.'
                    );
                }

                $pdo->beginTransaction();

                $delete = $pdo->prepare("
                    DELETE FROM package_occupancy_prices
                    WHERE package_id = ?
                ");
                $delete->execute([$packageId]);

                $insert = $pdo->prepare("
                    INSERT INTO package_occupancy_prices
                    (
                        package_id,valid_from,valid_to,star_category,
                        twin_price,triple_price,single_price,
                        child_with_bed_price,child_without_bed_price,
                        infant_price,infant_age_to,sort_order
                    )
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                ");

                foreach ($rows as $index => $row) {
                    $insert->execute([
                        $packageId,
                        $row['valid_from'],
                        $row['valid_to'],
                        $row['star_category'],
                        $row['twin_price'],
                        $row['triple_price'],
                        $row['single_price'],
                        $row['child_with_bed_price'],
                        $row['child_without_bed_price'],
                        $row['infant_price'],
                        $row['infant_age_to'],
                        $index + 1,
                    ]);
                }

                $pdo->commit();

                $_SESSION['package_occupancy_success'] =
                    'Smart occupancy pricing saved successfully.';

                redirect(
                    BASE_URL
                    . 'admin-package-occupancy.php?package_id='
                    . $packageId
                );

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error = $e instanceof RuntimeException
                    ? $e->getMessage()
                    : 'Unable to save occupancy pricing.';
                error_log('Occupancy pricing save error: ' . $e->getMessage());
            }
        }
    }
}

if (!empty($_SESSION['package_occupancy_success'])) {
    $success = (string)$_SESSION['package_occupancy_success'];
    unset($_SESSION['package_occupancy_success']);
}

$rows = [];

try {
    $rows = loadOccupancyRows($pdo, $packageId);
} catch (Throwable $e) {
    $error = $error ?: 'Step 08 database table is not installed yet. Import the Step 08 SQL file first.';
}

$seedMode = isset($_GET['seed']) && $_GET['seed'] === '1';

if (!$rows && $seedMode && $error === '') {
    try {
        $rows = buildOccupancySeed($pdo, $packageId);
        if (!$rows) {
            $error = 'No existing date-wise package prices were found to build from.';
        }
    } catch (Throwable $e) {
        $error = 'Unable to build occupancy rows from existing pricing.';
    }
}

$hotelNames = [3 => '',4 => '',5 => ''];
try {
    $stmt = $pdo->prepare("
        SELECT star_category,hotel_name_snapshot
        FROM package_hotels
        WHERE package_id = ?
        ORDER BY id ASC
    ");
    $stmt->execute([$packageId]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $star = (int)$r['star_category'];
        if (isset($hotelNames[$star]) && $hotelNames[$star] === '') {
            $hotelNames[$star] = trim((string)$r['hotel_name_snapshot']);
        }
    }
} catch (Throwable $e) {
    // Step 06 may not be installed.
}

if (!$rows && !$seedMode) {
    $rows = [[
        'valid_from' => date('Y-m-d'),
        'valid_to' => date('Y-m-d', strtotime('+30 days')),
        'star_category' => 3,
        'twin_price' => '',
        'triple_price' => '',
        'single_price' => '',
        'child_with_bed_price' => '',
        'child_without_bed_price' => '',
        'infant_price' => '',
        'infant_age_to' => 2,
    ]];
}

?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Smart Occupancy Pricing | TRAVSCOPE Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Manrope:wght@600;700;800&display=swap" rel="stylesheet">
<style>
:root{--blue:#2563eb;--navy:#12243b;--muted:#718096;--border:#dde6ef;--bg:#f5f8fc;--green:#0b9468;--red:#c43b55}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:#18283d;font-family:'DM Sans',sans-serif}
.top{background:#fff;border-bottom:1px solid var(--border);position:sticky;top:0;z-index:30}
.top-inner{max-width:1500px;margin:auto;padding:14px 22px;display:flex;align-items:center;justify-content:space-between;gap:12px}
.brand{font:800 20px/1 'Manrope',sans-serif;color:var(--navy)}.brand span{color:var(--blue)}
.actions{display:flex;gap:8px;flex-wrap:wrap}.btn{border:0;border-radius:10px;padding:10px 13px;font-weight:800;font-size:12px;text-decoration:none;cursor:pointer;display:inline-flex;align-items:center;gap:7px}
.btn-light{background:#eef3f8;color:#27384f}.btn-primary{background:linear-gradient(135deg,#2563eb,#3877f5);color:#fff}.btn-green{background:#e9faf4;color:#087a56;border:1px solid #c8efdf}
.wrap{max-width:1500px;margin:20px auto;padding:0 22px}
.hero{background:linear-gradient(135deg,#132841,#1e3a5c);color:#fff;border-radius:18px;padding:22px;margin-bottom:16px;box-shadow:0 15px 35px rgba(18,40,65,.12)}
.hero h1{margin:0 0 8px;font:800 24px/1.2 'Manrope',sans-serif}.hero p{margin:0;color:#d9e8f8;font-size:13px}.chips{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}.chip{background:rgba(255,255,255,.1);padding:7px 9px;border-radius:999px;font-size:10px;font-weight:800}
.alert{padding:12px 14px;border-radius:12px;margin-bottom:14px;font-size:12px;font-weight:700}.alert-error{background:#fff0f3;color:#a8233e;border:1px solid #ffd4dd}.alert-success{background:#eafaf4;color:#087a56;border:1px solid #c8efdf}
.card{background:#fff;border:1px solid var(--border);border-radius:16px;overflow:hidden;box-shadow:0 8px 25px rgba(15,35,60,.05)}
.card-head{padding:16px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:10px}.card-head h2{margin:0;font:800 16px/1.2 'Manrope',sans-serif}.card-head p{margin:5px 0 0;color:var(--muted);font-size:11px}
.table-wrap{overflow:auto}
table{width:100%;border-collapse:collapse;min-width:1180px}
th{background:#f7f9fc;color:#607087;font-size:9px;letter-spacing:.05em;text-transform:uppercase;text-align:left;padding:10px;border-bottom:1px solid var(--border)}
td{padding:8px 7px;border-bottom:1px solid #edf2f7;vertical-align:middle}
input,select{width:100%;border:1px solid #d6e0eb;border-radius:8px;padding:9px 8px;font:700 11px/1 'DM Sans',sans-serif;background:#fff;color:#24364c}
input:focus,select:focus{outline:2px solid #dbe8ff;border-color:#7aa7f8}
.star{font-weight:900;color:#b77a00}.hotel{display:block;color:#8b98a8;font-size:8px;margin-top:3px;max-width:130px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.remove{border:0;border-radius:8px;background:#fff0f3;color:#bd2946;width:32px;height:32px;cursor:pointer;font-weight:900}
.foot{padding:15px 18px;display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap}.note{font-size:10px;color:#6d7b8e;max-width:780px;line-height:1.5}
.legend{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}.legend span{background:#fff;border:1px solid var(--border);border-radius:10px;padding:9px 10px;font-size:10px;font-weight:800}
@media(max-width:760px){.wrap,.top-inner{padding-left:10px;padding-right:10px}.hero{padding:16px}.hero h1{font-size:19px}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head>
<body>
<header class="top">
  <div class="top-inner">
    <div class="brand">TRAV<span>SCOPE</span> · OCCUPANCY PRICING</div>
    <div class="actions">
      <a class="btn btn-light" href="<?= e(BASE_URL . 'admin-packages.php?edit=' . $packageId . '#package-form'); ?>">← Package Editor</a>
      <a class="btn btn-light" href="<?= e(BASE_URL . 'admin-packages.php'); ?>">All Packages</a>
    </div>
  </div>
</header>

<main class="wrap">
  <section class="hero">
    <h1><?= e((string)$package['title']); ?></h1>
    <p>
      <?= e((string)($package['destination_name'] ?? '')); ?>
      <?= !empty($package['destination_country']) ? ' · ' . e((string)$package['destination_country']) : ''; ?>
      · <?= (int)$package['duration_days']; ?>D / <?= (int)$package['duration_nights']; ?>N
      · Code <?= e((string)($package['package_code'] ?: 'Auto')); ?>
    </p>
    <div class="chips">
      <span class="chip">Twin / Double Sharing</span>
      <span class="chip">Triple Sharing</span>
      <span class="chip">Single Occupancy</span>
      <span class="chip">Child With Bed</span>
      <span class="chip">Child Without Bed</span>
      <span class="chip">Infant</span>
    </div>
  </section>

  <?php if ($error !== ''): ?>
    <div class="alert alert-error"><?= e($error); ?></div>
  <?php endif; ?>

  <?php if ($success !== ''): ?>
    <div class="alert alert-success"><?= e($success); ?></div>
  <?php endif; ?>

  <div class="legend">
    <span>Adult prices are per person.</span>
    <span>Infant fare applies up to the configured infant age.</span>
    <span>Blank child/infant fields fall back to the older age-price system.</span>
    <span>Old packages continue working without occupancy rows.</span>
  </div>

  <section class="card">
    <div class="card-head">
      <div>
        <h2>Smart Occupancy Matrix</h2>
        <p>Use separate rows for each date period and hotel category. Date periods may not overlap within the same star category.</p>
      </div>
      <div class="actions">
        <a class="btn btn-green" href="<?= e(BASE_URL . 'admin-package-occupancy.php?package_id=' . $packageId . '&seed=1'); ?>">Build From Current Prices</a>
        <button class="btn btn-light" type="button" id="addRow">+ Add Row</button>
      </div>
    </div>

    <form method="post" id="occupancyForm">
      <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
      <input type="hidden" name="package_id" value="<?= $packageId; ?>">
      <input type="hidden" name="action" value="save">

      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Valid From</th>
              <th>Valid To</th>
              <th>Category</th>
              <th>Twin / Double</th>
              <th>Triple</th>
              <th>Single</th>
              <th>Child With Bed</th>
              <th>Child Without Bed</th>
              <th>Infant</th>
              <th>Infant Age ≤</th>
              <th></th>
            </tr>
          </thead>
          <tbody id="rows">
          <?php foreach ($rows as $row): ?>
            <?php $star = (int)($row['star_category'] ?? 3); ?>
            <tr class="pricing-row">
              <td><input type="date" name="occ_valid_from[]" required value="<?= e((string)($row['valid_from'] ?? '')); ?>"></td>
              <td><input type="date" name="occ_valid_to[]" required value="<?= e((string)($row['valid_to'] ?? '')); ?>"></td>
              <td>
                <select name="occ_star[]" required>
                  <?php foreach ([3,4,5] as $s): ?>
                    <option value="<?= $s; ?>" <?= $star === $s ? 'selected' : ''; ?>><?= $s; ?>★</option>
                  <?php endforeach; ?>
                </select>
                <?php if (!empty($hotelNames[$star])): ?>
                  <span class="hotel"><?= e($hotelNames[$star]); ?></span>
                <?php endif; ?>
              </td>
              <td><input type="number" min="0" step="0.01" name="occ_twin[]" value="<?= e(occMoneyValue($row['twin_price'] ?? '')); ?>" placeholder="Per adult"></td>
              <td><input type="number" min="0" step="0.01" name="occ_triple[]" value="<?= e(occMoneyValue($row['triple_price'] ?? '')); ?>" placeholder="Per adult"></td>
              <td><input type="number" min="0" step="0.01" name="occ_single[]" value="<?= e(occMoneyValue($row['single_price'] ?? '')); ?>" placeholder="Per adult"></td>
              <td><input type="number" min="0" step="0.01" name="occ_child_with_bed[]" value="<?= e(occMoneyValue($row['child_with_bed_price'] ?? '')); ?>" placeholder="Per child"></td>
              <td><input type="number" min="0" step="0.01" name="occ_child_without_bed[]" value="<?= e(occMoneyValue($row['child_without_bed_price'] ?? '')); ?>" placeholder="Per child"></td>
              <td><input type="number" min="0" step="0.01" name="occ_infant[]" value="<?= e(occMoneyValue($row['infant_price'] ?? '')); ?>" placeholder="Per infant"></td>
              <td><input type="number" min="0" max="5" step="1" name="occ_infant_age_to[]" value="<?= (int)($row['infant_age_to'] ?? 2); ?>"></td>
              <td><button type="button" class="remove" title="Remove row">×</button></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="foot">
        <div class="note">
          “Build From Current Prices” copies your existing date-wise 3★/4★/5★ amount into Twin, Triple and Single as a starting point only. Review the amounts before saving. It does not invent a single-supplement or triple-sharing discount.
        </div>
        <button class="btn btn-primary" type="submit">Save Smart Occupancy Pricing</button>
      </div>
    </form>
  </section>
</main>

<template id="rowTemplate">
<tr class="pricing-row">
  <td><input type="date" name="occ_valid_from[]" required value="<?= e(date('Y-m-d')); ?>"></td>
  <td><input type="date" name="occ_valid_to[]" required value="<?= e(date('Y-m-d', strtotime('+30 days'))); ?>"></td>
  <td><select name="occ_star[]" required><option value="3">3★</option><option value="4">4★</option><option value="5">5★</option></select></td>
  <td><input type="number" min="0" step="0.01" name="occ_twin[]" placeholder="Per adult"></td>
  <td><input type="number" min="0" step="0.01" name="occ_triple[]" placeholder="Per adult"></td>
  <td><input type="number" min="0" step="0.01" name="occ_single[]" placeholder="Per adult"></td>
  <td><input type="number" min="0" step="0.01" name="occ_child_with_bed[]" placeholder="Per child"></td>
  <td><input type="number" min="0" step="0.01" name="occ_child_without_bed[]" placeholder="Per child"></td>
  <td><input type="number" min="0" step="0.01" name="occ_infant[]" placeholder="Per infant"></td>
  <td><input type="number" min="0" max="5" step="1" name="occ_infant_age_to[]" value="2"></td>
  <td><button type="button" class="remove" title="Remove row">×</button></td>
</tr>
</template>

<script>
const rows = document.getElementById('rows');
const template = document.getElementById('rowTemplate');

document.getElementById('addRow')?.addEventListener('click', function(){
    rows.appendChild(template.content.cloneNode(true));
});

rows?.addEventListener('click', function(event){
    const button = event.target.closest('.remove');
    if (!button) return;
    const row = button.closest('.pricing-row');
    if (!row) return;

    if (rows.querySelectorAll('.pricing-row').length <= 1) {
        row.querySelectorAll('input').forEach(input => {
            if (input.name === 'occ_infant_age_to[]') input.value = '2';
            else if (input.type !== 'date') input.value = '';
        });
        return;
    }

    row.remove();
});
</script>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
