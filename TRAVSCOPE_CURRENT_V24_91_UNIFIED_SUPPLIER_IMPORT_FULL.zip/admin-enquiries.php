<?php

require_once __DIR__ . '/config.php';

$crmFunctionsFile = __DIR__ . '/crm-functions.php';
if (is_file($crmFunctionsFile)) { require_once $crmFunctionsFile; }

/*
|--------------------------------------------------------------------------
| ADMIN AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_id'])) {

    header(
        'Location: '
        . BASE_URL
        . 'admin-login.php'
    );

    exit;
}

$adminId = (int)$_SESSION['admin_id'];


/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function adminEnquiryStatusLabel(string $status): string
{
    return match ($status) {

        'new'       => 'New',
        'contacted' => 'Contacted',
        'follow_up' => 'Follow Up',
        'converted' => 'Converted',
        'closed'    => 'Closed',

        default     => ucfirst(
            str_replace('_', ' ', $status)
        )
    };
}


function adminEnquiryStatusClass(string $status): string
{
    return match ($status) {

        'new'       => 'status-new',
        'contacted' => 'status-contacted',
        'follow_up' => 'status-follow',
        'converted' => 'status-converted',
        'closed'    => 'status-closed',

        default     => 'status-closed'
    };
}


function adminEnquiryDate($date): string
{
    if (empty($date)) {
        return '—';
    }

    $time = strtotime((string)$date);

    if (!$time) {
        return '—';
    }

    return date('d M Y, h:i A', $time);
}


function adminTravelDate($date): string
{
    if (empty($date)) {
        return 'Flexible';
    }

    $time = strtotime((string)$date);

    return $time
        ? date('d M Y', $time)
        : 'Flexible';
}


function adminEnquiryCategoryOptions(): array
{
    return [
        'Complete Holiday Package',
        'Visa Only',
        'Flight Only',
        'Hotel Only',
        'Flight + Hotel',
        'Honeymoon',
        'Family Holiday',
        'Group Tour',
        'Corporate / Business Travel',
        'Cruise',
        'Train / Transport',
        'Travel Insurance',
        'Other Travel Requirement'
    ];
}


function adminEnquiryCategoryFromMessage(?string $message): string
{
    $message = (string)$message;

    if (
        preg_match(
            '/(?:^|\R)Enquiry Category:\s*([^\r\n]+)/i',
            $message,
            $match
        )
    ) {
        $category = trim((string)($match[1] ?? ''));

        if (
            in_array(
                $category,
                adminEnquiryCategoryOptions(),
                true
            )
        ) {
            return $category;
        }
    }

    return 'General / Legacy';
}


function adminEnquiryCategoryClass(string $category): string
{
    return match ($category) {
        'Visa Only' => 'category-visa',
        'Flight Only' => 'category-flight',
        'Hotel Only' => 'category-hotel',
        'Flight + Hotel' => 'category-flight-hotel',
        'Complete Holiday Package' => 'category-package',
        'Honeymoon' => 'category-honeymoon',
        'Family Holiday' => 'category-family',
        'Group Tour' => 'category-group',
        'Corporate / Business Travel' => 'category-corporate',
        'Cruise' => 'category-cruise',
        'Train / Transport' => 'category-transport',
        'Travel Insurance' => 'category-insurance',
        'Other Travel Requirement' => 'category-other',
        default => 'category-legacy'
    };
}


function adminMoney($amount): string
{
    if (
        $amount === null ||
        $amount === ''
    ) {
        return 'Not specified';
    }

    return '₹' . number_format(
        (float)$amount,
        0
    );
}


/*
|--------------------------------------------------------------------------
| ENQUIRY -> BOOKING CONVERSION HELPER
|--------------------------------------------------------------------------
| Creates the real booking record used by Admin Bookings and My Bookings.
| Existing booking pages remain unchanged.
*/

function adminCreateBookingFromEnquiry(
    PDO $pdo,
    int $enquiryId
): int {

    $stmt = $pdo->prepare("
        SELECT
            e.id,
            e.package_id,
            e.name,
            e.email,
            e.mobile,
            e.destination,
            e.travel_date,
            e.adults,
            e.children,
            e.budget,
            e.message,
            e.status,

            p.sale_price AS package_sale_price,
            p.currency AS package_currency

        FROM enquiries e

        LEFT JOIN packages p
            ON p.id = e.package_id

        WHERE e.id = ?

        LIMIT 1
    ");

    $stmt->execute([$enquiryId]);

    $enquiry =
        $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$enquiry) {
        throw new RuntimeException(
            'Enquiry not found for booking conversion.'
        );
    }

    /*
    | Avoid duplicate booking creation if Admin submits Converted twice.
    | No schema change is required: match the core enquiry booking details.
    */
    $duplicateSql = "
        SELECT id
        FROM bookings
        WHERE customer_email = ?
          AND travel_date = ?
          AND adults = ?
          AND children = ?
    ";

    $duplicateParams = [
        (string)$enquiry['email'],
        (string)$enquiry['travel_date'],
        (int)$enquiry['adults'],
        (int)$enquiry['children']
    ];

    if (!empty($enquiry['package_id'])) {
        $duplicateSql .= " AND package_id = ?";
        $duplicateParams[] =
            (int)$enquiry['package_id'];
    } else {
        $duplicateSql .= " AND package_id IS NULL";
    }

    $duplicateSql .= "
        ORDER BY id DESC
        LIMIT 1
    ";

    $stmt =
        $pdo->prepare($duplicateSql);

    $stmt->execute($duplicateParams);

    $existingBookingId =
        (int)($stmt->fetchColumn() ?: 0);

    if ($existingBookingId > 0) {
        return $existingBookingId;
    }

    /*
    | Link the booking to a registered customer whenever the enquiry
    | email or normalized mobile belongs to a user account.
    */
    $userId = null;

    $email =
        mb_strtolower(
            trim(
                (string)$enquiry['email']
            )
        );

    $mobile =
        preg_replace(
            '/[^0-9]/',
            '',
            (string)$enquiry['mobile']
        );

    $mobileLast10 =
        strlen($mobile) >= 10
            ? substr($mobile, -10)
            : $mobile;

    if ($email !== '') {
        $stmt = $pdo->prepare("
            SELECT id
            FROM users
            WHERE LOWER(TRIM(email)) = ?
            ORDER BY id ASC
            LIMIT 1
        ");

        $stmt->execute([$email]);

        $matchedUserId =
            (int)($stmt->fetchColumn() ?: 0);

        if ($matchedUserId > 0) {
            $userId = $matchedUserId;
        }
    }

    if (
        $userId === null
        &&
        $mobileLast10 !== ''
    ) {
        $stmt = $pdo->prepare("
            SELECT id
            FROM users
            WHERE RIGHT(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    TRIM(COALESCE(mobile, '')),
                                    ' ',
                                    ''
                                ),
                                '-',
                                ''
                            ),
                            '(',
                            ''
                        ),
                        ')',
                        ''
                    ),
                    '+',
                    ''
                ),
                10
            ) = ?
            ORDER BY id ASC
            LIMIT 1
        ");

        $stmt->execute([
            $mobileLast10
        ]);

        $matchedUserId =
            (int)($stmt->fetchColumn() ?: 0);

        if ($matchedUserId > 0) {
            $userId = $matchedUserId;
        }
    }

    $totalAmount =
        $enquiry['budget'] !== null
        && $enquiry['budget'] !== ''
            ? (float)$enquiry['budget']
            : (float)($enquiry['package_sale_price'] ?? 0);

    $currency =
        trim(
            (string)(
                $enquiry['package_currency']
                ?? 'INR'
            )
        );

    if ($currency === '') {
        $currency = 'INR';
    }

    /*
    | Generate a booking number compatible with the existing booking pages.
    */
    do {
        $bookingNumber =
            'TS'
            . date('ymd')
            . strtoupper(
                substr(
                    bin2hex(
                        random_bytes(4)
                    ),
                    0,
                    6
                )
            );

        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM bookings
            WHERE booking_number = ?
        ");

        $stmt->execute([
            $bookingNumber
        ]);

    } while (
        (int)$stmt->fetchColumn() > 0
    );

    $stmt = $pdo->prepare("
        INSERT INTO bookings
        (
            booking_number,
            user_id,
            package_id,
            hotel_category,
            hotel_price,
            customer_name,
            customer_email,
            customer_mobile,
            travel_date,
            adults,
            children,
            total_amount,
            paid_amount,
            currency,
            booking_status,
            payment_status,
            special_request,
            created_at,
            updated_at
        )
        VALUES
        (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, NOW(), NOW()
        )
    ");

    $stmt->execute([
        $bookingNumber,
        $userId,
        !empty($enquiry['package_id'])
            ? (int)$enquiry['package_id']
            : null,
        null,
        0,
        (string)$enquiry['name'],
        (string)$enquiry['email'],
        (string)$enquiry['mobile'],
        (string)$enquiry['travel_date'],
        max(
            1,
            (int)$enquiry['adults']
        ),
        max(
            0,
            (int)$enquiry['children']
        ),
        $totalAmount,
        0,
        $currency,
        'pending',
        'unpaid',
        trim(
            (string)$enquiry['message']
        ) !== ''
            ? (string)$enquiry['message']
            : null
    ]);

    return (int)$pdo->lastInsertId();
}



/*
|--------------------------------------------------------------------------
| ENQUIRY ASSIGNMENT SYSTEM
|--------------------------------------------------------------------------
|
| Admin can assign:
| - one enquiry
| - selected enquiries
| - to a specific Manager / Staff
| - to All Managers / All Staff
|
| Manager can later reassign their enquiries to Staff.
|--------------------------------------------------------------------------
*/

$assignmentReady = false;

try {

    $assignmentColumns = [
        'assigned_user_id' => "
            ALTER TABLE enquiries
            ADD COLUMN assigned_user_id INT NULL
            AFTER admin_notes
        ",
        'assigned_role' => "
            ALTER TABLE enquiries
            ADD COLUMN assigned_role VARCHAR(20) NULL
            AFTER assigned_user_id
        ",
        'assigned_by_user_id' => "
            ALTER TABLE enquiries
            ADD COLUMN assigned_by_user_id INT NULL
            AFTER assigned_role
        ",
        'assigned_by_type' => "
            ALTER TABLE enquiries
            ADD COLUMN assigned_by_type VARCHAR(20) NULL
            AFTER assigned_by_user_id
        ",
        'assigned_at' => "
            ALTER TABLE enquiries
            ADD COLUMN assigned_at DATETIME NULL
            AFTER assigned_by_type
        "
    ];

    foreach ($assignmentColumns as $column => $alterSql) {

        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.columns
            WHERE table_schema = DATABASE()
              AND table_name = 'enquiries'
              AND column_name = ?
        ");

        $stmt->execute([$column]);

        if ((int)$stmt->fetchColumn() === 0) {
            $pdo->exec($alterSql);
        }
    }

    $assignmentReady = true;

} catch (Throwable $e) {

    error_log(
        'TRAVSCOPE enquiry assignment setup error: '
        . $e->getMessage()
    );

    $assignmentReady = false;
}


/*
|--------------------------------------------------------------------------
| ASSIGNABLE USERS
|--------------------------------------------------------------------------
*/

$assignmentUsers = [];
$managerUsers = [];
$staffUsers = [];

if ($assignmentReady) {

    try {

        $stmt = $pdo->query("
            SELECT
                id,
                full_name,
                email,
                role,
                status
            FROM users
            WHERE role IN ('manager','staff')
              AND status = 'active'
            ORDER BY
                CASE role
                    WHEN 'manager' THEN 1
                    WHEN 'staff' THEN 2
                    ELSE 3
                END,
                full_name ASC
        ");

        $assignmentUsers =
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            );

        foreach ($assignmentUsers as $member) {

            if (($member['role'] ?? '') === 'manager') {
                $managerUsers[] = $member;
            }

            if (($member['role'] ?? '') === 'staff') {
                $staffUsers[] = $member;
            }
        }

    } catch (Throwable $e) {

        error_log(
            'TRAVSCOPE assignable users error: '
            . $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| ASSIGNMENT TARGET HELPER
|--------------------------------------------------------------------------
*/

function adminResolveEnquiryAssignmentTarget(
    PDO $pdo,
    string $target
): array {

    $target =
        trim($target);

    if ($target === 'role:manager') {
        return [
            'user_id' => null,
            'role' => 'manager',
            'label' => 'All Managers'
        ];
    }

    if ($target === 'role:staff') {
        return [
            'user_id' => null,
            'role' => 'staff',
            'label' => 'All Staff'
        ];
    }

    if (
        preg_match(
            '/^user:(\d+)$/',
            $target,
            $match
        )
    ) {

        $userId =
            (int)$match[1];

        $stmt = $pdo->prepare("
            SELECT
                id,
                full_name,
                role
            FROM users
            WHERE id = ?
              AND role IN ('manager','staff')
              AND status = 'active'
            LIMIT 1
        ");

        $stmt->execute([$userId]);

        $member =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );

        if (!$member) {
            throw new RuntimeException(
                'Selected Manager or Staff account is not available.'
            );
        }

        return [
            'user_id' => (int)$member['id'],
            'role' => (string)$member['role'],
            'label' => (string)$member['full_name']
        ];
    }

    throw new RuntimeException(
        'Please select a valid Manager or Staff assignment.'
    );
}


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_enquiry_csrf'])) {

    $_SESSION['admin_enquiry_csrf'] =
        bin2hex(
            random_bytes(32)
        );
}

$csrfToken =
    $_SESSION['admin_enquiry_csrf'];


/*
|--------------------------------------------------------------------------
| FLASH
|--------------------------------------------------------------------------
*/

$success = '';
$error = '';

if (!empty($_SESSION['admin_enquiry_success'])) {

    $success =
        (string)$_SESSION['admin_enquiry_success'];

    unset(
        $_SESSION['admin_enquiry_success']
    );
}


/*
|--------------------------------------------------------------------------
| ALLOWED STATUSES
|--------------------------------------------------------------------------
*/

$allowedStatuses = [
    'new',
    'contacted',
    'follow_up',
    'converted',
    'closed'
];


/*
|--------------------------------------------------------------------------
| MANUAL ENQUIRY PACKAGE OPTIONS
|--------------------------------------------------------------------------
*/

$manualEnquiryDestinations = [];
$manualEnquiryPackages = [];

try {
    $stmt = $pdo->query("
        SELECT id,name,country
        FROM destinations
        WHERE status='active'
        ORDER BY name ASC,country ASC
    ");
    $manualEnquiryDestinations =
        $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
    error_log('Manual enquiry destination options error: ' . $e->getMessage());
    $manualEnquiryDestinations = [];
}

try {
    $stmt = $pdo->query("
        SELECT id,destination_id,title,package_code
        FROM packages
        WHERE status IN ('active','draft')
        ORDER BY title ASC
    ");

    $manualEnquiryPackages =
        $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

} catch (Throwable $e) {
    error_log(
        'Manual enquiry package options error: '
        . $e->getMessage()
    );

    $manualEnquiryPackages = [];
}



/*
|--------------------------------------------------------------------------
| MANUAL ENQUIRY CREATE
|--------------------------------------------------------------------------
| Creates the same enquiry record used by the normal admin enquiry list.
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    isset($_POST['add_manual_enquiry'])
) {

    $postedToken =
        (string)($_POST['csrf_token'] ?? '');

    if (
        $postedToken === ''
        ||
        !hash_equals(
            $_SESSION['admin_enquiry_csrf'] ?? '',
            $postedToken
        )
    ) {
        $error = 'Security verification failed.';
    } else {

        try {
            $enquiryCategory =
                trim(
                    (string)($_POST['manual_enquiry_category'] ?? '')
                );

            $name =
                trim(
                    (string)($_POST['manual_name'] ?? '')
                );

            $email =
                strtolower(
                    trim(
                        (string)($_POST['manual_email'] ?? '')
                    )
                );

            $mobile =
                trim(
                    (string)($_POST['manual_mobile'] ?? '')
                );

            $destination =
                trim(
                    (string)($_POST['manual_destination'] ?? '')
                );

            $travelDate =
                trim(
                    (string)($_POST['manual_travel_date'] ?? '')
                );

            $adults =
                max(
                    1,
                    min(
                        30,
                        (int)($_POST['manual_adults'] ?? 1)
                    )
                );

            $children =
                max(
                    0,
                    min(
                        30,
                        (int)($_POST['manual_children'] ?? 0)
                    )
                );

            $budgetRaw =
                trim(
                    (string)($_POST['manual_budget'] ?? '')
                );

            $message =
                trim(
                    (string)($_POST['manual_message'] ?? '')
                );

            $adminNotes =
                trim(
                    (string)($_POST['manual_admin_notes'] ?? '')
                );

            /*
            |--------------------------------------------------------------------------
            | COMPLETE MANUAL TRAVEL REQUIREMENTS
            |--------------------------------------------------------------------------
            | Extra travel fields are stored inside the existing message field.
            | No database/schema change is required.
            */

            $departureCity =
                trim((string)($_POST['manual_departure_city'] ?? ''));

            $returnDate =
                trim((string)($_POST['manual_return_date'] ?? ''));

            $tripType =
                trim((string)($_POST['manual_trip_type'] ?? ''));

            $nationality =
                trim((string)($_POST['manual_nationality'] ?? ''));

            $passportStatus =
                trim((string)($_POST['manual_passport_status'] ?? ''));

            $visaRequirement =
                trim((string)($_POST['manual_visa_requirement'] ?? ''));

            $visaNotes =
                trim((string)($_POST['manual_visa_notes'] ?? ''));

            $hotelCategory =
                trim((string)($_POST['manual_hotel_category'] ?? ''));

            $rooms =
                max(
                    0,
                    min(
                        20,
                        (int)($_POST['manual_rooms'] ?? 0)
                    )
                );

            $mealPlan =
                trim((string)($_POST['manual_meal_plan'] ?? ''));

            $flightPreference =
                trim((string)($_POST['manual_flight_preference'] ?? ''));

            $transportPreference =
                trim((string)($_POST['manual_transport_preference'] ?? ''));

            $servicesRequired =
                $_POST['manual_services_required']
                ?? [];

            if (!is_array($servicesRequired)) {
                $servicesRequired = [];
            }

            $allowedManualServices = [
                'Flights',
                'Hotels',
                'Visa Assistance',
                'Airport Transfer',
                'Local Transport',
                'Sightseeing',
                'Meals',
                'Travel Insurance',
                'Train Tickets',
                'Cruise',
                'Tour Guide',
                'Honeymoon / Special Arrangement',
                'Corporate / Group Travel'
            ];

            $servicesRequired =
                array_values(
                    array_intersect(
                        $allowedManualServices,
                        array_map('trim', $servicesRequired)
                    )
                );

            $destinationId =
                max(
                    0,
                    (int)($_POST['manual_destination_id'] ?? 0)
                );

            $packageId =
                max(
                    0,
                    (int)($_POST['manual_package_id'] ?? 0)
                );

            $status =
                trim(
                    (string)($_POST['manual_status'] ?? 'new')
                );

            $assignmentTarget =
                trim(
                    (string)($_POST['manual_assignment_target'] ?? '')
                );

            if (
                $enquiryCategory === ''
                ||
                !in_array(
                    $enquiryCategory,
                    adminEnquiryCategoryOptions(),
                    true
                )
            ) {
                throw new RuntimeException(
                    'Please select a valid enquiry category.'
                );
            }

            if ($name === '') {
                throw new RuntimeException(
                    'Customer name is required.'
                );
            }

            if (
                $email === ''
                ||
                !filter_var(
                    $email,
                    FILTER_VALIDATE_EMAIL
                )
            ) {
                throw new RuntimeException(
                    'A valid customer email is required.'
                );
            }

            if ($mobile === '') {
                throw new RuntimeException(
                    'Customer mobile number is required.'
                );
            }

            if ($destination === '') {
                throw new RuntimeException(
                    'Destination is required.'
                );
            }

            if ($destinationId <= 0) {
                throw new RuntimeException(
                    'Please choose a destination from the search suggestions.'
                );
            }

            $stmt = $pdo->prepare("
                SELECT id,name,country
                FROM destinations
                WHERE id=? AND status='active'
                LIMIT 1
            ");
            $stmt->execute([$destinationId]);
            $selectedDestination = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$selectedDestination) {
                throw new RuntimeException(
                    'Selected destination is not available.'
                );
            }

            $destination = trim((string)$selectedDestination['name']);

            if (
                $travelDate === ''
                ||
                !strtotime($travelDate)
            ) {
                throw new RuntimeException(
                    'A valid travel date is required.'
                );
            }

            if (
                $returnDate !== ''
                &&
                (
                    !strtotime($returnDate)
                    ||
                    strtotime($returnDate) < strtotime($travelDate)
                )
            ) {
                throw new RuntimeException(
                    'Return date must be the same as or after the travel date.'
                );
            }

            if (
                $budgetRaw === ''
                ||
                !is_numeric($budgetRaw)
                ||
                (float)$budgetRaw < 0
            ) {
                throw new RuntimeException(
                    'A valid enquiry budget is required.'
                );
            }

            if ($message === '') {
                throw new RuntimeException(
                    'Enquiry requirement / message is required.'
                );
            }

            $manualRequirementLines = [
                'Enquiry Category: ' . $enquiryCategory
            ];

            if ($departureCity !== '') {
                $manualRequirementLines[] = 'Departure City: ' . $departureCity;
            }

            if ($returnDate !== '') {
                $manualRequirementLines[] = 'Return Date: ' . $returnDate;
            }

            if ($tripType !== '') {
                $manualRequirementLines[] = 'Trip Type: ' . $tripType;
            }

            if ($nationality !== '') {
                $manualRequirementLines[] = 'Traveller Nationality: ' . $nationality;
            }

            if ($passportStatus !== '') {
                $manualRequirementLines[] = 'Passport Status: ' . $passportStatus;
            }

            if ($visaRequirement !== '') {
                $manualRequirementLines[] = 'Visa Requirement: ' . $visaRequirement;
            }

            if ($visaNotes !== '') {
                $manualRequirementLines[] = 'Visa Notes: ' . $visaNotes;
            }

            if ($hotelCategory !== '') {
                $manualRequirementLines[] = 'Hotel Category: ' . $hotelCategory;
            }

            if ($rooms > 0) {
                $manualRequirementLines[] = 'Rooms Required: ' . $rooms;
            }

            if ($mealPlan !== '') {
                $manualRequirementLines[] = 'Meal Plan: ' . $mealPlan;
            }

            if ($flightPreference !== '') {
                $manualRequirementLines[] = 'Flight Preference: ' . $flightPreference;
            }

            if ($transportPreference !== '') {
                $manualRequirementLines[] = 'Transport Preference: ' . $transportPreference;
            }

            if ($servicesRequired) {
                $manualRequirementLines[] =
                    'Services Required: '
                    . implode(', ', $servicesRequired);
            }

            if ($manualRequirementLines) {
                $message =
                    "TRAVEL REQUIREMENT DETAILS\n"
                    . implode("\n", $manualRequirementLines)
                    . "\n\nCUSTOMER REQUIREMENT\n"
                    . $message;
            }

            if (
                !in_array(
                    $status,
                    $allowedStatuses,
                    true
                )
            ) {
                $status = 'new';
            }

            if ($packageId > 0) {
                $stmt = $pdo->prepare("
                    SELECT id,title,destination_id
                    FROM packages
                    WHERE id=?
                      AND destination_id=?
                      AND status IN ('active','draft')
                    LIMIT 1
                ");

                $stmt->execute([$packageId,$destinationId]);

                if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
                    throw new RuntimeException(
                        'Selected package does not belong to the chosen destination.'
                    );
                }
            }

            $assignedUserId = null;
            $assignedRole = null;
            $assignedAt = null;

            if ($assignmentTarget !== '') {
                if (!$assignmentReady) {
                    throw new RuntimeException(
                        'Enquiry assignment setup is unavailable.'
                    );
                }

                $target =
                    adminResolveEnquiryAssignmentTarget(
                        $pdo,
                        $assignmentTarget
                    );

                $assignedUserId =
                    $target['user_id'];

                $assignedRole =
                    $target['role'];

                $assignedAt =
                    date('Y-m-d H:i:s');
            }

            $stmt = $pdo->prepare("
                INSERT INTO enquiries
                (
                    package_id,
                    name,
                    email,
                    mobile,
                    destination,
                    travel_date,
                    adults,
                    children,
                    budget,
                    message,
                    status,
                    admin_notes,
                    assigned_user_id,
                    assigned_role,
                    assigned_by_user_id,
                    assigned_by_type,
                    assigned_at,
                    created_at,
                    updated_at
                )
                VALUES
                (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, NOW(), NOW()
                )
            ");

            $stmt->execute([
                $packageId > 0
                    ? $packageId
                    : null,
                $name,
                $email,
                $mobile,
                $destination,
                $travelDate,
                $adults,
                $children,
                (float)$budgetRaw,
                $message,
                $status,
                $adminNotes !== ''
                    ? $adminNotes
                    : null,
                $assignedUserId,
                $assignedRole,
                $assignmentTarget !== ''
                    ? $adminId
                    : null,
                $assignmentTarget !== ''
                    ? 'admin'
                    : null,
                $assignedAt
            ]);

            $newEnquiryId =
                (int)$pdo->lastInsertId();

            $_SESSION['admin_enquiry_success'] =
                'Manual enquiry #ENQ'
                . str_pad(
                    (string)$newEnquiryId,
                    5,
                    '0',
                    STR_PAD_LEFT
                )
                . ' added successfully.';

            header(
                'Location: '
                . BASE_URL
                . 'admin-enquiries.php'
            );

            exit;

        } catch (RuntimeException $e) {
            $error =
                $e->getMessage();

        } catch (Throwable $e) {
            error_log(
                'Manual enquiry create error: '
                . $e->getMessage()
            );

            $error =
                'Unable to add the manual enquiry.';
        }
    }
}


/*
|--------------------------------------------------------------------------
| PHASE 0A — CREATE / OPEN TRIP
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_trip'])) {
    $postedToken = (string)($_POST['csrf_token'] ?? '');
    $tripEnquiryId = (int)($_POST['enquiry_id'] ?? 0);
    if ($postedToken === '' || !hash_equals($_SESSION['admin_enquiry_csrf'] ?? '', $postedToken)) {
        $error = 'Security verification failed.';
    } elseif ($tripEnquiryId <= 0) {
        $error = 'Invalid enquiry.';
    } elseif (!function_exists('crmCreateTripForEnquiry')) {
        $error = 'Trip helper is unavailable. Upload the Phase 0A crm-functions.php file.';
    } else {
        try {
            $trip = crmCreateTripForEnquiry($pdo, $tripEnquiryId, $adminId);
            $_SESSION['admin_enquiry_success'] = 'Trip ' . (string)$trip['trip_code'] . ' is ready.';
            header('Location: ' . BASE_URL . 'admin-crm.php?lead=' . $tripEnquiryId . '&trip=' . (int)$trip['id']);
            exit;
        } catch (Throwable $e) {
            error_log('Create trip from enquiry: ' . $e->getMessage());
            $error = $e->getMessage();
        }
    }
}

/*
|--------------------------------------------------------------------------
| STATUS UPDATE
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    isset($_POST['update_status'])
) {

    $postedToken =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    $enquiryId =
        (int)(
            $_POST['enquiry_id']
            ?? 0
        );

    $newStatus =
        trim(
            (string)(
                $_POST['status']
                ?? ''
            )
        );


    if (
        $postedToken === ''
        ||
        !hash_equals(
            $_SESSION['admin_enquiry_csrf'] ?? '',
            $postedToken
        )
    ) {

        $error =
            'Security verification failed.';
    }

    elseif ($enquiryId <= 0) {

        $error =
            'Invalid enquiry.';
    }

    elseif (
        !in_array(
            $newStatus,
            $allowedStatuses,
            true
        )
    ) {

        $error =
            'Invalid enquiry status.';
    }

    else {

        try {

            $pdo->beginTransaction();

            $createdBookingId = 0;

            if ($newStatus === 'converted') {
                $createdBookingId =
                    adminCreateBookingFromEnquiry(
                        $pdo,
                        $enquiryId
                    );
            }

            $stmt = $pdo->prepare("
                UPDATE enquiries

                SET status = ?

                WHERE id = ?

                LIMIT 1
            ");

            $stmt->execute([
                $newStatus,
                $enquiryId
            ]);

            $pdo->commit();

            $_SESSION[
                'admin_enquiry_success'
            ] =
                $newStatus === 'converted'
                    ? (
                        'Enquiry converted successfully. Booking #'
                        . $createdBookingId
                        . ' is now available in Bookings.'
                    )
                    : (
                        'Enquiry status updated to '
                        . adminEnquiryStatusLabel(
                            $newStatus
                        )
                        . '.'
                    );


            /*
            |--------------------------------------------------------------------------
            | KEEP FILTERS AFTER UPDATE
            |--------------------------------------------------------------------------
            */

            $redirectParams = [];

            if (!empty($_GET['status'])) {
                $redirectParams['status'] =
                    $_GET['status'];
            }

            if (!empty($_GET['q'])) {
                $redirectParams['q'] =
                    $_GET['q'];
            }

            if (!empty($_GET['page'])) {
                $redirectParams['page'] =
                    $_GET['page'];
            }

            if (!empty($_GET['category'])) {
                $redirectParams['category'] =
                    $_GET['category'];
            }


            $redirect =
                BASE_URL
                . 'admin-enquiries.php';

            if ($redirectParams) {

                $redirect .=
                    '?'
                    . http_build_query(
                        $redirectParams
                    );
            }

            header(
                'Location: '
                . $redirect
            );

            exit;

        } catch (Throwable $e) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log(
                'Admin enquiry status error: '
                . $e->getMessage()
            );

            $error =
                'Unable to update enquiry status.';
        }
    }
}


/*
|--------------------------------------------------------------------------
| BULK STATUS UPDATE
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    isset($_POST['bulk_update'])
) {

    $postedToken =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    $newStatus =
        trim(
            (string)(
                $_POST['bulk_status']
                ?? ''
            )
        );

    $selected =
        $_POST['selected']
        ?? [];


    if (
        $postedToken === ''
        ||
        !hash_equals(
            $_SESSION['admin_enquiry_csrf'] ?? '',
            $postedToken
        )
    ) {

        $error =
            'Security verification failed.';
    }

    elseif (
        !in_array(
            $newStatus,
            $allowedStatuses,
            true
        )
    ) {

        $error =
            'Please select a valid status.';
    }

    elseif (
        !is_array($selected)
        ||
        !$selected
    ) {

        $error =
            'Please select at least one enquiry.';
    }

    else {

        $ids = [];

        foreach ($selected as $id) {

            $id = (int)$id;

            if ($id > 0) {
                $ids[] = $id;
            }
        }

        $ids =
            array_values(
                array_unique($ids)
            );


        if (!$ids) {

            $error =
                'No valid enquiries were selected.';
        }

        else {

            try {

                $pdo->beginTransaction();

                if ($newStatus === 'converted') {
                    foreach ($ids as $conversionEnquiryId) {
                        adminCreateBookingFromEnquiry(
                            $pdo,
                            (int)$conversionEnquiryId
                        );
                    }
                }

                $placeholders =
                    implode(
                        ',',
                        array_fill(
                            0,
                            count($ids),
                            '?'
                        )
                    );

                $params =
                    array_merge(
                        [$newStatus],
                        $ids
                    );

                $stmt = $pdo->prepare("
                    UPDATE enquiries

                    SET status = ?

                    WHERE id IN ($placeholders)
                ");

                $stmt->execute(
                    $params
                );

                $pdo->commit();


                $_SESSION[
                    'admin_enquiry_success'
                ] =
                    $newStatus === 'converted'
                        ? (
                            count($ids)
                            . ' enquiry'
                            . (
                                count($ids) === 1
                                    ? ''
                                    : 'ies'
                            )
                            . ' converted and added to Bookings successfully.'
                        )
                        : (
                            count($ids)
                            . ' enquiry'
                            . (
                                count($ids) === 1
                                    ? ''
                                    : 'ies'
                            )
                            . ' updated successfully.'
                        );


                header(
                    'Location: '
                    . BASE_URL
                    . 'admin-enquiries.php'
                );

                exit;

            } catch (Throwable $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                error_log(
                    'Bulk enquiry update error: '
                    . $e->getMessage()
                );

                $error =
                    'Unable to update selected enquiries.';
            }
        }
    }
}



/*
|--------------------------------------------------------------------------
| SINGLE ENQUIRY ASSIGNMENT
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    isset($_POST['assign_enquiry'])
) {

    $postedToken =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    $enquiryId =
        (int)(
            $_POST['enquiry_id']
            ?? 0
        );

    $assignmentTarget =
        trim(
            (string)(
                $_POST['assignment_target']
                ?? ''
            )
        );

    if (
        $postedToken === ''
        ||
        !hash_equals(
            $_SESSION['admin_enquiry_csrf'] ?? '',
            $postedToken
        )
    ) {

        $error =
            'Security verification failed.';

    } elseif (!$assignmentReady) {

        $error =
            'Enquiry assignment database setup is unavailable.';

    } elseif ($enquiryId <= 0) {

        $error =
            'Invalid enquiry.';

    } else {

        try {

            $target =
                adminResolveEnquiryAssignmentTarget(
                    $pdo,
                    $assignmentTarget
                );

            $stmt = $pdo->prepare("
                UPDATE enquiries
                SET
                    assigned_user_id = ?,
                    assigned_role = ?,
                    assigned_by_user_id = ?,
                    assigned_by_type = 'admin',
                    assigned_at = NOW()
                WHERE id = ?
                LIMIT 1
            ");

            $stmt->execute([
                $target['user_id'],
                $target['role'],
                $adminId,
                $enquiryId
            ]);

            $_SESSION['admin_enquiry_success'] =
                'Enquiry #ENQ'
                . str_pad(
                    (string)$enquiryId,
                    5,
                    '0',
                    STR_PAD_LEFT
                )
                . ' assigned to '
                . $target['label']
                . '.';

            header(
                'Location: '
                . BASE_URL
                . 'admin-enquiries.php'
            );

            exit;

        } catch (Throwable $e) {

            error_log(
                'Single enquiry assignment error: '
                . $e->getMessage()
            );

            $error =
                $e instanceof RuntimeException
                    ? $e->getMessage()
                    : 'Unable to assign this enquiry.';
        }
    }
}


/*
|--------------------------------------------------------------------------
| BULK / SELECTED ENQUIRY ASSIGNMENT
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    isset($_POST['bulk_assign'])
) {

    $postedToken =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    $assignmentTarget =
        trim(
            (string)(
                $_POST['bulk_assignment_target']
                ?? ''
            )
        );

    $selected =
        $_POST['selected']
        ?? [];

    if (
        $postedToken === ''
        ||
        !hash_equals(
            $_SESSION['admin_enquiry_csrf'] ?? '',
            $postedToken
        )
    ) {

        $error =
            'Security verification failed.';

    } elseif (!$assignmentReady) {

        $error =
            'Enquiry assignment database setup is unavailable.';

    } elseif (
        !is_array($selected)
        ||
        !$selected
    ) {

        $error =
            'Please select at least one enquiry to assign.';

    } else {

        $ids = [];

        foreach ($selected as $id) {

            $id = (int)$id;

            if ($id > 0) {
                $ids[] = $id;
            }
        }

        $ids =
            array_values(
                array_unique($ids)
            );

        try {

            if (!$ids) {
                throw new RuntimeException(
                    'No valid enquiries were selected.'
                );
            }

            $target =
                adminResolveEnquiryAssignmentTarget(
                    $pdo,
                    $assignmentTarget
                );

            $placeholders =
                implode(
                    ',',
                    array_fill(
                        0,
                        count($ids),
                        '?'
                    )
                );

            $params = [
                $target['user_id'],
                $target['role'],
                $adminId
            ];

            foreach ($ids as $id) {
                $params[] = $id;
            }

            $stmt = $pdo->prepare("
                UPDATE enquiries
                SET
                    assigned_user_id = ?,
                    assigned_role = ?,
                    assigned_by_user_id = ?,
                    assigned_by_type = 'admin',
                    assigned_at = NOW()
                WHERE id IN ($placeholders)
            ");

            $stmt->execute($params);

            $_SESSION['admin_enquiry_success'] =
                count($ids)
                . ' selected enquiry'
                . (count($ids) === 1 ? '' : 's')
                . ' assigned to '
                . $target['label']
                . '.';

            header(
                'Location: '
                . BASE_URL
                . 'admin-enquiries.php'
            );

            exit;

        } catch (Throwable $e) {

            error_log(
                'Bulk enquiry assignment error: '
                . $e->getMessage()
            );

            $error =
                $e instanceof RuntimeException
                    ? $e->getMessage()
                    : 'Unable to assign selected enquiries.';
        }
    }
}


/*
|--------------------------------------------------------------------------
| ASSIGNMENT STATISTICS
|--------------------------------------------------------------------------
*/

$assignmentStats = [
    'assigned' => 0,
    'unassigned' => 0,
    'manager' => 0,
    'staff' => 0
];

$assignmentMemberCounts = [];

if ($assignmentReady) {

    try {

        $row = $pdo->query("
            SELECT
                SUM(
                    CASE
                        WHEN assigned_role IS NOT NULL
                        THEN 1
                        ELSE 0
                    END
                ) AS assigned_count,
                SUM(
                    CASE
                        WHEN assigned_role IS NULL
                        THEN 1
                        ELSE 0
                    END
                ) AS unassigned_count,
                SUM(
                    CASE
                        WHEN assigned_role = 'manager'
                        THEN 1
                        ELSE 0
                    END
                ) AS manager_count,
                SUM(
                    CASE
                        WHEN assigned_role = 'staff'
                        THEN 1
                        ELSE 0
                    END
                ) AS staff_count
            FROM enquiries
        ")->fetch(PDO::FETCH_ASSOC) ?: [];

        $assignmentStats = [
            'assigned' => (int)($row['assigned_count'] ?? 0),
            'unassigned' => (int)($row['unassigned_count'] ?? 0),
            'manager' => (int)($row['manager_count'] ?? 0),
            'staff' => (int)($row['staff_count'] ?? 0)
        ];

        $stmt = $pdo->query("
            SELECT
                u.id,
                u.full_name,
                u.role,
                COUNT(e.id) AS assigned_count
            FROM users u
            LEFT JOIN enquiries e
                ON e.assigned_user_id = u.id
            WHERE u.role IN ('manager','staff')
              AND u.status = 'active'
            GROUP BY
                u.id,
                u.full_name,
                u.role
            ORDER BY
                CASE u.role
                    WHEN 'manager' THEN 1
                    ELSE 2
                END,
                assigned_count DESC,
                u.full_name ASC
        ");

        $assignmentMemberCounts =
            $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {

        error_log(
            'Assignment statistics error: '
            . $e->getMessage()
        );
    }
}


/*
|--------------------------------------------------------------------------
| STATISTICS
|--------------------------------------------------------------------------
*/

$stats = [
    'total'     => 0,
    'new'       => 0,
    'contacted' => 0,
    'follow_up' => 0,
    'converted' => 0,
    'closed'    => 0
];

try {

    $stmt = $pdo->query("
        SELECT

            COUNT(*) AS total,

            SUM(
                CASE
                    WHEN status = 'new'
                    THEN 1
                    ELSE 0
                END
            ) AS new_count,

            SUM(
                CASE
                    WHEN status = 'contacted'
                    THEN 1
                    ELSE 0
                END
            ) AS contacted_count,

            SUM(
                CASE
                    WHEN status = 'follow_up'
                    THEN 1
                    ELSE 0
                END
            ) AS follow_up_count,

            SUM(
                CASE
                    WHEN status = 'converted'
                    THEN 1
                    ELSE 0
                END
            ) AS converted_count,

            SUM(
                CASE
                    WHEN status = 'closed'
                    THEN 1
                    ELSE 0
                END
            ) AS closed_count

        FROM enquiries
    ");

    $row =
        $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {

        $stats = [

            'total' =>
                (int)($row['total'] ?? 0),

            'new' =>
                (int)($row['new_count'] ?? 0),

            'contacted' =>
                (int)($row['contacted_count'] ?? 0),

            'follow_up' =>
                (int)($row['follow_up_count'] ?? 0),

            'converted' =>
                (int)($row['converted_count'] ?? 0),

            'closed' =>
                (int)($row['closed_count'] ?? 0)
        ];
    }

} catch (Throwable $e) {

    error_log(
        'Admin enquiry stats error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

$search =
    trim(
        (string)(
            $_GET['q']
            ?? ''
        )
    );

$statusFilter =
    trim(
        (string)(
            $_GET['status']
            ?? ''
        )
    );

$categoryFilter =
    trim(
        (string)(
            $_GET['category']
            ?? ''
        )
    );

if (
    $categoryFilter !== ''
    &&
    !in_array(
        $categoryFilter,
        adminEnquiryCategoryOptions(),
        true
    )
) {
    $categoryFilter = '';
}


if (
    $statusFilter !== ''
    &&
    (
        !in_array(
            $statusFilter,
            $allowedStatuses,
            true
        )
        ||
        $statusFilter === 'converted'
    )
) {

    $statusFilter = '';
}


/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/

$page =
    max(
        1,
        (int)(
            $_GET['page']
            ?? 1
        )
    );

$perPage = 20;


/*
|--------------------------------------------------------------------------
| WHERE
|--------------------------------------------------------------------------
*/

/*
| Converted enquiries belong to Booking workflow,
| so they are intentionally hidden from Admin Enquiries.
*/
$where = [
    "e.status <> 'converted'"
];
$params = [];


if ($statusFilter !== '') {

    $where[] =
        'e.status = ?';

    $params[] =
        $statusFilter;
}


if ($categoryFilter !== '') {

    $where[] =
        "e.message LIKE ?";

    $params[] =
        "%Enquiry Category: "
        . $categoryFilter
        . "%";
}


if ($search !== '') {

    $where[] = "
        (
            e.name LIKE ?
            OR e.email LIKE ?
            OR e.mobile LIKE ?
            OR e.destination LIKE ?
            OR e.message LIKE ?
            OR p.title LIKE ?
            OR p.package_code LIKE ?
            OR CAST(e.id AS CHAR) LIKE ?
        )
    ";

    $term =
        '%' . $search . '%';

    for ($i = 0; $i < 8; $i++) {
        $params[] = $term;
    }
}


$whereSql =
    $where
        ? ' WHERE ' . implode(
            ' AND ',
            $where
        )
        : '';


/*
|--------------------------------------------------------------------------
| COUNT FILTERED
|--------------------------------------------------------------------------
*/

$totalFiltered = 0;

try {

    $stmt = $pdo->prepare("
        SELECT COUNT(*)

        FROM enquiries e

        LEFT JOIN packages p
            ON p.id = e.package_id

        $whereSql
    ");

    $stmt->execute(
        $params
    );

    $totalFiltered =
        (int)$stmt->fetchColumn();

} catch (Throwable $e) {

    error_log(
        'Admin enquiry count error: '
        . $e->getMessage()
    );
}


$totalPages =
    max(
        1,
        (int)ceil(
            $totalFiltered
            /
            $perPage
        )
    );

if ($page > $totalPages) {
    $page = $totalPages;
}

$offset =
    ($page - 1)
    *
    $perPage;


/*
|--------------------------------------------------------------------------
| FETCH ENQUIRIES
|--------------------------------------------------------------------------
*/

$enquiries = [];

try {

    $sql = "
        SELECT

            e.id,
            e.package_id,
            e.name,
            e.email,
            e.mobile,
            e.destination,
            e.travel_date,
            e.adults,
            e.children,
            e.budget,
            e.message,
            e.status,
            e.admin_notes,
            e.assigned_user_id,
            e.assigned_role,
            e.assigned_by_user_id,
            e.assigned_by_type,
            e.assigned_at,
            e.created_at,
            e.updated_at,

            p.title AS package_title,
            p.package_code,
            p.slug,

            au.full_name AS assigned_user_name,
            au.email AS assigned_user_email,
            au.role AS assigned_user_role

        FROM enquiries e

        LEFT JOIN packages p
            ON p.id = e.package_id

        LEFT JOIN users au
            ON au.id = e.assigned_user_id

        $whereSql

        ORDER BY

            CASE e.status
                WHEN 'new' THEN 1
                WHEN 'follow_up' THEN 2
                WHEN 'contacted' THEN 3
                WHEN 'converted' THEN 4
                WHEN 'closed' THEN 5
                ELSE 6
            END,

            e.created_at DESC,
            e.id DESC

        LIMIT $perPage
        OFFSET $offset
    ";

    $stmt =
        $pdo->prepare($sql);

    $stmt->execute(
        $params
    );

    $enquiries =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );

} catch (Throwable $e) {

    error_log(
        'Admin enquiries fetch error: '
        . $e->getMessage()
    );

    $error =
        'Unable to load enquiries.';
}


/*
|--------------------------------------------------------------------------
| QUERY HELPER
|--------------------------------------------------------------------------
*/

function enquiryPageUrl(
    int $page,
    string $search,
    string $status,
    string $category = ''
): string {

    $params = [
        'page' => $page
    ];

    if ($search !== '') {
        $params['q'] = $search;
    }

    if ($status !== '') {
        $params['status'] = $status;
    }

    if ($category !== '') {
        $params['category'] = $category;
    }

    return BASE_URL
        . 'admin-enquiries.php?'
        . http_build_query($params);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
Enquiries | TRAVSCOPE Admin
</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>

:root {

    --navy:#07192d;
    --navy2:#0c3156;

    --blue:#0b74ff;

    --bg:#f4f7fb;

    --white:#fff;

    --text:#172235;

    --muted:#8290a0;

    --border:#e1e8ef;

    --green:#087952;
    --green-bg:#eaf9f3;

    --orange:#b46b00;
    --orange-bg:#fff4dc;

    --purple:#7255d9;
    --purple-bg:#f0edff;

    --red:#bd4453;
    --red-bg:#fff0f2;

    --gray:#677486;
    --gray-bg:#eef1f5;

    --shadow:
        0 12px 35px
        rgba(7,25,45,.07);
}


* {
    box-sizing:border-box;
    margin:0;
    padding:0;
}


body {

    background:var(--bg);

    color:var(--text);

    font-family:
        'DM Sans',
        sans-serif;
}


a {
    color:inherit;
    text-decoration:none;
}


button,
input,
select {
    font:inherit;
}


/* =========================================================
   TOPBAR
========================================================= */

.topbar {

    min-height:68px;

    padding:0 4%;

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:20px;

    background:var(--navy);

    color:white;
}


.brand {

    display:flex;

    align-items:center;

    gap:9px;

    font-family:
        'Manrope',
        sans-serif;

    font-size:17px;

    font-weight:800;
}


.brand-icon {

    width:37px;
    height:37px;

    border-radius:10px;

    display:grid;

    place-items:center;

    background:
        linear-gradient(
            135deg,
            #0b74ff,
            #00b8ff
        );
}


.brand span {
    color:#5fc9ff;
}


.top-actions {

    display:flex;

    align-items:center;

    gap:7px;
}


.top-link {

    min-height:37px;

    padding:0 11px;

    border-radius:8px;

    display:flex;

    align-items:center;

    gap:6px;

    color:#c4d4e2;

    font-size:8px;

    font-weight:700;
}


.top-link:hover {

    background:
        rgba(255,255,255,.08);

    color:white;
}


/* =========================================================
   LAYOUT
========================================================= */

.page {

    width:min(1450px,94%);

    margin:28px auto 55px;
}


.page-head {

    display:flex;

    align-items:flex-end;

    justify-content:space-between;

    gap:20px;

    margin-bottom:20px;
}


.eyebrow {

    color:var(--blue);

    font-size:7px;

    font-weight:800;

    letter-spacing:.8px;

    text-transform:uppercase;
}


.page-head h1 {

    margin-top:5px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:25px;
}


.page-head p {

    margin-top:5px;

    color:var(--muted);

    font-size:8px;
}


.refresh {

    min-height:39px;

    padding:0 13px;

    border:1px solid var(--border);

    border-radius:9px;

    display:flex;

    align-items:center;

    gap:6px;

    background:white;

    color:#59687a;

    font-size:8px;

    font-weight:800;
}


/* =========================================================
   ALERTS
========================================================= */

.alert {

    margin-bottom:15px;

    padding:12px 14px;

    border-radius:10px;

    display:flex;

    gap:8px;

    align-items:flex-start;

    font-size:8px;
}


.alert-success {

    border:1px solid #bce5d4;

    background:var(--green-bg);

    color:var(--green);
}


.alert-error {

    border:1px solid #efcbd0;

    background:var(--red-bg);

    color:var(--red);
}


/* =========================================================
   STATS
========================================================= */

.stats {

    display:grid;

    grid-template-columns:
        repeat(6,1fr);

    gap:10px;

    margin-bottom:18px;
}


.stat {

    padding:15px;

    border:1px solid var(--border);

    border-radius:12px;

    background:white;

    box-shadow:
        0 5px 18px
        rgba(7,25,45,.03);
}


.stat-head {

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:8px;
}


.stat-icon {

    width:33px;
    height:33px;

    border-radius:9px;

    display:grid;

    place-items:center;

    background:#edf5ff;

    color:var(--blue);

    font-size:10px;
}


.stat span {

    color:#8995a3;

    font-size:7px;

    font-weight:700;
}


.stat strong {

    display:block;

    margin-top:10px;

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:21px;
}


/* =========================================================
   FILTER CARD
========================================================= */

.card {

    border:1px solid var(--border);

    border-radius:14px;

    background:white;

    box-shadow:var(--shadow);
}


.filters {

    margin-bottom:15px;

    padding:15px;

    display:flex;

    align-items:center;

    gap:10px;

    flex-wrap:wrap;
}


.search-box {

    min-width:260px;

    flex:1;

    position:relative;
}


.search-box i {

    position:absolute;

    top:50%;
    left:13px;

    transform:translateY(-50%);

    color:#9aa6b3;

    font-size:9px;
}


.search-box input {

    width:100%;

    min-height:42px;

    padding:0 13px 0 37px;

    border:1px solid var(--border);

    border-radius:9px;

    outline:none;

    color:#526175;

    font-size:8px;
}


.filter-select {

    min-height:42px;

    padding:0 11px;

    border:1px solid var(--border);

    border-radius:9px;

    outline:none;

    background:white;

    color:#59687a;

    font-size:8px;
}


.filter-button {

    min-height:42px;

    padding:0 14px;

    border:0;

    border-radius:9px;

    cursor:pointer;

    background:var(--blue);

    color:white;

    font-size:8px;

    font-weight:800;
}


.clear-button {

    min-height:42px;

    padding:0 13px;

    border:1px solid var(--border);

    border-radius:9px;

    display:flex;

    align-items:center;

    background:white;

    color:#768393;

    font-size:8px;

    font-weight:700;
}


/* =========================================================
   BULK
========================================================= */

.bulk {

    padding:12px 15px;

    border-bottom:1px solid var(--border);

    display:flex;

    align-items:center;

    gap:8px;

    flex-wrap:wrap;

    background:#fafbfd;
}


.bulk-label {

    margin-right:auto;

    color:#788595;

    font-size:8px;
}


.bulk select {

    min-height:36px;

    padding:0 9px;

    border:1px solid var(--border);

    border-radius:8px;

    background:white;

    color:#59687a;

    font-size:8px;
}


.bulk button {

    min-height:36px;

    padding:0 11px;

    border:0;

    border-radius:8px;

    cursor:pointer;

    background:var(--navy);

    color:white;

    font-size:7px;

    font-weight:800;
}


/* =========================================================
   TABLE
========================================================= */

.table-wrap {

    width:100%;

    overflow-x:auto;
}


table {

    width:100%;

    min-width:1180px;

    border-collapse:collapse;
}


th {

    padding:11px 12px;

    border-bottom:1px solid var(--border);

    background:#fafbfd;

    color:#8793a1;

    font-size:7px;

    font-weight:800;

    text-align:left;

    text-transform:uppercase;

    letter-spacing:.4px;
}


td {

    padding:13px 12px;

    border-bottom:1px solid #edf0f3;

    vertical-align:top;

    color:#5f6d7e;

    font-size:8px;
}


tbody tr:hover {

    background:#fbfdff;
}


.checkbox {

    width:15px;
    height:15px;

    cursor:pointer;

    accent-color:var(--blue);
}


.enquiry-id {

    color:var(--blue);

    font-family:
        'Manrope',
        sans-serif;

    font-size:9px;

    font-weight:800;
}


.customer strong {

    display:block;

    color:var(--navy);

    font-size:9px;
}


.customer span {

    display:block;

    margin-top:3px;

    color:#8c98a6;

    font-size:7px;
}


.contact-links {

    margin-top:6px;

    display:flex;

    gap:5px;
}


.contact-button {

    width:27px;
    height:27px;

    border:1px solid var(--border);

    border-radius:7px;

    display:grid;

    place-items:center;

    background:white;

    color:#748294;

    font-size:8px;
}


.contact-button:hover {

    border-color:#9cc7ff;

    color:var(--blue);

    background:#f1f7ff;
}


.package-name {

    max-width:190px;

    color:#526175;

    font-size:8px;

    font-weight:700;

    line-height:1.5;
}


.package-code {

    display:block;

    margin-top:3px;

    color:#9ba5b1;

    font-size:6px;
}


.destination {

    max-width:150px;

    line-height:1.5;
}


.travel {

    white-space:nowrap;
}


.travel strong {

    display:block;

    color:#536174;

    font-size:8px;
}


.travel span {

    display:block;

    margin-top:3px;

    color:#929daa;

    font-size:7px;
}


.message-preview {

    max-width:220px;

    overflow:hidden;

    display:-webkit-box;

    -webkit-box-orient:vertical;

    -webkit-line-clamp:2;

    color:#7b8796;

    line-height:1.55;
}


/* =========================================================
   STATUS
========================================================= */

.status {

    display:inline-flex;

    align-items:center;

    gap:5px;

    padding:5px 8px;

    border-radius:20px;

    font-size:6px;

    font-weight:800;

    white-space:nowrap;
}


.status::before {

    content:"";

    width:5px;
    height:5px;

    border-radius:50%;

    background:currentColor;
}


.status-new {

    background:#e9f3ff;

    color:#0b74ff;
}


.status-contacted {

    background:#eaf9f3;

    color:#087952;
}


.status-follow {

    background:#fff4dc;

    color:#a96500;
}


.status-converted {

    background:#eeebff;

    color:#684bd2;
}


.status-closed {

    background:#eef1f5;

    color:#687586;
}


/* =========================================================
   QUICK STATUS
========================================================= */

.quick-status {

    margin-top:7px;

    display:flex;

    gap:4px;
}


.quick-status select {

    width:115px;

    min-height:31px;

    padding:0 6px;

    border:1px solid var(--border);

    border-radius:7px;

    background:white;

    color:#657386;

    font-size:7px;
}


.quick-status button {

    width:31px;
    height:31px;

    border:0;

    border-radius:7px;

    cursor:pointer;

    display:grid;

    place-items:center;

    background:#edf5ff;

    color:var(--blue);

    font-size:7px;
}


/* =========================================================
   ACTION
========================================================= */

.view-button {

    min-height:34px;

    padding:0 10px;

    border-radius:8px;

    display:inline-flex;

    align-items:center;

    justify-content:center;

    gap:5px;

    background:var(--navy);

    color:white;

    font-size:7px;

    font-weight:800;

    white-space:nowrap;
}


.view-button:hover {

    background:var(--blue);
}


/* =========================================================
   EMPTY
========================================================= */

.empty {

    padding:55px 20px;

    text-align:center;
}


.empty-icon {

    width:65px;
    height:65px;

    margin:0 auto 13px;

    border-radius:18px;

    display:grid;

    place-items:center;

    background:#edf5ff;

    color:var(--blue);

    font-size:22px;
}


.empty h3 {

    color:var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:14px;
}


.empty p {

    margin-top:5px;

    color:#8c98a6;

    font-size:8px;
}


/* =========================================================
   PAGINATION
========================================================= */

.pagination-area {

    padding:14px 15px;

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:15px;

    border-top:1px solid var(--border);
}


.pagination-info {

    color:#8995a3;

    font-size:7px;
}


.pagination {

    display:flex;

    gap:5px;
}


.page-button {

    min-width:34px;
    height:34px;

    padding:0 8px;

    border:1px solid var(--border);

    border-radius:8px;

    display:grid;

    place-items:center;

    background:white;

    color:#687586;

    font-size:7px;

    font-weight:800;
}


.page-button:hover,
.page-button.active {

    border-color:var(--blue);

    background:var(--blue);

    color:white;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:1100px) {

    .stats {
        grid-template-columns:
            repeat(3,1fr);
    }
}


@media(max-width:700px) {

    .topbar {

        padding:0 14px;
    }


    .top-actions
    .desktop-link {

        display:none;
    }


    .page {

        width:94%;

        margin-top:20px;
    }


    .page-head {

        align-items:flex-start;

        flex-direction:column;
    }


    .stats {

        grid-template-columns:
            repeat(2,1fr);
    }


    .filters {

        align-items:stretch;

        flex-direction:column;
    }


    .search-box {

        width:100%;

        min-width:0;
    }


    .filter-select,
    .filter-button,
    .clear-button {

        width:100%;
    }


    .clear-button {

        justify-content:center;
    }


    .pagination-area {

        align-items:flex-start;

        flex-direction:column;
    }
}



/* =========================================================
   2026-08-11 READABILITY + RESPONSIVE ADMIN NAV OVERRIDE
   Keeps all existing PHP/functions intact.
========================================================= */
html { -webkit-text-size-adjust:100%; }
body { font-size:14px; }
.topbar { min-height:72px; padding:0 3%; flex-wrap:wrap; }
.brand { font-size:18px; }
.top-actions { flex-wrap:wrap; justify-content:flex-end; }
.top-link { min-height:42px; padding:0 14px; font-size:14px; border-radius:9px; }
.page { width:min(1450px,96%); margin-top:24px; }
.eyebrow { font-size:12px; }
.page-head h1 { font-size:28px; }
.page-head p { font-size:14px; line-height:1.55; }
.refresh { min-height:44px; padding:0 15px; font-size:14px; }
.alert { font-size:14px; }
.stat span { font-size:13px; }
.stat strong { font-size:23px; }
.stat-icon { font-size:14px; }
.search-box i { font-size:14px; }
.search-box input,
.filter-select,
.filter-button,
.clear-button { min-height:44px; font-size:14px; }
.bulk-label,
.bulk select { font-size:13px; }
.bulk button { min-height:40px; padding:0 14px; font-size:13px; }
th { font-size:12px; padding:13px 12px; }
td { font-size:13px; padding:14px 12px; line-height:1.5; }
.enquiry-id { font-size:14px; }
.customer strong { font-size:14px; }
.customer span { font-size:12px; }
.contact-button { width:34px; height:34px; font-size:13px; }
.package-name { font-size:13px; }
.package-code { font-size:11px; }
.destination { font-size:13px; }
.travel strong { font-size:13px; }
.travel span { font-size:12px; }
.message-preview { font-size:13px; }
.status { font-size:11px; padding:6px 10px; }
.quick-status select { width:130px; min-height:36px; font-size:12px; }
.quick-status button { width:36px; height:36px; font-size:12px; }
.view-button { min-height:40px; padding:0 13px; font-size:13px; }
.empty h3 { font-size:17px; }
.empty p { font-size:13px; }
.pagination-info { font-size:12px; }
.page-button { min-width:38px; height:38px; font-size:12px; }

/* Increase tiny inline labels in enquiry rows without changing markup */
td div[style*="font-size:6px"],
td div[style*="font-size:7px"] { font-size:12px !important; }

@media(max-width:700px) {
    .topbar { padding:10px 14px; gap:10px; }
    .brand { font-size:16px; }
    .top-actions { width:100%; justify-content:flex-start; gap:6px; overflow-x:auto; flex-wrap:nowrap; padding-bottom:2px; }
    .top-actions .desktop-link { display:flex; }
    .top-link { flex:0 0 auto; min-height:40px; font-size:13px; padding:0 12px; }
    .page { width:94%; margin-top:18px; }
    .page-head h1 { font-size:24px; }
    .stats { grid-template-columns:repeat(2,minmax(0,1fr)); }
    .stat { padding:13px; }
    .table-wrap { -webkit-overflow-scrolling:touch; }
}

@media(max-width:420px) {
    .stats { grid-template-columns:1fr; }
    .page-head h1 { font-size:22px; }
    .top-link { font-size:12px; }
}



/* =========================================================
   PROFESSIONAL LEFT SIDEBAR ADMIN LAYOUT
   Navigation moved from top to side only.
========================================================= */

html,
body{
    min-height:100%;
}

body{
    background:var(--bg);
}

/* Shell */
.admin-shell{
    min-height:100vh;
}

.sidebar{
    position:fixed;
    inset:0 auto 0 0;
    width:235px;
    z-index:1100;
    overflow-y:auto;
    background:var(--navy);
    color:#fff;
    box-shadow:8px 0 28px rgba(7,25,45,.08);
    transition:transform .25s ease;
}

.sidebar-brand{
    min-height:72px;
    padding:0 18px;
    display:flex;
    align-items:center;
    gap:11px;
    border-bottom:1px solid rgba(255,255,255,.09);
    color:#fff;
    font-family:'Manrope',sans-serif;
    font-size:17px;
    font-weight:800;
}

.sidebar-brand > span:last-child{
    display:block;
}

.sidebar-brand > span:last-child > span{
    color:#66c8ff;
}

.sidebar-brand small{
    display:block;
    margin-top:2px;
    color:#7892aa;
    font-size:9px;
    font-weight:700;
    letter-spacing:1px;
}

.sidebar-brand-icon{
    width:38px;
    height:38px;
    flex:0 0 38px;
    display:grid;
    place-items:center;
    border-radius:10px;
    background:var(--blue);
    color:#fff;
}

.sidebar-menu{
    padding:14px 11px 25px;
}

.sidebar-title{
    padding:12px 11px 6px;
    color:#607991;
    font-size:10px;
    font-weight:800;
    letter-spacing:.9px;
}

.sidebar-link{
    min-height:40px;
    padding:0 11px;
    margin:3px 0;
    border-radius:8px;
    display:flex;
    align-items:center;
    gap:10px;
    color:#a6b7c7;
    font-size:13px;
    font-weight:700;
    transition:.18s ease;
}

.sidebar-link i{
    width:18px;
    text-align:center;
}

.sidebar-link:hover{
    background:rgba(255,255,255,.07);
    color:#fff;
}

.sidebar-link.active{
    background:var(--blue);
    color:#fff;
}

/* Main area */
.admin-main{
    min-height:100vh;
    margin-left:235px;
}

.topbar{
    min-height:64px;
    padding:0 22px;
    position:sticky;
    top:0;
    z-index:900;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:14px;
    background:#fff;
    color:var(--text);
    border-bottom:1px solid var(--border);
}

.topbar-left{
    display:flex;
    align-items:center;
    gap:10px;
}

.topbar-page-title{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:15px;
    font-weight:800;
}

.mobile-menu{
    display:none;
    width:38px;
    height:38px;
    border:1px solid var(--border);
    border-radius:8px;
    background:#fff;
    color:var(--navy);
}

.top-refresh{
    min-height:36px;
    padding:0 11px;
    font-size:12px;
}

/* Page uses available width beside sidebar */
.page{
    width:auto;
    max-width:none;
    margin:0;
    padding:20px 22px 38px;
}

.page-head{
    margin-bottom:16px;
}

.page-head h1{
    font-size:27px;
}

.page-head p{
    font-size:13px;
}

/* Keep text clearly readable */
.eyebrow{font-size:11px}
.alert{font-size:13px}
.stat span{font-size:12px}
.stat strong{font-size:23px}
.search-box input,
.filter-select,
.filter-button,
.clear-button{font-size:13px}
.bulk-label,
.bulk select,
.bulk button{font-size:12px}
th{font-size:11px}
td{font-size:12px}
.enquiry-id{font-size:13px}
.customer strong{font-size:13px}
.customer span{font-size:11px}
.package-name{font-size:12px}
.package-code{font-size:10px}
.destination{font-size:12px}
.travel strong{font-size:12px}
.travel span{font-size:11px}
.message-preview{font-size:12px}
.status{font-size:10px}
.quick-status select{font-size:11px}
.view-button{font-size:12px}
.pagination-info,
.page-button{font-size:11px}

/* Overlay */
.sidebar-overlay{
    position:fixed;
    inset:0;
    z-index:1050;
    display:none;
    background:rgba(4,18,31,.45);
}

.sidebar-overlay.show{
    display:block;
}

/* Tablet/mobile */
@media(max-width:900px){

    .sidebar{
        transform:translateX(-100%);
    }

    .sidebar.open{
        transform:translateX(0);
    }

    .admin-main{
        margin-left:0;
    }

    .mobile-menu{
        display:grid;
        place-items:center;
    }

    .page{
        padding:18px;
    }
}

@media(max-width:700px){

    .topbar{
        min-height:58px;
        padding:0 12px;
    }

    .topbar-page-title{
        font-size:14px;
    }

    .top-refresh{
        font-size:11px;
    }

    .page{
        width:auto;
        margin:0;
        padding:14px 11px 28px;
    }

    .page-head{
        margin-bottom:13px;
    }

    .page-head h1{
        font-size:23px;
    }

    .page-head p{
        font-size:12px;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ENQUIRIES — GRAPHICAL PROFESSIONAL VIEW / VISUAL ONLY */
.page{width:min(1540px,97%)!important;margin:16px auto 28px!important}
.page-head{margin-bottom:11px!important;align-items:center!important}
.page-head h1{margin-top:3px!important;font-size:25px!important;line-height:1.15!important}
.page-head p{margin-top:3px!important;font-size:10px!important}.eyebrow{font-size:8px!important}
.refresh{min-height:35px!important;padding:0 11px!important;font-size:10px!important}
.stats{grid-template-columns:repeat(6,minmax(0,1fr))!important;gap:8px!important;margin-bottom:9px!important}
.stat{min-height:80px!important;padding:10px 11px!important;border-radius:10px!important;position:relative;overflow:hidden;box-shadow:0 5px 16px rgba(15,23,42,.04)!important}
.stat:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px}
.stat:nth-child(1){background:linear-gradient(135deg,#fff,#eff6ff)!important;border-color:#dce9fb!important}.stat:nth-child(1):before{background:#2563eb}.stat:nth-child(1) .stat-icon{background:#dbeafe!important;color:#2563eb!important}
.stat:nth-child(2){background:linear-gradient(135deg,#fff,#fff7ed)!important;border-color:#f3e2cc!important}.stat:nth-child(2):before{background:#e58b2b}.stat:nth-child(2) .stat-icon{background:#ffedd5!important;color:#d97706!important}
.stat:nth-child(3){background:linear-gradient(135deg,#fff,#eefbff)!important;border-color:#d9eef5!important}.stat:nth-child(3):before{background:#0d8eaf}.stat:nth-child(3) .stat-icon{background:#cffafe!important;color:#0891b2!important}
.stat:nth-child(4){background:linear-gradient(135deg,#fff,#f5f3ff)!important;border-color:#e7e0fb!important}.stat:nth-child(4):before{background:#7c5bd1}.stat:nth-child(4) .stat-icon{background:#ede9fe!important;color:#7c3aed!important}
.stat:nth-child(5){background:linear-gradient(135deg,#fff,#ecfdf5)!important;border-color:#d8f1e5!important}.stat:nth-child(5):before{background:#0f9a68}.stat:nth-child(5) .stat-icon{background:#d1fae5!important;color:#059669!important}
.stat:nth-child(6){background:linear-gradient(135deg,#fff,#fff1f2)!important;border-color:#f4dce1!important}.stat:nth-child(6):before{background:#d74d61}.stat:nth-child(6) .stat-icon{background:#ffe4e6!important;color:#e11d48!important}
.stat-icon{width:31px!important;height:31px!important;border-radius:8px!important;font-size:11px!important}
.stat span{font-size:8px!important}.stat strong{margin-top:6px!important;font-size:19px!important;line-height:1!important}
.filters{margin-bottom:9px!important;padding:9px!important;gap:7px!important;flex-wrap:nowrap!important;border-radius:10px!important}
.search-box input,.filter-select,.filter-button,.clear-button{min-height:36px!important;height:36px!important;font-size:10px!important;border-radius:7px!important}
.search-box input{padding-left:34px!important}.filter-button{background:linear-gradient(135deg,#2563eb,#3b82f6)!important;box-shadow:0 4px 10px rgba(37,99,235,.14)}
.card{border-radius:10px!important}.bulk{padding:8px 10px!important;gap:6px!important}.bulk-label{font-size:9px!important}
.bulk select,.bulk button{min-height:32px!important;font-size:9px!important}
table{min-width:1080px!important}th{padding:7px 8px!important;font-size:8px!important}td{padding:8px!important;font-size:9px!important;line-height:1.3!important}
.enquiry-id{font-size:10px!important}.customer strong{font-size:10px!important}.customer span{margin-top:2px!important;font-size:8px!important}
.contact-links{margin-top:4px!important;gap:4px!important}.contact-button{width:25px!important;height:25px!important;font-size:8px!important}
.package-name,.destination{font-size:9px!important}.package-code{font-size:7px!important}.status{font-size:8px!important;padding:4px 7px!important}
.action-button,.manage-button,.quick-status-button{min-height:29px!important;padding:0 8px!important;font-size:8px!important;border-radius:6px!important}
.pagination{margin-top:8px!important;gap:4px!important}.page-button{min-width:30px!important;height:30px!important;font-size:9px!important}
@media(max-width:1180px){.stats{grid-template-columns:repeat(3,minmax(0,1fr))!important}.filters{flex-wrap:wrap!important}.search-box{min-width:100%!important}}
@media(max-width:760px){.page{width:calc(100% - 14px)!important;margin:10px auto 20px!important}.page-head{align-items:flex-start!important;flex-direction:column!important}.stats{grid-template-columns:repeat(2,minmax(0,1fr))!important}.filter-select,.filter-button,.clear-button{flex:1 1 100%!important;width:100%!important;min-height:40px!important;height:40px!important;font-size:12px!important}}
@media(max-width:450px){.stats{grid-template-columns:1fr!important}}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.page{
    margin:0 0 0 var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
    padding:16px 18px 20px!important;
}
.admin-main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}



/* =========================================================
   ENQUIRY ASSIGNMENT
========================================================= */

.assignment-overview{
    display:grid;
    grid-template-columns:repeat(4,minmax(0,1fr));
    gap:8px;
    margin:0 0 9px;
}
.assignment-overview-card{
    min-height:66px;
    padding:10px 12px;
    display:flex;
    align-items:center;
    gap:9px;
    border:1px solid var(--border);
    border-radius:10px;
    background:#fff;
}
.assignment-overview-card>i{
    width:31px;
    height:31px;
    display:grid;
    place-items:center;
    border-radius:8px;
}
.assignment-overview-card strong{
    display:block;
    font:800 17px/1 'Manrope',sans-serif;
    color:var(--navy);
}
.assignment-overview-card span{
    display:block;
    margin-top:4px;
    font-size:9px;
    font-weight:700;
}
.assignment-overview-card.assigned{background:linear-gradient(135deg,#f3f8ff,#fff)}
.assignment-overview-card.assigned>i{background:#e2efff;color:#2563eb}
.assignment-overview-card.manager{background:linear-gradient(135deg,#f7f2ff,#fff)}
.assignment-overview-card.manager>i{background:#eadfff;color:#7654c9}
.assignment-overview-card.staff{background:linear-gradient(135deg,#effbf6,#fff)}
.assignment-overview-card.staff>i{background:#daf5e8;color:#0f9a68}
.assignment-overview-card.unassigned{background:linear-gradient(135deg,#fff8ee,#fff)}
.assignment-overview-card.unassigned>i{background:#ffedd5;color:#d97706}

.assignment-members{
    display:flex;
    gap:6px;
    flex-wrap:wrap;
    margin:0 0 9px;
}
.assignment-member-chip{
    min-height:30px;
    padding:0 9px;
    display:inline-flex;
    align-items:center;
    gap:6px;
    border:1px solid #dce5ef;
    border-radius:999px;
    background:#fff;
    font-size:9px;
}
.assignment-member-chip strong{font-size:9px;color:#26364c}
.assignment-member-chip span{color:#758296;font-size:8px}
.assignment-member-chip.manager i{color:#7654c9}
.assignment-member-chip.staff i{color:#0f9a68}

.assigned-above-customer{
    width:max-content;
    max-width:100%;
    margin-bottom:5px;
    padding:3px 6px;
    display:flex;
    align-items:center;
    gap:4px;
    border-radius:999px;
    font-size:8px;
    font-weight:700;
}
.assigned-above-customer.manager{background:#f0e9ff;color:#704bc0}
.assigned-above-customer.staff{background:#e7f8f0;color:#087c59}
.assigned-above-customer.unassigned{background:#fff4e5;color:#a96500}
.assigned-above-customer strong{font-size:8px!important;color:inherit!important}

.assignment-select,
.row-assignment-select{
    border:1px solid var(--border);
    border-radius:7px;
    background:#fff;
    color:#536174;
    font-size:9px;
}
.assignment-select{min-height:36px;padding:0 8px}
.bulk-assign-button{
    background:linear-gradient(135deg,#0f9a68,#18b67e)!important;
}
.row-assignment-form{
    display:flex;
    align-items:center;
    gap:4px;
    margin-bottom:5px;
}
.row-assignment-select{
    width:120px;
    min-height:30px;
    padding:0 5px;
}
.row-assign-button{
    width:30px;
    height:30px;
    border:0;
    border-radius:7px;
    display:grid;
    place-items:center;
    background:#e7f8f0;
    color:#087c59;
    cursor:pointer;
}

@media(max-width:900px){
    .assignment-overview{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(max-width:520px){
    .assignment-overview{grid-template-columns:1fr}
}


/* =========================================================
   ENQUIRY CATEGORY-WISE MANAGEMENT
========================================================= */
.category-filter-select{
    min-width:190px;
}
.enquiry-category-badge{
    width:max-content;
    max-width:190px;
    margin-bottom:6px;
    padding:4px 7px;
    border-radius:999px;
    display:flex;
    align-items:center;
    gap:5px;
    font-size:7px;
    line-height:1.2;
    font-weight:800;
    white-space:normal;
}
.enquiry-category-badge i{font-size:7px}
.category-package{background:#e8f2ff;color:#075ec7}
.category-visa{background:#f1edff;color:#6b4fd3}
.category-flight{background:#e8fbff;color:#087e9d}
.category-hotel{background:#fff4dc;color:#a96300}
.category-flight-hotel{background:#eaf9f3;color:#087952}
.category-honeymoon{background:#fff0f5;color:#c43f72}
.category-family{background:#eef7ff;color:#376fb5}
.category-group{background:#f4f0ff;color:#7652bd}
.category-corporate{background:#edf1f5;color:#46566a}
.category-cruise{background:#e8f8ff;color:#08708e}
.category-transport{background:#fff3e8;color:#a55a16}
.category-insurance{background:#ecfdf5;color:#087952}
.category-other,.category-legacy{background:#eef1f5;color:#677486}
.manual-category-box{
    background:linear-gradient(135deg,#eff6ff,#f5f3ff)!important;
    border-color:#cbdcff!important;
}
@media(max-width:900px){
    .category-filter-select{min-width:0}
}

</style>


<style id="travscope-manual-enquiry-upgrade">
.enquiry-head-actions{
    display:flex;
    align-items:center;
    justify-content:flex-end;
    gap:8px;
    flex-wrap:wrap;
}

.manual-enquiry-open{
    min-height:44px;
    padding:0 15px;
    border:0;
    border-radius:9px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:7px;
    background:linear-gradient(135deg,#2563eb,#1d4ed8);
    color:#fff;
    cursor:pointer;
    font-size:13px;
    font-weight:800;
    box-shadow:0 7px 16px rgba(37,99,235,.18);
}

.manual-enquiry-open:hover{
    transform:translateY(-1px);
    box-shadow:0 9px 20px rgba(37,99,235,.24);
}

.manual-enquiry-modal{
    position:fixed;
    inset:0;
    z-index:5000;
    display:none;
    align-items:center;
    justify-content:center;
    padding:18px;
    background:rgba(15,23,42,.58);
    backdrop-filter:blur(3px);
}

.manual-enquiry-modal.open{
    display:flex;
}

.manual-enquiry-card{
    width:min(980px,96vw);
    max-height:94vh;
    overflow:auto;
    border-radius:18px;
    background:#fff;
    box-shadow:0 24px 70px rgba(15,23,42,.28);
}

.manual-enquiry-head{
    min-height:70px;
    padding:15px 18px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:15px;
    border-bottom:1px solid #e2e8f0;
    background:linear-gradient(135deg,#f8fbff,#fff);
}

.manual-enquiry-head h2{
    color:#0f172a;
    font-family:'Manrope',sans-serif;
    font-size:18px;
}

.manual-enquiry-head p{
    margin-top:4px;
    color:#64748b;
    font-size:12px;
}

.manual-enquiry-close{
    width:38px;
    height:38px;
    flex:0 0 38px;
    border:1px solid #fecdd3;
    border-radius:9px;
    display:grid;
    place-items:center;
    background:#fff1f2;
    color:#be123c;
    cursor:pointer;
}

.manual-enquiry-body{
    padding:16px 18px 18px;
}

.manual-enquiry-grid{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:11px;
}

.manual-enquiry-box{
    padding:12px;
    border:1px solid transparent;
    border-radius:12px;
}

.manual-enquiry-box.full{
    grid-column:1/-1;
}

.manual-enquiry-box:nth-child(4n+1){
    background:#eff6ff;
    border-color:#bfdbfe;
}

.manual-enquiry-box:nth-child(4n+2){
    background:#f5f3ff;
    border-color:#ddd6fe;
}

.manual-enquiry-box:nth-child(4n+3){
    background:#ecfdf5;
    border-color:#a7f3d0;
}

.manual-enquiry-box:nth-child(4n){
    background:#fff7ed;
    border-color:#fed7aa;
}

.manual-enquiry-box label{
    display:block;
    margin-bottom:6px;
    color:#334155;
    font-size:11px;
    font-weight:800;
}

.manual-enquiry-box .required{
    color:#dc2626;
}

.manual-enquiry-control{
    width:100%;
    min-height:42px;
    padding:9px 10px;
    border:1px solid #cbd5e1;
    border-radius:8px;
    outline:none;
    background:#fff;
    color:#1e293b;
    font:12px 'DM Sans',sans-serif;
}

textarea.manual-enquiry-control{
    min-height:92px;
    resize:vertical;
}

.manual-enquiry-control:focus{
    border-color:#60a5fa;
    box-shadow:0 0 0 3px rgba(37,99,235,.12);
}

.manual-destination-search{position:relative}
.manual-destination-results{
    position:absolute;left:0;right:0;top:calc(100% + 5px);z-index:40;
    max-height:230px;overflow:auto;border:1px solid #cbd5e1;border-radius:10px;
    background:#fff;box-shadow:0 14px 34px rgba(15,23,42,.14)
}
.manual-destination-result{
    width:100%;min-height:44px;padding:8px 10px;border:0;border-bottom:1px solid #eef2f7;
    display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;
    color:#1e293b;cursor:pointer;text-align:left;font-size:12px
}
.manual-destination-result:hover{background:#eff6ff;color:#1d4ed8}
.manual-destination-result strong{display:block;font-size:12px}
.manual-destination-result small{display:block;margin-top:2px;color:#64748b;font-size:10px}
.manual-destination-empty{padding:11px;color:#64748b;font-size:11px}
.manual-enquiry-help{margin-top:6px;color:#64748b;font-size:10px;line-height:1.45}

.manual-enquiry-section-title{
    padding:12px 14px !important;
    border-width:1px !important;
}
.manual-section-heading{
    display:flex;
    align-items:center;
    gap:8px;
    font:800 13px 'Manrope',sans-serif;
}
.manual-section-heading i{
    width:28px;
    height:28px;
    border-radius:8px;
    display:grid;
    place-items:center;
    background:rgba(255,255,255,.82);
}
.manual-section-sub{
    margin-top:4px;
    color:#64748b;
    font-size:10px;
    line-height:1.45;
}
.manual-section-blue{background:#eff6ff !important;border-color:#bfdbfe !important;color:#1d4ed8}
.manual-section-purple{background:#f5f3ff !important;border-color:#ddd6fe !important;color:#6d28d9}
.manual-section-green{background:#ecfdf5 !important;border-color:#a7f3d0 !important;color:#047857}
.manual-section-orange{background:#fff7ed !important;border-color:#fed7aa !important;color:#c2410c}
.manual-service-box{background:#f8fafc !important;border-color:#e2e8f0 !important}
.manual-service-grid{
    display:grid;
    grid-template-columns:repeat(3,minmax(0,1fr));
    gap:8px;
}
.manual-service-option{
    min-height:48px;
    padding:8px 9px;
    border:1px solid #dbe3ed;
    border-radius:9px;
    display:flex !important;
    align-items:center;
    gap:8px;
    margin:0 !important;
    background:#fff;
    color:#475569 !important;
    cursor:pointer;
    font-size:10px !important;
    font-weight:700 !important;
}
.manual-service-option:hover{border-color:#93c5fd;background:#eff6ff}
.manual-service-option input{width:15px;height:15px;flex:0 0 15px;accent-color:#2563eb}
.manual-service-icon{
    width:27px;
    height:27px;
    flex:0 0 27px;
    border-radius:7px;
    display:grid;
    place-items:center;
    background:#eef2ff;
    color:#4f46e5;
}
@media(max-width:820px){
    .manual-service-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(max-width:520px){
    .manual-service-grid{grid-template-columns:1fr}
}
.admin-main > .page{padding-top:18px}

.manual-enquiry-footer{
    margin-top:13px;
    padding-top:13px;
    border-top:1px solid #e2e8f0;
    display:flex;
    justify-content:flex-end;
    gap:8px;
}

.manual-enquiry-cancel,
.manual-enquiry-save{
    min-height:41px;
    padding:0 15px;
    border:0;
    border-radius:9px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:7px;
    cursor:pointer;
    font-size:12px;
    font-weight:800;
}

.manual-enquiry-cancel{
    border:1px solid #cbd5e1;
    background:#fff;
    color:#64748b;
}

.manual-enquiry-save{
    background:linear-gradient(135deg,#059669,#047857);
    color:#fff;
    box-shadow:0 7px 16px rgba(5,150,105,.18);
}

@media(max-width:700px){
    .enquiry-head-actions{
        width:100%;
        justify-content:stretch;
    }

    .enquiry-head-actions .refresh,
    .manual-enquiry-open{
        flex:1;
    }

    .manual-enquiry-modal{
        padding:7px;
        align-items:flex-start;
    }

    .manual-enquiry-card{
        width:100%;
        max-height:97vh;
        margin-top:5px;
        border-radius:13px;
    }

    .manual-enquiry-grid{
        grid-template-columns:1fr;
    }

    .manual-enquiry-box.full{
        grid-column:auto;
    }

    .manual-enquiry-footer{
        flex-direction:column-reverse;
    }

    .manual-enquiry-cancel,
    .manual-enquiry-save{
        width:100%;
    }
}
</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
<style id="travscope-v2453-international-enquiries">
/* V24.53 - visual-only, scoped Enquiry Directory consolidation. */
.enq-page-head,.enq-page-head *,.enq-workspace,.enq-workspace *,.enq-team-strip,.enq-team-strip *{box-sizing:border-box}
.page{width:calc(100% - 26px)!important;max-width:none!important;margin:13px auto 26px!important;color:#162a44}
.enq-page-head{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:15px!important;flex-wrap:wrap!important;padding:14px 16px!important;margin-bottom:8px!important;border:1px solid #dce6f2;border-left:4px solid #1376ed;border-radius:12px;background:linear-gradient(105deg,#fff 0%,#f5faff 100%);box-shadow:0 4px 16px rgba(24,58,95,.04)}
.enq-head-content{min-width:0;flex:1 1 640px}
.enq-title-line{display:flex;gap:12px;align-items:center}
.enq-page-head .eyebrow{font-size:9px!important;letter-spacing:.7px!important;line-height:1.3!important;color:#1375e8}
.enq-page-head h1{font-size:22px!important;line-height:1.16!important;font-weight:800!important;letter-spacing:-.6px!important;margin:3px 0 0!important;color:#142b47!important}
.enq-page-head p{font-size:10px!important;line-height:1.5!important;margin:3px 0 0!important;color:#6a7c94!important}
.enq-summary{display:flex;flex-wrap:wrap;align-items:center;gap:5px;margin-top:10px}
.enq-summary-pill{display:inline-flex;align-items:center;gap:5px;min-height:28px;padding:5px 8px;border:1px solid #dfe9f3;border-radius:7px;background:#fff;color:#527087;text-decoration:none!important;font:650 10px/1.2 Inter,system-ui,sans-serif!important;transition:border-color .15s,background .15s}
.enq-summary-pill:hover,.enq-summary-pill.is-active{background:#eaf4ff;border-color:#88baf5;color:#115eb5}
.enq-summary-pill strong{font-size:13px;font-weight:850;font-variant-numeric:tabular-nums;color:#193c61}
.enq-summary-pill i{font-size:10px;color:#407dbb}
.enq-metric-new i{color:#d58a13}.enq-metric-follow i{color:#7857c9}.enq-metric-converted i{color:#0a9865}.enq-metric-closed i{color:#be5264}
.enq-page-head .enquiry-head-actions{display:flex!important;gap:7px!important;align-self:center;flex:0 0 auto;flex-wrap:wrap}
.enq-page-head .refresh,.enq-page-head .manual-enquiry-open{height:34px!important;min-height:34px!important;padding:0 11px!important;border-radius:7px!important;font:750 11px/1.1 Inter,system-ui,sans-serif!important;display:inline-flex;align-items:center;justify-content:center;gap:6px;white-space:nowrap;box-shadow:none!important}
.enq-page-head .refresh{border:1px solid #d6e2ed;background:#fff;color:#355571;text-decoration:none}
.enq-page-head .manual-enquiry-open{background:#1168dc;border:1px solid #1168dc;color:#fff;cursor:pointer}
.enq-team-strip{display:flex;flex-wrap:wrap;gap:5px 11px;align-items:center;min-height:41px;margin:0 0 9px;padding:6px 11px;border:1px solid #dce6f2;border-radius:9px;background:#fff}
.enq-team-label{display:flex;align-items:center;gap:6px;font-size:10px;color:#355979;margin-right:2px}.enq-team-label i{color:#1775dd}
.enq-team-stat{display:inline-flex;align-items:center;gap:6px;padding:3px 9px;background:#f3f7fc;border:1px solid #e2eaf3;border-radius:6px;font-size:10px;color:#5f7490;white-space:nowrap}
.enq-team-stat strong{font-size:12px;font-variant-numeric:tabular-nums;color:#183a5b}
.enq-team-stat.unassigned{background:#fff7ed;border-color:#f5e4cf;color:#a46c20}.enq-team-stat.unassigned strong{color:#995b17}
.enq-team-details{margin-left:auto;position:relative;min-width:0;max-width:100%}
.enq-team-details summary{display:flex;gap:6px;align-items:center;cursor:pointer;list-style:none;font-size:10px;font-weight:750;color:#256ab0;padding:5px 7px;border:1px solid #dce8f4;border-radius:6px;background:#f5faff}
.enq-team-details summary::-webkit-details-marker{display:none}.enq-team-details[open] summary i:last-child{transform:rotate(180deg)}
.enq-team-members{position:absolute;right:0;top:calc(100% + 5px);z-index:20;display:flex;flex-direction:column;gap:5px;padding:10px;border:1px solid #dbe5f0;border-radius:9px;background:white;box-shadow:0 14px 30px rgba(21,47,77,.12);min-width:225px;max-height:270px;overflow:auto}
.enq-team-members .assignment-member-chip{border-radius:7px;width:100%;justify-content:flex-start;min-height:29px;padding:4px 7px;margin:0;gap:7px}
.enq-team-members .assignment-member-chip span{margin-left:auto}
.enq-workspace{overflow:visible!important;box-shadow:0 5px 20px rgba(30,62,100,.045)!important;border:1px solid #dce6f0!important;border-radius:11px!important;background:white!important}
.enq-workspace-heading{display:flex;gap:9px;align-items:center;justify-content:space-between;padding:10px 13px 8px;border-bottom:1px solid #e5edf5;background:linear-gradient(180deg,#fff,#fbfdff);border-radius:11px 11px 0 0}
.enq-workspace-heading h2{display:flex;flex-wrap:wrap;align-items:center;gap:7px;margin:0;font-size:13px!important;color:#143658!important;line-height:1.3;font-weight:800}
.enq-workspace-heading h2 i{color:#1475df}.enq-results{font-size:10px;color:#4c7190;border:1px solid #dce9f7;background:#f1f7ff;padding:3px 7px;border-radius:6px;white-space:nowrap}
.enq-workspace-heading p{margin:3px 0 0;color:#768aa1;font-size:10px;line-height:1.3}.enq-workspace-meta{font-size:9px;letter-spacing:.6px;color:#8092a6;font-weight:800;white-space:nowrap}
.enq-workspace .enq-directory-filters{display:flex!important;flex-wrap:wrap!important;align-items:center;gap:7px!important;margin:0!important;padding:9px 11px!important;border:0!important;border-bottom:1px solid #e3ebf4!important;border-radius:0!important;background:#fff!important;box-shadow:none!important}
.enq-workspace .search-box{flex:1 1 345px;min-width:190px}
.enq-workspace .search-box input,.enq-workspace .filter-select,.enq-workspace .filter-button,.enq-workspace .clear-button{height:34px!important;min-height:34px!important;border-radius:7px!important;font-size:11px!important}
.enq-workspace .search-box i{font-size:11px!important}.enq-workspace .search-box input{padding-left:33px!important}
.enq-workspace .filter-select{flex:0 1 164px;min-width:130px;padding:0 9px!important}
.enq-workspace .category-filter-select{flex-basis:210px;min-width:175px}
.enq-workspace .filter-button{padding:0 14px!important;background:#146cde!important;font-weight:750!important;box-shadow:none!important;white-space:nowrap}
.enq-workspace .clear-button{padding:0 9px!important;text-decoration:none;white-space:nowrap}
.enq-workspace .bulk{display:flex!important;align-items:center!important;justify-content:flex-end!important;flex-wrap:wrap!important;gap:6px!important;padding:8px 11px!important;border-bottom:1px solid #e1eaf3!important;margin:0!important;background:#fbfdff;color:#667e94}
.enq-workspace .enq-bulk-caption{font-size:10px;font-weight:800;letter-spacing:.1px;color:#355571;margin-right:auto;white-space:nowrap}
.enq-workspace .bulk-label{font-size:10px!important;color:#6b7b91;margin-right:4px}
.enq-workspace .bulk select,.enq-workspace .bulk button{height:32px!important;min-height:32px!important;border-radius:7px!important;font-size:10px!important;padding:0 9px!important}
.enq-workspace .bulk button{font-weight:750!important;white-space:nowrap}
.enq-directory-table{width:100%;overflow:auto;max-width:100%;scrollbar-color:#ccd8e7 transparent;scrollbar-width:thin}
.enq-workspace table{min-width:1160px!important;width:100%;border-collapse:collapse;table-layout:auto}
.enq-workspace th{font-size:9px!important;letter-spacing:.35px!important;font-weight:800!important;padding:10px 9px!important;background:#edf3fa!important;color:#34516f!important;border-bottom:1px solid #dce5ef!important;white-space:nowrap}
.enq-workspace td{font-size:10px!important;line-height:1.45!important;padding:11px 9px!important;border-bottom:1px solid #e5ecf4!important;vertical-align:top}
.enq-workspace tbody tr:nth-child(even){background:#fbfdff}.enq-workspace tbody tr:hover{background:#f5f9ff}
.enq-workspace .enquiry-id,.enq-workspace .customer strong{font-size:11px!important}.enq-workspace .customer span,.enq-workspace .package-name,.enq-workspace .destination{font-size:10px!important}
.enq-workspace .message-preview{font-size:10px!important;line-height:1.5!important}
.enq-workspace .row-assignment-select{font-size:10px!important;width:132px!important;min-height:31px!important}
.enq-workspace .quick-status select{font-size:10px!important;width:125px!important;min-height:31px!important}
.enq-workspace .quick-status button,.enq-workspace .row-assign-button{min-height:31px!important;height:31px!important}
.enq-workspace .view-button{font-size:10px!important;min-height:31px!important;padding:0 9px!important;white-space:nowrap}
.enq-workspace .status{font-size:9px!important}.enq-workspace .pagination-area{padding:9px 12px!important;gap:8px!important}
.enq-workspace .pagination-info{font-size:10px!important;color:#71859c}.enq-workspace .page-button{min-width:29px!important;height:29px!important}
.enq-page-head a:focus-visible,.enq-page-head button:focus-visible,.enq-workspace button:focus-visible,.enq-workspace input:focus-visible,.enq-workspace select:focus-visible,.enq-workspace a:focus-visible,.enq-team-details summary:focus-visible{outline:2px solid #2989ee!important;outline-offset:2px}
@media(max-width:1200px){.enq-page-head{align-items:flex-start!important}.enq-head-content{flex-basis:100%}.enq-page-head .enquiry-head-actions{margin-left:auto}.enq-workspace .filter-select{flex:1 1 150px}}
@media(max-width:760px){.page{width:calc(100% - 14px)!important;margin:9px auto 20px!important}.enq-page-head{padding:11px!important}.enq-page-head h1{font-size:20px!important}.enq-page-head .enquiry-head-actions{width:100%;margin-left:0;justify-content:flex-start}.enq-page-head .enquiry-head-actions .refresh,.enq-page-head .manual-enquiry-open{flex:1 1 auto}.enq-summary-pill{flex:1 1 auto;justify-content:center}.enq-team-details{margin-left:0}.enq-team-members{right:auto;left:0}.enq-workspace .search-box{flex:1 1 100%}.enq-workspace .filter-select,.enq-workspace .category-filter-select{flex:1 1 150px;min-width:120px}.enq-workspace .enq-directory-filters{padding:8px!important}.enq-workspace .bulk{justify-content:flex-start!important}.enq-workspace .enq-bulk-caption{width:100%;margin:0}}
@media(max-width:450px){.enq-summary-pill{flex:1 1 calc(33.333% - 7px);padding:5px 6px;font-size:9px!important}.enq-workspace .enq-workspace-meta{display:none}.enq-team-stat{padding:4px 6px}.enq-team-label{width:100%}.enq-workspace .filter-select{flex:1 1 100%}}
</style>
</head>

<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->







<!-- =========================================================
     SIDEBAR + TOPBAR
========================================================= -->

<div class="admin-shell">

<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->





<div class="admin-main">

<!-- =========================================================
     PAGE
========================================================= -->

<main class="page">


<header class="page-head enq-page-head">
 <div class="enq-head-content">
  <div class="enq-title-line"><div><div class="eyebrow">CUSTOMER RELATIONSHIP</div><h1>Travel Enquiries</h1><p>Track travellers, organise leads and convert enquiries into bookings.</p></div></div>
  <nav class="enq-summary" aria-label="Filter enquiries by status">
<a class="enq-summary-pill enq-metric-total <?= ($statusFilter === '') ? 'is-active' : ''; ?>" href="<?= e(BASE_URL . 'admin-enquiries.php'); ?>" title="View total enquiries"><i aria-hidden="true" class="fa-solid fa-inbox"></i><span>Total</span><strong><?= number_format((int)$stats['total']); ?></strong></a>
<a class="enq-summary-pill enq-metric-new <?= ($statusFilter === 'new') ? 'is-active' : ''; ?>" href="<?= e(BASE_URL . 'admin-enquiries.php?status=new'); ?>" title="View new enquiries"><i aria-hidden="true" class="fa-solid fa-bell"></i><span>New</span><strong><?= number_format((int)$stats['new']); ?></strong></a>
<a class="enq-summary-pill enq-metric-contacted <?= ($statusFilter === 'contacted') ? 'is-active' : ''; ?>" href="<?= e(BASE_URL . 'admin-enquiries.php?status=contacted'); ?>" title="View contacted enquiries"><i aria-hidden="true" class="fa-solid fa-phone"></i><span>Contacted</span><strong><?= number_format((int)$stats['contacted']); ?></strong></a>
<a class="enq-summary-pill enq-metric-follow <?= ($statusFilter === 'follow_up') ? 'is-active' : ''; ?>" href="<?= e(BASE_URL . 'admin-enquiries.php?status=follow_up'); ?>" title="View follow up enquiries"><i aria-hidden="true" class="fa-solid fa-clock"></i><span>Follow up</span><strong><?= number_format((int)$stats['follow_up']); ?></strong></a>
<a class="enq-summary-pill enq-metric-converted <?= ($statusFilter === 'converted') ? 'is-active' : ''; ?>" href="<?= e(BASE_URL . 'admin-enquiries.php?status=converted'); ?>" title="View converted enquiries"><i aria-hidden="true" class="fa-solid fa-circle-check"></i><span>Converted</span><strong><?= number_format((int)$stats['converted']); ?></strong></a>
<a class="enq-summary-pill enq-metric-closed <?= ($statusFilter === 'closed') ? 'is-active' : ''; ?>" href="<?= e(BASE_URL . 'admin-enquiries.php?status=closed'); ?>" title="View closed enquiries"><i aria-hidden="true" class="fa-solid fa-box-archive"></i><span>Closed</span><strong><?= number_format((int)$stats['closed']); ?></strong></a>
  </nav>
 </div>
 <div class="enquiry-head-actions">
  <a href="<?= e(BASE_URL . 'admin-enquiries.php'); ?>" class="refresh"><i class="fa-solid fa-rotate-right" aria-hidden="true"></i> Refresh</a>
  <button type="button" class="manual-enquiry-open" id="openManualEnquiry"><i class="fa-solid fa-plus" aria-hidden="true"></i> Manual Enquiry</button>
 </div>
</header>

<!-- =====================================================
     ALERTS
====================================================== -->

<?php if ($success !== ''): ?>

<div class="alert alert-success">

    <i class="fa-solid fa-circle-check"></i>

    <?= e($success); ?>

</div>

<?php endif; ?>


<?php if ($error !== ''): ?>

<div class="alert alert-error">

    <i class="fa-solid fa-circle-exclamation"></i>

    <?= e($error); ?>

</div>

<?php endif; ?>


<?php if ($assignmentReady): ?>
<section class="enq-team-strip" aria-label="Enquiry assignment overview">
 <div class="enq-team-label"><i class="fa-solid fa-user-group" aria-hidden="true"></i><strong>Ownership</strong></div>
 <div class="enq-team-stat"><span>Assigned</span><strong><?= number_format((int)$assignmentStats['assigned']); ?></strong></div>
 <div class="enq-team-stat"><span>Managers</span><strong><?= number_format((int)$assignmentStats['manager']); ?></strong></div>
 <div class="enq-team-stat"><span>Staff</span><strong><?= number_format((int)$assignmentStats['staff']); ?></strong></div>
 <div class="enq-team-stat unassigned"><span>Unassigned</span><strong><?= number_format((int)$assignmentStats['unassigned']); ?></strong></div>
 <?php if ($assignmentMemberCounts): ?>
 <details class="enq-team-details"><summary><i class="fa-solid fa-users-viewfinder" aria-hidden="true"></i> Team workload <i class="fa-solid fa-chevron-down" aria-hidden="true"></i></summary>
 <div class="enq-team-members">
  <?php foreach ($assignmentMemberCounts as $memberCount): ?>
   <div class="assignment-member-chip <?= e((string)$memberCount['role']); ?>">
    <i class="<?= ($memberCount['role'] ?? '') === 'manager' ? 'fa-solid fa-user-tie' : 'fa-solid fa-headset'; ?>" aria-hidden="true"></i>
    <strong><?= e((string)$memberCount['full_name']); ?></strong><span><?= number_format((int)$memberCount['assigned_count']); ?> assigned</span>
   </div>
  <?php endforeach; ?>
 </div></details>
 <?php endif; ?>
</section>
<?php endif; ?>

<!-- =====================================================
     FILTER
====================================================== -->

<section class="card enq-workspace" aria-labelledby="enq-directory-title">
 <div class="enq-workspace-heading"><div><h2 id="enq-directory-title"><i class="fa-solid fa-list-check" aria-hidden="true"></i> Enquiry Directory <span class="enq-results"><?= number_format((int)$totalFiltered); ?> results</span></h2><p>Search, update and allocate incoming travel enquiries.</p></div><span class="enq-workspace-meta">CRM / LEAD DESK</span></div>

<form
    method="get"
    action=""
    class="filters enq-directory-filters"
>


<div class="search-box">

    <i class="fa-solid fa-magnifying-glass"></i>

    <input
        type="search"
        name="q"
        value="<?= e($search); ?>"
        placeholder="Search name, phone, email, destination, package..."
    >

</div>


<select
    name="status"
    class="filter-select"
>

<option value="">
    All Statuses
</option>

<?php foreach ($allowedStatuses as $status): ?>

<option
    value="<?= e($status); ?>"
    <?= $statusFilter === $status
        ? 'selected'
        : ''; ?>
>

    <?= e(
        adminEnquiryStatusLabel(
            $status
        )
    ); ?>

</option>

<?php endforeach; ?>

</select>


<select
    name="category"
    class="filter-select category-filter-select"
>
<option value="">
    All Enquiry Categories
</option>

<?php foreach (adminEnquiryCategoryOptions() as $categoryOption): ?>
<option
    value="<?= e($categoryOption); ?>"
    <?= $categoryFilter === $categoryOption
        ? 'selected'
        : ''; ?>
>
    <?= e($categoryOption); ?>
</option>
<?php endforeach; ?>

</select>


<button
    type="submit"
    class="filter-button"
>

    <i class="fa-solid fa-filter"></i>

    Apply

</button>


<?php if (
    $search !== ''
    ||
    $statusFilter !== ''
    ||
    $categoryFilter !== ''
): ?>

<a
    href="<?= e(BASE_URL . 'admin-enquiries.php'); ?>"
    class="clear-button"
>

    Clear Filters

</a>

<?php endif; ?>


</form>


<!-- =====================================================
     ENQUIRIES
====================================================== -->

<!-- Table and bulk-action strip are part of the directory above. -->


<?php if ($enquiries): ?>


<form
    method="post"
    action=""
    id="bulkForm"
>


<input
    type="hidden"
    name="csrf_token"
    value="<?= e($csrfToken); ?>"
>


<div class="bulk" aria-label="Bulk enquiry actions">
 <span class="enq-bulk-caption">Bulk actions</span>


<span class="bulk-label">

    <strong id="selectedCount">
        0
    </strong>

    selected

</span>


<select
    name="bulk_status"
>

<option value="">
    Change status...
</option>

<?php foreach ($allowedStatuses as $status): ?>

<option value="<?= e($status); ?>">

    <?= e(
        adminEnquiryStatusLabel(
            $status
        )
    ); ?>

</option>

<?php endforeach; ?>

</select>


<button
    type="submit"
    name="bulk_update"
    value="1"
>

    Apply to Selected

</button>


<?php if ($assignmentReady): ?>

<select
    name="bulk_assignment_target"
    class="assignment-select"
>

<option value="">
    Assign selected...
</option>

<?php if ($managerUsers): ?>
<optgroup label="Managers">
    <option value="role:manager">All Managers</option>
    <?php foreach ($managerUsers as $member): ?>
        <option value="user:<?= (int)$member['id']; ?>">
            <?= e((string)$member['full_name']); ?> — Manager
        </option>
    <?php endforeach; ?>
</optgroup>
<?php endif; ?>

<?php if ($staffUsers): ?>
<optgroup label="Staff">
    <option value="role:staff">All Staff</option>
    <?php foreach ($staffUsers as $member): ?>
        <option value="user:<?= (int)$member['id']; ?>">
            <?= e((string)$member['full_name']); ?> — Staff
        </option>
    <?php endforeach; ?>
</optgroup>
<?php endif; ?>

</select>

<button
    type="submit"
    name="bulk_assign"
    value="1"
    class="bulk-assign-button"
>
    <i class="fa-solid fa-user-check"></i>
    Assign Selected
</button>

<?php endif; ?>


</div>


</form>

<div class="table-wrap enq-directory-table" role="region" aria-label="Enquiry records" tabindex="0">


<table>


<thead>

<tr>

<th>

<input
    type="checkbox"
    class="checkbox"
    id="selectAll"
>

</th>

<th>
    ID / Date
</th>

<th>
    Customer
</th>

<th>
    Package / Destination
</th>

<th>
    Travel
</th>

<th>
    Budget
</th>

<th>
    Message
</th>

<th>
    Status
</th>

<th>
    Action
</th>

</tr>

</thead>


<tbody>


<?php
$tripMap = [];
if (function_exists('crmTripsReady') && crmTripsReady($pdo) && !empty($enquiries)) {
    $tripIds = array_map(static fn($row) => (int)$row['id'], $enquiries);
    $placeholders = implode(',', array_fill(0, count($tripIds), '?'));
    $tripStmt = $pdo->prepare("SELECT id,enquiry_id,trip_code,stage FROM trips WHERE enquiry_id IN ($placeholders)");
    $tripStmt->execute($tripIds);
    foreach ($tripStmt->fetchAll(PDO::FETCH_ASSOC) as $tripRow) { $tripMap[(int)$tripRow['enquiry_id']] = $tripRow; }
}
?>
<?php foreach ($enquiries as $enquiry): ?>


<tr>


<td>

<input
    type="checkbox"
    class="checkbox row-checkbox"
    form="bulkForm"
    name="selected[]"
    value="<?= (int)$enquiry['id']; ?>"
>

</td>


<td>

<a
    href="<?= e(
        BASE_URL
        . 'admin-crm.php?lead='
        . (int)$enquiry['id']
    ); ?>"
    class="enquiry-id"
>

    #ENQ<?= str_pad(
        (string)$enquiry['id'],
        5,
        '0',
        STR_PAD_LEFT
    ); ?>

</a>

<div style="
    margin-top:4px;
    color:#96a1ad;
    font-size:6px;
">

    <?= e(
        adminEnquiryDate(
            $enquiry['created_at']
        )
    ); ?>

</div>

</td>


<td class="customer">


<?php if (
    !empty($enquiry['assigned_role'])
): ?>

<div class="assigned-above-customer <?= e((string)$enquiry['assigned_role']); ?>">

    <i class="<?= ($enquiry['assigned_role'] ?? '') === 'manager' ? 'fa-solid fa-user-tie' : 'fa-solid fa-headset'; ?>"></i>

    Assigned:
    <strong>
        <?= e(
            !empty($enquiry['assigned_user_name'])
                ? (string)$enquiry['assigned_user_name']
                : (
                    ($enquiry['assigned_role'] ?? '') === 'manager'
                        ? 'All Managers'
                        : 'All Staff'
                )
        ); ?>
    </strong>

</div>

<?php else: ?>

<div class="assigned-above-customer unassigned">
    <i class="fa-solid fa-user-clock"></i>
    Unassigned
</div>

<?php endif; ?>


<strong>

    <?= e(
        $enquiry['name']
    ); ?>

</strong>


<?php if (
    !empty(
        $enquiry['mobile']
    )
): ?>

<span>

    <?= e(
        $enquiry['mobile']
    ); ?>

</span>

<?php endif; ?>


<?php if (
    !empty(
        $enquiry['email']
    )
): ?>

<span>

    <?= e(
        $enquiry['email']
    ); ?>

</span>

<?php endif; ?>


<div class="contact-links">


<?php if (
    !empty(
        $enquiry['mobile']
    )
): ?>

<a
    href="tel:<?= e(
        preg_replace(
            '/[^0-9+]/',
            '',
            $enquiry['mobile']
        )
    ); ?>"
    class="contact-button"
    title="Call"
>

    <i class="fa-solid fa-phone"></i>

</a>

<?php endif; ?>


<?php if (
    !empty(
        $enquiry['email']
    )
): ?>

<a
    href="mailto:<?= e(
        $enquiry['email']
    ); ?>"
    class="contact-button"
    title="Email"
>

    <i class="fa-regular fa-envelope"></i>

</a>

<?php endif; ?>


</div>


</td>


<td>


<?php
$displayEnquiryCategory =
    adminEnquiryCategoryFromMessage(
        (string)($enquiry['message'] ?? '')
    );
?>
<div class="enquiry-category-badge <?= e(adminEnquiryCategoryClass($displayEnquiryCategory)); ?>">
    <i class="fa-solid fa-tag"></i>
    <?= e($displayEnquiryCategory); ?>
</div>

<?php if (
    !empty(
        $enquiry['package_title']
    )
): ?>

<div class="package-name">

    <?= e(
        $enquiry[
            'package_title'
        ]
    ); ?>

</div>


<?php if (
    !empty(
        $enquiry[
            'package_code'
        ]
    )
): ?>

<span class="package-code">

    <?= e(
        $enquiry[
            'package_code'
        ]
    ); ?>

</span>

<?php endif; ?>


<?php else: ?>

<div class="package-name">

    General Enquiry

</div>

<?php endif; ?>


<?php if (
    !empty(
        $enquiry[
            'destination'
        ]
    )
): ?>

<div
    class="destination"
    style="
        margin-top:5px;
        color:#8b97a5;
        font-size:7px;
    "
>

    <i class="fa-solid fa-location-dot"></i>

    <?= e(
        $enquiry[
            'destination'
        ]
    ); ?>

</div>

<?php endif; ?>


</td>


<td class="travel">


<strong>

    <?= e(
        adminTravelDate(
            $enquiry[
                'travel_date'
            ]
        )
    ); ?>

</strong>


<span>

    <?= (int)
        $enquiry[
            'adults'
        ]; ?>

    Adult<?= (int)$enquiry['adults'] === 1 ? '' : 's'; ?>

    <?php if (
        (int)$enquiry['children']
        > 0
    ): ?>

        ·

        <?= (int)
            $enquiry[
                'children'
            ]; ?>

        Child<?= (int)$enquiry['children'] === 1 ? '' : 'ren'; ?>

    <?php endif; ?>

</span>


</td>


<td>

<strong
    style="
        color:#536174;
        white-space:nowrap;
    "
>

    <?= e(
        adminMoney(
            $enquiry['budget']
        )
    ); ?>

</strong>

</td>


<td>

<div class="message-preview">

    <?= !empty(
        $enquiry['message']
    )
        ? e(
            $enquiry['message']
        )
        : 'No message provided.'; ?>

</div>


<?php if (
    !empty(
        $enquiry['admin_notes']
    )
): ?>

<div
    style="
        margin-top:5px;
        color:#a06b00;
        font-size:6px;
    "
>

    <i class="fa-solid fa-note-sticky"></i>

    Admin note added

</div>

<?php endif; ?>


</td>


<td>


<span
    class="status <?= e(
        adminEnquiryStatusClass(
            $enquiry['status']
        )
    ); ?>"
>

    <?= e(
        adminEnquiryStatusLabel(
            $enquiry['status']
        )
    ); ?>

</span>


<div class="quick-status">


<select
    class="quick-status-select"
    data-id="<?= (int)$enquiry['id']; ?>"
>

<?php foreach ($allowedStatuses as $status): ?>

<option
    value="<?= e($status); ?>"
    <?= $enquiry['status'] === $status
        ? 'selected'
        : ''; ?>
>

    <?= e(
        adminEnquiryStatusLabel(
            $status
        )
    ); ?>

</option>

<?php endforeach; ?>

</select>


<button
    type="button"
    class="quick-save"
    data-id="<?= (int)$enquiry['id']; ?>"
    title="Update Status"
>

    <i class="fa-solid fa-check"></i>

</button>


</div>


</td>


<td>


<?php if ($assignmentReady): ?>

<form
    method="post"
    action=""
    class="row-assignment-form"
>

<input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
<input type="hidden" name="enquiry_id" value="<?= (int)$enquiry['id']; ?>">

<select
    name="assignment_target"
    class="row-assignment-select"
    required
>
    <option value="">Assign...</option>

    <?php if ($managerUsers): ?>
        <optgroup label="Managers">
            <option value="role:manager">All Managers</option>
            <?php foreach ($managerUsers as $member): ?>
                <option
                    value="user:<?= (int)$member['id']; ?>"
                    <?= (int)($enquiry['assigned_user_id'] ?? 0) === (int)$member['id'] ? 'selected' : ''; ?>
                >
                    <?= e((string)$member['full_name']); ?>
                </option>
            <?php endforeach; ?>
        </optgroup>
    <?php endif; ?>

    <?php if ($staffUsers): ?>
        <optgroup label="Staff">
            <option value="role:staff">All Staff</option>
            <?php foreach ($staffUsers as $member): ?>
                <option
                    value="user:<?= (int)$member['id']; ?>"
                    <?= (int)($enquiry['assigned_user_id'] ?? 0) === (int)$member['id'] ? 'selected' : ''; ?>
                >
                    <?= e((string)$member['full_name']); ?>
                </option>
            <?php endforeach; ?>
        </optgroup>
    <?php endif; ?>
</select>

<button
    type="submit"
    name="assign_enquiry"
    value="1"
    class="row-assign-button"
    title="Assign Enquiry"
>
    <i class="fa-solid fa-user-check"></i>
</button>

</form>

<?php endif; ?>


<?php $rowTrip = $tripMap[(int)$enquiry['id']] ?? null; ?>
<?php if ($rowTrip): ?>
<a href="<?= e(BASE_URL . 'admin-crm.php?lead=' . (int)$enquiry['id'] . '&trip=' . (int)$rowTrip['id']); ?>" class="view-button" title="Open Trip Workspace">
    <i class="fa-solid fa-route"></i> <?= e((string)$rowTrip['trip_code']); ?>
</a>
<?php else: ?>
<form method="post" style="display:inline-flex;margin:0;">
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
    <input type="hidden" name="enquiry_id" value="<?= (int)$enquiry['id']; ?>">
    <button type="submit" name="create_trip" value="1" class="view-button" style="border:0;cursor:pointer;">
        <i class="fa-solid fa-route"></i> Create Trip
    </button>
</form>
<?php endif; ?>


</td>


</tr>


<?php endforeach; ?>


</tbody>


</table>


</div>





<!-- =====================================================
     PAGINATION
====================================================== -->

<div class="pagination-area">


<div class="pagination-info">

    Showing

    <?= number_format(
        $offset + 1
    ); ?>

    –

    <?= number_format(
        min(
            $offset + $perPage,
            $totalFiltered
        )
    ); ?>

    of

    <?= number_format(
        $totalFiltered
    ); ?>

    enquiries

</div>


<?php if ($totalPages > 1): ?>


<div class="pagination">


<?php if ($page > 1): ?>

<a
    href="<?= e(
        enquiryPageUrl(
            $page - 1,
            $search,
            $statusFilter,
            $categoryFilter
        )
    ); ?>"
    class="page-button"
>

    <i class="fa-solid fa-chevron-left"></i>

</a>

<?php endif; ?>


<?php

$startPage =
    max(
        1,
        $page - 2
    );

$endPage =
    min(
        $totalPages,
        $page + 2
    );

?>


<?php for (
    $i = $startPage;
    $i <= $endPage;
    $i++
): ?>

<a
    href="<?= e(
        enquiryPageUrl(
            $i,
            $search,
            $statusFilter,
            $categoryFilter
        )
    ); ?>"
    class="
        page-button
        <?= $i === $page
            ? 'active'
            : ''; ?>
    "
>

    <?= $i; ?>

</a>

<?php endfor; ?>


<?php if (
    $page < $totalPages
): ?>

<a
    href="<?= e(
        enquiryPageUrl(
            $page + 1,
            $search,
            $statusFilter,
            $categoryFilter
        )
    ); ?>"
    class="page-button"
>

    <i class="fa-solid fa-chevron-right"></i>

</a>

<?php endif; ?>


</div>


<?php endif; ?>


</div>


<?php else: ?>


<div class="empty">


<div class="empty-icon">

    <i class="fa-regular fa-message"></i>

</div>


<h3>

    No enquiries found

</h3>


<p>

    <?php if (
        $search !== ''
        ||
        $statusFilter !== ''
        ||
        $categoryFilter !== ''
    ): ?>

        No enquiries match the selected filters.

    <?php else: ?>

        Customer enquiries submitted through contact.php
        will appear here.

    <?php endif; ?>

</p>


</div>


<?php endif; ?>


</section>


<!-- =====================================================
     HIDDEN QUICK STATUS FORM
====================================================== -->

<form
    method="post"
    action=""
    id="quickStatusForm"
    style="display:none;"
>

<input
    type="hidden"
    name="csrf_token"
    value="<?= e($csrfToken); ?>"
>

<input
    type="hidden"
    name="enquiry_id"
    id="quickEnquiryId"
>

<input
    type="hidden"
    name="status"
    id="quickEnquiryStatus"
>

<input
    type="hidden"
    name="update_status"
    value="1"
>

</form>


</main>

</div>
</div>



<script>

/*
|--------------------------------------------------------------------------
| SELECT ALL
|--------------------------------------------------------------------------
*/

const selectAll =
    document.getElementById(
        'selectAll'
    );

const rowCheckboxes =
    document.querySelectorAll(
        '.row-checkbox'
    );

const selectedCount =
    document.getElementById(
        'selectedCount'
    );


function updateSelectedCount()
{
    if (!selectedCount) {
        return;
    }

    let count = 0;

    rowCheckboxes.forEach(
        function(box){

            if (box.checked) {
                count++;
            }
        }
    );

    selectedCount.textContent =
        count;
}


if (selectAll) {

    selectAll.addEventListener(
        'change',
        function(){

            rowCheckboxes.forEach(
                function(box){

                    box.checked =
                        selectAll.checked;
                }
            );

            updateSelectedCount();
        }
    );
}


rowCheckboxes.forEach(
    function(box){

        box.addEventListener(
            'change',
            function(){

                updateSelectedCount();

                if (selectAll) {

                    selectAll.checked =
                        rowCheckboxes.length > 0
                        &&
                        Array.from(
                            rowCheckboxes
                        ).every(
                            item =>
                                item.checked
                        );
                }
            }
        );
    }
);


/*
|--------------------------------------------------------------------------
| BULK CONFIRMATION
|--------------------------------------------------------------------------
*/

const bulkForm =
    document.getElementById(
        'bulkForm'
    );

if (bulkForm) {

    bulkForm.addEventListener(
        'submit',
        function(event){

            const selected =
                document.querySelectorAll(
                    '.row-checkbox:checked'
                );

            if (
                selected.length === 0
            ) {

                event.preventDefault();

                alert(
                    'Please select at least one enquiry.'
                );

                return;
            }

            if (
                !confirm(
                    'Update the selected enquiries?'
                )
            ) {

                event.preventDefault();
            }
        }
    );
}


/*
|--------------------------------------------------------------------------
| QUICK STATUS
|--------------------------------------------------------------------------
*/

document
    .querySelectorAll(
        '.quick-save'
    )
    .forEach(
        function(button){

            button.addEventListener(
                'click',
                function(){

                    const id =
                        this.dataset.id;

                    const select =
                        document.querySelector(
                            '.quick-status-select[data-id="'
                            + id
                            + '"]'
                        );

                    if (!select) {
                        return;
                    }

                    const form =
                        document.getElementById(
                            'quickStatusForm'
                        );

                    const idInput =
                        document.getElementById(
                            'quickEnquiryId'
                        );

                    const statusInput =
                        document.getElementById(
                            'quickEnquiryStatus'
                        );

                    if (
                        !form
                        ||
                        !idInput
                        ||
                        !statusInput
                    ) {
                        return;
                    }

                    idInput.value =
                        id;

                    statusInput.value =
                        select.value;

                    form.submit();
                }
            );
        }
    );

</script>



<script>
(function () {
    const sidebar = document.getElementById('sidebar');
    const mobileMenu = document.getElementById('mobileMenu');
    const overlay = document.getElementById('sidebarOverlay');

    if (!sidebar || !mobileMenu || !overlay) return;

    function closeSidebar() {
        sidebar.classList.remove('open');
        overlay.classList.remove('show');
    }

    mobileMenu.addEventListener('click', function () {
        sidebar.classList.toggle('open');
        overlay.classList.toggle('show');
    });

    overlay.addEventListener('click', closeSidebar);

    sidebar.querySelectorAll('a').forEach(function (link) {
        link.addEventListener('click', function () {
            if (window.innerWidth <= 900) {
                closeSidebar();
            }
        });
    });
})();
</script>







<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<div
    class="manual-enquiry-modal"
    id="manualEnquiryModal"
    aria-hidden="true"
>
    <div
        class="manual-enquiry-card"
        role="dialog"
        aria-modal="true"
        aria-labelledby="manualEnquiryTitle"
    >
        <div class="manual-enquiry-head">
            <div>
                <h2 id="manualEnquiryTitle">
                    <i class="fa-solid fa-pen-to-square"></i>
                    Add Manual Enquiry
                </h2>
                <p>
                    Record a complete customer travel requirement directly in the enquiry system.
                </p>
            </div>

            <button
                type="button"
                class="manual-enquiry-close"
                id="closeManualEnquiry"
                aria-label="Close"
            >
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <form
            method="post"
            action=""
            class="manual-enquiry-body"
            id="manualEnquiryForm"
        >
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($csrfToken); ?>"
            >

            <div class="manual-enquiry-grid">

                <div class="manual-enquiry-box full manual-category-box">
                    <label>
                        Enquiry Category
                        <span class="required">*</span>
                    </label>
                    <select
                        name="manual_enquiry_category"
                        class="manual-enquiry-control"
                        required
                    >
                        <option value="">Select enquiry category</option>
                        <?php foreach (adminEnquiryCategoryOptions() as $manualCategoryOption): ?>
                            <option value="<?= e($manualCategoryOption); ?>">
                                <?= e($manualCategoryOption); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="manual-enquiry-help">
                        Choose Visa, Flight, Hotel, Package or another travel category for category-wise Admin management.
                    </div>
                </div>

                <div class="manual-enquiry-box">
                    <label>
                        Customer Name
                        <span class="required">*</span>
                    </label>
                    <input
                        type="text"
                        name="manual_name"
                        class="manual-enquiry-control"
                        maxlength="150"
                        required
                    >
                </div>

                <div class="manual-enquiry-box">
                    <label>
                        Email Address
                        <span class="required">*</span>
                    </label>
                    <input
                        type="email"
                        name="manual_email"
                        class="manual-enquiry-control"
                        maxlength="190"
                        required
                    >
                </div>

                <div class="manual-enquiry-box">
                    <label>
                        Mobile Number
                        <span class="required">*</span>
                    </label>
                    <input
                        type="text"
                        name="manual_mobile"
                        class="manual-enquiry-control"
                        maxlength="30"
                        required
                    >
                </div>

                <div class="manual-enquiry-box manual-destination-search-box">
                    <label>
                        Destination
                        <span class="required">*</span>
                    </label>
                    <div class="manual-destination-search">
                        <input
                            type="text"
                            name="manual_destination"
                            id="manualDestinationSearch"
                            class="manual-enquiry-control"
                            maxlength="190"
                            placeholder="Type first letters, e.g. In, Bh, Du..."
                            autocomplete="off"
                            required
                        >
                        <input
                            type="hidden"
                            name="manual_destination_id"
                            id="manualDestinationId"
                            value=""
                        >
                        <div
                            class="manual-destination-results"
                            id="manualDestinationResults"
                            hidden
                        ></div>
                    </div>
                    <div class="manual-enquiry-help">
                        Start typing and choose from matching active destinations.
                    </div>
                </div>

                <div class="manual-enquiry-box">
                    <label>
                        Travel Date
                        <span class="required">*</span>
                    </label>
                    <input
                        type="date"
                        name="manual_travel_date"
                        class="manual-enquiry-control"
                        required
                    >
                </div>

                <div class="manual-enquiry-box">
                    <label>
                        Related Package
                    </label>
                    <select
                        name="manual_package_id"
                        id="manualPackageSelect"
                        class="manual-enquiry-control"
                        disabled
                    >
                        <option value="">Choose destination first</option>
                    </select>
                    <div class="manual-enquiry-help">
                        Only packages for the selected destination will appear.
                    </div>
                </div>

                <div class="manual-enquiry-box">
                    <label>
                        Adults
                        <span class="required">*</span>
                    </label>
                    <input
                        type="number"
                        name="manual_adults"
                        class="manual-enquiry-control"
                        min="1"
                        max="30"
                        value="2"
                        required
                    >
                </div>

                <div class="manual-enquiry-box">
                    <label>
                        Children
                    </label>
                    <input
                        type="number"
                        name="manual_children"
                        class="manual-enquiry-control"
                        min="0"
                        max="30"
                        value="0"
                    >
                </div>

                <div class="manual-enquiry-box">
                    <label>
                        Estimated Budget (₹)
                        <span class="required">*</span>
                    </label>
                    <input
                        type="number"
                        name="manual_budget"
                        class="manual-enquiry-control"
                        min="0"
                        step="1"
                        required
                    >
                </div>

                <div class="manual-enquiry-box">
                    <label>
                        Initial Status
                        <span class="required">*</span>
                    </label>
                    <select
                        name="manual_status"
                        class="manual-enquiry-control"
                        required
                    >
                        <option value="new">New</option>
                        <option value="contacted">Contacted</option>
                        <option value="follow_up">Follow Up</option>
                    </select>
                </div>

                <?php if ($assignmentReady): ?>
                <div class="manual-enquiry-box full">
                    <label>
                        Assign To
                    </label>
                    <select
                        name="manual_assignment_target"
                        class="manual-enquiry-control"
                    >
                        <option value="">
                            Keep Unassigned
                        </option>

                        <?php if ($managerUsers): ?>
                            <option value="role:manager">
                                All Managers
                            </option>

                            <?php foreach ($managerUsers as $member): ?>
                                <option value="user:<?= (int)$member['id']; ?>">
                                    Manager — <?= e((string)$member['full_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>

                        <?php if ($staffUsers): ?>
                            <option value="role:staff">
                                All Staff
                            </option>

                            <?php foreach ($staffUsers as $member): ?>
                                <option value="user:<?= (int)$member['id']; ?>">
                                    Staff — <?= e((string)$member['full_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <?php endif; ?>

                <div class="manual-enquiry-box full manual-enquiry-section-title manual-section-blue">
                    <div class="manual-section-heading">
                        <i class="fa-solid fa-route"></i>
                        Journey & Trip Planning
                    </div>
                    <div class="manual-section-sub">
                        Departure, return and trip-purpose details.
                    </div>
                </div>

                <div class="manual-enquiry-box">
                    <label>Departure City</label>
                    <input
                        type="text"
                        name="manual_departure_city"
                        class="manual-enquiry-control"
                        maxlength="150"
                        placeholder="Example: Kolkata, Delhi, Mumbai"
                    >
                </div>

                <div class="manual-enquiry-box">
                    <label>Return Date</label>
                    <input
                        type="date"
                        name="manual_return_date"
                        class="manual-enquiry-control"
                    >
                </div>

                <div class="manual-enquiry-box">
                    <label>Trip Type</label>
                    <select name="manual_trip_type" class="manual-enquiry-control">
                        <option value="">Select trip type</option>
                        <option value="Leisure / Holiday">Leisure / Holiday</option>
                        <option value="Honeymoon">Honeymoon</option>
                        <option value="Family">Family</option>
                        <option value="Friends / Group">Friends / Group</option>
                        <option value="Solo">Solo</option>
                        <option value="Business / Corporate">Business / Corporate</option>
                        <option value="MICE / Event">MICE / Event</option>
                        <option value="Pilgrimage">Pilgrimage</option>
                        <option value="Medical Travel">Medical Travel</option>
                        <option value="Education / Student">Education / Student</option>
                    </select>
                </div>

                <div class="manual-enquiry-box">
                    <label>Traveller Nationality</label>
                    <input
                        type="text"
                        name="manual_nationality"
                        class="manual-enquiry-control"
                        maxlength="100"
                        placeholder="Example: Indian"
                    >
                </div>

                <div class="manual-enquiry-box full manual-enquiry-section-title manual-section-purple">
                    <div class="manual-section-heading">
                        <i class="fa-solid fa-passport"></i>
                        Passport & Visa
                    </div>
                    <div class="manual-section-sub">
                        Visa-support and passport requirements for international travel.
                    </div>
                </div>

                <div class="manual-enquiry-box">
                    <label>Passport Status</label>
                    <select name="manual_passport_status" class="manual-enquiry-control">
                        <option value="">Select passport status</option>
                        <option value="Valid Passport Available">Valid Passport Available</option>
                        <option value="Passport Renewal Required">Passport Renewal Required</option>
                        <option value="New Passport Required">New Passport Required</option>
                        <option value="Not Applicable">Not Applicable</option>
                    </select>
                </div>

                <div class="manual-enquiry-box">
                    <label>Visa Requirement</label>
                    <select name="manual_visa_requirement" class="manual-enquiry-control">
                        <option value="">Select visa requirement</option>
                        <option value="Visa Assistance Required">Visa Assistance Required</option>
                        <option value="Visa Already Available">Visa Already Available</option>
                        <option value="Visa On Arrival / E-Visa Guidance">Visa On Arrival / E-Visa Guidance</option>
                        <option value="Visa Not Required">Visa Not Required</option>
                        <option value="Need Visa Eligibility Check">Need Visa Eligibility Check</option>
                    </select>
                </div>

                <div class="manual-enquiry-box full">
                    <label>Visa / Passport Notes</label>
                    <textarea
                        name="manual_visa_notes"
                        class="manual-enquiry-control"
                        maxlength="1500"
                        placeholder="Passport expiry, embassy requirement, visa history, urgent processing or other visa details..."
                    ></textarea>
                </div>

                <div class="manual-enquiry-box full manual-enquiry-section-title manual-section-green">
                    <div class="manual-section-heading">
                        <i class="fa-solid fa-hotel"></i>
                        Stay, Meals & Transport
                    </div>
                    <div class="manual-section-sub">
                        Accommodation, meal and local transport preferences.
                    </div>
                </div>

                <div class="manual-enquiry-box">
                    <label>Preferred Hotel Category</label>
                    <select name="manual_hotel_category" class="manual-enquiry-control">
                        <option value="">Select hotel preference</option>
                        <option value="Budget / Standard">Budget / Standard</option>
                        <option value="3 Star">3 Star</option>
                        <option value="4 Star">4 Star</option>
                        <option value="5 Star">5 Star</option>
                        <option value="Luxury / Premium">Luxury / Premium</option>
                        <option value="Resort / Villa">Resort / Villa</option>
                        <option value="Homestay / Apartment">Homestay / Apartment</option>
                    </select>
                </div>

                <div class="manual-enquiry-box">
                    <label>Rooms Required</label>
                    <input
                        type="number"
                        name="manual_rooms"
                        class="manual-enquiry-control"
                        min="0"
                        max="20"
                        value="1"
                    >
                </div>

                <div class="manual-enquiry-box">
                    <label>Meal Plan</label>
                    <select name="manual_meal_plan" class="manual-enquiry-control">
                        <option value="">Select meal plan</option>
                        <option value="Room Only">Room Only</option>
                        <option value="Breakfast">Breakfast</option>
                        <option value="Breakfast + Dinner">Breakfast + Dinner</option>
                        <option value="All Meals">All Meals</option>
                        <option value="All Inclusive">All Inclusive</option>
                        <option value="Special / Dietary Meal Required">Special / Dietary Meal Required</option>
                    </select>
                </div>

                <div class="manual-enquiry-box">
                    <label>Transport Preference</label>
                    <select name="manual_transport_preference" class="manual-enquiry-control">
                        <option value="">Select transport</option>
                        <option value="Private Car">Private Car</option>
                        <option value="Shared Vehicle / SIC">Shared Vehicle / SIC</option>
                        <option value="Tempo Traveller">Tempo Traveller</option>
                        <option value="Luxury Vehicle">Luxury Vehicle</option>
                        <option value="Coach / Bus">Coach / Bus</option>
                        <option value="Self Drive">Self Drive</option>
                        <option value="Public Transport Guidance">Public Transport Guidance</option>
                    </select>
                </div>

                <div class="manual-enquiry-box full manual-enquiry-section-title manual-section-orange">
                    <div class="manual-section-heading">
                        <i class="fa-solid fa-plane-departure"></i>
                        Flights & Travel Services
                    </div>
                    <div class="manual-section-sub">
                        Select all services requested by the traveller.
                    </div>
                </div>

                <div class="manual-enquiry-box full">
                    <label>Flight Preference</label>
                    <input
                        type="text"
                        name="manual_flight_preference"
                        class="manual-enquiry-control"
                        maxlength="300"
                        placeholder="Direct flight, preferred airline, departure time, cabin class..."
                    >
                </div>

                <div class="manual-enquiry-box full manual-service-box">
                    <label>Services Required</label>

                    <div class="manual-service-grid">
                        <?php
                        $manualServiceOptions = [
                            ['Flights', 'fa-plane'],
                            ['Hotels', 'fa-hotel'],
                            ['Visa Assistance', 'fa-passport'],
                            ['Airport Transfer', 'fa-van-shuttle'],
                            ['Local Transport', 'fa-car-side'],
                            ['Sightseeing', 'fa-camera'],
                            ['Meals', 'fa-utensils'],
                            ['Travel Insurance', 'fa-shield-heart'],
                            ['Train Tickets', 'fa-train'],
                            ['Cruise', 'fa-ship'],
                            ['Tour Guide', 'fa-person-walking-luggage'],
                            ['Honeymoon / Special Arrangement', 'fa-heart'],
                            ['Corporate / Group Travel', 'fa-people-group']
                        ];
                        ?>

                        <?php foreach ($manualServiceOptions as $manualServiceOption): ?>
                            <label class="manual-service-option">
                                <input
                                    type="checkbox"
                                    name="manual_services_required[]"
                                    value="<?= e($manualServiceOption[0]); ?>"
                                >
                                <span class="manual-service-icon">
                                    <i class="fa-solid <?= e($manualServiceOption[1]); ?>"></i>
                                </span>
                                <span><?= e($manualServiceOption[0]); ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="manual-enquiry-box full">
                    <label>
                        Full Travel Requirement
                        <span class="required">*</span>
                    </label>
                    <textarea
                        name="manual_message"
                        class="manual-enquiry-control"
                        maxlength="3000"
                        placeholder="Hotel preference, places to visit, flight requirement, room requirement, special requests and complete customer expectation..."
                        required
                    ></textarea>
                </div>

                <div class="manual-enquiry-box full">
                    <label>
                        Internal Admin Notes
                    </label>
                    <textarea
                        name="manual_admin_notes"
                        class="manual-enquiry-control"
                        maxlength="3000"
                        placeholder="Private notes for Admin / Manager / Staff..."
                    ></textarea>
                </div>

            </div>

            <div class="manual-enquiry-footer">
                <button
                    type="button"
                    class="manual-enquiry-cancel"
                    id="cancelManualEnquiry"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    name="add_manual_enquiry"
                    value="1"
                    class="manual-enquiry-save"
                >
                    <i class="fa-solid fa-circle-plus"></i>
                    Add Enquiry
                </button>
            </div>
        </form>
    </div>
</div>

<script id="travscope-manual-enquiry-script">
const manualEnquiryDestinations =
<?= json_encode(
    array_map(
        static fn(array $row): array => [
            'id' => (int)$row['id'],
            'name' => (string)$row['name'],
            'country' => (string)($row['country'] ?? '')
        ],
        $manualEnquiryDestinations
    ),
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
); ?>;

const manualEnquiryPackages =
<?= json_encode(
    array_map(
        static fn(array $row): array => [
            'id' => (int)$row['id'],
            'destination_id' => (int)($row['destination_id'] ?? 0),
            'title' => (string)$row['title'],
            'package_code' => (string)($row['package_code'] ?? '')
        ],
        $manualEnquiryPackages
    ),
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
); ?>;

(function(){
    const modal =
        document.getElementById(
            'manualEnquiryModal'
        );

    const openButton =
        document.getElementById(
            'openManualEnquiry'
        );

    const closeButton =
        document.getElementById(
            'closeManualEnquiry'
        );

    const cancelButton =
        document.getElementById(
            'cancelManualEnquiry'
        );

    if (!modal || !openButton) {
        return;
    }

    const destinationSearch = document.getElementById('manualDestinationSearch');
    const destinationId = document.getElementById('manualDestinationId');
    const destinationResults = document.getElementById('manualDestinationResults');
    const packageSelect = document.getElementById('manualPackageSelect');
    const manualForm = document.getElementById('manualEnquiryForm');

    function resetPackages(message) {
        if (!packageSelect) return;
        packageSelect.innerHTML = '';
        const option = document.createElement('option');
        option.value = '';
        option.textContent = message;
        packageSelect.appendChild(option);
        packageSelect.disabled = true;
    }

    function loadPackagesForDestination(id) {
        if (!packageSelect) return;

        const matches = manualEnquiryPackages.filter(function(pkg){
            return Number(pkg.destination_id) === Number(id);
        });

        packageSelect.innerHTML = '';

        const general = document.createElement('option');
        general.value = '';
        general.textContent = 'General / No package selected';
        packageSelect.appendChild(general);

        matches.forEach(function(pkg){
            const option = document.createElement('option');
            option.value = String(pkg.id);
            option.textContent =
                pkg.title + (pkg.package_code ? ' — ' + pkg.package_code : '');
            packageSelect.appendChild(option);
        });

        if (!matches.length) {
            const empty = document.createElement('option');
            empty.value = '';
            empty.textContent = 'No packages available for this destination';
            packageSelect.appendChild(empty);
        }

        packageSelect.disabled = false;
    }

    function chooseDestination(item) {
        destinationSearch.value = item.name;
        destinationId.value = String(item.id);
        destinationResults.hidden = true;
        destinationResults.innerHTML = '';
        loadPackagesForDestination(item.id);
    }

    function renderDestinationMatches(query) {
        if (!destinationResults) return;

        const needle = String(query || '').trim().toLowerCase();
        destinationResults.innerHTML = '';

        if (needle.length < 1) {
            destinationResults.hidden = true;
            return;
        }

        const matches = manualEnquiryDestinations
            .filter(function(item){
                return String(item.name || '').toLowerCase().includes(needle)
                    || String(item.country || '').toLowerCase().includes(needle);
            })
            .slice(0,20);

        if (!matches.length) {
            const empty = document.createElement('div');
            empty.className = 'manual-destination-empty';
            empty.textContent = 'No matching destination found.';
            destinationResults.appendChild(empty);
            destinationResults.hidden = false;
            return;
        }

        matches.forEach(function(item){
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'manual-destination-result';

            const text = document.createElement('span');
            const strong = document.createElement('strong');
            strong.textContent = item.name;
            const small = document.createElement('small');
            small.textContent = item.country || '';
            text.appendChild(strong);
            text.appendChild(small);

            const icon = document.createElement('i');
            icon.className = 'fa-solid fa-chevron-right';

            button.appendChild(text);
            button.appendChild(icon);

            button.addEventListener('click', function(){
                chooseDestination(item);
            });

            destinationResults.appendChild(button);
        });

        destinationResults.hidden = false;
    }

    destinationSearch?.addEventListener('input', function(){
        if (destinationId) destinationId.value = '';
        resetPackages('Choose destination first');
        renderDestinationMatches(destinationSearch.value);
    });

    destinationSearch?.addEventListener('focus', function(){
        if (
            destinationSearch.value.trim().length >= 1
            && !destinationId?.value
        ) {
            renderDestinationMatches(destinationSearch.value);
        }
    });

    document.addEventListener('click', function(event){
        if (
            destinationResults
            && destinationSearch
            && event.target !== destinationSearch
            && !destinationResults.contains(event.target)
        ) {
            destinationResults.hidden = true;
        }
    });

    manualForm?.addEventListener('submit', function(event){
        if (
            destinationSearch
            && destinationSearch.value.trim() !== ''
            && !destinationId?.value
        ) {
            event.preventDefault();
            renderDestinationMatches(destinationSearch.value);
            destinationSearch.focus();
            alert('Please choose the destination from the matching suggestions.');
        }
    });

    function setOpen(open) {
        modal.classList.toggle(
            'open',
            open
        );

        modal.setAttribute(
            'aria-hidden',
            open ? 'false' : 'true'
        );

        document.body.style.overflow =
            open ? 'hidden' : '';
    }

    openButton.addEventListener(
        'click',
        function(){
            setOpen(true);
            setTimeout(function(){
                destinationSearch?.focus();
            },50);
        }
    );

    closeButton?.addEventListener(
        'click',
        function(){
            setOpen(false);
        }
    );

    cancelButton?.addEventListener(
        'click',
        function(){
            setOpen(false);
        }
    );

    modal.addEventListener(
        'click',
        function(event){
            if (event.target === modal) {
                setOpen(false);
            }
        }
    );

    document.addEventListener(
        'keydown',
        function(event){
            if (
                event.key === 'Escape'
                && modal.classList.contains('open')
            ) {
                setOpen(false);
            }
        }
    );
})();
</script>


<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>