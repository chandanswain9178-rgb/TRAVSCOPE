<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
require_once __DIR__.'/supplier-functions.php';
$accessControlFunctionsFile=__DIR__.'/access-control-functions.php';
if(is_file($accessControlFunctionsFile))require_once $accessControlFunctionsFile;
if(empty($_SESSION['admin_id'])){header('Location: '.BASE_URL.'login.php');exit;}
$adminId=(int)$_SESSION['admin_id'];
if(function_exists('tsAclRequire')){try{tsAclRequire($pdo,$adminId,'view_supplier_cost','compare_supplier_quotes','enquiry',max(0,(int)($_GET['lead']??0)));}catch(RuntimeException $e){http_response_code(403);exit(htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8'));}}
$leadId=max(0,(int)($_GET['lead']??0));
$stmt=$pdo->prepare("SELECT * FROM enquiries WHERE id=? LIMIT 1");$stmt->execute([$leadId]);$lead=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$lead){http_response_code(404);exit('Enquiry not found.');}
$costingModeSelect=tsSupplierQuoteModeColumnExists($pdo)
    ? ",q.costing_mode"
    : ",NULL AS costing_mode";

$stmt=$pdo->prepare("
SELECT r.id request_id,r.request_code,r.request_group_code,r.request_type,r.status request_status,r.sent_at,r.first_response_at,
       r.trip_id,r.service_requirement_id,
       tsr.service_type linked_service_type,tsr.title linked_service_title,t.trip_code,
       s.company_name,s.priority,s.internal_rating,
       q.id quote_id,q.version_number,q.currency,q.net_amount,q.upgrade_amount,q.tax_amount,q.total_supplier_cost
       {$costingModeSelect},
       q.hotel_summary,q.transport_summary,q.payment_terms,q.cancellation_terms,q.validity_until,q.status quote_status
FROM supplier_requests r
JOIN suppliers s ON s.id=r.supplier_id
LEFT JOIN trip_service_requirements tsr ON tsr.id=r.service_requirement_id
LEFT JOIN trips t ON t.id=r.trip_id
LEFT JOIN supplier_quotes q ON q.id=(
    SELECT q2.id FROM supplier_quotes q2
    WHERE q2.supplier_request_id=r.id
    ORDER BY q2.version_number DESC,q2.id DESC LIMIT 1
)
WHERE r.enquiry_id=?
ORDER BY CASE s.priority WHEN 'preferred' THEN 1 WHEN 'regular' THEN 2 ELSE 3 END,s.company_name
");
$stmt->execute([$leadId]);$rows=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Compare Supplier Quotes | TRAVSCOPE</title>
<style>*{box-sizing:border-box}body{margin:0;background:#f5f7fb;color:#172033;font-family:Arial,sans-serif}.page{max-width:1600px;margin:auto;padding:26px}.btn{display:inline-flex;padding:10px 13px;border-radius:10px;background:#edf4ff;color:#145fae;text-decoration:none;font-weight:700;margin-right:7px}.panel{background:#fff;border:1px solid #e4e9f0;border-radius:16px;padding:18px;margin-top:16px}.wrap{overflow:auto}table{border-collapse:collapse;width:100%;min-width:1450px}th,td{padding:12px 10px;border:1px solid #e7ecf2;text-align:left;vertical-align:top;font-size:13px}th{background:#f7f9fc}.cost{font-size:18px;font-weight:800}.best{background:#f0fbf5}.muted{color:#778494}</style>
<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head><body><div class="page">
<a class="btn" href="admin-supplier-requests.php?lead=<?=$leadId?>">← Supplier Requests</a><a class="btn" href="admin-crm.php?lead=<?=$leadId?>">CRM Enquiry</a>
<h1>Supplier Comparison — #ENQ<?=str_pad((string)$leadId,5,'0',STR_PAD_LEFT)?></h1><p><?=tsSupE((string)$lead['destination'])?> · <?=tsSupE((string)$lead['name'])?></p>
<div class="panel"><div class="wrap"><table><thead><tr><th>Supplier</th><th>Trip Service</th><th>Request / Status</th><th>Response Time</th><th>Costing Mode</th><th>Net / Services</th><th>Supplier GST / Tax</th><th>Other / Upgrade</th><th>Total Supplier Cost</th><th>Hotel</th><th>Transport</th><th>Payment Terms</th><th>Cancellation</th><th>Validity</th><th>Action</th></tr></thead><tbody>
<?php if(!$rows):?><tr><td colspan="15">No supplier requests yet.</td></tr><?php endif;?>
<?php
$minByGroup=[];
foreach($rows as $compareRow){
    if(empty($compareRow['quote_id'])) continue;
    $groupKey=(string)($compareRow['request_group_code']?:('request-'.$compareRow['request_id']));
    $cost=(float)$compareRow['total_supplier_cost'];
    if(!isset($minByGroup[$groupKey])||$cost<$minByGroup[$groupKey])$minByGroup[$groupKey]=$cost;
}
foreach($rows as $r):
$quoteMode=tsSupplierQuoteModeFromRow($r,(string)($r['request_type']??''));
$response='—'; if($r['sent_at']&&$r['first_response_at']){$mins=max(0,(int)((strtotime($r['first_response_at'])-strtotime($r['sent_at']))/60));$response=$mins<60?$mins.' min':floor($mins/60).'h '.($mins%60).'m';}
$groupKey=(string)($r['request_group_code']?:('request-'.$r['request_id']));
$isBest=$r['quote_id']&&isset($minByGroup[$groupKey])&&(float)$r['total_supplier_cost']===(float)$minByGroup[$groupKey];
?>
<tr class="<?=$isBest?'best':''?>">
<td><strong><?=tsSupE((string)$r['company_name'])?></strong><br><span class="muted"><?=tsSupE(ucfirst((string)$r['priority']))?> · Rating <?=tsSupE((string)($r['internal_rating']?:'—'))?></span></td>
<td><?php if(!empty($r['linked_service_title'])):?><strong><?=tsSupE((string)$r['linked_service_title'])?></strong><br><span class="muted"><?=tsSupE(ucwords(str_replace('_',' ',(string)$r['linked_service_type'])))?><?=!empty($r['trip_code'])?' · '.tsSupE((string)$r['trip_code']):''?></span><?php else:?><span class="muted">Whole Trip / Legacy RFQ</span><?php endif;?></td>
<td><?=tsSupE((string)$r['request_code'])?><br><?=tsSupE(ucwords(str_replace('_',' ',(string)$r['request_status'])))?></td>
<td><?=tsSupE($response)?></td>
<td><?=$r['quote_id']?tsSupE(tsSupplierQuoteModeLabel($quoteMode)):'—'?></td>
<td><?=$r['quote_id']?tsSupE((string)$r['currency']).' '.number_format((float)$r['net_amount'],2):'—'?></td>
<td><?=$r['quote_id']?tsSupE((string)$r['currency']).' '.number_format((float)$r['tax_amount'],2):'—'?></td>
<td><?=$r['quote_id']?tsSupE((string)$r['currency']).' '.number_format((float)$r['upgrade_amount'],2):'—'?></td>
<td class="cost"><?=$r['quote_id']?tsSupE((string)$r['currency']).' '.number_format((float)$r['total_supplier_cost'],2):'Pending'?><?=$isBest?' ✓':''?></td>
<td><?=nl2br(tsSupE((string)($r['hotel_summary']?:'—')))?></td>
<td><?=nl2br(tsSupE((string)($r['transport_summary']?:'—')))?></td>
<td><?=nl2br(tsSupE((string)($r['payment_terms']?:'—')))?></td>
<td><?=nl2br(tsSupE((string)($r['cancellation_terms']?:'—')))?></td>
<td><?=tsSupE((string)($r['validity_until']?:'—'))?></td>
<td><a class="btn" href="admin-supplier-request-details.php?id=<?=(int)$r['request_id']?>">Review / Select</a></td>
</tr>
<?php endforeach;?>
</tbody></table></div></div>
<p class="muted">Lowest cost is highlighted only within the same RFQ group, so a Hotel-only quote is not compared against a Complete Package quote. Travscope should still consider quality, suitability, response speed, terms and reliability — not price alone.</p>
</div>
<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
