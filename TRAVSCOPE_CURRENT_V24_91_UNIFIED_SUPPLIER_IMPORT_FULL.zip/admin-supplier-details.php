<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/supplier-functions.php';
$rateBookFunctionsFile=__DIR__.'/supplier-rate-book-functions.php';
if(is_file($rateBookFunctionsFile))require_once $rateBookFunctionsFile;
$packageSupplierFunctionsFile=__DIR__.'/package-supplier-functions.php';
if(is_file($packageSupplierFunctionsFile))require_once $packageSupplierFunctionsFile;
$manualSupplierPackageFunctionsFile=__DIR__.'/supplier-manual-package-functions.php';
if(is_file($manualSupplierPackageFunctionsFile))require_once $manualSupplierPackageFunctionsFile;
$supplierHotelOptionsFile=__DIR__.'/supplier-hotel-option-functions.php';
if(is_file($supplierHotelOptionsFile))require_once $supplierHotelOptionsFile;
$accessControlFunctionsFile=__DIR__.'/access-control-functions.php';
if(is_file($accessControlFunctionsFile))require_once $accessControlFunctionsFile;

if (empty($_SESSION['admin_id'])) {
    header('Location: ' . BASE_URL . 'login.php'); exit;
}
$adminId=(int)$_SESSION['admin_id'];

$stmt=$pdo->prepare("SELECT id,name,email,role,status FROM admins WHERE id=? LIMIT 1");
$stmt->execute([$adminId]);
$admin=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$admin || ($admin['status']??'')!=='active'){unset($_SESSION['admin_id']);header('Location: '.BASE_URL.'login.php');exit;}

function sdE(?string $v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}

function sdStarFromCategory(string $value): int {
    $value=strtolower(trim($value));
    if(preg_match('/(?:^|\D)([345])\s*(?:star|\*|★)?/u',$value,$m)) return (int)$m[1];
    return 0;
}
function sdSupplierPriority(string $priority): int {
    return match(strtolower(trim($priority))){'preferred'=>10,'regular'=>50,'backup'=>90,default=>100};
}
function sdResolveHotelDestination(PDO $pdo,int $fallbackDestinationId,string $city): int {
    // V9: keep the selected parent destination (Tamil Nadu / Kashmir / Andaman)
    // and store the operational city separately. Do not replace Tamil Nadu with Chennai.
    return $fallbackDestinationId > 0 ? $fallbackDestinationId : 0;
}
function sdSyncHotelMasterFromRate(PDO $pdo,array $supplier,int $destinationId,string $city,string $category,string $hotelName,string $roomType,string $mealPlan,int $rateCardId,int $adminId): void {
    if(!tsSupplierTableExists($pdo,'hotels') || !tsSupplierTableExists($pdo,'destinations')) return;
    $star=sdStarFromCategory($category);
    $hotelName=trim(preg_replace('/\s+/u',' ',$hotelName)??$hotelName);
    $city=trim(preg_replace('/\s+/u',' ',$city)??$city);
    if($hotelName==='' || !in_array($star,[3,4,5],true) || $destinationId<=0 || $city==='')return;
    $locationId=function_exists('tsLocationUpsert')?tsLocationUpsert($pdo,$destinationId,$city,'supplier',$adminId):0;
    $priority=sdSupplierPriority((string)($supplier['priority']??'regular'));
    $supplierId=(int)($supplier['id']??0);
    $hasLocationId=function_exists('tsSupplierColumnExists') && tsSupplierColumnExists($pdo,'hotels','location_id');
    try{
        if($hasLocationId && $locationId>0){
            $find=$pdo->prepare("SELECT id,priority_order FROM hotels WHERE destination_id=? AND location_id=? AND LOWER(TRIM(hotel_name))=LOWER(TRIM(?)) AND star_category=? LIMIT 1");
            $find->execute([$destinationId,$locationId,$hotelName,$star]);
        }else{
            $find=$pdo->prepare("SELECT id,priority_order FROM hotels WHERE destination_id=? AND LOWER(TRIM(COALESCE(city,'')))=LOWER(TRIM(?)) AND LOWER(TRIM(hotel_name))=LOWER(TRIM(?)) AND star_category=? LIMIT 1");
            $find->execute([$destinationId,$city,$hotelName,$star]);
        }
        $existing=$find->fetch(PDO::FETCH_ASSOC);
        if($existing){
            $set=$hasLocationId?'location_id=COALESCE(?,location_id),':'';
            $sql="UPDATE hotels SET {$set} city=COALESCE(NULLIF(?,''),city),default_room_type=COALESCE(NULLIF(?,''),default_room_type),default_meal_plan=COALESCE(NULLIF(?,''),default_meal_plan),preferred_supplier_id=CASE WHEN ?<=priority_order THEN ? ELSE preferred_supplier_id END,source_rate_card_id=COALESCE(source_rate_card_id,?),priority_order=LEAST(priority_order,?),status='active',source='supplier_rate',updated_by_admin_id=? WHERE id=?";
            $vals=[];if($hasLocationId)$vals[]=$locationId?:null;array_push($vals,$city,$roomType,$mealPlan,$priority,$supplierId?:null,$rateCardId,$priority,$adminId?:null,(int)$existing['id']);
            $pdo->prepare($sql)->execute($vals);
            return;
        }
        if($hasLocationId){
            $pdo->prepare("INSERT INTO hotels(destination_id,location_id,hotel_name,city,star_category,default_room_type,default_meal_plan,preferred_supplier_id,source_rate_card_id,is_preferred,priority_order,status,source,notes,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,?,0,?,'active','supplier_rate',?,?,?)")
                ->execute([$destinationId,$locationId?:null,$hotelName,$city,$star,$roomType?:null,$mealPlan?:null,$supplierId?:null,$rateCardId,$priority,'Created automatically from Supplier 360 destination/city rate.',$adminId?:null,$adminId?:null]);
        }else{
            $pdo->prepare("INSERT INTO hotels(destination_id,hotel_name,city,star_category,default_room_type,default_meal_plan,preferred_supplier_id,source_rate_card_id,is_preferred,priority_order,status,source,notes,created_by_admin_id,updated_by_admin_id) VALUES(?,?,?,?,?,?,?,?,0,?,'active','supplier_rate',?,?,?)")
                ->execute([$destinationId,$hotelName,$city,$star,$roomType?:null,$mealPlan?:null,$supplierId?:null,$rateCardId,$priority,'Created automatically from Supplier 360 destination/city rate.',$adminId?:null,$adminId?:null]);
        }
    }catch(Throwable $ignored){}
}

$id=max(0,(int)($_GET['id']??$_POST['supplier_id']??0));
$stmt=$pdo->prepare("SELECT * FROM suppliers WHERE id=? LIMIT 1");
$stmt->execute([$id]);
$supplier=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$supplier){http_response_code(404);exit('Supplier not found.');}
if(function_exists('tsAclRequire')){try{tsAclRequire($pdo,$adminId,'view_supplier_cost','view_supplier_master_cost','supplier',$id);}catch(RuntimeException $e){http_response_code(403);exit(sdE($e->getMessage()));}}

// V9 child-city AJAX. Selecting Tamil Nadu now loads Chennai/Madurai/Ooty/etc.,
// not "Tamil Nadu" again as the city. Saved/manual supplier cities are merged into the same list.
if(isset($_GET['location_ajax'])){
    header('Content-Type: application/json; charset=utf-8');
    try{
        $action=trim((string)$_GET['location_ajax']);
        if($action!=='cities') throw new RuntimeException('Invalid location request.');
        $destinationId=max(0,(int)($_GET['destination_id']??0));
        if($destinationId<=0) throw new RuntimeException('Select a destination first.');
        $force=!empty($_GET['refresh']);
        if(!function_exists('tsLocationSyncGeoCities')) throw new RuntimeException('Destination City Master is unavailable.');
        $data=tsLocationSyncGeoCities($pdo,$destinationId,$adminId,$force);
        $dest=tsLocationDestination($pdo,$destinationId);
        $rows=[];
        foreach(($data['cities']??[]) as $row){
            $rows[]=['id'=>(int)($row['id']??0),'city'=>(string)($row['location_name']??''),'source'=>(string)($row['source']??'City Master')];
        }
        echo json_encode(['success'=>true,'destination'=>$dest,'data'=>$rows,'synced'=>(int)($data['synced']??0),'source'=>$data['source']??'local','message'=>$data['message']??''],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
    }catch(Throwable $e){http_response_code(422);echo json_encode(['success'=>false,'message'=>$e->getMessage()],JSON_UNESCAPED_UNICODE);exit;}
}

if(empty($_SESSION['supplier_detail_csrf']))$_SESSION['supplier_detail_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['supplier_detail_csrf'];
$success=(string)($_SESSION['supplier_detail_success']??'');
$error=(string)($_SESSION['supplier_detail_error']??'');
unset($_SESSION['supplier_detail_success'],$_SESSION['supplier_detail_error']);

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        if(!hash_equals($csrf,(string)($_POST['csrf']??'')))throw new RuntimeException('Security verification failed.');
        if(function_exists('tsAclRequire'))tsAclRequire($pdo,$adminId,'manage_supplier_procurement','manage_supplier_master','supplier',$id);
        $action=trim((string)($_POST['action']??''));

        if($action==='update_supplier'){
            $company=trim((string)($_POST['company_name']??''));
            if($company==='')throw new RuntimeException('Company name is required.');
            $priority=in_array((string)($_POST['priority']??''),['preferred','regular','backup'],true)?(string)$_POST['priority']:'regular';
            $status=in_array((string)($_POST['status']??''),['active','inactive'],true)?(string)$_POST['status']:'active';
            $ratingRaw=trim((string)($_POST['internal_rating']??''));
            $rating=$ratingRaw===''?null:max(0,min(5,(float)$ratingRaw));
            $stmt=$pdo->prepare("UPDATE suppliers SET company_name=?,supplier_type=?,legal_name=?,gstin=?,tax_id=?,website=?,country=?,state_region=?,city=?,address=?,default_currency=?,priority=?,internal_rating=?,payment_terms=?,cancellation_terms=?,notes=?,status=?,updated_by_admin_id=? WHERE id=?");
            $stmt->execute([
                $company,trim((string)($_POST['supplier_type']??''))?:null,trim((string)($_POST['legal_name']??''))?:null,
                strtoupper(trim((string)($_POST['gstin']??'')))?:null,trim((string)($_POST['tax_id']??''))?:null,
                trim((string)($_POST['website']??''))?:null,trim((string)($_POST['country']??''))?:null,
                trim((string)($_POST['state_region']??''))?:null,trim((string)($_POST['city']??''))?:null,
                trim((string)($_POST['address']??''))?:null,strtoupper(trim((string)($_POST['default_currency']??'INR')))?:'INR',
                $priority,$rating,trim((string)($_POST['payment_terms']??''))?:null,
                trim((string)($_POST['cancellation_terms']??''))?:null,trim((string)($_POST['notes']??''))?:null,
                $status,$adminId,$id
            ]);
            $_SESSION['supplier_detail_success']='Supplier profile updated.';
        }

        if($action==='add_contact'){
            $name=trim((string)($_POST['contact_name']??''));
            if($name==='')throw new RuntimeException('Contact name is required.');
            $primary=!empty($_POST['is_primary'])?1:0;
            if($primary){
                $stmt=$pdo->prepare("UPDATE supplier_contacts SET is_primary=0 WHERE supplier_id=?");
                $stmt->execute([$id]);
            }
            $stmt=$pdo->prepare("INSERT INTO supplier_contacts (supplier_id,contact_name,department,designation,mobile,whatsapp,email,is_primary,status,notes) VALUES (?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([$id,$name,trim((string)($_POST['department']??''))?:null,trim((string)($_POST['designation']??''))?:null,trim((string)($_POST['mobile']??''))?:null,trim((string)($_POST['whatsapp']??''))?:null,strtolower(trim((string)($_POST['email']??'')))?:null,$primary,'active',trim((string)($_POST['contact_notes']??''))?:null]);
            $_SESSION['supplier_detail_success']='Supplier contact added.';
        }

        if($action==='delete_contact'){
            $contactId=max(0,(int)($_POST['contact_id']??0));
            $stmt=$pdo->prepare("DELETE FROM supplier_contacts WHERE id=? AND supplier_id=?");
            $stmt->execute([$contactId,$id]);
            $_SESSION['supplier_detail_success']='Supplier contact removed.';
        }

        if($action==='save_destinations'){
            $selected=array_values(array_unique(array_filter(array_map('intval',(array)($_POST['destination_ids']??[])))));
            $pdo->beginTransaction();
            $pdo->prepare("DELETE FROM supplier_destinations WHERE supplier_id=?")->execute([$id]);
            if($selected){
                $ins=$pdo->prepare("INSERT INTO supplier_destinations (supplier_id,destination_id) VALUES (?,?)");
                foreach($selected as $destId)$ins->execute([$id,$destId]);
            }
            $pdo->commit();
            $_SESSION['supplier_detail_success']='Destination capability updated.';
        }

        if($action==='save_services'){
            $selected=array_values(array_unique(array_filter(array_map('intval',(array)($_POST['service_ids']??[])))));
            $pdo->beginTransaction();
            $pdo->prepare("DELETE FROM supplier_services WHERE supplier_id=?")->execute([$id]);
            if($selected){
                $ins=$pdo->prepare("INSERT INTO supplier_services (supplier_id,service_type_id) VALUES (?,?)");
                foreach($selected as $serviceId)$ins->execute([$id,$serviceId]);
            }
            $pdo->commit();
            $_SESSION['supplier_detail_success']='Service capability updated.';
        }


        if($action==='create_contract'){
            if(!tsSupplierRateEngineReady($pdo)){
                throw new RuntimeException('Contract Rate SQL is not installed yet.');
            }

            $name=trim((string)($_POST['contract_name']??''));
            $validFrom=trim((string)($_POST['valid_from']??''));
            $validTo=trim((string)($_POST['valid_to']??''));

            if($name==='')throw new RuntimeException('Contract name is required.');
            if($validFrom===''||$validTo==='')throw new RuntimeException('Contract validity dates are required.');
            if($validTo<$validFrom)throw new RuntimeException('Contract end date cannot be before start date.');

            $status=in_array((string)($_POST['contract_status']??''),['draft','active','inactive'],true)
                ? (string)$_POST['contract_status']
                : 'draft';

            $currency=strtoupper(trim((string)($_POST['contract_currency']??$supplier['default_currency']??'INR')));
            if($currency==='')$currency='INR';

            $tax=max(0,(float)($_POST['supplier_tax_percent']??0));
            $taxIncluded=!empty($_POST['tax_included'])?1:0;
            $code=tsSupplierContractCode($pdo,$id);

            $stmt=$pdo->prepare("
                INSERT INTO supplier_contracts
                (
                    supplier_id,contract_code,contract_name,currency,
                    valid_from,valid_to,status,source_reference,
                    supplier_tax_percent,tax_included,
                    payment_terms,cancellation_terms,notes,
                    created_by_admin_id,updated_by_admin_id
                )
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ");
            $stmt->execute([
                $id,$code,$name,$currency,$validFrom,$validTo,$status,
                trim((string)($_POST['source_reference']??''))?:null,
                $tax,$taxIncluded,
                trim((string)($_POST['contract_payment_terms']??''))?:null,
                trim((string)($_POST['contract_cancellation_terms']??''))?:null,
                trim((string)($_POST['contract_notes']??''))?:null,
                $adminId,$adminId
            ]);

            $_SESSION['supplier_detail_success']='Supplier contract '.$code.' created.';
        }

        if($action==='add_predefined_rate'){
            if(!tsSupplierRateEngineReady($pdo)){
                throw new RuntimeException('Contract Rate SQL is not installed yet.');
            }

            $contractId=max(0,(int)($_POST['contract_id']??0));
            $stmt=$pdo->prepare("
                SELECT *
                FROM supplier_contracts
                WHERE id=? AND supplier_id=?
                LIMIT 1
            ");
            $stmt->execute([$contractId,$id]);
            $contract=$stmt->fetch(PDO::FETCH_ASSOC);

            if(!$contract)throw new RuntimeException('Select a valid supplier contract.');

            $serviceType=strtolower(trim((string)($_POST['rate_service_type']??'other')));
            if(!in_array($serviceType,tsSupplierRateServiceTypes(),true))$serviceType='other';

            $title=trim((string)($_POST['rate_title']??''));
            $rateName=trim((string)($_POST['rate_name']??''));
            $amount=max(0,(float)($_POST['rate_amount']??0));

            if($title==='')throw new RuntimeException('Rate title is required.');
            if($rateName==='')$rateName=$title;
            if($amount<=0)throw new RuntimeException('Enter a positive supplier rate.');

            $validFrom=trim((string)($_POST['rate_valid_from']??''));
            $validTo=trim((string)($_POST['rate_valid_to']??''));
            if($validFrom!==''&&$validTo!==''&&$validTo<$validFrom){
                throw new RuntimeException('Rate end date cannot be before start date.');
            }

            $paxMin=trim((string)($_POST['pax_min']??''));
            $paxMax=trim((string)($_POST['pax_max']??''));
            if($paxMin!==''&&$paxMax!==''&&(int)$paxMax<(int)$paxMin){
                throw new RuntimeException('Maximum PAX cannot be below minimum PAX.');
            }

            $availability=in_array((string)($_POST['availability_status']??''),['available','on_request','closed'],true)
                ? (string)$_POST['availability_status']
                : 'available';

            $rateDestinationId=max(0,(int)($_POST['rate_destination_id']??0));
            $locationCity=trim(preg_replace('/\s+/u',' ',(string)($_POST['location_city']??''))??'');
            $hotelCategory=trim((string)($_POST['hotel_category']??''));
            $propertyName=trim(preg_replace('/\s+/u',' ',(string)($_POST['property_name']??''))??'');
            $roomType=trim((string)($_POST['room_type']??''));
            $mealPlan=trim((string)($_POST['meal_plan']??''));
            $vehicleType=trim(preg_replace('/\s+/u',' ',(string)($_POST['vehicle_type']??''))??'');

            $cityWiseServices=['hotel','transport','transfer','activity','sightseeing','guide','meal','other'];
            if(in_array($serviceType,$cityWiseServices,true)){
                if($rateDestinationId<=0)throw new RuntimeException('Select the destination for this location-wise supplier rate.');
                if($locationCity==='')throw new RuntimeException('Select or type the child Location / City under the destination.');
            }
            if($serviceType==='hotel'){
                if($hotelCategory==='')throw new RuntimeException('Select the hotel category.');
                if($propertyName==='')throw new RuntimeException('Select or enter the hotel name.');
            }
            if(in_array($serviceType,['transport','transfer'],true) && $vehicleType===''){
                throw new RuntimeException('Select or enter the vehicle type.');
            }

            $basis=(string)($_POST['unit_basis']??'flat');
            if(!array_key_exists($basis,tsSupplierRateUnitBases()))$basis='flat';

            $taxRaw=trim((string)($_POST['rate_tax_percent']??''));
            $rateTax=$taxRaw===''?null:max(0,(float)$taxRaw);

            $pdo->beginTransaction();

            if(function_exists('tsLocationEnsureSchema')){try{tsLocationEnsureSchema($pdo);}catch(Throwable $ignored){}}
            $locationId=($rateDestinationId>0 && $locationCity!=='' && function_exists('tsLocationUpsert'))
                ? tsLocationUpsert($pdo,$rateDestinationId,$locationCity,'supplier',$adminId)
                : 0;
            $hasLocationCity=function_exists('tsSupplierColumnExists') && tsSupplierColumnExists($pdo,'supplier_rate_cards','location_city');
            $hasLocationId=function_exists('tsSupplierColumnExists') && tsSupplierColumnExists($pdo,'supplier_rate_cards','location_id');
            if(!$hasLocationCity && in_array($serviceType,['hotel','transport','transfer'],true)){
                throw new RuntimeException('Location-aware supplier rates are not installed yet. Reload once or import travscope-v8-location-aware-supplier-rates.sql.');
            }

            $columns=[
                'contract_id','supplier_id','destination_id'
            ];
            $values=[$contractId,$id,$rateDestinationId?:null];
            if($hasLocationId){$columns[]='location_id';$values[]=$locationId?:null;}
            if($hasLocationCity){$columns[]='location_city';$values[]=$locationCity!==''?$locationCity:null;}
            $columns=array_merge($columns,[
                'service_type','rate_title','valid_from','valid_to','pax_min','pax_max',
                'hotel_category','property_name','room_type','meal_plan','vehicle_type',
                'nationality_rule','blackout_dates','availability_status','confirmation_required',
                'notes','status','created_by_admin_id','updated_by_admin_id'
            ]);
            array_push($values,
                $serviceType,$title,
                $validFrom!==''?$validFrom:null,$validTo!==''?$validTo:null,
                $paxMin!==''?max(0,(int)$paxMin):null,$paxMax!==''?max(0,(int)$paxMax):null,
                $hotelCategory!==''?$hotelCategory:null,$propertyName!==''?$propertyName:null,
                $roomType!==''?$roomType:null,$mealPlan!==''?$mealPlan:null,$vehicleType!==''?$vehicleType:null,
                trim((string)($_POST['nationality_rule']??''))?:null,
                trim((string)($_POST['blackout_dates']??''))?:null,$availability,
                !empty($_POST['confirmation_required'])?1:0,
                trim((string)($_POST['rate_notes']??''))?:null,'active',$adminId,$adminId
            );
            $placeholders=implode(',',array_fill(0,count($columns),'?'));
            $stmt=$pdo->prepare('INSERT INTO supplier_rate_cards (`'.implode('`,`',$columns).'`) VALUES ('.$placeholders.')');
            $stmt->execute($values);

            $rateCardId=(int)$pdo->lastInsertId();

            $stmt=$pdo->prepare("
                INSERT INTO supplier_rate_items
                (
                    rate_card_id,rate_name,unit_basis,amount,
                    tax_percent,tax_included,supplement_amount,
                    child_age_from,child_age_to,min_quantity,max_quantity,
                    status,sort_order,created_by_admin_id,updated_by_admin_id
                )
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ");
            $stmt->execute([
                $rateCardId,$rateName,$basis,$amount,$rateTax,
                !empty($_POST['rate_tax_included'])?1:0,
                max(0,(float)($_POST['supplement_amount']??0)),
                trim((string)($_POST['child_age_from']??''))!==''?max(0,(int)$_POST['child_age_from']):null,
                trim((string)($_POST['child_age_to']??''))!==''?max(0,(int)$_POST['child_age_to']):null,
                trim((string)($_POST['min_quantity']??''))!==''?max(0,(float)$_POST['min_quantity']):null,
                trim((string)($_POST['max_quantity']??''))!==''?max(0,(float)$_POST['max_quantity']):null,
                'active',10,$adminId,$adminId
            ]);

            if($serviceType==='hotel'){
                sdSyncHotelMasterFromRate($pdo,$supplier,$rateDestinationId,$locationCity,$hotelCategory,$propertyName,$roomType,$mealPlan,$rateCardId,$adminId);
            }

            $pdo->commit();
            $_SESSION['supplier_detail_success']=$serviceType==='hotel'
                ? 'Destination/location-wise hotel rate added and Hotel Master synchronized.'
                : (in_array($serviceType,['transport','transfer'],true)
                    ? 'Destination/location-wise vehicle rate added.'
                    : 'Predefined supplier rate added.');
        }

        if($action==='set_contract_status'){
            $contractId=max(0,(int)($_POST['contract_id']??0));
            $status=in_array((string)($_POST['contract_status']??''),['draft','active','inactive','expired'],true)
                ? (string)$_POST['contract_status']
                : 'inactive';

            $stmt=$pdo->prepare("
                UPDATE supplier_contracts
                SET status=?,updated_by_admin_id=?,updated_at=NOW()
                WHERE id=? AND supplier_id=?
            ");
            $stmt->execute([$status,$adminId,$contractId,$id]);
            $_SESSION['supplier_detail_success']='Contract status updated.';
        }

        if($action==='set_rate_status'){
            $rateCardId=max(0,(int)($_POST['rate_card_id']??0));
            $status=(string)($_POST['rate_status']??'inactive')==='active'?'active':'inactive';

            $stmt=$pdo->prepare("
                UPDATE supplier_rate_cards rc
                JOIN supplier_contracts c ON c.id=rc.contract_id
                SET rc.status=?,rc.updated_by_admin_id=?,rc.updated_at=NOW()
                WHERE rc.id=? AND c.supplier_id=?
            ");
            $stmt->execute([$status,$adminId,$rateCardId,$id]);

            $pdo->prepare("
                UPDATE supplier_rate_items
                SET status=?,updated_by_admin_id=?,updated_at=NOW()
                WHERE rate_card_id=?
            ")->execute([$status,$adminId,$rateCardId]);

            $_SESSION['supplier_detail_success']='Rate status updated.';
        }

        header('Location: admin-supplier-details.php?id='.$id);exit;
    }catch(Throwable $e){
        if($pdo->inTransaction())$pdo->rollBack();
        $_SESSION['supplier_detail_error']=$e->getMessage();
        header('Location: admin-supplier-details.php?id='.$id);exit;
    }
}

$stmt=$pdo->prepare("SELECT * FROM supplier_contacts WHERE supplier_id=? ORDER BY is_primary DESC,status ASC,contact_name ASC");
$stmt->execute([$id]);$contacts=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];

$destinations=$pdo->query("SELECT id,name,country,status FROM destinations ORDER BY country,name")->fetchAll(PDO::FETCH_ASSOC)?:[];
$stmt=$pdo->prepare("SELECT destination_id FROM supplier_destinations WHERE supplier_id=?");
$stmt->execute([$id]);$selectedDest=array_map('intval',$stmt->fetchAll(PDO::FETCH_COLUMN)?:[]);

$services=$pdo->query("SELECT id,service_code,service_name FROM supplier_service_types WHERE active=1 ORDER BY sort_order,service_name")->fetchAll(PDO::FETCH_ASSOC)?:[];
$stmt=$pdo->prepare("SELECT service_type_id FROM supplier_services WHERE supplier_id=?");
$stmt->execute([$id]);$selectedServices=array_map('intval',$stmt->fetchAll(PDO::FETCH_COLUMN)?:[]);

$stmt=$pdo->prepare("SELECT d.name,d.country FROM supplier_destinations sd JOIN destinations d ON d.id=sd.destination_id WHERE sd.supplier_id=? ORDER BY d.country,d.name");
$stmt->execute([$id]);$mappedDest=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
$stmt=$pdo->prepare("SELECT t.service_name FROM supplier_services ss JOIN supplier_service_types t ON t.id=ss.service_type_id WHERE ss.supplier_id=? ORDER BY t.sort_order");
$stmt->execute([$id]);$mappedServices=$stmt->fetchAll(PDO::FETCH_COLUMN)?:[];

// V19.1: organised supplier Rate Books are the primary source for quotation-ready seasonal tariffs.
$rateBookReady=function_exists('tsRBReady') && tsRBReady($pdo);
$supplierRateBooks=[];
if($rateBookReady){
    try{
        $stmt=$pdo->prepare("
            SELECT v.*,c.contract_code,c.contract_name,c.status contract_status,
                   sd.id source_document_id,sd.title source_title,sd.original_filename,
                   (SELECT COUNT(*) FROM supplier_contract_itineraries i WHERE i.contract_version_id=v.id) package_count,
                   (SELECT COUNT(*) FROM supplier_contract_pax_rates p WHERE p.contract_version_id=v.id) pax_rate_count,
                   (SELECT COUNT(*) FROM supplier_contract_day_itineraries di WHERE di.contract_version_id=v.id) day_count,
                   (SELECT COUNT(*) FROM supplier_contract_hotel_inventory hi WHERE hi.contract_version_id=v.id) hotel_count,
                   (SELECT COUNT(*) FROM supplier_contract_vehicle_rules vr WHERE vr.contract_version_id=v.id) vehicle_count,
                   (SELECT COUNT(*) FROM supplier_contract_activities a WHERE a.contract_version_id=v.id) activity_count,
                   (SELECT COUNT(*) FROM supplier_contract_policy_items pi WHERE pi.contract_version_id=v.id) policy_count,
                   (SELECT COUNT(*) FROM supplier_contract_version_documents vd WHERE vd.contract_version_id=v.id) document_count
            FROM supplier_contract_versions v
            JOIN supplier_contracts c ON c.id=v.contract_id
            JOIN supplier_documents sd ON sd.id=v.supplier_document_id
            WHERE c.supplier_id=?
            ORDER BY CASE v.status WHEN 'active' THEN 1 WHEN 'review' THEN 2 WHEN 'superseded' THEN 3 ELSE 4 END,
                     v.rate_priority DESC,v.valid_from DESC,v.version_no DESC
        ");
        $stmt->execute([$id]);
        $supplierRateBooks=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $ignored){$supplierRateBooks=[];}
}


/* V20.1: manual-first Supplier Package directory for this supplier. */
$manualSupplierPackages=[];$manualSupplierPackageReady=function_exists('tsMSReady') && tsMSReady($pdo);
if($manualSupplierPackageReady){
    try{
        $stmt=$pdo->prepare("SELECT c.*,
            (SELECT i.supplier_package_code FROM supplier_contract_itineraries i WHERE i.contract_id=c.id ORDER BY i.id LIMIT 1) supplier_package_code,
            (SELECT i.title FROM supplier_contract_itineraries i WHERE i.contract_id=c.id ORDER BY i.id LIMIT 1) supplier_package_title,
            (SELECT i.duration_nights FROM supplier_contract_itineraries i WHERE i.contract_id=c.id ORDER BY i.id LIMIT 1) duration_nights,
            (SELECT i.duration_days FROM supplier_contract_itineraries i WHERE i.contract_id=c.id ORDER BY i.id LIMIT 1) duration_days,
            (SELECT d.name FROM supplier_contract_itineraries i LEFT JOIN destinations d ON d.id=i.destination_id WHERE i.contract_id=c.id ORDER BY i.id LIMIT 1) destination_name,
            (SELECT COUNT(*) FROM supplier_contract_versions v WHERE v.contract_id=c.id) season_count,
            (SELECT COUNT(*) FROM supplier_contract_versions v WHERE v.contract_id=c.id AND v.status='active') active_season_count,
            (SELECT COUNT(*) FROM supplier_contract_pax_rates pr JOIN supplier_contract_rate_groups g ON g.id=pr.rate_group_id WHERE g.contract_id=c.id AND pr.status='active' AND g.status='active') active_pax_rows,
            (SELECT COUNT(*) FROM package_supplier_options o WHERE o.contract_id=c.id AND o.status='active') travscope_links
            FROM supplier_contracts c
            WHERE c.supplier_id=? AND c.record_type='package' AND c.entry_mode='manual'
            ORDER BY CASE c.status WHEN 'active' THEN 1 WHEN 'draft' THEN 2 ELSE 3 END,c.contract_name");
        $stmt->execute([$id]);$manualSupplierPackages=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $ignored){$manualSupplierPackages=[];}
}

/* V20: show exactly which TRAVSCOPE packages use this supplier. */
$supplierLinkedPackages=[];
if(function_exists('tsPSOReady') && tsPSOReady($pdo)){
    try{
        $stmt=$pdo->prepare("SELECT o.*,p.title package_title,p.package_code,p.source_type,p.status package_status,i.title supplier_package_title,i.supplier_package_code,v.season_name,v.valid_from,v.valid_to FROM package_supplier_options o JOIN packages p ON p.id=o.package_id LEFT JOIN supplier_contract_itineraries i ON i.id=o.itinerary_id LEFT JOIN supplier_contract_versions v ON v.id=o.contract_version_id WHERE o.supplier_id=? ORDER BY o.is_primary DESC,p.title,o.id");
        $stmt->execute([$id]);$supplierLinkedPackages=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
    }catch(Throwable $ignored){$supplierLinkedPackages=[];}
}

$contractRateReady=tsSupplierRateEngineReady($pdo);
$supplierContracts=[];
$supplierRates=[];

if($contractRateReady){
    $stmt=$pdo->prepare("
        SELECT *
        FROM supplier_contracts
        WHERE supplier_id=?
        ORDER BY
            CASE status
                WHEN 'active' THEN 1
                WHEN 'draft' THEN 2
                WHEN 'inactive' THEN 3
                ELSE 4
            END,
            valid_to DESC,
            id DESC
    ");
    $stmt->execute([$id]);
    $supplierContracts=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];

    $stmt=$pdo->prepare("
        SELECT
            rc.*,
            c.contract_code,
            c.contract_name,
            c.currency,
            c.supplier_tax_percent,
            c.tax_included contract_tax_included,
            c.valid_from contract_valid_from,
            c.valid_to contract_valid_to,
            d.name destination_name,
            d.country destination_country,
            ri.id rate_item_id,
            ri.rate_name,
            ri.unit_basis,
            ri.amount,
            ri.tax_percent rate_tax_percent,
            ri.tax_included rate_tax_included,
            ri.supplement_amount
        FROM supplier_rate_cards rc
        JOIN supplier_contracts c ON c.id=rc.contract_id
        JOIN supplier_rate_items ri ON ri.rate_card_id=rc.id
        LEFT JOIN destinations d ON d.id=rc.destination_id
        WHERE c.supplier_id=?
        ORDER BY
            CASE rc.status WHEN 'active' THEN 1 ELSE 2 END,
            c.valid_to DESC,
            rc.service_type,
            rc.rate_title,
            ri.sort_order,
            ri.id
    ");
    $stmt->execute([$id]);
    $supplierRates=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
}


$hotelSearchOptions=[];
$vehicleSearchOptions=[];
$locationSearchOptions=[];

try{
    if(tsSupplierTableExists($pdo,'hotels')){
        $sql="SELECT h.id,h.destination_id,h.hotel_name,h.city,h.star_category,h.default_room_type,h.default_meal_plan,d.name destination_name FROM hotels h LEFT JOIN destinations d ON d.id=h.destination_id WHERE h.status='active' ORDER BY COALESCE(NULLIF(h.city,''),d.name),h.star_category DESC,h.hotel_name LIMIT 1500";
        foreach(($pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC)?:[]) as $r){
            $hotelSearchOptions[]=[
                'id'=>(int)$r['id'],'destination_id'=>(int)$r['destination_id'],
                'destination'=>(string)($r['destination_name']??''),'city'=>(string)($r['city']??''),
                'star'=>(int)($r['star_category']??0),'hotel'=>(string)($r['hotel_name']??''),
                'room'=>(string)($r['default_room_type']??''),'meal'=>(string)($r['default_meal_plan']??''),
                'source'=>'Hotel Master'
            ];
        }
    }
}catch(Throwable $ignored){}

try{
    if(tsSupplierTableExists($pdo,'supplier_contract_hotel_inventory')){
        $st=$pdo->prepare("SELECT i.destination_id,i.city,i.supplier_category,i.mapped_star_category,i.hotel_name,i.room_type,i.meal_plan FROM supplier_contract_hotel_inventory i WHERE i.supplier_id=? AND i.status IN ('active','review') ORDER BY i.city,i.mapped_star_category DESC,i.hotel_name LIMIT 1000");
        $st->execute([$id]);
        foreach(($st->fetchAll(PDO::FETCH_ASSOC)?:[]) as $r){
            $hotelSearchOptions[]=[
                'id'=>0,'destination_id'=>(int)($r['destination_id']??0),'destination'=>'',
                'city'=>(string)($r['city']??''),'star'=>(int)($r['mapped_star_category']??0),
                'hotel'=>(string)($r['hotel_name']??''),'room'=>(string)($r['room_type']??''),
                'meal'=>(string)($r['meal_plan']??''),'source'=>'This Supplier Contract'
            ];
        }
    }
}catch(Throwable $ignored){}

try{
    if(tsSupplierTableExists($pdo,'supplier_contract_vehicle_rules')){
        $hasVehicleCity=function_exists('tsSupplierColumnExists') && tsSupplierColumnExists($pdo,'supplier_contract_vehicle_rules','city');
        $cityExpr=$hasVehicleCity?'COALESCE(city,\'\')':'\'\'';
        $st=$pdo->prepare("SELECT destination_id,{$cityExpr} city,supplier_category,pax_min,pax_max,vehicle_type,ac_basis,route_scope FROM supplier_contract_vehicle_rules WHERE supplier_id=? AND status IN ('active','review') ORDER BY vehicle_type LIMIT 700");
        $st->execute([$id]);
        foreach(($st->fetchAll(PDO::FETCH_ASSOC)?:[]) as $r){
            $vehicleSearchOptions[]=[
                'destination_id'=>(int)($r['destination_id']??0),'city'=>(string)($r['city']??''),
                'category'=>(string)($r['supplier_category']??''),'vehicle'=>(string)($r['vehicle_type']??''),
                'pax_min'=>$r['pax_min']!==null?(int)$r['pax_min']:null,
                'pax_max'=>$r['pax_max']!==null?(int)$r['pax_max']:null,
                'ac'=>(string)($r['ac_basis']??''),'route'=>(string)($r['route_scope']??''),
                'source'=>'This Supplier Contract'
            ];
        }
    }
}catch(Throwable $ignored){}

foreach($supplierRates as $r){
    $city=(string)($r['location_city']??'');
    if(trim((string)($r['property_name']??''))!==''){
        $hotelSearchOptions[]=[
            'id'=>0,'destination_id'=>(int)($r['destination_id']??0),'destination'=>(string)($r['destination_name']??''),
            'city'=>$city,'star'=>sdStarFromCategory((string)($r['hotel_category']??'')),
            'hotel'=>(string)$r['property_name'],'room'=>(string)($r['room_type']??''),
            'meal'=>(string)($r['meal_plan']??''),'source'=>'This Supplier Rate'
        ];
    }
    if(trim((string)($r['vehicle_type']??''))!==''){
        $vehicleSearchOptions[]=[
            'destination_id'=>(int)($r['destination_id']??0),'city'=>$city,
            'category'=>(string)($r['hotel_category']??''),'vehicle'=>(string)$r['vehicle_type'],
            'pax_min'=>$r['pax_min']!==null?(int)$r['pax_min']:null,
            'pax_max'=>$r['pax_max']!==null?(int)$r['pax_max']:null,
            'ac'=>'','route'=>'','source'=>'This Supplier Rate'
        ];
    }
}

// Deduplicate suggestions without losing supplier-specific rows.
$dedup=[];$cleanHotels=[];
foreach($hotelSearchOptions as $h){
    if(trim((string)$h['hotel'])==='')continue;
    $key=strtolower(trim((string)$h['destination_id']).'|'.trim((string)$h['city']).'|'.trim((string)$h['star']).'|'.trim((string)$h['hotel']));
    if(isset($dedup[$key]))continue;$dedup[$key]=1;$cleanHotels[]=$h;
}
$hotelSearchOptions=$cleanHotels;
$dedup=[];$cleanVehicles=[];
foreach($vehicleSearchOptions as $v){
    if(trim((string)$v['vehicle'])==='')continue;
    $key=strtolower(trim((string)$v['destination_id']).'|'.trim((string)$v['city']).'|'.trim((string)$v['vehicle']));
    if(isset($dedup[$key]))continue;$dedup[$key]=1;$cleanVehicles[]=$v;
}
$vehicleSearchOptions=$cleanVehicles;
// V9: parent destinations are NOT cities. Load true child locations from Destination City Master.
try{
    if(function_exists('tsLocationEnsureSchema'))tsLocationEnsureSchema($pdo);
    if(function_exists('tsLocationTableExists')&&tsLocationTableExists($pdo,'destination_locations')){
        foreach(($pdo->query("SELECT id,destination_id,location_name,source FROM destination_locations WHERE status='active' ORDER BY destination_id,sort_order,location_name")->fetchAll(PDO::FETCH_ASSOC)?:[]) as $l){
            $locationSearchOptions[]=['id'=>(int)$l['id'],'destination_id'=>(int)$l['destination_id'],'city'=>(string)$l['location_name'],'source'=>'City Master · '.(string)$l['source']];
        }
    }
}catch(Throwable $ignored){}
foreach($hotelSearchOptions as $h){if(trim((string)$h['city'])!=='')$locationSearchOptions[]=['destination_id'=>(int)$h['destination_id'],'city'=>(string)$h['city'],'source'=>$h['source']];}
foreach($vehicleSearchOptions as $v){if(trim((string)$v['city'])!=='')$locationSearchOptions[]=['destination_id'=>(int)$v['destination_id'],'city'=>(string)$v['city'],'source'=>$v['source']];}
$dedup=[];$cleanLocations=[];
foreach($locationSearchOptions as $l){$key=strtolower((string)$l['destination_id'].'|'.trim((string)$l['city']));if(trim((string)$l['city'])===''||isset($dedup[$key]))continue;$dedup[$key]=1;$cleanLocations[]=$l;}
$locationSearchOptions=$cleanLocations;

$current=basename($_SERVER['PHP_SELF']);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= sdE((string)$supplier['company_name']) ?> | Supplier | TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f5f7fb;color:#172033;font-family:Arial,sans-serif}.sidebar{position:fixed;inset:0 auto 0 0;width:260px;background:#07192d;color:#fff;padding:22px 14px;overflow:auto}.brand{display:flex;gap:12px;align-items:center;color:#fff;text-decoration:none;padding:7px 10px 20px}.brand strong{display:block}.brand small{color:#9fb0c6}.menu-title{font-size:10px;letter-spacing:.12em;color:#70849d;padding:19px 12px 7px;font-weight:800}.menu-link{display:flex;gap:11px;align-items:center;color:#c8d2df;text-decoration:none;padding:11px 12px;border-radius:10px;font-size:14px}.menu-link:hover,.menu-link.active{background:#122b47;color:#fff}.menu-link i{width:18px}.main{margin-left:260px}.topbar{height:72px;background:#fff;border-bottom:1px solid #e4e8ef;display:flex;align-items:center;justify-content:space-between;padding:0 26px}.page{padding:26px}.heading{display:flex;justify-content:space-between;gap:15px;align-items:start;margin-bottom:18px}.heading h1{margin:0;font-size:27px}.heading p{margin:6px 0;color:#718096}.btn{border:0;border-radius:10px;padding:10px 14px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;gap:7px;align-items:center}.primary{background:#0b74ff;color:#fff}.soft{background:#edf4ff;color:#145fb7}.danger{background:#fff0f0;color:#a72a2a}.panel{background:#fff;border:1px solid #e5e9f0;border-radius:16px;padding:19px;margin-bottom:17px;box-shadow:0 6px 24px rgba(7,25,45,.04)}.panel h2{margin:0 0 15px;font-size:18px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.full{grid-column:1/-1}.label{display:block;font-size:12px;font-weight:700;margin-bottom:6px}.input,select,textarea{width:100%;border:1px solid #d8e0ea;border-radius:10px;padding:10px;font:inherit;background:#fff}textarea{min-height:80px}.chips{display:flex;gap:7px;flex-wrap:wrap}.chip{padding:7px 9px;border-radius:999px;background:#eef4fb;font-size:12px}.checks{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}.check{border:1px solid #e1e7ee;border-radius:10px;padding:10px}.contact{display:grid;grid-template-columns:1.3fr .9fr 1fr 1fr 1.3fr auto;gap:8px;align-items:center;padding:11px 0;border-bottom:1px solid #edf1f5;font-size:13px}.badge{display:inline-flex;padding:6px 9px;border-radius:999px;background:#e8f8ef;color:#17663e;font-size:11px;font-weight:800}.alert{padding:12px 14px;border-radius:10px;margin-bottom:15px}.ok{background:#e9f8ef;color:#17663e}.err{background:#fff0f0;color:#a23030}.subtle{color:#778494}.actions{display:flex;gap:8px;flex-wrap:wrap}@media(max-width:900px){.sidebar{position:static;width:auto}.main{margin-left:0}.grid,.checks,.contact{grid-template-columns:1fr}.full{grid-column:auto}}

.contract-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:12px}
.contract-head p{margin:4px 0 0;color:#718096;font-size:12px}
.rate-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px;margin-bottom:14px}
.rate-summary>div{border:1px solid #e2e8f0;border-radius:12px;padding:11px;background:#f8fafc}
.rate-summary span{display:block;color:#64748b;font-size:9px;font-weight:800;text-transform:uppercase}
.rate-summary strong{display:block;margin-top:4px;font-size:16px;color:#0f172a}
.contract-card{border:1px solid #dbeafe;border-radius:13px;padding:12px;background:#f8fbff;margin-bottom:9px}
.contract-top{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}
.contract-top strong{font-size:13px}.contract-meta{display:flex;gap:7px;flex-wrap:wrap;margin-top:6px}
.contract-meta span{font-size:9px;font-weight:800;padding:4px 7px;border-radius:999px;background:#fff;color:#475569;border:1px solid #e2e8f0}
.rate-list{display:grid;gap:8px;margin-top:12px}
.rate-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}
.rate-row strong{font-size:11px}.rate-row small{display:block;margin-top:4px;color:#64748b;font-size:9px;line-height:1.45}
.rate-price{text-align:right;white-space:nowrap}.rate-price b{display:block;font-size:14px;color:#047857}
.rate-price span{display:block;margin-top:3px;color:#64748b;font-size:9px}
.rate-forms{display:grid;grid-template-columns:1fr 1.25fr;gap:13px;margin-top:15px}
.rate-box{border:1px dashed #cbd5e1;border-radius:13px;background:#f8fafc}
.rate-box summary{cursor:pointer;padding:12px;font-size:11px;font-weight:900;list-style:none}.rate-box summary::-webkit-details-marker{display:none}
.rate-box .inside{padding:0 12px 12px}
.rate-badge{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:9px;font-weight:900;background:#ecfdf5;color:#047857}
.rate-badge.draft{background:#fff7ed;color:#c2410c}.rate-badge.off{background:#f1f5f9;color:#64748b}
@media(max-width:950px){.rate-forms{grid-template-columns:1fr}.rate-summary{grid-template-columns:1fr 1fr}}
@media(max-width:600px){.rate-summary{grid-template-columns:1fr}.rate-row{grid-template-columns:1fr}.rate-price{text-align:left}}



.rb360-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:14px}.rb360-head h2{margin:0}.rb360-head p{margin:5px 0 0;color:#718096;font-size:12px}.rb360-actions{display:flex;gap:8px;flex-wrap:wrap}.rb360-flow{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:7px;margin:12px 0 15px}.rb360-step{padding:9px;border-radius:11px;border:1px solid #d9e8f7;background:#f8fbff;text-align:center;font-size:9px;font-weight:850;color:#315b85}.rb360-step i{display:block;font-size:15px;margin-bottom:5px;color:#0b74ff}.rb360-summary{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin:10px 0 14px}.rb360-summary>div{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.rb360-summary span{display:block;color:#64748b;font-size:8px;font-weight:850;text-transform:uppercase}.rb360-summary strong{display:block;margin-top:3px;font-size:16px;color:#0f172a}.rb360-card{border:1px solid #d8e7f7;background:linear-gradient(135deg,#f8fbff,#fff);border-radius:14px;padding:13px;margin-top:10px}.rb360-top{display:grid;grid-template-columns:minmax(0,1.5fr) minmax(0,.9fr) auto;gap:12px;align-items:start}.rb360-title{font-size:13px;font-weight:900;color:#123b67}.rb360-meta{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}.rb360-pill{font-size:8px;font-weight:850;padding:4px 7px;border-radius:999px;background:#eef4fb;color:#355e87;border:1px solid #deebf7}.rb360-badge{display:inline-flex;padding:5px 8px;border-radius:999px;font-size:8px;font-weight:950}.rb360-badge.active{background:#ecfdf5;color:#047857}.rb360-badge.future{background:#eff6ff;color:#1d4ed8}.rb360-badge.review{background:#fff7ed;color:#c2410c}.rb360-badge.superseded,.rb360-badge.expired{background:#f1f5f9;color:#64748b}.rb360-source{margin-top:8px;color:#64748b;font-size:9px}.rb360-counts{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:5px;margin-top:10px}.rb360-counts span{padding:6px;border-radius:8px;background:#fff;border:1px solid #e5edf5;text-align:center;font-size:8px;color:#526579}.rb360-counts b{display:block;font-size:11px;color:#143e69}.rb360-empty{padding:18px;border:1px dashed #bfd6ee;border-radius:13px;background:#f8fbff;text-align:center;color:#5d7187}.rb360-ready{padding:10px 12px;border-radius:10px;background:#ecfdf5;color:#047857;font-size:10px;font-weight:750;margin-top:10px}.rb360-warning{padding:10px 12px;border-radius:10px;background:#fff7ed;color:#9a3412;font-size:10px;margin-top:10px}@media(max-width:1050px){.rb360-flow{grid-template-columns:repeat(3,1fr)}.rb360-summary{grid-template-columns:repeat(3,1fr)}.rb360-counts{grid-template-columns:repeat(4,1fr)}.rb360-top{grid-template-columns:1fr}}@media(max-width:650px){.rb360-flow,.rb360-summary,.rb360-counts{grid-template-columns:1fr 1fr}}

.smart-rate-guide{grid-column:1/-1;display:flex;align-items:center;gap:10px;padding:11px 12px;border:1px solid #bfdbfe;border-radius:12px;background:linear-gradient(135deg,#eff6ff,#f8fbff);color:#1e4f86;font-size:10px;line-height:1.5}.smart-rate-guide i{width:30px;height:30px;border-radius:9px;background:#dbeafe;color:#1769d2;display:grid;place-items:center}.smart-rate-guide b{color:#0f3f73}.smart-field{position:relative}.smart-results{position:absolute;z-index:3500;left:0;right:0;top:calc(100% + 4px);max-height:230px;overflow:auto;background:#fff;border:1px solid #cfdced;border-radius:11px;box-shadow:0 14px 35px rgba(15,42,74,.15);display:none}.smart-results.open{display:block}.smart-result{display:block;width:100%;border:0;border-bottom:1px solid #edf2f7;padding:9px 10px;text-align:left;background:#fff;cursor:pointer}.smart-result:last-child{border-bottom:0}.smart-result:hover,.smart-result.active{background:#eff6ff}.smart-result strong{display:block;font-size:10px;color:#0f2f52}.smart-result small{display:block;margin-top:3px;font-size:8px;color:#6f8093}.smart-empty{padding:10px;color:#7b8794;font-size:9px;line-height:1.5}.smart-meta{margin-top:5px;min-height:15px;color:#6b7d90;font-size:8px}.service-section{grid-column:1/-1;border:1px solid #dbe7f4;border-radius:12px;padding:12px;background:#fbfdff}.service-section-title{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px}.service-section-title strong{font-size:11px;color:#123b67}.service-pill{font-size:8px;font-weight:900;padding:4px 7px;border-radius:999px;background:#e8f2ff;color:#1769d2}.service-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.hidden-service{display:none!important}.location-chipline{display:flex;gap:5px;flex-wrap:wrap;margin-top:6px}.location-chip{border:1px solid #d7e4f3;background:#fff;color:#315b85;border-radius:999px;padding:4px 7px;font-size:8px;font-weight:800;cursor:pointer}.location-chip:hover{background:#eaf4ff}.smart-count{font-weight:900;color:#1267c9}.rate-shortcuts{display:flex;gap:7px;flex-wrap:wrap}.rate-shortcuts a{font-size:9px;font-weight:800;text-decoration:none;color:#1769d2;background:#edf5ff;border:1px solid #d6e9ff;padding:6px 8px;border-radius:8px}@media(max-width:700px){.service-grid{grid-template-columns:1fr}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v8">
</head>
<body>
<aside class="sidebar">
<a class="brand" href="admin-dashboard.php"><i class="fa-solid fa-plane-departure"></i><span><strong>TRAVSCOPE</strong><small>Travel Business System</small></span></a>
<div class="menu-title">OVERVIEW</div><a class="menu-link" href="admin-dashboard.php"><i class="fa-solid fa-chart-pie"></i>Dashboard</a>
<div class="menu-title">SALES & CRM</div><a class="menu-link" href="admin-enquiries.php"><i class="fa-regular fa-message"></i>Enquiries</a><a class="menu-link" href="admin-customers.php"><i class="fa-solid fa-users"></i>Customers</a>
<div class="menu-title">TRAVEL PRODUCTS</div><a class="menu-link" href="admin-destinations.php"><i class="fa-solid fa-earth-americas"></i>Destinations</a><a class="menu-link" href="admin-packages.php"><i class="fa-solid fa-suitcase-rolling"></i>Packages</a>
<div class="menu-title">SUPPLIERS</div><a class="menu-link active" href="admin-suppliers.php"><i class="fa-solid fa-handshake"></i>Suppliers</a>
<div class="menu-title">OPERATIONS</div><a class="menu-link" href="admin-bookings.php"><i class="fa-solid fa-calendar-check"></i>Bookings</a><a class="menu-link" href="admin-cancellations.php"><i class="fa-solid fa-ban"></i>Cancellations</a>
<div class="menu-title">FINANCE</div><a class="menu-link" href="admin-payments.php"><i class="fa-solid fa-credit-card"></i>Payments</a>
<div class="menu-title">ADMINISTRATION</div><a class="menu-link" href="admin-settings.php"><i class="fa-solid fa-gear"></i>Settings</a><a class="menu-link" href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i>Logout</a>
</aside>
<main class="main">
<div class="topbar"><strong>Supplier 360</strong><span><?= sdE((string)$admin['name']) ?></span></div>
<div class="page">
<?php if($success):?><div class="alert ok"><?=sdE($success)?></div><?php endif;?>
<?php if($error):?><div class="alert err"><?=sdE($error)?></div><?php endif;?>
<div class="heading">
<div><a class="btn soft" href="admin-suppliers.php">← Suppliers</a><h1 style="margin-top:12px"><?=sdE((string)$supplier['company_name'])?></h1><p><?=sdE((string)$supplier['supplier_code'])?> · <?=sdE((string)($supplier['supplier_type']?:'Supplier'))?></p></div>
<div class="actions"><a class="btn primary" href="admin-supplier-package-manual.php?supplier_id=<?=$id?>"><i class="fa-solid fa-plus"></i> Add Supplier Package</a><a class="btn soft" href="admin-supplier-packages.php?supplier_id=<?=$id?>"><i class="fa-solid fa-box-open"></i> Supplier Packages</a><a class="btn soft" href="admin-supplier-hotels.php?supplier_id=<?=$id?>"><i class="fa-solid fa-hotel"></i> Hotel Options</a><a class="btn soft" href="admin-supplier-requests.php"><i class="fa-solid fa-paper-plane"></i> Supplier Requests</a><span class="badge"><?=sdE(ucfirst((string)$supplier['priority']))?></span><span class="badge"><?=sdE(ucfirst((string)$supplier['status']))?></span></div>
</div>

<div class="panel">
<h2>Supplier Profile</h2>
<form method="post"><input type="hidden" name="csrf" value="<?=sdE($csrf)?>"><input type="hidden" name="action" value="update_supplier"><input type="hidden" name="supplier_id" value="<?=$id?>">
<div class="grid">
<div><label class="label">Company Name *</label><input class="input" name="company_name" required value="<?=sdE((string)$supplier['company_name'])?>"></div>
<div><label class="label">Supplier Type</label><input class="input" name="supplier_type" value="<?=sdE((string)$supplier['supplier_type'])?>"></div>
<div><label class="label">Legal Name</label><input class="input" name="legal_name" value="<?=sdE((string)$supplier['legal_name'])?>"></div>
<div><label class="label">GSTIN</label><input class="input" name="gstin" value="<?=sdE((string)$supplier['gstin'])?>"></div>
<div><label class="label">Country</label><input class="input" name="country" value="<?=sdE((string)$supplier['country'])?>"></div>
<div><label class="label">State / Region</label><input class="input" name="state_region" value="<?=sdE((string)$supplier['state_region'])?>"></div>
<div><label class="label">City</label><input class="input" name="city" value="<?=sdE((string)$supplier['city'])?>"></div>
<div><label class="label">Website</label><input class="input" name="website" value="<?=sdE((string)$supplier['website'])?>"></div>
<div><label class="label">Priority</label><select name="priority"><?php foreach(['preferred'=>'Preferred','regular'=>'Regular','backup'=>'Backup'] as $v=>$l):?><option value="<?=$v?>" <?=$supplier['priority']===$v?'selected':''?>><?=$l?></option><?php endforeach;?></select></div>
<div><label class="label">Internal Rating</label><input class="input" type="number" min="0" max="5" step=".1" name="internal_rating" value="<?=sdE((string)$supplier['internal_rating'])?>"></div>
<div><label class="label">Currency</label><input class="input" name="default_currency" value="<?=sdE((string)$supplier['default_currency'])?>"></div>
<div><label class="label">Status</label><select name="status"><option value="active" <?=$supplier['status']==='active'?'selected':''?>>Active</option><option value="inactive" <?=$supplier['status']==='inactive'?'selected':''?>>Inactive</option></select></div>
<div class="full"><label class="label">Address</label><textarea name="address"><?=sdE((string)$supplier['address'])?></textarea></div>
<div class="full"><label class="label">Payment Terms</label><textarea name="payment_terms"><?=sdE((string)$supplier['payment_terms'])?></textarea></div>
<div class="full"><label class="label">Cancellation Terms</label><textarea name="cancellation_terms"><?=sdE((string)$supplier['cancellation_terms'])?></textarea></div>
<div class="full"><label class="label">Internal Notes</label><textarea name="notes"><?=sdE((string)$supplier['notes'])?></textarea></div>
<div class="full"><button class="btn primary"><i class="fa-solid fa-floppy-disk"></i> Save Profile</button></div>
</div></form>
</div>

<div class="panel">
<h2>Contacts</h2>
<?php if(!$contacts):?><p class="subtle">No contacts added yet.</p><?php endif;?>
<?php foreach($contacts as $c):?>
<div class="contact">
<div><strong><?=sdE((string)$c['contact_name'])?></strong><?php if($c['is_primary']):?> <span class="badge">Primary</span><?php endif;?></div>
<div><?=sdE((string)($c['department']?:'—'))?></div><div><?=sdE((string)($c['mobile']?:'—'))?></div><div><?=sdE((string)($c['whatsapp']?:'—'))?></div><div><?=sdE((string)($c['email']?:'—'))?></div>
<form method="post"><input type="hidden" name="csrf" value="<?=sdE($csrf)?>"><input type="hidden" name="action" value="delete_contact"><input type="hidden" name="supplier_id" value="<?=$id?>"><input type="hidden" name="contact_id" value="<?=(int)$c['id']?>"><button class="btn danger">Remove</button></form>
</div>
<?php endforeach;?>
<hr style="border:0;border-top:1px solid #edf1f5;margin:18px 0">
<form method="post"><input type="hidden" name="csrf" value="<?=sdE($csrf)?>"><input type="hidden" name="action" value="add_contact"><input type="hidden" name="supplier_id" value="<?=$id?>">
<div class="grid">
<div><label class="label">Contact Name *</label><input class="input" name="contact_name" required></div>
<div><label class="label">Department</label><select name="department"><option value="Sales">Sales</option><option value="Operations">Operations</option><option value="Accounts">Accounts</option><option value="Emergency">Emergency</option><option value="Management">Management</option><option value="Other">Other</option></select></div>
<div><label class="label">Designation</label><input class="input" name="designation"></div>
<div><label class="label">Mobile</label><input class="input" name="mobile"></div>
<div><label class="label">WhatsApp</label><input class="input" name="whatsapp"></div>
<div><label class="label">Email</label><input class="input" type="email" name="email"></div>
<div class="full"><label><input type="checkbox" name="is_primary" value="1"> Set as Primary Contact</label></div>
<div class="full"><button class="btn primary"><i class="fa-solid fa-plus"></i> Add Contact</button></div>
</div></form>
</div>

<div class="panel">
<h2>Destination Capability</h2>
<p class="subtle">Select every destination this supplier can handle. This mapping will be used later when an enquiry automatically suggests suitable suppliers.</p>
<?php if($mappedDest):?><div class="chips" style="margin-bottom:14px"><?php foreach($mappedDest as $d):?><span class="chip"><?=sdE((string)$d['name'])?><?=!empty($d['country'])?' · '.sdE((string)$d['country']):''?></span><?php endforeach;?></div><?php endif;?>
<form method="post"><input type="hidden" name="csrf" value="<?=sdE($csrf)?>"><input type="hidden" name="action" value="save_destinations"><input type="hidden" name="supplier_id" value="<?=$id?>">
<div class="checks"><?php foreach($destinations as $d):?><label class="check"><input type="checkbox" name="destination_ids[]" value="<?=(int)$d['id']?>" <?=in_array((int)$d['id'],$selectedDest,true)?'checked':''?>> <strong><?=sdE((string)$d['name'])?></strong><br><span class="subtle"><?=sdE((string)$d['country'])?></span></label><?php endforeach;?></div>
<div style="margin-top:13px"><button class="btn primary">Save Destinations</button></div></form>
</div>

<div class="panel">
<h2>Service Capability</h2>
<p class="subtle">Select the services this supplier can quote or fulfill.</p>
<?php if($mappedServices):?><div class="chips" style="margin-bottom:14px"><?php foreach($mappedServices as $name):?><span class="chip"><?=sdE((string)$name)?></span><?php endforeach;?></div><?php endif;?>
<form method="post"><input type="hidden" name="csrf" value="<?=sdE($csrf)?>"><input type="hidden" name="action" value="save_services"><input type="hidden" name="supplier_id" value="<?=$id?>">
<div class="checks"><?php foreach($services as $s):?><label class="check"><input type="checkbox" name="service_ids[]" value="<?=(int)$s['id']?>" <?=in_array((int)$s['id'],$selectedServices,true)?'checked':''?>> <?=sdE((string)$s['service_name'])?></label><?php endforeach;?></div>
<div style="margin-top:13px"><button class="btn primary">Save Services</button></div></form>
</div>

<div class="panel" id="supplier-packages-manual">
<div class="rb360-head"><div><h2><i class="fa-solid fa-box-open" style="color:#0b74ff"></i> Supplier Packages & Seasonal Cost</h2><p><strong>Manual-first testing:</strong> enter exactly what this supplier offers. Each Supplier Package can have Regular/High/Peak seasons, exact PAX/category costs, itinerary, vehicles, activities and terms. Hotel Options are maintained once at Supplier level, location-wise/category-wise. These are internal sourcing records, not customer-facing TRAVSCOPE packages.</p></div><div class="rb360-actions"><a class="btn primary" href="admin-supplier-package-manual.php?supplier_id=<?=$id?>"><i class="fa-solid fa-plus"></i> Add Supplier Package</a><a class="btn soft" href="admin-supplier-packages.php?supplier_id=<?=$id?>"><i class="fa-solid fa-list"></i> All Supplier Packages</a></div></div>
<div class="rb360-flow"><div class="rb360-step"><i class="fa-solid fa-handshake"></i>Supplier</div><div class="rb360-step"><i class="fa-solid fa-box-open"></i>Manual Package</div><div class="rb360-step"><i class="fa-solid fa-calendar-days"></i>Season / Validity</div><div class="rb360-step"><i class="fa-solid fa-users"></i>Exact PAX Cost</div><div class="rb360-step"><i class="fa-solid fa-route"></i>Itinerary / Hotels</div><div class="rb360-step"><i class="fa-solid fa-file-invoice-dollar"></i>Package / Quotation</div></div>
<?php if(!$manualSupplierPackageReady):?>
<div class="rb360-warning"><strong>Manual Supplier Package database update is not installed.</strong> Import <code>TRAVSCOPE_V20_1_MANUAL_SUPPLIER_PACKAGE_UPDATE.sql</code> once.</div>
<?php else:?>
<?php $mspActive=count(array_filter($manualSupplierPackages,static fn($r)=>(string)($r['status']??'')==='active'));$mspSeasons=array_sum(array_map(static fn($r)=>(int)($r['season_count']??0),$manualSupplierPackages));$mspRates=array_sum(array_map(static fn($r)=>(int)($r['active_pax_rows']??0),$manualSupplierPackages));$mspLinks=array_sum(array_map(static fn($r)=>(int)($r['travscope_links']??0),$manualSupplierPackages));?>
<div class="rb360-summary"><div><span>Supplier Packages</span><strong><?=count($manualSupplierPackages)?></strong></div><div><span>Active</span><strong><?=$mspActive?></strong></div><div><span>Seasons</span><strong><?=$mspSeasons?></strong></div><div><span>Active PAX Rates</span><strong><?=$mspRates?></strong></div><div><span>TRAVSCOPE Links</span><strong><?=$mspLinks?></strong></div></div>
<?php if(!$manualSupplierPackages):?>
<div class="rb360-empty"><i class="fa-solid fa-box-open" style="font-size:24px;color:#8fb7df"></i><h3 style="margin:8px 0 4px">No Supplier Package added yet</h3><div style="font-size:10px">For testing, add package details manually. Word/PDF automatic import is intentionally postponed for a future upgrade.</div><div style="margin-top:12px"><a class="btn primary" href="admin-supplier-package-manual.php?supplier_id=<?=$id?>"><i class="fa-solid fa-plus"></i> Add First Supplier Package</a></div></div>
<?php else:?>
<?php foreach($manualSupplierPackages as $mp):$ready=((string)$mp['status']==='active'&&(int)$mp['active_season_count']>0&&(int)$mp['active_pax_rows']>0);?>
<div class="rb360-card"><div class="rb360-top"><div><div class="rb360-title"><?=sdE((string)($mp['supplier_package_code']?:$mp['contract_name']))?> · <?=sdE((string)($mp['supplier_package_title']?:$mp['contract_name']))?></div><div class="rb360-meta"><span class="rb360-pill"><?=sdE((string)($mp['destination_name']?:'Destination not set'))?></span><span class="rb360-pill"><?=(int)$mp['duration_nights']?>N / <?=(int)$mp['duration_days']?>D</span><span class="rb360-pill"><?=(int)$mp['season_count']?> season(s)</span><span class="rb360-pill"><?=(int)$mp['active_pax_rows']?> active PAX rows</span></div><div class="rb360-source"><i class="fa-solid fa-pen-to-square"></i> Entry: Manual · Package belongs to supplier; customer Package Master remains separate.</div></div><div><span class="rb360-badge <?=sdE((string)$mp['status'])?>"><?=sdE(strtoupper((string)$mp['status']))?></span><?php if($ready):?><div class="rb360-ready"><i class="fa-solid fa-circle-check"></i> Quotation-ready for matching travel date + season + exact PAX.</div><?php else:?><div class="rb360-warning"><i class="fa-solid fa-triangle-exclamation"></i> Add/activate a season and exact PAX rates before quotation use.</div><?php endif;?></div><div class="rb360-actions"><a class="btn primary" href="admin-supplier-package-manual.php?id=<?=(int)$mp['id']?>"><i class="fa-solid fa-pen"></i> Manage Package</a><a class="btn soft" href="admin-package-import-supplier.php?supplier_id=<?=$id?>"><i class="fa-solid fa-link"></i> Use in Package Master</a></div></div></div>
<?php endforeach;?>
<?php endif;?>
<div class="rb360-warning" style="margin-top:12px"><strong>Future upgrade:</strong> supplier Word/PDF/Excel parsing and AI-assisted import remain available for later development, but are intentionally removed from the main testing workflow now. Manual data is the source of truth.</div>
<?php endif;?>
</div>

<div class="panel" id="travscope-package-links">
<div class="rb360-head"><div><h2><i class="fa-solid fa-link" style="color:#0b74ff"></i> TRAVSCOPE Packages Using This Supplier</h2><p>These are customer-facing Package Master products that can source their cost from this supplier. The supplier package never replaces the TRAVSCOPE package.</p></div><div class="rb360-actions"><a class="btn primary" href="admin-package-import-supplier.php?supplier_id=<?=$id?>"><i class="fa-solid fa-link"></i> Create/Link From Supplier Package</a><a class="btn soft" href="admin-packages.php"><i class="fa-solid fa-suitcase-rolling"></i> Package Master</a></div></div>
<?php if(!$supplierLinkedPackages):?>
<div class="rb360-empty"><strong>No TRAVSCOPE package is linked to this supplier yet.</strong><div style="margin-top:5px;font-size:10px">Use <em>Create Package From Supplier</em>, or open any existing Package Master record → Supplier & Costing → link this supplier as Primary/Alternate DMC.</div></div>
<?php else:?><div style="overflow:auto"><table style="width:100%;border-collapse:collapse"><thead><tr><th style="text-align:left;padding:8px;border-bottom:1px solid #e6edf5">TRAVSCOPE Package</th><th style="text-align:left;padding:8px;border-bottom:1px solid #e6edf5">Supplier Package</th><th style="text-align:left;padding:8px;border-bottom:1px solid #e6edf5">Role</th><th style="text-align:left;padding:8px;border-bottom:1px solid #e6edf5">Season / Validity</th><th style="text-align:left;padding:8px;border-bottom:1px solid #e6edf5">Quotation</th><th style="text-align:left;padding:8px;border-bottom:1px solid #e6edf5"></th></tr></thead><tbody><?php foreach($supplierLinkedPackages as $lp):?><tr><td style="padding:8px;border-bottom:1px solid #edf2f7"><strong><?=sdE((string)$lp['package_title'])?></strong><div class="subtle"><?=sdE((string)$lp['package_code'])?> · <?=sdE(ucwords(str_replace('_',' ',(string)$lp['source_type'])))?></div></td><td style="padding:8px;border-bottom:1px solid #edf2f7"><?=sdE((string)($lp['supplier_package_code']?:$lp['supplier_package_title']))?></td><td style="padding:8px;border-bottom:1px solid #edf2f7"><?php if(!empty($lp['is_primary'])):?><span class="rate-badge">PRIMARY DMC</span><?php else:?><span class="rate-badge off"><?=sdE(strtoupper(str_replace('_',' ',(string)$lp['relationship_type'])))?></span><?php endif;?></td><td style="padding:8px;border-bottom:1px solid #edf2f7"><?=sdE((string)($lp['season_name']?:'—'))?><div class="subtle"><?=sdE((string)$lp['valid_from'])?> → <?=sdE((string)$lp['valid_to'])?></div></td><td style="padding:8px;border-bottom:1px solid #edf2f7"><?=!empty($lp['enabled_for_quotation'])?'<span class="rate-badge">ENABLED</span>':'<span class="rate-badge off">HIDDEN</span>'?></td><td style="padding:8px;border-bottom:1px solid #edf2f7"><a class="btn soft" href="admin-package-suppliers.php?package_id=<?=(int)$lp['package_id']?>">Manage Link</a></td></tr><?php endforeach;?></tbody></table></div><?php endif;?>
</div>

<div class="panel" id="contracts-rates" style="display:none">
<div class="contract-head">
<div>
<h2 style="margin-bottom:0">Manual Contracts & Predefined Rates <span class="rate-badge off">ADVANCED / DIRECT ENTRY</span></h2>
<p>Use this section only for negotiated rates entered manually. For Word/PDF supplier tariffs and seasonal package matrices, use the Supplier Rate Books section above.</p>
</div>
<?php if($contractRateReady):?><span class="rate-badge"><i class="fa-solid fa-circle-check"></i>&nbsp; Rate Engine Ready</span><?php endif;?>
</div>

<?php if(!$contractRateReady):?>
<div class="alert err"><strong>Contract Rate SQL is not installed.</strong><br>Import <code>TRAVSCOPE_Supplier_Contract_Predefined_Rate_Engine.sql</code> once, then refresh.</div>
<?php else:?>

<div class="rate-summary">
<div><span>Contracts</span><strong><?=count($supplierContracts)?></strong></div>
<div><span>Active Contracts</span><strong><?=count(array_filter($supplierContracts,static fn($c)=>($c['status']??'')==='active'))?></strong></div>
<div><span>Rate Rows</span><strong><?=count($supplierRates)?></strong></div>
<div><span>Default Currency</span><strong><?=sdE((string)($supplier['default_currency']?:'INR'))?></strong></div>
</div>

<?php if(!$supplierContracts):?><p class="subtle">No supplier contract is recorded yet. Create the first negotiated / contracted rate agreement below.</p><?php endif;?>

<?php foreach($supplierContracts as $contract):?>
<div class="contract-card">
<div class="contract-top">
<div>
<strong><?=sdE((string)$contract['contract_code'])?> · <?=sdE((string)$contract['contract_name'])?></strong>
<div class="contract-meta">
<span><?=sdE((string)$contract['currency'])?></span>
<span><?=sdE((string)$contract['valid_from'])?> → <?=sdE((string)$contract['valid_to'])?></span>
<span>Tax <?=number_format((float)$contract['supplier_tax_percent'],2)?>% <?=$contract['tax_included']?'included':'extra'?></span>
<?php if(!empty($contract['source_reference'])):?><span><?=sdE((string)$contract['source_reference'])?></span><?php endif;?>
</div>
</div>
<div>
<span class="rate-badge <?=$contract['status']==='draft'?'draft':($contract['status']==='active'?'':'off')?>"><?=sdE(ucfirst((string)$contract['status']))?></span>
<form method="post" style="margin-top:6px;display:flex;gap:5px">
<input type="hidden" name="csrf" value="<?=sdE($csrf)?>">
<input type="hidden" name="action" value="set_contract_status">
<input type="hidden" name="supplier_id" value="<?=$id?>">
<input type="hidden" name="contract_id" value="<?=(int)$contract['id']?>">
<select name="contract_status" style="padding:6px;font-size:10px"><?php foreach(['active'=>'Active','draft'=>'Draft','inactive'=>'Inactive','expired'=>'Expired'] as $v=>$l):?><option value="<?=$v?>" <?=$contract['status']===$v?'selected':''?>><?=$l?></option><?php endforeach;?></select>
<button class="btn soft" style="padding:6px 8px;font-size:10px">Update</button>
</form>
</div>
</div>

<div class="rate-list">
<?php $contractRates=array_values(array_filter($supplierRates,static fn($r)=>(int)$r['contract_id']===(int)$contract['id'])); ?>
<?php if(!$contractRates):?><div class="subtle">No rate rows under this contract yet.</div><?php endif;?>
<?php foreach($contractRates as $rate):?>
<div class="rate-row">
<div>
<strong><?=sdE(tsSupplierRateServiceLabel((string)$rate['service_type']))?> · <?=sdE((string)$rate['rate_title'])?></strong>
<small>
<?=!empty($rate['destination_name'])?sdE((string)$rate['destination_name']):'All mapped destinations'?>
<?php if(!empty($rate['location_city'])):?> · <b><?=sdE((string)$rate['location_city'])?></b><?php endif;?>
· <?=sdE(tsSupplierRateUnitBases()[(string)$rate['unit_basis']]??(string)$rate['unit_basis'])?>
<?php if(!empty($rate['property_name'])):?> · <?=sdE((string)$rate['property_name'])?><?php endif;?>
<?php if(!empty($rate['vehicle_type'])):?> · <?=sdE((string)$rate['vehicle_type'])?><?php endif;?>
<?php if(!empty($rate['pax_min'])||!empty($rate['pax_max'])):?> · PAX <?=sdE((string)($rate['pax_min']?:'1'))?>–<?=sdE((string)($rate['pax_max']?:'Any'))?><?php endif;?>
· <?=sdE(ucwords(str_replace('_',' ',(string)$rate['availability_status'])))?>
<?=$rate['confirmation_required']?' · Confirmation required':''?>
</small>
</div>
<div class="rate-price">
<b><?=sdE((string)$rate['currency'])?> <?=number_format((float)$rate['amount'],2)?></b>
<span><?=sdE((string)$rate['rate_name'])?></span>
<form method="post" style="margin-top:5px">
<input type="hidden" name="csrf" value="<?=sdE($csrf)?>">
<input type="hidden" name="action" value="set_rate_status">
<input type="hidden" name="supplier_id" value="<?=$id?>">
<input type="hidden" name="rate_card_id" value="<?=(int)$rate['id']?>">
<input type="hidden" name="rate_status" value="<?=$rate['status']==='active'?'inactive':'active'?>">
<button class="btn <?=$rate['status']==='active'?'danger':'soft'?>" style="padding:5px 7px;font-size:9px"><?=$rate['status']==='active'?'Deactivate':'Activate'?></button>
</form>
</div>
</div>
<?php endforeach;?>
</div>
</div>
<?php endforeach;?>

<div class="rate-forms">
<details class="rate-box">
<summary><i class="fa-solid fa-file-signature"></i> New Supplier Contract</summary>
<div class="inside">
<form method="post"><input type="hidden" name="csrf" value="<?=sdE($csrf)?>"><input type="hidden" name="action" value="create_contract"><input type="hidden" name="supplier_id" value="<?=$id?>">
<div class="grid">
<div class="full"><label class="label">Contract Name *</label><input class="input" name="contract_name" required placeholder="Example: Andaman 2026–27 Contract"></div>
<div><label class="label">Valid From *</label><input class="input" type="date" name="valid_from" required></div>
<div><label class="label">Valid To *</label><input class="input" type="date" name="valid_to" required></div>
<div><label class="label">Currency</label><input class="input" name="contract_currency" value="<?=sdE((string)($supplier['default_currency']?:'INR'))?>"></div>
<div><label class="label">Status</label><select name="contract_status"><option value="draft">Draft</option><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
<div><label class="label">Supplier GST / Tax %</label><input class="input" type="number" min="0" step=".01" name="supplier_tax_percent" value="0"></div>
<div><label class="label">Source Reference</label><input class="input" name="source_reference" placeholder="Contract PDF / email / agreement ref"></div>
<div class="full"><label><input type="checkbox" name="tax_included" value="1"> Supplier tax is already included in contracted rates</label></div>
<div class="full"><label class="label">Payment Terms</label><textarea name="contract_payment_terms"><?=sdE((string)$supplier['payment_terms'])?></textarea></div>
<div class="full"><label class="label">Cancellation Terms</label><textarea name="contract_cancellation_terms"><?=sdE((string)$supplier['cancellation_terms'])?></textarea></div>
<div class="full"><label class="label">Contract Notes</label><textarea name="contract_notes"></textarea></div>
<div class="full"><button class="btn primary"><i class="fa-solid fa-plus"></i> Create Contract</button></div>
</div></form>
</div>
</details>

<details class="rate-box" <?=$supplierContracts?'':'style="opacity:.65"'?>>
<summary><i class="fa-solid fa-tags"></i> Add Predefined Rate</summary>
<div class="inside">
<?php if(!$supplierContracts):?><p class="subtle">Create a supplier contract first.</p><?php else:?>
<form method="post" id="supplierRateForm"><input type="hidden" name="csrf" value="<?=sdE($csrf)?>"><input type="hidden" name="action" value="add_predefined_rate"><input type="hidden" name="supplier_id" value="<?=$id?>">
<div class="grid">
<div class="smart-rate-guide"><i class="fa-solid fa-wand-magic-sparkles"></i><div><b>Destination / Location smart rate entry</b><br>Choose Service → Destination → child City/Location. Example: Tamil Nadu → Chennai/Madurai/Ooty. The city list is loaded from Destination City Master and may be synchronized from the geo service. You can also type a new city manually. Hotel/Vehicle/Activity/Sightseeing/Guide/Meal rates remain city-wise.</div></div>
<div class="full"><label class="label">Contract *</label><select name="contract_id" id="rateContract" required><?php foreach($supplierContracts as $c):?><option value="<?=(int)$c['id']?>"><?=sdE((string)$c['contract_code'])?> · <?=sdE((string)$c['contract_name'])?></option><?php endforeach;?></select></div>
<div><label class="label">Service *</label><select name="rate_service_type" id="rateServiceType"><?php foreach(tsSupplierRateServiceTypes() as $serviceType):?><option value="<?=sdE($serviceType)?>"><?=sdE(tsSupplierRateServiceLabel($serviceType))?></option><?php endforeach;?></select></div>
<div><label class="label">Destination *</label><select name="rate_destination_id" id="rateDestination"><option value="">All / General</option><?php foreach($destinations as $d):?><option value="<?=(int)$d['id']?>"><?=sdE((string)$d['name'])?><?=!empty($d['country'])?' · '.sdE((string)$d['country']):''?></option><?php endforeach;?></select></div>

<div class="full smart-field" id="rateLocationWrap"><label class="label">Location / City <span id="rateLocationRequired">*</span></label><input type="hidden" name="location_id" id="rateLocationId" value="0"><div style="display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px"><input class="input" name="location_city" id="rateLocationCity" autocomplete="off" placeholder="Choose a city under the destination, or type a new location"><button class="btn soft" type="button" id="syncDestinationCities"><i class="fa-solid fa-arrows-rotate"></i> Sync Cities</button></div><div class="smart-results" id="locationResults"></div><div class="smart-meta" id="locationMeta">Select a destination. TRAVSCOPE will load its child cities/locations.</div><div class="location-chipline" id="locationChips"></div></div>

<div class="service-section" id="hotelServiceSection">
<div class="service-section-title"><strong><i class="fa-solid fa-hotel"></i> Destination-wise Hotel</strong><span class="service-pill">AUTO SEARCH FROM HOTEL MASTER</span></div>
<div class="service-grid">
<div><label class="label">Hotel Category *</label><select name="hotel_category" id="rateHotelCategory"><option value="">Select category</option><option>5 Star Luxury</option><option>5 Star</option><option>4 Star Luxury</option><option>4 Star</option><option>3 Star</option><option>2 Star</option><option>Standard</option><option>Budget</option></select></div>
<div class="smart-field"><label class="label">Property / Hotel *</label><input class="input" name="property_name" id="ratePropertyName" autocomplete="off" placeholder="Search hotel by city..."><div class="smart-results" id="hotelResults"></div><div class="smart-meta" id="hotelMeta"><span class="smart-count" id="hotelCount">0</span> matching hotels. You may type a new supplier hotel if it is not yet in Hotel Master.</div></div>
<div><label class="label">Room Type</label><input class="input" name="room_type" id="rateRoomType" placeholder="Deluxe / Standard"></div>
<div><label class="label">Meal Plan</label><input class="input" name="meal_plan" id="rateMealPlan" placeholder="CP / MAP / AP / MAPAI"></div>
</div>
</div>

<div class="service-section hidden-service" id="vehicleServiceSection">
<div class="service-section-title"><strong><i class="fa-solid fa-car-side"></i> Destination-wise Vehicle</strong><span class="service-pill">SEARCH THIS SUPPLIER'S VEHICLES</span></div>
<div class="service-grid">
<div class="smart-field"><label class="label">Vehicle Type *</label><input class="input" name="vehicle_type" id="rateVehicleType" autocomplete="off" placeholder="Search Innova, Crysta, Tempo Traveller..."><div class="smart-results" id="vehicleResults"></div><div class="smart-meta" id="vehicleMeta"><span class="smart-count" id="vehicleCount">0</span> matching supplier vehicles. You may type a new vehicle type.</div></div>
<div><label class="label">Hotel / Supplier Category (optional)</label><input class="input" id="vehicleCategoryMirror" placeholder="Example: 4 Star package" readonly></div>
</div>
</div>

<div class="full"><label class="label">Rate Title *</label><input class="input" name="rate_title" id="rateTitle" required placeholder="Auto suggested from hotel/vehicle selection; you can edit it"></div>
<div><label class="label">Rate Name</label><input class="input" name="rate_name" placeholder="NET contracted rate"></div>
<div><label class="label">Unit Basis</label><select name="unit_basis"><?php foreach(tsSupplierRateUnitBases() as $v=>$l):?><option value="<?=sdE($v)?>"><?=sdE($l)?></option><?php endforeach;?></select></div>
<div><label class="label">Supplier Rate *</label><input class="input" type="number" min=".01" step=".01" name="rate_amount" required></div>
<div><label class="label">Rate GST / Tax %</label><input class="input" type="number" min="0" step=".01" name="rate_tax_percent" placeholder="Blank = use contract tax"></div>
<div><label class="label">Other / Supplement</label><input class="input" type="number" min="0" step=".01" name="supplement_amount" value="0"></div>
<div><label class="label">Availability</label><select name="availability_status"><option value="available">Available</option><option value="on_request">On Request</option><option value="closed">Closed</option></select></div>
<div><label class="label">Rate Valid From</label><input class="input" type="date" name="rate_valid_from"></div>
<div><label class="label">Rate Valid To</label><input class="input" type="date" name="rate_valid_to"></div>
<div><label class="label">Min PAX</label><input class="input" type="number" min="0" name="pax_min" id="ratePaxMin"></div>
<div><label class="label">Max PAX</label><input class="input" type="number" min="0" name="pax_max" id="ratePaxMax"></div>
<div><label class="label">Nationality Rule</label><input class="input" name="nationality_rule" placeholder="Optional"></div>
<div><label class="label">Child Age From</label><input class="input" type="number" min="0" name="child_age_from"></div>
<div><label class="label">Child Age To</label><input class="input" type="number" min="0" name="child_age_to"></div>
<div><label class="label">Min Quantity</label><input class="input" type="number" min="0" step=".01" name="min_quantity"></div>
<div><label class="label">Max Quantity</label><input class="input" type="number" min="0" step=".01" name="max_quantity"></div>
<div class="full"><label><input type="checkbox" name="rate_tax_included" value="1"> Tax is included in this specific rate</label></div>
<div class="full"><label><input type="checkbox" name="confirmation_required" value="1"> Rate requires supplier confirmation before booking</label></div>
<div class="full"><label class="label">Blackout Dates</label><input class="input" name="blackout_dates" placeholder="Example: 24–31 Dec; festival dates"></div>
<div class="full"><label class="label">Rate Notes / Conditions</label><textarea name="rate_notes"></textarea></div>
<div class="full"><div style="background:#eef7ff;border:1px solid #cfe4fb;color:#315e88;border-radius:10px;padding:10px 12px;margin-bottom:10px;font-size:10px;line-height:1.5"><strong>V21 hotel rule:</strong> supplier hotels are maintained once per supplier, location-wise/category-wise. Hotel prices are not entered separately; package cost comes from the seasonal package rate matrix.</div><div class="rate-shortcuts"><a href="admin-supplier-hotels.php?supplier_id=<?=$id?>"><i class="fa-solid fa-hotel"></i> Manage Hotel Options</a><a href="admin-supplier-vehicles.php"><i class="fa-solid fa-car"></i> View Supplier Vehicles</a><a href="admin-hotels.php"><i class="fa-solid fa-building"></i> Open Hotel Master</a></div></div>
<div class="full"><button class="btn primary"><i class="fa-solid fa-plus"></i> Add Destination-wise Rate</button></div>
</div></form>
<?php endif;?>
</div>
</details>
</div>
<?php endif;?>
</div>

</div></main>

<script>
(function(){
    const hotels=<?=json_encode($hotelSearchOptions,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;
    const vehicles=<?=json_encode($vehicleSearchOptions,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;
    const locations=<?=json_encode($locationSearchOptions,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;
    const form=document.getElementById('supplierRateForm');
    if(!form)return;
    const service=document.getElementById('rateServiceType');
    const destination=document.getElementById('rateDestination');
    const city=document.getElementById('rateLocationCity');
    const cityId=document.getElementById('rateLocationId');
    const syncCities=document.getElementById('syncDestinationCities');
    const cityWrap=document.getElementById('rateLocationWrap');
    const cityResults=document.getElementById('locationResults');
    const cityMeta=document.getElementById('locationMeta');
    const cityChips=document.getElementById('locationChips');
    const hotelSection=document.getElementById('hotelServiceSection');
    const vehicleSection=document.getElementById('vehicleServiceSection');
    const hotelCategory=document.getElementById('rateHotelCategory');
    const hotel=document.getElementById('ratePropertyName');
    const hotelResults=document.getElementById('hotelResults');
    const hotelCount=document.getElementById('hotelCount');
    const room=document.getElementById('rateRoomType');
    const meal=document.getElementById('rateMealPlan');
    const vehicle=document.getElementById('rateVehicleType');
    const vehicleResults=document.getElementById('vehicleResults');
    const vehicleCount=document.getElementById('vehicleCount');
    const paxMin=document.getElementById('ratePaxMin');
    const paxMax=document.getElementById('ratePaxMax');
    const title=document.getElementById('rateTitle');
    const locationRequired=document.getElementById('rateLocationRequired');
    const norm=v=>(v||'').toString().trim().toLowerCase().replace(/\s+/g,' ');
    const star=v=>{const m=(v||'').toString().match(/([345])/);return m?parseInt(m[1],10):0;};
    const selectedDest=()=>parseInt(destination.value||'0',10)||0;
    const selectedDestName=()=>((destination.options[destination.selectedIndex]?.text||'').split(' · ')[0]||'').trim();
    const isVehicle=()=>['transport','transfer'].includes(service.value);
    const isHotel=()=>service.value==='hotel';
    const cityWiseServices=['hotel','transport','transfer','activity','sightseeing','guide','meal','other'];
    const isLocationService=()=>cityWiseServices.includes(service.value);
    let titleAuto=true;
    title.addEventListener('input',()=>{titleAuto=title.value.trim()==='';});

    function hideResults(box){box.classList.remove('open');box.innerHTML='';}
    function renderResults(box,items,render,onPick,emptyText){
        box.innerHTML='';
        if(!items.length){
            const e=document.createElement('div');e.className='smart-empty';e.textContent=emptyText;box.appendChild(e);box.classList.add('open');return;
        }
        items.slice(0,14).forEach(item=>{
            const b=document.createElement('button');b.type='button';b.className='smart-result';
            const out=render(item);b.innerHTML='<strong>'+out[0]+'</strong><small>'+out[1]+'</small>';
            b.addEventListener('mousedown',e=>{e.preventDefault();onPick(item);hideResults(box);});box.appendChild(b);
        });
        box.classList.add('open');
    }
    const esc=v=>(v||'').toString().replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));

    async function loadDestinationCities(force=false){
        const d=selectedDest();
        cityId.value='0';
        if(!d){cityMeta.textContent='Select a destination first.';refreshChips();return;}
        cityMeta.textContent=force?'Refreshing child cities…':'Loading child cities…';
        try{
            const url='admin-supplier-details.php?id=<?= (int)$id ?>&location_ajax=cities&destination_id='+encodeURIComponent(d)+(force?'&refresh=1':'');
            const res=await fetch(url,{headers:{'Accept':'application/json'},credentials:'same-origin'});
            const json=await res.json();
            if(!res.ok||!json.success)throw new Error(json.message||'Unable to load city list.');
            const currentKeys=new Set(locations.map(x=>String(x.destination_id)+'|'+norm(x.city)));
            (json.data||[]).forEach(x=>{
                const k=String(d)+'|'+norm(x.city);
                if(x.city&&!currentKeys.has(k)){locations.push({id:x.id||0,destination_id:d,city:x.city,source:'City Master'});currentKeys.add(k);}
            });
            refreshChips();refreshCounts();
            cityMeta.textContent=(json.data||[]).length+' child city/location(s) available for '+((json.destination&&json.destination.name)||'this destination')+'. Type to search or choose below.';
            if(city===document.activeElement)city.dispatchEvent(new Event('input'));
        }catch(err){
            refreshChips();
            cityMeta.textContent='City sync unavailable: '+err.message+' You can still type a new city/location manually.';
        }
    }

    function locationMatches(){
        const d=selectedDest(),q=norm(city.value);
        const seen=new Set();
        return locations.filter(x=>(!d||!x.destination_id||parseInt(x.destination_id,10)===d))
            .filter(x=>!selectedDestName()||norm(x.city)!==norm(selectedDestName()))
            .filter(x=>!q||norm(x.city).includes(q))
            .filter(x=>{const k=norm(x.city);if(!k||seen.has(k))return false;seen.add(k);return true;});
    }
    function hotelMatches(){
        const d=selectedDest(),c=norm(city.value),q=norm(hotel.value),s=star(hotelCategory.value);
        return hotels.filter(x=>!d||!x.destination_id||parseInt(x.destination_id,10)===d)
            .filter(x=>!c||norm(x.city)===c||norm(x.city).includes(c)||c.includes(norm(x.city)))
            .filter(x=>!s||!x.star||parseInt(x.star,10)===s)
            .filter(x=>!q||norm(x.hotel).includes(q)||norm(x.city).includes(q));
    }
    function vehicleMatches(){
        const d=selectedDest(),c=norm(city.value),q=norm(vehicle.value);
        return vehicles.filter(x=>!d||!x.destination_id||parseInt(x.destination_id,10)===d)
            .filter(x=>!c||!x.city||norm(x.city)===c||norm(x.city).includes(c)||c.includes(norm(x.city)))
            .filter(x=>!q||norm(x.vehicle).includes(q)||norm(x.route).includes(q));
    }
    function suggestedTitle(){
        const loc=city.value.trim();
        if(isHotel()){
            const bits=[hotelCategory.value.trim(),hotel.value.trim(),loc].filter(Boolean);
            return bits.join(' · ');
        }
        if(isVehicle()){
            const bits=[vehicle.value.trim(),loc,service.options[service.selectedIndex]?.text||'Transport'].filter(Boolean);
            return bits.join(' · ');
        }
        return [service.options[service.selectedIndex]?.text||service.value,loc].filter(Boolean).join(' · ');
    }
    function refreshTitle(){if(titleAuto||title.value.trim()==='') {title.value=suggestedTitle();titleAuto=true;}}
    function refreshChips(){
        cityChips.innerHTML='';
        const d=selectedDest(),seen=new Set(),arr=[];
        locations.filter(x=>x.city&&(!d||parseInt(x.destination_id||0,10)===d))
            .filter(x=>!selectedDestName()||norm(x.city)!==norm(selectedDestName()))
            .forEach(x=>{const k=norm(x.city);if(k&&!seen.has(k)){seen.add(k);arr.push(x.city);}});
        arr.slice(0,18).forEach(name=>{const b=document.createElement('button');b.type='button';b.className='location-chip';b.textContent=name;b.addEventListener('click',()=>{city.value=name;const hit=locations.find(x=>parseInt(x.destination_id||0,10)===d&&norm(x.city)===norm(name));cityId.value=hit&&hit.id?hit.id:'0';hideResults(cityResults);refreshAll();if(isHotel())hotel.focus();else if(isVehicle())vehicle.focus();});cityChips.appendChild(b);});
        if(!arr.length)cityMeta.textContent='No saved child city yet. Click Sync Cities or type a new city/location manually.';
    }
    function refreshCounts(){hotelCount.textContent=hotelMatches().length;vehicleCount.textContent=vehicleMatches().length;}
    function refreshMode(){
        const h=isHotel(),v=isVehicle(),loc=isLocationService();
        hotelSection.classList.toggle('hidden-service',!h);vehicleSection.classList.toggle('hidden-service',!v);cityWrap.classList.remove('hidden-service');
        [hotelCategory,hotel,room,meal].forEach(el=>{if(el)el.disabled=!h;});
        if(vehicle)vehicle.disabled=!v;
        destination.required=loc;city.required=loc;
        locationRequired.textContent=loc?'*':'';
        refreshChips();refreshCounts();refreshTitle();
    }
    function refreshAll(){refreshChips();refreshCounts();refreshTitle();}

    city.addEventListener('input',()=>{cityId.value='0';const items=locationMatches();renderResults(cityResults,items,x=>[esc(x.city),esc(x.source||'City Master')],x=>{city.value=x.city;cityId.value=x.id||0;refreshAll();},'No matching child city. Keep typing to add this city manually when the rate is saved.');refreshCounts();refreshTitle();});
    city.addEventListener('focus',()=>city.dispatchEvent(new Event('input')));
    hotel.addEventListener('input',()=>{const items=hotelMatches();renderResults(hotelResults,items,x=>[esc(x.hotel),(x.star?esc(x.star+'★')+' · ':'')+esc(x.city||x.destination||'')+' · '+esc(x.source||'Hotel Master')],x=>{hotel.value=x.hotel;if(x.city)city.value=x.city;if(x.star)hotelCategory.value=x.star+' Star';if(x.room)room.value=x.room;if(x.meal)meal.value=x.meal;refreshAll();},'No matching hotel. Type the supplier hotel name; eligible 3★/4★/5★ hotels will sync to Hotel Master after save.');refreshCounts();refreshTitle();});
    hotel.addEventListener('focus',()=>hotel.dispatchEvent(new Event('input')));
    vehicle.addEventListener('input',()=>{const items=vehicleMatches();renderResults(vehicleResults,items,x=>[esc(x.vehicle),esc(x.city||'All locations')+(x.route?' · '+esc(x.route):'')+' · '+esc(x.source||'Supplier')],x=>{vehicle.value=x.vehicle;if(x.city)city.value=x.city;if(x.pax_min&&!paxMin.value)paxMin.value=x.pax_min;if(x.pax_max&&!paxMax.value)paxMax.value=x.pax_max;refreshAll();},'No matching vehicle for this supplier/location. You can type a new vehicle type.');refreshCounts();refreshTitle();});
    vehicle.addEventListener('focus',()=>vehicle.dispatchEvent(new Event('input')));
    destination.addEventListener('change',()=>{city.value='';cityId.value='0';hotel.value='';vehicle.value='';refreshAll();loadDestinationCities(false);});
    if(syncCities)syncCities.addEventListener('click',()=>loadDestinationCities(true));
    service.addEventListener('change',refreshMode);hotelCategory.addEventListener('change',()=>{refreshCounts();refreshTitle();});
    [room,meal].forEach(el=>el.addEventListener('input',refreshTitle));
    document.addEventListener('mousedown',e=>{if(!e.target.closest('.smart-field'))[cityResults,hotelResults,vehicleResults].forEach(hideResults);});
    form.addEventListener('submit',e=>{
        if(isLocationService() && (!selectedDest()||!city.value.trim())){
            e.preventDefault();alert('Select Destination and its child Location / City for this city-wise supplier rate.');return;
        }
        if(isHotel() && (!hotelCategory.value.trim()||!hotel.value.trim())){
            e.preventDefault();alert('Select Hotel Category and Hotel Name.');return;
        }
        if(isVehicle() && !vehicle.value.trim()){
            e.preventDefault();alert('Select or enter Vehicle Type.');return;
        }
    });
    refreshMode();
})();
</script>
<script src="assets/travscope-pro-admin.js?v=20260916-v9" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
