<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
require_once __DIR__.'/package-supplier-functions.php';
if(empty($_SESSION['admin_id'])){header('Location: '.BASE_URL.'admin-login.php');exit;}
$adminId=(int)$_SESSION['admin_id'];
$s=$pdo->prepare("SELECT id,name,status FROM admins WHERE id=? LIMIT 1");$s->execute([$adminId]);$admin=$s->fetch(PDO::FETCH_ASSOC);
if(!$admin||($admin['status']??'')!=='active'){unset($_SESSION['admin_id']);header('Location: '.BASE_URL.'admin-login.php');exit;}
if(empty($_SESSION['pkg_supplier_import_csrf']))$_SESSION['pkg_supplier_import_csrf']=bin2hex(random_bytes(32));$csrf=(string)$_SESSION['pkg_supplier_import_csrf'];
function psiE($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
$success=(string)($_SESSION['pkg_supplier_import_success']??'');$error='';unset($_SESSION['pkg_supplier_import_success']);
$ready=tsPSOReady($pdo);
if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        if(!hash_equals($csrf,(string)($_POST['csrf']??'')))throw new RuntimeException('Security verification failed.');
        if(!$ready)throw new RuntimeException('Install TRAVSCOPE V20 Package Supplier SQL first.');
        $itineraryId=max(0,(int)($_POST['itinerary_id']??0));if($itineraryId<=0)throw new RuntimeException('Choose a supplier package first.');
        $packageId=tsPSOCreatePackageFromSupplier($pdo,$itineraryId,$adminId);
        $importedPriceRows=0;
        try{
            $pc=$pdo->prepare('SELECT COUNT(*) FROM package_date_prices WHERE package_id=?');
            $pc->execute([$packageId]);
            $importedPriceRows=(int)$pc->fetchColumn();
        }catch(Throwable $ignored){}
        $_SESSION['admin_package_success']='Draft TRAVSCOPE package created from the Supplier Package with '.number_format($importedPriceRows).' supplier-derived pricing period(s). Review/adjust customer selling prices before publishing; supplier exact-PAX cost remains linked separately for quotation costing.';
        header('Location: '.BASE_URL.'admin-packages.php?edit='.$packageId.'#package-form');exit;
    }catch(Throwable $e){$error=$e->getMessage();}
}
$supplierId=max(0,(int)($_GET['supplier_id']??0));$contractFocus=max(0,(int)($_GET['contract_id']??0));$itineraryFocus=max(0,(int)($_GET['itinerary_id']??0));
$candidates=$ready?tsPSOSupplierPackageCandidates($pdo,0,$supplierId):[];
$suppliers=[];try{$suppliers=$pdo->query("SELECT id,company_name,supplier_code,priority FROM suppliers WHERE status='active' ORDER BY CASE priority WHEN 'preferred' THEN 1 WHEN 'regular' THEN 2 ELSE 3 END,company_name")->fetchAll(PDO::FETCH_ASSOC)?:[];}catch(Throwable $ignored){}
?><!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Create Package From Supplier | TRAVSCOPE</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260921-v20">
    <style>
        *{box-sizing:border-box}
        body{margin:0;background:#f3f7fc;color:#132c4b;font-family:Inter,Arial,sans-serif}
        /* Standalone fallback retains the legacy sidebar offset; the unified admin shell
           already supplies its own sidebar inset, so never apply the offset twice. */
        .psi-workspace{margin-left:230px;padding:12px 15px 24px;min-width:0;max-width:none;width:calc(100% - 230px)}
        body.ts-pro-admin .psi-workspace{margin:0!important;width:100%!important;max-width:none!important;min-width:0!important;padding:10px 14px 22px!important}
        body.ts-pro-admin .psi-workspace>*{width:100%;min-width:0}
        .psi-workspace .muted{font-size:12px;color:#687e97;line-height:1.5}
        .psi-workspace .btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:10px 13px;border:1px solid transparent;border-radius:9px;font-size:12px;line-height:1.2;font-weight:800;text-decoration:none;white-space:nowrap;cursor:pointer;transition:background .16s,box-shadow .16s}
        .psi-workspace .btn:focus-visible,.psi-workspace .control:focus-visible,.psi-workspace .pkg-search:focus-visible{outline:3px solid #93c5fd;outline-offset:2px}
        .psi-workspace .btn.blue{background:#126beb;color:white;box-shadow:0 3px 9px #155bd51c}
        .psi-workspace .btn.green{background:#087f5b;color:white;box-shadow:0 3px 9px #087f5b20}
        .psi-workspace .btn.soft{background:#edf4ff;border-color:#dce9fa;color:#1859a6}
        .psi-workspace .btn:hover:not(:disabled){filter:brightness(.965)}
        .psi-workspace .btn:disabled{cursor:not-allowed;background:#eff2f6;border-color:#e3e8ef;color:#8292a5}
        /* Compact ERP title bar: no hero banner or unused left gutter. */
        .psi-titleline{display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:57px;padding:6px 2px 9px;border-bottom:1px solid #dde6f1}
        .psi-title-group{display:flex;align-items:center;gap:11px;min-width:0}
        .psi-title-icon{display:grid;place-items:center;width:37px;height:37px;flex:0 0 37px;border:1px solid #d2e5ff;border-radius:10px;background:#e8f3ff;color:#176de0;font-size:16px}
        .psi-titleline h1{font-size:clamp(18px,1.45vw,22px);line-height:1.2;margin:0;color:#103455;letter-spacing:-.3px}
        .psi-titleline .psi-title-meta{margin:3px 0 0;font-size:11px;color:#72869e;line-height:1.35}
        .psi-title-actions{display:flex;align-items:center;justify-content:flex-end;gap:8px;flex-wrap:wrap}
        .psi-count{display:inline-flex;align-items:center;gap:7px;background:#e8f8ee;border:1px solid #c6e9d2;border-radius:8px;color:#08714d;font-size:11px;font-weight:850;padding:7px 10px;white-space:nowrap}
        .psi-count strong{font-size:15px;font-variant-numeric:tabular-nums}
        .psi-title-actions .btn{min-height:35px}
        .psi-panel{background:#fff;border:1px solid #dde6f1;border-radius:12px;margin-top:9px;box-shadow:0 5px 18px #1e46730a;min-width:0}
        .psi-guide summary{cursor:pointer;list-style:none;padding:12px 16px;font-size:12px;font-weight:850;color:#3a607f;display:flex;align-items:center;justify-content:space-between;gap:10px}
        .psi-guide summary::-webkit-details-marker{display:none}
        .psi-guide summary::after{content:'Show steps +';color:#1859a6;font-size:11px}
        .psi-guide[open] summary::after{content:'Hide steps −'}
        .psi-flow{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;padding:0 15px 14px}
        .psi-step{display:flex;align-items:flex-start;gap:9px;padding:11px;border-radius:10px;border:1px solid #dce8f5;background:#eef7ff}
        .psi-step:nth-child(2){background:#f7f0ff}.psi-step:nth-child(3){background:#fff7ea}.psi-step:nth-child(4){background:#edfbf4}
        .psi-step .num{display:grid;place-items:center;flex:0 0 24px;height:24px;border-radius:8px;background:#1169db;color:#fff;font-size:12px;font-weight:900}
        .psi-step:nth-child(2) .num{background:#8350cf}.psi-step:nth-child(3) .num{background:#df8a11}.psi-step:nth-child(4) .num{background:#0a9567}
        .psi-step b{display:block;font-size:12px;margin:0 0 3px}.psi-step small{display:block;color:#71839b;font-size:11px;line-height:1.4}
        .psi-toolbar{display:grid;grid-template-columns:minmax(220px,1fr) minmax(220px,1.45fr) minmax(160px,.7fr) auto;gap:10px;align-items:end;padding:12px 13px}
        .psi-field label{display:block;font-size:11px;font-weight:850;text-transform:uppercase;letter-spacing:.03em;color:#596f88;margin:0 0 6px}
        .psi-workspace .control,.psi-workspace .pkg-search{height:40px;min-width:0;width:100%;padding:9px 11px;border:1px solid #d3dfed;border-radius:9px;background:#fff;color:#193755;font-family:inherit;font-size:13px}
        .psi-searchwrap{position:relative}.psi-searchwrap>i{position:absolute;left:12px;top:13px;color:#6990b6;font-size:12px}.psi-workspace .pkg-search{padding-left:32px}
        .psi-resultbar{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;border-bottom:1px solid #e5ebf3;padding:11px 14px}
        .psi-resultbar h2{font-size:17px;line-height:1.3;margin:0 0 3px;color:#143251}
        .psi-resultbar .muted{margin:0}.psi-livecount{border-radius:8px;background:#edf5ff;padding:7px 10px;font-size:11px;font-weight:850;color:#1d62b1}
        .psi-table-scroll{max-width:100%;overflow:auto;max-height:min(69vh,790px);scrollbar-color:#b7cce1 #f6f9fd;}
        .psi-table{border-collapse:separate;border-spacing:0;width:100%;min-width:1090px;table-layout:fixed}
        .psi-table th{position:sticky;top:0;z-index:2;background:#eaf2fc;color:#294966;border-bottom:1px solid #d8e4f1;text-align:left;text-transform:uppercase;letter-spacing:.035em;font-size:10px;font-weight:900;padding:11px 10px}
        .psi-table td{border-bottom:1px solid #e8eef5;padding:11px 10px;vertical-align:middle;font-size:12px;color:#435976;line-height:1.5}
        .psi-table tr[hidden]{display:none!important}.psi-table tbody tr:last-child td{border-bottom:0}.psi-table tbody tr:hover{background:#f7fbff}.psi-table tbody tr.focus{background:#eff6ff;box-shadow:inset 3px 0 #1474ec}
        .psi-table .row-num{width:43px;text-align:center;color:#8192a8;font-size:11px;font-weight:800}
        .psi-code{font-weight:900;color:#143d6d;font-size:14px;line-height:1.2;margin-bottom:4px;overflow-wrap:anywhere}
        .psi-package-name{max-width:100%;overflow-wrap:anywhere;color:#50677f;font-size:12px;font-weight:620}
        .psi-supplier-name{font-weight:800;color:#203b56;font-size:12px;overflow-wrap:anywhere}
        .psi-subtext{font-size:11px;color:#7890a7;line-height:1.5;margin-top:4px}
        .psi-strong{font-weight:800;color:#264768}.psi-date{font-variant-numeric:tabular-nums;white-space:nowrap}
        .psi-badge{display:inline-flex;align-items:center;gap:4px;border-radius:7px;padding:4px 7px;font-size:10px;font-weight:850;line-height:1.25;white-space:nowrap}
        .psi-badge.blue{background:#e9f2ff;color:#1b68be}.psi-badge.green{background:#e7f8ef;color:#087c56}.psi-badge.amber{background:#fff1d8;color:#a76b10}.psi-badge.gray{background:#f0f4f8;color:#60758b}
        .psi-duration{font-size:13px;font-weight:850;color:#264768;font-variant-numeric:tabular-nums}
        .psi-pax{font-size:16px;color:#117f57;font-weight:900;font-variant-numeric:tabular-nums}
        .psi-action-cell form{display:flex;gap:7px;align-items:center;flex-wrap:wrap;margin:0}
        .psi-action-cell .btn{font-size:11px;padding:9px 10px}
        .psi-action-cell .btn i{font-size:11px}
        .psi-empty{padding:30px 17px;color:#677b92;text-align:center;font-size:13px}
        .psi-notice{padding:12px 14px;border-radius:9px;margin-top:13px;font-size:12px;line-height:1.5}
        .psi-notice.warn{background:#fff7ed;color:#92400e;border:1px solid #ffdfb5}
        .psi-notice.err{background:#fff0f0;color:#a23030;border:1px solid #ffd9d9}
        .psi-footer-note{display:flex;align-items:center;gap:7px;padding:11px 17px;background:#fbfdff;color:#708299;font-size:11px;border-top:1px solid #e5edf6;border-radius:0 0 14px 14px}
        @media(max-width:1160px){.psi-toolbar{grid-template-columns:repeat(2,minmax(0,1fr))}.psi-toolbar .btn{min-height:40px}}
        @media(max-width:900px){.psi-flow{grid-template-columns:repeat(2,minmax(0,1fr))}body.ts-pro-admin .psi-workspace{padding:10px!important}}
        @media(max-width:850px){.psi-workspace{margin-left:0;width:100%;padding:11px}}
        @media(max-width:580px){.psi-titleline{align-items:flex-start;flex-direction:column}.psi-title-actions{width:100%;justify-content:flex-start}.psi-toolbar,.psi-flow{grid-template-columns:1fr}.psi-resultbar{align-items:flex-start}.psi-count{padding:7px 10px}}
    </style>
</head>
<body>
<?php if(is_file(__DIR__.'/includes/admin-sidebar.php'))include __DIR__.'/includes/admin-sidebar.php'; ?>
<main class="psi-workspace">
    <header class="psi-titleline">
        <div class="psi-title-group">
            <span class="psi-title-icon" aria-hidden="true"><i class="fa-solid fa-file-import"></i></span>
            <div>
                <h1>Supplier Package Import</h1>
                <p class="psi-title-meta">Active supplier tours → editable TRAVSCOPE drafts · exact-PAX supplier costs stay linked separately</p>
            </div>
        </div>
        <div class="psi-title-actions">
            <span class="psi-count"><i class="fa-solid fa-boxes-stacked" aria-hidden="true"></i><strong><?=count($candidates)?></strong> active</span>
            <a class="btn soft" href="admin-packages.php"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i> Package Master</a>
        </div>
    </header>
    <?php if($error!==''):?><div class="psi-notice err" role="alert"><?=psiE($error)?></div><?php endif;?>
    <?php if(!$ready):?><div class="psi-notice warn" role="alert">Import the latest <strong>TRAVSCOPE V20.1 Manual Supplier Package SQL</strong> first.</div><?php endif;?>


    <section class="psi-panel" aria-label="Supplier package directory filters">
        <div class="psi-toolbar">
            <form method="get" id="supplier-filter-form" class="psi-field" style="margin:0;display:contents">
                <div class="psi-field">
                    <label for="psi-supplier">Supplier</label>
                    <select name="supplier_id" id="psi-supplier" class="control">
                        <option value="">All active suppliers</option>
                        <?php foreach($suppliers as $sup):?>
                            <option value="<?=(int)$sup['id']?>" <?=((int)$sup['id']===$supplierId?'selected':'')?>><?=psiE($sup['company_name'].(!empty($sup['supplier_code'])?' · '.$sup['supplier_code']:''))?></option>
                        <?php endforeach;?>
                    </select>
                </div>
                <div class="psi-field">
                    <label for="psi-search">Find a package</label>
                    <div class="psi-searchwrap"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i><input type="search" class="pkg-search" id="psi-search" placeholder="Code, tour, destination, supplier or season…" autocomplete="off" aria-controls="psi-package-table"></div>
                </div>
                <div class="psi-field">
                    <label for="psi-readiness">Rate availability</label>
                    <select id="psi-readiness" class="control" aria-controls="psi-package-table">
                        <option value="all">All packages</option>
                        <option value="ready">Ready to import</option>
                        <option value="missing">Rates missing</option>
                    </select>
                </div>
                <button class="btn blue" type="submit"><i class="fa-solid fa-filter"></i> Apply Supplier</button>
            </form>
        </div>
    </section>

    <section class="psi-panel" aria-labelledby="psi-directory-heading">
        <div class="psi-resultbar">
            <div><h2 id="psi-directory-heading">Active Supplier Packages</h2><p class="muted">One row per supplier package · review and create a Draft without mixing seasonal cost with customer selling prices.</p></div>
            <span class="psi-livecount" id="psi-livecount" aria-live="polite"><?=count($candidates)?> package<?=count($candidates)===1?'':'s'?> shown</span>
        </div>
        <?php if(!$candidates):?>
            <div class="psi-empty">No active supplier package is available for this filter. A Draft requires an active package, season, category and exact PAX rate. Check Supplier Packages / Rates first.</div>
        <?php else:?>
            <div class="psi-table-scroll" role="region" aria-label="Active supplier package directory" tabindex="0">
                <table class="psi-table" id="psi-package-table">
                    <colgroup>
                        <col style="width:4%"><col style="width:22%"><col style="width:14%"><col style="width:11%"><col style="width:15%"><col style="width:7%"><col style="width:10%"><col style="width:17%">
                    </colgroup>
                    <thead><tr>
                        <th scope="col" style="text-align:center">#</th>
                        <th scope="col">Package Code / Tour</th>
                        <th scope="col">Supplier</th>
                        <th scope="col">Destination</th>
                        <th scope="col">Season / Validity</th>
                        <th scope="col">Duration</th>
                        <th scope="col">Exact PAX / Status</th>
                        <th scope="col">Actions</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach($candidates as $i=>$row):
                        $focus=($contractFocus>0?$contractFocus===(int)$row['contract_id']:$itineraryFocus===(int)$row['itinerary_id']);
                        $hasRates=(int)$row['active_pax_rows']>0;
                        $searchText=implode(' ',[$row['supplier_package_code'],$row['title'],$row['company_name'],$row['supplier_code'],$row['destination_name'],$row['contract_name'],$row['season_name'],$row['valid_from'],$row['valid_to']]);
                    ?>
                    <tr class="psi-package-row <?=$focus?'focus':''?>" data-search="<?=psiE(strtolower($searchText))?>" data-rate="<?=$hasRates?'ready':'missing'?>" <?=$focus?'data-focus="true"':''?>>
                        <td class="row-num"><?=$i+1?></td>
                        <td>
                            <div class="psi-code"><?=psiE($row['supplier_package_code']?:$row['title'])?></div>
                            <div class="psi-package-name"><?=psiE($row['title'])?></div>
                            <div class="psi-subtext"><?=psiE(ucwords(str_replace('_',' ',(string)($row['entry_mode']?:'Supplier Package'))))?></div>
                        </td>
                        <td>
                            <div class="psi-supplier-name"><?=psiE($row['company_name'])?></div>
                            <?php if(!empty($row['supplier_code'])):?><div class="psi-subtext"><?=psiE($row['supplier_code'])?></div><?php endif;?>
                        </td>
                        <td><span class="psi-strong"><?=psiE($row['destination_name']?:'Not assigned')?></span></td>
                        <td>
                            <div class="psi-strong"><?=psiE($row['season_name']?:'Regular Season')?></div>
                            <div class="psi-subtext psi-date"><?=psiE($row['valid_from']?:'—')?> – <?=psiE($row['valid_to']?:'—')?></div>
                        </td>
                        <td><span class="psi-duration"><?=(int)$row['duration_nights']?>N / <?=(int)$row['duration_days']?>D</span></td>
                        <td>
                            <div class="psi-pax"><?=(int)$row['active_pax_rows']?></div>
                            <div class="psi-subtext" style="margin-top:0"><?=(int)$row['active_rate_groups']?> rate categor<?=((int)$row['active_rate_groups']===1?'y':'ies')?></div>
                            <div style="margin-top:6px"><span class="psi-badge <?=$hasRates?'green':'amber'?>"><i class="fa-solid <?=$hasRates?'fa-circle-check':'fa-triangle-exclamation'?>"></i> <?=$hasRates?'Ready':'Rates missing'?></span></div>
                        </td>
                        <td class="psi-action-cell">
                            <form method="post" onsubmit="return confirm('Create a new TRAVSCOPE Draft package from this supplier package?');">
                                <input type="hidden" name="csrf" value="<?=psiE($csrf)?>">
                                <input type="hidden" name="itinerary_id" value="<?=(int)$row['itinerary_id']?>">
                                <?php if($hasRates):?>
                                    <button type="submit" class="btn green" title="Create an editable TRAVSCOPE package"><i class="fa-solid fa-file-import"></i> Create Draft</button>
                                <?php else:?>
                                    <button class="btn" type="button" disabled title="An active exact-PAX rate is required"><i class="fa-solid fa-triangle-exclamation"></i> Rates Missing</button>
                                <?php endif;?>
                                <a class="btn soft" target="_blank" rel="noopener noreferrer" href="admin-supplier-package-manual.php?id=<?=(int)$row['contract_id']?>&version_id=<?=(int)$row['contract_version_id']?>" title="Open the existing supplier package"><i class="fa-solid fa-box-open"></i> View</a>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach;?>
                    </tbody>
                </table>
            </div>
            <div id="psi-no-match" class="psi-empty" role="status" hidden>No matching package found. Try another code, name, supplier or readiness status.</div>
            <div class="psi-footer-note"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i> Draft creation keeps the supplier source and seasonal exact-PAX costing linked. Existing Package Master records are not overwritten.</div>
        <?php endif;?>
    </section>
    <details class="psi-panel psi-guide">
        <summary><span><i class="fa-solid fa-route" style="color:#1473e6;margin-right:7px"></i> How supplier packages become TRAVSCOPE Drafts</span></summary>
        <div class="psi-flow">
            <div class="psi-step"><span class="num">1</span><div><b>Supplier</b><small>Choose the DMC/operator.</small></div></div>
            <div class="psi-step"><span class="num">2</span><div><b>Supplier Package</b><small>Select the existing supplier tour.</small></div></div>
            <div class="psi-step"><span class="num">3</span><div><b>Season + Exact PAX</b><small>Review rate validity and available rate rows.</small></div></div>
            <div class="psi-step"><span class="num">4</span><div><b>TRAVSCOPE Draft</b><small>Create the editable customer product.</small></div></div>
        </div>
    </details>
</main>
<script src="assets/travscope-pro-admin.js?v=20260921-v20" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
<script>
(function(){
    'use strict';
    const search=document.getElementById('psi-search');
    const readiness=document.getElementById('psi-readiness');
    const count=document.getElementById('psi-livecount');
    const empty=document.getElementById('psi-no-match');
    const rows=Array.from(document.querySelectorAll('.psi-package-row'));
    if(!search||!readiness||!count)return;
    function update(){
        const query=search.value.trim().toLocaleLowerCase();
        const status=readiness.value;
        let shown=0;
        for(const row of rows){
            const matchesText=!query||(row.dataset.search||'').includes(query);
            const matchesRate=status==='all'||row.dataset.rate===status;
            const visible=matchesText&&matchesRate;
            row.hidden=!visible;
            if(visible)shown++;
        }
        count.textContent=shown+' of '+rows.length+' package'+(rows.length===1?'':'s')+' shown';
        if(empty)empty.hidden=shown!==0;
    }
    search.addEventListener('input',update);
    readiness.addEventListener('change',update);
    update();
    const focus=rows.find(row=>row.dataset.focus==='true');
    if(focus){
        focus.setAttribute('aria-current','true');
    }
})();
</script>
</body></html>
