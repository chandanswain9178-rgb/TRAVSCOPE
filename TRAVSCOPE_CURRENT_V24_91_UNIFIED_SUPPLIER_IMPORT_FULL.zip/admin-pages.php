<?php
/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM - COMBINED ADMIN PAGE MANAGER
|--------------------------------------------------------------------------
| One file handles:
| - Page list
| - Add new page
| - Edit page
| - Admin preview
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';

requireAdmin();

$admin = currentAdmin($pdo);

if (!$admin) {
    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_mobile'],
        $_SESSION['admin_role']
    );

    redirect(BASE_URL . 'login.php');
}

$siteName = (string)getSetting($pdo, 'site_name', 'TRAVSCOPE.COM');
$adminInitial = strtoupper(substr((string)($admin['name'] ?? 'A'), 0, 1));

if (empty($_SESSION['admin_pages_csrf'])) {
    $_SESSION['admin_pages_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = (string)$_SESSION['admin_pages_csrf'];

function pageManagerSlug(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '-', $value);
    return trim((string)$value, '-');
}

function pageManagerDate(?string $date): string
{
    if (!$date) {
        return 'Not available';
    }

    $time = strtotime($date);
    return $time ? date('d M Y, h:i A', $time) : 'Not available';
}

function pageManagerRedirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function pageManagerExcerpt(string $html, int $length = 180): string
{
    $text = trim(preg_replace('/\s+/', ' ', strip_tags($html)));

    if (mb_strlen($text) <= $length) {
        return $text;
    }

    return mb_substr($text, 0, $length) . '...';
}

function pageManagerEditorHtml(?string $html): string
{
    return str_replace("\0", '', (string)$html);
}


function pageManagerStandardizePrivacyContent(string $html): string
{
    $html = str_replace("\0", '', $html);

    // Remove accidentally pasted browser/chat form controls completely.
    $html = preg_replace('/<(script|style|form|button|select|textarea|iframe|object|embed)\b[^>]*>.*?<\/\1>/is', '', $html);
    $html = preg_replace('/<(input|button|select|textarea|form|iframe|object|embed)\b[^>]*\/?>/is', '', $html);

    // Remove pasted visual/editor attributes. The normal website page CSS
    // will control the design, just like About Us and Terms & Conditions.
    $html = preg_replace(
        '/\s+(?:style|class|id|align|width|height|color|face|bgcolor|border|contenteditable|spellcheck|role|aria-[a-z0-9_-]+|data-[a-z0-9_-]+|on[a-z]+)\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)/i',
        '',
        $html
    );

    $html = preg_replace('/<\/?font\b[^>]*>/i', '', $html);
    $html = preg_replace('/<span\b[^>]*>(.*?)<\/span>/is', '$1', $html);
    $html = preg_replace('/<p>\s*(?:Browse\.\.\.|No files selected\.?|Ask anything)\s*<\/p>/i', '', $html);
    $html = preg_replace('/(?:<br\s*\/?>\s*){3,}/i', '<br><br>', $html);

    return trim((string)$html);
}

$action = strtolower(trim((string)($_GET['action'] ?? 'list')));
$allowedActions = ['list', 'add', 'edit', 'preview'];

if (!in_array($action, $allowedActions, true)) {
    $action = 'list';
}

$success = '';
$error = '';

if (!empty($_SESSION['admin_pages_success'])) {
    $success = (string)$_SESSION['admin_pages_success'];
    unset($_SESSION['admin_pages_success']);
}

if (!empty($_SESSION['admin_pages_error'])) {
    $error = (string)$_SESSION['admin_pages_error'];
    unset($_SESSION['admin_pages_error']);
}

/*
|--------------------------------------------------------------------------
| SAVE PAGE
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedToken = (string)($_POST['csrf_token'] ?? '');

    if (!hash_equals($csrfToken, $postedToken)) {
        $error = 'Security token mismatch. Please refresh the page and try again.';
    } else {
        $id = (int)($_POST['id'] ?? 0);
        $pageKey = pageManagerSlug((string)($_POST['page_key'] ?? ''));
        $pageTitle = trim((string)($_POST['page_title'] ?? ''));
        $metaTitle = trim((string)($_POST['meta_title'] ?? ''));
        $metaDescription = trim((string)($_POST['meta_description'] ?? ''));
        $heroTitle = trim((string)($_POST['hero_title'] ?? ''));
        $heroSubtitle = trim((string)($_POST['hero_subtitle'] ?? ''));
        $pageContent = trim((string)($_POST['page_content'] ?? ''));

        // Privacy Policy should use the same clean content design as
        // About Us and Terms & Conditions.
        if ($pageKey === 'privacy') {
            $pageContent = pageManagerStandardizePrivacyContent($pageContent);
        }

        $status = strtolower(trim((string)($_POST['status'] ?? 'active')));

        if (!in_array($status, ['active', 'inactive'], true)) {
            $status = 'active';
        }

        if ($pageKey === '') {
            $error = 'Page key is required.';
        } elseif ($pageTitle === '') {
            $error = 'Page title is required.';
        } elseif ($pageContent === '') {
            $error = 'Page content is required.';
        } else {
            try {
                if ($id > 0) {
                    $check = $pdo->prepare("
                        SELECT id
                        FROM website_pages
                        WHERE page_key = ?
                          AND id <> ?
                        LIMIT 1
                    ");
                    $check->execute([$pageKey, $id]);

                    if ($check->fetchColumn()) {
                        throw new RuntimeException('Another page already uses this page key.');
                    }

                    $stmt = $pdo->prepare("
                        UPDATE website_pages
                        SET
                            page_key = ?,
                            page_title = ?,
                            meta_title = ?,
                            meta_description = ?,
                            hero_title = ?,
                            hero_subtitle = ?,
                            page_content = ?,
                            status = ?,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                        LIMIT 1
                    ");

                    $stmt->execute([
                        $pageKey,
                        $pageTitle,
                        $metaTitle !== '' ? $metaTitle : null,
                        $metaDescription !== '' ? $metaDescription : null,
                        $heroTitle !== '' ? $heroTitle : null,
                        $heroSubtitle !== '' ? $heroSubtitle : null,
                        $pageContent,
                        $status,
                        $id
                    ]);

                    $_SESSION['admin_pages_success'] = 'Page updated successfully.';
                } else {
                    $check = $pdo->prepare("
                        SELECT id
                        FROM website_pages
                        WHERE page_key = ?
                        LIMIT 1
                    ");
                    $check->execute([$pageKey]);

                    if ($check->fetchColumn()) {
                        throw new RuntimeException('A page with this page key already exists.');
                    }

                    $stmt = $pdo->prepare("
                        INSERT INTO website_pages
                        (
                            page_key,
                            page_title,
                            meta_title,
                            meta_description,
                            hero_title,
                            hero_subtitle,
                            page_content,
                            status
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ");

                    $stmt->execute([
                        $pageKey,
                        $pageTitle,
                        $metaTitle !== '' ? $metaTitle : null,
                        $metaDescription !== '' ? $metaDescription : null,
                        $heroTitle !== '' ? $heroTitle : null,
                        $heroSubtitle !== '' ? $heroSubtitle : null,
                        $pageContent,
                        $status
                    ]);

                    $_SESSION['admin_pages_success'] = 'New page added successfully.';
                }

                pageManagerRedirect('admin-pages.php');
            } catch (Throwable $e) {
                error_log('TRAVSCOPE page save error: ' . $e->getMessage());
                $error = $e instanceof RuntimeException
                    ? $e->getMessage()
                    : 'The page could not be saved. Please check the database and try again.';
            }
        }

        $action = $id > 0 ? 'edit' : 'add';
    }
}

/*
|--------------------------------------------------------------------------
| LOAD CURRENT PAGE FOR EDIT / PREVIEW
|--------------------------------------------------------------------------
*/

$currentPage = null;
$currentId = (int)($_GET['id'] ?? ($_POST['id'] ?? 0));

if (in_array($action, ['edit', 'preview'], true)) {
    if ($currentId <= 0) {
        $error = 'Invalid page selected.';
        $action = 'list';
    } else {
        try {
            $stmt = $pdo->prepare("
                SELECT *
                FROM website_pages
                WHERE id = ?
                LIMIT 1
            ");
            $stmt->execute([$currentId]);
            $currentPage = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$currentPage) {
                $error = 'The selected page was not found.';
                $action = 'list';
            } elseif (strtolower((string)($currentPage['page_key'] ?? '')) === 'privacy') {
                $currentPage['page_content'] =
                    pageManagerStandardizePrivacyContent((string)($currentPage['page_content'] ?? ''));
            }
        } catch (Throwable $e) {
            error_log('TRAVSCOPE page load error: ' . $e->getMessage());
            $error = 'The selected page could not be loaded.';
            $action = 'list';
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error !== '') {
    $currentPage = [
        'id' => (int)($_POST['id'] ?? 0),
        'page_key' => (string)($_POST['page_key'] ?? ''),
        'page_title' => (string)($_POST['page_title'] ?? ''),
        'meta_title' => (string)($_POST['meta_title'] ?? ''),
        'meta_description' => (string)($_POST['meta_description'] ?? ''),
        'hero_title' => (string)($_POST['hero_title'] ?? ''),
        'hero_subtitle' => (string)($_POST['hero_subtitle'] ?? ''),
        'page_content' => (string)($_POST['page_content'] ?? ''),
        'status' => (string)($_POST['status'] ?? 'active'),
        'updated_at' => null,
    ];
}

/*
|--------------------------------------------------------------------------
| LIST DATA
|--------------------------------------------------------------------------
*/

$search = trim((string)($_GET['q'] ?? ''));
$statusFilter = strtolower(trim((string)($_GET['status'] ?? '')));

if (!in_array($statusFilter, ['', 'active', 'inactive'], true)) {
    $statusFilter = '';
}

$pages = [];
$totalPages = 0;
$activePages = 0;
$inactivePages = 0;
$tableReady = true;

try {
    $pdo->query("SELECT 1 FROM website_pages LIMIT 1");

    $totalPages = (int)$pdo->query(
        "SELECT COUNT(*) FROM website_pages"
    )->fetchColumn();

    $activePages = (int)$pdo->query(
        "SELECT COUNT(*) FROM website_pages WHERE status='active'"
    )->fetchColumn();

    $inactivePages = (int)$pdo->query(
        "SELECT COUNT(*) FROM website_pages WHERE status='inactive'"
    )->fetchColumn();

    if ($action === 'list') {
        $conditions = [];
        $params = [];

        if ($search !== '') {
            $conditions[] = "(
                page_title LIKE ?
                OR page_key LIKE ?
                OR meta_title LIKE ?
                OR hero_title LIKE ?
            )";

            $like = '%' . $search . '%';
            array_push($params, $like, $like, $like, $like);
        }

        if ($statusFilter !== '') {
            $conditions[] = "status = ?";
            $params[] = $statusFilter;
        }

        $sql = "
            SELECT
                id,
                page_key,
                page_title,
                meta_title,
                hero_title,
                page_content,
                status,
                updated_at
            FROM website_pages
        ";

        if ($conditions) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }

        $sql .= "
            ORDER BY
                FIELD(page_key, 'about', 'privacy', 'terms') ASC,
                page_title ASC,
                id ASC
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $pages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $e) {
    $tableReady = false;
    error_log('TRAVSCOPE admin pages load error: ' . $e->getMessage());

    if ($error === '') {
        $error = 'The website_pages table was not found or could not be loaded. Please run the SQL first.';
    }
}

$formPage = $currentPage ?: [
    'id' => 0,
    'page_key' => '',
    'page_title' => '',
    'meta_title' => '',
    'meta_description' => '',
    'hero_title' => '',
    'hero_subtitle' => '',
    'page_content' => '',
    'status' => 'active',
    'updated_at' => null,
];

$pageHeading = match ($action) {
    'add' => 'Add New Page',
    'edit' => 'Edit Page',
    'preview' => 'Page Preview',
    default => 'Website Pages',
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta name="robots" content="noindex,nofollow">
<title><?= e($pageHeading); ?> | <?= e($siteName); ?></title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>
:root{
    --navy:#07192d;
    --blue:#0b74ff;
    --bg:#f5f7fb;
    --white:#fff;
    --text:#172033;
    --muted:#778294;
    --border:#e5e9ef;
    --green:#0b9b63;
    --red:#d94457;
    --orange:#d97706;
    --shadow:0 10px 30px rgba(23,32,51,.06);
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif}
a{text-decoration:none;color:inherit}
button,input,select,textarea{font:inherit}
button{cursor:pointer}
.sidebar{position:fixed;inset:0 auto 0 0;width:265px;background:var(--navy);color:#fff;overflow-y:auto;z-index:1000;transition:.25s}
.sidebar-logo{height:80px;padding:0 22px;display:flex;align-items:center;gap:10px;border-bottom:1px solid rgba(255,255,255,.08);font:800 20px 'Manrope'}
.logo-icon{width:42px;height:42px;display:grid;place-items:center;border-radius:12px;background:var(--blue)}
.sidebar-logo span{color:#65b7ff}
.sidebar-menu{padding:17px 13px 30px}
.menu-title{padding:15px 13px 7px;color:#657b92;font-size:9px;font-weight:800;letter-spacing:1px}
.menu-link{min-height:44px;padding:0 13px;margin:3px 0;border-radius:9px;display:flex;align-items:center;gap:11px;color:#9fb0c2;font-size:11px;font-weight:600}
.menu-link:hover,.menu-link.active{background:var(--blue);color:#fff}
.menu-link i{width:19px;text-align:center}
.main{margin-left:265px;min-height:100vh}
.topbar{height:80px;padding:0 30px;display:flex;align-items:center;justify-content:space-between;background:#fff;border-bottom:1px solid var(--border);position:sticky;top:0;z-index:800}
.topbar-left,.top-actions,.admin-profile{display:flex;align-items:center;gap:11px}
.mobile-menu{display:none;width:39px;height:39px;border:1px solid var(--border);border-radius:9px;background:#fff}
.topbar-title{font:800 13px 'Manrope'}
.view-site{min-height:37px;padding:0 12px;display:flex;align-items:center;gap:7px;border:1px solid var(--border);border-radius:8px;color:#5f6b7c;font-size:9px;font-weight:700}
.admin-profile{padding-left:13px;border-left:1px solid var(--border)}
.admin-avatar{width:39px;height:39px;display:grid;place-items:center;border-radius:10px;background:var(--blue);color:#fff;font-weight:800}
.admin-info strong{display:block;font-size:10px}
.admin-info span{display:block;margin-top:3px;color:var(--muted);font-size:8px}
.content{width:min(1250px,100%);margin:auto;padding:30px}
.page-heading{margin-bottom:22px;display:flex;justify-content:space-between;align-items:flex-end;gap:15px}
.page-heading h1{margin:0;font:800 28px 'Manrope'}
.page-heading p{margin:6px 0 0;color:var(--muted);font-size:11px}
.heading-actions{display:flex;align-items:center;gap:9px;flex-wrap:wrap}
.button{min-height:40px;padding:0 14px;border:0;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;gap:7px;font-size:9px;font-weight:800}
.button.primary{background:var(--blue);color:#fff}
.button.secondary{background:#fff;border:1px solid var(--border);color:#5f6b7c}
.button.green{background:var(--green);color:#fff}
.alert{margin-bottom:18px;padding:13px 15px;border-radius:9px;font-size:10px;line-height:1.5}
.alert.success{background:#eaf9f2;border:1px solid #bfe8d5;color:#08794f}
.alert.error{background:#fff0f2;border:1px solid #f0c3ca;color:#a92d3f}
.stats-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:20px}
.stat-card{padding:20px;background:#fff;border:1px solid var(--border);border-radius:12px;box-shadow:var(--shadow);display:flex;align-items:center;justify-content:space-between;gap:15px}
.stat-copy span{display:block;color:var(--muted);font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.5px}
.stat-copy strong{display:block;margin-top:5px;color:var(--navy);font:800 25px 'Manrope'}
.stat-icon{width:46px;height:46px;border-radius:12px;display:grid;place-items:center;background:#edf5ff;color:var(--blue);font-size:18px}
.stat-icon.green{background:#e9f8f1;color:var(--green)}
.stat-icon.orange{background:#fff5e8;color:var(--orange)}
.card{background:#fff;border:1px solid var(--border);border-radius:12px;box-shadow:var(--shadow);overflow:hidden}
.card-head{padding:17px 19px;display:flex;justify-content:space-between;align-items:center;gap:15px;border-bottom:1px solid var(--border)}
.card-head h2{margin:0;font:800 15px 'Manrope'}
.card-head p{margin:4px 0 0;color:var(--muted);font-size:9px}
.filter-form{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.filter-control{min-height:38px;padding:0 11px;border:1px solid var(--border);border-radius:8px;outline:none;background:#fff;color:var(--text);font-size:10px}
.search-control{width:215px}
.filter-button{min-height:38px;padding:0 13px;border:0;border-radius:8px;background:var(--blue);color:#fff;font-size:9px;font-weight:800}
.reset-button{min-height:38px;padding:0 13px;border:1px solid var(--border);border-radius:8px;background:#fff;color:#627084;display:inline-flex;align-items:center;font-size:9px;font-weight:800}
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;min-width:900px}
th{padding:12px 17px;background:#fafbfd;color:#7a8697;text-align:left;font-size:8px;font-weight:800;text-transform:uppercase;letter-spacing:.55px}
td{padding:15px 17px;border-top:1px solid var(--border);vertical-align:middle;font-size:10px}
.page-name{display:flex;align-items:center;gap:11px}
.page-icon{width:39px;height:39px;border-radius:10px;display:grid;place-items:center;background:#edf5ff;color:var(--blue)}
.page-name strong{display:block;color:var(--navy);font-size:11px}
.page-name small{display:block;margin-top:3px;color:var(--muted);font-size:8px}
.status-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 9px;border-radius:20px;font-size:8px;font-weight:800;text-transform:capitalize}
.status-badge.active{background:#e9f8f1;color:#08794f}
.status-badge.inactive{background:#fff0f2;color:#a92d3f}
.status-dot{width:6px;height:6px;border-radius:50%;background:currentColor}
.actions{display:flex;align-items:center;gap:7px}
.action-button{min-height:34px;padding:0 10px;border:1px solid var(--border);border-radius:7px;display:inline-flex;align-items:center;justify-content:center;gap:6px;background:#fff;color:#5f6b7c;font-size:8px;font-weight:800;white-space:nowrap}
.action-button.edit{border-color:#b9d7ff;background:#edf5ff;color:#0b67d1}
.empty-state{padding:55px 20px;text-align:center}
.empty-state i{font-size:38px;color:#aeb8c5}
.empty-state h3{margin:13px 0 5px;font-family:'Manrope';color:var(--navy)}
.empty-state p{margin:0;color:var(--muted);font-size:10px}
.table-note{padding:13px 17px;border-top:1px solid var(--border);background:#fafbfd;color:var(--muted);font-size:9px}
.form-wrap{padding:22px}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:17px}
.form-group.full{grid-column:1/-1}
.form-group label{display:block;margin-bottom:7px;color:#4f5d70;font-size:10px;font-weight:800}
.form-control{width:100%;min-height:44px;padding:10px 12px;border:1px solid var(--border);border-radius:8px;outline:none;background:#fff;color:var(--text);font-size:11px}
textarea.form-control{min-height:105px;resize:vertical}
.form-help{display:block;margin-top:5px;color:var(--muted);font-size:8px}
.form-actions{display:flex;justify-content:flex-end;gap:9px;margin-top:20px;padding-top:18px;border-top:1px solid var(--border)}
.preview-hero{padding:60px 30px;background:linear-gradient(120deg,#07192d,#0b74ff);color:#fff;text-align:center}
.preview-hero h1{margin:0;font:800 clamp(30px,5vw,54px) 'Manrope'}
.preview-hero p{max-width:760px;margin:12px auto 0;color:#d8e8f8;font-size:14px}
.preview-body{padding:35px;max-width:950px;margin:auto;line-height:1.8;color:#344257}
.preview-body h1,.preview-body h2,.preview-body h3,.preview-body h4{color:var(--navy);font-family:'Manrope'}
.preview-body img{max-width:100%;height:auto;border-radius:10px}
.preview-meta{padding:12px 18px;background:#fafbfd;border-top:1px solid var(--border);color:var(--muted);font-size:9px}
.sidebar-overlay{position:fixed;inset:0;background:rgba(0,0,0,.42);z-index:900;display:none}
.sidebar-overlay.show{display:block}
@media(max-width:900px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:translateX(0)}.main{margin-left:0}.mobile-menu{display:grid;place-items:center}}
@media(max-width:760px){.content{padding:20px 14px 40px}.page-heading{align-items:flex-start;flex-direction:column}.heading-actions{width:100%}.heading-actions a{flex:1}.stats-grid{grid-template-columns:1fr}.card-head{align-items:flex-start;flex-direction:column}.filter-form{width:100%}.filter-control,.search-control,.filter-button,.reset-button{width:100%}.form-grid{grid-template-columns:1fr}.form-group.full{grid-column:auto}.form-actions{flex-direction:column-reverse}.form-actions .button{width:100%}}
@media(max-width:600px){.topbar{height:68px;padding:0 13px}.topbar-title,.admin-info,.view-site span{display:none}.admin-profile{padding-left:0;border:0}.page-heading h1{font-size:23px}.preview-hero{padding:45px 18px}.preview-body{padding:22px 17px}}

/* VISUAL HTML PAGE CONTENT EDITOR */
.page-editor-shell{overflow:hidden;border:1px solid var(--border);border-radius:11px;background:#fff}
.page-editor-toolbar{padding:9px;display:flex;align-items:center;gap:6px;flex-wrap:wrap;border-bottom:1px solid var(--border);background:#f8fafc}
.editor-tool{min-width:38px;min-height:38px;padding:0 10px;border:1px solid #dfe5ec;border-radius:7px;display:inline-flex;align-items:center;justify-content:center;gap:6px;background:#fff;color:#536174;font-size:12px;font-weight:800}
.editor-tool:hover,.editor-tool.active{border-color:#a9ccff;background:#edf5ff;color:var(--blue)}
.editor-separator{width:1px;height:27px;margin:0 2px;background:#dde4ec}
.page-visual-editor{min-height:420px;padding:26px;outline:none;overflow:auto;color:#344257;background:#fff;font-size:15px;line-height:1.8}
.page-visual-editor:focus{box-shadow:inset 0 0 0 2px rgba(11,116,255,.09)}
.page-visual-editor h1,.page-visual-editor h2,.page-visual-editor h3,.page-visual-editor h4{margin:1.15em 0 .55em;color:var(--navy);font-family:'Manrope',sans-serif;line-height:1.3}
.page-visual-editor h1:first-child,.page-visual-editor h2:first-child,.page-visual-editor h3:first-child{margin-top:0}
.page-visual-editor p{margin:.75em 0}
.page-visual-editor ul,.page-visual-editor ol{margin:.8em 0 .8em 1.5em;padding-left:1.1em}
.page-visual-editor li{margin:.35em 0}
.page-visual-editor strong{color:#1c2a3d}
.page-visual-editor a{color:var(--blue);text-decoration:underline}
.page-source-editor{width:100%;min-height:420px;padding:18px;border:0;outline:none;resize:vertical;display:none;background:#0f172a;color:#e2e8f0;font-family:Consolas,'Courier New',monospace;font-size:13px;line-height:1.65}
.page-source-editor.open{display:block}.page-visual-editor.hidden{display:none}
.editor-help{padding:10px 12px;border-top:1px solid var(--border);background:#fbfcfe;color:var(--muted);font-size:11px;line-height:1.55}
.editor-help strong{color:#526174}
.editor-paste-status{margin-left:auto;color:#08794f;font-size:11px;font-weight:800;opacity:0;transition:.2s}
.editor-paste-status.show{opacity:1}
.preview-body{font-size:15px}
.preview-body p{margin:0 0 16px}
.preview-body h1,.preview-body h2,.preview-body h3,.preview-body h4{margin:28px 0 12px;line-height:1.3}
.preview-body h1:first-child,.preview-body h2:first-child,.preview-body h3:first-child{margin-top:0}
.preview-body ul,.preview-body ol{margin:12px 0 20px 24px;padding-left:16px}
.preview-body li{margin:7px 0}
@media(max-width:760px){
 .page-editor-toolbar{gap:5px}
 .editor-tool{min-width:40px;min-height:40px;padding:0 9px;font-size:12px}
 .editor-separator{display:none}
 .page-visual-editor,.page-source-editor{min-height:360px}
 .page-visual-editor{padding:18px 15px;font-size:15px}
 .editor-paste-status{width:100%;margin-left:0}
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ============================================================
   STANDARD WEBSITE PAGE CONTENT DESIGN
   Used by Privacy Policy so it follows the same clean semantic
   content presentation as About Us and Terms & Conditions.
============================================================ */

.page-visual-editor h2,
.preview-body h2{
    margin:28px 0 11px;
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:22px;
    line-height:1.35;
    font-weight:800;
}

.page-visual-editor h3,
.preview-body h3{
    margin:23px 0 9px;
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:18px;
    line-height:1.4;
    font-weight:800;
}

.page-visual-editor p,
.preview-body p{
    margin:0 0 16px;
    color:#344257;
    font-size:15px;
    line-height:1.8;
}

.page-visual-editor ul,
.page-visual-editor ol,
.preview-body ul,
.preview-body ol{
    margin:10px 0 20px 24px;
    padding-left:16px;
    color:#344257;
    font-size:15px;
    line-height:1.75;
}

.page-visual-editor li,
.preview-body li{
    margin:7px 0;
    padding-left:3px;
}

.page-visual-editor strong,
.preview-body strong{
    color:#1c2a3d;
    font-weight:700;
}

.page-visual-editor a,
.preview-body a{
    color:var(--blue);
    text-decoration:underline;
    text-underline-offset:2px;
}

.page-visual-editor blockquote,
.preview-body blockquote{
    margin:18px 0;
    padding:13px 16px;
    border-left:4px solid var(--blue);
    border-radius:0 8px 8px 0;
    background:#f8fafc;
    color:#4f5d70;
}

.page-visual-editor table,
.preview-body table{
    width:100%;
    margin:18px 0 22px;
    border-collapse:collapse;
}

.page-visual-editor th,
.page-visual-editor td,
.preview-body th,
.preview-body td{
    padding:11px 12px;
    border:1px solid var(--border);
    text-align:left;
    vertical-align:top;
}

.page-visual-editor th,
.preview-body th{
    background:#f8fafc;
    color:var(--navy);
    font-weight:800;
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
}
.main > .content,
.main .content:first-child{
    width:auto!important;
    max-width:none!important;
    margin:0!important;
    padding:16px 18px 20px!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}


/* TRAVSCOPE V24.76 — International Content Management / Website Pages */
.ts-pages-hero{align-items:center!important;padding:17px 18px!important;margin-bottom:16px!important;background:linear-gradient(120deg,#fff,#f7fbff)!important;border:1px solid #dbe7f4!important;border-left:4px solid #14b8a6!important;border-radius:14px!important;box-shadow:0 8px 24px rgba(15,23,42,.045)!important}.ts-pages-title{min-width:270px}.ts-eyebrow,.ts-section-kicker{display:block;margin-bottom:3px;color:#1677ff;font-size:9px;font-weight:900;letter-spacing:.75px;text-transform:uppercase}.ts-pages-hero h1{font-size:25px!important}.ts-pages-hero p{margin-top:3px!important}.ts-pages-metrics{margin-left:auto;display:flex;gap:7px;flex-wrap:wrap;justify-content:flex-end}.ts-page-metric{position:relative;min-width:108px;padding:8px 10px 8px 12px;background:#fff;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden}.ts-page-metric:before{content:"";position:absolute;inset:0 auto 0 0;width:3px;background:#2563eb}.ts-page-metric.green:before{background:#10b981}.ts-page-metric.amber:before{background:#f59e0b}.ts-page-metric span{display:block;color:#64748b;font-size:8px;font-weight:800;text-transform:uppercase;letter-spacing:.4px}.ts-page-metric strong{display:block;margin-top:2px;color:#0f2744;font:800 18px 'Manrope',sans-serif}.ts-pages-hero .heading-actions{display:flex;gap:7px;flex-wrap:wrap}.ts-page-directory .card-head{padding:13px 14px!important}.ts-page-directory .card-head h2{font-size:15px!important}.ts-page-directory .filter-control{min-height:36px!important}.ts-page-directory .filter-button,.ts-page-directory .reset-button{min-height:36px!important}.ts-page-directory th{padding-top:10px!important;padding-bottom:10px!important}.ts-page-directory td{padding-top:10px!important;padding-bottom:10px!important}.ts-page-directory .page-icon{width:34px!important;height:34px!important}.ts-page-directory .action-button{min-height:31px!important}
@media(max-width:1050px){.ts-pages-hero{align-items:flex-start!important;flex-wrap:wrap}.ts-pages-metrics{order:3;width:100%;justify-content:flex-start}}
@media(max-width:760px){.ts-pages-hero{padding:14px!important}.ts-pages-metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));width:100%}.ts-page-metric{min-width:0}.ts-pages-hero .heading-actions{width:100%}.ts-pages-hero .heading-actions a{flex:1}}
</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head>
<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->








<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->



<main class="main">
    <header class="topbar">
        <div class="topbar-left">
            
            <div class="topbar-title">TRAVSCOPE Administration</div>
        </div>

        <div class="top-actions">
            <a href="<?= e(BASE_URL); ?>" target="_blank" class="view-site">
                <i class="fa-solid fa-arrow-up-right-from-square"></i>
                <span>View Website</span>
            </a>

            <div class="admin-profile">
                <div class="admin-avatar"><?= e($adminInitial); ?></div>
                <div class="admin-info">
                    <strong><?= e((string)($admin['name'] ?? 'Administrator')); ?></strong>
                    <span><?= e(ucwords(str_replace('_', ' ', (string)($admin['role'] ?? 'admin')))); ?></span>
                </div>
            </div>
        </div>
    </header>

    <div class="content">

        <div class="page-heading <?= $action === 'list' ? 'ts-pages-hero' : ''; ?>">
            <div class="ts-pages-title">
                <?php if ($action === 'list'): ?><span class="ts-eyebrow">CONTENT / WEBSITE</span><?php endif; ?>
                <h1><?= e($pageHeading); ?></h1>
                <p>
                    <?php if ($action === 'list'): ?>
                        Manage all dynamic website pages from one place.
                    <?php elseif ($action === 'preview'): ?>
                        Preview the saved page content inside the admin panel.
                    <?php else: ?>
                        Update page content, hero text, SEO information and publication status.
                    <?php endif; ?>
                </p>
            </div>

            <?php if ($action === 'list'): ?>
            <div class="ts-pages-metrics" aria-label="Website page summary">
                <div class="ts-page-metric blue"><span>Total Pages</span><strong><?= number_format($totalPages); ?></strong></div>
                <div class="ts-page-metric green"><span>Active</span><strong><?= number_format($activePages); ?></strong></div>
                <div class="ts-page-metric amber"><span>Inactive</span><strong><?= number_format($inactivePages); ?></strong></div>
            </div>
            <?php endif; ?>

            <div class="heading-actions">
                <?php if ($action !== 'list'): ?>
                    <a href="admin-pages.php" class="button secondary">
                        <i class="fa-solid fa-arrow-left"></i>
                        Back to Pages
                    </a>
                <?php endif; ?>

                <?php if ($action === 'preview' && $currentPage): ?>
                    <a href="admin-pages.php?action=edit&id=<?= (int)$currentPage['id']; ?>" class="button primary">
                        <i class="fa-solid fa-pen"></i>
                        Edit Page
                    </a>
                <?php elseif ($action === 'list' && $tableReady): ?>
                    <a href="admin-pages.php?action=add" class="button primary">
                        <i class="fa-solid fa-plus"></i>
                        Add New Page
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($success !== ''): ?>
            <div class="alert success"><i class="fa-solid fa-circle-check"></i> <?= e($success); ?></div>
        <?php endif; ?>

        <?php if ($error !== ''): ?>
            <div class="alert error"><i class="fa-solid fa-triangle-exclamation"></i> <?= e($error); ?></div>
        <?php endif; ?>

        <?php if ($action === 'list'): ?>

            <section class="card ts-page-directory">
                <div class="card-head">
                    <div>
                        <span class="ts-section-kicker">PAGE DIRECTORY</span>
                        <h2>All Website Pages</h2>
                        <p><?= number_format(count($pages)); ?> page(s) in this view · edit, preview and manage published content.</p>
                    </div>

                    <form method="get" class="filter-form">
                        <input type="search" name="q" class="filter-control search-control" value="<?= e($search); ?>" placeholder="Search pages...">

                        <select name="status" class="filter-control">
                            <option value="">All Statuses</option>
                            <option value="active" <?= $statusFilter === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?= $statusFilter === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        </select>

                        <button type="submit" class="filter-button">
                            <i class="fa-solid fa-magnifying-glass"></i> Search
                        </button>

                        <?php if ($search !== '' || $statusFilter !== ''): ?>
                            <a href="admin-pages.php" class="reset-button">Reset</a>
                        <?php endif; ?>
                    </form>
                </div>

                <?php if ($pages): ?>
                    <div class="table-wrap">
                        <table>
                            <thead>
                                <tr>
                                    <th>Page</th>
                                    <th>Content Preview</th>
                                    <th>Status</th>
                                    <th>Last Updated</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>

                            <tbody>
                            <?php foreach ($pages as $page): ?>
                                <?php $pageStatus = strtolower((string)$page['status']) === 'active' ? 'active' : 'inactive'; ?>
                                <tr>
                                    <td>
                                        <div class="page-name">
                                            <div class="page-icon"><i class="fa-regular fa-file-lines"></i></div>
                                            <div>
                                                <strong><?= e((string)$page['page_title']); ?></strong>
                                                <small>Key: <?= e((string)$page['page_key']); ?></small>
                                            </div>
                                        </div>
                                    </td>

                                    <td><?= e(pageManagerExcerpt((string)$page['page_content'])); ?></td>

                                    <td>
                                        <span class="status-badge <?= e($pageStatus); ?>">
                                            <span class="status-dot"></span>
                                            <?= e($pageStatus); ?>
                                        </span>
                                    </td>

                                    <td><?= e(pageManagerDate($page['updated_at'] ?? null)); ?></td>

                                    <td>
                                        <div class="actions">
                                            <a href="admin-pages.php?action=edit&id=<?= (int)$page['id']; ?>" class="action-button edit">
                                                <i class="fa-solid fa-pen"></i> Edit
                                            </a>

                                            <a href="admin-pages.php?action=preview&id=<?= (int)$page['id']; ?>" class="action-button">
                                                <i class="fa-regular fa-eye"></i> View
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="table-note">Showing <?= number_format(count($pages)); ?> page(s).</div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fa-regular fa-folder-open"></i>
                        <h3>No pages found</h3>
                        <p><?= $tableReady ? 'No pages match your current filter.' : 'Run the website_pages SQL, then refresh this page.'; ?></p>
                    </div>
                <?php endif; ?>
            </section>

        <?php elseif (in_array($action, ['add', 'edit'], true)): ?>

            <section class="card">
                <div class="card-head">
                    <div>
                        <h2><?= $action === 'add' ? 'Create Website Page' : 'Update Website Page'; ?></h2>
                        <p>All fields can now be managed directly inside admin-pages.php.</p>
                    </div>
                </div>

                <form method="post" class="form-wrap">
                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                    <input type="hidden" name="id" value="<?= (int)$formPage['id']; ?>">

                    <div class="form-grid">
                        <div class="form-group">
                            <label for="page_title">Page Title *</label>
                            <input type="text" id="page_title" name="page_title" class="form-control" required value="<?= e((string)$formPage['page_title']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="page_key">Page Key *</label>
                            <input type="text" id="page_key" name="page_key" class="form-control" required value="<?= e((string)$formPage['page_key']); ?>" placeholder="about">
                            <span class="form-help">Used in the public URL, for example: pages.php?page=about</span>
                        </div>

                        <div class="form-group">
                            <label for="meta_title">Meta Title</label>
                            <input type="text" id="meta_title" name="meta_title" class="form-control" value="<?= e((string)$formPage['meta_title']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="status">Status *</label>
                            <select id="status" name="status" class="form-control" required>
                                <option value="active" <?= strtolower((string)$formPage['status']) === 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?= strtolower((string)$formPage['status']) === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            </select>
                        </div>

                        <div class="form-group full">
                            <label for="meta_description">Meta Description</label>
                            <textarea id="meta_description" name="meta_description" class="form-control"><?= e((string)$formPage['meta_description']); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label for="hero_title">Hero Title</label>
                            <input type="text" id="hero_title" name="hero_title" class="form-control" value="<?= e((string)$formPage['hero_title']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="hero_subtitle">Hero Subtitle</label>
                            <input type="text" id="hero_subtitle" name="hero_subtitle" class="form-control" value="<?= e((string)$formPage['hero_subtitle']); ?>">
                        </div>

                        <div class="form-group full">
                            <label for="page_content_visual">Page Content *</label>

                            <div class="page-editor-shell">
                                <div class="page-editor-toolbar">
                                    <button type="button" class="editor-tool" data-command="formatBlock" data-value="H2">H2</button>
                                    <button type="button" class="editor-tool" data-command="formatBlock" data-value="H3">H3</button>
                                    <button type="button" class="editor-tool" data-command="formatBlock" data-value="P">P</button>
                                    <span class="editor-separator"></span>
                                    <button type="button" class="editor-tool" data-command="bold"><i class="fa-solid fa-bold"></i></button>
                                    <button type="button" class="editor-tool" data-command="italic"><i class="fa-solid fa-italic"></i></button>
                                    <button type="button" class="editor-tool" data-command="insertUnorderedList"><i class="fa-solid fa-list-ul"></i></button>
                                    <button type="button" class="editor-tool" data-command="insertOrderedList"><i class="fa-solid fa-list-ol"></i></button>
                                    <span class="editor-separator"></span>
                                    <button type="button" class="editor-tool" id="clearFormattingButton"><i class="fa-solid fa-eraser"></i> Clear</button>
                                    <button type="button" class="editor-tool" id="sourceToggleButton"><i class="fa-solid fa-code"></i> HTML</button>
                                    <span class="editor-paste-status" id="editorPasteStatus"><i class="fa-solid fa-circle-check"></i> Content formatted automatically</span>
                                </div>

                                <div id="page_content_visual" class="page-visual-editor" contenteditable="true" role="textbox" aria-multiline="true" spellcheck="true"></div>

                                <textarea id="page_content_source" class="page-source-editor" spellcheck="false"></textarea>

                                <div class="editor-help">
                                    <strong>Automatic formatting:</strong> paste HTML such as
                                    <code>&lt;h2&gt;About Us&lt;/h2&gt; &lt;p&gt;...&lt;/p&gt; &lt;ul&gt;&lt;li&gt;...&lt;/li&gt;&lt;/ul&gt;</code>
                                    and it will automatically show as headings, paragraphs and lists.
                                </div>
                            </div>

                            <textarea id="page_content" name="page_content" required style="position:absolute;left:-9999px;width:1px;height:1px;opacity:0;pointer-events:none;"><?= e((string)$formPage['page_content']); ?></textarea>
                        </div>
                    </div>

                    <div class="form-actions">
                        <a href="admin-pages.php" class="button secondary">Cancel</a>
                        <button type="submit" class="button primary">
                            <i class="fa-solid fa-floppy-disk"></i>
                            <?= $action === 'add' ? 'Create Page' : 'Save Changes'; ?>
                        </button>
                    </div>
                </form>
            </section>

        <?php elseif ($action === 'preview' && $currentPage): ?>

            <section class="card">
                <div class="preview-hero">
                    <h1><?= e((string)($currentPage['hero_title'] ?: $currentPage['page_title'])); ?></h1>

                    <?php if (!empty($currentPage['hero_subtitle'])): ?>
                        <p><?= e((string)$currentPage['hero_subtitle']); ?></p>
                    <?php endif; ?>
                </div>

                <article class="preview-body">
                    <?= (string)$currentPage['page_content']; ?>
                </article>

                <div class="preview-meta">
                    Page key: <?= e((string)$currentPage['page_key']); ?>
                    &nbsp; • &nbsp;
                    Status: <?= e((string)$currentPage['status']); ?>
                    &nbsp; • &nbsp;
                    Updated: <?= e(pageManagerDate($currentPage['updated_at'] ?? null)); ?>
                </div>
            </section>

        <?php endif; ?>

    </div>
</main>

<script>
(function(){
    const form=document.querySelector('form.form-wrap');
    const hidden=document.getElementById('page_content');
    const visual=document.getElementById('page_content_visual');
    const source=document.getElementById('page_content_source');
    const toggle=document.getElementById('sourceToggleButton');
    const clearBtn=document.getElementById('clearFormattingButton');
    const status=document.getElementById('editorPasteStatus');

    if(!hidden||!visual||!source) return;

    const initialHtml = hidden.value || '';
    visual.innerHTML = initialHtml;
    source.value = initialHtml;

    const syncVisual=()=>{
        hidden.value=visual.innerHTML.trim();
        source.value=hidden.value;
    };
    const syncSource=()=>{
        visual.innerHTML=source.value;
        hidden.value=source.value.trim();
    };
    const sourceOpen=()=>source.classList.contains('open');

    const showStatus=()=>{
        if(!status) return;
        status.classList.add('show');
        clearTimeout(showStatus.timer);
        showStatus.timer=setTimeout(()=>status.classList.remove('show'),2200);
    };

    const looksLikeHtml=(v)=>/<(h[1-6]|p|ul|ol|li|strong|b|em|i|a|br|div|section|blockquote|table|thead|tbody|tr|td|th)\b[^>]*>/i.test(v);

    const sanitizePastedHtml=(html)=>{
        const doc=new DOMParser().parseFromString('<div id="tsPasteRoot">'+html+'</div>','text/html');
        const root=doc.getElementById('tsPasteRoot');
        if(!root) return '';

        root.querySelectorAll('script,style,form,input,textarea,select,button,iframe,object,embed').forEach(el=>el.remove());

        root.querySelectorAll('*').forEach(el=>{
            [...el.attributes].forEach(attr=>{
                const n=attr.name.toLowerCase();
                if(
                    n==='style'||n==='class'||n==='id'||n==='align'||n==='width'||n==='height'||
                    n==='color'||n==='face'||n==='bgcolor'||n==='border'||n==='contenteditable'||
                    n==='spellcheck'||n==='role'||n.startsWith('aria-')||n.startsWith('data-')||
                    n.startsWith('on')
                ){
                    el.removeAttribute(attr.name);
                }
            });
        });

        return root.innerHTML;
    };

    const escapeHtml=(v)=>v.replace(/[&<>"']/g,ch=>({
        '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
    }[ch]));

    const smartPlainTextToHtml=(plain)=>{
        const lines=plain.replace(/\r/g,'').split('\n');
        let html='';
        let listType='';
        let paragraph=[];

        const flushParagraph=()=>{
            if(!paragraph.length) return;
            html+='<p>'+paragraph.map(v=>escapeHtml(v.trim())).join(' ')+'</p>';
            paragraph=[];
        };
        const closeList=()=>{
            if(listType){html+='</'+listType+'>';listType='';}
        };
        const openList=(type)=>{
            if(listType===type) return;
            closeList();
            listType=type;
            html+='<'+type+'>';
        };

        lines.forEach(raw=>{
            const line=raw.trim();

            if(!line){
                flushParagraph();
                closeList();
                return;
            }

            let m=line.match(/^(?:[-•*])\s+(.+)$/);
            if(m){
                flushParagraph();
                openList('ul');
                html+='<li>'+escapeHtml(m[1])+'</li>';
                return;
            }

            m=line.match(/^(\d+)[.)]\s+(.+)$/);
            if(m){
                flushParagraph();
                closeList();
                html+='<h2>'+escapeHtml(m[1]+'. '+m[2])+'</h2>';
                return;
            }

            const words=line.split(/\s+/).length;
            const headingLike=words<=10 && line.length<=90 && !/[.!?,;:]$/.test(line);

            if(headingLike){
                flushParagraph();
                closeList();
                html+='<h2>'+escapeHtml(line)+'</h2>';
                return;
            }

            paragraph.push(line);
        });

        flushParagraph();
        closeList();
        return html;
    };

    visual.addEventListener('paste',function(e){
        const cb=e.clipboardData;
        if(!cb) return;

        const html=cb.getData('text/html');
        const plain=cb.getData('text/plain');

        e.preventDefault();

        let clean='';
        if(html && html.trim()!==''){
            clean=sanitizePastedHtml(html);
        }

        if(!clean.trim() || !/<(h[1-6]|p|ul|ol|li)\b/i.test(clean)){
            clean=smartPlainTextToHtml(plain||'');
        }

        document.execCommand('insertHTML',false,clean);
        syncVisual();
        showStatus();
    });

    visual.addEventListener('input',syncVisual);
    source.addEventListener('input',()=>hidden.value=source.value.trim());

    document.querySelectorAll('.editor-tool[data-command]').forEach(btn=>{
        btn.addEventListener('click',function(){
            if(sourceOpen()) return;
            visual.focus();
            const cmd=this.dataset.command;
            const val=this.dataset.value||null;
            if(cmd==='formatBlock' && val){
                document.execCommand(cmd,false,'<'+val.toLowerCase()+'>');
            }else{
                document.execCommand(cmd,false,val);
            }
            syncVisual();
        });
    });

    clearBtn?.addEventListener('click',()=>{
        if(sourceOpen()) return;
        visual.focus();
        document.execCommand('removeFormat',false,null);
        syncVisual();
    });

    toggle?.addEventListener('click',()=>{
        if(sourceOpen()){
            syncSource();
            source.classList.remove('open');
            visual.classList.remove('hidden');
            toggle.classList.remove('active');
        }else{
            syncVisual();
            source.classList.add('open');
            visual.classList.add('hidden');
            toggle.classList.add('active');
        }
    });

    form?.addEventListener('submit',function(e){
        if(sourceOpen()) syncSource(); else syncVisual();
        if(hidden.value.trim()===''){
            e.preventDefault();
            alert('Page Content is required.');
            visual.classList.remove('hidden');
            source.classList.remove('open');
            toggle?.classList.remove('active');
            visual.focus();
        }
    });
})();
</script>

<script>
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebarOverlay');
const mobileMenu = document.getElementById('mobileMenu');

function closeSidebar() {
    sidebar?.classList.remove('open');
    overlay?.classList.remove('show');
}

mobileMenu?.addEventListener('click', () => {
    sidebar?.classList.toggle('open');
    overlay?.classList.toggle('show');
});

overlay?.addEventListener('click', closeSidebar);

window.addEventListener('resize', () => {
    if (window.innerWidth > 900) {
        closeSidebar();
    }
});

</script>







<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
