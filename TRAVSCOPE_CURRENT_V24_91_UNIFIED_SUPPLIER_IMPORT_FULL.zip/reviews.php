<?php
require_once __DIR__ . '/config.php';
requireLogin();

$user = currentUser($pdo);
if (!$user) {
    unset($_SESSION['user_id']);
    session_regenerate_id(true);
    redirect(BASE_URL . 'login.php');
}
if (strtolower((string)($user['status'] ?? '')) !== 'active') {
    unset($_SESSION['user_id']);
    session_regenerate_id(true);
    setFlash('error', 'Your account is currently unavailable.');
    redirect(BASE_URL . 'login.php');
}
if ((int)($user['email_verified'] ?? 0) !== 1) {
    $_SESSION['pending_verify_user_id'] = (int)$user['id'];
    $_SESSION['pending_verify_email'] = (string)$user['email'];
    $_SESSION['pending_verify_name'] = (string)$user['full_name'];
    unset($_SESSION['user_id']);
    redirect(BASE_URL . 'verify-email.php');
}

$userId = (int)$user['id'];
$fullName = trim((string)$user['full_name']);
$firstName = trim(explode(' ', $fullName)[0] ?? $fullName);
if ($firstName === '') $firstName = 'Traveller';
$userInitial = strtoupper(substr($firstName, 0, 1));
$siteName = getSetting($pdo, 'site_name', 'TRAVSCOPE.COM');

/*
|--------------------------------------------------------------------------
| REVIEW SUBMISSION - SAME PAGE
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['reviews_csrf'])) {
    $_SESSION['reviews_csrf'] = bin2hex(random_bytes(32));
}
$reviewCsrf = $_SESSION['reviews_csrf'];

$reviewSuccess = '';
$reviewError = '';

if (!empty($_SESSION['review_flash_success'])) {
    $reviewSuccess = (string)$_SESSION['review_flash_success'];
    unset($_SESSION['review_flash_success']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'submit_review') {

    $token = (string)($_POST['csrf_token'] ?? '');
    $bookingId = (int)($_POST['booking_id'] ?? 0);
    $rating = (int)($_POST['rating'] ?? 0);
    $title = trim((string)($_POST['title'] ?? ''));
    $reviewText = trim((string)($_POST['review_text'] ?? ''));

    if ($token === '' || !hash_equals($_SESSION['reviews_csrf'] ?? '', $token)) {
        $reviewError = 'Security verification failed. Please refresh and try again.';
    } elseif ($bookingId <= 0) {
        $reviewError = 'Invalid booking.';
    } elseif ($rating < 1 || $rating > 5) {
        $reviewError = 'Please select a rating from 1 to 5 stars.';
    } elseif ($reviewText === '') {
        $reviewError = 'Please write your travel experience.';
    } elseif (mb_strlen($title) > 200) {
        $reviewError = 'Review title is too long.';
    } elseif (mb_strlen($reviewText) > 5000) {
        $reviewError = 'Review text is too long.';
    } else {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                SELECT b.id, b.package_id, b.booking_status
                FROM bookings b
                WHERE b.id = ? AND b.user_id = ?
                LIMIT 1
                FOR UPDATE
            ");
            $stmt->execute([$bookingId, $userId]);
            $booking = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$booking) {
                throw new RuntimeException('Booking not found in your account.');
            }

            if (strtolower(trim((string)$booking['booking_status'])) !== 'completed') {
                throw new RuntimeException('You can review this package only after the trip is completed.');
            }

            if (empty($booking['package_id'])) {
                throw new RuntimeException('This booking is not linked to a package.');
            }

            $stmt = $pdo->prepare("
                SELECT id
                FROM reviews
                WHERE booking_id = ? AND user_id = ?
                LIMIT 1
            ");
            $stmt->execute([$bookingId, $userId]);

            if ($stmt->fetchColumn()) {
                throw new RuntimeException('You have already reviewed this completed booking.');
            }

            $stmt = $pdo->prepare("
                INSERT INTO reviews
                    (user_id, package_id, booking_id, rating, title, review_text, status, featured, created_at, updated_at)
                VALUES
                    (?, ?, ?, ?, ?, ?, 'pending', 0, NOW(), NOW())
            ");
            $stmt->execute([
                $userId,
                (int)$booking['package_id'],
                $bookingId,
                $rating,
                $title !== '' ? $title : null,
                $reviewText
            ]);

            $pdo->commit();

            $_SESSION['review_flash_success'] =
                'Thank you. Your review was submitted and is pending admin approval.';

            redirect(BASE_URL . 'reviews.php');

        } catch (RuntimeException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $reviewError = $e->getMessage();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('Same-page review submit error: ' . $e->getMessage());
            $reviewError = 'Unable to submit your review right now.';
        }
    }
}

$stmt = $pdo->prepare("
 SELECT COUNT(*) total_reviews,
 SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) pending_reviews,
 SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) approved_reviews,
 SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) rejected_reviews
 FROM reviews WHERE user_id=?
");
$stmt->execute([$userId]);
$s = $stmt->fetch() ?: [];
$totalReviews=(int)($s['total_reviews']??0);
$pendingReviews=(int)($s['pending_reviews']??0);
$approvedReviews=(int)($s['approved_reviews']??0);
$rejectedReviews=(int)($s['rejected_reviews']??0);

$stmt=$pdo->prepare("
 SELECT r.*,p.title package_title,p.slug package_slug,p.main_image
 FROM reviews r
 INNER JOIN packages p ON p.id=r.package_id
 WHERE r.user_id=?
 ORDER BY r.id DESC
");
$stmt->execute([$userId]);
$reviews=$stmt->fetchAll();

/*
|--------------------------------------------------------------------------
| COMPLETED BOOKINGS READY FOR REVIEW
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        b.id AS booking_id,
        b.booking_number,
        b.travel_date,
        b.booking_status,
        p.id AS package_id,
        p.title,
        p.slug,
        p.main_image
    FROM bookings b
    INNER JOIN packages p
        ON p.id = b.package_id
    WHERE b.user_id = ?
      AND LOWER(TRIM(b.booking_status)) = 'completed'
      AND NOT EXISTS (
          SELECT 1
          FROM reviews r
          WHERE r.user_id = b.user_id
            AND r.booking_id = b.id
      )
    ORDER BY b.id DESC
");

$stmt->execute([$userId]);
$reviewablePackages = $stmt->fetchAll();

function reviewImage(?string $image): string {
    $image=trim((string)$image);
    if ($image==='') return 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=900&q=85';
    if (preg_match('#^https?://#i',$image)) return $image;
    return BASE_URL.ltrim($image,'/');
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#07192d">
<title>My Reviews | <?=e($siteName)?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
:root{--navy:#07192d;--primary:#0b74ff;--cyan:#00b8ff;--bg:#f5f8fc;--text:#172033;--muted:#778294;--border:#e5eaf0;--green:#0aa66a;--orange:#ed8c21;--red:#df4859;--shadow:0 12px 35px rgba(7,25,45,.07)}
*{box-sizing:border-box;margin:0;padding:0}body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh}a{text-decoration:none;color:inherit}
.sidebar{position:fixed;left:0;top:0;bottom:0;width:265px;background:linear-gradient(180deg,#07192d,#061525);color:#fff;overflow-y:auto;z-index:1200;transition:.25s}
.logo{height:80px;padding:0 23px;display:flex;align-items:center;gap:11px;border-bottom:1px solid rgba(255,255,255,.08);font:800 20px 'Manrope'}
.logo-icon{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:linear-gradient(135deg,var(--primary),var(--cyan))}.logo span{color:#63b4ff}
.user{padding:22px 18px 17px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;gap:11px;align-items:center}.avatar{width:43px;height:43px;border-radius:50%;display:grid;place-items:center;background:rgba(99,180,255,.13);color:#78c0ff;font-weight:800}.user strong{font-size:12px}.user small{display:block;color:#7f93a9;font-size:9px;margin-top:3px}
.menu{padding:17px 13px 35px}.mt{padding:15px 13px 8px;color:#627990;font-size:9px;font-weight:800;letter-spacing:1.4px}.ml{min-height:47px;padding:0 14px;margin-bottom:4px;border-radius:10px;display:flex;align-items:center;gap:13px;color:#aebdcc;font-size:12px;font-weight:600}.ml i{width:19px;text-align:center}.ml:hover,.ml.active{color:#fff;background:rgba(11,116,255,.18)}.ml.active i{color:#63b4ff}
.main{margin-left:265px}.topbar{height:80px;padding:0 30px;position:sticky;top:0;z-index:900;background:rgba(255,255,255,.96);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}.topbar strong{display:block;color:var(--navy);font-size:13px}.topbar small{color:var(--muted);font-size:9px}.mobile{display:none;width:42px;height:42px;border:0;border-radius:10px;background:#edf4fb}.top-left{display:flex;align-items:center;gap:13px}.explore{padding:12px 15px;border-radius:10px;background:var(--primary);color:#fff;font-size:11px;font-weight:700}
.content{padding:30px}.hero{padding:30px;margin-bottom:22px;border-radius:20px;background:linear-gradient(120deg,#07192d,#0a3b68);color:#fff;display:flex;justify-content:space-between;align-items:center;box-shadow:0 18px 50px rgba(7,25,45,.12)}.hero h1{font:800 30px 'Manrope'}.hero p{margin-top:7px;color:rgba(255,255,255,.68);font-size:11px}.hero-icon{width:70px;height:70px;border-radius:18px;display:grid;place-items:center;background:rgba(255,255,255,.1);font-size:27px}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:15px;margin-bottom:22px}.stat{padding:18px;background:#fff;border:1px solid var(--border);border-radius:14px;box-shadow:var(--shadow)}.stat span{color:var(--muted);font-size:9px;font-weight:800}.stat strong{display:block;margin-top:8px;font:800 25px 'Manrope';color:var(--navy)}
.section{margin-bottom:22px;background:#fff;border:1px solid var(--border);border-radius:17px;overflow:hidden;box-shadow:var(--shadow)}.head{min-height:68px;padding:0 20px;border-bottom:1px solid var(--border);display:flex;align-items:center}.head h2{font:800 16px 'Manrope';color:var(--navy)}.head p{margin-top:3px;color:var(--muted);font-size:9px}
.eligible{padding:18px;display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.eligible-card{border:1px solid var(--border);border-radius:14px;overflow:hidden}.eligible-card img{width:100%;height:145px;object-fit:cover}.eligible-body{padding:14px}.eligible-body h3{font:700 13px 'Manrope';color:var(--navy)}.btn{margin-top:12px;padding:11px 13px;border-radius:9px;display:inline-flex;gap:7px;align-items:center;background:var(--primary);color:#fff;font-size:9px;font-weight:800}
.list{padding:18px;display:grid;gap:14px}.review{padding:17px;border:1px solid var(--border);border-radius:14px;display:grid;grid-template-columns:110px 1fr;gap:17px}.review img{width:110px;height:100px;border-radius:11px;object-fit:cover}.review-top{display:flex;justify-content:space-between;gap:12px}.title{font:700 14px 'Manrope';color:var(--navy)}.stars{margin-top:6px;color:#f4a825;font-size:12px}.text{margin-top:10px;color:#5f6b7c;font-size:10px;line-height:1.7}.meta{margin-top:10px;color:#919baa;font-size:9px}.status{padding:6px 9px;border-radius:50px;font-size:8px;font-weight:800;text-transform:uppercase;height:max-content}.pending{background:#fff3e5;color:#b96b12}.approved{background:#e9faf2;color:#078652}.rejected{background:#fff0f2;color:#c83347}.empty{padding:45px 20px;text-align:center}.empty i{font-size:30px;color:var(--primary)}.empty h3{margin-top:12px;font:800 17px 'Manrope'}.empty p{margin-top:7px;color:var(--muted);font-size:10px}
.overlay{display:none;position:fixed;inset:0;background:rgba(2,10,18,.55);z-index:1150}
@media(max-width:1000px){.stats{grid-template-columns:repeat(2,1fr)}.eligible{grid-template-columns:repeat(2,1fr)}}
@media(max-width:850px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:none}.overlay.show{display:block}.main{margin-left:0}.mobile{display:grid;place-items:center}.content{padding:20px}}
@media(max-width:650px){.topbar{height:70px;padding:0 14px}.topbar .labels{display:none}.content{padding:15px}.hero{padding:24px}.hero-icon{display:none}.stats{grid-template-columns:1fr 1fr}.eligible{grid-template-columns:1fr}.review{grid-template-columns:1fr}.review img{width:100%;height:180px}}
.review-alert{margin-bottom:16px;padding:13px 15px;border-radius:10px;font-size:10px;font-weight:700}
.review-alert.success{background:#eaf9f3;color:#08734f;border:1px solid #bce7d5}
.review-alert.error{background:#fff0f2;color:#b43748;border:1px solid #f0c5cc}
.inline-review-form{margin-top:13px;padding-top:13px;border-top:1px solid var(--border)}
.inline-review-form label{display:block;margin:9px 0 5px;font-size:9px;font-weight:800;color:var(--navy)}
.inline-review-form input[type=text],.inline-review-form textarea{width:100%;border:1px solid var(--border);border-radius:9px;padding:10px;font:inherit;background:#fff}
.inline-review-form textarea{min-height:110px;resize:vertical}
.star-input{display:flex;flex-direction:row-reverse;justify-content:flex-end;gap:3px}
.star-input input{display:none}.star-input label{margin:0;cursor:pointer;font-size:22px;color:#cfd6df}
.star-input label:hover,.star-input label:hover~label,.star-input input:checked~label{color:#f3a712}
.submit-review{margin-top:11px;border:0;border-radius:9px;padding:10px 14px;background:#0b74ff;color:#fff;font-weight:800;cursor:pointer}
.admin-reply{margin-top:13px;padding:13px 14px;border:1px solid #cfe4ff;border-radius:11px;background:#f3f8ff}
.admin-reply-head{display:flex;align-items:center;gap:7px;color:#0b5fc6;font-size:9px;font-weight:800}
.admin-reply-text{margin-top:7px;color:#46566b;font-size:10px;line-height:1.7;white-space:pre-wrap}
.admin-reply-date{margin-top:7px;color:#8a96a6;font-size:8px}


/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>
<body>
<div class="overlay" id="overlay"></div>
<aside class="sidebar" id="sidebar">
<a href="<?=e(BASE_URL)?>" class="logo"><span class="logo-icon"><i class="fa-solid fa-plane"></i></span>TRAV<span>SCOPE</span></a>
<div class="user"><div class="avatar"><?=e($userInitial)?></div><div><strong><?=e($fullName)?></strong><small>TRAVSCOPE Traveller</small></div></div>
<nav class="menu">
<div class="mt">MY TRAVSCOPE</div>
<a class="ml" href="dashboard.php"><i class="fa-solid fa-house"></i>Dashboard</a>
<a class="ml" href="packages.php"><i class="fa-solid fa-compass"></i>Explore Packages</a>
<a class="ml" href="my-bookings.php"><i class="fa-solid fa-suitcase-rolling"></i>My Bookings</a>
<a class="ml" href="wishlist.php"><i class="fa-regular fa-heart"></i>Wishlist</a>
<div class="mt">TRIP SUPPORT</div>
<a class="ml" href="my-enquiries.php"><i class="fa-regular fa-message"></i>My Enquiries</a>
<a class="ml active" href="reviews.php"><i class="fa-regular fa-star"></i>My Reviews</a>
<div class="mt">ACCOUNT</div>
<a class="ml" href="profile.php"><i class="fa-regular fa-user"></i>My Profile</a>
<a class="ml" href="change-password.php"><i class="fa-solid fa-lock"></i>Security</a>
<a class="ml" href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i>Logout</a>
</nav>
</aside>

<main class="main">
<header class="topbar">
<div class="top-left"><button class="mobile" id="mobile"><i class="fa-solid fa-bars"></i></button><div class="labels"><strong>My Reviews</strong><small>Your TRAVSCOPE travel experiences and feedback.</small></div></div>
<a class="explore" href="packages.php"><i class="fa-solid fa-compass"></i> Explore Trips</a>
</header>
<div class="content">
<?php if($reviewSuccess !== ''): ?><div class="review-alert success"><?=e($reviewSuccess)?></div><?php endif; ?>
<?php if($reviewError !== ''): ?><div class="review-alert error"><?=e($reviewError)?></div><?php endif; ?>
<section class="hero"><div><h1>My Travel Reviews</h1><p>View your submitted reviews, track approval status, and share feedback about completed journeys.</p></div><div class="hero-icon"><i class="fa-solid fa-star"></i></div></section>
<section class="stats">
<div class="stat"><span>TOTAL REVIEWS</span><strong><?=number_format($totalReviews)?></strong></div>
<div class="stat"><span>APPROVED</span><strong><?=number_format($approvedReviews)?></strong></div>
<div class="stat"><span>PENDING</span><strong><?=number_format($pendingReviews)?></strong></div>
<div class="stat"><span>REJECTED</span><strong><?=number_format($rejectedReviews)?></strong></div>
</section>

<?php if($reviewablePackages): ?>
<section class="section"><div class="head"><div><h2>Share Your Experience</h2><p>Completed trips ready for your review.</p></div></div>
<div class="eligible">
<?php foreach($reviewablePackages as $p): ?>
<article class="eligible-card"><img src="<?=e(reviewImage($p['main_image']))?>" alt="<?=e($p['title'])?>"><div class="eligible-body"><h3><?=e($p['title'])?></h3><?php if(!empty($p['booking_number'])): ?><div style="margin-top:5px;color:#778294;font-size:8px;font-weight:700;">Booking #<?=e($p['booking_number'])?></div><?php endif; ?><?php if(!empty($p['travel_date'])): ?><div style="margin-top:3px;color:#919baa;font-size:8px;">Travelled <?=date('d M Y',strtotime((string)$p['travel_date']))?></div><?php endif; ?><form method="post" class="inline-review-form">
<input type="hidden" name="csrf_token" value="<?=e($reviewCsrf)?>">
<input type="hidden" name="action" value="submit_review">
<input type="hidden" name="booking_id" value="<?=(int)$p['booking_id']?>">
<label>Your Rating</label>
<div class="star-input">
<?php for($star=5;$star>=1;$star--): ?>
<input type="radio" id="rating-<?=(int)$p['booking_id']?>-<?=$star?>" name="rating" value="<?=$star?>" required>
<label for="rating-<?=(int)$p['booking_id']?>-<?=$star?>"><i class="fa-solid fa-star"></i></label>
<?php endfor; ?>
</div>
<label>Review Title <span style="font-weight:500;color:#919baa">(optional)</span></label>
<input type="text" name="title" maxlength="200" placeholder="Give your experience a short title">
<label>Your Experience</label>
<textarea name="review_text" maxlength="5000" required placeholder="Tell us about your completed trip..."></textarea>
<button type="submit" class="submit-review"><i class="fa-solid fa-paper-plane"></i> Submit Review</button>
</form></div></article>
<?php endforeach; ?>
</div></section>
<?php endif; ?>

<section class="section"><div class="head"><div><h2>Submitted Reviews</h2><p>All reviews submitted from your account.</p></div></div>
<?php if(!$reviews): ?>
<div class="empty"><i class="fa-regular fa-star"></i><h3>No reviews yet</h3><p>After completing a trip, you can share your experience here.</p></div>
<?php else: ?><div class="list">
<?php foreach($reviews as $r): $status=strtolower((string)$r['status']); ?>
<article class="review">
<a href="package-details.php?slug=<?=urlencode((string)$r['package_slug'])?>"><img src="<?=e(reviewImage($r['main_image']))?>" alt="<?=e($r['package_title'])?>"></a>
<div><div class="review-top"><div><a class="title" href="package-details.php?slug=<?=urlencode((string)$r['package_slug'])?>"><?=e($r['package_title'])?></a><div class="stars">
<?php for($i=1;$i<=5;$i++): ?><i class="<?=$i<=(int)$r['rating']?'fa-solid':'fa-regular'?> fa-star"></i><?php endfor; ?>
</div></div><span class="status <?=in_array($status,['approved','rejected'],true)?e($status):'pending'?>"><?=e(ucfirst($status))?></span></div>
<div class="text"><?=e((string)($r['review_text'] ?: 'No written comment provided.'))?></div>
<div class="meta">Submitted <?=date('d M Y, h:i A',strtotime((string)$r['created_at']))?></div>

<?php if(trim((string)($r['admin_reply'] ?? '')) !== ''): ?>
<div class="admin-reply">
    <div class="admin-reply-head">
        <i class="fa-solid fa-headset"></i>
        TRAVSCOPE Response
    </div>

    <div class="admin-reply-text"><?=e((string)$r['admin_reply'])?></div>

    <?php if(!empty($r['admin_reply_at'])): ?>
    <div class="admin-reply-date">
        Replied <?=date('d M Y, h:i A', strtotime((string)$r['admin_reply_at']))?>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

</div></article>
<?php endforeach; ?></div><?php endif; ?>
</section>
</div>
</main>
<script>
const s=document.getElementById('sidebar'),m=document.getElementById('mobile'),o=document.getElementById('overlay');
function closeMenu(){s?.classList.remove('open');o?.classList.remove('show');document.body.style.overflow=''}
m?.addEventListener('click',()=>{s.classList.toggle('open');o.classList.toggle('show');document.body.style.overflow=s.classList.contains('open')?'hidden':''});
o?.addEventListener('click',closeMenu);window.addEventListener('resize',()=>{if(innerWidth>850)closeMenu()});
</script>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
