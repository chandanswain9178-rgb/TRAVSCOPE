<?php
/* TRAVSCOPE V24.11 - Admin Delete OTP Verification */
declare(strict_types=1);
require_once __DIR__.'/config.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: '.(defined('BASE_URL')?BASE_URL:'').'login.php');
    exit;
}

$token = trim((string)($_GET['token'] ?? $_POST['token'] ?? ''));
$pending = $token !== '' ? ($_SESSION['ts_admin_delete_pending'][$token] ?? null) : null;
$adminId = (int)$_SESSION['admin_id'];

if (!is_array($pending)
    || (int)($pending['admin_id'] ?? 0) !== $adminId
    || (int)($pending['created_at'] ?? 0) < time()-1800
) {
    http_response_code(410);
    exit('This delete verification request has expired. Return to the Admin Panel and click Delete again.');
}

if (empty($_SESSION['ts_admin_delete_otp_csrf'])) {
    $_SESSION['ts_admin_delete_otp_csrf'] = bin2hex(random_bytes(24));
}
$csrf = (string)$_SESSION['ts_admin_delete_otp_csrf'];
$error = '';
$message = (string)($pending['otp_message'] ?? 'A verification code has been sent to your Admin email.');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedCsrf = (string)($_POST['csrf'] ?? '');
    if ($postedCsrf === '' || !hash_equals($csrf, $postedCsrf)) {
        $error = 'Security verification failed. Please refresh and try again.';
    } elseif (isset($_POST['resend_otp'])) {
        $sent = createEmailOtp(
            $pdo,
            (string)$pending['admin_email'],
            (string)$pending['admin_name'],
            'admin_delete'
        );
        $message = (string)($sent['message'] ?? '');
        if (empty($sent['success'])) $error = $message;
        else $_SESSION['ts_admin_delete_pending'][$token]['otp_sent'] = true;
    } elseif (isset($_POST['verify_otp'])) {
        $otp = trim((string)($_POST['otp'] ?? ''));
        $verified = verifyEmailOtp(
            $pdo,
            (string)$pending['admin_email'],
            $otp,
            'admin_delete'
        );

        if (empty($verified['success'])) {
            $error = (string)($verified['message'] ?? 'Incorrect verification code.');
        } else {
            $_SESSION['ts_admin_delete_approved'][$token] = [
                'admin_id' => $adminId,
                'post_hash' => (string)$pending['post_hash'],
                'created_at' => time(),
            ];
            $target = (string)$pending['target_uri'];
            $post = (array)$pending['post'];
            unset($_SESSION['ts_admin_delete_pending'][$token]);

            function tsDeleteOtpHidden(string $name, $value): string {
                if (is_array($value)) {
                    $html='';
                    foreach ($value as $k=>$v) {
                        $html .= tsDeleteOtpHidden($name.'['.$k.']',$v);
                    }
                    return $html;
                }
                return '<input type="hidden" name="'.htmlspecialchars($name,ENT_QUOTES,'UTF-8').'" value="'.htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8').'">';
            }

            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Authorizing Delete | TRAVSCOPE</title></head><body>';
            echo '<form id="verifiedDelete" method="post" action="'.htmlspecialchars($target,ENT_QUOTES,'UTF-8').'">';
            foreach ($post as $k=>$v) echo tsDeleteOtpHidden((string)$k,$v);
            echo '<input type="hidden" name="__ts_delete_otp_token" value="'.htmlspecialchars($token,ENT_QUOTES,'UTF-8').'">';
            echo '</form><script>document.getElementById("verifiedDelete").submit();</script>';
            echo '<noscript><button type="submit" form="verifiedDelete">Continue Delete</button></noscript><script src="site-brand-sync.js?v=20261005-v2473" defer></script></body></html>';
            exit;
        }
    }
}

$masked = (string)$pending['admin_email'];
if (str_contains($masked,'@')) {
    [$left,$right]=explode('@',$masked,2);
    $masked = mb_substr($left,0,2).str_repeat('*',max(2,mb_strlen($left)-2)).'@'.$right;
}
$targetLabel = htmlspecialchars((string)($pending['target_script'] ?? 'Admin Panel'),ENT_QUOTES,'UTF-8');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Verify Delete | TRAVSCOPE Admin</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#18263a;font-family:Arial,Helvetica,sans-serif;min-height:100vh;display:grid;place-items:center;padding:22px}.box{width:min(470px,100%);background:#fff;border:1px solid #dfe7f1;border-radius:18px;padding:28px;box-shadow:0 18px 55px rgba(7,25,45,.1)}.brand{font-weight:900;color:#07192d;font-size:22px}.brand span{color:#0b74ff}.danger{margin:18px 0 8px;background:#fff2f2;border:1px solid #ffd2d2;color:#a82525;padding:13px;border-radius:12px;font-size:12px;font-weight:800}.muted{color:#6d7d91;font-size:12px;line-height:1.6}.msg{padding:10px 12px;border-radius:9px;margin:12px 0;font-size:12px}.ok{background:#eefbf5;color:#087952}.err{background:#fff0f0;color:#a23030}.otp{width:100%;height:54px;border:1px solid #cfd9e5;border-radius:10px;text-align:center;font-size:24px;font-weight:900;letter-spacing:8px;margin:12px 0}.btn{width:100%;border:0;border-radius:10px;min-height:44px;font-weight:850;cursor:pointer}.verify{background:#c62828;color:#fff}.resend{margin-top:9px;background:#eef4fb;color:#24557f}.cancel{display:block;text-align:center;margin-top:14px;color:#53697f;text-decoration:none;font-size:12px;font-weight:700}
</style>
</head>
<body>
<div class="box">
<div class="brand">TRAV<span>SCOPE</span></div>
<div class="danger">DELETE VERIFICATION REQUIRED</div>
<p class="muted">For security, this delete action will run only after the logged-in Admin verifies the OTP sent to <strong><?=htmlspecialchars($masked,ENT_QUOTES,'UTF-8')?></strong>.</p>
<p class="muted">Requested from: <strong><?=$targetLabel?></strong></p>
<?php if($message!==''):?><div class="msg ok"><?=htmlspecialchars($message,ENT_QUOTES,'UTF-8')?></div><?php endif;?>
<?php if($error!==''):?><div class="msg err"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></div><?php endif;?>
<form method="post">
<input type="hidden" name="token" value="<?=htmlspecialchars($token,ENT_QUOTES,'UTF-8')?>">
<input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf,ENT_QUOTES,'UTF-8')?>">
<input class="otp" name="otp" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" placeholder="000000" required autofocus>
<button class="btn verify" type="submit" name="verify_otp" value="1">Verify OTP & Delete</button>
</form>
<form method="post">
<input type="hidden" name="token" value="<?=htmlspecialchars($token,ENT_QUOTES,'UTF-8')?>">
<input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf,ENT_QUOTES,'UTF-8')?>">
<button class="btn resend" type="submit" name="resend_otp" value="1">Resend OTP</button>
</form>
<a class="cancel" href="<?=htmlspecialchars((string)$pending['target_uri'],ENT_QUOTES,'UTF-8')?>">Cancel and return</a>
</div>
<script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
