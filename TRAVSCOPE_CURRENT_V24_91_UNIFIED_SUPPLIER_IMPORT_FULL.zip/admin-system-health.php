<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/health-functions.php';

$aclFile =
    __DIR__
    . '/access-control-functions.php';

if (
    is_file($aclFile)
    && !function_exists('tsAclProfile')
) {
    require_once $aclFile;
}

requireAdmin();

$admin =
    currentAdmin($pdo);

if (
    !$admin
    || strtolower(
        (string)(
            $admin['status']
            ?? ''
        )
    ) !== 'active'
) {
    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_role']
    );

    redirect(
        BASE_URL
        . 'admin-login.php'
    );
}

$adminId =
    (int)$admin['id'];

$profile =
    function_exists('tsAclProfile')
        ? tsAclProfile(
            $pdo,
            $adminId,
            (string)(
                $admin['role']
                ?? 'admin'
            )
        )
        : (
            strtolower(
                (string)(
                    $admin['role']
                    ?? 'admin'
                )
            ) === 'super_admin'
                ? 'super_admin'
                : 'admin'
        );

if (
    !in_array(
        $profile,
        ['admin','super_admin'],
        true
    )
) {
    http_response_code(403);
    exit(
        'System Health Center is restricted to Admin / Super Admin.'
    );
}

$scan =
    tsHealthScan(
        $pdo
    );

if (
    isset($_GET['format'])
    && $_GET['format'] === 'json'
) {
    header(
        'Content-Type: application/json; charset=utf-8'
    );

    echo json_encode(
        $scan,
        JSON_PRETTY_PRINT
        | JSON_UNESCAPED_UNICODE
        | JSON_UNESCAPED_SLASHES
    );

    exit;
}

$categoryFilter =
    trim(
        (string)(
            $_GET['category']
            ?? ''
        )
    );

$statusFilter =
    trim(
        (string)(
            $_GET['status']
            ?? ''
        )
    );

if (
    !in_array(
        $statusFilter,
        [
            '',
            'pass',
            'info',
            'warning',
            'fail',
        ],
        true
    )
) {
    $statusFilter = '';
}

$checks =
    array_values(
        array_filter(
            (array)$scan['checks'],
            static function (
                array $check
            ) use (
                $categoryFilter,
                $statusFilter
            ): bool {
                if (
                    $categoryFilter !== ''
                    && (string)$check['category']
                        !== $categoryFilter
                ) {
                    return false;
                }

                if (
                    $statusFilter !== ''
                    && (string)$check['status']
                        !== $statusFilter
                ) {
                    return false;
                }

                return true;
            }
        )
    );

$categories =
    array_values(
        array_unique(
            array_map(
                static fn($check) =>
                    (string)$check['category'],
                (array)$scan['checks']
            )
        )
    );

sort($categories);

function shE(?string $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function shStatusLabel(string $status): string
{
    return
        match ($status) {
            'pass' => 'PASS',
            'warning' => 'WARNING',
            'fail' => 'FAIL',
            default => 'INFO',
        };
}

function shStatusIcon(string $status): string
{
    return
        match ($status) {
            'pass' => 'fa-circle-check',
            'warning' => 'fa-triangle-exclamation',
            'fail' => 'fa-circle-xmark',
            default => 'fa-circle-info',
        };
}

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Data Quality & System Health | TRAVSCOPE Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:68px;padding:10px 4%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;border-bottom:1px solid #dfe7f0;position:sticky;top:0;z-index:20}.brand{font-weight:900;color:#0f172a}.brand span{color:#2563eb}.top-actions{display:flex;gap:7px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;gap:6px;border:1px solid #cbd5e1;border-radius:9px;padding:8px 10px;background:#fff;color:#334155;text-decoration:none;font-size:9px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.wrap{max-width:1380px;margin:20px auto;padding:0 13px}.hero{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;padding:17px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:20px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px;line-height:1.5}.score{min-width:120px;padding:11px;border:1px solid #bfdbfe;border-radius:12px;background:#eff6ff;text-align:center}.score span{display:block;color:#64748b;font-size:8px;font-weight:900;text-transform:uppercase}.score strong{display:block;margin-top:4px;font-size:23px;color:#1d4ed8}.stats{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin-top:11px}.stat{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.stat span{display:block;color:#64748b;font-size:7.5px;font-weight:900;text-transform:uppercase}.stat strong{display:block;margin-top:4px;font-size:13px}.stat.fail{background:#fef2f2;border-color:#fecaca}.stat.fail strong{color:#b91c1c}.stat.warning{background:#fff7ed;border-color:#fed7aa}.stat.warning strong{color:#c2410c}.stat.pass{background:#ecfdf5;border-color:#a7f3d0}.stat.pass strong{color:#047857}.filters{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-top:11px;padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.filters select{min-height:32px;padding:6px 8px;border:1px solid #cbd5e1;border-radius:8px;font-size:8.5px}.list{margin-top:11px}.check{margin-bottom:8px;border:1px solid #dfe7f0;border-left-width:5px;border-radius:12px;background:#fff;overflow:hidden}.check.pass{border-left-color:#059669}.check.info{border-left-color:#2563eb}.check.warning{border-left-color:#d97706}.check.fail{border-left-color:#dc2626}.check-head{display:flex;justify-content:space-between;gap:10px;padding:11px}.check h3{margin:0;font-size:11px}.check p{margin:5px 0 0;color:#64748b;font-size:9px;line-height:1.5}.meta{display:flex;gap:5px;flex-wrap:wrap;margin-top:7px}.pill{display:inline-flex;align-items:center;gap:4px;padding:4px 7px;border-radius:999px;background:#f1f5f9;color:#64748b;font-size:7.5px;font-weight:900}.pill.pass{background:#dcfce7;color:#166534}.pill.warning{background:#fef3c7;color:#92400e}.pill.fail{background:#fee2e2;color:#b91c1c}.pill.info{background:#dbeafe;color:#1d4ed8}.recommend{padding:8px 11px;border-top:1px solid #eef2f7;background:#fbfdff;color:#475569;font-size:8.5px;line-height:1.5}.details{overflow:auto;border-top:1px solid #eef2f7}.details table{width:100%;border-collapse:collapse}.details th,.details td{padding:7px 8px;border-bottom:1px solid #eef2f7;text-align:left;font-size:8px;white-space:nowrap}.details th{background:#f8fafc;color:#64748b;font-size:7px;text-transform:uppercase}.empty{padding:25px;text-align:center;color:#94a3b8;border:1px dashed #cbd5e1;border-radius:12px;background:#fff;font-size:10px}.footer-note{margin:12px 0;padding:10px;border:1px solid #dbeafe;border-radius:10px;background:#eff6ff;color:#1e40af;font-size:9px;line-height:1.5}
@media(max-width:850px){.stats{grid-template-columns:repeat(2,1fr)}.top,.hero{flex-direction:column;align-items:flex-start}}
@media(max-width:520px){.stats{grid-template-columns:1fr}.check-head{display:block}.check-head>.pill{margin-top:7px}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head>
<body>

<header class="top">
    <div class="brand">
        TRAV<span>SCOPE</span> · SYSTEM HEALTH
    </div>

    <div class="top-actions">
        <a
            class="btn"
            href="<?= shE(BASE_URL . 'admin-dashboard.php'); ?>"
        >
            <i class="fa-solid fa-gauge-high"></i>
            Dashboard
        </a>

        <a
            class="btn"
            href="<?= shE(BASE_URL . 'admin-notifications.php'); ?>"
        >
            <i class="fa-regular fa-bell"></i>
            Notifications
        </a>

        <a
            class="btn"
            href="<?= shE(BASE_URL . 'admin-system-health.php?format=json'); ?>"
            target="_blank"
        >
            <i class="fa-solid fa-code"></i>
            JSON
        </a>

        <a
            class="btn primary"
            href="<?= shE(
                BASE_URL
                . 'admin-system-health.php?'
                . http_build_query([
                    'category' =>
                        $categoryFilter,
                    'status' =>
                        $statusFilter,
                    't' =>
                        time(),
                ])
            ); ?>"
        >
            <i class="fa-solid fa-rotate"></i>
            Rescan
        </a>
    </div>
</header>

<main class="wrap">

<section class="hero">
    <div>
        <h1>Data Quality & System Health Center</h1>
        <p>
            Read-only diagnostics for PHP/runtime readiness, module tables, database indexes,
            Trip/Booking bridges, quotation/service snapshots, supplier references, customer
            payment reconciliation, document files, communication failures and system alerts.
            No business record is automatically changed from this page.
        </p>
    </div>

    <div class="score">
        <span>Health Score</span>
        <strong><?= (int)$scan['summary']['health_score']; ?>%</strong>
    </div>
</section>

<div class="stats">
    <div class="stat pass">
        <span>Pass</span>
        <strong><?= (int)$scan['summary']['pass']; ?></strong>
    </div>

    <div class="stat">
        <span>Info</span>
        <strong><?= (int)$scan['summary']['info']; ?></strong>
    </div>

    <div class="stat warning">
        <span>Warning</span>
        <strong><?= (int)$scan['summary']['warning']; ?></strong>
    </div>

    <div class="stat fail">
        <span>Fail</span>
        <strong><?= (int)$scan['summary']['fail']; ?></strong>
    </div>

    <div class="stat">
        <span>Scan Time</span>
        <strong><?= (int)$scan['summary']['duration_ms']; ?> ms</strong>
    </div>
</div>

<div class="filters">
    <form
        method="get"
        style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;"
    >
        <select name="category">
            <option value="">All Categories</option>

            <?php foreach ($categories as $category): ?>
                <option
                    value="<?= shE($category); ?>"
                    <?= $categoryFilter === $category ? 'selected' : ''; ?>
                >
                    <?= shE($category); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <select name="status">
            <option value="">All Status</option>
            <option value="fail" <?= $statusFilter === 'fail' ? 'selected' : ''; ?>>Fail</option>
            <option value="warning" <?= $statusFilter === 'warning' ? 'selected' : ''; ?>>Warning</option>
            <option value="info" <?= $statusFilter === 'info' ? 'selected' : ''; ?>>Info</option>
            <option value="pass" <?= $statusFilter === 'pass' ? 'selected' : ''; ?>>Pass</option>
        </select>

        <button class="btn" type="submit">
            Filter
        </button>

        <a
            class="btn"
            href="<?= shE(BASE_URL . 'admin-system-health.php'); ?>"
        >
            Clear
        </a>
    </form>

    <span class="pill info">
        Generated <?= shE((string)$scan['generated_at']); ?>
    </span>
</div>

<div class="list">

<?php if (!$checks): ?>
    <div class="empty">
        No System Health checks match this filter.
    </div>
<?php endif; ?>

<?php foreach ($checks as $check): ?>
    <section class="check <?= shE((string)$check['status']); ?>">
        <div class="check-head">
            <div>
                <h3><?= shE((string)$check['title']); ?></h3>
                <p><?= shE((string)$check['message']); ?></p>

                <div class="meta">
                    <span class="pill">
                        <?= shE((string)$check['category']); ?>
                    </span>

                    <?php if ((int)$check['count'] > 0): ?>
                        <span class="pill">
                            <?= (int)$check['count']; ?> ISSUE<?= (int)$check['count'] === 1 ? '' : 'S'; ?>
                        </span>
                    <?php endif; ?>

                    <?php if (!empty($check['link'])): ?>
                        <a
                            class="pill info"
                            style="text-decoration:none;"
                            href="<?= shE(
                                str_starts_with(
                                    (string)$check['link'],
                                    'http'
                                )
                                    ? (string)$check['link']
                                    : BASE_URL
                                        . ltrim(
                                            (string)$check['link'],
                                            '/'
                                        )
                            ); ?>"
                        >
                            Open Related Page
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <span class="pill <?= shE((string)$check['status']); ?>">
                <i class="fa-solid <?= shE(shStatusIcon((string)$check['status'])); ?>"></i>
                <?= shE(shStatusLabel((string)$check['status'])); ?>
            </span>
        </div>

        <?php if (!empty($check['recommendation'])): ?>
            <div class="recommend">
                <strong>Safe recommendation:</strong>
                <?= shE((string)$check['recommendation']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($check['details'])): ?>
            <?php
            $detailRows =
                (array)$check['details'];

            $columns = [];

            foreach ($detailRows as $row) {
                if (is_array($row)) {
                    foreach (array_keys($row) as $column) {
                        if (!in_array($column, $columns, true)) {
                            $columns[] = $column;
                        }
                    }
                }
            }
            ?>

            <?php if ($columns): ?>
                <div class="details">
                    <table>
                        <thead>
                            <tr>
                                <?php foreach ($columns as $column): ?>
                                    <th><?= shE(str_replace('_', ' ', $column)); ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>

                        <tbody>
                            <?php foreach ($detailRows as $row): ?>
                                <tr>
                                    <?php foreach ($columns as $column): ?>
                                        <td>
                                            <?= shE(
                                                is_scalar(
                                                    $row[$column]
                                                    ?? null
                                                )
                                                    ? (string)($row[$column] ?? '')
                                                    : json_encode(
                                                        $row[$column] ?? null,
                                                        JSON_UNESCAPED_UNICODE
                                                        | JSON_UNESCAPED_SLASHES
                                                    )
                                            ); ?>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </section>
<?php endforeach; ?>

</div>

<div class="footer-note">
    <strong>Read-only by design.</strong>
    Financial totals, accepted quotation snapshots, supplier procurement history,
    document files and profitability closures are not automatically repaired.
    A FAIL identifies an inconsistency that should be reviewed against the exact
    Booking/Trip/payment/document history before any database change.
</div>

</main>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
