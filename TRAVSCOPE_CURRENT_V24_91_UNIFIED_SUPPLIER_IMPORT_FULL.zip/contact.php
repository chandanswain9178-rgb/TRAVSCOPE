<?php

require_once __DIR__ . '/config.php';

/*
|--------------------------------------------------------------------------
| PAGE
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
| PUBLIC WEBSITE SETTINGS
|--------------------------------------------------------------------------
| These values use the same settings table and keys managed by
| admin-settings.php. Changes made by the administrator are reflected here.
|--------------------------------------------------------------------------
*/

$siteName = trim((string)getSetting($pdo, 'site_name', 'TRAVSCOPE.COM'));
$siteTagline = trim((string)getSetting($pdo, 'site_tagline', 'Explore More. Travel Better.'));
$supportEmail = trim((string)getSetting($pdo, 'support_email', ''));
$supportMobile = trim((string)getSetting($pdo, 'support_mobile', ''));
$whatsappNumber = trim((string)getSetting($pdo, 'whatsapp_number', ''));
$officeAddress = trim((string)getSetting($pdo, 'office_address', ''));
$businessHours = trim((string)getSetting($pdo, 'business_hours', ''));

$whatsappUrl = trim((string)getSetting($pdo, 'whatsapp_url', ''));
$facebookUrl = trim((string)getSetting($pdo, 'facebook_url', ''));
$instagramUrl = trim((string)getSetting($pdo, 'instagram_url', ''));
$youtubeUrl = trim((string)getSetting($pdo, 'youtube_url', ''));
$xUrl = trim((string)getSetting($pdo, 'x_url', ''));

if ($whatsappUrl === '' && $whatsappNumber !== '') {
    $cleanWhatsappNumber = preg_replace('/\D+/', '', $whatsappNumber);
    if ($cleanWhatsappNumber !== '') {
        $whatsappUrl = 'https://wa.me/' . $cleanWhatsappNumber;
    }
}

$socialLinks = array_values(array_filter([
    [
        'name' => 'WhatsApp',
        'url' => $whatsappUrl,
        'icon' => 'fa-brands fa-whatsapp',
        'class' => 'whatsapp'
    ],
    [
        'name' => 'Facebook',
        'url' => $facebookUrl,
        'icon' => 'fa-brands fa-facebook-f',
        'class' => 'facebook'
    ],
    [
        'name' => 'Instagram',
        'url' => $instagramUrl,
        'icon' => 'fa-brands fa-instagram',
        'class' => 'instagram'
    ],
    [
        'name' => 'YouTube',
        'url' => $youtubeUrl,
        'icon' => 'fa-brands fa-youtube',
        'class' => 'youtube'
    ],
    [
        'name' => 'X / Twitter',
        'url' => $xUrl,
        'icon' => 'fa-brands fa-x-twitter',
        'class' => 'twitter'
    ],
], static fn(array $item): bool => $item['url'] !== ''));

$pageTitle = 'Contact & Travel Enquiry | ' . ($siteName !== '' ? $siteName : 'TRAVSCOPE.COM');



/*
|--------------------------------------------------------------------------
| CURRENT USER - OPTIONAL LOGIN
|--------------------------------------------------------------------------
|
| Contact page remains available to guests.
| Logged-in users get name/email/mobile automatically filled.
|
*/

$userId = !empty($_SESSION['user_id'])
    ? (int)$_SESSION['user_id']
    : 0;

$currentUser = null;

if ($userId > 0) {

    try {

        $stmt = $pdo->prepare("
            SELECT
                id,
                full_name,
                email,
                mobile,
                status
            FROM users
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([$userId]);

        $currentUser =
            $stmt->fetch(PDO::FETCH_ASSOC);

        if (
            !$currentUser ||
            ($currentUser['status'] ?? '') !== 'active'
        ) {

            $currentUser = null;
        }

    } catch (Throwable $e) {

        error_log(
            'Contact user fetch error: '
            . $e->getMessage()
        );

        $currentUser = null;
    }
}


/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['contact_csrf'])) {

    $_SESSION['contact_csrf'] =
        bin2hex(
            random_bytes(32)
        );
}

$csrfToken =
    $_SESSION['contact_csrf'];


/*
|--------------------------------------------------------------------------
| PACKAGE
|--------------------------------------------------------------------------
|
| Supports:
|
| contact.php?package=5
|
*/

$packageId =
    (int)(
        $_GET['package']
        ??
        $_POST['package_id']
        ??
        0
    );

$selectedPackage = null;

if ($packageId > 0) {

    try {

        $stmt = $pdo->prepare("
            SELECT
                p.id,
                p.title,
                p.slug,
                p.main_image,
                p.duration_days,
                p.duration_nights,
                p.sale_price,
                p.currency,
                p.status,

                d.name AS destination_name,
                d.country AS destination_country

            FROM packages p

            LEFT JOIN destinations d
                ON d.id = p.destination_id

            WHERE
                p.id = ?
                AND p.status = 'active'

            LIMIT 1
        ");

        $stmt->execute([
            $packageId
        ]);

        $selectedPackage =
            $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$selectedPackage) {
            $packageId = 0;
        }

    } catch (Throwable $e) {

        error_log(
            'Contact package fetch error: '
            . $e->getMessage()
        );

        $selectedPackage = null;
        $packageId = 0;
    }
}


/*
|--------------------------------------------------------------------------
| ACTIVE DESTINATIONS
|--------------------------------------------------------------------------
*/

$destinations = [];

try {

    $stmt = $pdo->query("
        SELECT DISTINCT
            d.id,
            d.name,
            d.country
        FROM destinations d
        WHERE d.status = 'active'
        ORDER BY
            d.sort_order ASC,
            d.name ASC
    ");

    $destinations =
        $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {

    error_log(
        'Contact destinations error: '
        . $e->getMessage()
    );

    $destinations = [];
}


/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function contactImage($image): string
{
    $image =
        trim(
            (string)$image
        );

    if ($image === '') {
        return '';
    }

    if (
        preg_match(
            '#^https?://#i',
            $image
        )
    ) {
        return $image;
    }

    return BASE_URL
        . ltrim(
            $image,
            '/'
        );
}


function contactMoney($amount): string
{
    if (
        $amount === null ||
        $amount === ''
    ) {
        return '';
    }

    return number_format(
        (float)$amount,
        0
    );
}


/*
|--------------------------------------------------------------------------
| DEFAULT FORM VALUES
|--------------------------------------------------------------------------
*/

$name =
    trim(
        (string)(
            $currentUser['full_name']
            ?? ''
        )
    );

$email =
    trim(
        (string)(
            $currentUser['email']
            ?? ''
        )
    );

$mobile =
    trim(
        (string)(
            $currentUser['mobile']
            ?? ''
        )
    );

$destination = '';

if ($selectedPackage) {

    $destination =
        trim(
            (string)(
                $selectedPackage['destination_name']
                ?? ''
            )
        );

    if (
        !empty(
            $selectedPackage[
                'destination_country'
            ]
        )
    ) {

        $destination .=
            (
                $destination !== ''
                    ? ', '
                    : ''
            )
            .
            $selectedPackage[
                'destination_country'
            ];
    }
}

$travelDate = '';
$adults = 1;
$children = 0;
$budget = '';
$message = '';

$enquiryCategory = '';
$departureCity = '';
$returnDate = '';
$tripType = '';
$nationality = '';
$passportStatus = '';
$visaRequirement = '';
$visaNotes = '';
$hotelCategory = '';
$rooms = 1;
$mealPlan = '';
$flightPreference = '';
$transportPreference = '';
$servicesRequired = [];

$error = '';
$success = '';


/*
|--------------------------------------------------------------------------
| CLEAR OLD ENQUIRY OTP STATE ON A FRESH CONTACT VISIT
|--------------------------------------------------------------------------
|
| A normal GET request to contact.php starts a NEW enquiry.
| Do not restore an OTP panel left in the session from an older visit.
|
| Exceptions:
| - ?submitted=1 keeps the success flash after a completed enquiry.
| - ?continue_otp=1 can be used internally if a future flow intentionally
|   needs to reopen the current pending OTP session.
|
*/

$isContactPost =
    ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';

$isSubmittedReturn =
    isset($_GET['submitted'])
    && (string)$_GET['submitted'] === '1';

$isOtpContinuation =
    isset($_GET['continue_otp'])
    && (string)$_GET['continue_otp'] === '1';

if (
    !$isContactPost
    &&
    !$isSubmittedReturn
    &&
    !$isOtpContinuation
) {

    unset(
        $_SESSION['contact_enquiry_pending']
    );
}


/*
|--------------------------------------------------------------------------
| FLASH SUCCESS
|--------------------------------------------------------------------------
*/

if (
    !empty(
        $_SESSION[
            'contact_success'
        ]
    )
) {

    $success =
        (string)
        $_SESSION[
            'contact_success'
        ];

    unset(
        $_SESSION[
            'contact_success'
        ]
    );
}


/*
|--------------------------------------------------------------------------
| ENQUIRY EMAIL OTP STATE
|--------------------------------------------------------------------------
*/

$enquiryOtpPending =
    !empty($_SESSION['contact_enquiry_pending'])
    && is_array($_SESSION['contact_enquiry_pending']);

/*
| Never keep an enquiry OTP session indefinitely.
| Use the configured OTP expiry when available, otherwise 10 minutes.
*/
if ($enquiryOtpPending) {

    $pendingCreatedAt =
        (int)(
            $_SESSION['contact_enquiry_pending']['created_at']
            ?? 0
        );

    $pendingMaxAge =
        defined('OTP_EXPIRY_MINUTES')
            ? max(1, (int)OTP_EXPIRY_MINUTES) * 60
            : 600;

    if (
        $pendingCreatedAt <= 0
        ||
        (time() - $pendingCreatedAt) > $pendingMaxAge
    ) {

        unset(
            $_SESSION['contact_enquiry_pending']
        );

        $enquiryOtpPending = false;
    }
}

if (
    $enquiryOtpPending
    &&
    ($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST'
) {
    $pending = $_SESSION['contact_enquiry_pending'];

    $name = (string)($pending['name'] ?? $name);
    $email = (string)($pending['email'] ?? $email);
    $mobile = (string)($pending['mobile'] ?? $mobile);
    $destination = (string)($pending['destination'] ?? $destination);
    $travelDate = (string)($pending['travel_date'] ?? $travelDate);
    $adults = (int)($pending['adults'] ?? $adults);
    $children = (int)($pending['children'] ?? $children);
    $budget = (string)($pending['budget_raw'] ?? $budget);
    $message = (string)($pending['customer_message'] ?? $pending['message'] ?? $message);
    $enquiryCategory = (string)($pending['enquiry_category'] ?? $enquiryCategory);
    $departureCity = (string)($pending['departure_city'] ?? $departureCity);
    $returnDate = (string)($pending['return_date'] ?? $returnDate);
    $tripType = (string)($pending['trip_type'] ?? $tripType);
    $nationality = (string)($pending['nationality'] ?? $nationality);
    $passportStatus = (string)($pending['passport_status'] ?? $passportStatus);
    $visaRequirement = (string)($pending['visa_requirement'] ?? $visaRequirement);
    $visaNotes = (string)($pending['visa_notes'] ?? $visaNotes);
    $hotelCategory = (string)($pending['hotel_category'] ?? $hotelCategory);
    $rooms = (int)($pending['rooms'] ?? $rooms);
    $mealPlan = (string)($pending['meal_plan'] ?? $mealPlan);
    $flightPreference = (string)($pending['flight_preference'] ?? $flightPreference);
    $transportPreference = (string)($pending['transport_preference'] ?? $transportPreference);
    $servicesRequired = is_array($pending['services_required'] ?? null)
        ? $pending['services_required'] : $servicesRequired;
}


/*
|--------------------------------------------------------------------------
| FORM SUBMISSION + EMAIL OTP
|--------------------------------------------------------------------------
*/

if (
    ($_SERVER['REQUEST_METHOD'] ?? 'GET')
    === 'POST'
) {

    $contactAction =
        trim(
            (string)(
                $_POST['contact_action']
                ?? 'send_otp'
            )
        );

    /*
     * OTP verification must never fall back to send_otp because of
     * button/JavaScript/browser submit behaviour. If an OTP is posted while
     * an enquiry verification session exists, treat it as verify_otp.
     */
    $postedOtp =
        trim(
            (string)(
                $_POST['email_otp']
                ?? ''
            )
        );

    if (
        (string)($_POST['otp_resend'] ?? '') === '1'
        &&
        !empty($_SESSION['contact_enquiry_pending'])
    ) {
        $contactAction = 'resend_otp';
    }

    if (
        $postedOtp !== ''
        &&
        !empty($_SESSION['contact_enquiry_pending'])
        &&
        is_array($_SESSION['contact_enquiry_pending'])
        &&
        $contactAction !== 'resend_otp'
    ) {
        $contactAction = 'verify_otp';
    }

    $postedToken =
        (string)(
            $_POST['csrf_token']
            ?? ''
        );

    if (
        $postedToken === ''
        ||
        !hash_equals(
            $_SESSION['contact_csrf']
            ?? '',
            $postedToken
        )
    ) {
        $error =
            'Security verification failed. Please refresh the page and try again.';
    }

    /*
    |--------------------------------------------------------------------------
    | VERIFY OTP
    |--------------------------------------------------------------------------
    */

    elseif ($contactAction === 'verify_otp') {

        $pending =
            $_SESSION['contact_enquiry_pending']
            ?? null;

        if (
            !$pending
            ||
            !is_array($pending)
        ) {
            $error =
                'Your enquiry verification session has expired. Please complete the form again.';
        } else {

            $otp = $postedOtp;

            if (
                $otp === ''
                ||
                !preg_match(
                    '/^[0-9]{' . (int)OTP_LENGTH . '}$/',
                    $otp
                )
            ) {
                $error =
                    'Please enter the complete '
                    . (int)OTP_LENGTH
                    . '-digit verification code.';
                $enquiryOtpPending = true;
            }

            if ($error === '') {

            $verify =
                verifyEmailOtp(
                    $pdo,
                    (string)$pending['email'],
                    $otp,
                    'enquiry'
                );

            if (empty($verify['success'])) {

                $error =
                    (string)(
                        $verify['message']
                        ?? 'Email verification failed.'
                    );

                $enquiryOtpPending = true;

            } else {

                try {

                    /*
                    |--------------------------------------------------------------------------
                    | DUPLICATE PROTECTION
                    |--------------------------------------------------------------------------
                    */

                    $stmt = $pdo->prepare("
                        SELECT id
                        FROM enquiries
                        WHERE
                            email = ?
                            AND mobile = ?
                            AND (package_id <=> ?)
                            AND created_at >=
                                DATE_SUB(
                                    NOW(),
                                    INTERVAL 60 SECOND
                                )
                        ORDER BY id DESC
                        LIMIT 1
                    ");

                    $stmt->execute([
                        (string)$pending['email'],
                        (string)$pending['mobile'],
                        !empty($pending['package_id'])
                            ? (int)$pending['package_id']
                            : null
                    ]);

                    $duplicateId =
                        $stmt->fetchColumn();

                    if ($duplicateId) {

                        $enquiryId =
                            (int)$duplicateId;

                    } else {

                        $stmt = $pdo->prepare("
                            INSERT INTO enquiries
                            (
                                package_id,
                                name,
                                email,
                                mobile,
                                destination,
                                travel_date,
                                adults,
                                children,
                                budget,
                                message,
                                status
                            )
                            VALUES
                            (
                                ?,
                                ?,
                                ?,
                                ?,
                                ?,
                                ?,
                                ?,
                                ?,
                                ?,
                                ?,
                                'new'
                            )
                        ");

                        $stmt->execute([
                            !empty($pending['package_id'])
                                ? (int)$pending['package_id']
                                : null,
                            (string)$pending['name'],
                            (string)$pending['email'],
                            (string)$pending['mobile'],
                            ($pending['destination'] ?? '') !== ''
                                ? (string)$pending['destination']
                                : null,
                            ($pending['travel_date'] ?? '') !== ''
                                ? (string)$pending['travel_date']
                                : null,
                            (int)$pending['adults'],
                            (int)$pending['children'],
                            ($pending['budget_raw'] ?? '') !== ''
                                ? (float)$pending['budget_raw']
                                : null,
                            ($pending['message'] ?? '') !== ''
                                ? (string)$pending['message']
                                : null
                        ]);

                        $enquiryId =
                            (int)$pdo->lastInsertId();
                    }

                    unset(
                        $_SESSION['contact_enquiry_pending']
                    );

                    $_SESSION['contact_csrf'] =
                        bin2hex(
                            random_bytes(32)
                        );

                    $_SESSION['contact_success'] =
                        'Enquiry sent successfully! Your enquiry #'
                        . $enquiryId
                        . ' has been received. Our travel team will contact you shortly.';

                    header(
                        'Location: '
                        . BASE_URL
                        . 'contact.php?submitted=1'
                    );

                    exit;

                } catch (Throwable $e) {

                    error_log(
                        'Verified contact enquiry insert error: '
                        . $e->getMessage()
                    );

                    $error =
                        'Your email was verified, but we could not save the enquiry. Please try again.';

                    $enquiryOtpPending = true;
                }
            }
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | RESEND OTP
    |--------------------------------------------------------------------------
    */

    elseif ($contactAction === 'resend_otp') {

        $pending =
            $_SESSION['contact_enquiry_pending']
            ?? null;

        if (
            !$pending
            ||
            !is_array($pending)
        ) {
            $error =
                'Your enquiry verification session has expired. Please complete the form again.';
        } else {

            $result =
                createEmailOtp(
                    $pdo,
                    (string)$pending['email'],
                    (string)$pending['name'],
                    'enquiry'
                );

            if (!empty($result['success'])) {

                $success =
                    'A new verification code has been sent to '
                    . maskEmail(
                        (string)$pending['email']
                    )
                    . '.';

            } else {

                $error =
                    (string)(
                        $result['message']
                        ?? 'Unable to resend verification code.'
                    );
            }

            $enquiryOtpPending = true;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | VALIDATE FORM + SEND FIRST OTP
    |--------------------------------------------------------------------------
    */

    else {

        $name =
            trim(
                (string)(
                    $_POST['name']
                    ?? ''
                )
            );

        $email =
            normalizeEmail(
                (string)(
                    $_POST['email']
                    ?? ''
                )
            );

        $mobile =
            trim(
                (string)(
                    $_POST['mobile']
                    ?? ''
                )
            );

        $destination =
            trim(
                (string)(
                    $_POST['destination']
                    ?? ''
                )
            );

        $travelDate =
            trim(
                (string)(
                    $_POST['travel_date']
                    ?? ''
                )
            );

        $adults =
            max(
                1,
                (int)(
                    $_POST['adults']
                    ?? 1
                )
            );

        $children =
            max(
                0,
                (int)(
                    $_POST['children']
                    ?? 0
                )
            );

        $budgetRaw =
            trim(
                (string)(
                    $_POST['budget']
                    ?? ''
                )
            );

        $budget =
            $budgetRaw;

        $message =
            trim(
                (string)(
                    $_POST['message']
                    ?? ''
                )
            );

        $enquiryCategory = trim((string)($_POST['enquiry_category'] ?? ''));
        $departureCity = trim((string)($_POST['departure_city'] ?? ''));
        $returnDate = trim((string)($_POST['return_date'] ?? ''));
        $tripType = trim((string)($_POST['trip_type'] ?? ''));
        $nationality = trim((string)($_POST['nationality'] ?? ''));
        $passportStatus = trim((string)($_POST['passport_status'] ?? ''));
        $visaRequirement = trim((string)($_POST['visa_requirement'] ?? ''));
        $visaNotes = trim((string)($_POST['visa_notes'] ?? ''));
        $hotelCategory = trim((string)($_POST['hotel_category'] ?? ''));
        $rooms = max(0, min(20, (int)($_POST['rooms'] ?? 1)));
        $mealPlan = trim((string)($_POST['meal_plan'] ?? ''));
        $flightPreference = trim((string)($_POST['flight_preference'] ?? ''));
        $transportPreference = trim((string)($_POST['transport_preference'] ?? ''));

        $servicesRequired = $_POST['services_required'] ?? [];
        if (!is_array($servicesRequired)) {
            $servicesRequired = [];
        }

        $allowedEnquiryCategories = [
            'Complete Holiday Package','Visa Only','Flight Only','Hotel Only',
            'Flight + Hotel','Honeymoon','Family Holiday','Group Tour',
            'Corporate / Business Travel','Cruise','Train / Transport',
            'Travel Insurance','Other Travel Requirement'
        ];

        $allowedServices = [
            'Flights','Hotels','Visa Assistance','Airport Transfer',
            'Local Transport','Sightseeing','Meals','Travel Insurance',
            'Train Tickets','Cruise','Tour Guide',
            'Honeymoon / Special Arrangement','Corporate / Group Travel'
        ];

        /*
         * Dedicated service form values.
         * These are mapped back into the existing enquiry columns where useful,
         * so Admin Enquiries keeps destination/travel-date compatibility without
         * showing the old duplicate generic form to the customer.
         */
        $serviceValues = [];
        $serviceFieldNames = [
            'flight_from','flight_to','flight_departure_date','flight_journey_type',
            'flight_return_date','flight_cabin','flight_airline','flight_route_preference',
            'hotel_destination','hotel_checkin','hotel_checkout','hotel_rooms_specific',
            'hotel_star_specific','hotel_meal_specific','hotel_preference_specific',
            'visa_country_specific','visa_nationality_specific','visa_type_specific',
            'visa_travel_date_specific','visa_applicants_specific','visa_passport_specific',
            'visa_priority_specific','visa_history_specific',
            'fh_from','fh_to','fh_departure','fh_return','fh_cabin','fh_rooms',
            'fh_hotel_category','fh_meal',
            'tour_from','tour_destination','tour_departure','tour_return','tour_hotel',
            'tour_rooms','tour_meal','tour_flights','tour_sightseeing','tour_transfer',
            'cruise_from','cruise_route','cruise_date','cruise_nights','cruise_cabin','cruise_line',
            'transport_from_specific','transport_to_specific','transport_date_specific',
            'transport_type_specific','transport_class_specific','transport_pickup_specific',
            'insurance_destination','insurance_from_date','insurance_to_date',
            'insurance_travellers','insurance_max_age','insurance_coverage',
            'other_service_name'
        ];
        foreach ($serviceFieldNames as $serviceFieldName) {
            $serviceValues[$serviceFieldName] =
                trim((string)($_POST[$serviceFieldName] ?? ''));
        }

        if (
            in_array(
                $enquiryCategory,
                ['Visa Only', 'Travel Insurance', 'Other Travel Requirement'],
                true
            )
        ) {
            $adults = 1;
            $children = 0;
        }

        switch ($enquiryCategory) {
            case 'Flight Only':
                $destination = $serviceValues['flight_to'];
                $travelDate = $serviceValues['flight_departure_date'];
                $departureCity = $serviceValues['flight_from'];
                $returnDate = $serviceValues['flight_return_date'];
                break;

            case 'Hotel Only':
                $destination = $serviceValues['hotel_destination'];
                $travelDate = $serviceValues['hotel_checkin'];
                $returnDate = $serviceValues['hotel_checkout'];
                $rooms = max(1, min(30, (int)($serviceValues['hotel_rooms_specific'] ?: 1)));
                break;

            case 'Visa Only':
                $destination = $serviceValues['visa_country_specific'];
                $travelDate = $serviceValues['visa_travel_date_specific'];
                $nationality = $serviceValues['visa_nationality_specific'];
                $passportStatus = $serviceValues['visa_passport_specific'];
                $visaRequirement = $serviceValues['visa_type_specific'];
                break;

            case 'Flight + Hotel':
                $destination = $serviceValues['fh_to'];
                $travelDate = $serviceValues['fh_departure'];
                $returnDate = $serviceValues['fh_return'];
                $departureCity = $serviceValues['fh_from'];
                $rooms = max(1, min(30, (int)($serviceValues['fh_rooms'] ?: 1)));
                break;

            case 'Complete Holiday Package':
            case 'Honeymoon':
            case 'Family Holiday':
            case 'Group Tour':
            case 'Corporate / Business Travel':
                $destination = $serviceValues['tour_destination'];
                $travelDate = $serviceValues['tour_departure'];
                $returnDate = $serviceValues['tour_return'];
                $departureCity = $serviceValues['tour_from'];
                $rooms = max(1, min(30, (int)($serviceValues['tour_rooms'] ?: 1)));
                break;

            case 'Cruise':
                $destination =
                    $serviceValues['cruise_route'] !== ''
                        ? $serviceValues['cruise_route']
                        : $serviceValues['cruise_from'];
                $travelDate = $serviceValues['cruise_date'];
                $departureCity = $serviceValues['cruise_from'];
                break;

            case 'Train / Transport':
                $destination = $serviceValues['transport_to_specific'];
                $travelDate = $serviceValues['transport_date_specific'];
                $departureCity = $serviceValues['transport_from_specific'];
                break;

            case 'Travel Insurance':
                $destination = $serviceValues['insurance_destination'];
                $travelDate = $serviceValues['insurance_from_date'];
                $returnDate = $serviceValues['insurance_to_date'];
                break;

            case 'Other Travel Requirement':
                $destination = '';
                $travelDate = '';
                break;
        }

        $requiredServiceFields = [
            'Flight Only' => [
                'flight_from' => 'Please select/search the departure city or airport.',
                'flight_to' => 'Please select/search the arrival city or airport.',
                'flight_departure_date' => 'Please select the flight departure date.'
            ],
            'Hotel Only' => [
                'hotel_destination' => 'Please select/search the hotel city or destination.',
                'hotel_checkin' => 'Please select the hotel check-in date.',
                'hotel_checkout' => 'Please select the hotel check-out date.'
            ],
            'Visa Only' => [
                'visa_country_specific' => 'Please select/search the visa country.',
                'visa_nationality_specific' => 'Please enter the traveller nationality.',
                'visa_type_specific' => 'Please select the visa purpose/type.',
                'visa_passport_specific' => 'Please select the passport status.'
            ],
            'Flight + Hotel' => [
                'fh_from' => 'Please select/search the departure city or airport.',
                'fh_to' => 'Please select/search the destination.',
                'fh_departure' => 'Please select the departure date.',
                'fh_return' => 'Please select the return date.'
            ],
            'Complete Holiday Package' => [
                'tour_from' => 'Please select/search the departure city.',
                'tour_destination' => 'Please select/search the holiday destination.',
                'tour_departure' => 'Please select the departure date.'
            ],
            'Honeymoon' => [
                'tour_from' => 'Please select/search the departure city.',
                'tour_destination' => 'Please select/search the honeymoon destination.',
                'tour_departure' => 'Please select the departure date.'
            ],
            'Family Holiday' => [
                'tour_from' => 'Please select/search the departure city.',
                'tour_destination' => 'Please select/search the family holiday destination.',
                'tour_departure' => 'Please select the departure date.'
            ],
            'Group Tour' => [
                'tour_from' => 'Please select/search the departure city.',
                'tour_destination' => 'Please select/search the group destination.',
                'tour_departure' => 'Please select the departure date.'
            ],
            'Corporate / Business Travel' => [
                'tour_from' => 'Please select/search the departure city.',
                'tour_destination' => 'Please select/search the business destination.',
                'tour_departure' => 'Please select the departure date.'
            ],
            'Cruise' => [
                'cruise_from' => 'Please select/search the cruise departure port or city.',
                'cruise_date' => 'Please select the sailing date.'
            ],
            'Train / Transport' => [
                'transport_from_specific' => 'Please select/search the departure location.',
                'transport_to_specific' => 'Please select/search the arrival location.',
                'transport_date_specific' => 'Please select the journey date.'
            ],
            'Travel Insurance' => [
                'insurance_destination' => 'Please select/search the destination country.',
                'insurance_from_date' => 'Please select the insurance departure date.',
                'insurance_to_date' => 'Please select the insurance return date.'
            ],
            'Other Travel Requirement' => [
                'other_service_name' => 'Please enter the travel service you need.'
            ]
        ];


        $servicesRequired = array_values(
            array_intersect($allowedServices, array_map('trim', $servicesRequired))
        );


        if ($name === '') {

            $error =
                'Please enter your full name.';

        } elseif (
            mb_strlen($name) < 2
            ||
            mb_strlen($name) > 150
        ) {

            $error =
                'Please enter a valid full name.';

        } elseif ($email === '') {

            $error =
                'Email address is required for enquiry verification.';

        } elseif (!validEmail($email)) {

            $error =
                'Please enter a valid email address.';

        } elseif (mb_strlen($email) > 190) {

            $error =
                'Email address is too long.';

        } elseif (
            $enquiryCategory === ''
            ||
            !in_array($enquiryCategory, $allowedEnquiryCategories, true)
        ) {

            $error =
                'Please select what travel service you need.';

        } elseif ($mobile === '') {

            $error =
                'Please enter your mobile number.';

        } elseif (
            !preg_match(
                '/^[0-9+\-\s()]{7,20}$/',
                $mobile
            )
        ) {

            $error =
                'Please enter a valid mobile number.';

        } else {

            foreach (($requiredServiceFields[$enquiryCategory] ?? []) as $fieldName => $fieldError) {
                if (($serviceValues[$fieldName] ?? '') === '') {
                    $error = $fieldError;
                    break;
                }
            }

            if (
                $error === ''
                &&
                $travelDate !== ''
                &&
                (
                    !preg_match('/^\d{4}-\d{2}-\d{2}$/', $travelDate)
                    ||
                    strtotime($travelDate) === false
                )
            ) {
                $error = 'Please select a valid travel date.';
            }

            if (
                $error === ''
                &&
                $travelDate !== ''
                &&
                $travelDate < date('Y-m-d')
            ) {
                $error = 'Travel date cannot be in the past.';
            }

            if (
                $error === ''
                &&
                $returnDate !== ''
                &&
                (
                    !preg_match('/^\d{4}-\d{2}-\d{2}$/', $returnDate)
                    ||
                    strtotime($returnDate) === false
                    ||
                    ($travelDate !== '' && $returnDate < $travelDate)
                )
            ) {
                $error = 'Return/check-out date must be the same as or after the departure/check-in date.';
            }

        }

        $travellerCountCategories = [
            'Complete Holiday Package',
            'Flight Only',
            'Hotel Only',
            'Flight + Hotel',
            'Honeymoon',
            'Family Holiday',
            'Group Tour',
            'Corporate / Business Travel',
            'Cruise',
            'Train / Transport'
        ];

        if (
            $error === ''
            &&
            in_array($enquiryCategory, $travellerCountCategories, true)
            &&
            (
                $adults < 1
                ||
                $adults > 50
            )
        ) {

            $error =
                'Please select a valid number of adults.';
        }

        if (
            $error === ''
            &&
            in_array($enquiryCategory, $travellerCountCategories, true)
            &&
            (
                $children < 0
                ||
                $children > 50
            )
        ) {

            $error =
                'Please select a valid number of children.';
        }

        if (
            $error === ''
            &&
            $budgetRaw !== ''
            &&
            (
                !is_numeric($budgetRaw)
                ||
                (float)$budgetRaw < 0
            )
        ) {

            $error =
                'Please enter a valid budget amount.';

        }

        if ($error === '' && $message === '') {

            $error =
                'Please tell us your travel requirement.';

        }

        if (
            $error === ''
            &&
            mb_strlen($message) > 5000
        ) {

            $error =
                'Message cannot exceed 5000 characters.';

        }

        if ($error === '') {

            $dedicatedFieldLabels = [
                'flight_from'=>'Flight From','flight_to'=>'Flight To','flight_departure_date'=>'Flight Departure Date',
                'flight_journey_type'=>'Journey Type','flight_return_date'=>'Flight Return Date','flight_cabin'=>'Cabin Class',
                'flight_airline'=>'Preferred Airline','flight_route_preference'=>'Flight Route Preference',
                'hotel_destination'=>'Hotel Destination','hotel_checkin'=>'Hotel Check-in','hotel_checkout'=>'Hotel Check-out',
                'hotel_rooms_specific'=>'Hotel Rooms','hotel_star_specific'=>'Hotel Category','hotel_meal_specific'=>'Hotel Meal Plan',
                'hotel_preference_specific'=>'Preferred Hotel / Area',
                'visa_country_specific'=>'Visa Country','visa_nationality_specific'=>'Visa Traveller Nationality',
                'visa_type_specific'=>'Visa Type / Purpose','visa_travel_date_specific'=>'Visa Expected Travel Date',
                'visa_applicants_specific'=>'Visa Applicants','visa_passport_specific'=>'Visa Passport Status',
                'visa_priority_specific'=>'Visa Processing Priority','visa_history_specific'=>'Visa History / Notes',
                'fh_from'=>'Flight + Hotel From','fh_to'=>'Flight + Hotel To','fh_departure'=>'Flight + Hotel Departure',
                'fh_return'=>'Flight + Hotel Return','fh_cabin'=>'Flight + Hotel Cabin','fh_rooms'=>'Flight + Hotel Rooms',
                'fh_hotel_category'=>'Flight + Hotel Category','fh_meal'=>'Flight + Hotel Meal Plan',
                'tour_from'=>'Tour Departure City','tour_destination'=>'Tour Destination','tour_departure'=>'Tour Departure Date',
                'tour_return'=>'Tour Return Date','tour_hotel'=>'Tour Hotel Category','tour_rooms'=>'Tour Rooms',
                'tour_meal'=>'Tour Meal Preference','tour_flights'=>'Tour Flights Required',
                'tour_sightseeing'=>'Tour Sightseeing Required','tour_transfer'=>'Tour Transfer Preference',
                'cruise_from'=>'Cruise Departure Port / City','cruise_route'=>'Cruise Route / Destination',
                'cruise_date'=>'Cruise Sailing Date','cruise_nights'=>'Cruise Nights','cruise_cabin'=>'Cruise Cabin',
                'cruise_line'=>'Preferred Cruise Line',
                'transport_from_specific'=>'Transport From','transport_to_specific'=>'Transport To',
                'transport_date_specific'=>'Transport Journey Date','transport_type_specific'=>'Transport Type',
                'transport_class_specific'=>'Transport Class','transport_pickup_specific'=>'Pickup / Drop Notes',
                'insurance_destination'=>'Insurance Destination','insurance_from_date'=>'Insurance Departure Date',
                'insurance_to_date'=>'Insurance Return Date','insurance_travellers'=>'Insurance Travellers',
                'insurance_max_age'=>'Oldest Traveller Age','insurance_coverage'=>'Insurance Coverage',
                'other_service_name'=>'Requested Other Service'
            ];

            $dedicatedRequirementLines = [];
            foreach ($dedicatedFieldLabels as $fieldName => $fieldLabel) {
                $fieldValue = trim((string)($_POST[$fieldName] ?? ''));
                if ($fieldValue !== '') {
                    $dedicatedRequirementLines[] = $fieldLabel . ': ' . $fieldValue;
                }
            }

            $requirementLines = [
                'Enquiry Category: ' . $enquiryCategory
            ];

            if ($departureCity !== '') $requirementLines[] = 'Departure City: ' . $departureCity;
            if ($returnDate !== '') $requirementLines[] = 'Return Date: ' . $returnDate;
            if ($tripType !== '') $requirementLines[] = 'Trip Type: ' . $tripType;
            if ($nationality !== '') $requirementLines[] = 'Traveller Nationality: ' . $nationality;
            if ($passportStatus !== '') $requirementLines[] = 'Passport Status: ' . $passportStatus;
            if ($visaRequirement !== '') $requirementLines[] = 'Visa Requirement: ' . $visaRequirement;
            if ($visaNotes !== '') $requirementLines[] = 'Visa Notes: ' . $visaNotes;
            if ($hotelCategory !== '') $requirementLines[] = 'Hotel Category: ' . $hotelCategory;
            if ($rooms > 0) $requirementLines[] = 'Rooms Required: ' . $rooms;
            if ($mealPlan !== '') $requirementLines[] = 'Meal Plan: ' . $mealPlan;
            if ($flightPreference !== '') $requirementLines[] = 'Flight Preference: ' . $flightPreference;
            if ($transportPreference !== '') $requirementLines[] = 'Transport Preference: ' . $transportPreference;
            if ($servicesRequired) {
                $requirementLines[] = 'Services Required: ' . implode(', ', $servicesRequired);
            }

            if ($dedicatedRequirementLines) {
                $requirementLines = array_merge(
                    $requirementLines,
                    $dedicatedRequirementLines
                );
            }

            $storedMessage =
                "TRAVEL REQUIREMENT DETAILS\n"
                . implode("\n", $requirementLines)
                . "\n\nCUSTOMER REQUIREMENT\n"
                . $message;

            $_SESSION['contact_enquiry_pending'] = [
                'package_id' =>
                    $packageId > 0
                        ? $packageId
                        : null,
                'name' => $name,
                'email' => $email,
                'mobile' => $mobile,
                'destination' => $destination,
                'travel_date' => $travelDate,
                'adults' => $adults,
                'children' => $children,
                'budget_raw' => $budgetRaw,
                'message' => $storedMessage,
                'customer_message' => $message,
                'enquiry_category' => $enquiryCategory,
                'departure_city' => $departureCity,
                'return_date' => $returnDate,
                'trip_type' => $tripType,
                'nationality' => $nationality,
                'passport_status' => $passportStatus,
                'visa_requirement' => $visaRequirement,
                'visa_notes' => $visaNotes,
                'hotel_category' => $hotelCategory,
                'rooms' => $rooms,
                'meal_plan' => $mealPlan,
                'flight_preference' => $flightPreference,
                'transport_preference' => $transportPreference,
                'services_required' => $servicesRequired,
                'created_at' => time()
            ];

            $result =
                createEmailOtp(
                    $pdo,
                    $email,
                    $name,
                    'enquiry'
                );

            if (!empty($result['success'])) {

                $success =
                    'OTP sent successfully to '
                    . maskEmail($email)
                    . '. Please enter the verification code to complete your enquiry.';

                $enquiryOtpPending = true;

            } else {

                unset(
                    $_SESSION['contact_enquiry_pending']
                );

                $error =
                    (string)(
                        $result['message']
                        ?? 'Unable to send email verification code.'
                    );
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| PACKAGE IMAGE
|--------------------------------------------------------------------------
*/

$packageImage = '';

if (
    $selectedPackage
    &&
    !empty(
        $selectedPackage[
            'main_image'
        ]
    )
) {

    $packageImage =
        contactImage(
            $selectedPackage[
                'main_image'
            ]
        );
}


/*
|--------------------------------------------------------------------------
| MINIMUM DATE
|--------------------------------------------------------------------------
*/

$minimumTravelDate =
    date('Y-m-d');

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
<?= e($pageTitle); ?>
</title>

<meta
    name="description"
    content="Plan your next journey with TRAVSCOPE. Send us your destination, travel date, budget and traveller details for a personalised travel enquiry."
>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

:root {

    --navy:#07192d;
    --navy2:#0c3156;

    --blue:#0b74ff;
    --cyan:#00b8ff;

    --green:#07885f;
    --green-bg:#eaf9f3;

    --orange:#e68a00;
    --orange-bg:#fff6e5;

    --red:#c73e4f;
    --red-bg:#fff0f2;

    --white:#ffffff;

    --bg:#f4f7fb;

    --text:#172235;

    --muted:#7d8998;

    --border:#e1e8ef;

    --shadow:
        0 20px 60px
        rgba(7,25,45,.09);
}


* {
    box-sizing:border-box;
    margin:0;
    padding:0;
}


html {
    scroll-behavior:smooth;
}


body {

    min-height:100vh;

    background:
        var(--bg);

    color:
        var(--text);

    font-family:
        'DM Sans',
        sans-serif;
}


a {
    color:inherit;
    text-decoration:none;
}


button,
input,
select,
textarea {
    font:inherit;
}


/* =========================================================
   HEADER
========================================================= */

.header {

    min-height:72px;

    padding:
        0 6%;

    display:flex;

    align-items:center;

    justify-content:
        space-between;

    gap:20px;

    border-bottom:
        1px solid
        var(--border);

    background:
        rgba(255,255,255,.97);

    position:relative;

    z-index:20;
}


.logo {

    display:flex;

    align-items:center;

    gap:9px;

    color:
        var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:19px;

    font-weight:800;
}


.logo-icon {

    width:40px;
    height:40px;

    border-radius:11px;

    display:grid;

    place-items:center;

    color:white;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--cyan)
        );

    box-shadow:
        0 8px 18px
        rgba(11,116,255,.18);
}


.logo span {
    color:var(--blue);
}


.header-nav {

    display:flex;

    align-items:center;

    gap:7px;
}


.nav-link {

    min-height:39px;

    padding:
        0 12px;

    border-radius:9px;

    display:inline-flex;

    align-items:center;

    gap:6px;

    color:#637286;

    font-size:8px;

    font-weight:800;

    transition:.2s;
}


.nav-link:hover {

    color:
        var(--blue);

    background:#f2f7ff;
}


.nav-login {

    border:
        1px solid
        var(--border);

    background:white;
}


/* =========================================================
   HERO
========================================================= */

.hero {

    min-height:335px;

    padding:
        65px 20px 115px;

    position:relative;

    overflow:hidden;

    color:white;

    text-align:center;

    background:
        radial-gradient(
            circle at 15% 20%,
            rgba(0,184,255,.20),
            transparent 25%
        ),
        radial-gradient(
            circle at 85% 75%,
            rgba(11,116,255,.20),
            transparent 27%
        ),
        linear-gradient(
            135deg,
            #06172a,
            #0b3763
        );
}


.hero::before {

    content:"";

    width:310px;
    height:310px;

    position:absolute;

    top:-190px;
    right:8%;

    border:
        50px solid
        rgba(255,255,255,.025);

    border-radius:50%;
}


.hero-badge {

    display:inline-flex;

    align-items:center;

    gap:6px;

    padding:
        7px 11px;

    position:relative;

    z-index:2;

    border:
        1px solid
        rgba(255,255,255,.12);

    border-radius:30px;

    background:
        rgba(255,255,255,.07);

    color:#d2e6f7;

    font-size:7px;

    font-weight:800;

    text-transform:uppercase;

    letter-spacing:.8px;
}


.hero h1 {

    max-width:760px;

    margin:
        15px auto 0;

    position:relative;

    z-index:2;

    font-family:
        'Manrope',
        sans-serif;

    font-size:36px;

    line-height:1.2;
}


.hero p {

    max-width:650px;

    margin:
        12px auto 0;

    position:relative;

    z-index:2;

    color:#b7cee2;

    font-size:9px;

    line-height:1.8;
}


/* =========================================================
   MAIN
========================================================= */

.container {

    width:
        min(1120px,92%);

    margin:
        -70px auto 55px;

    position:relative;

    z-index:10;
}


.contact-grid {

    display:grid;

    grid-template-columns:
        minmax(0,1fr)
        340px;

    gap:20px;

    align-items:start;
}


.card {

    border:
        1px solid
        var(--border);

    border-radius:18px;

    overflow:hidden;

    background:white;

    box-shadow:
        var(--shadow);
}


/* =========================================================
   FORM CARD
========================================================= */

.form-header {

    padding:
        22px 24px;

    border-bottom:
        1px solid
        var(--border);
}


.form-label {

    display:inline-flex;

    align-items:center;

    gap:5px;

    margin-bottom:6px;

    color:
        var(--blue);

    font-size:7px;

    font-weight:800;

    text-transform:uppercase;

    letter-spacing:.7px;
}


.form-header h2 {

    color:
        var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:19px;
}


.form-header p {

    margin-top:5px;

    color:
        var(--muted);

    font-size:8px;

    line-height:1.7;
}


.form-body {

    padding:
        24px;
}


.alert {

    margin-bottom:18px;

    padding:
        13px 14px;

    border-radius:10px;

    display:flex;

    align-items:flex-start;

    gap:9px;

    font-size:8px;

    line-height:1.7;
}


.alert-error {

    border:
        1px solid
        #efc7cd;

    background:
        var(--red-bg);

    color:
        var(--red);
}


.alert-success {

    border:
        1px solid
        #bde6d5;

    background:
        var(--green-bg);

    color:
        var(--green);
}


.alert i {
    margin-top:2px;
}


.form-grid {

    display:grid;

    grid-template-columns:
        repeat(2,minmax(0,1fr));

    gap:16px;
}


.field {
    min-width:0;
}


.field-full {
    grid-column:1 / -1;
}


.field label {

    display:block;

    margin-bottom:7px;

    color:#526175;

    font-size:8px;

    font-weight:800;
}


.required {
    color:#e34b5c;
}


.optional {

    color:#9ca6b2;

    font-weight:500;
}


.input-wrap {

    position:relative;
}


.input-icon {

    width:40px;

    position:absolute;

    top:0;
    bottom:0;
    left:0;

    display:grid;

    place-items:center;

    pointer-events:none;

    color:#9aa7b5;

    font-size:9px;
}


.input,
.select,
.textarea {

    width:100%;

    border:
        1px solid
        #dce4ec;

    border-radius:10px;

    outline:none;

    background:#fff;

    color:#3f4f63;

    font-size:9px;

    transition:.2s;
}


.input,
.select {

    min-height:47px;

    padding:
        0 12px;
}


.input.with-icon,
.select.with-icon {

    padding-left:39px;
}


.select {

    cursor:pointer;
}


.textarea {

    min-height:145px;

    padding:
        12px;

    resize:vertical;

    line-height:1.7;
}


.input:focus,
.select:focus,
.textarea:focus {

    border-color:#86b7ff;

    box-shadow:
        0 0 0 3px
        rgba(11,116,255,.06);
}


.field-note {

    margin-top:5px;

    color:#9aa5b2;

    font-size:7px;

    line-height:1.5;
}


/* =========================================================
   COMPLETE TRAVEL ENQUIRY
========================================================= */
.travel-section{padding:14px 16px;border:1px solid #dbe7f4;border-radius:12px}
.travel-section-blue{background:#eff6ff;border-color:#bfdbfe}
.travel-section-purple{background:#f5f3ff;border-color:#ddd6fe}
.travel-section-green{background:#ecfdf5;border-color:#a7f3d0}
.travel-section-orange{background:#fff7ed;border-color:#fed7aa}
.travel-section-title{display:flex;align-items:center;gap:9px;color:var(--navy);font-family:'Manrope',sans-serif;font-size:15px;font-weight:800}
.travel-section-title i{color:var(--blue)}
.compact-textarea{min-height:105px}
.travel-services-wrap{padding:14px;border:1px solid #e1e8ef;border-radius:12px;background:#f8fafc}
.travel-services-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.travel-service-option{min-height:48px;margin:0!important;padding:8px 10px;display:flex!important;align-items:center;gap:8px;border:1px solid #dce4ec;border-radius:9px;background:#fff;color:#526175!important;cursor:pointer;font-size:13px!important;font-weight:700!important}
.travel-service-option:hover{border-color:#86b7ff;background:#f2f7ff}
.travel-service-option input{width:16px;height:16px;accent-color:var(--blue)}
.travel-service-option span{width:27px;height:27px;flex:0 0 27px;display:grid;place-items:center;border-radius:7px;background:#edf5ff;color:var(--blue)}
@media(max-width:760px){.travel-services-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:480px){.travel-services-grid{grid-template-columns:1fr}}

/* =========================================================
   TRAVELLER COUNTERS
========================================================= */

.traveller-grid {

    display:grid;

    grid-template-columns:
        repeat(2,1fr);

    gap:10px;
}


.traveller-box {

    min-height:72px;

    padding:
        11px;

    border:
        1px solid
        #e0e6ed;

    border-radius:10px;

    display:flex;

    align-items:center;

    justify-content:
        space-between;

    gap:10px;

    background:#fbfcfe;
}


.traveller-box strong {

    display:block;

    color:#536275;

    font-size:8px;
}


.traveller-box span {

    display:block;

    margin-top:3px;

    color:#9ba5b1;

    font-size:6px;
}


.counter {

    display:flex;

    align-items:center;

    gap:7px;
}


.counter button {

    width:29px;
    height:29px;

    border:
        1px solid
        #dce4ec;

    border-radius:8px;

    cursor:pointer;

    display:grid;

    place-items:center;

    background:white;

    color:
        var(--blue);

    font-size:8px;
}


.counter button:hover {

    background:#edf5ff;
}


.counter-value {

    min-width:22px;

    text-align:center;

    color:
        var(--navy);

    font-size:10px;

    font-weight:800;
}


.counter input {
    display:none;
}


/* =========================================================
   SUBMIT
========================================================= */


.otp-panel{
    margin-top:18px;
    padding:18px;
    border:1px solid #cfe2ff;
    border-radius:14px;
    background:#f5f9ff;
}

.otp-panel-head{
    display:flex;
    align-items:flex-start;
    gap:11px;
    margin-bottom:14px;
}

.otp-panel-icon{
    width:38px;
    height:38px;
    flex:none;
    display:grid;
    place-items:center;
    border-radius:10px;
    background:#e5f1ff;
    color:var(--blue);
}

.otp-panel h3{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:13px;
}

.otp-panel p{
    margin-top:3px;
    color:var(--muted);
    font-size:10px;
    line-height:1.6;
}

.otp-input{
    text-align:center;
    letter-spacing:8px;
    font-size:18px !important;
    font-weight:800 !important;
}

.otp-resend-note{
    margin-top:9px;
    color:var(--muted);
    font-size:9px;
}


.otp-panel{
    position:fixed !important;
    inset:0 !important;
    z-index:9999 !important;
    margin:0 !important;
    padding:20px !important;
    display:flex !important;
    flex-direction:column;
    align-items:center;
    justify-content:center;
    border:0 !important;
    border-radius:0 !important;
    background:rgba(4,18,34,.72) !important;
    backdrop-filter:blur(7px);
}
.otp-panel-head,
.otp-panel > label,
.otp-panel > .input,
.otp-panel > .otp-resend-note{
    width:min(430px,100%);
    background:#fff;
}
.otp-panel-head{
    margin:0 !important;
    padding:26px 25px 18px;
    border-radius:22px 22px 0 0;
    align-items:center !important;
}
.otp-panel-icon{
    width:52px !important;
    height:52px !important;
    border-radius:16px !important;
    background:linear-gradient(135deg,var(--blue),var(--cyan)) !important;
    color:#fff !important;
    font-size:17px;
}
.otp-panel h3{font-size:18px !important;}
.otp-panel p{font-size:9px !important;}
.otp-panel > label{
    padding:8px 25px 6px;
    color:#526175;
    font-size:8px;
    font-weight:800;
}
.otp-panel > .otp-input{
    width:min(380px,calc(100% - 50px)) !important;
    min-height:58px;
    margin:0 25px;
    border-radius:12px;
    text-align:center;
    letter-spacing:10px;
    font-size:22px !important;
    font-weight:800 !important;
    color:var(--navy);
}
.otp-panel > .otp-resend-note{
    padding:10px 25px 22px;
    border-radius:0 0 22px 22px;
    text-align:center;
}
body:has(.otp-panel){overflow:hidden;}


.otp-panel + .submit-area{
    width:min(380px,calc(100% - 50px));
    position:fixed;
    z-index:10000;
    left:50%;
    top:calc(50% + 118px);
    transform:translateX(-50%);
    margin:0;
    padding:0;
    border:0;
}
.otp-panel + .submit-area .submit-button{
    min-height:46px;
}

.submit-area {

    margin-top:21px;

    padding-top:19px;

    border-top:
        1px solid
        #edf0f3;
}


.submit-button {

    width:100%;

    min-height:50px;

    border:0;

    border-radius:10px;

    cursor:pointer;

    display:flex;

    align-items:center;

    justify-content:center;

    gap:7px;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            #0866dc
        );

    color:white;

    font-size:9px;

    font-weight:800;

    box-shadow:
        0 10px 25px
        rgba(11,116,255,.20);

    transition:.2s;
}


.submit-button:hover {

    transform:
        translateY(-1px);

    box-shadow:
        0 13px 30px
        rgba(11,116,255,.25);
}


.submit-button:disabled {

    opacity:.65;

    cursor:not-allowed;

    transform:none;
}


.privacy {

    margin-top:10px;

    display:flex;

    align-items:flex-start;

    justify-content:center;

    gap:6px;

    color:#97a2ae;

    font-size:7px;

    line-height:1.5;

    text-align:center;
}


.privacy i {
    color:var(--green);
}


/* =========================================================
   SIDE PACKAGE
========================================================= */

.side-stack {

    display:flex;

    flex-direction:column;

    gap:14px;
}


.package-card-image {

    height:190px;

    position:relative;

    display:grid;

    place-items:center;

    overflow:hidden;

    background:
        linear-gradient(
            135deg,
            #e6f1fc,
            #f2f7fb
        );

    color:
        var(--blue);

    font-size:34px;
}


.package-card-image img {

    width:100%;
    height:100%;

    object-fit:cover;
}


.package-tag {

    position:absolute;

    top:12px;
    left:12px;

    padding:
        6px 9px;

    border-radius:20px;

    background:
        rgba(7,25,45,.78);

    color:white;

    font-size:6px;

    font-weight:800;

    text-transform:uppercase;

    backdrop-filter:
        blur(6px);
}


.package-info {

    padding:18px;
}


.package-info-label {

    color:
        var(--blue);

    font-size:7px;

    font-weight:800;

    text-transform:uppercase;

    letter-spacing:.6px;
}


.package-info h3 {

    margin-top:6px;

    color:
        var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:15px;

    line-height:1.4;
}


.package-destination {

    margin-top:7px;

    color:#8491a1;

    font-size:8px;

    line-height:1.5;
}


.package-meta {

    margin-top:14px;

    display:grid;

    grid-template-columns:
        1fr 1fr;

    gap:7px;
}


.meta-box {

    padding:
        10px;

    border-radius:9px;

    background:#f6f8fb;
}


.meta-box span {

    display:block;

    color:#9aa5b1;

    font-size:6px;

    text-transform:uppercase;
}


.meta-box strong {

    display:block;

    margin-top:3px;

    color:#526175;

    font-size:8px;
}


.package-price {

    margin-top:14px;

    padding-top:13px;

    border-top:
        1px solid
        #edf0f3;
}


.package-price span {

    color:#97a2af;

    font-size:7px;
}


.package-price strong {

    display:block;

    margin-top:2px;

    color:
        var(--navy);

    font-family:
        'Manrope',
        sans-serif;

    font-size:19px;
}


/* =========================================================
   HELP CARD
========================================================= */

.help-card {

    padding:19px;

    background:
        linear-gradient(
            135deg,
            #07192d,
            #0b345d
        );

    color:white;
}


.help-icon {

    width:42px;
    height:42px;

    border-radius:11px;

    display:grid;

    place-items:center;

    background:
        rgba(255,255,255,.09);

    color:#7ad7ff;

    font-size:15px;
}


.help-card h3 {

    margin-top:11px;

    font-family:
        'Manrope',
        sans-serif;

    font-size:13px;
}


.help-card p {

    margin-top:5px;

    color:#afc6d9;

    font-size:8px;

    line-height:1.7;
}


.help-points {

    margin-top:13px;

    display:flex;

    flex-direction:column;

    gap:7px;
}


.help-point {

    display:flex;

    align-items:center;

    gap:7px;

    color:#d6e5f1;

    font-size:7px;
}


.help-point i {

    width:19px;
    height:19px;

    border-radius:50%;

    display:grid;

    place-items:center;

    background:
        rgba(15,192,132,.13);

    color:#50d9a8;

    font-size:6px;
}


/* =========================================================
   WHY US
========================================================= */

.why {

    width:
        min(1120px,92%);

    margin:
        0 auto 55px;
}


.why-grid {

    display:grid;

    grid-template-columns:
        repeat(4,1fr);

    gap:10px;
}


.why-item {

    padding:17px;

    border:
        1px solid
        var(--border);

    border-radius:13px;

    background:white;
}


.why-icon {

    width:37px;
    height:37px;

    margin-bottom:9px;

    border-radius:10px;

    display:grid;

    place-items:center;

    background:#edf5ff;

    color:
        var(--blue);

    font-size:12px;
}


.why-item strong {

    display:block;

    color:
        var(--navy);

    font-size:9px;
}


.why-item span {

    display:block;

    margin-top:4px;

    color:#8d98a5;

    font-size:7px;

    line-height:1.6;
}


/* =========================================================
   FOOTER
========================================================= */

.footer {

    padding:
        25px 20px;

    border-top:
        1px solid
        var(--border);

    background:white;

    text-align:center;

    color:#929daa;

    font-size:7px;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:900px) {

    .contact-grid {

        grid-template-columns:1fr;
    }


    .side-stack {

        display:grid;

        grid-template-columns:
            repeat(2,1fr);
    }


    .why-grid {

        grid-template-columns:
            repeat(2,1fr);
    }
}


@media(max-width:650px) {

    .header {

        min-height:64px;

        padding:
            0 14px;
    }


    .logo {

        font-size:16px;
    }


    .logo-icon {

        width:36px;
        height:36px;
    }


    .header-nav
    .hide-mobile {

        display:none;
    }


    .hero {

        min-height:290px;

        padding:
            45px 18px 105px;
    }


    .hero h1 {

        font-size:27px;
    }


    .container {

        width:94%;

        margin-top:-65px;
    }


    .form-header,
    .form-body {

        padding:
            18px;
    }


    .form-grid {

        grid-template-columns:1fr;
    }


    .field-full {

        grid-column:auto;
    }


    .traveller-grid {

        grid-template-columns:1fr;
    }


    .side-stack {

        grid-template-columns:1fr;
    }


    .why {

        width:94%;
    }


    .why-grid {

        grid-template-columns:1fr;
    }
}


/* =========================================================
   PROFESSIONAL READABILITY + CENTERED CONTACT LAYOUT
========================================================= */

html{
    font-size:16px;
    -webkit-text-size-adjust:100%;
    text-size-adjust:100%;
}

body{
    font-size:16px;
    line-height:1.6;
    overflow-wrap:anywhere;
}

.header{
    min-height:76px;
}

.logo{
    font-size:20px;
}

.nav-link{
    font-size:14px;
}

.hero-badge{
    font-size:12px;
}

.hero h1{
    font-size:clamp(34px,5vw,52px);
    line-height:1.18;
}

.hero p{
    font-size:17px;
    line-height:1.8;
}

.container{
    width:min(940px,94%);
}

.contact-grid{
    grid-template-columns:minmax(0,860px);
    justify-content:center;
    gap:24px;
}

.card{
    width:100%;
}

.form-header{
    padding:28px 30px;
    text-align:center;
}

.form-label{
    font-size:12px;
}

.form-header h2{
    font-size:clamp(25px,3vw,32px);
}

.form-header p{
    max-width:650px;
    margin:8px auto 0;
    font-size:16px;
}

.form-body{
    padding:30px;
}

.alert{
    font-size:15px;
}

.field label{
    font-size:14px;
    line-height:1.4;
}

.optional,
.field-note{
    font-size:13px;
}

.input-icon{
    width:48px;
    font-size:15px;
}

.input,
.select,
.textarea{
    font-size:16px;
    color:#28384d;
}

.input,
.select{
    min-height:54px;
    padding:0 15px;
}

.input.with-icon,
.select.with-icon{
    padding-left:48px;
}

.textarea{
    min-height:165px;
    padding:15px;
}

.traveller-box{
    min-height:88px;
    padding:15px;
}

.traveller-box strong{
    font-size:15px;
}

.traveller-box span{
    font-size:13px;
}

.counter button{
    width:38px;
    height:38px;
    font-size:13px;
}

.counter-value{
    min-width:28px;
    font-size:17px;
}

.submit-button{
    min-height:55px;
    font-size:16px;
}

.privacy{
    font-size:13px;
}

.otp-panel h3{
    font-size:22px !important;
}

.otp-panel p,
.otp-panel > label,
.otp-resend-note{
    font-size:14px !important;
}

.side-stack{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:18px;
}

.package-tag,
.package-info-label{
    font-size:12px;
}

.package-info h3{
    font-size:20px;
}

.package-destination{
    font-size:14px;
}

.meta-box span,
.package-price span{
    font-size:12px;
}

.meta-box strong{
    font-size:14px;
}

.help-card h3{
    font-size:20px;
}

.help-card p{
    font-size:15px;
}

.help-point{
    font-size:14px;
}

.help-point i{
    width:25px;
    height:25px;
    font-size:10px;
}

.why{
    width:min(1120px,94%);
}

.why-item{
    padding:22px;
}

.why-item strong{
    font-size:16px;
}

.why-item span{
    font-size:14px;
}

.footer{
    padding:38px 20px;
    font-size:14px;
}

.footer-content{
    width:min(1120px,94%);
    margin:auto;
}

.footer-brand{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:22px;
    font-weight:800;
}

.footer-tagline{
    margin-top:6px;
    color:#6f7d90;
    font-size:15px;
}

.footer-contact{
    margin:22px auto 0;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-wrap:wrap;
    gap:12px 20px;
}

.footer-contact-item{
    display:inline-flex;
    align-items:center;
    gap:8px;
    color:#536275;
    font-size:14px;
}

.footer-contact-item i{
    color:var(--blue);
}

.social-section{
    margin-top:25px;
    padding-top:23px;
    border-top:1px solid var(--border);
}

.social-title{
    color:var(--navy);
    font-size:15px;
    font-weight:800;
}

.social-icons{
    margin-top:14px;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-wrap:wrap;
    gap:12px;
}

.social-link{
    width:48px;
    height:48px;
    border:1px solid var(--border);
    border-radius:50%;
    display:grid;
    place-items:center;
    background:#fff;
    color:var(--navy);
    font-size:19px;
    box-shadow:0 8px 22px rgba(7,25,45,.07);
    transition:transform .2s, box-shadow .2s, color .2s;
}

.social-link:hover{
    transform:translateY(-3px);
    box-shadow:0 12px 28px rgba(7,25,45,.12);
    color:var(--blue);
}

.social-link.whatsapp:hover{color:#18a957}
.social-link.facebook:hover{color:#1877f2}
.social-link.instagram:hover{color:#d62976}
.social-link.youtube:hover{color:#ff0000}
.social-link.twitter:hover{color:#111}

.footer-copy{
    margin-top:22px;
    color:#8b96a4;
    font-size:13px;
}

@media(max-width:900px){
    .side-stack{
        grid-template-columns:1fr;
    }
}

@media(max-width:650px){
    .hero h1{
        font-size:32px;
    }

    .hero p{
        font-size:15px;
    }

    .container{
        width:95%;
    }

    .form-header,
    .form-body{
        padding:21px 17px;
    }

    .form-header h2{
        font-size:25px;
    }

    .form-header p{
        font-size:15px;
    }

    .field label{
        font-size:14px;
    }

    .input,
    .select,
    .textarea{
        font-size:16px;
    }

    .why-item strong{
        font-size:16px;
    }

    .why-item span{
        font-size:14px;
    }

    .footer-contact{
        flex-direction:column;
    }

    .social-link{
        width:46px;
        height:46px;
    }
}

@media(max-width:380px){
    .form-body{
        padding:18px 13px;
    }

    .hero h1{
        font-size:28px;
    }

    .traveller-box{
        align-items:flex-start;
        flex-direction:column;
    }

    .counter{
        width:100%;
        justify-content:space-between;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}


/* =========================================================
   DYNAMIC SERVICE REQUIREMENT FORM
   Only relevant requirement boxes display after category choice.
========================================================= */
.service-requirement-block.service-requirement-hidden{
    display:none !important;
}
#enquiry_category:not([data-category-selected="1"]) ~ * .service-requirement-block{
    display:none;
}
.dynamic-requirement-hint{
    grid-column:1/-1;
    padding:11px 13px;
    border:1px dashed #cbd5e1;
    border-radius:10px;
    background:#f8fafc;
    color:#64748b;
    font-size:9px;
    font-weight:700;
}

/* =========================================================
   IQ200 SERVICE-SPECIFIC FORM
========================================================= */
.category-common-block{
    display:contents;
}
.category-common-block.service-requirement-hidden{
    display:none !important;
}
.dynamic-required-mark.optional{
    margin-left:5px;
    color:#94a3b8;
    font-size:9px;
    font-weight:600;
}
.dynamic-required-mark.required{
    margin-left:3px;
    color:#dc2626;
    font-size:11px;
    font-weight:800;
}

/* Dedicated category forms */
.dedicated-service-form{
    display:none;
    grid-column:1/-1;
    padding:14px;
    border:1px solid #dbeafe;
    border-radius:14px;
    background:linear-gradient(135deg,#f8fbff,#ffffff);
}
.dedicated-service-form.is-open{display:block;}
.dedicated-service-head{
    display:flex;
    align-items:center;
    gap:8px;
    margin-bottom:12px;
    font-size:13px;
    font-weight:900;
    color:#0f3d68;
}
.dedicated-service-grid{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:12px;
}
.dedicated-service-grid .field{margin:0;}
@media(max-width:760px){
    .dedicated-service-grid{grid-template-columns:1fr;}
}

/* Service form open fix: dedicated forms are independent of hidden legacy wrappers. */
.dedicated-service-form.is-open{
    display:block !important;
}

/* Category-specific traveller counters */
#categoryTravellerBlock.category-traveller-hidden{
    display:none !important;
}
</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>

<body>


<!-- =========================================================
     HEADER
========================================================= -->

<header class="header">


<a
    href="<?= e(BASE_URL . 'index.php'); ?>"
    class="logo"
>

    <span class="logo-icon">
        <i class="fa-solid fa-plane"></i>
    </span>

    <?= e($siteName !== '' ? $siteName : 'TRAVSCOPE.COM'); ?>

</a>


<nav class="header-nav">


<a
    href="<?= e(BASE_URL . 'packages.php'); ?>"
    class="nav-link hide-mobile"
>

    <i class="fa-solid fa-compass"></i>

    Packages

</a>


<?php if ($userId > 0): ?>

<a
    href="<?= e(BASE_URL . 'my-bookings.php'); ?>"
    class="nav-link hide-mobile"
>

    <i class="fa-solid fa-suitcase-rolling"></i>

    My Bookings

</a>


<a
    href="<?= e(BASE_URL . 'dashboard.php'); ?>"
    class="nav-link nav-login"
>

    <i class="fa-solid fa-user"></i>

    Dashboard

</a>

<?php else: ?>

<a
    href="<?= e(BASE_URL . 'login.php'); ?>"
    class="nav-link nav-login"
>

    <i class="fa-solid fa-right-to-bracket"></i>

    Login

</a>

<?php endif; ?>


</nav>

</header>


<!-- =========================================================
     HERO
========================================================= -->

<section class="hero">


<div class="hero-badge">

    <i class="fa-solid fa-route"></i>

    PERSONAL TRAVEL PLANNING

</div>


<h1>

    Tell Us Your Travel Dream.
    <br>
    We'll Help Plan the Journey.

</h1>


<p>

    Share your destination, preferred travel date,
    travellers and budget. Our travel team can review
    your requirements and help you find the right package.

</p>


</section>


<!-- =========================================================
     MAIN
========================================================= -->

<main class="container">


<div class="contact-grid">


<!-- =====================================================
     ENQUIRY FORM
====================================================== -->

<section class="card">


<div class="form-header">


<span class="form-label">

    <i class="fa-solid fa-paper-plane"></i>

    TRAVEL ENQUIRY

</span>


<h2>

    Plan Your Trip

</h2>


<p>

    Complete the form below and send your travel
    requirements to our team.

</p>


</div>


<div class="form-body">


<?php if ($error !== ''): ?>

<div class="alert alert-error">

    <i class="fa-solid fa-circle-exclamation"></i>

    <div>
        <?= e($error); ?>
    </div>

</div>

<?php endif; ?>


<?php if ($success !== '' && !$enquiryOtpPending): ?>

<div class="alert alert-success">

    <i class="fa-solid fa-circle-check"></i>

    <div>

        <strong>
            Enquiry Sent Successfully
        </strong>

        <br>

        <?= e($success); ?>

    </div>

</div>

<?php endif; ?>


<form
    method="post"
    action=""
    id="enquiryForm"
    autocomplete="on"
>


<input
    type="hidden"
    name="csrf_token"
    value="<?= e($csrfToken); ?>"
>


<input
    type="hidden"
    name="package_id"
    value="<?= (int)$packageId; ?>"
>


<div class="form-grid">


<!-- NAME -->

<div class="field">


<label for="name">

    Full Name

    <span class="required">*</span>

</label>


<div class="input-wrap">


<span class="input-icon">

    <i class="fa-regular fa-user"></i>

</span>


<input
    type="text"
    name="name"
    id="name"
    class="input with-icon"
    maxlength="150"
    required
    autocomplete="name"
    placeholder="Your full name"
    value="<?= e($name); ?>"
>


</div>


</div>


<!-- MOBILE -->

<div class="field">


<label for="mobile">

    Mobile Number

    <span class="required">*</span>

</label>


<div class="input-wrap">


<span class="input-icon">

    <i class="fa-solid fa-phone"></i>

</span>


<input
    type="tel"
    name="mobile"
    id="mobile"
    class="input with-icon"
    maxlength="20"
    required
    autocomplete="tel"
    placeholder="Your mobile number"
    value="<?= e($mobile); ?>"
>


</div>


</div>


<!-- EMAIL -->

<div class="field">


<label for="email">

    Email Address

    <span style="color:#c73e4f;">*</span>

</label>


<div class="input-wrap">


<span class="input-icon">

    <i class="fa-regular fa-envelope"></i>

</span>


<input
    type="email"
    name="email"
    id="email"
    class="input with-icon"
    maxlength="190"
    required
    autocomplete="email"
    placeholder="you@example.com"
    value="<?= e($email); ?>"
>


</div>


</div>


<!-- ENQUIRY CATEGORY -->

<div class="field field-full travel-section travel-section-blue">
<label for="enquiry_category">
    What Travel Service Do You Need?
    <span class="required">*</span>
</label>
<div class="input-wrap">
<span class="input-icon"><i class="fa-solid fa-suitcase-rolling"></i></span>
<select name="enquiry_category" id="enquiry_category" class="select with-icon" required>
    <option value="">Select enquiry category</option>
    <?php foreach ([
        'Complete Holiday Package','Visa Only','Flight Only','Hotel Only',
        'Flight + Hotel','Honeymoon','Family Holiday','Group Tour',
        'Corporate / Business Travel','Cruise','Train / Transport',
        'Travel Insurance','Other Travel Requirement'
    ] as $publicCategory): ?>
        <option value="<?= e($publicCategory); ?>" <?= $enquiryCategory === $publicCategory ? 'selected' : ''; ?>>
            <?= e($publicCategory); ?>
        </option>
    <?php endforeach; ?>
</select>
</div>
<div class="field-note">
    Choose a service. Only its requirement form will open. From / To / Destination boxes are searchable.
</div>
</div>

<!-- Searchable destination/country suggestions for dedicated service forms -->
<datalist id="travel_location_suggestions">
<?php foreach ($destinations as $searchLocation): ?>
    <?php
    $searchLocationValue =
        trim((string)$searchLocation['name'])
        .
        (!empty($searchLocation['country']) ? ', ' . trim((string)$searchLocation['country']) : '');
    ?>
    <option value="<?= e($searchLocationValue); ?>"></option>
<?php endforeach; ?>
</datalist>

<datalist id="travel_country_suggestions">
<?php
$searchCountries = [];
foreach ($destinations as $searchLocation) {
    $countryName = trim((string)($searchLocation['country'] ?? ''));
    if ($countryName !== '') {
        $searchCountries[$countryName] = true;
    }
}
ksort($searchCountries);
foreach (array_keys($searchCountries) as $countryName):
?>
    <option value="<?= e($countryName); ?>"></option>
<?php endforeach; ?>
</datalist>

<!-- =========================================================
     DEDICATED SERVICE-SPECIFIC REQUIREMENT FORMS
========================================================= -->
<div class="field field-full dedicated-service-form" data-category-form="Flight Only">
    <div class="dedicated-service-head"><i class="fa-solid fa-plane"></i> Flight Requirement</div>
    <div class="dedicated-service-grid">
        <div class="field"><label>From City / Airport <span class="required">*</span></label><input class="input" type="text" name="flight_from" maxlength="150" placeholder="Example: Delhi / DEL" list="travel_location_suggestions" autocomplete="off"></div>
        <div class="field"><label>To City / Airport <span class="required">*</span></label><input class="input" type="text" name="flight_to" maxlength="150" placeholder="Example: Dubai / DXB" list="travel_location_suggestions" autocomplete="off"></div>
        <div class="field"><label>Departure Date <span class="required">*</span></label><input class="input" type="date" name="flight_departure_date" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Journey Type</label><select class="select" name="flight_journey_type"><option value="">Select</option><option>One Way</option><option>Round Trip</option><option>Multi City</option></select></div>
        <div class="field"><label>Return Date</label><input class="input" type="date" name="flight_return_date" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Cabin Class</label><select class="select" name="flight_cabin"><option value="">Any cabin</option><option>Economy</option><option>Premium Economy</option><option>Business</option><option>First Class</option></select></div>
        <div class="field"><label>Preferred Airline</label><input class="input" type="text" name="flight_airline" maxlength="150" placeholder="Any airline or preference"></div>
        <div class="field"><label>Flight Preference</label><select class="select" name="flight_route_preference"><option value="">No preference</option><option>Direct / Non-stop</option><option>1 Stop Acceptable</option><option>Any Best Option</option></select></div>
    </div>
</div>

<div class="field field-full dedicated-service-form" data-category-form="Hotel Only">
    <div class="dedicated-service-head"><i class="fa-solid fa-hotel"></i> Hotel Requirement</div>
    <div class="dedicated-service-grid">
        <div class="field"><label>Hotel City / Destination <span class="required">*</span></label><input class="input" type="text" name="hotel_destination" maxlength="150" placeholder="City / destination" list="travel_location_suggestions" autocomplete="off"></div>
        <div class="field"><label>Check-in <span class="required">*</span></label><input class="input" type="date" name="hotel_checkin" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Check-out <span class="required">*</span></label><input class="input" type="date" name="hotel_checkout" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Rooms <span class="required">*</span></label><input class="input" type="number" name="hotel_rooms_specific" min="1" max="30" value="1"></div>
        <div class="field"><label>Hotel Category</label><select class="select" name="hotel_star_specific"><option value="">Any category</option><option>Budget / Standard</option><option>3 Star</option><option>4 Star</option><option>5 Star</option><option>Luxury / Premium</option><option>Resort / Villa</option></select></div>
        <div class="field"><label>Meal Plan</label><select class="select" name="hotel_meal_specific"><option value="">Any meal plan</option><option>Room Only</option><option>Breakfast</option><option>Breakfast + Dinner</option><option>All Meals</option><option>All Inclusive</option></select></div>
        <div class="field field-full"><label>Preferred Hotel / Area</label><input class="input" type="text" name="hotel_preference_specific" maxlength="250" placeholder="Hotel name, landmark or preferred area"></div>
    </div>
</div>

<div class="field field-full dedicated-service-form" data-category-form="Visa Only">
    <div class="dedicated-service-head"><i class="fa-solid fa-passport"></i> Visa Requirement</div>
    <div class="dedicated-service-grid">
        <div class="field"><label>Visa Country <span class="required">*</span></label><input class="input" type="text" name="visa_country_specific" maxlength="120" placeholder="Country applying for" list="travel_country_suggestions" autocomplete="off"></div>
        <div class="field"><label>Traveller Nationality <span class="required">*</span></label><input class="input" type="text" name="visa_nationality_specific" maxlength="100" placeholder="Example: Indian"></div>
        <div class="field"><label>Purpose / Visa Type <span class="required">*</span></label><select class="select" name="visa_type_specific"><option value="">Select visa purpose</option><option>Tourist</option><option>Business</option><option>Visit Family / Friends</option><option>Student</option><option>Transit</option><option>Medical</option><option>Other</option></select></div>
        <div class="field"><label>Expected Travel Date</label><input class="input" type="date" name="visa_travel_date_specific" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Number of Applicants</label><input class="input" type="number" name="visa_applicants_specific" min="1" max="50" value="1"></div>
        <div class="field"><label>Passport Status <span class="required">*</span></label><select class="select" name="visa_passport_specific"><option value="">Select passport status</option><option>Valid Passport Available</option><option>Passport Renewal Required</option><option>New Passport Required</option></select></div>
        <div class="field"><label>Processing Priority</label><select class="select" name="visa_priority_specific"><option value="">Normal</option><option>Normal Processing</option><option>Urgent</option><option>Need Eligibility Guidance</option></select></div>
        <div class="field field-full"><label>Previous Visa / Rejection / Special Notes</label><textarea class="textarea compact-textarea" name="visa_history_specific" maxlength="1200" placeholder="Previous visa history, rejection, passport expiry or special situation..."></textarea></div>
    </div>
</div>

<div class="field field-full dedicated-service-form" data-category-form="Flight + Hotel">
    <div class="dedicated-service-head"><i class="fa-solid fa-plane-circle-check"></i> Flight + Hotel Requirement</div>
    <div class="dedicated-service-grid">
        <div class="field"><label>From City / Airport <span class="required">*</span></label><input class="input" type="text" name="fh_from" maxlength="150" list="travel_location_suggestions" autocomplete="off"></div>
        <div class="field"><label>To City / Destination <span class="required">*</span></label><input class="input" type="text" name="fh_to" maxlength="150" list="travel_location_suggestions" autocomplete="off"></div>
        <div class="field"><label>Departure Date <span class="required">*</span></label><input class="input" type="date" name="fh_departure" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Return Date <span class="required">*</span></label><input class="input" type="date" name="fh_return" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Cabin Class</label><select class="select" name="fh_cabin"><option>Economy</option><option>Premium Economy</option><option>Business</option><option>First Class</option></select></div>
        <div class="field"><label>Rooms <span class="required">*</span></label><input class="input" type="number" name="fh_rooms" min="1" max="30" value="1"></div>
        <div class="field"><label>Hotel Category</label><select class="select" name="fh_hotel_category"><option value="">Any category</option><option>3 Star</option><option>4 Star</option><option>5 Star</option><option>Luxury / Premium</option></select></div>
        <div class="field"><label>Meal Plan</label><select class="select" name="fh_meal"><option value="">Any meal plan</option><option>Breakfast</option><option>Breakfast + Dinner</option><option>All Meals</option></select></div>
    </div>
</div>

<div class="field field-full dedicated-service-form" data-category-form="Complete Holiday Package|Honeymoon|Family Holiday|Group Tour|Corporate / Business Travel">
    <div class="dedicated-service-head"><i class="fa-solid fa-umbrella-beach"></i> Holiday / Tour Requirement</div>
    <div class="dedicated-service-grid">
        <div class="field"><label>Departure City <span class="required">*</span></label><input class="input" type="text" name="tour_from" maxlength="150" list="travel_location_suggestions" autocomplete="off"></div>
        <div class="field"><label>Destination <span class="required">*</span></label><input class="input" type="text" name="tour_destination" maxlength="150" list="travel_location_suggestions" autocomplete="off"></div>
        <div class="field"><label>Departure Date <span class="required">*</span></label><input class="input" type="date" name="tour_departure" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Return Date</label><input class="input" type="date" name="tour_return" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Hotel Category</label><select class="select" name="tour_hotel"><option value="">Select preference</option><option>3 Star</option><option>4 Star</option><option>5 Star</option><option>Luxury / Premium</option></select></div>
        <div class="field"><label>Rooms</label><input class="input" type="number" name="tour_rooms" min="1" max="30" value="1"></div>
        <div class="field"><label>Meal Preference</label><select class="select" name="tour_meal"><option value="">Select meal preference</option><option>Breakfast</option><option>Breakfast + Dinner</option><option>All Meals</option></select></div>
        <div class="field"><label>Need Flights?</label><select class="select" name="tour_flights"><option value="">Select</option><option>Yes</option><option>No</option><option>Quote Both Options</option></select></div>
        <div class="field"><label>Need Sightseeing?</label><select class="select" name="tour_sightseeing"><option value="">Select</option><option>Yes</option><option>No</option></select></div>
        <div class="field"><label>Need Transfers?</label><select class="select" name="tour_transfer"><option value="">Select</option><option>Private</option><option>Shared / SIC</option><option>No Transfer</option></select></div>
    </div>
</div>

<div class="field field-full dedicated-service-form" data-category-form="Cruise">
    <div class="dedicated-service-head"><i class="fa-solid fa-ship"></i> Cruise Requirement</div>
    <div class="dedicated-service-grid">
        <div class="field"><label>Departure Port / City <span class="required">*</span></label><input class="input" type="text" name="cruise_from" maxlength="150" list="travel_location_suggestions" autocomplete="off"></div>
        <div class="field"><label>Preferred Route / Destination</label><input class="input" type="text" name="cruise_route" maxlength="200" list="travel_location_suggestions" autocomplete="off"></div>
        <div class="field"><label>Sailing Date <span class="required">*</span></label><input class="input" type="date" name="cruise_date" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Preferred Nights</label><input class="input" type="number" name="cruise_nights" min="1" max="60"></div>
        <div class="field"><label>Cabin Preference</label><select class="select" name="cruise_cabin"><option value="">Any cabin</option><option>Interior</option><option>Ocean View</option><option>Balcony</option><option>Suite</option></select></div>
        <div class="field"><label>Preferred Cruise Line</label><input class="input" type="text" name="cruise_line" maxlength="150"></div>
    </div>
</div>

<div class="field field-full dedicated-service-form" data-category-form="Train / Transport">
    <div class="dedicated-service-head"><i class="fa-solid fa-train"></i> Train / Transport Requirement</div>
    <div class="dedicated-service-grid">
        <div class="field"><label>From <span class="required">*</span></label><input class="input" type="text" name="transport_from_specific" maxlength="150" list="travel_location_suggestions" autocomplete="off"></div>
        <div class="field"><label>To <span class="required">*</span></label><input class="input" type="text" name="transport_to_specific" maxlength="150" list="travel_location_suggestions" autocomplete="off"></div>
        <div class="field"><label>Journey Date <span class="required">*</span></label><input class="input" type="date" name="transport_date_specific" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Transport Type</label><select class="select" name="transport_type_specific"><option value="">Select</option><option>Train</option><option>Private Car</option><option>Tempo Traveller</option><option>Coach / Bus</option><option>Airport Transfer</option><option>Local Transport</option></select></div>
        <div class="field"><label>Train / Vehicle Class</label><input class="input" type="text" name="transport_class_specific" maxlength="150" placeholder="Example: 2A / 3A / SUV / Luxury"></div>
        <div class="field"><label>Pickup / Drop Notes</label><input class="input" type="text" name="transport_pickup_specific" maxlength="250"></div>
    </div>
</div>

<div class="field field-full dedicated-service-form" data-category-form="Travel Insurance">
    <div class="dedicated-service-head"><i class="fa-solid fa-shield-heart"></i> Travel Insurance Requirement</div>
    <div class="dedicated-service-grid">
        <div class="field"><label>Destination Country <span class="required">*</span></label><input class="input" type="text" name="insurance_destination" maxlength="120" list="travel_country_suggestions" autocomplete="off"></div>
        <div class="field"><label>Departure Date <span class="required">*</span></label><input class="input" type="date" name="insurance_from_date" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Return Date <span class="required">*</span></label><input class="input" type="date" name="insurance_to_date" min="<?= e($minimumTravelDate); ?>"></div>
        <div class="field"><label>Number of Travellers</label><input class="input" type="number" name="insurance_travellers" min="1" max="50" value="1"></div>
        <div class="field"><label>Oldest Traveller Age</label><input class="input" type="number" name="insurance_max_age" min="0" max="100"></div>
        <div class="field"><label>Coverage Type</label><select class="select" name="insurance_coverage"><option value="">Need recommendation</option><option>Single Trip</option><option>Multi Trip / Annual</option><option>Student Travel</option><option>Senior Citizen</option><option>Business Travel</option></select></div>
    </div>
</div>

<div class="field field-full dedicated-service-form" data-category-form="Other Travel Requirement">
    <div class="dedicated-service-head"><i class="fa-solid fa-list-check"></i> Other Travel Requirement</div>
    <div class="dedicated-service-grid">
        <div class="field field-full"><label>What Service Do You Need? <span class="required">*</span></label><input class="input" type="text" name="other_service_name" maxlength="200" placeholder="Tell us the exact travel service you need"></div>
    </div>
</div>


<div class="category-common-block service-requirement-block" data-service-groups="package honeymoon family group corporate flight hotel flight-hotel visa cruise transport insurance">


<!-- DESTINATION -->

<div class="field">


<label for="destination">

    Destination
    <span class="dynamic-required-mark" data-required-for="destination"></span>

</label>


<div class="input-wrap">


<span class="input-icon">

    <i class="fa-solid fa-location-dot"></i>

</span>


<select
    name="destination"
    id="destination"
    class="select with-icon"
>
    <option value="">Select available destination</option>

    <?php foreach ($destinations as $item): ?>

        <?php
        $destinationValue =
            trim((string)$item['name'])
            .
            (
                !empty($item['country'])
                    ? ', ' . trim((string)$item['country'])
                    : ''
            );
        ?>

        <option
            value="<?= e($destinationValue); ?>"
            <?= $destination === $destinationValue ? 'selected' : ''; ?>
        >
            <?= e($destinationValue); ?>
        </option>

    <?php endforeach; ?>
</select>


</div>


</div>


<div class="category-common-block service-requirement-block" data-service-groups="package honeymoon family group corporate flight hotel flight-hotel visa cruise transport insurance">

</div>

<!-- TRAVEL DATE -->

<div class="field">


<label for="travel_date">

    Preferred Travel Date
    <span class="dynamic-required-mark" data-required-for="travel_date"></span>

</label>


<div class="input-wrap">


<span class="input-icon">

    <i class="fa-regular fa-calendar"></i>

</span>


<input
    type="date"
    name="travel_date"
    id="travel_date"
    class="input with-icon"
    min="<?= e($minimumTravelDate); ?>"
    value="<?= e($travelDate); ?>"
>


</div>


</div>


<div class="category-common-block service-requirement-block" data-service-groups="package honeymoon family group corporate flight hotel flight-hotel cruise transport">

</div>

<!-- BUDGET -->

<div class="field">


<label for="budget">

    Approximate Budget

    <span class="optional">
        (optional)
    </span>

</label>


<div class="input-wrap">


<span class="input-icon">

    <i class="fa-solid fa-indian-rupee-sign"></i>

</span>


<input
    type="number"
    name="budget"
    id="budget"
    class="input with-icon"
    min="0"
    step="0.01"
    placeholder="Example: 50000"
    value="<?= e(
        $budget === ''
            ? ''
            : (string)$budget
    ); ?>"
>


</div>


<div class="field-note">

    Enter your approximate total trip budget in INR.

</div>


</div>



</div>

<!-- COMPLETE TRAVEL REQUIREMENTS -->

<div class="field field-full travel-section travel-section-purple service-requirement-block" data-service-groups="journey flight package honeymoon family group corporate cruise transport">
<div class="travel-section-title"><i class="fa-solid fa-route"></i> Journey & Trip Planning</div>
<div class="field-note">Add useful details for a more accurate travel proposal.</div>
</div>

<div class="field service-requirement-block" data-service-groups="journey flight package honeymoon family group corporate cruise transport">
<label>Departure City <span class="optional">(optional)</span></label>
<input type="text" name="departure_city" id="departure_city" class="input" maxlength="150"
       placeholder="Example: Delhi, Mumbai, Kolkata" value="<?= e($departureCity); ?>">
</div>

<div class="field service-requirement-block" data-service-groups="journey flight package honeymoon family group corporate cruise transport">
<label>Return Date <span class="optional">(optional)</span></label>
<input type="date" name="return_date" class="input" min="<?= e($minimumTravelDate); ?>" value="<?= e($returnDate); ?>">
</div>

<div class="field service-requirement-block" data-service-groups="journey package honeymoon family group corporate cruise">
<label>Trip Type <span class="optional">(optional)</span></label>
<select name="trip_type" class="select">
<option value="">Select trip type</option>
<?php foreach (['Leisure / Holiday','Honeymoon','Family','Friends / Group','Solo','Business / Corporate','MICE / Event','Pilgrimage','Medical Travel','Education / Student'] as $v): ?>
<option value="<?= e($v); ?>" <?= $tripType === $v ? 'selected' : ''; ?>><?= e($v); ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="field service-requirement-block" data-service-groups="journey visa package honeymoon family group corporate cruise">
<label>Traveller Nationality <span class="optional">(optional)</span></label>
<input type="text" name="nationality" id="nationality" class="input" maxlength="100" placeholder="Example: Indian" value="<?= e($nationality); ?>">
</div>

<div class="field field-full travel-section travel-section-green service-requirement-block" data-service-groups="visa package honeymoon family group corporate cruise">
<div class="travel-section-title"><i class="fa-solid fa-passport"></i> Passport & Visa</div>
</div>

<div class="field service-requirement-block" data-service-groups="visa">
<label>Passport Status <span class="optional">(optional)</span></label>
<select name="passport_status" id="passport_status" class="select">
<option value="">Select passport status</option>
<?php foreach (['Valid Passport Available','Passport Renewal Required','New Passport Required','Not Applicable'] as $v): ?>
<option value="<?= e($v); ?>" <?= $passportStatus === $v ? 'selected' : ''; ?>><?= e($v); ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="field service-requirement-block" data-service-groups="visa">
<label>Visa Requirement <span class="optional">(optional)</span></label>
<select name="visa_requirement" id="visa_requirement" class="select">
<option value="">Select visa requirement</option>
<?php foreach (['Visa Assistance Required','Visa Already Available','Visa On Arrival / E-Visa Guidance','Visa Not Required','Need Visa Eligibility Check'] as $v): ?>
<option value="<?= e($v); ?>" <?= $visaRequirement === $v ? 'selected' : ''; ?>><?= e($v); ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="field field-full service-requirement-block" data-service-groups="visa">
<label>Visa / Passport Notes <span class="optional">(optional)</span></label>
<textarea name="visa_notes" class="textarea compact-textarea" maxlength="1500"
placeholder="Passport expiry, visa history, embassy requirement or urgent processing..."><?= e($visaNotes); ?></textarea>
</div>

<div class="field field-full travel-section travel-section-orange service-requirement-block" data-service-groups="hotel flight package honeymoon family group corporate flight-hotel transport">
<div class="travel-section-title"><i class="fa-solid fa-hotel"></i> Hotel, Meals, Flight & Transport</div>
</div>

<div class="field service-requirement-block" data-service-groups="hotel package honeymoon family group corporate flight-hotel">
<label>Hotel Category <span class="optional">(optional)</span></label>
<select name="hotel_category" class="select">
<option value="">Select hotel preference</option>
<?php foreach (['Budget / Standard','3 Star','4 Star','5 Star','Luxury / Premium','Resort / Villa','Homestay / Apartment'] as $v): ?>
<option value="<?= e($v); ?>" <?= $hotelCategory === $v ? 'selected' : ''; ?>><?= e($v); ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="field service-requirement-block" data-service-groups="hotel package honeymoon family group corporate flight-hotel">
<label>Rooms Required <span class="optional">(optional)</span></label>
<input type="number" name="rooms" id="rooms" class="input" min="0" max="20" value="<?= (int)$rooms; ?>">
</div>

<div class="field service-requirement-block" data-service-groups="hotel package honeymoon family group corporate flight-hotel">
<label>Meal Plan <span class="optional">(optional)</span></label>
<select name="meal_plan" class="select">
<option value="">Select meal plan</option>
<?php foreach (['Room Only','Breakfast','Breakfast + Dinner','All Meals','All Inclusive','Special / Dietary Meal Required'] as $v): ?>
<option value="<?= e($v); ?>" <?= $mealPlan === $v ? 'selected' : ''; ?>><?= e($v); ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="field service-requirement-block" data-service-groups="transport package honeymoon family group corporate cruise">
<label>Transport Preference <span class="optional">(optional)</span></label>
<select name="transport_preference" class="select">
<option value="">Select transport</option>
<?php foreach (['Private Car','Shared Vehicle / SIC','Tempo Traveller','Luxury Vehicle','Coach / Bus','Self Drive','Public Transport Guidance'] as $v): ?>
<option value="<?= e($v); ?>" <?= $transportPreference === $v ? 'selected' : ''; ?>><?= e($v); ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="field field-full service-requirement-block" data-service-groups="flight package honeymoon family group corporate flight-hotel">
<label>Flight Preference <span class="optional">(optional)</span></label>
<input type="text" name="flight_preference" class="input" maxlength="300"
placeholder="Direct flight, preferred airline, cabin class or departure time..." value="<?= e($flightPreference); ?>">
</div>

<div class="field field-full travel-services-wrap service-requirement-block" data-service-groups="package honeymoon family group corporate other">
<label>Services Required <span class="optional">(select all that apply)</span></label>
<div class="travel-services-grid">
<?php foreach ([
'Flights'=>'fa-plane','Hotels'=>'fa-hotel','Visa Assistance'=>'fa-passport',
'Airport Transfer'=>'fa-van-shuttle','Local Transport'=>'fa-car-side',
'Sightseeing'=>'fa-camera','Meals'=>'fa-utensils','Travel Insurance'=>'fa-shield-heart',
'Train Tickets'=>'fa-train','Cruise'=>'fa-ship','Tour Guide'=>'fa-person-walking-luggage',
'Honeymoon / Special Arrangement'=>'fa-heart','Corporate / Group Travel'=>'fa-people-group'
] as $serviceName => $serviceIcon): ?>
<label class="travel-service-option">
<input type="checkbox" name="services_required[]" value="<?= e($serviceName); ?>"
<?= in_array($serviceName, $servicesRequired, true) ? 'checked' : ''; ?>>
<span><i class="fa-solid <?= e($serviceIcon); ?>"></i></span>
<?= e($serviceName); ?>
</label>
<?php endforeach; ?>
</div>
</div>

<div id="categoryTravellerBlock" data-traveller-categories="Complete Holiday Package|Flight Only|Hotel Only|Flight + Hotel|Honeymoon|Family Holiday|Group Tour|Corporate / Business Travel|Cruise|Train / Transport">
<!-- TRAVELLERS -->

<div class="field field-full">


<label>

    Travellers

</label>


<div class="traveller-grid">


<!-- ADULTS -->

<div class="traveller-box">


<div>

    <strong>
        Adults
    </strong>

    <span>
        Age 12+
    </span>

</div>


<div class="counter">


<button
    type="button"
    data-counter="adults"
    data-action="minus"
    aria-label="Decrease adults"
>

    <i class="fa-solid fa-minus"></i>

</button>


<div
    class="counter-value"
    id="adultsValue"
>

    <?= (int)$adults; ?>

</div>


<input
    type="number"
    name="adults"
    id="adults"
    min="1"
    max="50"
    value="<?= (int)$adults; ?>"
>


<button
    type="button"
    data-counter="adults"
    data-action="plus"
    aria-label="Increase adults"
>

    <i class="fa-solid fa-plus"></i>

</button>


</div>


</div>


<!-- CHILDREN -->

<div class="traveller-box">


<div>

    <strong>
        Children
    </strong>

    <span>
        Below age 12
    </span>

</div>


<div class="counter">


<button
    type="button"
    data-counter="children"
    data-action="minus"
    aria-label="Decrease children"
>

    <i class="fa-solid fa-minus"></i>

</button>


<div
    class="counter-value"
    id="childrenValue"
>

    <?= (int)$children; ?>

</div>


<input
    type="number"
    name="children"
    id="children"
    min="0"
    max="50"
    value="<?= (int)$children; ?>"
>


<button
    type="button"
    data-counter="children"
    data-action="plus"
    aria-label="Increase children"
>

    <i class="fa-solid fa-plus"></i>

</button>


</div>


</div>


</div>


</div>



</div>

<!-- MESSAGE -->

<div class="field field-full">


<label for="message">

    Tell Us About Your Trip
    <span class="required">*</span>

</label>


<textarea
    name="message"
    id="message"
    class="textarea"
    maxlength="5000"
    required
    placeholder="Tell us your main travel requirement, preferred plan, special needs or anything else our travel team should know..."
><?= e($message); ?></textarea>


<div class="field-note">

    <span id="messageCount">
        <?= mb_strlen($message); ?>
    </span>

    / 5000 characters

</div>


</div>


</div>


<?php if ($enquiryOtpPending): ?>

<input
    type="hidden"
    name="contact_action"
    value="verify_otp"
    id="otpVerifyAction"
>

<div class="otp-panel">

    <div class="otp-panel-head">

        <div class="otp-panel-icon">
            <i class="fa-solid fa-shield-halved"></i>
        </div>

        <div>
            <div style="display:inline-flex;align-items:center;gap:5px;margin-bottom:5px;padding:5px 8px;border-radius:20px;background:#eaf9f3;color:#07885f;font-size:7px;font-weight:800;">
                <i class="fa-solid fa-circle-check"></i>
                OTP Sent Successfully
            </div>
            <h3>Verify your email</h3>
            <p>
                Enter the <?= (int)OTP_LENGTH; ?>-digit OTP sent to
                <strong><?= e(maskEmail($email)); ?></strong>.
                Your enquiry details are already saved for verification. Enter the OTP only; you do not need to fill the form again.
            </p>
        </div>

    </div>

    <label for="email_otp">
        Email Verification Code
    </label>

    <input
        type="text"
        name="email_otp"
        id="email_otp"
        class="input otp-input"
        inputmode="numeric"
        autocomplete="one-time-code"
        pattern="[0-9]{<?= (int)OTP_LENGTH; ?>}"
        maxlength="<?= (int)OTP_LENGTH; ?>"
        placeholder="<?= str_repeat('0', (int)OTP_LENGTH); ?>"
        required
    >

    <div class="otp-resend-note">
        Didn't receive the code?
        <strong id="resendTimer">Resend OTP in 01:00</strong>
    </div>

</div>


<div class="submit-area">

<button
    type="submit"
    name="contact_action"
    value="verify_otp"
    class="submit-button"
    id="submitButton"
    formnovalidate
>
    <i class="fa-solid fa-circle-check"></i>
    Verify & Send Enquiry
</button>

<button
    type="submit"
    name="otp_resend"
    value="1"
    class="submit-button"
    id="resendOtpButton"
    style="margin-top:10px;background:#0c3156;"
    formnovalidate
>
    <i class="fa-solid fa-rotate"></i>
    Resend OTP
</button>

</div>

<?php else: ?>

<div class="submit-area">

<button
    type="submit"
    name="contact_action"
    value="send_otp"
    class="submit-button"
    id="submitButton"
>
    <i class="fa-regular fa-envelope"></i>
    Send Enquiry
</button>

</div>

<?php endif; ?>


</form>


<!-- =====================================================
     SIDEBAR
====================================================== -->

<aside class="side-stack">


<?php if ($selectedPackage): ?>


<section class="card">


<div class="package-card-image">


<?php if ($packageImage !== ''): ?>

<img
    src="<?= e($packageImage); ?>"
    alt="<?= e($selectedPackage['title']); ?>"
>

<?php else: ?>

<i class="fa-solid fa-mountain-sun"></i>

<?php endif; ?>


<span class="package-tag">

    Selected Package

</span>


</div>


<div class="package-info">


<span class="package-info-label">

    Your Enquiry Is For

</span>


<h3>

    <?= e(
        $selectedPackage[
            'title'
        ]
    ); ?>

</h3>


<?php if (
    !empty(
        $selectedPackage[
            'destination_name'
        ]
    )
): ?>

<div class="package-destination">

    <i class="fa-solid fa-location-dot"></i>

    <?= e(
        $selectedPackage[
            'destination_name'
        ]
    ); ?>

    <?php if (
        !empty(
            $selectedPackage[
                'destination_country'
            ]
        )
    ): ?>

        ,
        <?= e(
            $selectedPackage[
                'destination_country'
            ]
        ); ?>

    <?php endif; ?>

</div>

<?php endif; ?>


<div class="package-meta">


<div class="meta-box">

    <span>
        Duration
    </span>

    <strong>

        <?= (int)
            $selectedPackage[
                'duration_days'
            ]; ?>

        Days /

        <?= (int)
            $selectedPackage[
                'duration_nights'
            ]; ?>

        Nights

    </strong>

</div>


<div class="meta-box">

    <span>
        Package
    </span>

    <strong>
        #<?= (int)$packageId; ?>
    </strong>

</div>


</div>


<?php if (
    (float)(
        $selectedPackage[
            'sale_price'
        ]
        ?? 0
    )
    > 0
): ?>

<div class="package-price">

    <span>
        Package price
    </span>

    <strong>

        ₹<?= contactMoney(
            $selectedPackage[
                'sale_price'
            ]
        ); ?>

    </strong>

</div>

<?php endif; ?>


</div>


</section>


<?php endif; ?>


<section class="card help-card">


<div class="help-icon">

    <i class="fa-solid fa-headset"></i>

</div>


<h3>

    Need Help Planning?

</h3>


<p>

    Send your requirements and our travel team can
    review your trip details and contact you.

</p>


<div class="help-points">


<div class="help-point">

    <i class="fa-solid fa-check"></i>

    Personalised travel enquiry

</div>


<div class="help-point">

    <i class="fa-solid fa-check"></i>

    Package guidance

</div>


<div class="help-point">

    <i class="fa-solid fa-check"></i>

    Budget & itinerary discussion

</div>


<div class="help-point">

    <i class="fa-solid fa-check"></i>

    Booking assistance

</div>


</div>


</section>


</aside>


</div>


</main>


<!-- =========================================================
     WHY TRAVSCOPE
========================================================= -->

<section class="why">


<div class="why-grid">


<div class="why-item">


<div class="why-icon">

    <i class="fa-solid fa-user-tie"></i>

</div>


<strong>

    Travel Assistance

</strong>


<span>

    Share your requirements so our team can understand
    the journey you are planning.

</span>


</div>


<div class="why-item">


<div class="why-icon">

    <i class="fa-solid fa-route"></i>

</div>


<strong>

    Flexible Planning

</strong>


<span>

    Tell us your destination, dates, travellers and
    preferences.

</span>


</div>


<div class="why-item">


<div class="why-icon">

    <i class="fa-solid fa-wallet"></i>

</div>


<strong>

    Budget Friendly

</strong>


<span>

    Add your expected budget so the team can understand
    your preferred travel range.

</span>


</div>


<div class="why-item">


<div class="why-icon">

    <i class="fa-solid fa-shield-heart"></i>

</div>


<strong>

    Easy Enquiry

</strong>


<span>

    Your request is stored directly in the TRAVSCOPE
    enquiry management system.

</span>


</div>


</div>


</section>


<!-- =========================================================
     FOOTER
========================================================= -->

<footer class="footer">

<div class="footer-content">

    <div class="footer-brand">
        <?= e($siteName !== '' ? $siteName : 'TRAVSCOPE.COM'); ?>
    </div>

    <?php if ($siteTagline !== ''): ?>
        <div class="footer-tagline">
            <?= e($siteTagline); ?>
        </div>
    <?php endif; ?>

    <?php if (
        $supportEmail !== ''
        || $supportMobile !== ''
        || $officeAddress !== ''
        || $businessHours !== ''
    ): ?>

        <div class="footer-contact">

            <?php if ($supportEmail !== ''): ?>
                <a
                    class="footer-contact-item"
                    href="mailto:<?= e($supportEmail); ?>"
                >
                    <i class="fa-regular fa-envelope"></i>
                    <span><?= e($supportEmail); ?></span>
                </a>
            <?php endif; ?>

            <?php if ($supportMobile !== ''): ?>
                <a
                    class="footer-contact-item"
                    href="tel:<?= e(preg_replace('/[^0-9+]/', '', $supportMobile)); ?>"
                >
                    <i class="fa-solid fa-phone"></i>
                    <span><?= e($supportMobile); ?></span>
                </a>
            <?php endif; ?>

            <?php if ($officeAddress !== ''): ?>
                <div class="footer-contact-item">
                    <i class="fa-solid fa-location-dot"></i>
                    <span><?= nl2br(e($officeAddress)); ?></span>
                </div>
            <?php endif; ?>

            <?php if ($businessHours !== ''): ?>
                <div class="footer-contact-item">
                    <i class="fa-regular fa-clock"></i>
                    <span><?= e($businessHours); ?></span>
                </div>
            <?php endif; ?>

        </div>

    <?php endif; ?>

    <?php if ($socialLinks): ?>

        <div class="social-section">

            <div class="social-title">
                Connect With Us
            </div>

            <div class="social-icons">

                <?php foreach ($socialLinks as $social): ?>

                    <a
                        href="<?= e($social['url']); ?>"
                        class="social-link <?= e($social['class']); ?>"
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label="<?= e($social['name']); ?>"
                        title="<?= e($social['name']); ?>"
                    >
                        <i class="<?= e($social['icon']); ?>"></i>
                    </a>

                <?php endforeach; ?>

            </div>

        </div>

    <?php endif; ?>

    <div class="footer-copy">
        © <?= date('Y'); ?>
        <?= e($siteName !== '' ? $siteName : 'TRAVSCOPE.COM'); ?>
        · Travel Enquiry &amp; Booking Platform
    </div>

</div>

</footer>


<script>

/*
|--------------------------------------------------------------------------
| TRAVELLER COUNTERS
|--------------------------------------------------------------------------
*/

document
    .querySelectorAll(
        '[data-counter]'
    )
    .forEach(function(button){

        button.addEventListener(
            'click',
            function(){

                const name =
                    this.dataset.counter;

                const action =
                    this.dataset.action;

                const input =
                    document.getElementById(
                        name
                    );

                const display =
                    document.getElementById(
                        name + 'Value'
                    );

                if (
                    !input ||
                    !display
                ) {
                    return;
                }

                const min =
                    parseInt(
                        input.min || '0',
                        10
                    );

                const max =
                    parseInt(
                        input.max || '50',
                        10
                    );

                let value =
                    parseInt(
                        input.value || min,
                        10
                    );

                if (
                    action === 'plus'
                    &&
                    value < max
                ) {

                    value++;
                }

                if (
                    action === 'minus'
                    &&
                    value > min
                ) {

                    value--;
                }

                input.value =
                    value;

                display.textContent =
                    value;
            }
        );
    });


/*
|--------------------------------------------------------------------------
| MESSAGE COUNTER
|--------------------------------------------------------------------------
*/

const message =
    document.getElementById(
        'message'
    );

const messageCount =
    document.getElementById(
        'messageCount'
    );

if (
    message &&
    messageCount
) {

    message.addEventListener(
        'input',
        function(){

            messageCount.textContent =
                this.value.length;
        }
    );
}


/*
|--------------------------------------------------------------------------
| SUBMIT PROTECTION
|--------------------------------------------------------------------------
*/

const enquiryForm =
    document.getElementById(
        'enquiryForm'
    );

if (enquiryForm) {

    enquiryForm.addEventListener(
        'submit',
        function(event){

            const submitter =
                event.submitter;

            /*
            |--------------------------------------------------------------------------
            | IMPORTANT
            |--------------------------------------------------------------------------
            | A disabled submit button is not included in POST data.
            | Preserve its contact_action before disabling it, otherwise
            | verify_otp falls back to send_otp on the PHP side.
            */

            if (
                submitter
                &&
                submitter.name === 'contact_action'
                &&
                submitter.value !== 'verify_otp'
            ) {

                let actionInput =
                    enquiryForm.querySelector(
                        'input[type="hidden"][name="contact_action"]'
                    );

                if (!actionInput) {

                    actionInput =
                        document.createElement(
                            'input'
                        );

                    actionInput.type =
                        'hidden';

                    actionInput.name =
                        'contact_action';

                    enquiryForm.appendChild(
                        actionInput
                    );
                }

                actionInput.value =
                    submitter.value;
            }

            if (!submitter) {
                return;
            }

            submitter.disabled =
                true;

            if (
                submitter.value === 'verify_otp'
            ) {

                submitter.innerHTML =
                    '<i class="fa-solid fa-spinner fa-spin"></i> Verifying & Submitting...';

            } else if (
                submitter.id === 'resendOtpButton'
                ||
                submitter.name === 'otp_resend'
            ) {

                submitter.innerHTML =
                    '<i class="fa-solid fa-spinner fa-spin"></i> Resending OTP...';

            } else {

                submitter.innerHTML =
                    '<i class="fa-solid fa-spinner fa-spin"></i> Sending OTP...';
            }
        }
    );
}


/*
|--------------------------------------------------------------------------
| RESEND OTP COUNTDOWN - 60 SECONDS
|--------------------------------------------------------------------------
*/

const resendOtpButton =
    document.getElementById('resendOtpButton');

const resendTimer =
    document.getElementById('resendTimer');

if (
    resendOtpButton
    &&
    resendTimer
) {

    let resendSeconds = 60;

    resendOtpButton.disabled = true;

    function updateResendTimer() {

        if (resendSeconds <= 0) {

            resendOtpButton.disabled = false;

            resendTimer.textContent =
                'You can resend OTP now';

            return;
        }

        const minutes =
            Math.floor(resendSeconds / 60);

        const seconds =
            resendSeconds % 60;

        resendTimer.textContent =
            'Resend OTP in '
            + String(minutes).padStart(2, '0')
            + ':'
            + String(seconds).padStart(2, '0');

        resendSeconds--;

        setTimeout(
            updateResendTimer,
            1000
        );
    }

    updateResendTimer();
}

</script>



<script id="travscope-dynamic-service-requirements">
(function(){
    const category = document.getElementById('enquiry_category');
    if (!category) return;

    const blocks = Array.from(
        document.querySelectorAll('.service-requirement-block')
    );

    const categoryGroups = {
        'Complete Holiday Package': ['package'],
        'Visa Only': ['visa'],
        'Flight Only': ['flight'],
        'Hotel Only': ['hotel'],
        'Flight + Hotel': ['flight-hotel'],
        'Honeymoon': ['honeymoon'],
        'Family Holiday': ['family'],
        'Group Tour': ['group'],
        'Corporate / Business Travel': ['corporate'],
        'Cruise': ['cruise'],
        'Train / Transport': ['transport'],
        'Travel Insurance': ['insurance'],
        'Other Travel Requirement': ['other']
    };

    const requiredByCategory = {
        'Complete Holiday Package': ['destination','travel_date'],
        'Visa Only': [
            'destination',
            'nationality',
            'passport_status',
            'visa_requirement'
        ],
        'Flight Only': [
            'destination',
            'travel_date',
            'departure_city'
        ],
        'Hotel Only': [
            'destination',
            'travel_date',
            'rooms'
        ],
        'Flight + Hotel': [
            'destination',
            'travel_date',
            'departure_city',
            'rooms'
        ],
        'Honeymoon': ['destination','travel_date'],
        'Family Holiday': ['destination','travel_date'],
        'Group Tour': ['destination','travel_date'],
        'Corporate / Business Travel': ['destination','travel_date'],
        'Cruise': ['destination','travel_date'],
        'Train / Transport': ['destination','travel_date'],
        'Travel Insurance': ['destination','travel_date'],
        'Other Travel Requirement': []
    };

    function updateRequirementBoxes(){
        const selected = category.value || '';
        const groups = categoryGroups[selected] || [];
        const requiredIds = requiredByCategory[selected] || [];

        const travellerBlock = document.getElementById('categoryTravellerBlock');
        if (travellerBlock) {
            const travellerCategories = (travellerBlock.dataset.travellerCategories || '').split('|');
            const showTravellers = selected !== '' && travellerCategories.includes(selected);

            travellerBlock.classList.toggle('category-traveller-hidden', !showTravellers);

            travellerBlock.querySelectorAll('input,select,textarea,button').forEach(function(control){
                control.disabled = !showTravellers;
            });
        }

        document.querySelectorAll('.dedicated-service-form').forEach(function(formBox){
            const categories = (formBox.dataset.categoryForm || '').split('|');
            const open = selected !== '' && categories.includes(selected);
            formBox.classList.toggle('is-open', open);

            formBox.querySelectorAll('input,select,textarea').forEach(function(control){
                control.disabled = !open;
            });
        });

        /*
         * Dedicated form is now the single source of service requirements.
         * Old generic destination/date/budget/visa/hotel blocks stay hidden
         * and disabled, so there is never a double form.
         */
        blocks.forEach(function(block){
            block.classList.add('service-requirement-hidden');
            block.querySelectorAll('input,select,textarea').forEach(function(control){
                control.required = false;
                control.disabled = true;
            });
        });


        const dedicatedRequired = {
            'Flight Only': ['flight_from','flight_to','flight_departure_date'],
            'Hotel Only': ['hotel_destination','hotel_checkin','hotel_checkout','hotel_rooms_specific'],
            'Visa Only': ['visa_country_specific','visa_nationality_specific','visa_type_specific','visa_passport_specific'],
            'Flight + Hotel': ['fh_from','fh_to','fh_departure','fh_return','fh_rooms'],
            'Complete Holiday Package': ['tour_from','tour_destination','tour_departure'],
            'Honeymoon': ['tour_from','tour_destination','tour_departure'],
            'Family Holiday': ['tour_from','tour_destination','tour_departure'],
            'Group Tour': ['tour_from','tour_destination','tour_departure'],
            'Corporate / Business Travel': ['tour_from','tour_destination','tour_departure'],
            'Cruise': ['cruise_from','cruise_date'],
            'Train / Transport': ['transport_from_specific','transport_to_specific','transport_date_specific'],
            'Travel Insurance': ['insurance_destination','insurance_from_date','insurance_to_date'],
            'Other Travel Requirement': ['other_service_name']
        };

        document.querySelectorAll('.dedicated-service-form [name]').forEach(function(control){
            control.required = false;
        });
        (dedicatedRequired[selected] || []).forEach(function(name){
            const control = document.querySelector(
                '.dedicated-service-form.is-open [name="' + name + '"]'
            );
            if (control) control.required = true;
        });


    }

    category.addEventListener('change', updateRequirementBoxes);
    updateRequirementBoxes();
})();
</script>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>