<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
require_once __DIR__.'/supplier-hotel-option-functions.php';
require_once __DIR__.'/supplier-hotel-import-functions.php';
if(function_exists('requireAdmin'))requireAdmin();elseif(empty($_SESSION['admin_id'])){header('Location: '.(defined('BASE_URL')?BASE_URL:'').'login.php');exit;}
$adminId=(int)($_SESSION['admin_id']??0);
function shiE($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
if(empty($_SESSION['shi_csrf']))$_SESSION['shi_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['shi_csrf'];
$suppliers=tsSHOSuppliers($pdo);
$supplierId=max(0,(int)($_GET['supplier_id']??$_POST['supplier_id']??0));
if($supplierId<=0&&count($suppliers)===1)$supplierId=(int)$suppliers[0]['id'];
$supplier=$supplierId>0?tsSHOSupplier($pdo,$supplierId):null;
$destinations=tsSHODestinations($pdo);
$error='';$success=(string)($_SESSION['shi_success']??'');unset($_SESSION['shi_success']);
$token=trim((string)($_GET['token']??$_POST['token']??''));
$preview=null;
$isAjax=($_SERVER['REQUEST_METHOD']==='POST'&&!empty($_POST['ajax']));

function shiCounts(array $rows):array{
    $c=['total'=>count($rows),'included'=>0,'valid'=>0,'errors'=>0,'warnings'=>0,'duplicates'=>0,'unlinked'=>0,'missing_city'=>0,'excluded'=>0];
    foreach($rows as $r){
        if(!empty($r['excluded'])){$c['excluded']++;continue;}
        $c['included']++;
        if(empty($r['errors']))$c['valid']++;else $c['errors']++;
        if(!empty($r['warnings']))$c['warnings']++;
        if(!empty($r['existing_id']))$c['duplicates']++;
        if(empty($r['hotel_id']))$c['unlinked']++;
        foreach(($r['warnings']??[]) as $w)if(stripos((string)$w,'Location Master')!==false){$c['missing_city']++;break;}
    }
    return $c;
}
function shiPreviewData(string $token):?array{return $token!==''&&isset($_SESSION['shi_import_'.$token])&&is_array($_SESSION['shi_import_'.$token])?$_SESSION['shi_import_'.$token]:null;}
function shiPostedDestinationMap():array{
    $map=[];$labels=$_POST['map_label']??[];$ids=$_POST['map_destination_id']??[];
    if(is_array($labels)&&is_array($ids))foreach($labels as $i=>$label){$id=(int)($ids[$i]??0);$label=trim((string)$label);if($label!==''&&$id>0)$map[$label]=$id;}
    return $map;
}
function shiApplyPosted(PDO $pdo,array $data,int $supplierId):array{
    $postedRows=is_array($_POST['rows']??null)?$_POST['rows']:[];
    $data['rows']=tsSHIApplyPreviewCorrections($pdo,$data['rows']??[],$supplierId,$postedRows,shiPostedDestinationMap());
    $data['updated_at']=time();
    return $data;
}
function shiJson(bool $ok,string $message,array $extra=[]):never{
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge(['ok'=>$ok,'message'=>$message],$extra),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
function shiRowSourceLabel(array $r):string{
    foreach(['source_destination','source_state','destination_name'] as $k){$v=trim((string)($r[$k]??''));if($v!=='')return $v;}
    return '';
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        if(!hash_equals($csrf,(string)($_POST['csrf']??'')))throw new RuntimeException('Security verification failed. Reload and try again.');
        $action=(string)($_POST['action']??'');
        if($action==='preview'){
            if(!$supplier)throw new RuntimeException('Choose a supplier first.');
            if(empty($_FILES['import_file'])||!is_array($_FILES['import_file']))throw new RuntimeException('Choose an Excel or CSV file.');
            $f=$_FILES['import_file'];if((int)($f['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)throw new RuntimeException('Upload failed. Please choose the file again.');
            if((int)($f['size']??0)>8*1024*1024)throw new RuntimeException('File is too large. Maximum import file size is 8 MB.');
            $name=(string)($f['name']??'');$ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));if(!in_array($ext,['xlsx','csv'],true))throw new RuntimeException('Only .xlsx or .csv files are supported.');
            $matrix=tsSHIParseFile((string)$f['tmp_name'],$name);$rows=tsSHIValidateRows($pdo,$matrix,$supplierId);if(!$rows)throw new RuntimeException('No hotel rows were found in the file.');
            $token=bin2hex(random_bytes(16));$_SESSION['shi_import_'.$token]=['supplier_id'=>$supplierId,'file_name'=>$name,'created_at'=>time(),'rows'=>$rows];
            header('Location: admin-supplier-hotel-import.php?supplier_id='.$supplierId.'&token='.rawurlencode($token));exit;
        }
        if(in_array($action,['revalidate','quick_add_destination','quick_add_location','quick_add_hotel_master','import'],true)){
            $key='shi_import_'.$token;$data=$_SESSION[$key]??null;
            if(!is_array($data))throw new RuntimeException('Import preview expired. Upload the file again.');
            if((int)($data['supplier_id']??0)!==$supplierId)throw new RuntimeException('Supplier changed after preview. Upload the file again.');

            if($action==='revalidate'){
                $data=shiApplyPosted($pdo,$data,$supplierId);$_SESSION[$key]=$data;
                $_SESSION['shi_success']='Corrections saved and revalidated.';
                header('Location: admin-supplier-hotel-import.php?supplier_id='.$supplierId.'&token='.rawurlencode($token));exit;
            }
            if($action==='quick_add_destination'){
                $data=shiApplyPosted($pdo,$data,$supplierId);
                $sourceLabel=trim((string)($_POST['source_label']??''));
                $newName=trim((string)($_POST['quick_name']??$sourceLabel));
                $country=trim((string)($_POST['quick_country']??'India'));
                if($sourceLabel===''||$newName==='')throw new RuntimeException('Destination name is missing.');
                $newId=tsSHIQuickCreateDestination($pdo,$newName,$country!==''?$country:'India');
                foreach($data['rows'] as $i=>$row){
                    if(strcasecmp(shiRowSourceLabel($row),$sourceLabel)===0){$data['rows'][$i]['destination_id']=$newId;$data['rows'][$i]['destination_name']=$newName;}
                    $data['rows'][$i]=tsSHIRevalidatePreparedRow($pdo,$data['rows'][$i],$supplierId,[]);
                }
                $data['updated_at']=time();$_SESSION[$key]=$data;
                shiJson(true,'Destination “'.$newName.'” added and matching rows revalidated.',['reload_url'=>'admin-supplier-hotel-import.php?supplier_id='.$supplierId.'&token='.rawurlencode($token)]);
            }
            if($action==='quick_add_location'){
                $data=shiApplyPosted($pdo,$data,$supplierId);$idx=(int)($_POST['quick_row_index']??-1);
                if(!isset($data['rows'][$idx]))throw new RuntimeException('Preview row was not found.');
                $row=$data['rows'][$idx];$did=(int)($row['destination_id']??0);$city=trim((string)($row['city']??''));
                if($did<=0)throw new RuntimeException('Choose or create the Destination first.');if($city==='')throw new RuntimeException('Enter the City / Location first.');
                if(!function_exists('tsLocationUpsert'))throw new RuntimeException('Location Master is not available.');
                $locationId=tsLocationUpsert($pdo,$did,$city,'supplier_import',$adminId?:null);
                foreach($data['rows'] as $i=>$r)$data['rows'][$i]=tsSHIRevalidatePreparedRow($pdo,$r,$supplierId,[]);
                $data['updated_at']=time();$_SESSION[$key]=$data;
                shiJson(true,'City / Location “'.$city.'” added to Location Master.',['location_id'=>$locationId,'reload_url'=>'admin-supplier-hotel-import.php?supplier_id='.$supplierId.'&token='.rawurlencode($token)]);
            }
            if($action==='quick_add_hotel_master'){
                $data=shiApplyPosted($pdo,$data,$supplierId);$idx=(int)($_POST['quick_row_index']??-1);
                if(!isset($data['rows'][$idx]))throw new RuntimeException('Preview row was not found.');
                $hotelId=tsSHIQuickCreateHotelMaster($pdo,$data['rows'][$idx],$supplierId,$adminId);
                foreach($data['rows'] as $i=>$r)$data['rows'][$i]=tsSHIRevalidatePreparedRow($pdo,$r,$supplierId,[]);
                $data['updated_at']=time();$_SESSION[$key]=$data;
                shiJson(true,'Hotel Master record created/linked.',['hotel_id'=>$hotelId,'reload_url'=>'admin-supplier-hotel-import.php?supplier_id='.$supplierId.'&token='.rawurlencode($token)]);
            }
            if($action==='import'){
                $rows=$data['rows']??[];$counts=shiCounts($rows);
                if($counts['errors']>0)throw new RuntimeException('Fix or exclude all ERROR rows before final import. Nothing was imported.');
                $createMissing=!empty($_POST['create_missing_locations']);$updateDuplicates=!empty($_POST['update_duplicates']);
                if($counts['missing_city']>0&&!$createMissing)throw new RuntimeException($counts['missing_city'].' row(s) still have a city not in Location Master. Use + City or tick Create missing City/Location records.');
                $imported=0;$updated=0;$skippedDuplicate=0;$excluded=0;$failed=0;$failureMessages=[];
                foreach($rows as $r){
                    if(!empty($r['excluded'])){$excluded++;continue;}if(!empty($r['errors']))continue;
                    if(!empty($r['existing_id'])&&!$updateDuplicates){$skippedDuplicate++;continue;}
                    try{
                        $payload=$r;$payload['supplier_id']=$supplierId;$payload['option_id']=$updateDuplicates?(int)($r['existing_id']??0):0;
                        $id=tsSHOSave($pdo,$payload,$adminId);
                        if(($r['status']??'active')==='inactive'&&$id>0){$q=$pdo->prepare("UPDATE supplier_hotel_options SET status='inactive',updated_by_admin_id=?,updated_at=NOW() WHERE id=?");$q->execute([$adminId?:null,$id]);}
                        if(!empty($r['existing_id']))$updated++;else $imported++;
                    }catch(Throwable $rowError){$failed++;if(count($failureMessages)<5)$failureMessages[]='Row '.(int)($r['row_no']??0).': '.$rowError->getMessage();}
                }
                unset($_SESSION[$key]);
                $msg="Bulk import complete: {$imported} new, {$updated} updated, {$skippedDuplicate} duplicate(s) skipped, {$excluded} excluded, {$failed} failed.";
                if($failureMessages)$msg.=' '.implode(' | ',$failureMessages);
                $_SESSION['shi_success']=$msg;header('Location: admin-supplier-hotels.php?supplier_id='.$supplierId);exit;
            }
        }
        throw new RuntimeException('Unknown import action.');
    }catch(Throwable $e){
        if($isAjax)shiJson(false,$e->getMessage());
        $error=$e->getMessage();
    }
}

$preview=shiPreviewData($token);
if($preview&&$supplierId<=0){$supplierId=(int)($preview['supplier_id']??0);$supplier=$supplierId>0?tsSHOSupplier($pdo,$supplierId):null;}
$counts=$preview?shiCounts($preview['rows']??[]):null;
$unknownLabels=[];
if($preview){foreach(($preview['rows']??[]) as $r){if(!empty($r['excluded']))continue;if((int)($r['destination_id']??0)<=0){$label=shiRowSourceLabel($r);if($label!==''){$unknownLabels[$label]=trim((string)($r['source_country']??'India'))?:'India';}}}}
$travCats=['Budget','2 Star','3 Star','4 Star','5 Star','Luxury','Boutique','Resort'];
$previewMode=(bool)$preview;
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Import Supplier Hotels | TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><script>document.documentElement.classList.add('ts-pro-preload');</script><link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260924-v217">
<style>
:root{--line:#dfe7f1;--ink:#123b63;--muted:#6f8297;--blue:#0b74ff;--green:#0b8d61;--amber:#b97800;--red:#b33d3d}.wrap{max-width:1540px;margin:0 auto}.hero{display:flex;justify-content:space-between;gap:18px;align-items:flex-start;margin-bottom:12px}.hero h1{margin:0;color:var(--ink);font-size:25px}.hero p{margin:5px 0 0;color:var(--muted);font-size:10px;line-height:1.55}.actions{display:flex;gap:8px;flex-wrap:wrap}.btnx{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:1px solid var(--line);background:#fff;color:#24557f;text-decoration:none;font-weight:850;font-size:10px;border-radius:9px;padding:8px 10px;cursor:pointer;white-space:nowrap}.btnx.primary{background:var(--blue);color:#fff;border-color:var(--blue)}.btnx.green{background:var(--green);color:#fff;border-color:var(--green)}.btnx.danger{background:#fff4f4;color:#a43636;border-color:#efcccc}.btnx.tiny{font-size:8px;padding:5px 7px;border-radius:7px}.btnx:disabled{opacity:.5;cursor:not-allowed}.card{background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:0 6px 20px rgba(23,57,92,.045);margin-bottom:12px;overflow:hidden}.card-head{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:13px 15px;border-bottom:1px solid #edf2f7}.card-head h2{margin:0;color:#163f67;font-size:15px}.card-head p{margin:3px 0 0;color:var(--muted);font-size:9px}.card-body{padding:14px}.field label{display:block;font-size:8px;font-weight:900;color:#60768d;text-transform:uppercase;letter-spacing:.04em;margin-bottom:5px}.input,select{width:100%;box-sizing:border-box;border:1px solid #dbe5ef;border-radius:7px;background:#fff;color:#193e61;font-size:9px;padding:6px 7px;outline:none}.upload-grid{display:grid;grid-template-columns:1fr 1.3fr auto;gap:10px;align-items:end}.template-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}.template{border:1px solid #dfe7f1;border-radius:12px;padding:12px;background:#fbfdff}.template b{display:block;color:#173f66;font-size:11px}.template p{font-size:8.5px;color:#72849a;line-height:1.5}.notice{border:1px solid #cfe2f7;background:#eef7ff;color:#315e88;padding:12px 14px;border-radius:12px;font-size:10px;line-height:1.55;margin-bottom:12px}.success{background:#ecfaf3;border:1px solid #c7ecd9;color:#11744f;padding:9px 11px;border-radius:9px;font-size:9px}.error{background:#fff1f1;border:1px solid #f1caca;color:#a23a3a;padding:9px 11px;border-radius:9px;font-size:9px}.small{font-size:8px;color:#72849a}.badge{display:inline-flex;padding:3px 6px;border-radius:999px;font-size:7px;font-weight:900;white-space:nowrap}.ok{background:#e9f7f0;color:#087d58}.warn{background:#fff2d9;color:#986000}.bad{background:#fff0f0;color:#a13b3b}.off{background:#edf1f5;color:#6c7d8e}
/* V21.7 embedded rectification workbench: keep TRAVSCOPE sidebar/topbar visible. */
body.shi-preview-mode{background:#f4f8fc!important}
body.ts-pro-admin.shi-preview-mode{overflow:hidden!important}
body.ts-pro-admin.shi-preview-mode .main>.content{height:calc(100vh - var(--ts-topbar));min-height:0!important;overflow:hidden!important;padding:8px 10px 10px!important}
body.ts-pro-admin.shi-preview-mode .main>.content:before{display:none!important}
.shi-workbench{height:100%;min-height:0;display:flex;flex-direction:column;overflow:hidden;border:1px solid #dce6f0;border-radius:11px;background:#f8fbfe;box-shadow:0 6px 18px rgba(24,68,108,.055)}
.shi-bar{flex:0 0 auto;min-height:48px;background:#fff;border-bottom:1px solid #dce6f0;display:flex;align-items:center;gap:8px;padding:6px 8px;z-index:20}
.shi-title{min-width:205px}.shi-title b{display:block;color:#153f67;font-size:12px}.shi-title span{display:block;color:#718499;font-size:7.5px;margin-top:2px;max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.shi-kpis{display:flex;gap:4px;flex:1;min-width:0}.shi-kpi{min-width:54px;border:1px solid #e0e8f0;border-radius:7px;background:#f9fbfd;padding:4px 6px}.shi-kpi span{display:block;font-size:6px;text-transform:uppercase;font-weight:900;color:#78899b}.shi-kpi b{font-size:12px;color:#173f66}.shi-kpi.err b{color:#b13b3b}.shi-kpi.good b{color:#087d58}
.shi-bar-actions{display:flex;gap:5px;align-items:center}.shi-bar-actions .btnx{padding:6px 8px;font-size:8px}
.quickfixes{flex:0 0 auto;background:#fff9e8;border-bottom:1px solid #eed9a5;padding:5px 8px;display:flex;gap:6px;align-items:center;overflow-x:auto;scrollbar-width:thin}.quickfix{display:flex;align-items:center;gap:5px;min-width:max-content;font-size:7.5px;color:#725716}.quickfix select{width:205px;min-width:205px;padding:4px 5px}.quickfix .btnx{padding:5px 6px;font-size:7px}
.shi-message{flex:0 0 auto;margin:5px 8px 0}
.shi-table-shell{flex:1 1 auto;min-height:0;margin:6px 7px 0;border:1px solid #dfe7ef;border-radius:8px;background:#fff;overflow:auto;overscroll-behavior:contain;scrollbar-width:auto;scrollbar-color:#9fb4c8 #edf3f8}
.shi-table-shell::-webkit-scrollbar{width:12px;height:12px}.shi-table-shell::-webkit-scrollbar-track{background:#edf3f8}.shi-table-shell::-webkit-scrollbar-thumb{background:#9fb4c8;border-radius:10px;border:2px solid #edf3f8}.shi-table-shell::-webkit-scrollbar-corner{background:#edf3f8}
.preview-table{border-collapse:collapse;width:max-content;min-width:100%;table-layout:auto}.preview-table th{position:sticky;top:0;z-index:7;background:#eef4fa!important;color:#365d81;font-size:7px!important;text-transform:uppercase;text-align:left;padding:6px 5px;border-bottom:1px solid #d7e2ec;white-space:nowrap}.preview-table td{font-size:8px!important;color:#334f69;padding:4px 5px;border-bottom:1px solid #edf2f7;vertical-align:middle;white-space:nowrap}.preview-table tr.row-error{background:#fff8f8}.preview-table tr.row-excluded{opacity:.5;background:#f4f6f8}.preview-table tr:hover{background:#f8fbff}.preview-table input.input,.preview-table select{height:27px;padding:3px 5px;font-size:8px!important}
.col-inc{width:38px;text-align:center}.col-row{width:34px}.col-status{width:64px}.cell-dest{min-width:175px}.cell-city{min-width:125px}.cell-scat{min-width:120px}.cell-tcat{min-width:105px}.cell-hotel{min-width:185px}.cell-room{min-width:90px}.cell-meal{min-width:68px}.cell-active{min-width:78px}.cell-fix{min-width:220px;max-width:280px;white-space:normal!important}.inline-line{display:flex;gap:4px;align-items:center}.inline-line>*:first-child{flex:1;min-width:0}.source-note{font-size:6.5px;color:#8393a3;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.fixmsg{font-size:7px;line-height:1.25;white-space:normal}.fixmsg.err{color:#ad3e3e}.fixmsg.warn{color:#8a6317}
.shi-bottom{flex:0 0 auto;background:#fff;border-top:1px solid #dce6f0;padding:6px 8px;display:flex;align-items:center;gap:8px}.shi-bottom .check{display:flex;gap:4px;align-items:center;font-size:7.5px;color:#526d86;white-space:nowrap}.shi-bottom .spacer{flex:1}.shi-ready{font-size:7.5px;font-weight:800;white-space:nowrap}.shi-ready.stop{color:#a13b3b}.shi-ready.good{color:#087d58}.shi-bottom .btnx{padding:6px 8px;font-size:8px}
.ajax-toast{position:fixed;right:16px;top:calc(var(--ts-topbar) + 10px);z-index:2147483670;background:#173f66;color:#fff;border-radius:9px;padding:10px 13px;font-size:9px;box-shadow:0 8px 28px rgba(0,0,0,.18);display:none}.ajax-toast.bad{background:#a43b3b}.ajax-toast.show{display:block}
@media(max-width:1200px){.upload-grid,.template-grid{grid-template-columns:1fr}.shi-title{min-width:170px}.shi-kpis{gap:3px}.shi-kpi{min-width:48px}.shi-bar,.shi-bottom{overflow-x:auto}.preview-table{min-width:1360px}}
@media(max-width:820px){body.ts-pro-admin.shi-preview-mode{overflow:auto!important}body.ts-pro-admin.shi-preview-mode .main>.content{height:auto!important;min-height:calc(100vh - 58px)!important;overflow:visible!important;padding:8px!important}.shi-workbench{height:calc(100vh - 78px);min-height:560px}.shi-kpis{display:none}.shi-table-shell{min-height:320px}}
</style></head><body class="<?=$previewMode?'shi-preview-mode':''?>"><main class="main"><div class="content">
<?php if(!$preview):?><div class="wrap">
<div class="hero"><div><h1><i class="fa-solid fa-file-import"></i> Import Supplier Hotel Options</h1><p>Upload Excel/CSV, validate everything first, then import only the corrected rows.</p></div><div class="actions"><a class="btnx" href="admin-supplier-hotels.php<?=$supplierId?'?supplier_id='.$supplierId:''?>"><i class="fa-solid fa-arrow-left"></i> Hotel Options</a><a class="btnx" href="templates/TRAVSCOPE_Supplier_Hotel_Options_Bulk_Import_Template.xlsx" download><i class="fa-solid fa-file-excel"></i> Excel Template</a><a class="btnx" href="templates/TRAVSCOPE_Supplier_Hotel_Options_Bulk_Import_Template.csv" download><i class="fa-solid fa-file-csv"></i> CSV Template</a></div></div>
<div class="notice"><i class="fa-solid fa-circle-info"></i> <b>Safe workflow:</b> Upload → Preview → Correct → Revalidate → Import. Nothing is written until final import.</div>
<?php if($success!==''):?><div class="success" style="margin-bottom:10px"><?=shiE($success)?></div><?php endif;?><?php if($error!==''):?><div class="error" style="margin-bottom:10px"><?=shiE($error)?></div><?php endif;?>
<section class="card"><div class="card-head"><div><h2>Choose supplier and upload file</h2><p>One file is imported into one supplier.</p></div></div><div class="card-body"><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=shiE($csrf)?>"><input type="hidden" name="action" value="preview"><div class="upload-grid"><div class="field"><label>Supplier *</label><select name="supplier_id" required><option value="0">Select supplier…</option><?php foreach($suppliers as $s):?><option value="<?=(int)$s['id']?>" <?=$supplierId===(int)$s['id']?'selected':''?>><?=shiE($s['company_name'])?> · <?=shiE($s['supplier_code']??'')?></option><?php endforeach;?></select></div><div class="field"><label>Excel / CSV file *</label><input class="input" type="file" name="import_file" accept=".xlsx,.csv" required><div class="small">Maximum 8 MB · up to 2,000 hotel rows.</div></div><div><button class="btnx primary" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Upload & Preview</button></div></div></form></div></section>
<section class="card"><div class="card-head"><div><h2>Predefined templates</h2><p>Use the same format every time for reliable bulk import.</p></div></div><div class="card-body"><div class="template-grid"><div class="template"><b><i class="fa-solid fa-file-excel"></i> Excel .xlsx</b><p>Recommended. Includes examples, instructions and dropdown lists.</p><a class="btnx green" href="templates/TRAVSCOPE_Supplier_Hotel_Options_Bulk_Import_Template.xlsx" download>Download Excel</a></div><div class="template"><b><i class="fa-solid fa-file-csv"></i> CSV</b><p>Same import columns in flat-file format.</p><a class="btnx" href="templates/TRAVSCOPE_Supplier_Hotel_Options_Bulk_Import_Template.csv" download>Download CSV</a></div><div class="template"><b><i class="fa-solid fa-shield-check"></i> Preview First</b><p>Unavailable Destination, City or Hotel Master can now be added directly inside the correction screen.</p></div></div></div></section>
</div>
<?php else:?>
<div class="shi-workbench">
<div class="shi-bar">
  <div class="shi-title"><b><i class="fa-solid fa-table-list"></i> Import Rectification Workbench</b><span><?=shiE($supplier['company_name']??'Supplier')?> · <?=shiE($preview['file_name']??'')?> </span></div>
  <div class="shi-kpis"><div class="shi-kpi"><span>Rows</span><b><?=$counts['total']?></b></div><div class="shi-kpi good"><span>Valid</span><b><?=$counts['valid']?></b></div><div class="shi-kpi err"><span>Errors</span><b><?=$counts['errors']?></b></div><div class="shi-kpi"><span>Duplicate</span><b><?=$counts['duplicates']?></b></div><div class="shi-kpi"><span>Missing City</span><b><?=$counts['missing_city']?></b></div><div class="shi-kpi"><span>Excluded</span><b><?=$counts['excluded']?></b></div></div>
  <div class="shi-bar-actions"><a class="btnx" href="admin-supplier-hotel-import.php?supplier_id=<?=$supplierId?>"><i class="fa-solid fa-arrow-left"></i> New File</a><button class="btnx primary" type="button" onclick="document.getElementById('correctionForm').requestSubmit()"><i class="fa-solid fa-arrows-rotate"></i> Save & Revalidate</button><?php if($counts['errors']===0):?><button class="btnx green" type="button" onclick="document.getElementById('finalImportForm').requestSubmit()"><i class="fa-solid fa-file-import"></i> Import Ready</button><?php endif;?></div>
</div>
<?php if($success!==''):?><div class="shi-message success"><?=shiE($success)?></div><?php endif;?><?php if($error!==''):?><div class="shi-message error"><?=shiE($error)?></div><?php endif;?>
<form method="post" id="correctionForm" style="display:contents"><input type="hidden" name="csrf" value="<?=shiE($csrf)?>"><input type="hidden" name="action" value="revalidate"><input type="hidden" name="supplier_id" value="<?=$supplierId?>"><input type="hidden" name="token" value="<?=shiE($token)?>">
<?php if($unknownLabels):?><div class="quickfixes"><b style="font-size:8px;color:#6f5311;white-space:nowrap"><i class="fa-solid fa-wand-magic-sparkles"></i> Missing Destination:</b><?php foreach($unknownLabels as $label=>$country):?><div class="quickfix"><span><?=shiE($label)?></span><input type="hidden" name="map_label[]" value="<?=shiE($label)?>"><select name="map_destination_id[]"><option value="0">Map to existing…</option><?php foreach($destinations as $d):?><option value="<?=(int)$d['id']?>"><?=shiE($d['name'])?><?=trim((string)($d['country']??''))!==''?' · '.shiE($d['country']):''?></option><?php endforeach;?></select><button class="btnx tiny primary" type="button" onclick='shiAddDestination(<?=json_encode($label)?>,<?=json_encode($country)?>)'><i class="fa-solid fa-plus"></i> Add "<?=shiE($label)?>"</button></div><?php endforeach;?></div><?php endif;?>
<div class="shi-table-shell"><table class="preview-table"><thead><tr><th class="col-inc">Use</th><th class="col-row">Row</th><th class="col-status">Status</th><th>Destination</th><th>City</th><th>Supplier Cat.</th><th>TRAVSCOPE</th><th>Hotel</th><th>Room</th><th>Meal</th><th>Active</th><th>Fix / Validation</th></tr></thead><tbody>
<?php foreach(($preview['rows']??[]) as $i=>$r):$bad=!empty($r['errors']);$dup=!empty($r['existing_id']);$excluded=!empty($r['excluded']);$sourceLabel=shiRowSourceLabel($r);$country=trim((string)($r['source_country']??'India'))?:'India';?>
<tr class="<?=$excluded?'row-excluded':($bad?'row-error':'')?>">
<td class="col-inc"><input type="checkbox" name="rows[<?=$i?>][include]" value="1" <?=$excluded?'':'checked'?>></td>
<td class="col-row"><?=intval($r['row_no'])?></td>
<td class="col-status"><?php if($excluded):?><span class="badge off">EXCLUDED</span><?php elseif($bad):?><span class="badge bad">ERROR</span><?php elseif($dup):?><span class="badge warn">DUPLICATE</span><?php elseif(!empty($r['warnings'])):?><span class="badge warn">CHECK</span><?php else:?><span class="badge ok">VALID</span><?php endif;?></td>
<td class="cell-dest"><div class="inline-line"><select name="rows[<?=$i?>][destination_id]"><option value="0">Select…</option><?php foreach($destinations as $d):?><option value="<?=(int)$d['id']?>" <?=(int)($r['destination_id']??0)===(int)$d['id']?'selected':''?>><?=shiE($d['name'])?><?=trim((string)($d['country']??''))!==''?' · '.shiE($d['country']):''?></option><?php endforeach;?></select><?php if((int)($r['destination_id']??0)<=0&&$sourceLabel!==''):?><button class="btnx tiny primary" type="button" title="Add this Destination directly" onclick='shiAddDestination(<?=json_encode($sourceLabel)?>,<?=json_encode($country)?>)'><i class="fa-solid fa-plus"></i></button><?php endif;?></div><?php if($sourceLabel!==''&&strcasecmp($sourceLabel,(string)($r['destination_name']??''))!==0):?><div class="source-note">Excel: <?=shiE($sourceLabel)?></div><?php endif;?></td>
<td class="cell-city"><div class="inline-line"><input class="input" name="rows[<?=$i?>][city]" value="<?=shiE($r['city']??'')?>"><?php if((int)($r['location_id']??0)<=0&&trim((string)($r['city']??''))!==''):?><button class="btnx tiny" type="button" title="Add City/Location directly" onclick="shiQuickRow('quick_add_location',<?=$i?>)"><i class="fa-solid fa-plus"></i></button><?php endif;?></div></td>
<td class="cell-scat"><input class="input" name="rows[<?=$i?>][supplier_category]" value="<?=shiE($r['supplier_category']??'')?>"></td>
<td class="cell-tcat"><select name="rows[<?=$i?>][travscope_category]"><?php foreach($travCats as $cat):?><option value="<?=shiE($cat)?>" <?=strcasecmp((string)($r['travscope_category']??''),$cat)===0?'selected':''?>><?=shiE($cat)?></option><?php endforeach;?></select></td>
<td class="cell-hotel"><div class="inline-line"><input class="input" name="rows[<?=$i?>][hotel_name]" value="<?=shiE($r['hotel_name']??'')?>"><?php if(empty($r['hotel_id'])&&in_array((int)($r['mapped_star_category']??0),[3,4,5],true)):?><button class="btnx tiny" type="button" title="Create/link basic Hotel Master record" onclick="shiQuickRow('quick_add_hotel_master',<?=$i?>)"><i class="fa-solid fa-hotel"></i>+</button><?php endif;?></div><?php if(!empty($r['hotel_id'])):?><div class="source-note" style="color:#087d58">Hotel Master #<?=intval($r['hotel_id'])?> linked</div><?php else:?><div class="source-note">Supplier-only until linked</div><?php endif;?></td>
<td class="cell-room"><input class="input" name="rows[<?=$i?>][room_type]" value="<?=shiE($r['room_type']??'')?>"></td>
<td class="cell-meal"><input class="input" name="rows[<?=$i?>][meal_plan]" value="<?=shiE($r['meal_plan']??'')?>"></td>
<td class="cell-active"><select name="rows[<?=$i?>][status]"><option value="active" <?=($r['status']??'active')==='active'?'selected':''?>>Active</option><option value="inactive" <?=($r['status']??'')==='inactive'?'selected':''?>>Inactive</option></select></td>
<td class="cell-fix"><?php if($excluded):?><span class="fixmsg">Excluded</span><?php else:?><?php foreach(($r['errors']??[]) as $m):?><div class="fixmsg err"><i class="fa-solid fa-circle-xmark"></i> <?=shiE($m)?></div><?php endforeach;?><?php foreach(($r['warnings']??[]) as $m):?><div class="fixmsg warn"><i class="fa-solid fa-triangle-exclamation"></i> <?=shiE($m)?></div><?php endforeach;?><?php if(empty($r['errors'])&&empty($r['warnings'])):?><span class="fixmsg" style="color:#087d58">Ready</span><?php endif;?><?php endif;?></td>
</tr><?php endforeach;?>
</tbody></table></div>
</form>
<form method="post" id="finalImportForm" class="shi-bottom"><input type="hidden" name="csrf" value="<?=shiE($csrf)?>"><input type="hidden" name="action" value="import"><input type="hidden" name="supplier_id" value="<?=$supplierId?>"><input type="hidden" name="token" value="<?=shiE($token)?>"><label class="check"><input type="checkbox" name="create_missing_locations" value="1" <?=$counts['missing_city']>0?'checked':''?>> Create any remaining missing cities</label><label class="check"><input type="checkbox" name="update_duplicates" value="1"> Update duplicates</label><span class="spacer"></span><?php if($counts['errors']>0):?><span class="shi-ready stop"><i class="fa-solid fa-lock"></i> <?=$counts['errors']?> error row(s) must be fixed or excluded.</span><?php else:?><span class="shi-ready good"><i class="fa-solid fa-circle-check"></i> Ready for import.</span><?php endif;?><button class="btnx primary" type="button" onclick="document.getElementById('correctionForm').requestSubmit()"><i class="fa-solid fa-floppy-disk"></i> Save & Revalidate</button><button class="btnx green" type="submit" <?=$counts['errors']>0?'disabled':''?> onclick="return confirm('Import the corrected supplier hotel rows now?');"><i class="fa-solid fa-file-import"></i> Import <?=$counts['valid']?> Ready</button></form>
</div>
<?php endif;?>
<div id="shiToast" class="ajax-toast"></div></div></main>
<script>
function shiToast(message,bad){const el=document.getElementById('shiToast');if(!el)return;el.textContent=message;el.className='ajax-toast show'+(bad?' bad':'');clearTimeout(window._shiToastTimer);window._shiToastTimer=setTimeout(()=>{el.className='ajax-toast';},3500);}
async function shiAjax(action,extra){const form=document.getElementById('correctionForm');if(!form)return;const fd=new FormData(form);fd.set('action',action);fd.set('ajax','1');Object.entries(extra||{}).forEach(([k,v])=>fd.set(k,String(v)));shiToast('Saving current edits…',false);try{const res=await fetch(location.href,{method:'POST',body:fd,headers:{'X-Requested-With':'XMLHttpRequest'}});const data=await res.json();if(!data.ok)throw new Error(data.message||'Action failed');shiToast(data.message||'Saved',false);setTimeout(()=>{location.href=data.reload_url||location.href;},450);}catch(e){shiToast(e.message||'Action failed',true);}}
function shiAddDestination(label,country){if(!label)return;const name=prompt('Create Destination Master record:',label);if(name===null||name.trim()==='')return;shiAjax('quick_add_destination',{source_label:label,quick_name:name.trim(),quick_country:country||'India'});}
function shiQuickRow(action,index){shiAjax(action,{quick_row_index:index});}
</script><script src="assets/travscope-pro-admin.js?v=20260924-v217" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script></body></html>
