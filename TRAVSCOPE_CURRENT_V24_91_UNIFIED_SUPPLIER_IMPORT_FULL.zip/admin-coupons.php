<?php
/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM - ADMIN COUPONS
|--------------------------------------------------------------------------
| PHP 7.4 compatible
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';

requireAdmin();

$admin = currentAdmin($pdo);

if (!$admin) {
    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_mobile'],
        $_SESSION['admin_role']
    );
    redirect(BASE_URL . 'login.php');
}

$siteName = 'TRAVSCOPE.COM';
$currencySymbol = '₹';

try {
    $siteName = getSetting($pdo, 'site_name', 'TRAVSCOPE.COM');
    $currencySymbol = getSetting($pdo, 'currency_symbol', '₹');
} catch (Throwable $e) {
    error_log('Coupon settings error: ' . $e->getMessage());
}

$success = '';
$error = '';

if (!empty($_SESSION['admin_coupon_success'])) {
    $success = (string)$_SESSION['admin_coupon_success'];
    unset($_SESSION['admin_coupon_success']);
}

if (!empty($_SESSION['admin_coupon_error'])) {
    $error = (string)$_SESSION['admin_coupon_error'];
    unset($_SESSION['admin_coupon_error']);
}

function couponRedirect($statusFilter, $search)
{
    $url = BASE_URL . 'admin-coupons.php';
    $params = array();

    if ($statusFilter !== '' && $statusFilter !== 'all') {
        $params['status'] = $statusFilter;
    }

    if ($search !== '') {
        $params['search'] = $search;
    }

    if ($params) {
        $url .= '?' . http_build_query($params);
    }

    redirect($url);
}

function couponDateTime($value)
{
    $value = trim((string)$value);

    if ($value === '') {
        return null;
    }

    $time = strtotime($value);

    if ($time === false) {
        return false;
    }

    return date('Y-m-d H:i:s', $time);
}

function couponState($coupon)
{
    if ((string)$coupon['status'] === 'inactive') {
        return array('Inactive', 'inactive');
    }

    $now = time();

    if (!empty($coupon['expiry_date']) && strtotime($coupon['expiry_date']) <= $now) {
        return array('Expired', 'expired');
    }

    if (!empty($coupon['start_date']) && strtotime($coupon['start_date']) > $now) {
        return array('Scheduled', 'scheduled');
    }

    if (
        $coupon['usage_limit'] !== null &&
        (int)$coupon['used_count'] >= (int)$coupon['usage_limit']
    ) {
        return array('Limit Reached', 'limit');
    }

    return array('Active', 'active');
}

/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $csrf = $_POST['csrf_token'] ?? '';
    $action = strtolower(trim((string)($_POST['action'] ?? '')));
    $returnStatus = strtolower(trim((string)($_POST['return_status'] ?? 'all')));
    $returnSearch = trim((string)($_POST['return_search'] ?? ''));

    if (!verifyCsrf($csrf)) {
        $_SESSION['admin_coupon_error'] = 'Security validation failed. Please try again.';
        couponRedirect($returnStatus, $returnSearch);
    }

    try {

        if ($action === 'save') {

            $couponId = (int)($_POST['coupon_id'] ?? 0);
            $codeValue = strtoupper(trim((string)($_POST['code'] ?? '')));
            $description = trim((string)($_POST['description'] ?? ''));
            $discountType = strtolower(trim((string)($_POST['discount_type'] ?? 'percentage')));
            $discountValue = (float)($_POST['discount_value'] ?? 0);
            $minimumAmount = (float)($_POST['minimum_amount'] ?? 0);

            $maxRaw = trim((string)($_POST['maximum_discount'] ?? ''));
            $maximumDiscount = $maxRaw === '' ? null : (float)$maxRaw;

            $limitRaw = trim((string)($_POST['usage_limit'] ?? ''));
            $usageLimit = $limitRaw === '' ? null : (int)$limitRaw;

            $startDate = couponDateTime($_POST['start_date'] ?? '');
            $expiryDate = couponDateTime($_POST['expiry_date'] ?? '');
            $status = strtolower(trim((string)($_POST['status'] ?? 'active')));

            if ($codeValue === '') {
                throw new RuntimeException('Coupon code is required.');
            }

            if (!preg_match('/^[A-Z0-9_-]{2,50}$/', $codeValue)) {
                throw new RuntimeException(
                    'Coupon code can contain only letters, numbers, hyphens and underscores.'
                );
            }

            if (!in_array($discountType, array('percentage', 'fixed'), true)) {
                throw new RuntimeException('Invalid discount type.');
            }

            if ($discountValue <= 0) {
                throw new RuntimeException('Discount value must be greater than zero.');
            }

            if ($discountType === 'percentage' && $discountValue > 100) {
                throw new RuntimeException('Percentage discount cannot exceed 100%.');
            }

            if ($minimumAmount < 0) {
                throw new RuntimeException('Minimum booking amount cannot be negative.');
            }

            if ($maximumDiscount !== null && $maximumDiscount <= 0) {
                throw new RuntimeException(
                    'Maximum discount must be greater than zero or left blank.'
                );
            }

            if ($usageLimit !== null && $usageLimit <= 0) {
                throw new RuntimeException(
                    'Usage limit must be greater than zero or left blank.'
                );
            }

            if ($startDate === false || $expiryDate === false) {
                throw new RuntimeException('Invalid coupon date.');
            }

            if (
                $startDate !== null &&
                $expiryDate !== null &&
                strtotime($expiryDate) <= strtotime($startDate)
            ) {
                throw new RuntimeException('Expiry date must be after the start date.');
            }

            if (!in_array($status, array('active', 'inactive'), true)) {
                $status = 'active';
            }

            if ($discountType === 'fixed') {
                $maximumDiscount = null;
            }

            $stmt = $pdo->prepare("
                SELECT id
                FROM coupons
                WHERE code = ?
                  AND id <> ?
                LIMIT 1
            ");
            $stmt->execute(array($codeValue, $couponId));

            if ($stmt->fetch()) {
                throw new RuntimeException('This coupon code already exists.');
            }

            if ($couponId > 0) {

                $stmt = $pdo->prepare("
                    SELECT id, used_count
                    FROM coupons
                    WHERE id = ?
                    LIMIT 1
                ");
                $stmt->execute(array($couponId));
                $existing = $stmt->fetch();

                if (!$existing) {
                    throw new RuntimeException('Coupon not found.');
                }

                if (
                    $usageLimit !== null &&
                    $usageLimit < (int)$existing['used_count']
                ) {
                    throw new RuntimeException(
                        'Usage limit cannot be less than the current used count.'
                    );
                }

                $stmt = $pdo->prepare("
                    UPDATE coupons
                    SET
                        code = ?,
                        description = ?,
                        discount_type = ?,
                        discount_value = ?,
                        minimum_amount = ?,
                        maximum_discount = ?,
                        usage_limit = ?,
                        start_date = ?,
                        expiry_date = ?,
                        status = ?
                    WHERE id = ?
                ");

                $stmt->execute(array(
                    $codeValue,
                    $description !== '' ? $description : null,
                    $discountType,
                    $discountValue,
                    $minimumAmount,
                    $maximumDiscount,
                    $usageLimit,
                    $startDate,
                    $expiryDate,
                    $status,
                    $couponId
                ));

                $_SESSION['admin_coupon_success'] =
                    'Coupon ' . $codeValue . ' updated successfully.';

            } else {

                $stmt = $pdo->prepare("
                    INSERT INTO coupons
                    (
                        code,
                        description,
                        discount_type,
                        discount_value,
                        minimum_amount,
                        maximum_discount,
                        usage_limit,
                        used_count,
                        start_date,
                        expiry_date,
                        status
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?)
                ");

                $stmt->execute(array(
                    $codeValue,
                    $description !== '' ? $description : null,
                    $discountType,
                    $discountValue,
                    $minimumAmount,
                    $maximumDiscount,
                    $usageLimit,
                    $startDate,
                    $expiryDate,
                    $status
                ));

                $_SESSION['admin_coupon_success'] =
                    'Coupon ' . $codeValue . ' created successfully.';
            }

            couponRedirect($returnStatus, $returnSearch);
        }

        if ($action === 'toggle_status') {

            $couponId = (int)($_POST['coupon_id'] ?? 0);

            if ($couponId <= 0) {
                throw new RuntimeException('Invalid coupon.');
            }

            $stmt = $pdo->prepare("
                UPDATE coupons
                SET status =
                    CASE
                        WHEN status = 'active' THEN 'inactive'
                        ELSE 'active'
                    END
                WHERE id = ?
            ");
            $stmt->execute(array($couponId));

            if ($stmt->rowCount() !== 1) {
                throw new RuntimeException('Coupon status could not be changed.');
            }

            $_SESSION['admin_coupon_success'] = 'Coupon status updated successfully.';
            couponRedirect($returnStatus, $returnSearch);
        }

        if ($action === 'delete') {

            $couponId = (int)($_POST['coupon_id'] ?? 0);

            if ($couponId <= 0) {
                throw new RuntimeException('Invalid coupon.');
            }

            $stmt = $pdo->prepare("
                SELECT code, used_count
                FROM coupons
                WHERE id = ?
                LIMIT 1
            ");
            $stmt->execute(array($couponId));
            $coupon = $stmt->fetch();

            if (!$coupon) {
                throw new RuntimeException('Coupon not found.');
            }

            if ((int)$coupon['used_count'] > 0) {
                throw new RuntimeException(
                    'A used coupon cannot be deleted. Disable it instead.'
                );
            }

            $stmt = $pdo->prepare("
                DELETE FROM coupons
                WHERE id = ?
                  AND used_count = 0
            ");
            $stmt->execute(array($couponId));

            if ($stmt->rowCount() !== 1) {
                throw new RuntimeException('Coupon could not be deleted.');
            }

            $_SESSION['admin_coupon_success'] =
                'Coupon ' . $coupon['code'] . ' deleted successfully.';

            couponRedirect($returnStatus, $returnSearch);
        }

        throw new RuntimeException('Invalid coupon action.');

    } catch (Throwable $e) {
        error_log('Admin coupon error: ' . $e->getMessage());
        $_SESSION['admin_coupon_error'] = $e->getMessage();
        couponRedirect($returnStatus, $returnSearch);
    }
}

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

$statusFilter = strtolower(trim((string)($_GET['status'] ?? 'all')));
$allowedFilters = array(
    'all',
    'active',
    'inactive',
    'expired',
    'scheduled',
    'limit_reached'
);

if (!in_array($statusFilter, $allowedFilters, true)) {
    $statusFilter = 'all';
}

$search = trim((string)($_GET['search'] ?? ''));

/*
|--------------------------------------------------------------------------
| EDIT DATA
|--------------------------------------------------------------------------
*/

$editCoupon = null;
$editId = (int)($_GET['edit'] ?? 0);

if ($editId > 0) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM coupons WHERE id = ? LIMIT 1");
        $stmt->execute(array($editId));
        $editCoupon = $stmt->fetch();
    } catch (Throwable $e) {
        error_log('Coupon edit error: ' . $e->getMessage());
    }
}

/*
|--------------------------------------------------------------------------
| STATISTICS
|--------------------------------------------------------------------------
*/

$counts = array(
    'all' => 0,
    'active' => 0,
    'inactive' => 0,
    'expired' => 0,
    'scheduled' => 0,
    'limit_reached' => 0
);

$totalUses = 0;

try {
    $counts['all'] = (int)$pdo->query("SELECT COUNT(*) FROM coupons")->fetchColumn();

    $counts['active'] = (int)$pdo->query("
        SELECT COUNT(*)
        FROM coupons
        WHERE status = 'active'
          AND (start_date IS NULL OR start_date <= NOW())
          AND (expiry_date IS NULL OR expiry_date > NOW())
          AND (usage_limit IS NULL OR used_count < usage_limit)
    ")->fetchColumn();

    $counts['inactive'] = (int)$pdo->query("
        SELECT COUNT(*) FROM coupons WHERE status = 'inactive'
    ")->fetchColumn();

    $counts['expired'] = (int)$pdo->query("
        SELECT COUNT(*)
        FROM coupons
        WHERE expiry_date IS NOT NULL
          AND expiry_date <= NOW()
    ")->fetchColumn();

    $counts['scheduled'] = (int)$pdo->query("
        SELECT COUNT(*)
        FROM coupons
        WHERE status = 'active'
          AND start_date IS NOT NULL
          AND start_date > NOW()
    ")->fetchColumn();

    $counts['limit_reached'] = (int)$pdo->query("
        SELECT COUNT(*)
        FROM coupons
        WHERE usage_limit IS NOT NULL
          AND used_count >= usage_limit
    ")->fetchColumn();

    $totalUses = (int)$pdo->query("
        SELECT COALESCE(SUM(used_count), 0) FROM coupons
    ")->fetchColumn();

} catch (Throwable $e) {
    error_log('Coupon statistics error: ' . $e->getMessage());
}

/*
|--------------------------------------------------------------------------
| COUPON LIST
|--------------------------------------------------------------------------
*/

$coupons = array();

try {
    $where = array();
    $params = array();

    if ($statusFilter === 'active') {
        $where[] = "
            c.status = 'active'
            AND (c.start_date IS NULL OR c.start_date <= NOW())
            AND (c.expiry_date IS NULL OR c.expiry_date > NOW())
            AND (c.usage_limit IS NULL OR c.used_count < c.usage_limit)
        ";
    } elseif ($statusFilter === 'inactive') {
        $where[] = "c.status = 'inactive'";
    } elseif ($statusFilter === 'expired') {
        $where[] = "c.expiry_date IS NOT NULL AND c.expiry_date <= NOW()";
    } elseif ($statusFilter === 'scheduled') {
        $where[] = "
            c.status = 'active'
            AND c.start_date IS NOT NULL
            AND c.start_date > NOW()
        ";
    } elseif ($statusFilter === 'limit_reached') {
        $where[] = "
            c.usage_limit IS NOT NULL
            AND c.used_count >= c.usage_limit
        ";
    }

    if ($search !== '') {
        $where[] = "(c.code LIKE ? OR c.description LIKE ?)";
        $term = '%' . $search . '%';
        $params[] = $term;
        $params[] = $term;
    }

    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $stmt = $pdo->prepare("
        SELECT c.*
        FROM coupons c
        {$whereSql}
        ORDER BY c.id DESC
        LIMIT 500
    ");
    $stmt->execute($params);
    $coupons = $stmt->fetchAll();

} catch (Throwable $e) {
    $error = 'Coupons could not be loaded.';
    error_log('Coupon list error: ' . $e->getMessage());
}

$adminName = trim((string)($admin['name'] ?? 'Admin'));

if ($adminName === '') {
    $adminName = 'Admin';
}

$adminInitial = strtoupper(substr($adminName, 0, 1));
$csrfToken = csrfToken();

$form = array(
    'id' => $editCoupon ? (int)$editCoupon['id'] : 0,
    'code' => $editCoupon ? $editCoupon['code'] : '',
    'description' => $editCoupon ? $editCoupon['description'] : '',
    'discount_type' => $editCoupon ? $editCoupon['discount_type'] : 'percentage',
    'discount_value' => $editCoupon ? $editCoupon['discount_value'] : '',
    'minimum_amount' => $editCoupon ? $editCoupon['minimum_amount'] : '0.00',
    'maximum_discount' => $editCoupon ? $editCoupon['maximum_discount'] : '',
    'usage_limit' => $editCoupon ? $editCoupon['usage_limit'] : '',
    'start_date' => (
        $editCoupon && !empty($editCoupon['start_date'])
        ? date('Y-m-d\TH:i', strtotime($editCoupon['start_date']))
        : ''
    ),
    'expiry_date' => (
        $editCoupon && !empty($editCoupon['expiry_date'])
        ? date('Y-m-d\TH:i', strtotime($editCoupon['expiry_date']))
        : ''
    ),
    'status' => $editCoupon ? $editCoupon['status'] : 'active'
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex,nofollow">
<title>Coupons | <?= e($siteName); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
:root{--nav:#07192d;--blue:#0b74ff;--bg:#f5f7fb;--text:#172033;--muted:#778294;--border:#e6eaf0;--green:#0da66a;--red:#e24a5c;--orange:#e88b22;--shadow:0 8px 30px rgba(23,32,51,.06)}
*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:var(--bg);color:var(--text)}a{text-decoration:none;color:inherit}button,input,select,textarea{font:inherit}
.sidebar{position:fixed;inset:0 auto 0 0;width:265px;background:var(--nav);color:#fff;z-index:1000;overflow:auto;transition:.25s}
.logo{height:80px;padding:0 22px;display:flex;align-items:center;gap:10px;font-size:20px;font-weight:800;border-bottom:1px solid rgba(255,255,255,.08)}.logo i{width:42px;height:42px;border-radius:12px;background:var(--blue);display:grid;place-items:center}.logo span{color:#63b4ff}
.menu{padding:18px 13px}.menu-title{padding:15px 13px 7px;color:#647990;font-size:10px;font-weight:800}.menu a{min-height:44px;padding:0 13px;margin:3px 0;border-radius:9px;display:flex;align-items:center;gap:11px;color:#9fb0c2;font-size:13px;font-weight:600}.menu a:hover,.menu a.active{color:#fff;background:#0b74ff}.menu i{width:19px;text-align:center}
.main{margin-left:265px;min-height:100vh}.topbar{height:80px;padding:0 30px;background:#fff;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:800}.top-left,.admin{display:flex;align-items:center;gap:10px}.hamburger{display:none;width:38px;height:38px;border:1px solid var(--border);border-radius:8px;background:#fff}.avatar{width:38px;height:38px;border-radius:10px;background:var(--blue);color:#fff;display:grid;place-items:center;font-weight:800}.admin small{display:block;color:var(--muted);margin-top:3px}
.content{padding:30px;max-width:1550px;margin:auto}.heading{margin-bottom:22px}.heading h1{margin:0;font-size:28px}.heading p{color:var(--muted);font-size:11px}
.alert{margin-bottom:18px;padding:13px;border-radius:9px;font-size:11px}.success{background:#edfaf5;color:#087a50;border:1px solid #bfe9d7}.error{background:#fff0f2;color:#b22e41;border:1px solid #f0c3c9}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px}.stat,.card{background:#fff;border:1px solid var(--border);border-radius:12px;box-shadow:var(--shadow)}.stat{padding:18px}.stat label{color:var(--muted);font-size:9px;font-weight:800}.stat strong{display:block;margin-top:7px;font-size:22px}
.layout{display:grid;grid-template-columns:minmax(330px,.7fr) minmax(0,1.5fr);gap:20px;align-items:start}.card-head{padding:16px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}.card-head h2{margin:0;font-size:14px}.card-body{padding:18px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:13px}.field.full{grid-column:1/-1}.field label{display:block;margin-bottom:6px;color:#5d697b;font-size:9px;font-weight:800}.control{width:100%;min-height:40px;border:1px solid var(--border);border-radius:8px;padding:0 10px;background:#fff}.field textarea{min-height:78px;padding:10px;resize:vertical}.help{margin-top:5px;color:#929baa;font-size:8px;line-height:1.5}.form-actions{margin-top:15px;display:flex;gap:8px}.btn{min-height:38px;padding:0 13px;border:1px solid var(--border);border-radius:8px;background:#fff;display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-size:10px;font-weight:800}.btn-primary{background:var(--blue);border-color:var(--blue);color:#fff}
.filters{padding:14px;display:flex;gap:6px;flex-wrap:wrap;border-bottom:1px solid var(--border)}.filter{padding:8px 9px;border:1px solid var(--border);border-radius:7px;color:#667085;font-size:9px;font-weight:700}.filter.active{background:#edf5ff;border-color:var(--blue);color:var(--blue)}.search{padding:0 14px 14px;display:flex;gap:6px}.search input{flex:1;height:35px;border:1px solid var(--border);border-radius:7px;padding:0 10px}.search button{width:38px;border:0;border-radius:7px;background:var(--blue);color:#fff}
.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;min-width:980px}th{background:#f9fafc;color:#7d8999;font-size:8px;text-align:left;padding:11px 12px}td{border-top:1px solid #edf0f3;padding:13px 12px;font-size:10px;vertical-align:middle}.code{color:var(--blue);font-weight:800;font-size:12px}.sub{margin-top:3px;color:var(--muted);font-size:8px}.badge{padding:6px 9px;border-radius:20px;font-size:8px;font-weight:800;text-transform:uppercase;display:inline-flex}.badge-active{background:#e9f9f2;color:#078454}.badge-inactive{background:#eef1f5;color:#667085}.badge-expired{background:#ffedef;color:#c63248}.badge-scheduled{background:#f0edff;color:#6848c7}.badge-limit{background:#fff4e4;color:#b66b08}
.actions{display:flex;gap:5px;flex-wrap:wrap}.action{min-height:29px;padding:0 8px;border:0;border-radius:6px;display:inline-flex;align-items:center;gap:5px;font-size:8px;font-weight:800;cursor:pointer}.edit{background:#edf5ff;color:#0b74ff}.toggle{background:#fff4e4;color:#b66b08}.delete{background:#ffedef;color:#c63248}.inline{display:inline}.empty{padding:50px 20px;text-align:center;color:var(--muted)}
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:900;display:none}.overlay.show{display:block}
@media(max-width:1150px){.stats{grid-template-columns:1fr 1fr}.layout{grid-template-columns:1fr}}
@media(max-width:850px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:none}.main{margin-left:0}.hamburger{display:block}.content{padding:20px}}
@media(max-width:600px){.topbar{height:68px;padding:0 12px}.admin div:last-child{display:none}.content{padding:15px 11px}.stats,.grid{grid-template-columns:1fr}.field.full{grid-column:auto}.heading h1{font-size:23px}}


/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
}
.main > .content,
.main .content:first-child{
    width:auto!important;
    max-width:none!important;
    margin:0!important;
    padding:16px 18px 20px!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">

<style>
/* TRAVSCOPE V24.75 — International Marketing / Coupons */
.mk-page-head{display:flex;align-items:center;justify-content:space-between;gap:22px;padding:18px 20px;margin-bottom:14px;background:#fff;border:1px solid #dce6f1;border-radius:16px;box-shadow:0 8px 24px rgba(15,23,42,.045);border-left:4px solid #2563eb}
.mk-title-block h1{margin:3px 0 4px;font-size:26px;line-height:1.05;color:#0f172a}.mk-title-block p{margin:0;color:#64748b;font-size:11px}.mk-eyebrow{font-size:9px;letter-spacing:.12em;font-weight:900;color:#2563eb}
.mk-head-right{display:flex;align-items:center;gap:10px}.mk-kpi-row{display:flex;gap:7px;flex-wrap:wrap;justify-content:flex-end}.mk-kpi{min-width:104px;padding:9px 11px;border:1px solid #e2e8f0;border-radius:11px;background:#fbfdff;border-left:3px solid #2563eb}.mk-kpi span{display:block;font-size:7px;text-transform:uppercase;letter-spacing:.06em;color:#64748b;font-weight:900}.mk-kpi strong{display:block;margin-top:3px;font-size:16px;color:#0f172a}.mk-kpi.mk-green{border-left-color:#10b981}.mk-kpi.mk-amber{border-left-color:#f59e0b}.mk-kpi.mk-violet{border-left-color:#8b5cf6}
.mk-primary-action{height:40px;padding:0 14px;border:0;border-radius:9px;background:#2563eb;color:#fff;font-size:10px;font-weight:900;white-space:nowrap;box-shadow:0 7px 18px rgba(37,99,235,.18);cursor:pointer}
.stats{display:none!important}.mk-coupon-layout{display:block!important}.coupon-editor-card{display:none;margin-bottom:14px}.coupon-editor-card.is-open{display:block}.coupon-editor-card .card-head{background:#f8fbff}.coupon-editor-card .card-body{padding:14px 16px}.coupon-editor-card .grid{grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.coupon-editor-card .field.full{grid-column:span 2}.coupon-editor-card .field textarea{min-height:58px}.coupon-directory-card{overflow:hidden}.mk-directory-head{padding:14px 16px 8px;display:flex;justify-content:space-between;align-items:end}.mk-directory-head h2{margin:2px 0;font-size:15px}.mk-directory-head p{margin:0;color:#64748b;font-size:9px}.coupon-directory-card .filters{padding:8px 12px;border-top:1px solid #eef2f7}.coupon-directory-card .search{padding:0 12px 10px}.coupon-directory-card th{background:#edf4fb;color:#516176}.coupon-directory-card td{padding-top:10px;padding-bottom:10px}
@media(max-width:1200px){.mk-page-head{align-items:flex-start;flex-direction:column}.mk-head-right{width:100%;justify-content:space-between}.coupon-editor-card .grid{grid-template-columns:1fr 1fr}}
@media(max-width:700px){.mk-head-right{flex-direction:column;align-items:stretch}.mk-kpi-row{justify-content:flex-start}.mk-kpi{flex:1;min-width:120px}.coupon-editor-card .grid{grid-template-columns:1fr}.coupon-editor-card .field.full{grid-column:auto}}
</style>
</head>
<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->






<div class="overlay" id="overlay"></div>

<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->



<main class="main">

<header class="topbar">
    <div class="top-left">
        
        <strong>TRAVSCOPE Administration</strong>
    </div>

    <div class="admin">
        <div class="avatar"><?= e($adminInitial); ?></div>
        <div>
            <strong><?= e($adminName); ?></strong>
            <small><?= e(ucwords(str_replace('_', ' ', (string)($admin['role'] ?? 'admin')))); ?></small>
        </div>
    </div>
</header>

<div class="content">

    <section class="mk-page-head">
        <div class="mk-title-block">
            <div class="mk-eyebrow">MARKETING / PROMOTIONS</div>
            <h1>Coupon Management</h1>
            <p>Create, schedule and control promotional booking discounts from one workspace.</p>
        </div>
        <div class="mk-head-right">
            <div class="mk-kpi-row">
                <div class="mk-kpi mk-blue"><span>Total Coupons</span><strong><?= number_format($counts['all']); ?></strong></div>
                <div class="mk-kpi mk-green"><span>Available Now</span><strong><?= number_format($counts['active']); ?></strong></div>
                <div class="mk-kpi mk-amber"><span>Total Uses</span><strong><?= number_format($totalUses); ?></strong></div>
                <div class="mk-kpi mk-violet"><span>Expired</span><strong><?= number_format($counts['expired']); ?></strong></div>
            </div>
            <button type="button" class="mk-primary-action" id="couponEditorToggle">
                <i class="fa-solid fa-plus"></i>
                <?= $editCoupon ? 'Edit Coupon' : 'Create Coupon'; ?>
            </button>
        </div>
    </section>

    <?php if ($success !== ''): ?>
        <div class="alert success">
            <i class="fa-solid fa-circle-check"></i>
            <?= e($success); ?>
        </div>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
        <div class="alert error">
            <i class="fa-solid fa-triangle-exclamation"></i>
            <?= e($error); ?>
        </div>
    <?php endif; ?>

    <div class="stats">
        <div class="stat">
            <label>TOTAL COUPONS</label>
            <strong><?= number_format($counts['all']); ?></strong>
        </div>
        <div class="stat">
            <label>AVAILABLE NOW</label>
            <strong><?= number_format($counts['active']); ?></strong>
        </div>
        <div class="stat">
            <label>TOTAL USES</label>
            <strong><?= number_format($totalUses); ?></strong>
        </div>
        <div class="stat">
            <label>EXPIRED</label>
            <strong><?= number_format($counts['expired']); ?></strong>
        </div>
    </div>

    <div class="layout mk-coupon-layout">

        <section class="card coupon-editor-card<?= $editCoupon ? ' is-open' : ''; ?>">
            <div class="card-head">
                <h2><?= $editCoupon ? 'Edit Coupon' : 'Create Coupon'; ?></h2>

                <?php if ($editCoupon): ?>
                    <a href="admin-coupons.php" class="btn">Cancel</a>
                <?php endif; ?>
            </div>

            <div class="card-body">
                <form method="post">

                    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="coupon_id" value="<?= (int)$form['id']; ?>">
                    <input type="hidden" name="return_status" value="<?= e($statusFilter); ?>">
                    <input type="hidden" name="return_search" value="<?= e($search); ?>">

                    <div class="grid">

                        <div class="field full">
                            <label>COUPON CODE *</label>
                            <input
                                class="control"
                                type="text"
                                name="code"
                                maxlength="50"
                                required
                                value="<?= e((string)$form['code']); ?>"
                                placeholder="SUMMER20"
                                style="text-transform:uppercase"
                            >
                        </div>

                        <div class="field full">
                            <label>DESCRIPTION</label>
                            <textarea
                                class="control"
                                name="description"
                                maxlength="255"
                                placeholder="Optional coupon description"
                            ><?= e((string)$form['description']); ?></textarea>
                        </div>

                        <div class="field">
                            <label>DISCOUNT TYPE *</label>
                            <select class="control" name="discount_type" id="discountType">
                                <option value="percentage" <?= $form['discount_type'] === 'percentage' ? 'selected' : ''; ?>>
                                    Percentage
                                </option>
                                <option value="fixed" <?= $form['discount_type'] === 'fixed' ? 'selected' : ''; ?>>
                                    Fixed Amount
                                </option>
                            </select>
                        </div>

                        <div class="field">
                            <label>DISCOUNT VALUE *</label>
                            <input
                                class="control"
                                type="number"
                                name="discount_value"
                                min="0.01"
                                step="0.01"
                                required
                                value="<?= e((string)$form['discount_value']); ?>"
                            >
                        </div>

                        <div class="field">
                            <label>MINIMUM BOOKING AMOUNT</label>
                            <input
                                class="control"
                                type="number"
                                name="minimum_amount"
                                min="0"
                                step="0.01"
                                value="<?= e((string)$form['minimum_amount']); ?>"
                            >
                        </div>

                        <div class="field">
                            <label>MAXIMUM DISCOUNT</label>
                            <input
                                class="control"
                                type="number"
                                name="maximum_discount"
                                id="maximumDiscount"
                                min="0.01"
                                step="0.01"
                                value="<?= e((string)$form['maximum_discount']); ?>"
                                placeholder="Optional"
                            >
                            <div class="help" id="maxHelp">
                                Optional cap for percentage coupons.
                            </div>
                        </div>

                        <div class="field">
                            <label>USAGE LIMIT</label>
                            <input
                                class="control"
                                type="number"
                                name="usage_limit"
                                min="1"
                                step="1"
                                value="<?= e((string)$form['usage_limit']); ?>"
                                placeholder="Unlimited"
                            >
                        </div>

                        <div class="field">
                            <label>STATUS</label>
                            <select class="control" name="status">
                                <option value="active" <?= $form['status'] === 'active' ? 'selected' : ''; ?>>
                                    Active
                                </option>
                                <option value="inactive" <?= $form['status'] === 'inactive' ? 'selected' : ''; ?>>
                                    Inactive
                                </option>
                            </select>
                        </div>

                        <div class="field">
                            <label>START DATE & TIME</label>
                            <input
                                class="control"
                                type="datetime-local"
                                name="start_date"
                                value="<?= e((string)$form['start_date']); ?>"
                            >
                        </div>

                        <div class="field">
                            <label>EXPIRY DATE & TIME</label>
                            <input
                                class="control"
                                type="datetime-local"
                                name="expiry_date"
                                value="<?= e((string)$form['expiry_date']); ?>"
                            >
                        </div>

                    </div>

                    <div class="form-actions">
                        <button class="btn btn-primary" type="submit">
                            <i class="fa-solid fa-floppy-disk"></i>
                            <?= $editCoupon ? 'Update Coupon' : 'Create Coupon'; ?>
                        </button>
                    </div>

                </form>
            </div>
        </section>

        <section class="card coupon-directory-card">

            <div class="mk-directory-head">
                <div>
                    <div class="mk-eyebrow">CAMPAIGN DIRECTORY</div>
                    <h2>Coupons & Promotions</h2>
                    <p><?= number_format(count($coupons)); ?> record(s) in this view</p>
                </div>
            </div>

            <div class="filters">
                <?php
                $filterLabels = array(
                    'all' => 'All',
                    'active' => 'Available',
                    'inactive' => 'Inactive',
                    'expired' => 'Expired',
                    'scheduled' => 'Scheduled',
                    'limit_reached' => 'Limit Reached'
                );
                ?>

                <?php foreach ($filterLabels as $key => $label): ?>
                    <a
                        class="filter <?= $statusFilter === $key ? 'active' : ''; ?>"
                        href="admin-coupons.php?status=<?= e($key); ?>"
                    >
                        <?= e($label); ?> (<?= number_format($counts[$key]); ?>)
                    </a>
                <?php endforeach; ?>
            </div>

            <form class="search" method="get">
                <?php if ($statusFilter !== 'all'): ?>
                    <input type="hidden" name="status" value="<?= e($statusFilter); ?>">
                <?php endif; ?>

                <input
                    type="text"
                    name="search"
                    value="<?= e($search); ?>"
                    placeholder="Search coupon code or description..."
                >
                <button type="submit">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>
            </form>

            <?php if (!$coupons): ?>

                <div class="empty">
                    <i class="fa-solid fa-ticket"></i>
                    <h3>No coupons found</h3>
                    <p>Create your first coupon using the form.</p>
                </div>

            <?php else: ?>

                <div class="table-wrap">
                    <table>
                        <thead>
                        <tr>
                            <th>COUPON</th>
                            <th>DISCOUNT</th>
                            <th>MINIMUM</th>
                            <th>USAGE</th>
                            <th>VALIDITY</th>
                            <th>STATE</th>
                            <th>ACTIONS</th>
                        </tr>
                        </thead>

                        <tbody>

                        <?php foreach ($coupons as $coupon): ?>
                            <?php $state = couponState($coupon); ?>

                            <tr>
                                <td>
                                    <div class="code"><?= e($coupon['code']); ?></div>

                                    <?php if (!empty($coupon['description'])): ?>
                                        <div class="sub"><?= e($coupon['description']); ?></div>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <strong>
                                        <?php if ($coupon['discount_type'] === 'percentage'): ?>
                                            <?= number_format((float)$coupon['discount_value'], 2); ?>%
                                        <?php else: ?>
                                            <?= e($currencySymbol); ?><?= number_format((float)$coupon['discount_value'], 2); ?>
                                        <?php endif; ?>
                                    </strong>

                                    <?php if ($coupon['maximum_discount'] !== null): ?>
                                        <div class="sub">
                                            Max <?= e($currencySymbol); ?><?= number_format((float)$coupon['maximum_discount'], 2); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?= e($currencySymbol); ?><?= number_format((float)$coupon['minimum_amount'], 2); ?>
                                </td>

                                <td>
                                    <?= number_format((int)$coupon['used_count']); ?>
                                    /
                                    <?= $coupon['usage_limit'] === null
                                        ? 'Unlimited'
                                        : number_format((int)$coupon['usage_limit']); ?>
                                </td>

                                <td>
                                    <div>
                                        <?= !empty($coupon['start_date'])
                                            ? date('d M Y', strtotime($coupon['start_date']))
                                            : 'Immediately'; ?>
                                    </div>
                                    <div class="sub">
                                        to
                                        <?= !empty($coupon['expiry_date'])
                                            ? date('d M Y', strtotime($coupon['expiry_date']))
                                            : 'No expiry'; ?>
                                    </div>
                                </td>

                                <td>
                                    <span class="badge badge-<?= e($state[1]); ?>">
                                        <?= e($state[0]); ?>
                                    </span>
                                </td>

                                <td>
                                    <div class="actions">

                                        <a
                                            class="action edit"
                                            href="admin-coupons.php?edit=<?= (int)$coupon['id']; ?>"
                                        >
                                            <i class="fa-solid fa-pen"></i>Edit
                                        </a>

                                        <form method="post" class="inline">
                                            <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                            <input type="hidden" name="action" value="toggle_status">
                                            <input type="hidden" name="coupon_id" value="<?= (int)$coupon['id']; ?>">
                                            <input type="hidden" name="return_status" value="<?= e($statusFilter); ?>">
                                            <input type="hidden" name="return_search" value="<?= e($search); ?>">

                                            <button class="action toggle" type="submit">
                                                <i class="fa-solid fa-power-off"></i>
                                                <?= $coupon['status'] === 'active' ? 'Disable' : 'Enable'; ?>
                                            </button>
                                        </form>

                                        <?php if ((int)$coupon['used_count'] === 0): ?>
                                            <form method="post" class="inline delete-form">
                                                <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="coupon_id" value="<?= (int)$coupon['id']; ?>">
                                                <input type="hidden" name="return_status" value="<?= e($statusFilter); ?>">
                                                <input type="hidden" name="return_search" value="<?= e($search); ?>">

                                                <button class="action delete" type="submit">
                                                    <i class="fa-solid fa-trash"></i>Delete
                                                </button>
                                            </form>
                                        <?php endif; ?>

                                    </div>
                                </td>
                            </tr>

                        <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>

            <?php endif; ?>

        </section>

    </div>
</div>
</main>

<script>
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');
const hamburger = document.getElementById('hamburger');

if (hamburger) {
    hamburger.addEventListener('click', function () {
        sidebar.classList.toggle('open');
        overlay.classList.toggle('show');
    });
}

if (overlay) {
    overlay.addEventListener('click', function () {
        sidebar.classList.remove('open');
        overlay.classList.remove('show');
    });
}

document.querySelectorAll('.delete-form').forEach(function (form) {
    form.addEventListener('submit', function (event) {

    });
});

const couponEditorToggle = document.getElementById('couponEditorToggle');
const couponEditorCard = document.querySelector('.coupon-editor-card');
if (couponEditorToggle && couponEditorCard) {
    couponEditorToggle.addEventListener('click', function () {
        couponEditorCard.classList.toggle('is-open');
        if (couponEditorCard.classList.contains('is-open')) {
            setTimeout(function(){ couponEditorCard.scrollIntoView({behavior:'smooth', block:'start'}); }, 50);
        }
    });
}

const discountType = document.getElementById('discountType');
const maximumDiscount = document.getElementById('maximumDiscount');
const maxHelp = document.getElementById('maxHelp');

function updateDiscountFields() {
    if (!discountType || !maximumDiscount || !maxHelp) {
        return;
    }

    if (discountType.value === 'fixed') {
        maximumDiscount.disabled = true;
        maximumDiscount.value = '';
        maxHelp.textContent = 'Not needed for a fixed amount discount.';
    } else {
        maximumDiscount.disabled = false;
        maxHelp.textContent = 'Optional cap for percentage coupons.';
    }
}

if (discountType) {
    discountType.addEventListener('change', updateDiscountFields);
    updateDiscountFields();
}
</script>







<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
