<?php
/**
 * TRAVSCOPE V24.56 — Customer > Package > Travel Date > Version filters.
 * Presentation-only upgrade. The existing query, permissions and link targets are retained.
 */
declare(strict_types=1);
require_once __DIR__ . '/config.php';
if (function_exists('requireAdmin')) {
    requireAdmin();
} elseif (empty($_SESSION['admin_id'])) {
    header('Location: ' . (defined('BASE_URL') ? BASE_URL : '') . 'admin-login.php');
    exit;
}
if (!function_exists('tcx')) {
    function tcx($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

$rows = [];
try {
    // Keep this original, bounded customer-package version query unchanged.
    $q = $pdo->query("SELECT v.id,v.lead_id,v.version_number,v.package_id,v.package_title,v.hotel_category,v.travel_date,v.adults,v.children,v.final_price,v.created_at,e.name customer_name,e.destination FROM crm_package_versions v LEFT JOIN enquiries e ON e.id=v.lead_id ORDER BY v.id DESC LIMIT 150");
    $rows = $q->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
    // Preserve the existing read-only directory behaviour on installations without CRM versions.
}

$customerOptions = [];
$versionOptions = [];
$uniquePackages = [];
$upcomingVersions = 0;
$today = date('Y-m-d');
foreach ($rows as $r) {
    $name = trim((string)($r['customer_name'] ?? ''));
    $name = $name !== '' ? $name : 'Customer';
    $customerOptions[$name] = true;
    $version = max(1, (int)($r['version_number'] ?? 1));
    $versionOptions[$version] = true;
    $packageKey = trim((string)($r['package_id'] ?? ''));
    if ($packageKey === '') $packageKey = 'title:' . trim((string)($r['package_title'] ?? 'Custom Package'));
    $uniquePackages[$packageKey] = true;
    $travelDate = (string)($r['travel_date'] ?? '');
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $travelDate) && $travelDate >= $today) $upcomingVersions++;
}
uksort($customerOptions, 'strnatcasecmp');
krsort($versionOptions, SORT_NUMERIC);
$versionCount = count($rows);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Customer Packages | TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v3">
<style>
/* V24.55: all page styles scoped so the shared admin navigation remains untouched. */
.cp-page{--cp-navy:#12345f;--cp-ink:#142541;--cp-blue:#2463df;--cp-muted:#71829c;--cp-line:#dce5f1;--cp-bg:#f5f8fc;color:var(--cp-ink);padding-bottom:24px}
.cp-page *{box-sizing:border-box}
.cp-page .cp-hero{border:1px solid #d9e6f5;border-left:4px solid #0b85d6;border-radius:13px;padding:17px 19px;background:linear-gradient(115deg,#fff 47%,#f0f7ff 100%);box-shadow:0 7px 22px rgba(23,52,89,.045);display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;margin:0 0 12px}
.cp-page .cp-eyebrow{font-size:10px;letter-spacing:.12em;font-weight:850;color:#077bc2;text-transform:uppercase;margin-bottom:3px}
.cp-page h1,.cp-page h2,.cp-page h3,.cp-page p{margin:0}
.cp-page h1{font-size:clamp(23px,2.2vw,29px);line-height:1.16;letter-spacing:-.035em;color:#132841;font-weight:850}
.cp-page .cp-desc{font-size:12px;color:#69809b;line-height:1.5;margin-top:5px;max-width:650px}
.cp-page .cp-hero-side{display:flex;align-items:center;flex-wrap:wrap;justify-content:flex-end;gap:7px}
.cp-page .cp-stat{min-width:97px;min-height:52px;border:1px solid #e1eaf5;border-radius:10px;background:rgba(255,255,255,.94);display:flex;align-items:center;gap:8px;padding:8px 10px}
.cp-page .cp-stat-icon{width:29px;height:29px;flex:0 0 29px;border-radius:9px;display:grid;place-items:center;font-size:12px}
.cp-page .cp-stat b{font-size:17px;line-height:1;display:block;font-variant-numeric:tabular-nums;letter-spacing:-.035em;color:#14375e}
.cp-page .cp-stat small{display:block;white-space:nowrap;font-size:9px;color:#72839b;font-weight:750;margin-top:4px}
.cp-page .cp-stat.blue .cp-stat-icon{color:#1967dc;background:#e8f0ff}
.cp-page .cp-stat.violet .cp-stat-icon{color:#7952db;background:#f1ecff}
.cp-page .cp-stat.green .cp-stat-icon{color:#068967;background:#e0f8ed}
.cp-page .cp-stat.amber .cp-stat-icon{color:#bf6d0d;background:#fff2df}
.cp-page .cp-master-link{display:inline-flex;align-items:center;gap:7px;text-decoration:none;white-space:nowrap;background:#1255ca;color:#fff!important;padding:11px 12px;border-radius:9px;font-size:11px;font-weight:800;box-shadow:0 5px 12px rgba(37,99,235,.14);transition:background .15s}
.cp-page .cp-master-link:hover{background:#0e419e}
.cp-page .cp-workflow{border:1px solid var(--cp-line);border-radius:12px;padding:10px 13px;background:#fff;display:flex;gap:16px;align-items:center;margin-bottom:12px;box-shadow:0 5px 16px rgba(20,49,92,.035)}
.cp-page .cp-workflow-heading{min-width:145px;max-width:155px}
.cp-page .cp-workflow-heading strong{display:block;color:#153e6d;font-size:11px;font-weight:850}
.cp-page .cp-workflow-heading span{font-size:10px;color:#8090a6;line-height:1.35;display:block;margin-top:2px}
.cp-page .cp-steps{list-style:none;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:6px;flex:1;margin:0;padding:0;min-width:0}
.cp-page .cp-step{display:flex;gap:8px;align-items:center;position:relative;min-width:0;border:1px solid var(--cp-line);background:#f8fbff;padding:7px 9px;border-radius:9px}
.cp-page .cp-step-icon{display:grid;place-items:center;flex:0 0 30px;height:30px;border-radius:8px;font-size:12px}
.cp-page .cp-step span{min-width:0}
.cp-page .cp-step b{font-size:10px;color:#273e5f;display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
.cp-page .cp-step small{font-size:9px;color:#8190a7;display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;margin-top:2px}
.cp-page .cp-step:nth-child(1) .cp-step-icon{background:#e6efff;color:#2761d9}
.cp-page .cp-step:nth-child(2) .cp-step-icon{background:#e1f8ed;color:#039767}
.cp-page .cp-step:nth-child(3) .cp-step-icon{background:#fff1db;color:#cb7812}
.cp-page .cp-step:nth-child(4) .cp-step-icon{background:#e2f6fa;color:#088ba5}
.cp-page .cp-step:nth-child(5){background:#f6f0ff;border-color:#e6d9ff}
.cp-page .cp-step:nth-child(5) .cp-step-icon{background:#e9dcff;color:#8052c9}
.cp-page .cp-directory{background:#fff;border:1px solid #dce5ef;border-radius:13px;overflow:hidden;box-shadow:0 9px 24px rgba(17,47,89,.05)}
.cp-page .cp-dir-top{padding:13px 15px 11px;display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap;background:linear-gradient(105deg,#f5f9ff,#fff)}
.cp-page .cp-dir-title{display:flex;align-items:center;gap:9px}
.cp-page .cp-dir-icon{display:grid;place-items:center;background:#e5efff;color:#1e65db;width:34px;height:34px;border-radius:10px;font-size:14px}
.cp-page .cp-dir-title h2{font-size:16px;font-weight:850;letter-spacing:-.02em;color:#193657}
.cp-page .cp-dir-title p{font-size:10px;color:#8190a7;margin-top:1px}
.cp-page .cp-dir-count{display:inline-flex;align-items:center;gap:5px;background:#e8f3ff;color:#2067ba;border:1px solid #d4e7ff;padding:6px 9px;border-radius:999px;font-weight:800;font-size:10px;white-space:nowrap}
.cp-page .cp-controls{padding:10px 15px;background:#fff;border-top:1px solid #ebf0f6;border-bottom:1px solid #e1e9f2;display:grid;grid-template-columns:minmax(155px,1.4fr) minmax(130px,1fr) minmax(175px,1.55fr) minmax(125px,1fr) minmax(90px,.75fr) minmax(135px,1fr) auto;gap:8px;align-items:end}
.cp-page .cp-field{display:flex;min-width:0;flex-direction:column;gap:4px}
.cp-page .cp-field>span{font-size:10px;line-height:1.2;letter-spacing:.015em;font-weight:800;color:#557391}
.cp-page .cp-field.is-trip>span{color:#2463df}
.cp-page .cp-control:disabled{background:#f0f4f9;color:#94a3b8;border-color:#e3e9f2;cursor:not-allowed}
.cp-page .cp-help{color:#3869a5;font-weight:750}
.cp-page .cp-input-wrap{position:relative;min-width:0}
.cp-page .cp-input-wrap>i{position:absolute;top:50%;left:12px;transform:translateY(-50%);color:#8a9cb2;font-size:12px;pointer-events:none}
.cp-page .cp-control{min-width:0;width:100%;height:36px;border:1px solid #d8e3f0;border-radius:8px;background:#fff;color:#314b69;padding:0 10px;font-size:11px;outline:none}
.cp-page .cp-control:focus{border-color:#3583e9;box-shadow:0 0 0 3px rgba(37,99,235,.10)}
.cp-page .cp-input-wrap .cp-control{padding-left:33px}
.cp-page .cp-reset{height:36px;border:1px solid #d8e3f0;border-radius:8px;background:#f5f8ff;color:#2960aa;font-size:11px;font-weight:800;padding:0 11px;white-space:nowrap;cursor:pointer}
.cp-page .cp-reset:hover{background:#e9f2ff}
.cp-page .cp-results{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;padding:8px 15px;font-size:10px;color:#7889a1;background:#fbfdff}
.cp-page .cp-results strong{color:#1e5fa8}
.cp-page .cp-table-scroll{width:100%;overflow-x:auto;scrollbar-color:#c2d2e7 transparent}
.cp-page .cp-table{border-collapse:separate;border-spacing:0;min-width:1050px;width:100%;table-layout:fixed}
.cp-page .cp-table th{background:#edf3fa;text-transform:uppercase;color:#516b89;letter-spacing:.045em;text-align:left;font-size:9px;font-weight:850;padding:11px 12px;border-top:1px solid #e4ebf4;border-bottom:1px solid #d5e0ec;white-space:nowrap}
.cp-page .cp-table td{padding:10px 12px;font-size:11px;line-height:1.45;vertical-align:middle;border-bottom:1px solid #e9eef5;color:#354b67}
.cp-page .cp-table tbody tr:nth-child(even){background:#fafcff}
.cp-page .cp-table tbody tr:hover{background:#eef6ff}
.cp-page .cp-table tbody tr[hidden],.cp-page .cp-no-results[hidden]{display:none!important}
.cp-page .cp-table tbody tr:last-child td{border-bottom:0}
.cp-page .cp-person{display:flex;align-items:center;gap:9px;min-width:0}
.cp-page .cp-avatar{background:linear-gradient(130deg,#deebff,#eff1ff);color:#3166c7;border:1px solid #dbe7ff;width:31px;height:31px;border-radius:9px;display:grid;place-items:center;font-size:12px;font-weight:850;flex:none}
.cp-page .cp-person b{display:block;color:#183554;font-size:11px;white-space:normal;word-break:break-word}
.cp-page .cp-muted{display:block;color:#8b9bb0;font-size:9px;margin-top:3px}
.cp-page .cp-package-name{font-size:11px;font-weight:750;color:#1d3d63;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;line-clamp:2;overflow:hidden;overflow-wrap:anywhere}
.cp-page .cp-destination{display:flex;align-items:center;gap:4px;font-size:10px;color:#6284a9;margin-top:4px}
.cp-page .cp-version{display:inline-flex;align-items:center;justify-content:center;min-width:33px;padding:5px 7px;border-radius:7px;font-size:10px;font-weight:900;border:1px solid #d5e4ff;background:#edf4ff;color:#2364d4}
.cp-page .cp-version-v2{background:#f1ecff;border-color:#e5daff;color:#7049cb}
.cp-page .cp-version-v3{background:#e2f8f1;border-color:#c8eee1;color:#048664}
.cp-page .cp-version-v4{background:#fff3df;border-color:#ffe4b8;color:#b86810}
.cp-page .cp-travel{font-size:11px;font-weight:800;color:#243d60;white-space:nowrap}
.cp-page .cp-pax{display:inline-flex;gap:5px;margin-top:4px;color:#7289a6;font-size:10px;white-space:nowrap}
.cp-page .cp-pax i{color:#8ca3c2}
.cp-page .cp-hotel{background:#f2f6fb;border:1px solid #e1e9f2;color:#55708e;border-radius:6px;display:inline-block;max-width:100%;font-size:10px;font-weight:750;padding:4px 7px;overflow-wrap:anywhere}
.cp-page .cp-price{font-size:13px;font-weight:900;color:#087a60;white-space:nowrap;font-variant-numeric:tabular-nums}
.cp-page .cp-actions{display:flex;align-items:center;gap:5px;flex-wrap:wrap}
.cp-page .cp-action{display:inline-flex;align-items:center;justify-content:center;gap:5px;white-space:nowrap;text-decoration:none!important;border-radius:7px;padding:7px 9px;font-size:10px;font-weight:800;line-height:1;border:1px solid transparent;transition:background .15s,color .15s}
.cp-page .cp-action.crm{background:#eaf3ff;border-color:#d6e7ff;color:#1461c8!important}
.cp-page .cp-action.crm:hover{background:#dbeaff}
.cp-page .cp-action.quote{background:#ecf9f3;border-color:#d4efdf;color:#087750!important}
.cp-page .cp-action.quote:hover{background:#d9f3e6}
.cp-page .cp-no-results{padding:30px 16px;text-align:center;color:#6b809b;font-size:12px}
.cp-page .cp-no-results i{font-size:23px;display:block;color:#9bb5d1;margin-bottom:7px}
.cp-page .cp-empty{padding:35px 20px;text-align:center;background:#fff}
.cp-page .cp-empty i{font-size:25px;color:#89a6c7;margin-bottom:9px}
.cp-page .cp-empty h3{font-size:15px;color:#233f63}
.cp-page .cp-empty p{font-size:11px;color:#7a8ca4;margin:5px 0 14px}
.cp-page .cp-empty a{display:inline-block;border-radius:8px;background:#2062d4;color:#fff!important;text-decoration:none;padding:9px 13px;font-size:11px;font-weight:800}
@media(max-width:1350px){.cp-page .cp-workflow{display:block}.cp-page .cp-workflow-heading{max-width:none;margin-bottom:8px}.cp-page .cp-steps{width:100%}.cp-page .cp-hero-side{justify-content:flex-start}}
@media(max-width:1450px){.cp-page .cp-controls{grid-template-columns:repeat(3,minmax(0,1fr))}.cp-page .cp-reset{width:100%}}
@media(max-width:960px){.cp-page .cp-hero{align-items:flex-start}.cp-page .cp-hero-side{justify-content:flex-start}.cp-page .cp-steps{grid-template-columns:repeat(3,minmax(0,1fr))}.cp-page .cp-controls{grid-template-columns:repeat(2,minmax(0,1fr))}.cp-page .cp-input-wrap{grid-column:1/-1}}
@media(max-width:560px){.cp-page .cp-hero{padding:13px}.cp-page .cp-stat{min-width:calc(50% - 4px);flex:1}.cp-page .cp-hero-side{width:100%}.cp-page .cp-master-link{width:100%;justify-content:center}.cp-page .cp-steps{grid-template-columns:repeat(2,minmax(0,1fr))}.cp-page .cp-step:last-child{grid-column:1/-1}.cp-page .cp-controls{padding:10px;grid-template-columns:1fr}.cp-page .cp-input-wrap{grid-column:auto}.cp-page .cp-reset{width:100%}}
</style>
</head>
<body>
<main class="main">
<div class="content cp-page">
  <header class="cp-hero">
    <div class="cp-hero-copy">
      <div class="cp-eyebrow"><i class="fa-solid fa-layer-group" aria-hidden="true"></i> &nbsp;Customer sales / Package snapshots</div>
      <h1>Customer Packages</h1>
      <p class="cp-desc">Manage customer-specific package versions built from Package Master, supplier costing and travel plans.</p>
    </div>
    <div class="cp-hero-side" aria-label="Package version summary">
      <div class="cp-stat blue"><span class="cp-stat-icon"><i class="fa-solid fa-copy" aria-hidden="true"></i></span><span><b><?= $versionCount ?></b><small>Versions</small></span></div>
      <div class="cp-stat violet"><span class="cp-stat-icon"><i class="fa-solid fa-users" aria-hidden="true"></i></span><span><b><?= count($customerOptions) ?></b><small>Customers</small></span></div>
      <div class="cp-stat green"><span class="cp-stat-icon"><i class="fa-solid fa-suitcase-rolling" aria-hidden="true"></i></span><span><b><?= count($uniquePackages) ?></b><small>Package types</small></span></div>
      <div class="cp-stat amber"><span class="cp-stat-icon"><i class="fa-solid fa-calendar-day" aria-hidden="true"></i></span><span><b><?= $upcomingVersions ?></b><small>Future-dated</small></span></div>
      <a class="cp-master-link" href="admin-packages.php"><i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i> Package Master</a>
    </div>
  </header>

  <section class="cp-workflow" aria-label="Package creation workflow reference">
    <div class="cp-workflow-heading"><strong>PACKAGE BUILD WORKFLOW</strong><span>Five stages from inventory to customer quotation</span></div>
    <ol class="cp-steps">
      <li class="cp-step"><span class="cp-step-icon"><i class="fa-solid fa-map" aria-hidden="true"></i></span><span><b>01 · Package Master</b><small>Base itinerary / product</small></span></li>
      <li class="cp-step"><span class="cp-step-icon"><i class="fa-solid fa-file-invoice-dollar" aria-hidden="true"></i></span><span><b>02 · Supplier Cost</b><small>Contract &amp; PAX rates</small></span></li>
      <li class="cp-step"><span class="cp-step-icon"><i class="fa-solid fa-hotel" aria-hidden="true"></i></span><span><b>03 · Hotels</b><small>Destination hotel pool</small></span></li>
      <li class="cp-step"><span class="cp-step-icon"><i class="fa-solid fa-van-shuttle" aria-hidden="true"></i></span><span><b>04 · Transport</b><small>Supplier vehicle rules</small></span></li>
      <li class="cp-step"><span class="cp-step-icon"><i class="fa-solid fa-file-circle-check" aria-hidden="true"></i></span><span><b>05 · Customer Version</b><small>Quotation snapshot</small></span></li>
    </ol>
  </section>

  <section class="cp-directory" aria-labelledby="cpDirectoryTitle">
    <div class="cp-dir-top">
      <div class="cp-dir-title"><span class="cp-dir-icon"><i class="fa-solid fa-rectangle-list" aria-hidden="true"></i></span><div><h2 id="cpDirectoryTitle">Customer Package Versions</h2><p>Select Customer → Package → Travel Date to compare only that trip’s versions.</p></div></div>
      <span class="cp-dir-count"><i class="fa-solid fa-database" aria-hidden="true"></i> <?= $versionCount ?> latest version<?= $versionCount === 1 ? '' : 's' ?> loaded<?= $versionCount >= 150 ? ' · limit 150' : '' ?></span>
    </div>
    <?php if (!$rows): ?>
      <div class="cp-empty"><i class="fa-solid fa-folder-open" aria-hidden="true"></i><h3>No customer package versions yet</h3><p>Open an enquiry or CRM trip and build a quotation package to see its versions here.</p><a href="admin-enquiries.php"><i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i> Open Enquiries</a></div>
    <?php else: ?>
      <div class="cp-controls" role="search" aria-label="Filter loaded package versions">
        <label class="cp-field"><span>Quick Search</span><span class="cp-input-wrap"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i><input class="cp-control" id="cpSearch" type="search" placeholder="Name, package, destination..." autocomplete="off" aria-label="Search package versions"></span></label>
        <label class="cp-field is-trip"><span>1 · Customer</span><select class="cp-control" id="cpCustomer" aria-label="Choose customer"><option value="">All customers</option><?php foreach ($customerOptions as $name => $_): ?><option value="<?= tcx($name) ?>"><?= tcx($name) ?></option><?php endforeach; ?></select></label>
        <label class="cp-field is-trip"><span>2 · Specific Package</span><select class="cp-control" id="cpPackage" aria-label="Choose a specific package" disabled><option value="">Choose customer first</option></select></label>
        <label class="cp-field is-trip"><span>3 · Travel Date</span><select class="cp-control" id="cpDate" aria-label="Choose package travel date" disabled><option value="">Choose package first</option></select></label>
        <label class="cp-field"><span>4 · Version</span><select class="cp-control" id="cpVersion" aria-label="Filter by version"><option value="">All versions</option><?php foreach ($versionOptions as $version => $_): ?><option value="<?= (int)$version ?>">Version <?= (int)$version ?></option><?php endforeach; ?></select></label>
        <label class="cp-field"><span>Sort Records</span><select class="cp-control" id="cpSort" aria-label="Sort package versions"><option value="newest">Newest first</option><option value="oldest">Oldest first</option><option value="price_desc">Price: high to low</option><option value="price_asc">Price: low to high</option><option value="travel_asc">Travel date: earliest</option></select></label>
        <button class="cp-reset" id="cpClear" type="button"><i class="fa-solid fa-rotate-left" aria-hidden="true"></i> Clear</button>
      </div>
      <div class="cp-results" aria-live="polite"><span id="cpResultLabel">Showing <?= $versionCount ?> of <?= $versionCount ?> loaded versions</span><span id="cpFilterHint" class="cp-help">Choose a customer to filter by an individual trip · Prices are saved quotation snapshots</span></div>
      <div class="cp-table-scroll" role="region" aria-label="Customer package version directory" tabindex="0">
        <table class="cp-table" id="cpTable">
          <colgroup><col style="width:15%"><col style="width:27%"><col style="width:7%"><col style="width:14%"><col style="width:10%"><col style="width:11%"><col style="width:16%"></colgroup>
          <thead><tr><th scope="col">Customer</th><th scope="col">Package / Destination</th><th scope="col">Version</th><th scope="col">Travel / PAX</th><th scope="col">Hotel</th><th scope="col">Saved price</th><th scope="col">Actions</th></tr></thead>
          <tbody id="cpRows">
          <?php foreach ($rows as $r):
              $customer = trim((string)($r['customer_name'] ?? ''));
              $customer = $customer !== '' ? $customer : 'Customer';
              $packageTitle = trim((string)($r['package_title'] ?? ''));
              $packageTitle = $packageTitle !== '' ? $packageTitle : 'Custom Package';
              $destination = trim((string)($r['destination'] ?? ''));
              $destination = $destination !== '' ? $destination : 'Not specified';
              $hotelCategory = trim((string)($r['hotel_category'] ?? ''));
              $version = max(1, (int)($r['version_number'] ?? 1));
              $adults = max(0, (int)($r['adults'] ?? 0));
              $children = max(0, (int)($r['children'] ?? 0));
              $price = (float)($r['final_price'] ?? 0);
              $travelRaw = trim((string)($r['travel_date'] ?? ''));
              $timestamp = $travelRaw !== '' ? strtotime($travelRaw) : false;
              $travelDisplay = $timestamp !== false ? date('d M Y', $timestamp) : ($travelRaw !== '' ? $travelRaw : 'Not set');
              // The stored package ID identifies the base product across versions; otherwise use its title.
              $packageId = (int)($r['package_id'] ?? 0);
              $packageKey = $packageId > 0 ? 'id:' . $packageId : 'title:' . strtolower(trim(preg_replace('/\s+/u', ' ', $packageTitle) ?? $packageTitle));
              $dateCandidate = substr($travelRaw, 0, 10);
              $parsedDate = DateTimeImmutable::createFromFormat('!Y-m-d', $dateCandidate);
              $travelKey = $parsedDate && $parsedDate->format('Y-m-d') === $dateCandidate ? $dateCandidate : '';
              $searchText = implode(' ', [$customer, $packageTitle, $destination, $hotelCategory, 'V'.$version, $travelRaw]);
          ?>
            <tr data-id="<?= (int)($r['id'] ?? 0) ?>" data-customer="<?= tcx($customer) ?>" data-package="<?= tcx($packageKey) ?>" data-package-name="<?= tcx($packageTitle) ?>" data-date="<?= tcx($travelKey) ?>" data-version="<?= $version ?>" data-price="<?= tcx($price) ?>" data-travel="<?= tcx($travelKey !== '' ? $travelKey : '9999-99-99') ?>" data-search="<?= tcx($searchText) ?>">
              <td><div class="cp-person"><span class="cp-avatar" aria-hidden="true"><?= tcx(strtoupper(substr($customer, 0, 1))) ?></span><span><b><?= tcx($customer) ?></b><small class="cp-muted">Customer version</small></span></div></td>
              <td><span class="cp-package-name" title="<?= tcx($packageTitle) ?>"><?= tcx($packageTitle) ?></span><span class="cp-destination"><i class="fa-solid fa-location-dot" aria-hidden="true"></i> <?= tcx($destination) ?></span></td>
              <td><span class="cp-version cp-version-v<?= min(4, $version) ?>" title="Version <?= $version ?>">V<?= $version ?></span></td>
              <td><span class="cp-travel"><?= tcx($travelDisplay) ?></span><span class="cp-pax"><i class="fa-solid fa-users" aria-hidden="true"></i> <?= $adults ?> Adult<?= $adults === 1 ? '' : 's' ?> · <?= $children ?> Child<?= $children === 1 ? '' : 'ren' ?></span></td>
              <td><span class="cp-hotel"><?= $hotelCategory !== '' ? tcx($hotelCategory) : '—' ?></span></td>
              <td><span class="cp-price">₹<?= number_format($price, 2) ?></span><span class="cp-muted">Version value</span></td>
              <td><div class="cp-actions"><a class="cp-action crm" href="admin-crm.php?lead=<?= (int)($r['lead_id'] ?? 0) ?>#crm-package" title="Open this customer in CRM"><i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i> Open CRM</a><a class="cp-action quote" href="admin-customer-quotations.php" title="Open customer quotations"><i class="fa-solid fa-file-invoice" aria-hidden="true"></i> Quotation</a></div></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div class="cp-no-results" id="cpNoResults" hidden><i class="fa-solid fa-filter-circle-xmark" aria-hidden="true"></i><span id="cpEmptyText">No matching package versions. Try changing your search or filters.</span></div>
    <?php endif; ?>
  </section>
</div>
</main>
<?php if ($rows): ?>
<script>
(function () {
  'use strict';
  var search = document.getElementById('cpSearch');
  var customer = document.getElementById('cpCustomer');
  var packageSelect = document.getElementById('cpPackage');
  var travelDate = document.getElementById('cpDate');
  var version = document.getElementById('cpVersion');
  var sort = document.getElementById('cpSort');
  var clear = document.getElementById('cpClear');
  var tbody = document.getElementById('cpRows');
  var count = document.getElementById('cpResultLabel');
  var hint = document.getElementById('cpFilterHint');
  var empty = document.getElementById('cpNoResults');
  var emptyText = document.getElementById('cpEmptyText');
  if (!search || !customer || !packageSelect || !travelDate || !version || !sort || !tbody || !clear || !count || !hint || !empty || !emptyText) return;
  var rows = Array.prototype.slice.call(tbody.querySelectorAll('tr[data-id]'));
  var missingDate = '__undated__';
  var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  function dateValue(row) { return row.dataset.date || missingDate; }
  function dateLabel(value) {
    if (value === missingDate) return 'Travel date not set';
    var parts = value.split('-');
    return parts[2] + ' ' + months[Number(parts[1]) - 1] + ' ' + parts[0];
  }
  function setOptions(control, placeholder, entries) {
    // DOM textContent is used instead of HTML interpolation for supplier/package titles.
    while (control.firstChild) control.removeChild(control.firstChild);
    var first = document.createElement('option');
    first.value = '';
    first.textContent = placeholder;
    control.appendChild(first);
    entries.forEach(function (entry) {
      var option = document.createElement('option');
      option.value = entry.value;
      option.textContent = entry.label;
      control.appendChild(option);
    });
    control.value = '';
  }
  function resetDates() {
    setOptions(travelDate, 'Choose package first', []);
    travelDate.disabled = true;
  }
  function resetVersions() {
    setOptions(version, 'Choose travel date first', []);
    version.disabled = true;
  }
  function refreshPackages() {
    resetDates();
    if (!customer.value) {
      setOptions(packageSelect, 'Choose customer first', []);
      packageSelect.disabled = true;
      refreshVersions();
      return;
    }
    var packages = new Map();
    rows.forEach(function (row) {
      if (row.dataset.customer !== customer.value) return;
      if (!packages.has(row.dataset.package)) packages.set(row.dataset.package, row.dataset.packageName || 'Custom Package');
    });
    var entries = Array.from(packages, function (pair) { return {value:pair[0], label:pair[1]}; });
    entries.sort(function (a,b) { return a.label.localeCompare(b.label, undefined, {numeric:true, sensitivity:'base'}); });
    // If multiple saved base products have the same title, make the options distinguishable.
    var labelCounts = {};
    entries.forEach(function (entry) { labelCounts[entry.label] = (labelCounts[entry.label] || 0) + 1; });
    entries.forEach(function (entry) {
      if (labelCounts[entry.label] > 1) entry.label += ' (' + entry.value.replace(/^id:/, 'Package #') + ')';
    });
    setOptions(packageSelect, 'Select a specific package (' + entries.length + ')', entries);
    packageSelect.disabled = entries.length === 0;
    resetVersions();
  }
  function refreshDates() {
    if (!customer.value || !packageSelect.value) {
      resetDates();
      resetVersions();
      return;
    }
    var dates = new Set();
    rows.forEach(function (row) {
      if (row.dataset.customer === customer.value && row.dataset.package === packageSelect.value) dates.add(dateValue(row));
    });
    var entries = Array.from(dates).sort(function (a,b) {
      if (a === missingDate) return 1;
      if (b === missingDate) return -1;
      return b.localeCompare(a);
    }).map(function (d) { return {value:d, label:dateLabel(d)}; });
    setOptions(travelDate, 'Select travel date (' + entries.length + ')', entries);
    travelDate.disabled = entries.length === 0;
    resetVersions();
  }
  function refreshVersions() {
    if (customer.value && (!packageSelect.value || !travelDate.value)) {
      resetVersions();
      return;
    }
    var versions = new Set();
    rows.forEach(function (row) {
      if (customer.value && (row.dataset.customer !== customer.value || row.dataset.package !== packageSelect.value || dateValue(row) !== travelDate.value)) return;
      versions.add(row.dataset.version);
    });
    var entries = Array.from(versions).sort(function(a,b) {return Number(b)-Number(a);}).map(function(v) {return {value:v,label:'Version '+v};});
    setOptions(version, 'All versions', entries);
    version.disabled = entries.length === 0;
  }
  function applyFilters() {
    var q = search.value.trim().toLocaleLowerCase();
    var c = customer.value;
    var p = packageSelect.value;
    var d = travelDate.value;
    var v = version.value;
    var mode = sort.value;
    var needsPackage = Boolean(c && !p);
    var needsDate = Boolean(c && p && !d);
    var ordered = rows.slice();
    ordered.sort(function (a, b) {
      if (mode === 'oldest') return Number(a.dataset.id) - Number(b.dataset.id);
      if (mode === 'price_desc') return Number(b.dataset.price) - Number(a.dataset.price) || Number(b.dataset.id) - Number(a.dataset.id);
      if (mode === 'price_asc') return Number(a.dataset.price) - Number(b.dataset.price) || Number(b.dataset.id) - Number(a.dataset.id);
      if (mode === 'travel_asc') return (a.dataset.travel || '9999-99-99').localeCompare(b.dataset.travel || '9999-99-99') || Number(b.dataset.id) - Number(a.dataset.id);
      return Number(b.dataset.id) - Number(a.dataset.id);
    });
    var shown = 0;
    ordered.forEach(function (row) {
      var match = !needsPackage && !needsDate && (!q || (row.dataset.search || '').toLocaleLowerCase().indexOf(q) !== -1) && (!c || (row.dataset.customer === c && row.dataset.package === p && dateValue(row) === d)) && (!v || row.dataset.version === v);
      row.hidden = !match;
      if (match) shown++;
      tbody.appendChild(row);
    });
    if (needsPackage) {
      count.textContent = 'Select a package for ' + c;
      hint.textContent = 'Step 2: choose one of this customer’s saved packages';
      emptyText.textContent = 'Choose a specific package to see its available travel dates.';
    } else if (needsDate) {
      count.textContent = 'Select a travel date for the chosen package';
      hint.textContent = 'Step 3: choose the departure date before viewing its versions';
      emptyText.textContent = 'Choose a travel date to see only the versions for that trip.';
    } else {
      count.textContent = 'Showing ' + shown + ' of ' + rows.length + ' loaded versions';
      hint.textContent = c ? ('Only versions for ' + c + ' · ' + dateLabel(d) + ' · Prices are quotation snapshots') : 'Choose a customer to filter by an individual trip · Prices are saved quotation snapshots';
      emptyText.textContent = 'No matching package versions. Try changing your search or filters.';
    }
    empty.hidden = shown !== 0;
  }
  search.addEventListener('input', applyFilters);
  customer.addEventListener('change', function () { refreshPackages(); applyFilters(); });
  packageSelect.addEventListener('change', function () { refreshDates(); applyFilters(); });
  travelDate.addEventListener('change', function () { refreshVersions(); applyFilters(); });
  version.addEventListener('change', applyFilters);
  sort.addEventListener('change', applyFilters);
  clear.addEventListener('click', function () { search.value = ''; customer.value = ''; sort.value = 'newest'; refreshPackages(); applyFilters(); search.focus(); });
  refreshPackages();
  applyFilters();
})();
</script>
<?php endif; ?>
<script src="assets/travscope-pro-admin.js?v=20260916-v3" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
