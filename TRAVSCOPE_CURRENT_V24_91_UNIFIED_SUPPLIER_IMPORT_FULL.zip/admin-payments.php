<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE.COM
| ADMIN PAYMENT MANAGEMENT
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';

$billingFunctionsFile = __DIR__ . '/billing-functions.php';
if (is_file($billingFunctionsFile)) {
    require_once $billingFunctionsFile;
}

requireAdmin();

$admin = currentAdmin($pdo);

if (!$admin) {

    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_mobile'],
        $_SESSION['admin_role']
    );

    redirect(BASE_URL . 'login.php');
}


/*
|--------------------------------------------------------------------------
| SETTINGS
|--------------------------------------------------------------------------
*/

$siteName = 'TRAVSCOPE.COM';

$currencySymbol = '₹';

try {

    $siteName = getSetting(
        $pdo,
        'site_name',
        'TRAVSCOPE.COM'
    );

    $currencySymbol = getSetting(
        $pdo,
        'currency_symbol',
        '₹'
    );

} catch (Throwable $e) {

    error_log(
        'Admin payments settings error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| FLASH MESSAGE
|--------------------------------------------------------------------------
*/

$success = '';
$error = '';

if (!empty($_SESSION['admin_payment_success'])) {

    $success =
        (string)$_SESSION['admin_payment_success'];

    unset($_SESSION['admin_payment_success']);
}

if (!empty($_SESSION['admin_payment_error'])) {

    $error =
        (string)$_SESSION['admin_payment_error'];

    unset($_SESSION['admin_payment_error']);
}


/*
|--------------------------------------------------------------------------
| HANDLE APPROVE / REJECT
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $csrf =
        $_POST['csrf_token']
        ?? '';

    $paymentId =
        (int)(
            $_POST['payment_id']
            ?? 0
        );

    $action =
        strtolower(
            trim(
                (string)(
                    $_POST['action']
                    ?? ''
                )
            )
        );


    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */

    if (!verifyCsrf($csrf)) {

        $_SESSION['admin_payment_error'] =
            'Security validation failed. Please try again.';

        redirect(
            BASE_URL .
            'admin-payments.php'
        );
    }


    if ($paymentId <= 0) {

        $_SESSION['admin_payment_error'] =
            'Invalid payment selected.';

        redirect(
            BASE_URL .
            'admin-payments.php'
        );
    }


    if (
        !in_array(
            $action,
            [
                'approve',
                'reject'
            ],
            true
        )
    ) {

        $_SESSION['admin_payment_error'] =
            'Invalid payment action.';

        redirect(
            BASE_URL .
            'admin-payments.php'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | PROCESS
    |--------------------------------------------------------------------------
    */

    try {

        $pdo->beginTransaction();


        /*
        |--------------------------------------------------------------------------
        | LOCK PAYMENT + BOOKING
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT

                pay.id AS payment_id,
                pay.booking_id,
                pay.transaction_id,
                pay.amount,
                pay.currency,
                pay.payment_method,
                pay.payment_gateway,
                pay.status AS payment_record_status,

                b.booking_number,
                b.total_amount,
                b.paid_amount,
                b.booking_status,
                b.payment_status

            FROM payments pay

            INNER JOIN bookings b
                ON b.id = pay.booking_id

            WHERE pay.id = ?

            LIMIT 1

            FOR UPDATE
        ");

        $stmt->execute([
            $paymentId
        ]);

        $payment =
            $stmt->fetch();


        if (!$payment) {

            throw new RuntimeException(
                'Payment record was not found.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | PAYMENT MUST STILL BE PENDING
        |--------------------------------------------------------------------------
        */

        if (
            strtolower(
                (string)$payment['payment_record_status']
            )
            !==
            'pending'
        ) {

            throw new RuntimeException(
                'This payment has already been processed.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | APPROVE
        |--------------------------------------------------------------------------
        */

        if ($action === 'approve') {

            $paymentAmount =
                max(
                    0,
                    (float)$payment['amount']
                );

            $totalAmount =
                max(
                    0,
                    (float)$payment['total_amount']
                );

            $currentPaid =
                max(
                    0,
                    (float)$payment['paid_amount']
                );

            /* A FINAL GST/TCS invoice is the authoritative customer payable. */
            if (function_exists('tsBillLatestFinalInvoiceAny')) {
                $finalInvoice = tsBillLatestFinalInvoiceAny($pdo, (int)$payment['booking_id']);
                if ($finalInvoice) {
                    $invoiceTotal = max(0, round((float)($finalInvoice['booking_total'] ?? 0), 2));
                    if ($invoiceTotal > 0 && abs($invoiceTotal - $totalAmount) > .01) {
                        $totalAmount = $invoiceTotal;
                        $pdo->prepare("UPDATE bookings SET total_amount=?, payment_status=? WHERE id=?")
                            ->execute([$totalAmount, tsBillPaymentStatus($totalAmount, $currentPaid), (int)$payment['booking_id']]);
                    }
                }
            }


            if ($paymentAmount <= 0) {

                throw new RuntimeException(
                    'Payment amount is invalid.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | NEW PAID AMOUNT
            |--------------------------------------------------------------------------
            */

            $newPaidAmount =
                $currentPaid
                +
                $paymentAmount;


            /*
            |--------------------------------------------------------------------------
            | DO NOT ALLOW PAID AMOUNT ABOVE BOOKING TOTAL
            |--------------------------------------------------------------------------
            */

            if (
                $newPaidAmount
                >
                $totalAmount
            ) {

                $newPaidAmount =
                    $totalAmount;
            }


            /*
            |--------------------------------------------------------------------------
            | DETERMINE PAYMENT STATUS
            |--------------------------------------------------------------------------
            */

            if (
                $newPaidAmount
                >=
                $totalAmount
                &&
                $totalAmount > 0
            ) {

                $newPaymentStatus =
                    'paid';

                $newBookingStatus =
                    'confirmed';

            } else {

                $newPaymentStatus =
                    'partial';

                /*
                | Do not downgrade an already confirmed booking.
                */

                if (
                    strtolower(
                        (string)$payment['booking_status']
                    )
                    ===
                    'confirmed'
                ) {

                    $newBookingStatus =
                        'confirmed';

                } else {

                    $newBookingStatus =
                        'pending';
                }
            }


            /*
            |--------------------------------------------------------------------------
            | APPROVE PAYMENT
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare("
                UPDATE payments

                SET
                    status = 'success',
                    paid_at = NOW()

                WHERE
                    id = ?
                    AND status = 'pending'
            ");

            $stmt->execute([
                $paymentId
            ]);


            if ($stmt->rowCount() !== 1) {

                throw new RuntimeException(
                    'Payment could not be approved because its status changed.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | UPDATE BOOKING
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare("
                UPDATE bookings

                SET
                    paid_amount = ?,
                    payment_status = ?,
                    booking_status = ?

                WHERE id = ?
            ");

            $stmt->execute([
                $newPaidAmount,
                $newPaymentStatus,
                $newBookingStatus,
                (int)$payment['booking_id']
            ]);

            $paymentReceipt = null;

            if (
                function_exists('tsBillReady')
                && tsBillReady($pdo)
            ) {
                $paymentReceipt = tsBillOnPaymentApproved(
                    $pdo,
                    $paymentId,
                    (int)($admin['id'] ?? 0)
                );
            }


            $pdo->commit();


            $receiptEmailMessage = '';

            if (
                is_array($paymentReceipt)
                && !empty($paymentReceipt['id'])
                && function_exists('tsBillSendApprovedPaymentReceiptEmail')
            ) {
                try {
                    $receiptEmailResult =
                        tsBillSendApprovedPaymentReceiptEmail(
                            $pdo,
                            (int)$paymentReceipt['id']
                        );

                    $receiptEmailMessage =
                        !empty($receiptEmailResult['sent'])
                        ? ' Payment receipt emailed to the customer.'
                        : ' ' . (string)(
                            $receiptEmailResult['message']
                            ?? 'Payment receipt email was not sent.'
                        );

                } catch (Throwable $mailError) {
                    error_log(
                        'Admin payment receipt email error: '
                        . $mailError->getMessage()
                    );

                    $receiptEmailMessage =
                        ' Payment was approved, but the receipt email could not be sent.';
                }
            }


            $_SESSION['admin_payment_success'] =
                'Payment approved successfully. Booking '
                .
                $payment['booking_number']
                .
                (
                    $newPaymentStatus === 'paid'
                    ? ' is now fully paid and confirmed.'
                    : ' is now partially paid.'
                )
                .
                $receiptEmailMessage;


        /*
        |--------------------------------------------------------------------------
        | REJECT
        |--------------------------------------------------------------------------
        */

        } else {

            $stmt = $pdo->prepare("
                UPDATE payments

                SET
                    status = 'failed',
                    paid_at = NULL

                WHERE
                    id = ?
                    AND status = 'pending'
            ");

            $stmt->execute([
                $paymentId
            ]);


            if ($stmt->rowCount() !== 1) {

                throw new RuntimeException(
                    'Payment could not be rejected because its status changed.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | BOOKING REMAINS UNPAID/PARTIAL
            |--------------------------------------------------------------------------
            |
            | We do NOT modify paid_amount because rejected
            | payments were never added to paid_amount.
            |--------------------------------------------------------------------------
            */


            $pdo->commit();


            $_SESSION['admin_payment_success'] =
                'Payment rejected successfully. The customer can submit another payment.';
        }


    } catch (Throwable $e) {

        if ($pdo->inTransaction()) {

            $pdo->rollBack();
        }


        error_log(
            'Admin payment processing error: '
            . $e->getMessage()
        );


        $_SESSION['admin_payment_error'] =
            $e->getMessage();
    }


    /*
    |--------------------------------------------------------------------------
    | PRESERVE FILTER
    |--------------------------------------------------------------------------
    */

    $returnFilter =
        trim(
            (string)(
                $_POST['return_filter']
                ?? ''
            )
        );

    $url =
        BASE_URL .
        'admin-payments.php';

    if (
        in_array(
            $returnFilter,
            [
                'pending',
                'success',
                'failed',
                'refunded'
            ],
            true
        )
    ) {

        $url .=
            '?status='
            .
            urlencode(
                $returnFilter
            );
    }


    redirect($url);
}


/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

$statusFilter =
    strtolower(
        trim(
            (string)(
                $_GET['status']
                ?? 'all'
            )
        )
    );


$allowedFilters = [
    'all',
    'pending',
    'success',
    'failed',
    'refunded'
];


if (
    !in_array(
        $statusFilter,
        $allowedFilters,
        true
    )
) {

    $statusFilter =
        'all';
}


$search =
    trim(
        (string)(
            $_GET['search']
            ?? ''
        )
    );


/*
|--------------------------------------------------------------------------
| PAYMENT COUNTS
|--------------------------------------------------------------------------
*/

$counts = [
    'all' => 0,
    'pending' => 0,
    'success' => 0,
    'failed' => 0,
    'refunded' => 0
];


try {

    $counts['all'] =
        (int)$pdo->query("
            SELECT COUNT(*)
            FROM payments
        ")->fetchColumn();


    foreach (
        [
            'pending',
            'success',
            'failed',
            'refunded'
        ]
        as $status
    ) {

        $stmt =
            $pdo->prepare("
                SELECT COUNT(*)
                FROM payments
                WHERE status = ?
            ");

        $stmt->execute([
            $status
        ]);

        $counts[$status] =
            (int)$stmt->fetchColumn();
    }


} catch (Throwable $e) {

    error_log(
        'Admin payment count error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| PAYMENT STATISTICS
|--------------------------------------------------------------------------
*/

$totalSuccessfulAmount = 0.00;
$pendingAmount = 0.00;
$todaySuccessfulAmount = 0.00;


try {

    $totalSuccessfulAmount =
        (float)$pdo->query("
            SELECT
                COALESCE(
                    SUM(amount),
                    0
                )
            FROM payments
            WHERE status = 'success'
        ")->fetchColumn();


    $pendingAmount =
        (float)$pdo->query("
            SELECT
                COALESCE(
                    SUM(amount),
                    0
                )
            FROM payments
            WHERE status = 'pending'
        ")->fetchColumn();


    $todaySuccessfulAmount =
        (float)$pdo->query("
            SELECT
                COALESCE(
                    SUM(amount),
                    0
                )
            FROM payments

            WHERE
                status = 'success'

                AND DATE(
                    COALESCE(
                        paid_at,
                        created_at
                    )
                ) = CURRENT_DATE()
        ")->fetchColumn();


} catch (Throwable $e) {

    error_log(
        'Admin payment statistics error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| FETCH PAYMENTS
|--------------------------------------------------------------------------
*/

$payments = [];


try {

    $where = [];
    $params = [];


    if ($statusFilter !== 'all') {

        $where[] =
            'pay.status = ?';

        $params[] =
            $statusFilter;
    }


    if ($search !== '') {

        $where[] = "
            (
                pay.transaction_id LIKE ?
                OR b.booking_number LIKE ?
                OR b.customer_name LIKE ?
                OR b.customer_email LIKE ?
                OR b.customer_mobile LIKE ?
                OR p.title LIKE ?
            )
        ";

        $searchTerm =
            '%' . $search . '%';

        for ($i = 0; $i < 6; $i++) {

            $params[] =
                $searchTerm;
        }
    }


    $whereSql =
        $where
        ? 'WHERE ' . implode(
            ' AND ',
            $where
        )
        : '';


    $sql = "
        SELECT

            pay.id,
            pay.booking_id,
            pay.transaction_id,
            pay.payment_gateway,
            pay.amount,
            pay.currency,
            pay.payment_method,
            pay.status,
            pay.gateway_response,
            pay.paid_at,
            pay.created_at,

            b.booking_number,
            b.user_id,
            b.customer_name,
            b.customer_email,
            b.customer_mobile,
            b.travel_date,
            b.adults,
            b.children,
            b.total_amount,
            b.paid_amount,
            b.booking_status,
            b.payment_status,

            p.title AS package_title,

            d.name AS destination_name,
            d.country AS destination_country

        FROM payments pay

        INNER JOIN bookings b
            ON b.id = pay.booking_id

        LEFT JOIN packages p
            ON p.id = b.package_id

        LEFT JOIN destinations d
            ON d.id = p.destination_id

        {$whereSql}

        ORDER BY

            CASE pay.status
                WHEN 'pending' THEN 1
                WHEN 'success' THEN 2
                WHEN 'failed' THEN 3
                WHEN 'refunded' THEN 4
                ELSE 5
            END,

            pay.id DESC

        LIMIT 500
    ";


    $stmt =
        $pdo->prepare($sql);

    $stmt->execute($params);

    $payments =
        $stmt->fetchAll();


} catch (Throwable $e) {

    $payments = [];

    $error =
        'Payments could not be loaded.';

    error_log(
        'Admin payment list error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| ADMIN INITIAL
|--------------------------------------------------------------------------
*/

$adminName =
    trim(
        (string)(
            $admin['name']
            ?? 'Admin'
        )
    );

if ($adminName === '') {

    $adminName =
        'Admin';
}

$adminInitial =
    strtoupper(
        substr(
            $adminName,
            0,
            1
        )
    );


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

$csrfToken =
    csrfToken();

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#07192d"
>

<meta
    name="robots"
    content="noindex,nofollow"
>

<title>
Payments | <?= e($siteName); ?>
</title>


<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

:root {

    --sidebar:#07192d;
    --sidebar-light:#0d2743;

    --primary:#0b74ff;
    --primary-dark:#075fd2;

    --background:#f5f7fb;
    --white:#ffffff;

    --text:#172033;
    --muted:#778294;

    --border:#e6eaf0;

    --green:#0da66a;
    --orange:#e88b22;
    --red:#e24a5c;
    --purple:#7956d8;

    --shadow:
        0 8px 30px
        rgba(23,32,51,.06);
}


* {

    margin:0;
    padding:0;
    box-sizing:border-box;
}


html {

    scroll-behavior:smooth;
}


body {

    font-family:'DM Sans',sans-serif;
    background:var(--background);
    color:var(--text);
    min-height:100vh;
}


a {

    text-decoration:none;
    color:inherit;
}


button,
input {

    font-family:inherit;
}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar {

    position:fixed;

    top:0;
    left:0;
    bottom:0;

    width:265px;

    background:var(--sidebar);

    color:white;

    z-index:1100;

    overflow-y:auto;

    transition:.25s ease;
}


.sidebar-logo {

    height:80px;

    padding:0 23px;

    display:flex;
    align-items:center;

    gap:11px;

    border-bottom:
        1px solid
        rgba(255,255,255,.08);

    font-family:'Manrope',sans-serif;

    font-size:20px;

    font-weight:800;
}


.logo-icon {

    width:42px;
    height:42px;

    border-radius:12px;

    display:grid;
    place-items:center;

    background:
        linear-gradient(
            135deg,
            #0b74ff,
            #00b7ff
        );

    transform:rotate(-5deg);
}


.sidebar-logo span {

    color:#63b4ff;
}


.sidebar-menu {

    padding:20px 13px 35px;
}


.menu-title {

    padding:14px 13px 8px;

    color:#647990;

    font-size:10px;
    font-weight:800;

    letter-spacing:1.4px;
}


.menu-link {

    min-height:44px;

    margin:3px 0;

    padding:0 13px;

    border-radius:9px;

    display:flex;
    align-items:center;

    gap:11px;

    color:#9fb0c2;

    font-size:13px;

    font-weight:600;

    transition:.2s;
}


.menu-link i {

    width:20px;

    text-align:center;

    font-size:14px;
}


.menu-link:hover {

    color:white;

    background:
        rgba(255,255,255,.06);
}


.menu-link.active {

    color:white;

    background:
        linear-gradient(
            135deg,
            #0b74ff,
            #0968e2
        );
}


.menu-badge {

    min-width:21px;

    height:19px;

    margin-left:auto;

    padding:0 6px;

    border-radius:20px;

    display:grid;
    place-items:center;

    background:var(--red);

    color:white;

    font-size:9px;

    font-weight:800;
}


.sidebar-overlay {

    position:fixed;

    inset:0;

    background:
        rgba(0,0,0,.42);

    z-index:1050;

    opacity:0;

    visibility:hidden;

    transition:.2s;
}


.sidebar-overlay.show {

    opacity:1;

    visibility:visible;
}


/* =========================================================
   MAIN
========================================================= */

.main {

    min-height:100vh;

    margin-left:265px;
}


/* =========================================================
   TOPBAR
========================================================= */

.topbar {

    height:80px;

    padding:0 30px;

    position:sticky;

    top:0;

    z-index:900;

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:20px;

    background:
        rgba(255,255,255,.96);

    border-bottom:
        1px solid
        var(--border);

    backdrop-filter:
        blur(10px);
}


.topbar-left {

    display:flex;
    align-items:center;

    gap:14px;
}


.mobile-menu {

    width:39px;
    height:39px;

    border:1px solid var(--border);

    border-radius:9px;

    display:none;
    place-items:center;

    background:white;

    color:var(--text);

    cursor:pointer;
}


.topbar-title {

    font-family:'Manrope',sans-serif;

    font-size:15px;

    font-weight:800;
}


.top-actions {

    display:flex;
    align-items:center;

    gap:14px;
}


.view-site {

    height:38px;

    padding:0 13px;

    border:1px solid var(--border);

    border-radius:8px;

    display:flex;
    align-items:center;

    gap:7px;

    background:white;

    color:#657286;

    font-size:11px;

    font-weight:700;
}


.notification {

    width:39px;
    height:39px;

    position:relative;

    border:1px solid var(--border);

    border-radius:9px;

    display:grid;
    place-items:center;

    background:white;

    color:#657286;
}


.notification-dot {

    width:8px;
    height:8px;

    position:absolute;

    top:6px;
    right:6px;

    border:2px solid white;

    border-radius:50%;

    background:var(--red);
}


.admin-profile {

    padding-left:14px;

    border-left:
        1px solid
        var(--border);

    display:flex;
    align-items:center;

    gap:9px;
}


.admin-avatar {

    width:38px;
    height:38px;

    border-radius:10px;

    display:grid;
    place-items:center;

    background:
        linear-gradient(
            135deg,
            var(--primary),
            #00a6ff
        );

    color:white;

    font-weight:800;
}


.admin-info strong {

    display:block;

    font-size:11px;
}


.admin-info span {

    display:block;

    margin-top:2px;

    color:var(--muted);

    font-size:9px;
}


/* =========================================================
   CONTENT
========================================================= */

.content {

    padding:30px;
}


.page-heading {

    margin-bottom:24px;

    display:flex;
    align-items:flex-start;
    justify-content:space-between;

    gap:20px;
}


.page-heading h1 {

    font-family:'Manrope',sans-serif;

    font-size:28px;

    color:var(--text);
}


.page-heading p {

    margin-top:5px;

    color:var(--muted);

    font-size:11px;
}


/* =========================================================
   ALERT
========================================================= */

.alert {

    margin-bottom:20px;

    padding:13px 15px;

    border-radius:9px;

    display:flex;
    align-items:flex-start;

    gap:9px;

    font-size:11px;

    line-height:1.5;
}


.alert-success {

    border:1px solid #bfe9d7;

    background:#edfaf5;

    color:#087a50;
}


.alert-error {

    border:1px solid #f0c3c9;

    background:#fff0f2;

    color:#b22e41;
}


/* =========================================================
   STATISTICS
========================================================= */

.stats-grid {

    margin-bottom:24px;

    display:grid;

    grid-template-columns:
        repeat(4,1fr);

    gap:15px;
}


.stat-card {

    min-height:120px;

    padding:19px;

    border:
        1px solid
        var(--border);

    border-radius:12px;

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:15px;

    background:white;

    box-shadow:var(--shadow);
}


.stat-label {

    color:var(--muted);

    font-size:9px;

    font-weight:800;

    letter-spacing:.6px;
}


.stat-number {

    margin-top:7px;

    font-family:'Manrope',sans-serif;

    font-size:23px;

    font-weight:800;
}


.stat-sub {

    margin-top:4px;

    color:#8994a3;

    font-size:9px;
}


.stat-icon {

    width:44px;
    height:44px;

    flex:0 0 44px;

    border-radius:11px;

    display:grid;
    place-items:center;

    background:#edf5ff;

    color:var(--primary);

    font-size:17px;
}


.stat-card.pending .stat-icon {

    background:#fff4e7;

    color:var(--orange);
}


.stat-card.success .stat-icon {

    background:#eaf9f3;

    color:var(--green);
}


.stat-card.today .stat-icon {

    background:#f1edff;

    color:var(--purple);
}


/* =========================================================
   FILTER CARD
========================================================= */

.card {

    margin-bottom:20px;

    border:
        1px solid
        var(--border);

    border-radius:12px;

    background:white;

    box-shadow:var(--shadow);

    overflow:hidden;
}


.filter-bar {

    padding:16px;

    display:flex;
    align-items:center;
    justify-content:space-between;

    gap:15px;

    border-bottom:
        1px solid
        var(--border);
}


.filters {

    display:flex;

    gap:7px;

    flex-wrap:wrap;
}


.filter {

    min-height:35px;

    padding:0 11px;

    border:
        1px solid
        var(--border);

    border-radius:7px;

    display:inline-flex;
    align-items:center;

    gap:6px;

    background:white;

    color:#657286;

    font-size:10px;

    font-weight:700;
}


.filter.active {

    border-color:var(--primary);

    background:#edf5ff;

    color:var(--primary);
}


.filter-count {

    min-width:18px;
    height:18px;

    padding:0 5px;

    border-radius:20px;

    display:grid;
    place-items:center;

    background:#eef1f5;

    font-size:8px;
}


.filter.active .filter-count {

    background:var(--primary);

    color:white;
}


/* =========================================================
   SEARCH
========================================================= */

.search-form {

    display:flex;

    gap:7px;
}


.search-box {

    width:240px;
    height:36px;

    padding:0 11px;

    border:
        1px solid
        var(--border);

    border-radius:7px;

    outline:none;

    color:var(--text);

    font-size:10px;
}


.search-box:focus {

    border-color:#91c1ff;

    box-shadow:
        0 0 0 3px
        rgba(11,116,255,.06);
}


.search-button {

    width:38px;
    height:36px;

    border:0;

    border-radius:7px;

    display:grid;
    place-items:center;

    background:var(--primary);

    color:white;

    cursor:pointer;
}


/* =========================================================
   TABLE
========================================================= */

.table-wrap {

    overflow-x:auto;
}


table {

    width:100%;

    border-collapse:collapse;

    min-width:1100px;
}


th {

    padding:12px 15px;

    background:#f9fafc;

    border-bottom:
        1px solid
        var(--border);

    color:#7d8999;

    text-align:left;

    font-size:9px;

    font-weight:800;

    letter-spacing:.4px;
}


td {

    padding:14px 15px;

    border-bottom:
        1px solid
        #edf0f3;

    vertical-align:middle;

    font-size:10px;
}


tbody tr:hover {

    background:#fbfcfe;
}


.booking-ref {

    color:var(--primary);

    font-weight:800;
}


.customer strong {

    display:block;

    color:var(--text);

    font-size:10px;
}


.customer span {

    display:block;

    margin-top:3px;

    color:var(--muted);

    font-size:8px;
}


.package-name {

    max-width:180px;

    color:#455266;

    font-weight:600;
}


.transaction {

    font-family:monospace;

    color:#344054;

    font-size:10px;

    font-weight:700;

    word-break:break-all;
}


.amount {

    color:var(--text);

    font-family:'Manrope',sans-serif;

    font-size:11px;

    font-weight:800;
}


/* =========================================================
   STATUS
========================================================= */

.status {

    min-height:25px;

    padding:0 8px;

    border-radius:20px;

    display:inline-flex;
    align-items:center;

    font-size:8px;

    font-weight:800;

    text-transform:uppercase;
}


.status-pending {

    background:#fff4e4;

    color:#b66b08;
}


.status-success {

    background:#e9f9f2;

    color:#078454;
}


.status-failed {

    background:#ffedef;

    color:#c63248;
}


.status-refunded {

    background:#f0edff;

    color:#6848c7;
}


/* =========================================================
   ACTIONS
========================================================= */

.actions {

    display:flex;

    gap:6px;
}


.action-form {

    display:inline;
}


.action-btn {

    min-height:31px;

    padding:0 10px;

    border:0;

    border-radius:6px;

    display:inline-flex;
    align-items:center;

    gap:5px;

    cursor:pointer;

    font-size:9px;

    font-weight:800;
}


.approve {

    background:#e8f8f1;

    color:#078454;
}


.approve:hover {

    background:#d9f4e8;
}


.reject {

    background:#ffedef;

    color:#c63248;
}


.reject:hover {

    background:#ffe0e4;
}


.view-details {

    background:#edf5ff;

    color:#0b74ff;
}


.view-details:hover {

    background:#dfeeff;
}


.processed {

    color:#8a95a4;

    font-size:9px;
}


/* =========================================================
   EMPTY
========================================================= */

.empty {

    padding:60px 20px;

    text-align:center;
}


.empty-icon {

    width:60px;
    height:60px;

    margin:0 auto 12px;

    border-radius:50%;

    display:grid;
    place-items:center;

    background:#edf5ff;

    color:var(--primary);

    font-size:21px;
}


.empty h3 {

    font-family:'Manrope',sans-serif;

    font-size:16px;
}


.empty p {

    margin-top:5px;

    color:var(--muted);

    font-size:10px;
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:1150px) {

    .stats-grid {

        grid-template-columns:
            repeat(2,1fr);
    }
}


@media(max-width:850px) {

    .sidebar {

        transform:
            translateX(-100%);
    }


    .sidebar.open {

        transform:
            translateX(0);
    }


    .main {

        margin-left:0;
    }


    .mobile-menu {

        display:grid;
    }


    .content {

        padding:20px;
    }


    .filter-bar {

        align-items:stretch;

        flex-direction:column;
    }


    .search-box {

        width:100%;
    }


    .search-form {

        width:100%;
    }


    .search-form .search-box {

        flex:1;
    }
}


@media(max-width:550px) {

    .topbar {

        height:68px;

        padding:0 13px;
    }


    .topbar-title {

        display:none;
    }


    .view-site span,
    .admin-info {

        display:none;
    }


    .admin-profile {

        padding-left:0;

        border:0;
    }


    .content {

        padding:16px 12px 40px;
    }


    .page-heading h1 {

        font-size:23px;
    }


    .stats-grid {

        grid-template-columns:1fr;
    }


    .stat-card {

        min-height:105px;
    }
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
}
.main > .content,
.main .content:first-child{
    width:auto!important;
    max-width:none!important;
    margin:0!important;
    padding:16px 18px 20px!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}


/* ============================================================
   V24.72 — INTERNATIONAL PAYMENT DIRECTORY
============================================================ */
.v2472-finance-head{
    display:grid!important;grid-template-columns:minmax(290px,1.35fr) minmax(560px,1fr)!important;
    gap:18px!important;align-items:center!important;padding:18px 20px!important;
    border:1px solid #dbe6f4!important;border-left:5px solid #0b74ff!important;border-radius:16px!important;
    background:linear-gradient(135deg,#ffffff 0%,#f5f9ff 100%)!important;box-shadow:0 10px 30px rgba(15,42,73,.05)!important;
}
.v2472-finance-title h1{margin:2px 0 4px!important;font-size:25px!important;line-height:1.12!important;color:#10233f!important}
.v2472-finance-title p{margin:0!important;font-size:12px!important;color:#6f8096!important}
.v2472-eyebrow{display:block;color:#0b74ff;font-size:10px;font-weight:900;letter-spacing:.95px;text-transform:uppercase}
.v2472-finance-metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.v2472-metric{position:relative;min-width:0;padding:10px 12px;border:1px solid #e2e9f2;border-radius:11px;background:#fff;box-shadow:0 4px 14px rgba(16,35,63,.035);overflow:hidden}
.v2472-metric:before{content:"";position:absolute;left:0;top:0;bottom:0;width:3px;background:#0b74ff}
.v2472-metric.amber:before{background:#f59e0b}.v2472-metric.green:before{background:#10b981}.v2472-metric.violet:before{background:#8b5cf6}
.v2472-metric span{display:block;font-size:9px;font-weight:850;text-transform:uppercase;letter-spacing:.3px;color:#7a899c;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.v2472-metric strong{display:block;margin-top:3px;color:#10233f;font-size:17px;line-height:1.15;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.v2472-metric small{display:block;margin-top:2px;color:#9a6b15;font-size:9px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.v2472-finance-directory{margin-top:14px!important;border-radius:14px!important;overflow:hidden!important;border:1px solid #dfe7f1!important;box-shadow:0 8px 24px rgba(15,42,73,.04)!important}
.v2472-directory-head{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:12px 14px;border-bottom:1px solid #e4ebf3;background:#fbfdff}
.v2472-directory-head strong{display:block;margin-top:1px;font-size:15px;color:#123155}.v2472-directory-head small{display:block;margin-top:2px;color:#8795a8;font-size:10px}
.v2472-directory-note{font-size:10px;font-weight:750;color:#58718f;background:#eef6ff;border:1px solid #d9e9fb;border-radius:999px;padding:7px 10px;white-space:nowrap}
.v2472-finance-directory .filter-bar{margin:0!important;padding:10px 12px!important;border:0!important;border-bottom:1px solid #e5ebf2!important;border-radius:0!important;background:#fff!important}
.v2472-finance-directory .filters{gap:5px!important}
.v2472-finance-directory .filter{min-height:32px!important;padding:0 10px!important;border-radius:999px!important;font-size:11px!important}
.v2472-finance-directory .filter-count{min-width:18px!important;height:18px!important;font-size:9px!important}
.v2472-finance-directory .search-form{margin-left:auto!important}
.v2472-finance-directory .search-box{height:34px!important;min-width:250px!important;font-size:11px!important;border-radius:9px!important}
.v2472-finance-directory .search-button{height:34px!important;width:38px!important;border-radius:9px!important}
.v2472-finance-directory .table-wrap{border:0!important;border-radius:0!important;box-shadow:none!important}
.v2472-finance-directory table thead th{background:#eef4fb!important;color:#47617e!important;font-size:10px!important;letter-spacing:.25px!important;padding:10px 9px!important}
.v2472-finance-directory table tbody td{padding:10px 9px!important;vertical-align:middle!important}
.v2472-finance-directory table tbody tr:hover{background:#f8fbff!important}
@media(max-width:1180px){.v2472-finance-head{grid-template-columns:1fr!important}.v2472-finance-metrics{grid-template-columns:repeat(4,minmax(120px,1fr))}}
@media(max-width:760px){.v2472-finance-head{padding:14px!important}.v2472-finance-metrics{grid-template-columns:1fr 1fr}.v2472-directory-head{align-items:flex-start;flex-direction:column}.v2472-directory-note{white-space:normal}.v2472-finance-directory .filter-bar{align-items:stretch!important;flex-direction:column!important}.v2472-finance-directory .search-form{margin-left:0!important;width:100%!important}.v2472-finance-directory .search-box{min-width:0!important;width:100%!important}}
</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head>

<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->







<!-- =========================================================
     SIDEBAR OVERLAY
========================================================= -->




<!-- =========================================================
     SIDEBAR
========================================================= -->

<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->




<!-- =========================================================
     MAIN
========================================================= -->

<main class="main">


<!-- TOPBAR -->

<header class="topbar">


    <div class="topbar-left">


        


        <div class="topbar-title">

            TRAVSCOPE Administration

        </div>


    </div>


    <div class="top-actions">


        <a
            href="<?= e(BASE_URL); ?>"
            target="_blank"
            class="view-site"
        >

            <i class="fa-solid fa-arrow-up-right-from-square"></i>

            <span>
                View Website
            </span>

        </a>


        <a
            href="admin-payments.php?status=pending"
            class="notification"
            title="Pending Payments"
        >

            <i class="fa-regular fa-bell"></i>

            <?php if (
                $counts['pending'] > 0
            ): ?>

                <span
                    class="notification-dot"
                ></span>

            <?php endif; ?>

        </a>


        <div class="admin-profile">


            <div class="admin-avatar">

                <?= e($adminInitial); ?>

            </div>


            <div class="admin-info">

                <strong>

                    <?= e(
                        $admin['name']
                    ); ?>

                </strong>


                <span>

                    <?= e(
                        ucwords(
                            str_replace(
                                '_',
                                ' ',
                                $admin['role']
                            )
                        )
                    ); ?>

                </span>

            </div>


        </div>


    </div>


</header>


<!-- =========================================================
     CONTENT
========================================================= -->

<div class="content">


    <div class="page-heading v2472-finance-head">

        <div class="v2472-finance-title">
            <span class="v2472-eyebrow">FINANCE / CUSTOMER COLLECTIONS</span>
            <h1>Payment Management</h1>
            <p>Review customer submissions, verify transactions and keep booking payment status accurate.</p>
        </div>

        <div class="v2472-finance-metrics" aria-label="Payment summary">
            <div class="v2472-metric blue">
                <span>Total Payments</span>
                <strong><?= number_format($counts['all']); ?></strong>
            </div>
            <div class="v2472-metric amber">
                <span>Pending Verification</span>
                <strong><?= number_format($counts['pending']); ?></strong>
                <small><?= e($currencySymbol); ?><?= number_format($pendingAmount, 2); ?></small>
            </div>
            <div class="v2472-metric green">
                <span>Verified Revenue</span>
                <strong><?= e($currencySymbol); ?><?= number_format($totalSuccessfulAmount, 0); ?></strong>
            </div>
            <div class="v2472-metric violet">
                <span>Verified Today</span>
                <strong><?= e($currencySymbol); ?><?= number_format($todaySuccessfulAmount, 0); ?></strong>
            </div>
        </div>

    </div>


    <!-- SUCCESS -->

    <?php if ($success !== ''): ?>

        <div class="alert alert-success">

            <i class="fa-solid fa-circle-check"></i>

            <div>
                <?= e($success); ?>
            </div>

        </div>

    <?php endif; ?>


    <!-- ERROR -->

    <?php if ($error !== ''): ?>

        <div class="alert alert-error">

            <i class="fa-solid fa-triangle-exclamation"></i>

            <div>
                <?= e($error); ?>
            </div>

        </div>

    <?php endif; ?>

    <!-- =====================================================
         PAYMENTS
    ====================================================== -->

    <section class="card v2472-finance-directory">

        <div class="v2472-directory-head">
            <div>
                <span class="v2472-eyebrow">PAYMENT DIRECTORY</span>
                <strong>Transactions & Verification</strong>
                <small><?= number_format($counts[$statusFilter] ?? $counts['all']); ?> record(s) in this view</small>
            </div>
            <div class="v2472-directory-note"><i class="fa-solid fa-shield-halved"></i> Verified payments only contribute to collected revenue</div>
        </div>

        <div class="filter-bar">


            <div class="filters">


                <?php

                $filterLabels = [

                    'all' =>
                        'All',

                    'pending' =>
                        'Pending',

                    'success' =>
                        'Successful',

                    'failed' =>
                        'Failed',

                    'refunded' =>
                        'Refunded'
                ];

                ?>


                <?php foreach (
                    $filterLabels
                    as $filterKey => $label
                ): ?>


                    <a
                        href="admin-payments.php?status=<?= e($filterKey); ?>"
                        class="filter <?= $statusFilter === $filterKey ? 'active' : ''; ?>"
                    >

                        <?= e($label); ?>

                        <span class="filter-count">

                            <?= number_format(
                                $counts[$filterKey]
                            ); ?>

                        </span>

                    </a>


                <?php endforeach; ?>


            </div>


            <!-- SEARCH -->

            <form
                method="get"
                class="search-form"
            >


                <?php if (
                    $statusFilter !== 'all'
                ): ?>

                    <input
                        type="hidden"
                        name="status"
                        value="<?= e($statusFilter); ?>"
                    >

                <?php endif; ?>


                <input
                    type="text"
                    name="search"
                    class="search-box"
                    value="<?= e($search); ?>"
                    placeholder="Booking, UTR, customer..."
                >


                <button
                    type="submit"
                    class="search-button"
                    title="Search"
                >

                    <i class="fa-solid fa-magnifying-glass"></i>

                </button>


            </form>


        </div>


        <?php if (!$payments): ?>


            <div class="empty">


                <div class="empty-icon">

                    <i class="fa-solid fa-credit-card"></i>

                </div>


                <h3>
                    No payments found
                </h3>


                <p>

                    <?php if (
                        $statusFilter === 'pending'
                    ): ?>

                        There are currently no payments waiting for verification.

                    <?php else: ?>

                        No payment records match your current filter.

                    <?php endif; ?>

                </p>


            </div>


        <?php else: ?>


        <div class="table-wrap">


            <table>


                <thead>

                <tr>

                    <th>
                        PAYMENT
                    </th>

                    <th>
                        BOOKING
                    </th>

                    <th>
                        CUSTOMER
                    </th>

                    <th>
                        PACKAGE
                    </th>

                    <th>
                        TRANSACTION / UTR
                    </th>

                    <th>
                        METHOD
                    </th>

                    <th>
                        AMOUNT
                    </th>

                    <th>
                        STATUS
                    </th>

                    <th>
                        SUBMITTED
                    </th>

                    <th>
                        ACTION
                    </th>

                </tr>

                </thead>


                <tbody>


                <?php foreach (
                    $payments
                    as $payment
                ): ?>


                    <tr>


                        <td>

                            <strong>
                                #<?= (int)$payment['id']; ?>
                            </strong>

                        </td>


                        <td>

                            <div class="booking-ref">

                                <?= e(
                                    $payment['booking_number']
                                ); ?>

                            </div>

                            <div
                                style="
                                    margin-top:3px;
                                    color:#8994a3;
                                    font-size:8px;
                                "
                            >

                                Booking ID:
                                <?= (int)$payment['booking_id']; ?>

                            </div>

                        </td>


                        <td>

                            <div class="customer">

                                <strong>

                                    <?= e(
                                        $payment['customer_name']
                                    ); ?>

                                </strong>


                                <span>

                                    <?= e(
                                        $payment['customer_email']
                                    ); ?>

                                </span>


                                <span>

                                    <?= e(
                                        $payment['customer_mobile']
                                    ); ?>

                                </span>

                            </div>

                        </td>


                        <td>

                            <div class="package-name">

                                <?= e(
                                    $payment['package_title']
                                    ?: 'Travel Package'
                                ); ?>

                            </div>


                            <?php if (
                                !empty(
                                    $payment['destination_name']
                                )
                            ): ?>

                                <div
                                    style="
                                        margin-top:4px;
                                        color:#8994a3;
                                        font-size:8px;
                                    "
                                >

                                    <i class="fa-solid fa-location-dot"></i>

                                    <?= e(
                                        $payment['destination_name']
                                    ); ?>

                                </div>

                            <?php endif; ?>

                        </td>


                        <td>

                            <div class="transaction">

                                <?= e(
                                    $payment['transaction_id']
                                    ?: '-'
                                ); ?>

                            </div>

                        </td>


                        <td>

                            <strong>

                                <?= e(
                                    $payment['payment_method']
                                    ?: '-'
                                ); ?>

                            </strong>


                            <?php if (
                                !empty(
                                    $payment['payment_gateway']
                                )
                            ): ?>

                                <div
                                    style="
                                        margin-top:3px;
                                        color:#8994a3;
                                        font-size:8px;
                                    "
                                >

                                    <?= e(
                                        $payment['payment_gateway']
                                    ); ?>

                                </div>

                            <?php endif; ?>

                        </td>


                        <td>

                            <div class="amount">

                                <?= e($currencySymbol); ?>

                                <?= number_format(
                                    (float)$payment['amount'],
                                    2
                                ); ?>

                            </div>


                            <div
                                style="
                                    margin-top:3px;
                                    color:#8994a3;
                                    font-size:8px;
                                "
                            >

                                Total:

                                <?= e($currencySymbol); ?>

                                <?= number_format(
                                    (float)$payment['total_amount'],
                                    2
                                ); ?>

                            </div>

                        </td>


                        <td>

                            <span
                                class="status status-<?= e($payment['status']); ?>"
                            >

                                <?= e(
                                    ucfirst(
                                        $payment['status']
                                    )
                                ); ?>

                            </span>

                        </td>


                        <td>

                            <?= date(
                                'd M Y',
                                strtotime(
                                    $payment['created_at']
                                )
                            ); ?>


                            <div
                                style="
                                    margin-top:3px;
                                    color:#8994a3;
                                    font-size:8px;
                                "
                            >

                                <?= date(
                                    'h:i A',
                                    strtotime(
                                        $payment['created_at']
                                    )
                                ); ?>

                            </div>

                        </td>


                        <td>


                            <div class="actions">

                                <a
                                    href="admin-payment-details.php?id=<?= (int)$payment['id']; ?>"
                                    class="action-btn view-details"
                                    title="View complete payment details"
                                >
                                    <i class="fa-solid fa-eye"></i>
                                    View
                                </a>


                            <?php if (
                                $payment['status']
                                ===
                                'pending'
                            ): ?>


                                    <!-- APPROVE -->

                                    <form
                                        method="post"
                                        class="action-form approve-form"
                                    >

                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= e($csrfToken); ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="payment_id"
                                            value="<?= (int)$payment['id']; ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="approve"
                                        >

                                        <input
                                            type="hidden"
                                            name="return_filter"
                                            value="<?= e($statusFilter); ?>"
                                        >


                                        <button
                                            type="submit"
                                            class="action-btn approve"
                                        >

                                            <i class="fa-solid fa-check"></i>

                                            Approve

                                        </button>


                                    </form>


                                    <!-- REJECT -->

                                    <form
                                        method="post"
                                        class="action-form reject-form"
                                    >

                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= e($csrfToken); ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="payment_id"
                                            value="<?= (int)$payment['id']; ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="reject"
                                        >

                                        <input
                                            type="hidden"
                                            name="return_filter"
                                            value="<?= e($statusFilter); ?>"
                                        >


                                        <button
                                            type="submit"
                                            class="action-btn reject"
                                        >

                                            <i class="fa-solid fa-xmark"></i>

                                            Reject

                                        </button>


                                    </form>


                            <?php else: ?>


                                <div class="processed">


                                    <?php if (
                                        $payment['status']
                                        ===
                                        'success'
                                    ): ?>

                                        <i class="fa-solid fa-circle-check"></i>

                                        Verified

                                        <?php if (
                                            !empty(
                                                $payment['paid_at']
                                            )
                                        ): ?>

                                            <div
                                                style="
                                                    margin-top:3px;
                                                    font-size:8px;
                                                "
                                            >

                                                <?= date(
                                                    'd M Y',
                                                    strtotime(
                                                        $payment['paid_at']
                                                    )
                                                ); ?>

                                            </div>

                                        <?php endif; ?>


                                    <?php elseif (
                                        $payment['status']
                                        ===
                                        'failed'
                                    ): ?>

                                        <i class="fa-solid fa-circle-xmark"></i>

                                        Rejected


                                    <?php else: ?>

                                        <?= e(
                                            ucfirst(
                                                $payment['status']
                                            )
                                        ); ?>

                                    <?php endif; ?>


                                </div>


                            <?php endif; ?>


                            </div>


                        </td>


                    </tr>


                <?php endforeach; ?>


                </tbody>


            </table>


        </div>


        <?php endif; ?>


    </section>


</div>


</main>


<script>

/*
|--------------------------------------------------------------------------
| MOBILE SIDEBAR
|--------------------------------------------------------------------------
*/

const sidebar =
    document.getElementById(
        'sidebar'
    );

const mobileMenu =
    document.getElementById(
        'mobileMenu'
    );

const sidebarOverlay =
    document.getElementById(
        'sidebarOverlay'
    );


function openSidebar() {

    sidebar.classList.add(
        'open'
    );

    sidebarOverlay.classList.add(
        'show'
    );
}


function closeSidebar() {

    sidebar.classList.remove(
        'open'
    );

    sidebarOverlay.classList.remove(
        'show'
    );
}


if (mobileMenu) {

    mobileMenu.addEventListener(
        'click',
        function () {

            if (
                sidebar.classList.contains(
                    'open'
                )
            ) {

                closeSidebar();

            } else {

                openSidebar();
            }
        }
    );
}


if (sidebarOverlay) {

    sidebarOverlay.addEventListener(
        'click',
        closeSidebar
    );
}


window.addEventListener(
    'resize',
    function () {

        if (
            window.innerWidth > 850
        ) {

            closeSidebar();
        }
    }
);


/*
|--------------------------------------------------------------------------
| APPROVE CONFIRMATION
|--------------------------------------------------------------------------
*/

document
.querySelectorAll(
    '.approve-form'
)
.forEach(
    function(form) {

        form.addEventListener(
            'submit',
            function(event) {

                const confirmed =
                    confirm(
                        'Have you verified this transaction in your bank/UPI account?\n\nApprove this payment only if the money has actually been received.'
                    );

                if (!confirmed) {

                    event.preventDefault();

                    return;
                }


                const button =
                    form.querySelector(
                        'button'
                    );

                if (button) {

                    button.disabled = true;

                    button.innerHTML =
                        '<i class="fa-solid fa-spinner fa-spin"></i> Approving...';
                }
            }
        );
    }
);


/*
|--------------------------------------------------------------------------
| REJECT CONFIRMATION
|--------------------------------------------------------------------------
*/

document
.querySelectorAll(
    '.reject-form'
)
.forEach(
    function(form) {

        form.addEventListener(
            'submit',
            function(event) {

                const confirmed =
                    confirm(
                        'Reject this payment submission?\n\nThe customer will be able to submit another transaction.'
                    );

                if (!confirmed) {

                    event.preventDefault();

                    return;
                }


                const button =
                    form.querySelector(
                        'button'
                    );

                if (button) {

                    button.disabled = true;

                    button.innerHTML =
                        '<i class="fa-solid fa-spinner fa-spin"></i> Rejecting...';
                }
            }
        );
    }
);

</script>








<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>