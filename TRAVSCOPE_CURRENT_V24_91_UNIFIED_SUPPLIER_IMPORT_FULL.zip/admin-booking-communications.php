<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/communication-functions.php';

$docFunctions = __DIR__ . '/document-functions.php';
if (is_file($docFunctions)) require_once $docFunctions;

if (empty($_SESSION['admin_id'])) redirect(BASE_URL . 'admin-login.php');
$adminId=(int)$_SESSION['admin_id'];
$stmt=$pdo->prepare("SELECT id,name,email,role,status FROM admins WHERE id=? LIMIT 1");
$stmt->execute([$adminId]);
$admin=$stmt->fetch(PDO::FETCH_ASSOC) ?: null;
if(!$admin || (string)$admin['status']!=='active'){unset($_SESSION['admin_id']);redirect(BASE_URL.'admin-login.php');}

$bookingId=max(0,(int)($_GET['id'] ?? $_POST['booking_id'] ?? 0));
if($bookingId<=0) redirect(BASE_URL.'admin-bookings.php');
if(!tsCommReady($pdo)){http_response_code(503);exit('Customer Communication Center SQL is not installed yet.');}

$booking=tsCommBooking($pdo,$bookingId);
$trip=tsCommTripContext($pdo,$bookingId);

if(empty($_SESSION['admin_booking_comm_csrf'])) $_SESSION['admin_booking_comm_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['admin_booking_comm_csrf'];
$error='';$success='';
if(!empty($_SESSION['admin_booking_comm_success'])){$success=(string)$_SESSION['admin_booking_comm_success'];unset($_SESSION['admin_booking_comm_success']);}

if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!hash_equals($csrf,(string)($_POST['csrf_token'] ?? ''))){$error='Security verification failed. Refresh and try again.';}
    else{
        $action=(string)($_POST['action'] ?? '');
        try{
            if($action==='sync_email'){
                $result=tsCommSyncEmailReplies($pdo,$bookingId);
                $_SESSION['admin_booking_comm_success']=$result['message'] ?: 'Email synchronization completed.';
            }elseif($action==='send_manual'){
                $channel=(string)($_POST['channel'] ?? 'email');
                $templateKey=trim((string)($_POST['template_key'] ?? '')) ?: null;
                $subject=(string)($_POST['subject'] ?? '');
                $body=(string)($_POST['body_text'] ?? '');
                if($channel==='email'){
                    tsCommSendEmail($pdo,$bookingId,$subject,$body,$adminId,$templateKey);
                    $_SESSION['admin_booking_comm_success']='Customer email sent and stored in the Booking timeline.';
                }elseif($channel==='whatsapp'){
                    $wa=tsCommRecordWhatsApp($pdo,$bookingId,$body,$adminId,$templateKey);
                    header('Location: '.$wa['url']);exit;
                }elseif($channel==='whatsapp_inbound'){
                    tsCommRecordInboundWhatsApp($pdo,$bookingId,$body,$adminId);
                    $_SESSION['admin_booking_comm_success']='Customer WhatsApp reply recorded in the Booking timeline.';
                }elseif($channel==='internal'){
                    tsCommInternalNote($pdo,$bookingId,$body,$adminId);
                    $_SESSION['admin_booking_comm_success']='Internal note added. Customer cannot see this note.';
                }else throw new RuntimeException('Select Email, WhatsApp, Customer WhatsApp Reply or Internal Note.');
            }elseif($action==='send_job'){
                tsCommSendJob($pdo,max(0,(int)($_POST['job_id'] ?? 0)),$adminId,true);
                $_SESSION['admin_booking_comm_success']='Communication job sent.';
            }elseif($action==='run_due'){
                tsCommRefreshJobs($pdo,$bookingId);
                $result=tsCommRunDueJobs($pdo,$bookingId,$adminId,20);
                $_SESSION['admin_booking_comm_success']='Due communications processed: '.$result['sent'].' sent'.($result['failed']?(', '.$result['failed'].' failed'):'').'.';
            }elseif($action==='save_template'){
                tsCommSaveTemplate($pdo,$adminId,(string)($_POST['template_key'] ?? ''),(string)($_POST['template_name'] ?? ''),(string)($_POST['subject_template'] ?? ''),(string)($_POST['body_template'] ?? ''),!empty($_POST['is_active']));
                $_SESSION['admin_booking_comm_success']='Message template saved.';
            }else throw new RuntimeException('Invalid Communication Center action.');

            redirect(BASE_URL.'admin-booking-communications.php?id='.$bookingId);
        }catch(RuntimeException $e){$error=$e->getMessage();}
        catch(Throwable $e){error_log('Admin Booking Communication Center: '.$e->getMessage());$error='Unable to complete communication action: '.$e->getMessage();}
    }
}

tsCommRefreshJobs($pdo,$bookingId);
$jobs=tsCommJobs($pdo,$bookingId);
$templates=tsCommTemplates($pdo,false);
$timeline=tsCommTimeline($pdo,$bookingId,true);
$summary=tsCommSummary($pdo,$bookingId);

$templatePayload=[];
foreach($templates as $template){
    if(empty($template['is_active']))continue;
    try{$render=tsCommRenderTemplate($pdo,$bookingId,(string)$template['template_key']);}
    catch(Throwable $e){$render=['subject'=>(string)($template['subject_template']??''),'body'=>(string)$template['body_template']];}
    $templatePayload[(string)$template['template_key']]=['name'=>(string)$template['template_name'],'subject'=>(string)$render['subject'],'body'=>(string)$render['body']];
}

function abcDate(?string $v): string{if(!$v)return '-';$ts=strtotime($v);return $ts?date('d M Y, h:i A',$ts):'-';}
function abcExcerpt(string $v,int $max=160): string{$v=trim(preg_replace('/\s+/',' ',$v)??$v);return mb_strlen($v)>$max?mb_substr($v,0,$max).'…':$v;}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Customer Communication Center | TRAVSCOPE Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:66px;padding:10px 4%;display:flex;justify-content:space-between;align-items:center;gap:10px;background:#fff;border-bottom:1px solid #dfe7f0;position:sticky;top:0;z-index:20}.brand{font-weight:900}.brand span{color:#2563eb}.btn{display:inline-flex;align-items:center;gap:6px;border:1px solid #cbd5e1;border-radius:9px;padding:8px 10px;background:#fff;color:#334155;text-decoration:none;font-size:9px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.btn.good{background:#059669;border-color:#059669;color:#fff}.btn.wa{background:#16a34a;border-color:#16a34a;color:#fff}.btn.warn{background:#fff7ed;border-color:#fed7aa;color:#c2410c}.wrap{max-width:1280px;margin:20px auto;padding:0 13px}.hero{padding:17px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff);display:flex;justify-content:space-between;gap:15px;align-items:flex-start}.hero h1{margin:0;font-size:20px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px;line-height:1.5}.notice{margin-top:10px;padding:10px 12px;border-radius:10px;font-size:10px}.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#047857}.err{background:#fef2f2;border:1px solid #fecaca;color:#b91c1c}.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:11px}.stat{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.stat span{display:block;color:#64748b;font-size:7.5px;font-weight:900;text-transform:uppercase}.stat strong{display:block;margin-top:4px;font-size:13px}.grid{display:grid;grid-template-columns:.9fr 1.1fr;gap:11px;margin-top:11px}.card{background:#fff;border:1px solid #dfe7f0;border-radius:13px;overflow:hidden}.card.full{grid-column:1/-1}.head{padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff;display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.head h2{margin:0;font-size:12px}.head p{margin:4px 0 0;color:#64748b;font-size:8.5px;line-height:1.45}.body{padding:11px}label{display:block;margin-bottom:4px;color:#475569;font-size:8px;font-weight:900}input,select,textarea{width:100%;min-height:34px;padding:7px 8px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;font-size:9px}textarea{min-height:145px;resize:vertical}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}.full{grid-column:1/-1}.job{padding:9px;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:7px;background:#fff}.job-top{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.job strong{font-size:10px}.job small{display:block;margin-top:3px;color:#64748b;font-size:8px}.pill{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:7.5px;font-weight:900}.pill.pending{background:#fff7ed;color:#c2410c}.pill.sent{background:#dcfce7;color:#166534}.pill.failed{background:#fef2f2;color:#b91c1c}.pill.cancelled,.pill.skipped{background:#f1f5f9;color:#64748b}.timeline{display:grid;gap:8px}.msg{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.msg.outbound{border-left:4px solid #2563eb}.msg.inbound{border-left:4px solid #16a34a}.msg.internal{border-left:4px solid #94a3b8;background:#f8fafc}.msg.quote{background:#fffbeb;border-color:#fde68a}.msg-top{display:flex;justify-content:space-between;gap:8px}.msg-top strong{font-size:10px}.msg-top small{font-size:8px;color:#64748b}.msg pre{white-space:pre-wrap;font:inherit;font-size:9px;line-height:1.55;margin:8px 0 0}.quoted{margin-top:7px}.quoted summary{cursor:pointer;color:#64748b;font-size:8px;font-weight:900}.quoted pre{padding:8px;border-radius:8px;background:#f8fafc;color:#64748b}.template-card{padding:9px;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:7px}.template-card summary{cursor:pointer;font-size:9px;font-weight:900}.template-card textarea{min-height:110px}.small-note{padding:9px;border:1px solid #dbeafe;border-radius:9px;background:#eff6ff;color:#1d4ed8;font-size:8.5px;line-height:1.5}.actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:7px}
@media(max-width:950px){.grid{grid-template-columns:1fr}.card.full{grid-column:auto}.stats{grid-template-columns:1fr 1fr}}@media(max-width:620px){.top,.hero{align-items:flex-start;flex-direction:column}.form-grid{grid-template-columns:1fr}.full{grid-column:auto}.stats{grid-template-columns:1fr}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head>
<body>
<header class="top"><div class="brand">TRAV<span>SCOPE</span> · COMMUNICATION CENTER</div><div style="display:flex;gap:7px;flex-wrap:wrap"><a class="btn" href="<?= e(BASE_URL.'admin-communications.php'); ?>"><i class="fa-solid fa-list-check"></i> All Communication Tasks</a><a class="btn" target="_blank" href="<?= e(BASE_URL.'booking-communications.php?booking='.$bookingId); ?>"><i class="fa-solid fa-user"></i> Customer View</a><a class="btn primary" href="<?= e(BASE_URL.'admin-booking-details.php?id='.$bookingId.'#customer-communication-center'); ?>"><i class="fa-solid fa-arrow-left"></i> Back to Booking</a></div></header>
<main class="wrap">
<section class="hero"><div><h1>Customer Communication & Automation Center</h1><p>Booking <?= e((string)$booking['booking_number']); ?> · <?= e((string)($booking['customer_name'] ?? 'Customer')); ?><?php if(!empty($trip['trip_code'])): ?> · Trip <?= e((string)$trip['trip_code']); ?><?php endif; ?><?php if(!empty($trip['owner_name'])): ?> · CRM Owner <?= e((string)$trip['owner_name']); ?><?php endif; ?> · Email, WhatsApp handoff, internal notes, quotation history and scheduled customer reminders.</p></div><form method="post"><input type="hidden" name="booking_id" value="<?= $bookingId; ?>"><input type="hidden" name="csrf_token" value="<?= e($csrf); ?>"><input type="hidden" name="action" value="sync_email"><button class="btn good" type="submit"><i class="fa-solid fa-rotate"></i> Sync Email Replies</button></form></section>
<?php if($success): ?><div class="notice ok"><?= e($success); ?></div><?php endif; ?>
<?php if($error): ?><div class="notice err"><?= e($error); ?></div><?php endif; ?>
<div class="stats"><div class="stat"><span>Due Automation Tasks</span><strong><?= (int)$summary['due']; ?></strong></div><div class="stat"><span>Upcoming Tasks</span><strong><?= (int)$summary['upcoming']; ?></strong></div><div class="stat"><span>Customer Replies Synced</span><strong><?= (int)$summary['inbound']; ?></strong></div><div class="stat"><span>Last Booking Contact</span><strong style="font-size:10px"><?= !empty($summary['last']) ? e(abcDate((string)$summary['last']['at_time'])) : 'None'; ?></strong></div></div>
<div class="grid">
<section class="card"><div class="head"><div><h2>Compose Customer Message</h2><p>Email sends through existing SMTP. WhatsApp opens the customer chat and records a handoff; delivery cannot be independently confirmed without a WhatsApp API connection. Internal Note stays Admin-only.</p></div></div><div class="body">
<form method="post" id="commComposer"><input type="hidden" name="booking_id" value="<?= $bookingId; ?>"><input type="hidden" name="csrf_token" value="<?= e($csrf); ?>"><input type="hidden" name="action" value="send_manual"><div class="form-grid"><div><label>Channel</label><select name="channel" id="commChannel"><option value="email">Email</option><option value="whatsapp">WhatsApp to Customer</option><option value="whatsapp_inbound">Record Customer WhatsApp Reply</option><option value="internal">Internal Note</option></select></div><div><label>Reusable Template</label><select name="template_key" id="commTemplate"><option value="">Custom Message</option><?php foreach($templates as $template): if(empty($template['is_active']))continue; ?><option value="<?= e((string)$template['template_key']); ?>"><?= e((string)$template['template_name']); ?></option><?php endforeach; ?></select></div><div class="full" id="commSubjectWrap"><label>Email Subject</label><input name="subject" id="commSubject" value="Booking <?= e((string)$booking['booking_number']); ?>"></div><div class="full"><label>Message</label><textarea name="body_text" id="commBody" required></textarea></div></div><div class="actions"><button class="btn primary" type="submit" id="commSend"><i class="fa-solid fa-paper-plane"></i> Send / Record</button></div></form>
<div class="small-note" style="margin-top:10px">Email subjects automatically include <?= e(tsCommThreadTag($bookingId)); ?> so customer replies can be synchronized into this exact Booking thread.</div>
</div></section>

<section class="card"><div class="head"><div><h2>Automation Queue</h2><p>Generated from live payment installments, missing traveller documents, departure date, Final Voucher, Final Document Pack and completed-trip review follow-up.</p></div><form method="post"><input type="hidden" name="booking_id" value="<?= $bookingId; ?>"><input type="hidden" name="csrf_token" value="<?= e($csrf); ?>"><input type="hidden" name="action" value="run_due"><button class="btn good" type="submit">Run Due Now</button></form></div><div class="body">
<?php $shown=0; foreach($jobs as $job): if($shown>=12)break; $shown++; $isDue=in_array((string)$job['status'],['pending','failed'],true)&&strtotime((string)$job['due_at'])<=time(); ?>
<div class="job"><div class="job-top"><div><strong><?= e((string)($job['template_name'] ?: $job['job_type'])); ?></strong><small><?= e(abcDate((string)$job['due_at'])); ?> · <?= e(ucwords(str_replace('_',' ',(string)$job['job_type']))); ?><?php if(!empty($trip['owner_name'])): ?> · Owner <?= e((string)$trip['owner_name']); ?><?php endif; ?><?php if(!empty($job['last_error'])): ?> · <?= e(abcExcerpt((string)$job['last_error'],90)); ?><?php endif; ?></small></div><span class="pill <?= e((string)$job['status']); ?>"><?= e(strtoupper((string)$job['status'])); ?></span></div><?php if(in_array((string)$job['status'],['pending','failed'],true)): ?><form method="post" style="margin-top:7px"><input type="hidden" name="booking_id" value="<?= $bookingId; ?>"><input type="hidden" name="csrf_token" value="<?= e($csrf); ?>"><input type="hidden" name="action" value="send_job"><input type="hidden" name="job_id" value="<?= (int)$job['id']; ?>"><button class="btn <?= $isDue?'good':''; ?>" type="submit"><?= $isDue?'Send Due Message':'Send Early'; ?></button></form><?php endif; ?></div>
<?php endforeach; if(!$jobs): ?><div class="small-note">No communication automation jobs are active for this Booking.</div><?php endif; ?>
<div class="small-note" style="margin-top:8px"><strong>Unattended automation:</strong> the included CLI-only <code>communication-cron.php</code> can be scheduled in cPanel/cron. It will not run from a browser.</div>
</div></section>

<section class="card full"><div class="head"><div><h2>Unified Customer Timeline</h2><p>The accepted quotation email conversation is preserved as pre-booking history. Booking emails, customer email replies, WhatsApp handoffs and Admin internal notes continue underneath it.</p></div><span class="pill pending"><?= count($timeline); ?> EVENTS</span></div><div class="body"><div class="timeline">
<?php if(!$timeline): ?><div class="small-note">No communication history yet.</div><?php endif; ?>
<?php foreach($timeline as $message): $direction=(string)($message['direction'] ?? 'outbound'); $split=tsCommSplitQuotedReply((string)($message['body_text'] ?? '')); ?>
<div class="msg <?= e($direction); ?> <?= ($message['source']??'')==='quotation'?'quote':''; ?>"><div class="msg-top"><div><strong><?php if(($message['source']??'')==='quotation'): ?>PRE-BOOKING QUOTATION · <?php endif; ?><?= e(strtoupper((string)($message['channel'] ?? 'email'))); ?> · <?= e(strtoupper($direction)); ?></strong><?php if(!empty($message['subject'])): ?><small style="display:block;margin-top:3px"><?= e((string)$message['subject']); ?></small><?php endif; ?></div><small><?= e(abcDate((string)($message['timeline_at'] ?? $message['sent_at'] ?? $message['created_at'] ?? ''))); ?> · <?= e(strtoupper((string)($message['delivery_status'] ?? ''))); ?></small></div><pre><?= e($split['current']!==''?$split['current']:'(No current message text)'); ?></pre><?php if($split['quoted']!==''): ?><details class="quoted"><summary>Show quoted email history</summary><pre><?= e($split['quoted']); ?></pre></details><?php endif; ?></div>
<?php endforeach; ?>
</div></div></section>

<section class="card full"><div class="head"><div><h2>Reusable Message Templates</h2><p>System templates can be adjusted here. Placeholders such as {{customer_name}}, {{booking_number}}, {{payment_link}}, {{documents_link}}, {{voucher_link}} and {{document_pack_link}} are rendered per Booking.</p></div></div><div class="body">
<?php foreach($templates as $template): ?><details class="template-card"><summary><?= e((string)$template['template_name']); ?> · <?= e((string)$template['template_key']); ?><?= empty($template['is_active'])?' · INACTIVE':''; ?></summary><form method="post" style="margin-top:8px"><input type="hidden" name="booking_id" value="<?= $bookingId; ?>"><input type="hidden" name="csrf_token" value="<?= e($csrf); ?>"><input type="hidden" name="action" value="save_template"><input type="hidden" name="template_key" value="<?= e((string)$template['template_key']); ?>"><div class="form-grid"><div><label>Template Name</label><input name="template_name" value="<?= e((string)$template['template_name']); ?>" required></div><div><label>Active</label><label style="margin-top:9px"><input type="checkbox" name="is_active" value="1" <?= !empty($template['is_active'])?'checked':''; ?> style="width:auto;min-height:auto"> Enabled</label></div><div class="full"><label>Email Subject</label><input name="subject_template" value="<?= e((string)($template['subject_template'] ?? '')); ?>"></div><div class="full"><label>Template Body</label><textarea name="body_template" required><?= e((string)$template['body_template']); ?></textarea></div></div><button class="btn primary" type="submit" style="margin-top:7px">Save Template</button></form></details><?php endforeach; ?>
</div></section>
</div>
</main>
<script>
const commTemplates=<?= json_encode($templatePayload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;
const templateSelect=document.getElementById('commTemplate');const channel=document.getElementById('commChannel');const subject=document.getElementById('commSubject');const body=document.getElementById('commBody');const subjectWrap=document.getElementById('commSubjectWrap');
function syncChannel(){subjectWrap.style.display=channel.value==='email'?'':'none';}
channel.addEventListener('change',syncChannel);syncChannel();
templateSelect.addEventListener('change',function(){const t=commTemplates[this.value];if(!t)return;subject.value=t.subject||'';body.value=t.body||'';});
</script>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
