<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/supplier-functions.php';
require_once __DIR__ . '/supplier-document-functions.php';
require_once __DIR__ . '/supplier-contract-inventory-functions.php';

if (empty($_SESSION['admin_id'])) { header('Location: '.BASE_URL.'login.php'); exit; }
$adminId=(int)$_SESSION['admin_id'];
$stmt=$pdo->prepare("SELECT id,name,email,role,status FROM admins WHERE id=? LIMIT 1");$stmt->execute([$adminId]);$admin=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$admin || ($admin['status']??'')!=='active'){unset($_SESSION['admin_id']);header('Location: '.BASE_URL.'login.php');exit;}
function sciE($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
try { tsSupplierDocumentEnsureSchema($pdo); } catch (Throwable $ignored) {}
if(!tsSupplierDocumentCenterReady($pdo) || !tsSCIReady($pdo)){http_response_code(503);exit('Supplier Document tables are ready, but Step 11B Hotel/Vehicle Inventory SQL is still required.');}

$versionId=max(0,(int)($_GET['version_id']??$_POST['version_id']??0));
$version=tsSCIGetVersion($pdo,$versionId);
if(!$version){http_response_code(404);exit('Supplier contract version not found.');}

if(empty($_SESSION['supplier_inventory_csrf']))$_SESSION['supplier_inventory_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['supplier_inventory_csrf'];
$success=(string)($_SESSION['supplier_inventory_success']??'');$error=(string)($_SESSION['supplier_inventory_error']??'');
unset($_SESSION['supplier_inventory_success'],$_SESSION['supplier_inventory_error']);

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        if(!hash_equals($csrf,(string)($_POST['csrf']??'')))throw new RuntimeException('Security verification failed.');
        $action=trim((string)($_POST['action']??''));
        if($action==='build_inventory'){
            $result=tsSCIBuildInventory($pdo,$versionId,$adminId);
            $_SESSION['supplier_inventory_success']='Supplier source parsed: '.$result['hotels'].' hotel alternatives and '.$result['vehicle_rules'].' vehicle/category rules prepared for review. '.($result['matched_hotels']?'Existing Hotel Master matches: '.$result['matched_hotels'].'.':'');
        }elseif($action==='auto_match'){
            $count=tsSCIAutoMatchInventory($pdo,$versionId,$adminId);
            $_SESSION['supplier_inventory_success']=$count.' additional supplier hotel row(s) matched to the existing Hotel Master.';
        }elseif($action==='sync_hotels'){
            $r=tsSCISyncEligibleHotelsToMaster($pdo,$versionId,$adminId);
            $_SESSION['supplier_inventory_success']='Hotel Master sync complete. Created '.$r['created'].' new 3★/4★/5★ hotel(s); matched '.$r['matched'].' existing hotel(s). Budget/Standard/2★ rows remain safely in Supplier Inventory.';
        }elseif($action==='manual_map'){
            $inventoryId=max(0,(int)($_POST['inventory_id']??0));$hotelId=max(0,(int)($_POST['hotel_id']??0));
            if($inventoryId<=0||$hotelId<=0)throw new RuntimeException('Select a valid Hotel Master record.');
            tsSCIManualMapHotel($pdo,$inventoryId,$hotelId,$adminId);
            $_SESSION['supplier_inventory_success']='Supplier hotel mapped to Hotel Master and the alias was saved for future supplier sheets.';
        }elseif($action==='add_supplier_hotel'){
            $newId=tsSCIAddSupplierHotelInventory($pdo,$versionId,[
                'city'=>$_POST['city']??'',
                'supplier_category'=>$_POST['supplier_category']??'',
                'hotel_name'=>$_POST['hotel_name']??'',
                'room_type'=>$_POST['room_type']??'',
                'meal_plan'=>$_POST['meal_plan']??'',
            ],$adminId);
            $_SESSION['supplier_inventory_success']='Location-wise supplier hotel added to this contract inventory (#'.$newId.'). It will now be available to itinerary/quotation hotel allocation after inventory approval.';
        }elseif($action==='add_supplier_vehicle'){
            $newId=tsSCIAddSupplierVehicleRule($pdo,$versionId,[
                'city'=>$_POST['vehicle_city']??'',
                'supplier_category'=>$_POST['vehicle_supplier_category']??'',
                'vehicle_type'=>$_POST['vehicle_type']??'',
                'pax_min'=>$_POST['vehicle_pax_min']??'',
                'pax_max'=>$_POST['vehicle_pax_max']??'',
                'ac_basis'=>$_POST['vehicle_ac_basis']??'unspecified',
                'route_scope'=>$_POST['vehicle_route_scope']??'',
            ],$adminId);
            $_SESSION['supplier_inventory_success']='Supplier-level vehicle rule added (#'.$newId.'). CRM/Quotation will consume it only after inventory approval.';
        }elseif($action==='approve_inventory'){
            $r=tsSCIApproveInventory($pdo,$versionId,$adminId);
            $_SESSION['supplier_inventory_success']='Inventory approved: '.$r['hotels'].' hotel row(s) and '.$r['vehicles'].' vehicle rule(s) activated for this contract version. No customer price was changed.';
        }elseif($action==='set_destination'){
            $destinationId=max(0,(int)($_POST['destination_id']??0));
            $check=$pdo->prepare("SELECT id FROM destinations WHERE id=? LIMIT 1");$check->execute([$destinationId]);
            if(!$check->fetchColumn())throw new RuntimeException('Select a valid destination.');
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE supplier_documents SET destination_id=?,updated_at=NOW() WHERE id=?")->execute([$destinationId,(int)$version['supplier_document_id']]);
            $pdo->prepare("UPDATE supplier_contract_hotel_inventory SET destination_id=?,updated_by_admin_id=?,updated_at=NOW() WHERE contract_version_id=?")->execute([$destinationId,$adminId,$versionId]);
            $pdo->prepare("UPDATE supplier_contract_vehicle_rules SET destination_id=?,updated_by_admin_id=?,updated_at=NOW() WHERE contract_version_id=?")->execute([$destinationId,$adminId,$versionId]);
            $pdo->commit();
            if(function_exists('tsLocationSyncGeoCities')){try{tsLocationSyncGeoCities($pdo,$destinationId,$adminId,false);}catch(Throwable $ignored){}}
            $_SESSION['supplier_inventory_success']='Destination linked to this supplier source and its inventory. Child city/location list is ready for hotel and vehicle entry.';
        }else throw new RuntimeException('Invalid inventory action.');
        header('Location: admin-supplier-contract-inventory.php?version_id='.$versionId);exit;
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$_SESSION['supplier_inventory_error']=$e->getMessage();header('Location: admin-supplier-contract-inventory.php?version_id='.$versionId);exit;}
}

$version=tsSCIGetVersion($pdo,$versionId);$summary=tsSCIInventorySummary($pdo,$versionId);
$stmt=$pdo->prepare("SELECT * FROM supplier_contract_hotel_inventory WHERE contract_version_id=? ORDER BY FIELD(supplier_category,'5 Star Luxury','5 Star','4 Star Luxury','4 Star','3 Star','2 Star','Standard','Budget'),city,source_order,id");$stmt->execute([$versionId]);$hotelRows=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
$stmt=$pdo->prepare("SELECT * FROM supplier_contract_vehicle_rules WHERE contract_version_id=? ORDER BY FIELD(supplier_category,'5 Star Luxury','5 Star','4 Star Luxury','4 Star','3 Star','2 Star','Standard','Budget','All'),source_order,id");$stmt->execute([$versionId]);$vehicleRows=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
$destinations=$pdo->query("SELECT id,name,country FROM destinations WHERE status='active' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC)?:[];
$contractCities=[];if(!empty($version['destination_id'])&&function_exists('tsLocationEnsureSchema')){try{tsLocationEnsureSchema($pdo);$contractCities=tsLocationList($pdo,(int)$version['destination_id']);if(!$contractCities){$sync=tsLocationSyncGeoCities($pdo,(int)$version['destination_id'],$adminId,false);$contractCities=$sync['cities']??[];}}catch(Throwable $ignored){}}
$hotelMaster=[];
if(tsSCITableExists($pdo,'hotels')){
    $sql="SELECT h.id,h.hotel_name,h.city,h.star_category,d.name destination_name FROM hotels h JOIN destinations d ON d.id=h.destination_id WHERE h.status='active'";
    $params=[];
    if(!empty($version['destination_id'])){$sql.=" AND h.destination_id=?";$params[]=(int)$version['destination_id'];}
    $sql.=" ORDER BY h.star_category,h.city,h.hotel_name";$stmt=$pdo->prepare($sql);$stmt->execute($params);$hotelMaster=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
}
$grouped=[];foreach($hotelRows as $row){$key=$row['supplier_category'].'|'.$row['city'];$grouped[$key][]=$row;}

$categoryOrder=['5 Star Luxury'=>10,'5 Star'=>20,'4 Star Luxury'=>30,'4 Star'=>40,'3 Star'=>50,'2 Star'=>60,'Standard'=>70,'Budget'=>80];
$matrixCities=[];$matrixCategories=[];$hotelMatrix=[];$matrixRoomTypes=[];$matrixMealPlans=[];
foreach($hotelRows as $row){
    $city=trim((string)$row['city']);$cat=trim((string)$row['supplier_category']);
    if($city!==''&&!in_array($city,$matrixCities,true))$matrixCities[]=$city;
    if($cat!==''&&!in_array($cat,$matrixCategories,true))$matrixCategories[]=$cat;
    $hotelMatrix[$cat][$city][]=$row;
    $rt=trim((string)($row['room_type']??''));if($rt!=='')$matrixRoomTypes[$cat][$rt]=true;
    $mp=trim((string)($row['meal_plan']??''));if($mp!=='')$matrixMealPlans[$cat][$mp]=true;
}
usort($matrixCategories,static function($a,$b)use($categoryOrder){$wa=$categoryOrder[$a]??999;$wb=$categoryOrder[$b]??999;return $wa===$wb?strcmp($a,$b):($wa<=>$wb);});
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Supplier Contract Inventory | TRAVSCOPE</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,sans-serif}.sidebar{position:fixed;inset:0 auto 0 0;width:255px;background:#07192d;color:#fff;padding:20px 14px}.brand{color:#fff;text-decoration:none;font-weight:900;font-size:20px}.menu{margin-top:28px}.menu a{display:flex;gap:10px;color:#cbd5e1;text-decoration:none;padding:11px;border-radius:9px}.menu a:hover,.menu a.active{background:#12304e;color:#fff}.main{margin-left:255px}.top{height:70px;background:#fff;border-bottom:1px solid #e4e8ef;padding:0 25px;display:flex;align-items:center;justify-content:space-between}.page{padding:25px}.head{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;margin-bottom:17px}.head h1{margin:0 0 6px;font-size:25px}.muted{color:#728197}.actions{display:flex;gap:8px;flex-wrap:wrap}.btn{border:0;border-radius:10px;padding:10px 13px;text-decoration:none;font-weight:800;cursor:pointer;display:inline-flex;align-items:center;gap:7px}.primary{background:#0b74ff;color:#fff}.soft{background:#eaf2ff;color:#155daf}.good{background:#087f5b;color:#fff}.warn{background:#fff7ed;color:#9a3412}.panel{background:#fff;border:1px solid #e3e9f1;border-radius:15px;padding:18px;margin-bottom:16px;box-shadow:0 5px 22px rgba(7,25,45,.035)}.panel h2{margin:0 0 10px}.summary{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin-bottom:16px}.summary div{background:#fff;border:1px solid #e3e9f1;border-radius:13px;padding:13px}.summary small{display:block;color:#77859a;font-weight:800;text-transform:uppercase;font-size:9px}.summary strong{font-size:21px;display:block;margin-top:5px}.alert{padding:12px 14px;border-radius:10px;margin-bottom:14px}.ok{background:#e8f8ef;color:#17663e}.err{background:#fff0f0;color:#a23030}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.input,select{width:100%;border:1px solid #d8e0ea;border-radius:9px;padding:9px;background:#fff}.label{font-size:10px;font-weight:900;display:block;margin-bottom:5px}.inventory-group{border:1px solid #e5eaf1;border-radius:12px;margin:10px 0;overflow:hidden}.group-head{background:#f8fafc;padding:10px 12px;display:flex;justify-content:space-between;gap:10px}.hotel-row{display:grid;grid-template-columns:2.1fr .6fr 1fr 1.7fr;gap:8px;align-items:center;padding:9px 12px;border-top:1px solid #edf1f5;font-size:12px}.badge{display:inline-flex;border-radius:999px;padding:4px 7px;font-size:9px;font-weight:900;background:#eef4fb;color:#315c89}.badge.matched,.badge.created,.badge.active{background:#e9f8ef;color:#08714e}.badge.unmatched,.badge.review{background:#fff7ed;color:#a54b0b}.vehicles{width:100%;border-collapse:collapse;font-size:12px}.vehicles th,.vehicles td{text-align:left;border-bottom:1px solid #edf1f5;padding:9px}.note{padding:11px;background:#f8fafc;border-radius:10px;font-size:12px;line-height:1.5}.matrix-wrap{overflow:auto;border:1px solid #e3e9f1;border-radius:12px}.supplier-matrix{width:100%;min-width:980px;border-collapse:collapse;table-layout:fixed}.supplier-matrix th,.supplier-matrix td{border:1px solid #d8e0ea;vertical-align:top;padding:10px;font-size:12px;line-height:1.45}.supplier-matrix thead th{background:#fff7ed;color:#b45309;font-size:13px}.supplier-matrix tbody tr:nth-child(odd){background:#fffaf5}.supplier-matrix .cat-cell{width:145px;font-weight:900;color:#111827;background:#fff4dc}.supplier-matrix .meta-cell{width:155px;background:#fafafa}.matrix-hotel{display:flex;gap:6px;align-items:flex-start;padding:4px 0;border-bottom:1px dashed #e8edf3}.matrix-hotel:last-child{border-bottom:0}.matrix-state{display:inline-flex;align-items:center;justify-content:center;min-width:17px;height:17px;border-radius:50%;font-size:9px;font-weight:900;margin-top:1px}.matrix-state.ok{background:#dcfce7;color:#08714e}.matrix-state.review{background:#ffedd5;color:#b45309}.matrix-empty{color:#a0a9b5;font-style:italic}.matrix-legend{display:flex;gap:12px;flex-wrap:wrap;margin:9px 0 0;color:#728197;font-size:11px}.matrix-legend span{display:flex;align-items:center;gap:5px}@media(max-width:900px){.sidebar{position:static;width:auto}.main{margin-left:0}.summary,.grid{grid-template-columns:1fr}.hotel-row{grid-template-columns:1fr}.page{padding:14px}.head{display:block}.actions{margin-top:12px}}
</style>
<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v6">
</head><body>
<aside class="sidebar"><a class="brand" href="admin-dashboard.php">TRAVSCOPE</a><div class="menu"><a href="admin-suppliers.php"><i class="fa-solid fa-building"></i> Suppliers</a><a href="admin-supplier-documents.php" class="active"><i class="fa-solid fa-file-contract"></i> Supplier Documents</a><a href="admin-packages.php"><i class="fa-solid fa-suitcase"></i> Packages</a><a href="admin-dashboard.php"><i class="fa-solid fa-gauge"></i> Dashboard</a></div></aside>
<main class="main"><div class="top"><strong>Supplier Contract Intelligence</strong><span><?=sciE($admin['name'])?></span></div><div class="page">
<div class="head"><div><h1>Hotel + Vehicle Inventory</h1><div class="muted"><?=sciE($version['contract_code'])?> · <?=sciE($version['contract_name'])?> · <?=sciE($version['version_label']?:('V'.$version['version_no']))?> · <?=sciE($version['company_name'])?></div></div><div class="actions"><a class="btn soft" href="admin-supplier-document.php?id=<?=(int)$version['supplier_document_id']?>"><i class="fa-solid fa-arrow-left"></i> Source Document</a><a class="btn soft" href="admin-supplier-details.php?id=<?=(int)$version['supplier_id']?>#contracts-rates"><i class="fa-solid fa-building"></i> Supplier 360</a></div></div>
<?php if($success):?><div class="alert ok"><?=sciE($success)?></div><?php endif;?><?php if($error):?><div class="alert err"><?=sciE($error)?></div><?php endif;?>
<div class="summary"><div><small>Hotel Alternatives</small><strong><?=$summary['hotels']?></strong></div><div><small>Mapped to Hotel Master</small><strong><?=$summary['mapped']?></strong></div><div><small>Unmatched</small><strong><?=$summary['unmatched']?></strong></div><div><small>Vehicle Rules</small><strong><?=$summary['vehicles']?></strong></div><div><small>Inventory Status</small><strong><?=($summary['active_hotels']||$summary['active_vehicles'])?'ACTIVE':'REVIEW'?></strong></div></div>

<div class="panel"><h2>Step 11B Controls</h2><div class="note">This screen reads the supplier contract source document as supplier inventory. It does <strong>not</strong> publish website packages, change customer quotations or send anything to suppliers. Budget / Standard / 2★ categories are preserved in Supplier Inventory. 3★, 4★ and 5★ (including supplier labels such as 5 Star Deluxe/Premium/Luxury) can map safely to Hotel Master.</div><div class="actions" style="margin-top:12px">
<form method="post" onsubmit="return confirm('Rebuild review inventory from the original supplier source document? Existing ACTIVE inventory is preserved.');"><input type="hidden" name="csrf" value="<?=sciE($csrf)?>"><input type="hidden" name="version_id" value="<?=$versionId?>"><input type="hidden" name="action" value="build_inventory"><button class="btn primary"><i class="fa-solid fa-wand-magic-sparkles"></i> Build / Refresh From Source</button></form>
<?php if($summary['hotels']):?><form method="post"><input type="hidden" name="csrf" value="<?=sciE($csrf)?>"><input type="hidden" name="version_id" value="<?=$versionId?>"><input type="hidden" name="action" value="auto_match"><button class="btn soft"><i class="fa-solid fa-link"></i> Auto Match Existing Hotels</button></form><?php endif;?>
<?php if($summary['hotels'] && !empty($version['destination_id'])):?><form method="post" onsubmit="return confirm('Create only unmatched eligible 3★/4★/5★ properties in Hotel Master? 5 Star / 05 Star / Five Star / Deluxe / Premium / Luxury labels map to 5★. Existing normalized matches are reused.');"><input type="hidden" name="csrf" value="<?=sciE($csrf)?>"><input type="hidden" name="version_id" value="<?=$versionId?>"><input type="hidden" name="action" value="sync_hotels"><button class="btn soft"><i class="fa-solid fa-hotel"></i> Sync Eligible Hotels to Hotel Master</button></form><?php endif;?>
<?php if($summary['hotels']||$summary['vehicles']):?><form method="post" onsubmit="return confirm('Approve this reviewed hotel/vehicle inventory for the contract version? This still does not create customer selling prices.');"><input type="hidden" name="csrf" value="<?=sciE($csrf)?>"><input type="hidden" name="version_id" value="<?=$versionId?>"><input type="hidden" name="action" value="approve_inventory"><button class="btn good"><i class="fa-solid fa-circle-check"></i> Approve Inventory</button></form><?php endif;?></div></div>

<div class="panel"><h2>Destination Mapping</h2><form method="post"><input type="hidden" name="csrf" value="<?=sciE($csrf)?>"><input type="hidden" name="version_id" value="<?=$versionId?>"><input type="hidden" name="action" value="set_destination"><div class="grid"><div><label class="label">Supplier Contract Destination</label><select name="destination_id" required><option value="">Select destination</option><?php foreach($destinations as $d):?><option value="<?=(int)$d['id']?>" <?=(int)$version['destination_id']===(int)$d['id']?'selected':''?>><?=sciE($d['name'].($d['country']?' · '.$d['country']:''))?></option><?php endforeach;?></select></div><div style="align-self:end"><button class="btn soft"><i class="fa-solid fa-location-dot"></i> Save Destination</button></div></div></form></div>


<datalist id="contractCityList"><?php foreach($contractCities as $cl):?><option value="<?=sciE((string)$cl['location_name'])?>"><?php endforeach;?></datalist>
<div class="panel"><div class="note"><strong>Destination → City rule:</strong> the contract keeps its parent destination, while hotels and vehicles are saved under child cities. <?php if(!empty($version['destination_id'])):?><a href="admin-destination-locations.php?destination_id=<?=(int)$version['destination_id']?>" style="font-weight:800;color:#175da8">Manage / Sync Cities</a><?php endif;?></div></div>
<div class="panel">
<h2>Add Location-wise Supplier Hotel</h2>
<p class="muted">Add hotels here at the <strong>Supplier Contract</strong> level. CRM/Trip/Quotation screens only consume this approved inventory; they no longer create hotel inventory.</p>
<form method="post">
<input type="hidden" name="csrf" value="<?=sciE($csrf)?>">
<input type="hidden" name="version_id" value="<?=$versionId?>">
<input type="hidden" name="action" value="add_supplier_hotel">
<div class="grid">
<div><label class="label">Location / City</label><input class="input" name="city" list="contractCityList" placeholder="Choose city or type a new location" required><small class="muted">City belongs under the selected contract destination.</small></div>
<div><label class="label">Supplier Category</label><select name="supplier_category" required><option value="">Select category</option><?php foreach(['5 Star Luxury','5 Star','4 Star Luxury','4 Star','3 Star','2 Star','Standard','Budget'] as $cat):?><option value="<?=sciE($cat)?>"><?=sciE($cat)?></option><?php endforeach;?></select></div>
<div><label class="label">Supplier Hotel Name</label><input class="input" name="hotel_name" placeholder="Exact hotel name from supplier" required></div>
<div><label class="label">Room Type / Category</label><input class="input" name="room_type" placeholder="Deluxe / Premium / Standard"></div>
<div><label class="label">Meal Plan</label><input class="input" name="meal_plan" value="<?=sciE((string)($version['meal_plan']??$version['detected_meal_plan']??''))?>" placeholder="MAPAI / CPAI / AP"></div>
<div style="align-self:end"><button class="btn primary"><i class="fa-solid fa-plus"></i> Add to Supplier Inventory</button></div>
</div>
</form>
<?php if((string)($version['status']??'')==='active'):?><div class="note" style="margin-top:10px;color:#9a3412"><strong>Active version is immutable:</strong> create a new supplier contract version before adding/changing hotels.</div><?php endif;?>
</div>

<div class="panel"><h2>Supplier Source Matrix</h2><div class="note">This view mirrors the supplier's original table structure: <strong>Category as rows</strong> and <strong>destinations/cities as columns</strong>. TRAVSCOPE still stores one hotel per database row underneath, so matching, aliases, contracts and quotations remain reliable. Supplier room category/meal columns are preserved separately instead of being mistaken for destinations.</div>
<?php if(!$hotelRows):?><p class="muted">No supplier matrix yet. Click <strong>Build / Refresh From Source</strong>.</p><?php else:?><div class="matrix-wrap" style="margin-top:12px"><table class="supplier-matrix"><thead><tr><th>Category</th><?php foreach($matrixCities as $city):?><th><?=sciE($city)?></th><?php endforeach;?><th>Room Category</th><th>Meal Plan</th></tr></thead><tbody>
<?php foreach($matrixCategories as $cat):?><tr><td class="cat-cell"><?=sciE($cat)?><?php $mappedStar=tsSCIStarFromCategory($cat);if($mappedStar):?><br><span class="badge"><?= (int)$mappedStar ?>★ Hotel Master</span><?php else:?><br><span class="badge">Supplier-only</span><?php endif;?></td>
<?php foreach($matrixCities as $city):?><td><?php $cellRows=$hotelMatrix[$cat][$city]??[];if(!$cellRows):?><span class="matrix-empty">—</span><?php else:?><?php foreach($cellRows as $r):?><div class="matrix-hotel"><span class="matrix-state <?=!empty($r['hotel_id'])?'ok':'review'?>"><?=!empty($r['hotel_id'])?'✓':'!'?></span><span><strong><?=sciE($r['hotel_name'])?></strong><?php if(!empty($r['hotel_id'])):?><br><small class="muted">Mapped to Hotel Master</small><?php else:?><br><small class="muted">Supplier alternative</small><?php endif;?></span></div><?php endforeach;?><?php endif;?></td><?php endforeach;?>
<td class="meta-cell"><?php $roomValues=array_keys($matrixRoomTypes[$cat]??[]);?><?= $roomValues?sciE(implode(' / ',$roomValues)):'<span class="matrix-empty">Not specified</span>' ?></td>
<td class="meta-cell"><?php $mealValues=array_keys($matrixMealPlans[$cat]??[]);?><?= $mealValues?sciE(implode(' / ',$mealValues)):'<span class="matrix-empty">Contract default</span>' ?></td></tr><?php endforeach;?>
</tbody></table></div><div class="matrix-legend"><span><i class="matrix-state ok">✓</i> Matched/created in Hotel Master</span><span><i class="matrix-state review">!</i> Supplier alternative awaiting mapping or supplier-only category</span></div><?php endif;?></div>

<div class="panel"><h2>Hotel Mapping Details</h2><?php if(!$hotelRows):?><p class="muted">No hotel inventory yet. Click <strong>Build / Refresh From Source</strong>.</p><?php endif;?>
<?php foreach($grouped as $key=>$rows):?><?php [$cat,$city]=explode('|',$key,2);?><div class="inventory-group"><div class="group-head"><strong><?=sciE($cat)?> · <?=sciE($city)?></strong><span class="badge"><?=count($rows)?> alternative<?=count($rows)===1?'':'s'?></span></div>
<?php foreach($rows as $r):?><div class="hotel-row"><div><strong><?=sciE($r['hotel_name'])?></strong><br><span class="muted"><?=sciE((string)($r['meal_plan']?:'Meal plan from contract'))?></span></div><div><?=!empty($r['mapped_star_category'])?(int)$r['mapped_star_category'].'★':'Supplier-only'?></div><div><span class="badge <?=sciE($r['mapping_status'])?>"><?=sciE(strtoupper($r['mapping_status']))?></span> <span class="badge <?=sciE($r['status'])?>"><?=sciE(strtoupper($r['status']))?></span></div><div>
<?php if(!empty($r['hotel_id'])):?><span class="muted">Hotel Master #<?=(int)$r['hotel_id']?></span><?php elseif(!empty($r['mapped_star_category']) && $hotelMaster):?><form method="post" style="display:flex;gap:5px"><input type="hidden" name="csrf" value="<?=sciE($csrf)?>"><input type="hidden" name="version_id" value="<?=$versionId?>"><input type="hidden" name="action" value="manual_map"><input type="hidden" name="inventory_id" value="<?=(int)$r['id']?>"><select name="hotel_id" required><option value="">Map existing hotel...</option><?php foreach($hotelMaster as $hm):?><?php if((int)$hm['star_category']!==(int)$r['mapped_star_category'])continue;if(strcasecmp(trim((string)($hm['city']??'')),trim((string)$r['city']))!==0)continue;?><option value="<?=(int)$hm['id']?>"><?=sciE($hm['hotel_name'].' · '.($hm['city']?:$hm['destination_name']))?></option><?php endforeach;?></select><button class="btn soft" style="padding:8px">Map</button></form><?php else:?><span class="muted">Kept in supplier inventory</span><?php endif;?></div></div><?php endforeach;?></div><?php endforeach;?></div>

<div class="panel"><h2>Add Supplier Vehicle Rule</h2><p class="muted">Vehicle types and PAX rules belong to the <strong>Supplier Contract</strong>, exactly like location-wise hotels. Trip/Quotation screens only select from approved rules.</p><form method="post"><input type="hidden" name="csrf" value="<?=sciE($csrf)?>"><input type="hidden" name="version_id" value="<?=$versionId?>"><input type="hidden" name="action" value="add_supplier_vehicle"><div class="grid"><div><label class="label">Location / City</label><input class="input" name="vehicle_city" list="contractCityList" placeholder="Choose city or type a new location" required></div><div><label class="label">Supplier Category</label><select name="vehicle_supplier_category" required><option value="">Select category</option><?php foreach(['5 Star Luxury','5 Star','4 Star Luxury','4 Star','3 Star','2 Star','Standard','Budget','All'] as $cat):?><option value="<?=sciE($cat)?>"><?=sciE($cat)?></option><?php endforeach;?></select></div><div><label class="label">Vehicle Type</label><input class="input" name="vehicle_type" placeholder="Innova / Crysta / Tempo Traveller" required></div><div><label class="label">AC Basis</label><select name="vehicle_ac_basis"><option value="unspecified">Not specified</option><option value="ac">A/C</option><option value="non_ac">Non A/C</option></select></div><div><label class="label">PAX Min</label><input class="input" type="number" min="1" name="vehicle_pax_min" placeholder="2"></div><div><label class="label">PAX Max</label><input class="input" type="number" min="1" name="vehicle_pax_max" placeholder="4"></div><div class="full"><label class="label">Route / Scope (optional)</label><input class="input" name="vehicle_route_scope" placeholder="Airport pickup + all sightseeing / Srinagar-Pahalgam-Gulmarg"></div><div style="align-self:end"><button class="btn primary"><i class="fa-solid fa-van-shuttle"></i> Add Vehicle Rule</button></div></div></form><?php if((string)($version['status']??'')==='active'):?><div class="note" style="margin-top:10px;color:#9a3412"><strong>Active version is immutable:</strong> create a new supplier contract version before adding/changing vehicle rules.</div><?php endif;?></div>

<div class="panel"><h2>Vehicle / Transport Rules</h2><p class="muted">PAX thresholds stay blank when the supplier only says “as per pax”. TRAVSCOPE shows supplier alternatives rather than inventing an assignment.</p><?php if(!$vehicleRows):?><p class="muted">No vehicle rules prepared yet.</p><?php else:?><table class="vehicles"><thead><tr><th>Location</th><th>Supplier Category</th><th>Vehicle</th><th>PAX Rule</th><th>AC Basis</th><th>Route / Scope</th><th>Status</th></tr></thead><tbody><?php foreach($vehicleRows as $v):?><tr><td><?=sciE((string)($v['city']??'All / Contract-wide'))?></td><td><?=sciE($v['supplier_category'])?></td><td><strong><?=sciE($v['vehicle_type'])?></strong></td><td><?=($v['pax_min']||$v['pax_max'])?sciE((string)$v['pax_min'].'–'.(string)$v['pax_max']):'As per supplier / not specified'?></td><td><?=sciE(strtoupper(str_replace('_',' ',$v['ac_basis'])))?></td><td><?=sciE((string)($v['route_scope']??''))?></td><td><span class="badge <?=sciE($v['status'])?>"><?=sciE(strtoupper($v['status']))?></span></td></tr><?php endforeach;?></tbody></table><?php endif;?></div>
</div></main>
<script src="assets/travscope-pro-admin.js?v=20260916-v9" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
