<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
require_once __DIR__.'/supplier-functions.php';
$token=trim((string)($_GET['token']??$_POST['token']??''));
if($token===''||strlen($token)<40){http_response_code(404);exit('Invalid supplier response link.');}
$hash=hash('sha256',$token);
$stmt=$pdo->prepare("SELECT t.id token_id,t.supplier_request_id,r.*,s.company_name,c.contact_name FROM supplier_request_portal_tokens t JOIN supplier_requests r ON r.id=t.supplier_request_id JOIN suppliers s ON s.id=r.supplier_id LEFT JOIN supplier_contacts c ON c.id=r.supplier_contact_id WHERE t.token_hash=? AND t.revoked_at IS NULL AND (t.expires_at IS NULL OR t.expires_at>NOW()) LIMIT 1");
$stmt->execute([$hash]);$request=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$request){http_response_code(404);exit('This supplier response link is invalid or expired.');}
$id=(int)$request['supplier_request_id'];
$linkedServiceRequirement=null;
if(!empty($request['service_requirement_id'])){
    $stmt=$pdo->prepare("
        SELECT r.*,d.name destination_name,t.trip_code
        FROM trip_service_requirements r
        LEFT JOIN destinations d ON d.id=r.destination_id
        LEFT JOIN trips t ON t.id=r.trip_id
        WHERE r.id=? AND r.enquiry_id=?
        LIMIT 1
    ");
    $stmt->execute([(int)$request['service_requirement_id'],(int)$request['enquiry_id']]);
    $linkedServiceRequirement=$stmt->fetch(PDO::FETCH_ASSOC)?:null;
}
$pdo->prepare("UPDATE supplier_request_portal_tokens SET last_used_at=NOW() WHERE id=?")->execute([(int)$request['token_id']]);
if(empty($_SESSION['supplier_portal_csrf']))$_SESSION['supplier_portal_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['supplier_portal_csrf'];$success='';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  if(!hash_equals($csrf,(string)($_POST['csrf']??'')))throw new RuntimeException('Security verification failed.');
  $action=(string)($_POST['action']??'message');
  if($action==='message'){
   $message=trim((string)($_POST['message']??''));if($message==='')throw new RuntimeException('Write a message first.');
   $upload=tsSupplierUploadQuote($_FILES['attachment']??[]);
   tsSupplierMessage($pdo,$id,'supplier',null,$message,'portal',$upload['path'],$upload['name']);
   tsSupplierEvent($pdo,$id,'supplier_reply',null,$message,'portal');
   $pdo->prepare("UPDATE supplier_requests SET status=CASE WHEN status IN ('selected','rejected','cancelled') THEN status ELSE 'partial_response' END,first_response_at=COALESCE(first_response_at,NOW()),last_response_at=NOW() WHERE id=?")->execute([$id]);
   $success='Reply sent to TRAVSCOPE.';
  }
  if($action==='quote'){
   $currency=strtoupper(trim((string)($_POST['currency']??'INR')))?:'INR';
   $mode=tsSupplierQuoteMode(
       (string)($_POST['costing_mode']??(
           (string)($request['request_type']??'')==='service_quote'
               ? 'service_wise'
               : 'complete_package'
       ))
   );

   $costing=tsSupplierQuoteBuildCosting(
       $mode,
       max(0,(float)($_POST['package_base_amount']??0)),
       max(0,(float)($_POST['tax_amount']??0)),
       max(0,(float)($_POST['upgrade_amount']??0)),
       (array)($_POST['item_type']??[]),
       (array)($_POST['item_description']??[]),
       (array)($_POST['item_cost']??[])
   );

   $net=(float)$costing['net_amount'];
   $upgrade=(float)$costing['upgrade_amount'];
   $tax=(float)$costing['tax_amount'];
   $total=(float)$costing['total_supplier_cost'];

   $upload=tsSupplierUploadQuote($_FILES['quote_attachment']??[]);
   $stmt=$pdo->prepare("SELECT COALESCE(MAX(version_number),0)+1 FROM supplier_quotes WHERE supplier_request_id=?");
   $stmt->execute([$id]);
   $version=(int)$stmt->fetchColumn();

   $pdo->beginTransaction();

   if($version>1){
       $pdo->prepare("UPDATE supplier_quotes SET status='superseded' WHERE supplier_request_id=? AND status='received'")
           ->execute([$id]);
   }

   if(tsSupplierQuoteModeColumnExists($pdo)){
       $stmt=$pdo->prepare("
           INSERT INTO supplier_quotes
           (supplier_request_id,version_number,response_channel,costing_mode,currency,net_amount,upgrade_amount,tax_amount,total_supplier_cost,
            hotel_summary,transport_summary,inclusions,exclusions,payment_terms,cancellation_terms,validity_until,response_notes,
            attachment_path,original_filename,status,received_at,created_by_admin_id)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'received',NOW(),NULL)
       ");
       $stmt->execute([
           $id,$version,'manual',$mode,$currency,$net,$upgrade,$tax,$total,
           trim((string)($_POST['hotel_summary']??''))?:null,
           trim((string)($_POST['transport_summary']??''))?:null,
           trim((string)($_POST['inclusions']??''))?:null,
           trim((string)($_POST['exclusions']??''))?:null,
           trim((string)($_POST['payment_terms']??''))?:null,
           trim((string)($_POST['cancellation_terms']??''))?:null,
           trim((string)($_POST['validity_until']??''))?:null,
           trim((string)($_POST['quote_notes']??''))?:null,
           $upload['path'],$upload['name']
       ]);
   }else{
       $stmt=$pdo->prepare("
           INSERT INTO supplier_quotes
           (supplier_request_id,version_number,response_channel,currency,net_amount,upgrade_amount,tax_amount,total_supplier_cost,
            hotel_summary,transport_summary,inclusions,exclusions,payment_terms,cancellation_terms,validity_until,response_notes,
            attachment_path,original_filename,status,received_at,created_by_admin_id)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'received',NOW(),NULL)
       ");
       $stmt->execute([
           $id,$version,'manual',$currency,$net,$upgrade,$tax,$total,
           trim((string)($_POST['hotel_summary']??''))?:null,
           trim((string)($_POST['transport_summary']??''))?:null,
           trim((string)($_POST['inclusions']??''))?:null,
           trim((string)($_POST['exclusions']??''))?:null,
           trim((string)($_POST['payment_terms']??''))?:null,
           trim((string)($_POST['cancellation_terms']??''))?:null,
           trim((string)($_POST['validity_until']??''))?:null,
           trim((string)($_POST['quote_notes']??''))?:null,
           $upload['path'],$upload['name']
       ]);
   }

   $quoteId=(int)$pdo->lastInsertId();
   $ins=$pdo->prepare("
       INSERT INTO supplier_quote_items
       (supplier_quote_id,item_type,description,quantity,unit_cost,line_cost,is_upgrade,sort_order)
       VALUES (?,?,?,1,?,?,?,?)
   ");

   foreach($costing['items'] as $i=>$item){
       $cost=(float)$item['cost'];
       $ins->execute([
           $quoteId,
           (string)$item['item_type'],
           (string)$item['description'],
           $cost,
           $cost,
           (int)$item['is_upgrade'],
           $i+1
       ]);
   }

   tsSupplierMessage(
       $pdo,
       $id,
       'supplier',
       null,
       'Submitted quotation V'.$version.' — '.tsSupplierQuoteModeLabel($mode).' — '.$currency.' '.number_format($total,2),
       'portal',
       $upload['path'],
       $upload['name']
   );

   tsSupplierEvent(
       $pdo,
       $id,
       'response_received',
       null,
       'Supplier submitted quotation V'.$version.' through secure portal · '.tsSupplierQuoteModeLabel($mode).'.',
       'portal'
   );

   $pdo->prepare("
       UPDATE supplier_requests
       SET status='response_received',
           first_response_at=COALESCE(first_response_at,NOW()),
           last_response_at=NOW()
       WHERE id=?
   ")->execute([$id]);

   if(!empty($request['service_requirement_id'])){
       $pdo->prepare("UPDATE trip_service_requirements SET status='quoted',updated_at=NOW() WHERE id=?")
           ->execute([(int)$request['service_requirement_id']]);
   }

   $pdo->commit();
   $success='Quotation V'.$version.' submitted successfully.';
  }
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$error=$e->getMessage();}
}
$stmt=$pdo->prepare("SELECT * FROM supplier_request_messages WHERE supplier_request_id=? ORDER BY sent_at,id");$stmt->execute([$id]);$messages=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
$stmt=$pdo->prepare("SELECT * FROM supplier_quotes WHERE supplier_request_id=? ORDER BY version_number DESC");$stmt->execute([$id]);$quotes=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
$quoteItems=[];
foreach($quotes as $quoteRow){
    $st=$pdo->prepare("SELECT * FROM supplier_quote_items WHERE supplier_quote_id=? ORDER BY sort_order,id");
    $st->execute([(int)$quoteRow['id']]);
    $quoteItems[(int)$quoteRow['id']]=$st->fetchAll(PDO::FETCH_ASSOC)?:[];
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Supplier Workspace | TRAVSCOPE</title>
<style>
*{box-sizing:border-box}
:root{
 --navy:#0b1f37;--blue:#2563eb;--blue2:#eaf2ff;--green:#059669;--green2:#eafbf3;
 --purple:#7c3aed;--amber:#d97706;--bg:#eef3f8;--card:#fff;--line:#dfe7f1;--text:#172033;--muted:#64748b;
}
html,body{height:100%}
body{margin:0;background:var(--bg);color:var(--text);font-family:Arial,sans-serif;overflow:hidden}
a{color:#1455c0;text-decoration:none}.portal{height:100vh;padding:14px;display:grid;grid-template-rows:auto 1fr;gap:12px;max-width:1500px;margin:auto}
.topbar{background:linear-gradient(135deg,#0c2747,#123b65);color:#fff;border-radius:16px;padding:13px 16px;display:flex;align-items:center;justify-content:space-between;gap:14px;box-shadow:0 8px 24px rgba(15,23,42,.12)}
.brandline{display:flex;align-items:center;gap:11px}.logo{width:38px;height:38px;border-radius:11px;background:#19a6ff;display:grid;place-items:center;font-size:19px;font-weight:900}.brand{font-weight:900;font-size:15px}.subtitle{font-size:10px;color:#cbd7e5;margin-top:2px}.request-pill{padding:8px 11px;border-radius:999px;background:rgba(255,255,255,.12);font-size:11px;font-weight:800;white-space:nowrap}
.workspace{min-height:0;display:grid;grid-template-columns:minmax(270px,33%) minmax(0,1fr);gap:12px}.side,.main{min-height:0}.side{display:flex;flex-direction:column;gap:10px;overflow:auto}.panel{background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:0 4px 16px rgba(15,23,42,.04)}.panel-pad{padding:13px}.section-title{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:9px}.section-title h2{font-size:13px;margin:0;font-weight:900;color:var(--navy)}.tiny{font-size:10px;color:var(--muted)}
.req{white-space:pre-wrap;background:#f8fafc;border:1px solid #e8eef5;padding:11px;border-radius:10px;line-height:1.45;font-size:11px;max-height:250px;overflow:auto}.quote-mini{padding:9px 10px;border:1px solid #ddd6fe;background:#faf8ff;border-radius:10px;margin-top:7px}.quote-mini strong{font-size:12px}.quote-money{font-size:16px;font-weight:900;color:#4c1d95;margin-top:4px}.status{display:inline-flex;padding:3px 7px;border-radius:999px;background:#eef2ff;color:#4f46e5;font-size:9px;font-weight:800}
.action-row{display:flex;gap:7px;flex-wrap:wrap}.btn{border:0;border-radius:9px;padding:9px 12px;font-weight:800;cursor:pointer;font-size:11px}.blue{background:var(--blue);color:#fff}.green{background:var(--green);color:#fff}.light{background:#eef4fb;color:#174a7c}.purple{background:#ede9fe;color:#6d28d9}.btn:hover{filter:brightness(.97)}
.main{display:grid;grid-template-rows:1fr;overflow:hidden}.conversation{min-height:0;display:grid;grid-template-rows:auto 1fr auto;background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:0 4px 16px rgba(15,23,42,.04);overflow:hidden}.conversation-head{padding:12px 14px;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fbfdff}.conversation-head h1{font-size:15px;margin:0;color:var(--navy)}.conversation-head .meta{font-size:10px;color:var(--muted);margin-top:2px}.quote-toggle{border:1px solid #c4b5fd;background:#f5f3ff;color:#6d28d9;border-radius:9px;padding:8px 10px;font-size:10px;font-weight:900;cursor:pointer}
.messages{min-height:0;overflow:auto;padding:14px;display:flex;flex-direction:column;gap:9px;background:linear-gradient(180deg,#fbfdff,#f6f9fc)}.empty{margin:auto;color:var(--muted);font-size:12px}.msg{max-width:72%;padding:10px 12px;border-radius:14px;font-size:11px;line-height:1.45;box-shadow:0 2px 8px rgba(15,23,42,.04)}.msg.admin{align-self:flex-start;background:var(--blue2);border-bottom-left-radius:5px}.msg.supplier{align-self:flex-end;background:var(--green2);border-bottom-right-radius:5px}.msg-head{display:flex;justify-content:space-between;gap:10px;font-size:9px;font-weight:900;margin-bottom:4px}.msg small{display:block;color:var(--muted);margin-top:5px;font-size:9px}.attachment{display:inline-flex;margin-top:6px;padding:5px 7px;background:#fff;border-radius:7px;font-size:9px}
.composer{padding:11px 12px;border-top:1px solid var(--line);background:#fff}.composer form{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:end}.compose-box{border:1px solid #cfd9e6;border-radius:11px;padding:7px;background:#fbfdff}.compose-box textarea{width:100%;border:0;outline:0;resize:none;min-height:54px;max-height:100px;background:transparent;font:inherit;font-size:11px}.compose-tools{display:flex;align-items:center;justify-content:space-between;gap:8px;border-top:1px solid #e8eef5;padding-top:6px}.file{font-size:9px;max-width:220px}.send{min-width:88px;height:42px}
.flash{padding:9px 11px;border-radius:9px;margin-bottom:8px;font-size:11px}.ok{background:#ecfdf5;color:#047857}.err{background:#fef2f2;color:#b91c1c}
.quote-drawer{position:fixed;inset:0;background:rgba(15,23,42,.38);display:none;align-items:center;justify-content:flex-end;z-index:50}.quote-drawer.open{display:flex}.drawer-card{height:100%;width:min(620px,100%);background:#fff;padding:15px;overflow:auto;box-shadow:-10px 0 30px rgba(15,23,42,.18)}.drawer-head{display:flex;align-items:center;justify-content:space-between;gap:10px;position:sticky;top:-15px;background:#fff;padding:4px 0 10px;z-index:2}.drawer-head h2{margin:0;font-size:16px}.close{border:0;background:#eef2f7;width:34px;height:34px;border-radius:9px;cursor:pointer;font-size:18px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.full{grid-column:1/-1}label{display:block;font-size:10px;font-weight:800;margin:0 0 5px}input,textarea{width:100%;padding:9px;border:1px solid #cbd5e1;border-radius:9px;font:inherit;font-size:11px}textarea{min-height:72px}.drawer-submit{margin-top:12px;width:100%;padding:12px}
@media(max-width:900px){body{overflow:auto}.portal{height:auto;min-height:100vh}.workspace{grid-template-columns:1fr}.side{overflow:visible}.main{min-height:650px}.conversation{min-height:650px}.msg{max-width:88%}}
@media(max-width:560px){.portal{padding:8px}.topbar{border-radius:12px;padding:10px}.request-pill{display:none}.workspace{gap:8px}.side{gap:8px}.grid{grid-template-columns:1fr}.full{grid-column:auto}.msg{max-width:94%}.composer form{grid-template-columns:1fr}.send{width:100%}.compose-tools{align-items:flex-start;flex-direction:column}.drawer-card{width:100%}}

.quote-mini-top{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}
.mode-pill{display:inline-flex;padding:4px 7px;border-radius:999px;font-size:9px;font-weight:800;border:1px solid #dbe5f0;background:#f8fafc;color:#475569}
.mode-pill.complete_package{background:#eef6ff;border-color:#bfdbfe;color:#1d4ed8}
.mode-pill.service_wise{background:#ecfdf5;border-color:#a7f3d0;color:#047857}
.mode-pill.hybrid{background:#f5f3ff;border-color:#ddd6fe;color:#6d28d9}
.mini-breakdown{margin-top:6px;border-top:1px dashed var(--line);padding-top:5px}
.mini-breakdown summary{cursor:pointer;font-size:10px;font-weight:800;color:#475569}
.mini-breakdown div{font-size:9px;color:#64748b;padding-top:3px}
.mode-box{padding:11px;border:1px solid #bfdbfe;border-radius:12px;background:#eff6ff;margin-bottom:12px}
.mode-box label{display:block;font-size:12px;font-weight:800;margin-bottom:5px}
.mode-box select{width:100%;min-height:40px;border:1px solid var(--line);border-radius:9px;padding:8px;background:#fff}
.portal-service-costs{margin-top:12px;padding-top:10px;border-top:1px dashed #cbd5e1}
.portal-service-costs h3{margin:0 0 4px;font-size:13px}
.portal-cost-row{display:grid;grid-template-columns:150px minmax(0,1fr) 130px;gap:7px;margin-top:7px}
.portal-cost-row select,.portal-cost-row input{width:100%;border:1px solid var(--line);border-radius:9px;padding:8px;background:#fff}
.portal-formula{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 12px;margin-top:12px;border-radius:10px;background:#0f172a;color:#fff}
.portal-formula span{font-size:9px;font-weight:900;text-transform:uppercase;color:#93c5fd}
.portal-formula strong{font-size:11px;text-align:right}
@media(max-width:720px){.portal-cost-row{grid-template-columns:1fr}.portal-formula{align-items:flex-start;flex-direction:column}}

</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head>
<body>
<div class="portal">
  <div class="topbar">
    <div class="brandline">
      <div class="logo">✈</div>
      <div><div class="brand">TRAVSCOPE Supplier Workspace</div><div class="subtitle"><?=tsSupE((string)$request['company_name'])?> · secure request & quotation communication</div></div>
    </div>
    <div class="request-pill"><?=tsSupE((string)$request['request_code'])?></div>
  </div>

  <div class="workspace">
    <aside class="side">
      <?php if($success):?><div class="flash ok"><?=tsSupE($success)?></div><?php endif;?>
      <?php if($error):?><div class="flash err"><?=tsSupE($error)?></div><?php endif;?>

      <section class="panel panel-pad">
        <div class="section-title"><h2>📋 Travel Requirement</h2><span class="status"><?=tsSupE((string)$request['status'])?></span></div>
        <?php if($linkedServiceRequirement):?><div style="margin-bottom:8px;padding:8px 10px;border:1px solid #fed7aa;border-radius:9px;background:#fff7ed;color:#9a3412"><strong style="display:block;font-size:11px">Exact Service: <?=tsSupE((string)$linkedServiceRequirement['title'])?></strong><span style="font-size:9px"><?=tsSupE(ucwords(str_replace('_',' ',(string)$linkedServiceRequirement['service_type'])))?><?=!empty($linkedServiceRequirement['trip_code'])?' · '.tsSupE((string)$linkedServiceRequirement['trip_code']):''?></span></div><?php endif;?>
        <div class="req"><?=tsSupE((string)$request['requirement_text'])?><?php if($request['special_requirements']):?>

SPECIAL REQUIREMENTS
<?=tsSupE((string)$request['special_requirements'])?><?php endif;?></div>
      </section>

      <section class="panel panel-pad">
        <div class="section-title"><h2>💰 Quotation</h2><button class="btn purple" type="button" onclick="openQuoteDrawer()">+ Submit / Revise</button></div>
        <?php if(!$quotes):?>
          <div class="tiny">No quotation submitted yet. Use <strong>Submit / Revise</strong> when your commercial rate is ready.</div>
        <?php endif;?>
        <?php foreach($quotes as $q):?>
          <?php $quoteMode=tsSupplierQuoteModeFromRow($q,(string)($request['request_type']??'')); ?>
          <div class="quote-mini">
            <div class="quote-mini-top">
              <div><strong>Version <?=(int)$q['version_number']?></strong> <span class="status"><?=tsSupE((string)$q['status'])?></span></div>
              <span class="mode-pill <?=tsSupE($quoteMode)?>"><?=tsSupE(tsSupplierQuoteModeLabel($quoteMode))?></span>
            </div>
            <div class="quote-money"><?=tsSupE((string)$q['currency'])?> <?=number_format((float)$q['total_supplier_cost'],2)?></div>
            <div class="tiny">NET/services <?=number_format((float)($q['net_amount']??0),2)?> · GST/Tax <?=number_format((float)($q['tax_amount']??0),2)?> · Other <?=number_format((float)($q['upgrade_amount']??0),2)?></div>
            <?php if($quoteItems[(int)$q['id']]??[]):?>
              <details class="mini-breakdown"><summary>View cost breakdown</summary>
                <?php foreach($quoteItems[(int)$q['id']] as $item):?>
                  <div><?=tsSupE(ucfirst((string)$item['item_type']))?> · <?=tsSupE((string)$item['description'])?> — <?=tsSupE((string)$q['currency'])?> <?=number_format((float)$item['line_cost'],2)?></div>
                <?php endforeach;?>
              </details>
            <?php endif;?>
            <div class="tiny"><?=tsSupE((string)$q['received_at'])?></div>
          </div>
        <?php endforeach;?>
      </section>
    </aside>

    <main class="main">
      <section class="conversation">
        <div class="conversation-head">
          <div><h1>💬 Conversation with TRAVSCOPE</h1><div class="meta">Reply here instead of sending separate emails. Messages stay linked to this RFQ.</div></div>
          <button class="quote-toggle" type="button" onclick="openQuoteDrawer()">Quotation</button>
        </div>

        <div class="messages" id="messageFeed">
          <?php if(!$messages):?><div class="empty">No messages yet. Write your first reply below.</div><?php endif;?>
          <?php foreach($messages as $m):?>
            <div class="msg <?=($m['sender_type']==='supplier'?'supplier':'admin')?>">
              <div class="msg-head"><span><?=$m['sender_type']==='supplier'?'YOU':'TRAVSCOPE'?></span></div>
              <div><?=nl2br(tsSupE((string)$m['message']))?></div>
              <?php if($m['attachment_path']):?><a class="attachment" target="_blank" href="<?=tsSupE(BASE_URL.(string)$m['attachment_path'])?>">📎 <?=tsSupE((string)($m['original_filename']?:'Attachment'))?></a><?php endif;?>
              <small><?=tsSupE((string)$m['sent_at'])?></small>
            </div>
          <?php endforeach;?>
        </div>

        <div class="composer">
          <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="token" value="<?=tsSupE($token)?>"><input type="hidden" name="csrf" value="<?=tsSupE($csrf)?>"><input type="hidden" name="action" value="message">
            <div class="compose-box">
              <textarea name="message" placeholder="Write a message to TRAVSCOPE..." required></textarea>
              <div class="compose-tools"><input class="file" type="file" name="attachment"><span class="tiny">PDF, Excel, Word or image can be attached.</span></div>
            </div>
            <button class="btn blue send">Send Reply</button>
          </form>
        </div>
      </section>
    </main>
  </div>
</div>

<div class="quote-drawer" id="quoteDrawer" onclick="drawerBackdrop(event)">
  <div class="drawer-card">
    <div class="drawer-head"><div><h2>Submit / Revise Quotation</h2><div class="tiny">A new submission creates the next version; older versions remain preserved.</div></div><button class="close" type="button" onclick="closeQuoteDrawer()">×</button></div>
    <form method="post" enctype="multipart/form-data" class="supplier-portal-costing-form">
      <input type="hidden" name="token" value="<?=tsSupE($token)?>">
      <input type="hidden" name="csrf" value="<?=tsSupE($csrf)?>">
      <input type="hidden" name="action" value="quote">

      <div class="mode-box">
        <label>How are you quoting this requirement?</label>
        <select name="costing_mode" class="js-portal-mode">
          <option value="complete_package" <?=($request['request_type']??'')!=='service_quote'?'selected':''?>>Complete Package Rate</option>
          <option value="service_wise" <?=($request['request_type']??'')==='service_quote'?'selected':''?>>Service-wise Costing</option>
          <option value="hybrid">Hybrid — Package + Extra Services</option>
        </select>
        <div class="tiny">Complete Package = one NET package amount. Service-wise = hotel/transport/activity etc. Hybrid = package base plus separately charged services.</div>
      </div>

      <div class="grid">
        <div><label>Currency</label><input name="currency" value="INR"></div>

        <div class="js-portal-package-field">
          <label>Package / Base NET Amount</label>
          <input class="js-portal-package-base" type="number" step=".01" min="0" name="package_base_amount" placeholder="Your NET amount">
        </div>

        <div>
          <label>Supplier GST / Tax Amount</label>
          <input class="js-portal-tax" type="number" step=".01" min="0" name="tax_amount" value="0">
        </div>

        <div>
          <label>Other / Upgrade Charges</label>
          <input class="js-portal-other" type="number" step=".01" min="0" name="upgrade_amount" value="0">
        </div>

        <div>
          <label>Total Supplier Payable</label>
          <input class="js-portal-total" type="number" step=".01" value="0" readonly>
        </div>

        <div><label>Valid Until</label><input type="date" name="validity_until"></div>
        <div><label>Quote Attachment</label><input type="file" name="quote_attachment"></div>

        <div class="full"><label>Hotel / Room / Meal</label><textarea name="hotel_summary" placeholder="Hotel, room category, meal plan..."></textarea></div>
        <div class="full"><label>Transport / Vehicle</label><textarea name="transport_summary" placeholder="Vehicle, transfers, transport conditions..."></textarea></div>
        <div><label>Inclusions</label><textarea name="inclusions"></textarea></div>
        <div><label>Exclusions</label><textarea name="exclusions"></textarea></div>
        <div><label>Payment Terms</label><textarea name="payment_terms"></textarea></div>
        <div><label>Cancellation Terms</label><textarea name="cancellation_terms"></textarea></div>
        <div class="full"><label>Notes</label><textarea name="quote_notes"></textarea></div>
      </div>

      <div class="portal-service-costs js-portal-service-costs">
        <h3>Service Cost Items</h3>
        <div class="tiny">Use these rows for Service-wise or Hybrid costing. Please do not add GST again inside a service row.</div>
        <?php for($i=0;$i<8;$i++):?>
          <div class="portal-cost-row">
            <select name="item_type[]">
              <option value="hotel">Hotel</option>
              <option value="transport">Transport</option>
              <option value="activity">Activity</option>
              <option value="sightseeing">Sightseeing</option>
              <option value="transfer">Transfer</option>
              <option value="flight">Flight</option>
              <option value="visa">Visa</option>
              <option value="insurance">Insurance</option>
              <option value="upgrade">Upgrade</option>
              <option value="other">Other</option>
            </select>
            <input name="item_description[]" placeholder="Service description">
            <input class="js-portal-item-cost" type="number" min="0" step=".01" name="item_cost[]" placeholder="Cost">
          </div>
        <?php endfor;?>
      </div>

      <div class="portal-formula">
        <span>Supplier Cost Formula</span>
        <strong class="js-portal-formula">Enter your supplier cost</strong>
      </div>

      <button class="btn green drawer-submit">Submit Quotation</button>
    </form>
  </div>
</div>

<script>
function openQuoteDrawer(){document.getElementById('quoteDrawer').classList.add('open');}
function closeQuoteDrawer(){document.getElementById('quoteDrawer').classList.remove('open');}
function drawerBackdrop(e){if(e.target.id==='quoteDrawer')closeQuoteDrawer();}

(function(){
  const form=document.querySelector('.supplier-portal-costing-form');
  if(!form) return;

  const mode=form.querySelector('.js-portal-mode');
  const packageField=form.querySelector('.js-portal-package-field');
  const packageBase=form.querySelector('.js-portal-package-base');
  const tax=form.querySelector('.js-portal-tax');
  const other=form.querySelector('.js-portal-other');
  const total=form.querySelector('.js-portal-total');
  const serviceBlock=form.querySelector('.js-portal-service-costs');
  const formula=form.querySelector('.js-portal-formula');
  const itemCosts=Array.from(form.querySelectorAll('.js-portal-item-cost'));
  const num=(el)=>Math.max(0,Number(el?.value||0));

  function calculate(){
    const selected=mode?.value||'complete_package';
    const packageAmount=num(packageBase);
    const services=itemCosts.reduce((sum,input)=>sum+num(input),0);
    const net=selected==='service_wise'
      ? services
      : selected==='hybrid'
        ? packageAmount+services
        : packageAmount;
    const taxAmount=num(tax);
    const otherAmount=num(other);
    const finalTotal=net+taxAmount+otherAmount;

    if(packageField) packageField.hidden=selected==='service_wise';
    if(serviceBlock) serviceBlock.hidden=selected==='complete_package';
    if(total) total.value=finalTotal.toFixed(2);

    if(formula){
      const label=selected==='complete_package'
        ? 'Package NET'
        : selected==='service_wise'
          ? 'Service items'
          : 'Package NET + extra services';
      formula.textContent=label+' '+net.toFixed(2)+' + GST/Tax '+taxAmount.toFixed(2)+' + Other '+otherAmount.toFixed(2)+' = '+finalTotal.toFixed(2);
    }
  }

  [mode,packageBase,tax,other,...itemCosts].forEach(function(el){
    el?.addEventListener('input',calculate);
    el?.addEventListener('change',calculate);
  });

  calculate();
})();

window.addEventListener('keydown',function(e){if(e.key==='Escape')closeQuoteDrawer();});
window.addEventListener('load',function(){var feed=document.getElementById('messageFeed');if(feed)feed.scrollTop=feed.scrollHeight;});
</script>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>