<?php
require_once __DIR__.'/config.php';
require_once __DIR__.'/commercial-workflow-functions.php';
$access=__DIR__.'/access-control-functions.php'; if(is_file($access)) require_once $access;
if(empty($_SESSION['admin_id'])){header('Location: '.BASE_URL.'admin-login.php');exit;}
$adminId=(int)$_SESSION['admin_id'];
$tripId=max(0,(int)($_GET['trip_id']??$_POST['trip_id']??0));
$trip=tsCWTrip($pdo,$tripId);
if(!$trip){http_response_code(404);exit('Trip not found.');}
$leadId=(int)$trip['enquiry_id'];
if(function_exists('tsAclRequire')){try{tsAclRequire($pdo,$adminId,'view_supplier_cost','view_commercial_hub','trip',$tripId);}catch(Throwable $e){http_response_code(403);exit(htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8'));}}
if(empty($_SESSION['cw_csrf']))$_SESSION['cw_csrf']=bin2hex(random_bytes(32));
$csrf=(string)$_SESSION['cw_csrf'];
$success=(string)($_SESSION['cw_success']??'');$error='';unset($_SESSION['cw_success']);

if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  if(!hash_equals($csrf,(string)($_POST['csrf']??''))) throw new RuntimeException('Security verification failed.');
  $action=(string)($_POST['action']??'');
  if($action==='add_change'){
    $text=trim((string)($_POST['request_text']??'')); if(mb_strlen($text)<3)throw new RuntimeException('Enter the requested change.');
    $id=tsCWCreateChangeRequest($pdo,[
      'lead_id'=>$leadId,'trip_id'=>$tripId,'quotation_version_id'=>(int)($_POST['quotation_version_id']??0),
      'source'=>(string)($_POST['source']??'admin'),'request_type'=>(string)($_POST['request_type']??'auto'),
      'priority'=>(string)($_POST['priority']??'normal'),'request_text'=>$text,
      'requested_by_name'=>(string)($trip['customer_name']??''),'requested_by_email'=>(string)($trip['customer_email']??''),
      'assigned_admin_id'=>$adminId,'actor_id'=>$adminId
    ]);
    $_SESSION['cw_success']='Change request #'.$id.' recorded and Trip marked for requotation.';
  } elseif($action==='change_status'){
    $id=max(0,(int)($_POST['change_id']??0));$status=(string)($_POST['status']??'');
    $allowed=['open','in_review','requote_prepared','responded','resolved','rejected']; if(!in_array($status,$allowed,true))throw new RuntimeException('Invalid request status.');
    $stmt=$pdo->prepare("UPDATE crm_change_requests SET status=?,resolved_by_admin_id=CASE WHEN ? IN ('resolved','rejected') THEN ? ELSE resolved_by_admin_id END,resolved_at=CASE WHEN ? IN ('resolved','rejected') THEN NOW() ELSE NULL END,updated_at=NOW() WHERE id=? AND trip_id=?");
    $stmt->execute([$status,$status,$adminId,$status,$id,$tripId]);
    tsCWEvent($pdo,$tripId,$leadId,'change_request_status','Change request status updated','Request #'.$id.' → '.str_replace('_',' ',$status),'admin',$adminId,'internal',null,null,$id);
    $_SESSION['cw_success']='Change request status updated.';
  } elseif($action==='internal_note'){
    $note=trim((string)($_POST['note']??''));if($note==='')throw new RuntimeException('Enter a note.');
    tsCWEvent($pdo,$tripId,$leadId,'internal_note','Commercial internal note',$note,'admin',$adminId,'internal');
    $_SESSION['cw_success']='Internal note added.';
  } else throw new RuntimeException('Unknown action.');
  header('Location: '.BASE_URL.'admin-trip-commercial-hub.php?trip_id='.$tripId);exit;
 }catch(Throwable $e){$error=$e->getMessage();}
}

$state=tsCWState($pdo,$tripId);$changes=tsCWChangeRequests($pdo,$tripId);$latest=tsCWLatestQuotation($pdo,$leadId);$booking=tsCWBookingForTrip($pdo,$tripId);$timeline=tsCWTimeline($pdo,$tripId,$leadId,140);
$supplierRequests=[];
if(tsCWTableExists($pdo,'supplier_requests')){
 $stmt=$pdo->prepare("SELECT r.id,r.request_code,r.subject,r.status,r.sent_at,r.last_response_at,r.selected_quote_id,s.company_name FROM supplier_requests r JOIN suppliers s ON s.id=r.supplier_id WHERE r.trip_id=? ORDER BY r.created_at DESC");$stmt->execute([$tripId]);$supplierRequests=$stmt->fetchAll(PDO::FETCH_ASSOC)?:[];
}
function cwe($v){return htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function cwdate($v){$t=strtotime((string)$v);return $t?date('d M Y H:i',$t):'—';}
$stateLabel=str_replace('_',' ',(string)($state['status']??'clean'));
$stateClass=in_array(($state['status']??''),['requote_required','customer_change_requested','customer_rejected','supplier_cost_changed'],true)?'warn':(in_array(($state['status']??''),['customer_accepted','requote_prepared'],true)?'good':'info');
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Commercial Hub | TRAVSCOPE</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><style>
:root{--navy:#07192d;--blue:#0b74ff;--line:#dce5ef;--muted:#64748b;--bg:#f4f7fb;--green:#0f9f6e;--amber:#b76a00}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Inter,Arial,sans-serif;color:#172033}.top{background:var(--navy);color:#fff;padding:14px 22px;display:flex;justify-content:space-between;gap:12px;align-items:center}.wrap{max-width:1450px;margin:22px auto;padding:0 16px}.head,.panel{background:#fff;border:1px solid var(--line);border-radius:16px;padding:18px;margin-bottom:14px}.head{display:flex;justify-content:space-between;gap:15px;align-items:flex-start}.actions{display:flex;gap:8px;flex-wrap:wrap}.btn{border:0;border-radius:9px;padding:9px 12px;text-decoration:none;font-weight:800;font-size:12px;cursor:pointer;background:#eaf2ff;color:#0757b5}.btn.primary{background:var(--blue);color:#fff}.btn.good{background:#e8f8f1;color:#087a55}.btn.warn{background:#fff5df;color:#8a5600}.grid{display:grid;grid-template-columns:1.05fr .95fr;gap:14px}.metric-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.metric{border:1px solid var(--line);border-radius:12px;padding:13px;background:#fbfdff}.metric small{color:var(--muted);font-size:10px;text-transform:uppercase;font-weight:800}.metric strong{display:block;margin-top:5px}.state{display:inline-flex;padding:7px 10px;border-radius:999px;font-weight:900;text-transform:uppercase;font-size:11px}.state.good{background:#e8f8f1;color:#087a55}.state.warn{background:#fff5df;color:#8a5600}.state.info{background:#eaf2ff;color:#0757b5}.muted{color:var(--muted);font-size:12px}.alert{padding:12px;border-radius:10px;margin:10px 0}.alert.ok{background:#e8f8f1;color:#087a55}.alert.err{background:#fff0f0;color:#a72b2b}.req{border:1px solid var(--line);border-radius:12px;padding:12px;margin-top:9px}.reqtop{display:flex;justify-content:space-between;gap:8px}.pill{display:inline-block;padding:4px 7px;border-radius:999px;background:#eef3f8;font-size:10px;font-weight:800}.formgrid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.full{grid-column:1/-1}label{display:block;font-size:10px;font-weight:900;color:#64748b;margin-bottom:4px;text-transform:uppercase}input,select,textarea{width:100%;border:1px solid #cfd9e5;border-radius:8px;padding:9px;font:inherit}textarea{min-height:85px}.timeline{display:grid;gap:8px;max-height:700px;overflow:auto}.event{border-left:3px solid #cbd7e6;background:#fafcff;padding:10px 12px;border-radius:0 9px 9px 0}.event .meta{font-size:10px;color:#758399}.event strong{font-size:12px}.event p{white-space:pre-wrap;font-size:11px;color:#4d5e72;margin:5px 0 0}.supplier{padding:10px;border:1px solid var(--line);border-radius:10px;margin-top:8px}.supplier strong{font-size:12px}@media(max-width:900px){.grid,.metric-grid,.formgrid{grid-template-columns:1fr}.head{display:block}.actions{margin-top:12px}}
</style>
<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head><body><header class="top"><strong>TRAVSCOPE · COMMERCIAL CONTROL HUB</strong><span><?=cwe($trip['trip_code'])?></span></header><main class="wrap">
<section class="head"><div><h1 style="margin:0 0 5px">Customer ↔ Supplier ↔ Quotation Control</h1><div class="muted"><?=cwe($trip['customer_name'])?> · <?=cwe($trip['trip_title'])?> · <?=cwe($trip['travel_start_date']?:$trip['enquiry_travel_date']?:'Travel date pending')?></div></div><div class="actions"><a class="btn" href="<?=cwe(BASE_URL.'admin-crm.php?lead='.$leadId.'&trip='.$tripId.'#packageProposal')?>"><i class="fa-solid fa-arrow-left"></i> CRM</a><a class="btn" href="<?=cwe(BASE_URL.'admin-trip-contract-rates.php?trip_id='.$tripId)?>"><i class="fa-solid fa-table-cells"></i> Contract Rates</a><a class="btn" href="<?=cwe(BASE_URL.'admin-supplier-requests.php?lead='.$leadId.'&trip='.$tripId)?>"><i class="fa-solid fa-building"></i> Supplier Sourcing</a><a class="btn" href="<?=cwe(BASE_URL.'admin-communications.php?status=open') ?>"><i class="fa-solid fa-inbox"></i> Shared Inbox</a><?php if($booking):?><a class="btn good" href="<?=cwe(BASE_URL.'admin-booking-details.php?id='.(int)$booking['id'])?>"><i class="fa-solid fa-suitcase"></i> Booking</a><?php endif;?></div></section>
<?php if($success):?><div class="alert ok"><?=cwe($success)?></div><?php endif;?><?php if($error):?><div class="alert err"><?=cwe($error)?></div><?php endif;?>
<section class="panel"><div class="metric-grid"><div class="metric"><small>Commercial State</small><strong><span class="state <?=$stateClass?>"><?=cwe($stateLabel)?></span></strong></div><div class="metric"><small>Latest Quotation</small><strong><?= $latest?'V'.(int)$latest['version_number'].' · '.number_format((float)$latest['final_price'],2):'Not prepared' ?></strong></div><div class="metric"><small>Open Change Requests</small><strong><?=count(array_filter($changes,fn($r)=>in_array($r['status'],['open','in_review'],true)))?></strong></div><div class="metric"><small>Supplier Requests</small><strong><?=count($supplierRequests)?></strong></div></div><?php if(!empty($state['reason_text'])):?><div class="muted" style="margin-top:10px"><strong>Current reason:</strong> <?=cwe($state['reason_text'])?></div><?php endif;?></section>
<div class="grid"><div>
<section class="panel"><h2 style="margin-top:0">Customer Change Requests</h2><?php if(!$changes):?><div class="muted">No structured change request recorded yet.</div><?php endif;?><?php foreach($changes as $r):?><div class="req"><div class="reqtop"><div><span class="pill"><?=cwe(strtoupper($r['request_type']))?></span> <span class="pill"><?=cwe(str_replace('_',' ',$r['status']))?></span> <span class="pill"><?=cwe($r['source'])?></span></div><small class="muted"><?=cwdate($r['created_at'])?></small></div><p style="white-space:pre-wrap;font-size:12px"><?=cwe($r['request_text'])?></p><form method="post" class="actions"><input type="hidden" name="csrf" value="<?=cwe($csrf)?>"><input type="hidden" name="trip_id" value="<?=$tripId?>"><input type="hidden" name="action" value="change_status"><input type="hidden" name="change_id" value="<?=(int)$r['id']?>"><select name="status" style="width:auto"><option value="open">Open</option><option value="in_review">In Review</option><option value="requote_prepared">Requote Prepared</option><option value="responded">Responded</option><option value="resolved">Resolved</option><option value="rejected">Rejected</option></select><button class="btn" type="submit">Update</button></form></div><?php endforeach;?></section>
<section class="panel"><h2 style="margin-top:0">Record Change / Call / WhatsApp Requirement</h2><form method="post" class="formgrid"><input type="hidden" name="csrf" value="<?=cwe($csrf)?>"><input type="hidden" name="trip_id" value="<?=$tripId?>"><input type="hidden" name="action" value="add_change"><input type="hidden" name="quotation_version_id" value="<?=(int)($latest['id']??0)?>"><div><label>Source</label><select name="source"><option value="admin">Admin / Call</option><option value="phone">Phone</option><option value="whatsapp">WhatsApp</option><option value="email">Email</option></select></div><div><label>Type</label><select name="request_type"><option value="auto">Auto Detect</option><option value="dates">Dates</option><option value="hotel">Hotel</option><option value="pax">PAX</option><option value="vehicle">Vehicle</option><option value="itinerary">Itinerary</option><option value="activity">Activity</option><option value="meal">Meal</option><option value="price">Price</option><option value="documents">Documents</option><option value="other">Other</option></select></div><div><label>Priority</label><select name="priority"><option>normal</option><option>high</option><option>urgent</option></select></div><div class="full"><label>Exact Customer Requirement</label><textarea name="request_text" required></textarea></div><div class="full"><button class="btn primary" type="submit"><i class="fa-solid fa-plus"></i> Record & Require Requotation</button></div></form></section>
<section class="panel"><h2 style="margin-top:0">Supplier Conversations / RFQs</h2><?php if(!$supplierRequests):?><div class="muted">No supplier request linked to this Trip.</div><?php endif;?><?php foreach($supplierRequests as $r):?><div class="supplier"><strong><?=cwe($r['company_name'])?> · <?=cwe($r['request_code'])?></strong><div class="muted"><?=cwe($r['subject'])?> · <?=cwe(str_replace('_',' ',$r['status']))?><?=!empty($r['selected_quote_id'])?' · Quote selected':''?></div><div style="margin-top:6px"><a class="btn" href="<?=cwe(BASE_URL.'admin-supplier-request-details.php?id='.(int)$r['id'])?>">Open Conversation</a></div></div><?php endforeach;?></section>
</div><div>
<section class="panel"><h2 style="margin-top:0">Unified Timeline</h2><div class="timeline"><?php foreach($timeline as $e):?><div class="event"><div class="meta"><?=cwdate($e['ts']??'')?> · <?=cwe(strtoupper((string)($e['actor']??'system')))?> · <?=cwe((string)($e['channel']??'system'))?></div><strong><?=cwe((string)($e['summary']??$e['kind']??'Event'))?></strong><?php if(trim((string)($e['details']??''))!==''):?><p><?=cwe(mb_substr((string)$e['details'],0,1200))?></p><?php endif;?></div><?php endforeach;?></div></section>
<section class="panel"><h2 style="margin-top:0">Internal Commercial Note</h2><form method="post"><input type="hidden" name="csrf" value="<?=cwe($csrf)?>"><input type="hidden" name="trip_id" value="<?=$tripId?>"><input type="hidden" name="action" value="internal_note"><textarea name="note" required placeholder="Supplier called, customer wants 4★ instead of 3★, waiting for revised rate..."></textarea><button class="btn primary" type="submit" style="margin-top:8px">Add Note</button></form></section>
</div></div></main>
<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
