<?php
require_once __DIR__ . '/config.php';

$siteName=(string)getSetting($pdo,'site_name','TRAVSCOPE.COM');
$siteTagline=(string)getSetting($pdo,'site_tagline','Explore More. Travel Better.');

function storyDetailImage(?string $image): string{
 $image=trim((string)$image);
 if($image==='')return 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1600&q=85';
 if(preg_match('#^https?://#i',$image))return $image;
 return BASE_URL.ltrim($image,'/');
}

$slug=trim((string)($_GET['slug']??''));
if($slug===''){http_response_code(404);exit('Travel story not found.');}

$story=null;$gallery=[];$related=[];

try{
 $s=$pdo->prepare("
 SELECT b.*,c.name category_name,c.slug category_slug,
        d.name destination_name,d.slug destination_slug,d.country destination_country,
        p.title package_title,p.slug package_slug,p.main_image package_image,
        p.duration_days,p.duration_nights,p.sale_price,p.regular_price
 FROM blogs b
 LEFT JOIN blog_categories c ON c.id=b.category_id
 LEFT JOIN destinations d ON d.id=b.destination_id
 LEFT JOIN packages p ON p.id=b.package_id
 WHERE b.slug=? AND b.status='published' AND (b.published_at IS NULL OR b.published_at<=NOW())
 LIMIT 1
 ");
 $s->execute([$slug]);$story=$s->fetch(PDO::FETCH_ASSOC);
}catch(Throwable $e){}

if(!$story){http_response_code(404);exit('Travel story not found or currently unavailable.');}

try{$pdo->prepare("UPDATE blogs SET views=views+1 WHERE id=?")->execute([(int)$story['id']]);}catch(Throwable $e){}

try{$s=$pdo->prepare("SELECT * FROM blog_images WHERE blog_id=? ORDER BY sort_order ASC,id ASC");$s->execute([(int)$story['id']]);$gallery=$s->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){}

try{
 $where="b.status='published' AND b.id<>? AND (b.published_at IS NULL OR b.published_at<=NOW())";
 $params=[(int)$story['id']];
 if(!empty($story['destination_id'])){$where.=" AND b.destination_id=?";$params[]=(int)$story['destination_id'];}
 $s=$pdo->prepare("SELECT b.*,c.name category_name FROM blogs b LEFT JOIN blog_categories c ON c.id=b.category_id WHERE $where ORDER BY b.featured DESC,COALESCE(b.published_at,b.created_at) DESC LIMIT 3");
 $s->execute($params);$related=$s->fetchAll(PDO::FETCH_ASSOC);
}catch(Throwable $e){}

$metaTitle=trim((string)($story['meta_title']??'')) ?: $story['title'].' | '.$siteName;
$metaDesc=trim((string)($story['meta_description']??'')) ?: trim((string)($story['excerpt']??''));
if($metaDesc==='')$metaDesc=mb_substr(trim(preg_replace('/\s+/',' ',strip_tags($story['content']))),0,160);
$locationParts=array_values(array_filter([$story['location_name']??'',$story['city']??'',$story['state_name']??'',$story['country']??'']));
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="<?= e($metaDesc); ?>"><title><?= e($metaTitle); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
:root{--navy:#07192d;--blue:#0b74ff;--bg:#f5f8fc;--text:#172033;--muted:#748196;--border:#e4eaf1;--white:#fff;--shadow:0 16px 45px rgba(7,25,45,.09)}
*{box-sizing:border-box;margin:0;padding:0}body{font-family:'DM Sans',sans-serif;color:var(--text);background:#fff;line-height:1.7;font-size:16px}a{text-decoration:none;color:inherit}img{display:block;width:100%}.container{width:min(1180px,calc(100% - 34px));margin:auto}.nav{position:sticky;top:0;z-index:1000;background:rgba(255,255,255,.97);border-bottom:1px solid var(--border)}.navin{height:76px;display:flex;align-items:center;justify-content:space-between}.logo{display:flex;align-items:center;gap:10px;font:800 21px 'Manrope';color:var(--navy)}.logoicon{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;color:#fff;background:linear-gradient(135deg,var(--blue),#00b8ff)}.logo span{color:var(--blue)}.links{display:flex;gap:23px}.links a{font-size:14px;font-weight:700;color:#405067}.links a:hover{color:var(--blue)}
.hero{position:relative;min-height:560px;display:flex;align-items:flex-end;background:#07192d center/cover no-repeat}.hero:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(3,15,28,.08),rgba(3,15,28,.88))}.hero-content{position:relative;z-index:2;padding:90px 0 55px;color:#fff;max-width:900px}.tag{display:inline-flex;padding:7px 11px;border-radius:20px;background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.2);font-size:12px;font-weight:800}.hero h1{margin-top:14px;font:800 clamp(38px,6vw,65px)/1.08 'Manrope'}.meta{display:flex;gap:16px;flex-wrap:wrap;margin-top:17px;color:#d7e3ee;font-size:13px}
.layout{display:grid;grid-template-columns:minmax(0,1fr) 330px;gap:32px;padding:48px 0 80px}.article{min-width:0}.lead{padding-bottom:24px;margin-bottom:24px;border-bottom:1px solid var(--border);color:#536176;font-size:18px;line-height:1.8}.content{color:#3e4c60;font-size:16px;line-height:1.9}.content h1,.content h2,.content h3,.content h4{margin:31px 0 12px;color:var(--navy);font-family:'Manrope';line-height:1.3}.content p{margin:0 0 18px}.content ul,.content ol{margin:0 0 20px 25px;padding-left:16px}.content li{margin:7px 0}.content blockquote{margin:25px 0;padding:18px 20px;border-left:4px solid var(--blue);background:#f3f8ff;border-radius:9px}.gallery{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-top:32px}.gallery figure{overflow:hidden;border-radius:13px;background:#f0f3f6}.gallery img{height:260px;object-fit:cover}.gallery figcaption{padding:9px 11px;color:var(--muted);font-size:12px}
.sidebar{display:flex;flex-direction:column;gap:16px}.side-card{padding:20px;border:1px solid var(--border);border-radius:14px;background:#fff;box-shadow:var(--shadow)}.side-card h3{font:800 17px 'Manrope';color:var(--navy)}.side-card p{margin-top:8px;color:var(--muted);font-size:14px}.location-list{margin-top:12px;display:grid;gap:8px}.location-item{display:flex;gap:9px;align-items:flex-start;color:#526174;font-size:13px}.location-item i{margin-top:4px;color:var(--blue)}.btn{min-height:44px;margin-top:14px;padding:0 15px;border-radius:9px;display:inline-flex;align-items:center;justify-content:center;gap:7px;background:var(--blue);color:#fff;font-size:13px;font-weight:800}.package-img{height:145px;margin:-20px -20px 15px;overflow:hidden;border-radius:14px 14px 0 0}.package-img img{height:100%;object-fit:cover}
.related{padding:70px 0;background:var(--bg)}.heading{text-align:center;margin-bottom:30px}.heading h2{font:800 32px 'Manrope';color:var(--navy)}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.story-card{overflow:hidden;border:1px solid var(--border);border-radius:15px;background:#fff}.story-card img{height:190px;object-fit:cover}.story-card div{padding:16px}.story-card span{color:var(--blue);font-size:11px;font-weight:800}.story-card h3{margin-top:6px;font:800 17px/1.4 'Manrope';color:var(--navy)}
.footer{padding:40px 0;background:#051525;color:#9db0c2}.foot{display:flex;justify-content:space-between;align-items:center}.footer .logo{color:#fff}.footer p{font-size:13px}
@media(max-width:900px){.layout{grid-template-columns:1fr}.sidebar{display:grid;grid-template-columns:1fr 1fr}.links{display:none}}
@media(max-width:650px){.hero{min-height:500px}.layout{padding:35px 0 55px}.lead{font-size:17px}.gallery{grid-template-columns:1fr}.gallery img{height:230px}.sidebar{grid-template-columns:1fr}.grid{grid-template-columns:1fr}.foot{align-items:flex-start;flex-direction:column;gap:15px}}


/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL PUBLIC UI
   Visual-only override for a clean international travel website.
============================================================ */
:root{
    --ts-navy:#0b1f36;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f6f8fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-success:#15803d;
    --ts-danger:#b91c1c;
    --ts-radius:12px;
    --ts-shadow:0 8px 24px rgba(15,23,42,.06);
    --ts-shadow-hover:0 12px 30px rgba(15,23,42,.10);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);
}
html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.55!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Global brand/header */
.header,.site-header,.navbar,.topbar{
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.brand,.site-logo{
    font-weight:800!important;
    letter-spacing:-.4px!important;
}
.nav a,.navbar a,.menu a{
    font-size:13px!important;
    font-weight:700!important;
    border-radius:8px!important;
}

/* Headings */
h1,h2,h3,h4{
    color:var(--ts-navy);
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
}
h1{letter-spacing:-.7px}
h2{letter-spacing:-.4px}

/* Cards */
.card,.package-card,.booking-card,.review-card,.blog-card,.wishlist-card,.profile-card,.section,.panel{
    border-color:var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    box-shadow:var(--ts-shadow)!important;
}
.card:hover,.package-card:hover,.blog-card:hover,.wishlist-card:hover{
    box-shadow:var(--ts-shadow-hover)!important;
}

/* Forms */
label,.form-group label,.field label{
    color:#334155!important;
    font-size:12px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
    border:1px solid #cbd5e1!important;
    border-radius:8px!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,select:focus,textarea:focus,.form-control:focus,.control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:800!important;
}
.btn-primary,.button.primary,.cta,.submit-btn,.book-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.primary:hover,.cta:hover,.submit-btn:hover,.book-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}

/* Tables / account history */
table{font-size:12px!important}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    font-size:11px!important;
    font-weight:800!important;
}
td{font-size:12px!important}

/* Status / alerts */
.badge,.status,.tag,.chip{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{border-radius:9px!important;font-size:12px!important}

/* Readable supporting text */
small,.helper,.help,.muted,.subtext{font-size:11px!important;color:var(--ts-muted)!important}

/* Responsive touch sizes */
@media(max-width:700px){
    body{font-size:14px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.form-control,.control{
        min-height:44px!important;
        font-size:14px!important;
    }
    .btn,.button,.cta,.submit-btn,.book-btn,.login-btn,.register-btn{
        min-height:42px!important;
        font-size:12px!important;
    }
}

</style>
<!-- TRAVSCOPE PRO UNIFORM UI -->
<link rel="stylesheet" href="assets/travscope-pro-public.css?v=20260916-pro">
</head><body>
<nav class="nav"><div class="container navin"><a href="<?= e(BASE_URL); ?>" class="logo"><span class="logoicon"><i class="fa-solid fa-plane"></i></span>TRAV<span>SCOPE</span></a><div class="links"><a href="index.php">Home</a><a href="packages.php">Packages</a><a href="destinations.php">Destinations</a><a href="blog.php">Travel Stories</a><a href="contact.php">Contact</a></div></div></nav>
<section class="hero" style="background-image:url('<?= e(storyDetailImage($story['main_image'])); ?>')"><div class="container"><div class="hero-content"><span class="tag"><?= e($story['category_name'] ?: 'Travel Story'); ?></span><h1><?= e($story['title']); ?></h1><div class="meta"><span><i class="fa-solid fa-location-dot"></i> <?= e($story['location_name'] ?: $story['destination_name'] ?: $story['country'] ?: 'Travel'); ?></span><span><i class="fa-regular fa-calendar"></i> <?= e(date('d M Y',strtotime($story['published_at'] ?: $story['created_at']))); ?></span><span><i class="fa-regular fa-user"></i> <?= e($story['author_name']); ?></span><span><i class="fa-regular fa-eye"></i> <?= number_format((int)$story['views']+1); ?></span></div></div></div></section>
<div class="container"><div class="layout"><article class="article"><?php if(!empty($story['excerpt'])): ?><div class="lead"><?= e($story['excerpt']); ?></div><?php endif; ?><div class="content"><?= (string)$story['content']; ?></div>
<?php if($gallery): ?><div class="gallery"><?php foreach($gallery as $g): ?><figure><img src="<?= e(storyDetailImage($g['image'])); ?>" alt="<?= e($g['alt_text'] ?: $story['title']); ?>"><?php if(!empty($g['caption'])||!empty($g['location_name'])): ?><figcaption><?= e($g['caption'] ?: $g['location_name']); ?></figcaption><?php endif; ?></figure><?php endforeach; ?></div><?php endif; ?></article>
<aside class="sidebar">
<div class="side-card"><h3>Story Location</h3><div class="location-list"><?php foreach($locationParts as $part): ?><div class="location-item"><i class="fa-solid fa-location-dot"></i><span><?= e($part); ?></span></div><?php endforeach; ?><?php if(!empty($story['destination_name'])): ?><div class="location-item"><i class="fa-solid fa-earth-americas"></i><span><?= e($story['destination_name']); ?><?= !empty($story['destination_country'])?', '.$story['destination_country']:''; ?></span></div><?php endif; ?></div><?php if(!empty($story['destination_id'])): ?><a class="btn" href="packages.php?destination=<?= (int)$story['destination_id']; ?>">Explore This Destination</a><?php endif; ?></div>
<?php if(!empty($story['package_id'])): ?><div class="side-card"><?php if(!empty($story['package_image'])): ?><div class="package-img"><img src="<?= e(storyDetailImage($story['package_image'])); ?>" alt="<?= e($story['package_title']); ?>"></div><?php endif; ?><h3>Travel This Story</h3><p><?= e($story['package_title']); ?></p><a class="btn" href="package-details.php?slug=<?= urlencode($story['package_slug']); ?>">View Related Package <i class="fa-solid fa-arrow-right"></i></a></div><?php endif; ?>
<div class="side-card"><h3>Explore More Stories</h3><p>Discover more destinations, local experiences and travel ideas from TRAVSCOPE.</p><a class="btn" href="blog.php">All Travel Stories</a></div>
</aside></div></div>
<?php if($related): ?><section class="related"><div class="container"><div class="heading"><h2>More Stories You May Like</h2></div><div class="grid"><?php foreach($related as $r): ?><a class="story-card" href="blog-details.php?slug=<?= urlencode($r['slug']); ?>"><img src="<?= e(storyDetailImage($r['main_image'])); ?>" alt="<?= e($r['title']); ?>"><div><span><?= e($r['category_name'] ?: 'Travel Story'); ?></span><h3><?= e($r['title']); ?></h3></div></a><?php endforeach; ?></div></div></section><?php endif; ?>
<footer class="footer"><div class="container foot"><a href="<?= e(BASE_URL); ?>" class="logo"><span class="logoicon"><i class="fa-solid fa-plane"></i></span>TRAV<span>SCOPE</span></a><p><?= e($siteTagline); ?> &copy; <?= date('Y'); ?> TRAVSCOPE.COM</p></div></footer>

<script src="assets/travscope-pro-public.js?v=20260916-pro" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body></html>
