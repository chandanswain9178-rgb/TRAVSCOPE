<?php

/*
|--------------------------------------------------------------------------
| TRAVSCOPE ADMIN BOOKINGS
| HOTEL CATEGORY + PER-PERSON PRICE VERSION: 2026-08-04-R1
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/cancellation-workflow-functions.php';

/*
|--------------------------------------------------------------------------
| ADMIN AUTH
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_id'])) {
    redirect(BASE_URL . 'admin-login.php');
}

$adminId = (int)$_SESSION['admin_id'];

$stmt = $pdo->prepare("
    SELECT id, name, email, role, status
    FROM admins
    WHERE id = ?
    LIMIT 1
");

$stmt->execute([$adminId]);

$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin || $admin['status'] !== 'active') {
    unset($_SESSION['admin_id']);
    redirect(BASE_URL . 'admin-login.php');
}

/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_booking_csrf'])) {
    $_SESSION['admin_booking_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['admin_booking_csrf'];

/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function bookingMoney($amount, $currency = 'INR')
{
    $amount = (float)$amount;
    $currency = strtoupper(trim((string)$currency));

    if ($currency === 'INR') {
        return '₹' . number_format($amount, 2);
    }

    return $currency . ' ' . number_format($amount, 2);
}


function adminBookingHotelCategoryLabel(?string $category): string
{
    $category = strtolower(trim((string)$category));

    return match ($category) {
        '3_star', '3' => '3 Star Hotel',
        '4_star', '4' => '4 Star Hotel',
        '5_star', '5' => '5 Star Hotel',
        default => 'Not specified'
    };
}

function bookingStatusClass($status)
{
    switch ($status) {
        case 'confirmed':
            return 'success';

        case 'completed':
            return 'blue';

        case 'cancelled':
            return 'danger';

        default:
            return 'warning';
    }
}

function paymentStatusClass($status)
{
    switch ($status) {
        case 'paid':
            return 'success';

        case 'partial':
            return 'warning';

        case 'refunded':
            return 'blue';

        default:
            return 'danger';
    }
}

function safeDate($date, $format = 'd M Y')
{
    if (empty($date)) {
        return 'Not set';
    }

    $time = strtotime($date);

    if (!$time) {
        return 'Not set';
    }

    return date($format, $time);
}

/*
|--------------------------------------------------------------------------
| FLASH MESSAGE
|--------------------------------------------------------------------------
*/

$success = '';
$error = '';

if (!empty($_SESSION['admin_booking_success'])) {
    $success = $_SESSION['admin_booking_success'];
    unset($_SESSION['admin_booking_success']);
}

if (!empty($_SESSION['admin_booking_error'])) {
    $error = $_SESSION['admin_booking_error'];
    unset($_SESSION['admin_booking_error']);
}

/*
|--------------------------------------------------------------------------
| STATUS UPDATE
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $postedToken = (string)($_POST['csrf_token'] ?? '');

    if (
        $postedToken === '' ||
        !hash_equals(
            $_SESSION['admin_booking_csrf'] ?? '',
            $postedToken
        )
    ) {

        $error = 'Security verification failed. Please refresh and try again.';

    } else {

        $action = (string)($_POST['action'] ?? '');

        if ($action === 'change_booking_status') {

            $bookingId = (int)($_POST['booking_id'] ?? 0);

            $newStatus = strtolower(
                trim((string)($_POST['new_status'] ?? ''))
            );

            $allowedStatuses = [
                'pending',
                'confirmed',
                'cancelled',
                'completed'
            ];

            if ($bookingId <= 0) {

                $error = 'Invalid booking.';

            } elseif (!in_array($newStatus, $allowedStatuses, true)) {

                $error = 'Invalid booking status.';

            } else {

                try {

                    /*
                    |--------------------------------------------------------------------------
                    | FETCH CURRENT BOOKING
                    |--------------------------------------------------------------------------
                    */

                    $stmt = $pdo->prepare("
                        SELECT
                            id,
                            booking_number,
                            booking_status
                        FROM bookings
                        WHERE id = ?
                        LIMIT 1
                    ");

                    $stmt->execute([$bookingId]);

                    $booking = $stmt->fetch(PDO::FETCH_ASSOC);

                    if (!$booking) {
                        throw new RuntimeException(
                            'Booking not found.'
                        );
                    }

                    $currentStatus = $booking['booking_status'];

                    /*
                    |--------------------------------------------------------------------------
                    | VALID STATUS TRANSITIONS
                    |--------------------------------------------------------------------------
                    |
                    | pending   -> confirmed / cancelled
                    | confirmed -> completed / cancelled
                    |
                    | completed and cancelled are treated as final states here.
                    |
                    */

                    $allowedTransitions = [
                        'pending' => [
                            'confirmed',
                            'cancelled'
                        ],

                        'confirmed' => [
                            'completed',
                            'cancelled'
                        ],

                        'completed' => [],

                        'cancelled' => []
                    ];

                    if ($currentStatus === $newStatus) {

                        throw new RuntimeException(
                            'Booking already has this status.'
                        );
                    }

                    if (
                        !isset($allowedTransitions[$currentStatus]) ||
                        !in_array(
                            $newStatus,
                            $allowedTransitions[$currentStatus],
                            true
                        )
                    ) {

                        throw new RuntimeException(
                            'This booking cannot be changed from ' .
                            ucfirst($currentStatus) .
                            ' to ' .
                            ucfirst($newStatus) .
                            '.'
                        );
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | UPDATE
                    |--------------------------------------------------------------------------
                    */

                    if ($newStatus === 'cancelled') {
                        tsCancelRecordDirect($pdo,$bookingId,$adminId,'Bookings list');
                        $_SESSION['admin_cancellation_success'] = 'Booking cancelled. Complete the financial/refund review in Finance → Cancellations.';
                        redirect(BASE_URL . 'admin-cancellations.php?search=' . urlencode((string)$booking['booking_number']));
                    }

                    $stmt = $pdo->prepare("
                        UPDATE bookings
                        SET booking_status = ?
                        WHERE id = ?
                        LIMIT 1
                    ");

                    $stmt->execute([
                        $newStatus,
                        $bookingId
                    ]);

                    $_SESSION['admin_booking_success'] =
                        'Booking ' .
                        $booking['booking_number'] .
                        ' changed to ' .
                        ucfirst($newStatus) .
                        '.';

                    redirect(BASE_URL . 'admin-bookings.php');

                } catch (RuntimeException $e) {

                    $error = $e->getMessage();

                } catch (Throwable $e) {

                    error_log(
                        'Booking status error: ' .
                        $e->getMessage()
                    );

                    $error =
                        'Unable to update booking status.';
                }
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

$search = trim(
    (string)($_GET['q'] ?? '')
);

$bookingStatus = strtolower(
    trim((string)($_GET['booking_status'] ?? ''))
);

$paymentStatus = strtolower(
    trim((string)($_GET['payment_status'] ?? ''))
);

$hotelCategory = strtolower(
    trim((string)($_GET['hotel_category'] ?? ''))
);

if (
    !in_array(
        $hotelCategory,
        ['3_star', '4_star', '5_star'],
        true
    )
) {
    $hotelCategory = '';
}

$dateFrom = trim(
    (string)($_GET['date_from'] ?? '')
);

$dateTo = trim(
    (string)($_GET['date_to'] ?? '')
);

$allowedBookingStatuses = [
    'pending',
    'confirmed',
    'cancelled',
    'completed'
];

$allowedPaymentStatuses = [
    'unpaid',
    'partial',
    'paid',
    'refunded'
];

if (
    $bookingStatus !== '' &&
    !in_array(
        $bookingStatus,
        $allowedBookingStatuses,
        true
    )
) {
    $bookingStatus = '';
}

if (
    $paymentStatus !== '' &&
    !in_array(
        $paymentStatus,
        $allowedPaymentStatuses,
        true
    )
) {
    $paymentStatus = '';
}

/*
|--------------------------------------------------------------------------
| STATS
|--------------------------------------------------------------------------
*/

$stats = [
    'total' => 0,
    'pending' => 0,
    'confirmed' => 0,
    'completed' => 0,
    'cancelled' => 0,
    'paid' => 0,
    'revenue' => 0
];

try {

    $stmt = $pdo->query("
        SELECT
            COUNT(*) AS total,

            SUM(
                booking_status = 'pending'
            ) AS pending,

            SUM(
                booking_status = 'confirmed'
            ) AS confirmed,

            SUM(
                booking_status = 'completed'
            ) AS completed,

            SUM(
                booking_status = 'cancelled'
            ) AS cancelled,

            SUM(
                payment_status = 'paid'
            ) AS paid,

            COALESCE(
                SUM(paid_amount),
                0
            ) AS revenue

        FROM bookings
    ");

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {

        $stats['total'] =
            (int)($row['total'] ?? 0);

        $stats['pending'] =
            (int)($row['pending'] ?? 0);

        $stats['confirmed'] =
            (int)($row['confirmed'] ?? 0);

        $stats['completed'] =
            (int)($row['completed'] ?? 0);

        $stats['cancelled'] =
            (int)($row['cancelled'] ?? 0);

        $stats['paid'] =
            (int)($row['paid'] ?? 0);

        $stats['revenue'] =
            (float)($row['revenue'] ?? 0);
    }

} catch (Throwable $e) {

    error_log(
        'Booking stats error: ' .
        $e->getMessage()
    );
}

/*
|--------------------------------------------------------------------------
| BUILD QUERY
|--------------------------------------------------------------------------
*/

$where = [];
$params = [];

if ($search !== '') {

    $where[] = "
        (
            b.booking_number LIKE ?
            OR b.customer_name LIKE ?
            OR b.customer_email LIKE ?
            OR b.customer_mobile LIKE ?
            OR p.title LIKE ?
        )
    ";

    $term = '%' . $search . '%';

    array_push(
        $params,
        $term,
        $term,
        $term,
        $term,
        $term
    );
}

if ($bookingStatus !== '') {

    $where[] = "b.booking_status = ?";

    $params[] = $bookingStatus;
}

if ($paymentStatus !== '') {

    $where[] = "b.payment_status = ?";

    $params[] = $paymentStatus;
}

if ($hotelCategory !== '') {

    $where[] = "b.hotel_category = ?";

    $params[] = $hotelCategory;
}

if (
    $dateFrom !== '' &&
    preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)
) {

    $where[] = "b.travel_date >= ?";

    $params[] = $dateFrom;
}

if (
    $dateTo !== '' &&
    preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)
) {

    $where[] = "b.travel_date <= ?";

    $params[] = $dateTo;
}

$whereSql = '';

if ($where) {
    $whereSql =
        ' WHERE ' .
        implode(' AND ', $where);
}

/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/

$perPage = 12;

$page = max(
    1,
    (int)($_GET['page'] ?? 1)
);

$totalRows = 0;

try {

    $countSql = "
        SELECT COUNT(*)

        FROM bookings b

        LEFT JOIN packages p
            ON p.id = b.package_id

        {$whereSql}
    ";

    $stmt = $pdo->prepare($countSql);

    $stmt->execute($params);

    $totalRows =
        (int)$stmt->fetchColumn();

} catch (Throwable $e) {

    error_log(
        'Booking count error: ' .
        $e->getMessage()
    );
}

$totalPages = max(
    1,
    (int)ceil(
        $totalRows / $perPage
    )
);

if ($page > $totalPages) {
    $page = $totalPages;
}

$offset =
    ($page - 1) * $perPage;

/*
|--------------------------------------------------------------------------
| FETCH BOOKINGS
|--------------------------------------------------------------------------
*/

$bookings = [];

try {

    $sql = "
        SELECT

            b.id,
            b.booking_number,
            b.user_id,
            b.package_id,
            b.hotel_category,
            b.hotel_price,

            b.customer_name,
            b.customer_email,
            b.customer_mobile,

            b.travel_date,

            b.adults,
            b.children,

            b.total_amount,
            b.paid_amount,
            b.currency,

            b.booking_status,
            b.payment_status,

            b.special_request,

            b.created_at,
            b.updated_at,

            p.title AS package_title,
            p.slug AS package_slug,
            p.main_image AS package_image,
            p.duration_days,
            p.duration_nights,
            p.package_type,

            u.full_name AS registered_user_name,
            u.email AS registered_user_email,

            (
                SELECT COUNT(*)
                FROM payments pay
                WHERE pay.booking_id = b.id
            ) AS payment_count,

            (
                SELECT pay.status
                FROM payments pay
                WHERE pay.booking_id = b.id
                ORDER BY pay.id DESC
                LIMIT 1
            ) AS latest_payment_status,

            (
                SELECT pay.transaction_id
                FROM payments pay
                WHERE pay.booking_id = b.id
                ORDER BY pay.id DESC
                LIMIT 1
            ) AS latest_transaction_id

        FROM bookings b

        LEFT JOIN packages p
            ON p.id = b.package_id

        LEFT JOIN users u
            ON u.id = b.user_id

        {$whereSql}

        ORDER BY
            b.created_at DESC,
            b.id DESC

        LIMIT {$perPage}
        OFFSET {$offset}
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute($params);

    $bookings =
        $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {

    error_log(
        'Bookings fetch error: ' .
        $e->getMessage()
    );

    $error =
        'Unable to load bookings.';
}

/*
|--------------------------------------------------------------------------
| URL BUILDER FOR PAGINATION
|--------------------------------------------------------------------------
*/

function bookingPageUrl($page)
{
    $query = $_GET;

    $query['page'] = $page;

    return BASE_URL .
        'admin-bookings.php?' .
        http_build_query($query);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Bookings | TRAVSCOPE Admin</title>

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap"
    rel="stylesheet"
>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>

:root{
    --navy:#07192d;
    --navy2:#0c2947;
    --blue:#0b74ff;
    --blue2:#075fcf;
    --cyan:#00b8ff;
    --green:#07885f;
    --red:#d94355;
    --orange:#df8617;

    --bg:#f4f7fb;
    --white:#fff;

    --text:#172235;
    --muted:#7e8a9b;

    --border:#e1e8ef;

    --shadow:
        0 14px 40px rgba(7,25,45,.07);
}

*{
    box-sizing:border-box;
    margin:0;
    padding:0;
}

body{
    background:var(--bg);
    color:var(--text);
    font-family:'DM Sans',sans-serif;
}

a{
    color:inherit;
    text-decoration:none;
}

button,
input,
select{
    font:inherit;
}

/*
|--------------------------------------------------------------------------
| HEADER
|--------------------------------------------------------------------------
*/

.header{
    height:70px;
    padding:0 28px;

    position:sticky;
    top:0;
    z-index:1000;

    display:flex;
    align-items:center;
    justify-content:space-between;

    background:white;

    border-bottom:
        1px solid var(--border);
}

.logo{
    display:flex;
    align-items:center;
    gap:9px;

    color:var(--navy);

    font-family:'Manrope',sans-serif;
    font-size:18px;
    font-weight:800;
}

.logo-icon{
    width:38px;
    height:38px;

    border-radius:11px;

    display:grid;
    place-items:center;

    color:white;

    background:
        linear-gradient(
            135deg,
            var(--blue),
            var(--cyan)
        );
}

.logo span{
    color:var(--blue);
}

.admin{
    display:flex;
    align-items:center;
    gap:9px;
}

.avatar{
    width:38px;
    height:38px;

    border-radius:10px;

    display:grid;
    place-items:center;

    background:#edf5ff;

    color:var(--blue);

    font-weight:800;
}

.admin strong{
    display:block;

    font-size:10px;
}

.admin small{
    display:block;

    margin-top:2px;

    color:#929dab;

    font-size:8px;
}

/*
|--------------------------------------------------------------------------
| LAYOUT
|--------------------------------------------------------------------------
*/

.layout{
    min-height:
        calc(100vh - 70px);

    display:grid;

    grid-template-columns:
        230px minmax(0,1fr);
}

/*
|--------------------------------------------------------------------------
| SIDEBAR
|--------------------------------------------------------------------------
*/

.sidebar{
    padding:20px 13px;

    background:var(--navy);

    color:white;
}

.menu-title{
    padding:0 11px;

    margin:
        13px 0 7px;

    color:#71869c;

    font-size:7px;

    font-weight:800;

    text-transform:uppercase;

    letter-spacing:1px;
}

.sidebar a{
    min-height:43px;

    margin-bottom:4px;

    padding:0 12px;

    border-radius:9px;

    display:flex;

    align-items:center;

    gap:10px;

    color:#b6c5d4;

    font-size:9px;

    font-weight:700;
}

.sidebar a:hover,
.sidebar a.active{
    color:white;

    background:
        rgba(255,255,255,.1);
}

.sidebar a.active{
    background:
        linear-gradient(
            135deg,
            var(--blue),
            #0866dd
        );
}

.sidebar i{
    width:18px;

    text-align:center;
}

/*
|--------------------------------------------------------------------------
| MAIN
|--------------------------------------------------------------------------
*/

.main{
    min-width:0;

    padding:27px;
}

.page-head{
    margin-bottom:21px;

    display:flex;

    align-items:flex-end;

    justify-content:space-between;

    gap:20px;
}

.page-head h1{
    color:var(--navy);

    font-family:'Manrope',sans-serif;

    font-size:25px;
}

.page-head p{
    margin-top:5px;

    color:var(--muted);

    font-size:9px;
}

.refresh-btn{
    min-height:40px;

    padding:0 13px;

    border:
        1px solid var(--border);

    border-radius:8px;

    display:inline-flex;

    align-items:center;

    gap:6px;

    background:white;

    color:#5f6d80;

    font-size:8px;

    font-weight:800;
}

/*
|--------------------------------------------------------------------------
| ALERTS
|--------------------------------------------------------------------------
*/

.alert{
    margin-bottom:17px;

    padding:13px 15px;

    border-radius:10px;

    display:flex;

    align-items:center;

    gap:8px;

    font-size:9px;
}

.alert-success{
    border:
        1px solid #bce7d5;

    background:#eaf9f3;

    color:#08734f;
}

.alert-error{
    border:
        1px solid #f0c5cc;

    background:#fff0f2;

    color:#b43748;
}

/*
|--------------------------------------------------------------------------
| STATS
|--------------------------------------------------------------------------
*/

.stats{
    margin-bottom:20px;

    display:grid;

    grid-template-columns:
        repeat(5,1fr);

    gap:12px;
}

.stat{
    padding:16px;

    border:
        1px solid var(--border);

    border-radius:13px;

    background:white;

    box-shadow:var(--shadow);
}

.stat-top{
    display:flex;

    align-items:center;

    justify-content:space-between;
}

.stat-icon{
    width:35px;
    height:35px;

    border-radius:10px;

    display:grid;

    place-items:center;

    background:#edf5ff;

    color:var(--blue);
}

.stat strong{
    display:block;

    margin-top:12px;

    color:var(--navy);

    font-family:'Manrope',sans-serif;

    font-size:22px;
}

.stat span{
    display:block;

    margin-top:2px;

    color:#8d98a7;

    font-size:8px;
}

/*
|--------------------------------------------------------------------------
| CARD
|--------------------------------------------------------------------------
*/

.card{
    margin-bottom:20px;

    border:
        1px solid var(--border);

    border-radius:15px;

    overflow:hidden;

    background:white;

    box-shadow:var(--shadow);
}

.card-head{
    min-height:62px;

    padding:0 19px;

    border-bottom:
        1px solid var(--border);

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:15px;
}

.card-head h2{
    color:var(--navy);

    font-family:'Manrope',sans-serif;

    font-size:13px;
}

.card-head p{
    margin-top:3px;

    color:#929dab;

    font-size:8px;
}

.card-body{
    padding:19px;
}

/*
|--------------------------------------------------------------------------
| FILTER
|--------------------------------------------------------------------------
*/

.filters{
    display:grid;

    grid-template-columns:
        2fr 1fr 1fr 1fr 1fr 1fr auto;

    gap:8px;
}

.control{
    width:100%;

    height:41px;

    padding:0 10px;

    border:
        1px solid #dfe6ed;

    border-radius:8px;

    outline:none;

    background:white;

    color:#39475a;

    font-size:8px;
}

.control:focus{
    border-color:#8abaff;

    box-shadow:
        0 0 0 3px
        rgba(11,116,255,.06);
}

.filter-btn{
    height:41px;

    padding:0 14px;

    border:0;

    border-radius:8px;

    cursor:pointer;

    background:var(--navy);

    color:white;

    font-size:8px;

    font-weight:800;
}

.clear-filter{
    margin-top:10px;

    display:inline-flex;

    align-items:center;

    gap:5px;

    color:var(--blue);

    font-size:8px;

    font-weight:700;
}

/*
|--------------------------------------------------------------------------
| BOOKING MANAGEMENT TABLE
|--------------------------------------------------------------------------
*/

.table-wrap{
    width:100%;
    overflow-x:auto;
}

.booking-table{
    width:100%;
    min-width:1320px;
    border-collapse:collapse;
}

.booking-table thead{
    background:#f8fafc;
}

.booking-table th{
    padding:11px 12px;
    border-bottom:1px solid var(--border);
    color:#8793a3;
    font-size:7px;
    font-weight:800;
    text-align:left;
    text-transform:uppercase;
    letter-spacing:.45px;
    white-space:nowrap;
}

.booking-table td{
    padding:12px;
    border-bottom:1px solid #edf1f5;
    color:#465469;
    font-size:8px;
    vertical-align:middle;
}

.booking-table tbody tr:hover{
    background:#fbfdff;
}

.booking-no{
    color:var(--navy);
    font-family:'Manrope',sans-serif;
    font-size:9px;
    font-weight:800;
    white-space:nowrap;
}

.subtext{
    margin-top:3px;
    color:#929dab;
    font-size:7px;
}

.customer-cell strong,
.package-cell strong{
    display:block;
    max-width:190px;
    overflow:hidden;
    color:#26364a;
    font-size:8px;
    text-overflow:ellipsis;
    white-space:nowrap;
}

.package-cell strong{
    color:var(--navy);
}

.money-main{
    color:var(--navy);
    font-size:9px;
    font-weight:800;
    white-space:nowrap;
}

.money-balance{
    margin-top:3px;
    color:var(--orange);
    font-size:7px;
    white-space:nowrap;
}

.badge{
    display:inline-flex;
    align-items:center;
    gap:4px;
    padding:5px 8px;
    border-radius:20px;
    font-size:7px;
    font-weight:800;
    text-transform:capitalize;
    white-space:nowrap;
}

.badge-success{background:#e8f8f1;color:var(--green);}
.badge-warning{background:#fff6e7;color:#bf7415;}
.badge-danger{background:#fff0f2;color:var(--red);}
.badge-blue{background:#edf5ff;color:var(--blue);}

.table-actions{
    display:flex;
    align-items:center;
    gap:5px;
    flex-wrap:wrap;
    min-width:230px;
}

.table-actions form{
    margin:0;
}

.btn{
    min-height:31px;
    padding:0 8px;
    border:0;
    border-radius:6px;
    cursor:pointer;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:4px;
    font-size:7px;
    font-weight:800;
    white-space:nowrap;
}

.btn-details{background:#edf5ff;color:var(--blue);}
.btn-confirm{background:#e9f9f2;color:var(--green);}
.btn-complete{background:#edf5ff;color:var(--blue);}
.btn-cancel{background:#fff0f2;color:var(--red);}
.payment-link{background:#f4f6f8;color:#627084;}

/*
|--------------------------------------------------------------------------
| EMPTY
|--------------------------------------------------------------------------
*/

.empty{
    padding:60px 20px;

    text-align:center;
}

.empty-icon{
    width:70px;
    height:70px;

    margin:
        0 auto 14px;

    border-radius:20px;

    display:grid;

    place-items:center;

    background:#edf5ff;

    color:var(--blue);

    font-size:25px;
}

.empty h3{
    color:var(--navy);

    font-family:'Manrope',sans-serif;

    font-size:14px;
}

.empty p{
    margin-top:6px;

    color:#8b97a6;

    font-size:8px;
}

/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/

.pagination{
    margin-top:20px;

    display:flex;

    align-items:center;

    justify-content:center;

    gap:5px;

    flex-wrap:wrap;
}

.page-btn{
    min-width:35px;
    height:35px;

    padding:0 9px;

    border:
        1px solid var(--border);

    border-radius:7px;

    display:grid;

    place-items:center;

    background:white;

    color:#617084;

    font-size:8px;

    font-weight:800;
}

.page-btn:hover{
    border-color:#a9cdf9;

    color:var(--blue);
}

.page-btn.active{
    border-color:var(--blue);

    background:var(--blue);

    color:white;
}

/*
|--------------------------------------------------------------------------
| RESPONSIVE
|--------------------------------------------------------------------------
*/

@media(max-width:1150px){

    .stats{
        grid-template-columns:
            repeat(3,1fr);
    }

    .filters{
        grid-template-columns:
            repeat(3,1fr);
    }
}

@media(max-width:900px){

    .layout{
        grid-template-columns:1fr;
    }

    .sidebar{
        display:none;
    }

    .main{
        padding:18px;
    }

}

@media(max-width:650px){

    .header{
        padding:0 13px;
    }

    .admin > div:last-child{
        display:none;
    }

    .main{
        padding:13px;
    }

    .page-head{
        align-items:flex-start;

        flex-direction:column;
    }

    .stats{
        grid-template-columns:
            repeat(2,1fr);
    }

    .filters{
        grid-template-columns:1fr;
    }

}


/*
|--------------------------------------------------------------------------
| READABLE DEFAULT ADMIN TEXT SIZE — 2026-08-05
| Only typography is adjusted. All existing code and functionality stay intact.
|--------------------------------------------------------------------------
*/

body{
    font-size:15px;
    line-height:1.5;
}

.logo{font-size:20px;}
.admin strong{font-size:14px;}
.admin small{font-size:12px;}

.menu-title{font-size:11px;}
.sidebar a{font-size:14px;}

.page-head h1{font-size:28px;}
.page-head p{font-size:14px;}
.refresh-btn{font-size:13px;}
.alert{font-size:14px;}

.stat strong{font-size:24px;}
.stat span{font-size:13px;}

.card-head h2{font-size:17px;}
.card-head p{font-size:13px;}

.control,
.filter-btn{font-size:13px;}
.clear-filter{font-size:13px;}

.booking-table th{font-size:11px;}
.booking-table td{font-size:13px;}
.booking-no{font-size:14px;}
.subtext{font-size:11px;line-height:1.45;}
.customer-cell strong,
.package-cell strong{font-size:13px;}
.money-main{font-size:14px;}
.money-balance{font-size:12px;}
.badge{font-size:11px;}
.btn{font-size:12px;}

.empty h3{font-size:18px;}
.empty p{font-size:13px;}
.page-btn{font-size:13px;}

@media(max-width:650px){
    body{font-size:14px;}
    .page-head h1{font-size:24px;}
    .control,
    .filter-btn{font-size:14px;}
}



/* ============================================================
   TRAVSCOPE UNIFIED PROFESSIONAL ADMIN UI
   Visual-only override: colors, typography, spacing, forms,
   cards, tables and responsive presentation.
============================================================ */
:root{
    --ts-navy:#0f172a;
    --ts-navy-2:#111c32;
    --ts-blue:#2563eb;
    --ts-blue-hover:#1d4ed8;
    --ts-blue-soft:#eff6ff;
    --ts-cyan:#0ea5e9;
    --ts-bg:#f4f7fb;
    --ts-surface:#ffffff;
    --ts-soft:#f8fafc;
    --ts-text:#1e293b;
    --ts-muted:#64748b;
    --ts-border:#e2e8f0;
    --ts-border-strong:#cbd5e1;
    --ts-success:#15803d;
    --ts-success-soft:#ecfdf3;
    --ts-warning:#b45309;
    --ts-warning-soft:#fff7ed;
    --ts-danger:#b91c1c;
    --ts-danger-soft:#fef2f2;
    --ts-radius:10px;
    --ts-shadow:0 6px 18px rgba(15,23,42,.055);
    --ts-shadow-hover:0 10px 26px rgba(15,23,42,.085);
    --ts-focus:0 0 0 3px rgba(37,99,235,.14);

    --navy:var(--ts-navy);
    --blue:var(--ts-blue);
    --cyan:var(--ts-cyan);
    --bg:var(--ts-bg);
    --white:var(--ts-surface);
    --text:var(--ts-text);
    --muted:var(--ts-muted);
    --border:var(--ts-border);
    --green:var(--ts-success);
    --orange:var(--ts-warning);
    --red:var(--ts-danger);
    --shadow:var(--ts-shadow);
}

html{-webkit-text-size-adjust:100%;text-rendering:optimizeLegibility}
body{
    background:var(--ts-bg)!important;
    color:var(--ts-text)!important;
    font-family:"DM Sans",Arial,Helvetica,sans-serif!important;
    font-size:14px!important;
    line-height:1.5!important;
}
button,input,select,textarea{font:inherit}
a,button,input,select,textarea{-webkit-tap-highlight-color:transparent}
a:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{
    outline:none!important;
    box-shadow:var(--ts-focus)!important;
}

/* Side navigation */
.sidebar,.admin-sidebar,.odisha-style-sidebar{
    background:linear-gradient(180deg,var(--ts-navy) 0%,var(--ts-navy-2) 100%)!important;
    color:#fff!important;
}
.sidebar a,.admin-sidebar a,.odisha-style-nav-link,.menu-link{
    border-radius:8px!important;
    font-size:12px!important;
    font-weight:700!important;
}
.sidebar a.active,.admin-sidebar a.active,.odisha-style-nav-link.active,.menu-link.active{
    background:linear-gradient(135deg,var(--ts-blue),#3b82f6)!important;
    color:#fff!important;
    box-shadow:0 5px 14px rgba(37,99,235,.22)!important;
}
.menu-title,.sidebar-title,.odisha-style-menu-label{
    color:#64748b!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.9px!important;
}

/* Header/topbar */
.header,.topbar,.admin-header{
    background:rgba(255,255,255,.97)!important;
    border-bottom:1px solid var(--ts-border)!important;
    box-shadow:0 1px 0 rgba(15,23,42,.02)!important;
}
.logo,.topbar-title,.odisha-style-topbar-title{
    color:var(--ts-navy)!important;
    font-weight:800!important;
}
.admin strong,.header-user strong{font-size:13px!important}
.admin small,.header-user span{font-size:11px!important;color:var(--ts-muted)!important}

/* Main headings */
.page-head h1,.page-heading h1,.main h1{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:26px!important;
    line-height:1.15!important;
    font-weight:800!important;
    letter-spacing:-.55px!important;
}
.page-head p,.page-heading p{
    color:var(--ts-muted)!important;
    font-size:12px!important;
}

/* Cards */
.card,.panel,.customer-card,.stat,.stat-card,.profile-manager,.booking-card{
    border:1px solid var(--ts-border)!important;
    border-radius:var(--ts-radius)!important;
    background:#fff!important;
    box-shadow:var(--ts-shadow)!important;
}
.card-head,.card-header,.section-header{
    border-bottom:1px solid var(--ts-border)!important;
    background:#fff!important;
}
.card-head h2,.card-head h3,.card-header h2,.card-header h3,.section-title h2{
    color:var(--ts-navy)!important;
    font-family:"Manrope","DM Sans",Arial,sans-serif!important;
    font-size:15px!important;
    font-weight:800!important;
}
.card-head p,.card-header p,.section-title p{
    color:var(--ts-muted)!important;
    font-size:10px!important;
}

/* Statistics */
.stat span,.stat-card span,.metric span{
    color:var(--ts-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
.stat strong,.stat-card strong{
    color:var(--ts-navy)!important;
    font-size:21px!important;
    font-weight:800!important;
}
.metric strong{font-size:13px!important}

/* Forms */
label,.field label,.form-group label,.admin-label{
    color:#334155!important;
    font-size:11px!important;
    font-weight:700!important;
}
input:not([type="checkbox"]):not([type="radio"]),
select,textarea,.control,.form-control,.admin-field,.pm-control{
    border:1px solid var(--ts-border-strong)!important;
    border-radius:7px!important;
    background:#fff!important;
    color:var(--ts-text)!important;
    font-size:13px!important;
}
input:not([type="checkbox"]):not([type="radio"]):focus,
select:focus,textarea:focus,.control:focus,.form-control:focus,.admin-field:focus,.pm-control:focus{
    border-color:#60a5fa!important;
    box-shadow:var(--ts-focus)!important;
    outline:none!important;
}
input::placeholder,textarea::placeholder{color:#94a3b8!important}

/* Buttons */
.btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button,.page-button,.page-btn{
    border-radius:7px!important;
    font-size:11px!important;
    font-weight:800!important;
}
.btn-primary,.button.blue,.profile-save,.pm-save,.filter-btn{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}
.btn-primary:hover,.button.blue:hover,.profile-save:hover,.pm-save:hover,.filter-btn:hover{
    background:var(--ts-blue-hover)!important;
    border-color:var(--ts-blue-hover)!important;
}
.btn-secondary,.button.light{
    background:#fff!important;
    border-color:var(--ts-border)!important;
    color:#475569!important;
}

/* Tables */
table{
    color:var(--ts-text)!important;
    font-size:11px!important;
}
th{
    background:var(--ts-soft)!important;
    color:#64748b!important;
    border-bottom:1px solid var(--ts-border)!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.45px!important;
}
td{
    border-top:1px solid #eef2f6!important;
    font-size:11px!important;
}
tbody tr:hover{background:#fbfdff!important}

/* Badges/status */
.badge,.status,.status-badge,.mini-status{
    border-radius:999px!important;
    font-size:10px!important;
    font-weight:800!important;
}
.alert{
    border-radius:8px!important;
    font-size:12px!important;
}
.alert-success{
    background:var(--ts-success-soft)!important;
    border-color:#bbf7d0!important;
    color:#166534!important;
}
.alert-error{
    background:var(--ts-danger-soft)!important;
    border-color:#fecaca!important;
    color:#991b1b!important;
}

/* Compact spacing */
.main,.content,.page{min-width:0}
.card-body,.section-body{padding:14px!important}
.form-grid,.filters,.info-grid{gap:10px!important}

/* Pagination */
.pagination{gap:5px!important}
.page-btn,.page-button{
    min-width:34px!important;
    height:34px!important;
    background:#fff!important;
    border:1px solid var(--ts-border)!important;
    color:#475569!important;
}
.page-btn.active,.page-button.active{
    background:var(--ts-blue)!important;
    border-color:var(--ts-blue)!important;
    color:#fff!important;
}

/* Responsive */
@media(max-width:900px){
    .page-head h1,.page-heading h1,.main h1{font-size:23px!important}
}
@media(max-width:700px){
    body{font-size:14px!important}
    .page-head h1,.page-heading h1,.main h1{font-size:22px!important}
    input:not([type="checkbox"]):not([type="radio"]),select,textarea,.control,.form-control,.admin-field,.pm-control{
        min-height:42px!important;
        font-size:14px!important;
    }
    .btn,.button,.filter-btn,.refresh-btn,.save-top,.profile-save,.pm-save,.action,.view-button{
        min-height:38px!important;
        font-size:11px!important;
    }
    .card-body,.section-body{padding:12px!important}
}



/* BOOKINGS — GRAPHICAL PROFESSIONAL VIEW / VISUAL ONLY */
.main{padding:16px 18px 20px!important}
.page-head{margin-bottom:11px!important;align-items:center!important}
.page-head h1{font-size:25px!important;line-height:1.15!important}
.page-head p{margin-top:3px!important;font-size:11px!important;line-height:1.4!important}
.refresh-btn{min-height:35px!important;padding:0 11px!important;font-size:10px!important}
.stats{grid-template-columns:repeat(5,minmax(0,1fr))!important;gap:8px!important;margin-bottom:9px!important}
.stat{min-height:82px!important;padding:11px 12px!important;border-radius:10px!important;position:relative;overflow:hidden;box-shadow:0 5px 16px rgba(15,23,42,.045)!important}
.stat:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px}
.stat:nth-child(1){background:linear-gradient(135deg,#fff,#eff6ff)!important;border-color:#dce9fb!important}.stat:nth-child(1):before{background:#2563eb}.stat:nth-child(1) .stat-icon{background:#dbeafe!important;color:#2563eb!important}
.stat:nth-child(2){background:linear-gradient(135deg,#fff,#fff7ed)!important;border-color:#f4e3ce!important}.stat:nth-child(2):before{background:#ea8b22}.stat:nth-child(2) .stat-icon{background:#ffedd5!important;color:#d97706!important}
.stat:nth-child(3){background:linear-gradient(135deg,#fff,#ecfdf5)!important;border-color:#d8f1e5!important}.stat:nth-child(3):before{background:#0f9a68}.stat:nth-child(3) .stat-icon{background:#d1fae5!important;color:#059669!important}
.stat:nth-child(4){background:linear-gradient(135deg,#fff,#f5f3ff)!important;border-color:#e7e0fb!important}.stat:nth-child(4):before{background:#7c5bd1}.stat:nth-child(4) .stat-icon{background:#ede9fe!important;color:#7c3aed!important}
.stat:nth-child(5){background:linear-gradient(135deg,#fff,#eefbff)!important;border-color:#d9eef5!important}.stat:nth-child(5):before{background:#0d8eaf}.stat:nth-child(5) .stat-icon{background:#cffafe!important;color:#0891b2!important}
.stat-icon{width:32px!important;height:32px!important;border-radius:8px!important;font-size:12px!important}
.stat strong{margin-top:6px!important;font-size:19px!important;line-height:1!important}
.stat span{margin-top:3px!important;font-size:9px!important}
.card{margin-bottom:9px!important;border-radius:10px!important}
.card-head{min-height:46px!important;padding:8px 12px!important}
.card-head h2{font-size:14px!important}.card-head p{margin-top:2px!important;font-size:9px!important}
.card-body{padding:10px 12px!important}
.filters{grid-template-columns:minmax(260px,2fr) repeat(5,minmax(125px,1fr)) auto!important;gap:6px!important}
.control{height:35px!important;min-height:35px!important;padding:0 8px!important;font-size:10px!important;border-radius:7px!important}
.filter-btn{height:35px!important;min-height:35px!important;padding:0 11px!important;font-size:10px!important;background:linear-gradient(135deg,#2563eb,#3b82f6)!important;box-shadow:0 4px 10px rgba(37,99,235,.15)}
.clear-filter{margin-top:6px!important;font-size:9px!important}
.booking-table{min-width:1220px!important}
.booking-table th{padding:7px 8px!important;font-size:8px!important}
.booking-table td{padding:8px!important;font-size:9px!important;line-height:1.3!important}
.booking-no{font-size:10px!important}.subtext{margin-top:2px!important;font-size:8px!important}
.customer-cell strong,.package-cell strong{font-size:9px!important}
.money-main{font-size:10px!important}.money-balance{font-size:8px!important}
.badge{padding:4px 7px!important;font-size:8px!important}
.booking-table button,.booking-table select,.booking-table .action-btn{min-height:29px!important;font-size:8px!important;border-radius:6px!important}
@media(max-width:1180px){.stats{grid-template-columns:repeat(3,minmax(0,1fr))!important}.filters{grid-template-columns:repeat(3,minmax(0,1fr))!important}}
@media(max-width:760px){.main{padding:11px 8px 16px!important}.page-head{align-items:flex-start!important;flex-direction:column!important}.stats{grid-template-columns:repeat(2,minmax(0,1fr))!important}.filters{grid-template-columns:1fr!important}.control,.filter-btn{min-height:40px!important;height:40px!important;font-size:12px!important}}
@media(max-width:450px){.stats{grid-template-columns:1fr!important}}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}


/* ============================================================
   MODERN PROFESSIONAL SIDEBAR NAVIGATION
   VISUAL ONLY — LINKS, COUNTS AND DASHBOARD LOGIC UNCHANGED
============================================================ */

.sidebar{
    width:265px !important;
    background:
        linear-gradient(180deg,#0b172a 0%,#101d33 58%,#0c1829 100%) !important;
    border-right:1px solid rgba(255,255,255,.045) !important;
    box-shadow:10px 0 30px rgba(10,24,43,.08) !important;
}

.sidebar-logo{
    height:72px !important;
    padding:0 17px !important;
    gap:10px !important;
    border-bottom:1px solid rgba(255,255,255,.08) !important;
    font-size:16px !important;
    letter-spacing:-.2px !important;
}

.sidebar-logo .logo-icon{
    width:38px !important;
    height:38px !important;
    border-radius:11px !important;
    background:linear-gradient(135deg,#1577ff,#0bb9ee) !important;
    box-shadow:0 7px 18px rgba(11,116,255,.25) !important;
}

.sidebar-menu{
    padding:12px 10px 24px !important;
}

/* Group titles */
.menu-title{
    position:relative !important;
    margin:9px 7px 6px !important;
    padding:7px 8px 7px 10px !important;
    color:#75869c !important;
    font-size:9px !important;
    font-weight:800 !important;
    letter-spacing:1.1px !important;
    line-height:1 !important;
}

.menu-title:before{
    content:"";
    position:absolute;
    left:0;
    top:50%;
    width:3px;
    height:13px;
    border-radius:999px;
    transform:translateY(-50%);
    background:#2d7ff9;
    opacity:.55;
}

/* Navigation buttons */
.menu-link{
    min-height:42px !important;
    margin:3px 0 !important;
    padding:0 9px !important;
    gap:9px !important;
    border:1px solid transparent !important;
    border-radius:10px !important;
    color:#aebbd0 !important;
    font-size:11px !important;
    font-weight:700 !important;
    transition:
        background .16s ease,
        border-color .16s ease,
        color .16s ease,
        transform .16s ease,
        box-shadow .16s ease !important;
}

.menu-link i{
    width:29px !important;
    height:29px !important;
    flex:0 0 29px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:8px !important;
    background:rgba(255,255,255,.055) !important;
    color:#90a3bb !important;
    font-size:11px !important;
    transition:.16s ease !important;
}

.menu-link:hover{
    color:#fff !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    transform:translateX(2px) !important;
}

.menu-link:hover i{
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
}

/* Active item */
.menu-link.active{
    color:#fff !important;
    background:
        linear-gradient(135deg,#2563eb 0%,#3b82f6 58%,#2875f0 100%) !important;
    border-color:rgba(119,173,255,.45) !important;
    box-shadow:
        0 7px 16px rgba(37,99,235,.23),
        inset 0 1px 0 rgba(255,255,255,.14) !important;
}

.menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.10) !important;
}

/* Give menu categories subtle individual icon colours */
.sidebar-menu .menu-link[href*="crm"] i{
    background:rgba(124,91,209,.14) !important;
    color:#b5a1f8 !important;
}

.sidebar-menu .menu-link[href*="destination"] i{
    background:rgba(14,165,233,.13) !important;
    color:#77d2f3 !important;
}

.sidebar-menu .menu-link[href*="package"] i{
    background:rgba(245,158,11,.14) !important;
    color:#f7bf5b !important;
}

.sidebar-menu .menu-link[href*="gallery"] i{
    background:rgba(16,185,129,.13) !important;
    color:#67dcb6 !important;
}

.sidebar-menu .menu-link[href*="booking"] i{
    background:rgba(99,102,241,.14) !important;
    color:#a8aaf7 !important;
}

.sidebar-menu .menu-link[href*="cancellation"] i{
    background:rgba(244,63,94,.14) !important;
    color:#f394a6 !important;
}

.sidebar-menu .menu-link[href*="coupon"] i{
    background:rgba(6,182,212,.13) !important;
    color:#72d8e9 !important;
}

.sidebar-menu .menu-link[href*="enquir"] i{
    background:rgba(59,130,246,.14) !important;
    color:#8db9f6 !important;
}

.sidebar-menu .menu-link[href*="customer"] i,
.sidebar-menu .menu-link[href*="users"] i{
    background:rgba(20,184,166,.13) !important;
    color:#72d7ca !important;
}

.sidebar-menu .menu-link[href*="review"] i{
    background:rgba(234,179,8,.14) !important;
    color:#f4d35f !important;
}

.sidebar-menu .menu-link[href*="blog"] i,
.sidebar-menu .menu-link[href*="story"] i{
    background:rgba(168,85,247,.14) !important;
    color:#c9a0f8 !important;
}

.sidebar-menu .menu-link[href*="settings"] i{
    background:rgba(148,163,184,.14) !important;
    color:#bac5d2 !important;
}

.sidebar-menu .menu-link[href*="website"] i{
    background:rgba(34,197,94,.13) !important;
    color:#72dc92 !important;
}

/* Active icon always follows active design */
.sidebar-menu .menu-link.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}

/* Modern badges */
.menu-badge{
    min-width:21px !important;
    height:21px !important;
    padding:0 6px !important;
    border:1px solid rgba(255,255,255,.13) !important;
    border-radius:999px !important;
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
    color:#fff !important;
    font-size:9px !important;
    font-weight:800 !important;
    box-shadow:0 3px 8px rgba(0,0,0,.15) !important;
}

/* Override old inline badge colours for consistent modern look */
.menu-link .menu-badge[style]{
    background:linear-gradient(135deg,#1d75db,#3189ef) !important;
}

/* CRM badge slightly purple */
.sidebar-menu .menu-link[href*="crm"] .menu-badge{
    background:linear-gradient(135deg,#7450d5,#9369ed) !important;
}

/* Destructive / alert type badge */
.sidebar-menu .menu-link[href*="cancellation"] .menu-badge{
    background:linear-gradient(135deg,#d84b61,#ec6377) !important;
}

/* Bottom website/settings area feels separated */
.sidebar-menu .menu-title:last-of-type{
    margin-top:14px !important;
}

/* Slim scrollbar */
.sidebar{
    scrollbar-width:thin;
    scrollbar-color:#314158 transparent;
}

.sidebar::-webkit-scrollbar{
    width:5px;
}

.sidebar::-webkit-scrollbar-thumb{
    background:#314158;
    border-radius:999px;
}

.sidebar::-webkit-scrollbar-track{
    background:transparent;
}

/* Keep main alignment exactly with sidebar width */
.main{
    margin-left:265px !important;
}

@media(max-width:850px){
    .main{
        margin-left:0 !important;
    }

    .sidebar{
        width:265px !important;
    }
}



/* ============================================================
   TRAVSCOPE MODERN LEFT PANEL — VISUAL ONLY
   Matches admin-dashboard.php navigation style.
   No PHP, database, form, action, link or page logic changed.
============================================================ */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    background:
        radial-gradient(circle at top left,rgba(40,117,255,.22),transparent 28%),
        radial-gradient(circle at bottom right,rgba(15,154,104,.12),transparent 24%),
        linear-gradient(180deg,#081225 0%,#0d1830 100%) !important;
    color:#fff !important;
    border-right:1px solid rgba(255,255,255,.06) !important;
    box-shadow:14px 0 38px rgba(4,10,24,.28),inset -1px 0 0 rgba(255,255,255,.03) !important;
}
.sidebar-logo,
.odisha-style-logo{
    margin:12px 12px 8px !important;
    padding:14px !important;
    min-height:68px !important;
    height:auto !important;
    border:1px solid rgba(255,255,255,.07) !important;
    border-radius:16px !important;
    background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03)) !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 10px 24px rgba(0,0,0,.16) !important;
}
.logo-icon,
.odisha-style-logo-icon{
    box-shadow:0 10px 24px rgba(37,99,235,.28) !important;
}
.sidebar-menu{padding:6px 10px 14px !important;}
.menu-title,
.sidebar-title,
.odisha-style-menu-label{
    margin:16px 10px 8px !important;
    padding:0 2px !important;
    color:rgba(183,202,234,.70) !important;
    font-size:10px !important;
    font-weight:800 !important;
    letter-spacing:.13em !important;
    text-transform:uppercase !important;
}
.menu-link,
.odisha-style-nav-link,
.admin-sidebar a{
    position:relative !important;
    min-height:46px !important;
    margin:0 4px 7px !important;
    padding:8px 13px 8px 12px !important;
    border:1px solid transparent !important;
    border-radius:13px !important;
    display:flex !important;
    align-items:center !important;
    gap:11px !important;
    background:transparent !important;
    color:rgba(226,236,255,.76) !important;
    font-size:13px !important;
    font-weight:700 !important;
    line-height:1.15 !important;
    transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease,box-shadow .16s ease !important;
}
.menu-link:hover,
.odisha-style-nav-link:hover,
.admin-sidebar a:hover{
    transform:translateX(2px) !important;
    color:#fff !important;
    border-color:rgba(255,255,255,.08) !important;
    background:rgba(255,255,255,.045) !important;
    box-shadow:0 8px 20px rgba(0,0,0,.14) !important;
}
.menu-link i,
.odisha-style-nav-icon,
.admin-sidebar a i{
    width:30px !important;
    height:30px !important;
    flex:0 0 30px !important;
    display:grid !important;
    place-items:center !important;
    border-radius:10px !important;
    background:rgba(255,255,255,.06) !important;
    color:#cfe0ff !important;
    font-size:12px !important;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04) !important;
}
.menu-link.active,
.odisha-style-nav-link.active,
.admin-sidebar a.active{
    color:#fff !important;
    border-color:rgba(75,138,255,.36) !important;
    background:linear-gradient(135deg,rgba(37,99,235,.95),rgba(80,140,255,.95)) !important;
    box-shadow:0 12px 24px rgba(15,23,42,.26),0 0 0 1px rgba(255,255,255,.03) inset !important;
}
.menu-link.active i,
.odisha-style-nav-link.active .odisha-style-nav-icon,
.admin-sidebar a.active i{
    background:rgba(255,255,255,.18) !important;
    color:#fff !important;
}
.menu-link.active::after,
.odisha-style-nav-link.active::after,
.admin-sidebar a.active::after{
    content:"";
    position:absolute;
    left:-4px;
    top:9px;
    bottom:9px;
    width:4px;
    border-radius:999px;
    background:linear-gradient(180deg,#8dc2ff 0%,#fff 100%);
    box-shadow:0 0 12px rgba(141,194,255,.7);
}
.menu-badge,
.odisha-style-nav-badge{
    min-width:22px !important;
    height:22px !important;
    padding:0 6px !important;
    margin-left:auto !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.10) !important;
    color:#fff !important;
    border:1px solid rgba(255,255,255,.09) !important;
    font-size:10px !important;
    font-weight:800 !important;
}
.menu-link[href*="logout"],
.odisha-style-nav-link[href*="logout"],
.admin-sidebar a[href*="logout"]{
    margin-top:12px !important;
    border-color:rgba(255,107,107,.15) !important;
    background:rgba(255,78,78,.06) !important;
    color:#ffd6d6 !important;
}



/* === EXACT DASHBOARD SIDEBAR — CROSS-ADMIN COMPATIBILITY === */
.menu-badge:empty{display:none!important}
.sidebar .menu-link{box-sizing:border-box!important}
.sidebar .menu-link span:not(.menu-badge){min-width:0}

/* Existing admin layouts with header above sidebar */
.layout > .sidebar{top:0!important}
.layout > .main{min-width:0}

/* CRM uses a different main wrapper */
.odisha-style-main{margin-left:265px!important;min-width:0!important}

/* Detail pages that originally had no navigation sidebar */
body.ts-dashboard-sidebar-added > .topbar{margin-left:265px!important;width:auto!important}
body.ts-dashboard-sidebar-added > .page{margin-left:265px!important;width:auto!important;max-width:none!important}
body.ts-dashboard-sidebar-added > main.page{padding-left:22px!important;padding-right:22px!important}

@media(max-width:850px){
    .odisha-style-main{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .topbar{margin-left:0!important}
    body.ts-dashboard-sidebar-added > .page{margin-left:0!important}
}


/* ============================================================
   DASHBOARD-ALIGNED ADMIN WORKSPACE
   Layout spacing only: remove duplicate sidebar gap and keep
   content immediately beside the fixed 265px dashboard sidebar.
============================================================ */
:root{--ts-admin-sidebar-width:265px}

.layout{
    display:block!important;
    grid-template-columns:none!important;
    min-height:100vh!important;
}
.main{
    margin-left:var(--ts-admin-sidebar-width)!important;
    width:auto!important;
    max-width:none!important;
    min-width:0!important;
    padding:16px 18px 20px!important;
}

@media(max-width:850px){
    .main,.page,.admin-main{
        margin-left:0!important;
    }
    .main{padding:14px 12px 18px!important;}
    .page{padding:14px 12px 18px!important;}
    .main > .content,.main .content:first-child{padding:14px 12px 18px!important;}
}



/* ============================================================
   TRAVSCOPE FINAL ADMIN LAYOUT STANDARD
   Dashboard-aligned, edge-to-edge workspace, no page-sideways
   overflow, responsive on desktop/tablet/mobile.
   VISUAL/LAYOUT ONLY — business logic untouched.
============================================================ */

html,
body{
    width:100% !important;
    max-width:100% !important;
    overflow-x:hidden !important;
}

/* Fixed dashboard-standard sidebar */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    width:265px !important;
    min-width:265px !important;
    max-width:265px !important;
    position:fixed !important;
    left:0 !important;
    top:0 !important;
    bottom:0 !important;
    z-index:1100 !important;
}

/* Root wrappers must not reserve a second sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    width:100% !important;
    max-width:100% !important;
    min-width:0 !important;
}

/* Common root layout wrappers containing the fixed sidebar */
.layout{
    display:block !important;
}

/* Main workspace: identical horizontal start to dashboard */
.main,
.admin-main,
.odisha-style-main{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Standalone page/content roots used by CRM/enquiry/detail screens */
body > .page,
body > .content{
    margin-left:265px !important;
    width:calc(100% - 265px) !important;
    max-width:none !important;
    min-width:0 !important;
    box-sizing:border-box !important;
}

/* Nested pages must fill their main workspace, never recentre/narrow */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100% !important;
    max-width:none !important;
    min-width:0 !important;
    margin-left:0 !important;
    margin-right:0 !important;
}

/* Dashboard-like visual breathing room */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:16px !important;
    padding-right:16px !important;
}

.page,
.content,
.card,
.panel,
.profile-manager,
.form-wrap,
.editor-shell,
.settings-content,
.table-wrap,
.content-grid,
.details-grid,
.info-grid,
.summary-grid,
.customer-grid,
.form-grid,
.filters,
.grid{
    min-width:0 !important;
    max-width:100% !important;
    box-sizing:border-box !important;
}

/* Prevent nested width declarations from pushing the entire page sideways */
.card,
.panel,
.form-wrap,
.editor-shell,
.settings-content,
.profile-manager{
    width:auto !important;
}

/* Tables scroll inside their own card only — never the whole admin page */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100% !important;
    max-width:100% !important;
    overflow-x:auto !important;
    overflow-y:hidden;
    -webkit-overflow-scrolling:touch;
}

table,
.booking-table,
.customer-table,
.destination-table,
.pricing-table{
    max-width:none;
}

/* Media stays inside its card */
img,
video,
canvas{
    max-width:100%;
}

/* Common data grids adapt instead of forcing horizontal page scroll */
.stats,
.stats-grid,
.mini-stats,
.overview-grid,
.summary-grid,
.details-grid,
.info-grid,
.content-grid,
finance-grid,
.money-grid,
.action-grid{
    min-width:0 !important;
}

/* Desktop professional spacing */
.page-head,
.page-heading{
    margin-left:0 !important;
    margin-right:0 !important;
}

@media(min-width:851px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-top:16px !important;
        padding-bottom:20px !important;
    }

    /* CRM / enquiry pages that previously used centered 94–97% widths */
    .page{
        width:100% !important;
        max-width:none !important;
    }
}

/* Tablet: sidebar collapses exactly like dashboard */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:265px !important;
        min-width:265px !important;
        max-width:265px !important;
        transform:translateX(-100%);
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
        max-width:100% !important;
        padding-left:12px !important;
        padding-right:12px !important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block !important;
        width:100% !important;
    }

    .page,
    .content{
        width:100% !important;
        max-width:100% !important;
        margin-left:0 !important;
        margin-right:0 !important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr)) !important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr !important;
    }
}

/* Phone */
@media(max-width:600px){
    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:8px !important;
        padding-right:8px !important;
        padding-top:10px !important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr !important;
    }

    .page-head,
    .page-heading{
        gap:8px !important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px !important;
    }

    /* Buttons/forms remain touch-friendly */
    input:not([type="checkbox"]):not([type="radio"]),
    select,
    textarea,
    .control,
    .form-control{
        max-width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE STABLE COMPACT SIDEBAR
   Same exact dimensions/position on every admin page.
   No desktop jump, slide, resize, or layout shift.
============================================================ */

:root{
    --ts-sidebar-width:230px;
    --ts-sidebar-bg:#09162b;
    --ts-sidebar-bg-2:#0d1c35;
    --ts-sidebar-text:#b9c7d9;
    --ts-sidebar-heading:#70839f;
    --ts-sidebar-active:#2f7df4;
}

/* Disable visual shifting on desktop */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar,
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    transition:none !important;
    animation:none !important;
}

/* Exact same compact sidebar everywhere */
.sidebar,
.admin-sidebar,
.odisha-style-sidebar{
    position:fixed !important;
    top:0 !important;
    left:0 !important;
    bottom:0 !important;
    width:var(--ts-sidebar-width) !important;
    min-width:var(--ts-sidebar-width) !important;
    max-width:var(--ts-sidebar-width) !important;
    height:100vh !important;
    background:
        linear-gradient(180deg,var(--ts-sidebar-bg) 0%,var(--ts-sidebar-bg-2) 100%) !important;
    overflow:hidden !important;
    z-index:1100 !important;
    box-shadow:8px 0 24px rgba(8,18,38,.16) !important;
}

/* Compact logo — identical height on every page */
.sidebar-logo{
    height:64px !important;
    min-height:64px !important;
    margin:8px 9px 5px !important;
    padding:0 11px !important;
    gap:9px !important;
    border:1px solid rgba(255,255,255,.065) !important;
    border-radius:12px !important;
    background:rgba(255,255,255,.035) !important;
    font-size:15px !important;
    line-height:1 !important;
    box-shadow:none !important;
}

.sidebar-logo .logo-icon,
.sidebar-logo > .logo-icon{
    width:34px !important;
    height:34px !important;
    flex:0 0 34px !important;
    border-radius:9px !important;
    font-size:12px !important;
    transform:none !important;
}

/* Fit the full menu without the panel moving up/down */
.sidebar-menu{
    height:calc(100vh - 77px) !important;
    padding:3px 8px 8px !important;
    overflow-y:auto !important;
    overflow-x:hidden !important;
    scrollbar-width:none !important;
    overscroll-behavior:contain !important;
}

.sidebar-menu::-webkit-scrollbar{
    width:0 !important;
    height:0 !important;
}

/* Small organized section headings */
.menu-title{
    height:22px !important;
    min-height:22px !important;
    margin:4px 5px 2px !important;
    padding:6px 4px 2px !important;
    display:flex !important;
    align-items:flex-end !important;
    color:var(--ts-sidebar-heading) !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    letter-spacing:1px !important;
    white-space:nowrap !important;
}

/* Compact fixed-height menu buttons */
.menu-link,
.sidebar .menu-link{
    position:relative !important;
    width:100% !important;
    height:36px !important;
    min-height:36px !important;
    max-height:36px !important;
    margin:0 0 2px !important;
    padding:0 9px !important;
    display:flex !important;
    align-items:center !important;
    gap:8px !important;
    border:1px solid transparent !important;
    border-radius:9px !important;
    background:transparent !important;
    color:var(--ts-sidebar-text) !important;
    font-size:11px !important;
    font-weight:700 !important;
    line-height:1 !important;
    white-space:nowrap !important;
    transform:none !important;
    box-shadow:none !important;
    transition:none !important;
}

/* Same icon box size everywhere */
.menu-link i,
.sidebar .menu-link i{
    width:24px !important;
    height:24px !important;
    min-width:24px !important;
    flex:0 0 24px !important;
    margin:0 !important;
    display:grid !important;
    place-items:center !important;
    border-radius:7px !important;
    background:rgba(255,255,255,.055) !important;
    color:#a9c9f8 !important;
    font-size:10px !important;
    line-height:1 !important;
}

/* Hover does not move the button */
.menu-link:hover,
.sidebar .menu-link:hover{
    transform:none !important;
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(255,255,255,.055) !important;
    color:#fff !important;
    box-shadow:none !important;
}

/* Current page: only color changes, dimensions remain identical */
.menu-link.active,
.sidebar .menu-link.active{
    height:36px !important;
    min-height:36px !important;
    padding:0 9px !important;
    transform:none !important;
    background:linear-gradient(135deg,#256ee9,#3d8af7) !important;
    border-color:rgba(104,164,255,.42) !important;
    color:#fff !important;
    box-shadow:0 4px 12px rgba(23,92,210,.18) !important;
}

.menu-link.active i,
.sidebar .menu-link.active i{
    background:rgba(255,255,255,.16) !important;
    color:#fff !important;
}

/* Remove active side stripe that can visually shift */
.menu-link.active::after{
    display:none !important;
}

.menu-link::before{
    display:none !important;
}

/* Fixed small counters */
.menu-badge{
    margin-left:auto !important;
    min-width:18px !important;
    width:auto !important;
    height:18px !important;
    padding:0 5px !important;
    border-radius:999px !important;
    display:inline-flex !important;
    align-items:center !important;
    justify-content:center !important;
    background:rgba(255,255,255,.12) !important;
    border:0 !important;
    color:#fff !important;
    font-size:8px !important;
    font-weight:800 !important;
    line-height:1 !important;
    box-shadow:none !important;
}

/* Do not treat logout as a different-size button */
.menu-link[href*="logout"]{
    margin-top:2px !important;
    height:36px !important;
    min-height:36px !important;
}

/* Every desktop page begins at the exact same X coordinate */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

body > .page,
body > .content{
    margin-left:var(--ts-sidebar-width) !important;
    width:calc(100% - var(--ts-sidebar-width)) !important;
    max-width:none !important;
}

/* Do not let nested pages add their own left gap */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0 !important;
    width:100% !important;
    max-width:none !important;
}

/* Mobile retains slide drawer; desktop remains completely fixed */
@media(max-width:850px){
    .sidebar,
    .admin-sidebar,
    .odisha-style-sidebar{
        width:230px !important;
        min-width:230px !important;
        max-width:230px !important;
        overflow-y:auto !important;
        transform:translateX(-100%) !important;
        transition:transform .18s ease !important;
    }

    .sidebar.open,
    .admin-sidebar.open,
    .odisha-style-sidebar.open{
        transform:translateX(0) !important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0 !important;
        width:100% !important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT ADMIN LEFT PANEL
   IDENTICAL ON EVERY ADMIN PHP.
   Only active menu item and page content change.
============================================================ */

:root{
    --ts-fixed-sidebar:230px;
    --ts-side-bg:#09162b;
    --ts-side-bg2:#0d1c35;
    --ts-side-text:#bdc9d9;
    --ts-side-muted:#71839e;
    --ts-side-blue:#2f7df4;
}

/* Lock sidebar dimensions before page content paints */
html{overflow-x:hidden!important}
body{overflow-x:hidden!important}

.sidebar{
    position:fixed!important;
    inset:0 auto 0 0!important;
    width:var(--ts-fixed-sidebar)!important;
    min-width:var(--ts-fixed-sidebar)!important;
    max-width:var(--ts-fixed-sidebar)!important;
    height:100vh!important;
    z-index:1100!important;

    display:flex!important;
    flex-direction:column!important;

    background:
        radial-gradient(circle at 15% 0%,rgba(55,126,255,.14),transparent 23%),
        linear-gradient(180deg,var(--ts-side-bg),var(--ts-side-bg2))!important;

    color:#fff!important;
    border-right:1px solid rgba(255,255,255,.055)!important;
    box-shadow:8px 0 24px rgba(7,18,39,.15)!important;

    overflow:hidden!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

/* Brand block */
.sidebar-logo{
    flex:0 0 62px!important;
    height:62px!important;
    min-height:62px!important;

    margin:8px 9px 5px!important;
    padding:0 11px!important;

    display:flex!important;
    align-items:center!important;
    gap:9px!important;

    border:1px solid rgba(255,255,255,.07)!important;
    border-radius:12px!important;
    background:rgba(255,255,255,.035)!important;

    color:#fff!important;
    font-family:'Manrope','DM Sans',Arial,sans-serif!important;
    font-size:14px!important;
    font-weight:800!important;
    letter-spacing:0!important;
    line-height:1!important;

    box-shadow:none!important;
    transition:none!important;
}

.sidebar-logo .logo-icon{
    width:34px!important;
    height:34px!important;
    min-width:34px!important;
    flex:0 0 34px!important;

    display:grid!important;
    place-items:center!important;

    border-radius:9px!important;
    background:linear-gradient(135deg,#1688ff,#27b7e9)!important;
    color:#fff!important;
    font-size:12px!important;

    transform:none!important;
    box-shadow:0 5px 12px rgba(22,136,255,.18)!important;
}

.sidebar-logo span{
    color:#6db7ff!important;
}

/* Menu body */
.sidebar-menu{
    flex:1 1 auto!important;
    min-height:0!important;

    padding:2px 8px 8px!important;

    overflow-y:auto!important;
    overflow-x:hidden!important;

    scrollbar-width:none!important;
    overscroll-behavior:contain!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

/* Section labels */
.menu-title{
    height:21px!important;
    min-height:21px!important;
    margin:4px 5px 2px!important;
    padding:5px 4px 2px!important;

    display:flex!important;
    align-items:flex-end!important;

    color:var(--ts-side-muted)!important;
    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;
    letter-spacing:1px!important;
    text-transform:uppercase!important;

    white-space:nowrap!important;
}

/* Every button uses EXACT same geometry */
.menu-link{
    position:relative!important;

    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    display:flex!important;
    align-items:center!important;
    gap:8px!important;

    border:1px solid transparent!important;
    border-radius:9px!important;

    background:transparent!important;
    color:var(--ts-side-text)!important;

    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;

    white-space:nowrap!important;

    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
}

.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;

    margin:0!important;

    display:grid!important;
    place-items:center!important;

    border-radius:7px!important;
    background:rgba(255,255,255,.055)!important;
    color:#a8c8f6!important;

    font-size:10px!important;
    line-height:1!important;

    transition:none!important;
}

/* Hover only changes colour — never size/position */
.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;

    transform:none!important;
    box-shadow:none!important;
}
.menu-link:hover i{
    background:rgba(255,255,255,.085)!important;
    color:#fff!important;
}

/* Active state keeps EXACT same geometry */
.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;

    margin:0 0 2px!important;
    padding:0 9px!important;

    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;

    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}

.menu-link::before,
.menu-link::after{
    display:none!important;
}

/* Constant compact badges */
.menu-badge{
    margin-left:auto!important;
    min-width:18px!important;
    height:18px!important;
    padding:0 5px!important;

    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;

    border:0!important;
    border-radius:999px!important;

    background:rgba(255,255,255,.12)!important;
    color:#fff!important;

    font-size:8px!important;
    font-weight:800!important;
    line-height:1!important;

    box-shadow:none!important;
}

/* Main content always begins immediately after same sidebar */
.main,
.admin-main,
.odisha-style-main{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:var(--ts-fixed-sidebar)!important;
    width:calc(100% - var(--ts-fixed-sidebar))!important;
    max-width:none!important;
    min-width:0!important;
}

/* No second sidebar gap from old grid layouts */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
}

.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    margin-left:0!important;
    margin-right:0!important;
    width:100%!important;
    max-width:none!important;
}

/* Mobile drawer only */
@media(max-width:850px){
    .sidebar{
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
    }

    .sidebar.open{
        transform:translateX(0)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }
}



/* ============================================================
   TRAVSCOPE CONSTANT SIDEBAR BEHAVIOUR
   Desktop: panel never moves.
   Mobile/tablet: one universal 3-line hamburger drawer.
============================================================ */

/* Universal mobile hamburger stays hidden on desktop */
.ts-mobile-sidebar-toggle{
    display:none;
    position:fixed;
    top:12px;
    left:12px;
    z-index:1305;

    width:40px;
    height:40px;
    padding:0;

    border:1px solid #d9e3ee;
    border-radius:10px;

    background:#ffffff;
    color:#12233b;

    align-items:center;
    justify-content:center;

    box-shadow:0 5px 16px rgba(15,23,42,.12);
    cursor:pointer;
}

.ts-mobile-sidebar-toggle .ts-bars{
    width:18px;
    height:14px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.ts-mobile-sidebar-toggle .ts-bars span{
    display:block;
    width:100%;
    height:2px;
    border-radius:999px;
    background:currentColor;
    transition:transform .18s ease, opacity .18s ease;
}

.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(1){
    transform:translateY(6px) rotate(45deg);
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(2){
    opacity:0;
}
.ts-mobile-sidebar-toggle.open .ts-bars span:nth-child(3){
    transform:translateY(-6px) rotate(-45deg);
}

/* One universal overlay */
.ts-sidebar-overlay{
    display:none;
    position:fixed;
    inset:0;
    z-index:1090;
    background:rgba(4,12,25,.48);
    backdrop-filter:blur(2px);
}

/* Desktop must remain absolutely constant */
@media(min-width:851px){
    .sidebar{
        transform:none!important;
        visibility:visible!important;
    }

    .ts-sidebar-overlay,
    .ts-mobile-sidebar-toggle{
        display:none!important;
    }
}

/* Mobile/tablet drawer */
@media(max-width:850px){
    .ts-mobile-sidebar-toggle{
        display:flex!important;
    }

    .sidebar{
        transform:translateX(-100%)!important;
        visibility:visible!important;
        transition:transform .18s ease!important;
        box-shadow:12px 0 32px rgba(5,14,31,.24)!important;
    }

    .sidebar.ts-sidebar-open,
    .sidebar.open{
        transform:translateX(0)!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
    }

    body.ts-sidebar-lock{
        overflow:hidden!important;
    }

    /* Give top area room for hamburger without changing content width */
    .topbar,
    .header,
    .admin-header{
        padding-left:60px!important;
    }
}

/* Small phones */
@media(max-width:520px){
    .ts-mobile-sidebar-toggle{
        top:9px;
        left:9px;
        width:38px;
        height:38px;
    }

    .topbar,
    .header,
    .admin-header{
        padding-left:55px!important;
    }
}



/* ============================================================
   TRAVSCOPE FINAL CONSTANT PANEL + DASHBOARD PAGE ALIGNMENT
   Same left panel on every page. Only right page content changes.
============================================================ */

/* ---------- 1. ONE EXACT MENU BUTTON DESIGN EVERYWHERE ---------- */
.sidebar .menu-link,
.sidebar a.menu-link{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    gap:8px!important;
    border:1px solid transparent!important;
    border-radius:9px!important;
    background:transparent!important;
    color:#bdc9d9!important;
    font-size:11px!important;
    font-weight:700!important;
    line-height:1!important;
    box-shadow:none!important;
    transform:none!important;
    transition:none!important;
}

/* Every inactive icon uses the same neutral panel style.
   Removes old yellow/green/purple differences on individual pages. */
.sidebar .menu-link i,
.sidebar a.menu-link i{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    flex:0 0 23px!important;
    margin:0!important;
    display:grid!important;
    place-items:center!important;
    border-radius:7px!important;
    background:rgba(255,255,255,.06)!important;
    color:#abc9f3!important;
    font-size:10px!important;
    box-shadow:none!important;
}

.sidebar .menu-link:hover,
.sidebar a.menu-link:hover{
    background:rgba(255,255,255,.055)!important;
    border-color:rgba(255,255,255,.055)!important;
    color:#fff!important;
    transform:none!important;
}

.sidebar .menu-link.active,
.sidebar a.menu-link.active{
    width:100%!important;
    height:35px!important;
    min-height:35px!important;
    max-height:35px!important;
    margin:0 0 2px!important;
    padding:0 9px!important;
    background:linear-gradient(135deg,#246fe9,#3b88f6)!important;
    border-color:rgba(105,166,255,.35)!important;
    color:#fff!important;
    box-shadow:0 4px 11px rgba(35,111,233,.16)!important;
    transform:none!important;
}
.sidebar .menu-link.active i,
.sidebar a.menu-link.active i{
    background:rgba(255,255,255,.16)!important;
    color:#fff!important;
}
.sidebar .menu-link::before,
.sidebar .menu-link::after{
    display:none!important;
}

/* ---------- 2. DIRECT PAGE HEADERS MUST START AFTER SIDEBAR ---------- */
/* Some old admin pages use a body-level .header while Dashboard uses
   a topbar inside .main. Only body-level headers receive the offset. */
body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    box-sizing:border-box!important;
    left:auto!important;
    right:0!important;
}

/* Headers already inside .main must NOT receive a second offset */
.main > .header,
.main > .topbar,
.main > .admin-header,
.admin-main > .header,
.admin-main > .topbar,
.odisha-style-main > .header,
.odisha-style-main > .topbar{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

/* ---------- 3. ONE EXACT RIGHT-SIDE WORKSPACE GEOMETRY ---------- */
.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Pages that put .page/.content directly under body */
body > .page,
body > .content{
    margin-left:230px!important;
    margin-right:0!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
    box-sizing:border-box!important;
}

/* Old two-column shells must never reserve another sidebar column */
.layout,
.admin-shell,
.odisha-style-admin-layout{
    display:block!important;
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin:0!important;
}

/* Nested page wrappers fill the right workspace exactly */
.main > .page,
.main .page,
.admin-main > .page,
.admin-main .page,
.odisha-style-main > .page,
.odisha-style-main .page,
.main > .content,
.admin-main > .content,
.odisha-style-main > .content{
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    margin-left:0!important;
    margin-right:0!important;
    box-sizing:border-box!important;
}

/* Standard dashboard-like internal spacing */
.main,
.admin-main,
.odisha-style-main,
body > .page,
body > .content{
    padding-left:14px!important;
    padding-right:14px!important;
}

.page,
.content{
    min-width:0!important;
    box-sizing:border-box!important;
}

/* ---------- 4. NO WHOLE-PAGE SIDEWAYS SCROLL ---------- */
html,
body{
    width:100%!important;
    max-width:100%!important;
    overflow-x:hidden!important;
}

.card,
.panel,
.form-wrap,
.profile-manager,
.editor-shell,
.settings-content,
.page,
.content,
.page-head,
.page-heading,
.stats,
.stats-grid,
.mini-stats,
.filters,
.form-grid,
.info-grid,
.details-grid,
.content-grid,
.summary-grid{
    min-width:0!important;
    max-width:100%!important;
    box-sizing:border-box!important;
}

/* Wide data stays scrollable inside its own card only */
.table-wrap,
.pricing-table-wrap,
.season-price-table-wrap{
    width:100%!important;
    max-width:100%!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    -webkit-overflow-scrolling:touch;
}

/* ---------- 5. RESPONSIVE: SAME HAMBURGER / DRAWER ON ALL PAGES ---------- */
@media(max-width:850px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:58px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
        padding-left:10px!important;
        padding-right:10px!important;
    }

    .layout,
    .admin-shell,
    .odisha-style-admin-layout{
        display:block!important;
        width:100%!important;
    }

    .stats,
    .stats-grid,
    .mini-stats{
        grid-template-columns:repeat(2,minmax(0,1fr))!important;
    }

    .filters,
    .form-grid,
    .details-grid,
    .info-grid,
    .summary-grid,
    .content-grid{
        grid-template-columns:1fr!important;
    }
}

@media(max-width:560px){
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:54px!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content{
        padding-left:7px!important;
        padding-right:7px!important;
    }

    .stats,
    .stats-grid,
    .mini-stats,
    .overview-grid{
        grid-template-columns:1fr!important;
    }

    .page-head,
    .page-heading{
        gap:7px!important;
    }

    .page-head h1,
    .page-heading h1{
        font-size:22px!important;
    }
}



/* ============================================================
   TRAVSCOPE SINGLE CLEAN PANEL
   Exactly one desktop sidebar and one mobile hamburger.
============================================================ */

.sidebar-brand-text{
    display:flex;
    flex-direction:column;
    gap:2px;
    min-width:0;
}
.sidebar-brand-text strong{
    color:#fff;
    font-size:13px;
    line-height:1;
    font-weight:800;
}
.sidebar-brand-text small{
    color:#8fa8c7;
    font-size:8px;
    line-height:1.1;
    font-weight:700;
    white-space:nowrap;
}

.sidebar{
    width:230px!important;
    min-width:230px!important;
    max-width:230px!important;
    position:fixed!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    z-index:1100!important;
    overflow:hidden!important;
}

.sidebar-menu{
    overflow-y:auto!important;
    overflow-x:hidden!important;
    scrollbar-width:none!important;
}
.sidebar-menu::-webkit-scrollbar{display:none!important}

.main,
.admin-main,
.odisha-style-main{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
    min-width:0!important;
}

body > .page,
body > .content{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

body > .header,
body > header.header,
body > .topbar,
body > header.topbar,
body > .admin-header,
body > header.admin-header{
    margin-left:230px!important;
    width:calc(100% - 230px)!important;
    max-width:calc(100% - 230px)!important;
}

.main > .topbar,
.main > .header,
.admin-main > .topbar,
.admin-main > .header,
.odisha-style-main > .topbar,
.odisha-style-main > .header{
    margin-left:0!important;
    width:100%!important;
    max-width:100%!important;
}

.ts-mobile-sidebar-toggle{
    display:none!important;
}

.ts-sidebar-overlay{
    display:none!important;
}

@media(max-width:850px){
    .sidebar{
        transform:translateX(-100%)!important;
        transition:transform .18s ease!important;
        width:230px!important;
        min-width:230px!important;
        max-width:230px!important;
    }

    .sidebar.ts-sidebar-open{
        transform:translateX(0)!important;
    }

    .ts-mobile-sidebar-toggle{
        display:flex!important;
        position:fixed!important;
        top:10px!important;
        left:10px!important;
        z-index:1305!important;
        width:40px!important;
        height:40px!important;
        padding:0!important;
        align-items:center!important;
        justify-content:center!important;
        border:1px solid #d9e3ee!important;
        border-radius:10px!important;
        background:#fff!important;
        color:#12233b!important;
        box-shadow:0 5px 16px rgba(15,23,42,.12)!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars{
        width:18px!important;
        height:14px!important;
        display:flex!important;
        flex-direction:column!important;
        justify-content:space-between!important;
    }

    .ts-mobile-sidebar-toggle .ts-bars span{
        display:block!important;
        width:100%!important;
        height:2px!important;
        border-radius:999px!important;
        background:currentColor!important;
    }

    .ts-sidebar-overlay.ts-sidebar-open{
        display:block!important;
        position:fixed!important;
        inset:0!important;
        z-index:1090!important;
        background:rgba(4,12,25,.48)!important;
    }

    .main,
    .admin-main,
    .odisha-style-main,
    body > .page,
    body > .content,
    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        margin-left:0!important;
        width:100%!important;
        max-width:100%!important;
    }

    body > .header,
    body > header.header,
    body > .topbar,
    body > header.topbar,
    body > .admin-header,
    body > header.admin-header{
        padding-left:58px!important;
    }
}


/* V24.71 — International Booking Operations */
.booking-page-head{padding:16px 18px!important;margin-bottom:10px!important;border:1px solid #dce7f2;border-left:4px solid #1683ff;border-radius:14px;background:linear-gradient(115deg,#fff 0%,#f8fbff 58%,#eef7ff 100%);box-shadow:0 8px 24px rgba(16,49,83,.05);align-items:center!important}
.booking-heading-copy{min-width:0;flex:1}.booking-eyebrow{font-size:9px;font-weight:800;letter-spacing:.11em;color:#1683ff;margin-bottom:4px}.booking-page-head h1{font-size:24px!important}.booking-page-head p{font-size:10px!important;max-width:720px}.booking-head-actions{display:flex;align-items:center;gap:8px}.booking-kpis{display:flex;flex-wrap:wrap;gap:6px;margin-top:11px}.bkpi{min-height:34px;padding:5px 9px;border:1px solid #e1e9f2;border-radius:9px;background:#fff;display:inline-grid;grid-template-columns:20px auto;grid-template-rows:auto auto;column-gap:6px;align-items:center;box-shadow:0 4px 12px rgba(17,51,86,.04)}.bkpi i{grid-row:1/3;width:20px;height:20px;border-radius:6px;display:grid;place-items:center;background:#edf5ff;color:#1677e8;font-size:9px}.bkpi b{font:800 12px/1.05 Manrope,sans-serif;color:#0c2947}.bkpi small{font-size:7.5px;line-height:1;color:#7d8a9a;font-weight:700}.bkpi-amber i{background:#fff5df;color:#d3820b}.bkpi-green i{background:#e8f9f1;color:#0c9365}.bkpi-violet i{background:#f2ebff;color:#7d42db}.bkpi-cyan i{background:#e8fafd;color:#078a9c}.booking-filter-card{margin-bottom:0!important;border-radius:12px 12px 0 0!important;box-shadow:none!important}.booking-filter-card .card-head{min-height:46px!important;padding:0 13px!important}.booking-filter-card .card-body{padding:10px 12px 11px!important}.booking-filter-card .card-head h2,.booking-results-card .card-head h2{display:flex;align-items:center;gap:7px;font-size:12px!important}.booking-filter-card .card-head h2 i,.booking-results-card .card-head h2 i{color:#1683ff}.booking-results-card{margin-top:-1px!important;border-radius:0 0 12px 12px!important;box-shadow:0 10px 24px rgba(17,51,86,.05)!important}.booking-results-card .card-head{min-height:44px!important;padding:0 13px!important;background:#fbfdff}.booking-results-card .card-body{padding:0 10px 10px!important}.booking-results-card .booking-table th{background:#edf4fb!important;font-size:7.5px!important;letter-spacing:.02em}.booking-results-card .booking-table td{padding-top:9px!important;padding-bottom:9px!important}.booking-filter-card .filters{grid-template-columns:minmax(230px,1.9fr) repeat(3,minmax(130px,1fr)) repeat(2,minmax(125px,.85fr)) auto!important;gap:6px!important}.booking-filter-card .control,.booking-filter-card .filter-btn{height:36px!important;min-height:36px!important;font-size:8px!important}.booking-filter-card .clear-filter{margin-top:7px!important}.booking-page-head+.alert{margin-top:0}@media(max-width:1120px){.booking-filter-card .filters{grid-template-columns:repeat(3,minmax(0,1fr))!important}.booking-kpis{max-width:760px}}@media(max-width:760px){.booking-page-head{align-items:flex-start!important}.booking-kpis{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));width:100%}.booking-head-actions{width:100%}.booking-head-actions .refresh-btn{width:100%;justify-content:center}.booking-filter-card .filters{grid-template-columns:1fr!important}.bkpi-cyan{grid-column:1/-1}}
</style>


<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head>

<body>

<button type="button"
        class="ts-mobile-sidebar-toggle"
        id="tsMobileSidebarToggle"
        aria-label="Open admin menu"
        aria-controls="sidebar"
        aria-expanded="false">
    <span class="ts-bars" aria-hidden="true">
        <span></span><span></span><span></span>
    </span>
</button>
<div class="ts-sidebar-overlay" id="tsSidebarOverlay" aria-hidden="true"></div>

<!-- =========================================================
     TRAVSCOPE SINGLE CONSTANT ADMIN SIDEBAR
========================================================= -->
<aside class="sidebar" id="sidebar">
    <a href="admin-dashboard.php" class="sidebar-logo">
        <div class="logo-icon"><i class="fa-solid fa-plane"></i></div>
        <div class="sidebar-brand-text">
            <strong>TRAVSCOPE</strong>
            <small>Travel Business System</small>
        </div>
    </a>

    <nav class="sidebar-menu">
        <div class="menu-title">OVERVIEW</div>

        <a href="admin-dashboard.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-dashboard.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i><span>Dashboard</span>
        </a>

        <div class="menu-title">SALES & CRM</div>

        <a href="admin-enquiries.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-enquiries.php','admin-enquiry-details.php','admin-crm.php'], true) ? 'active' : ''; ?>">
            <i class="fa-regular fa-message"></i><span>Enquiries</span>
        </a>

        <a href="admin-customers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-customers.php','admin-users.php','admin-user-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i><span>Customers</span>
        </a>
<div class="menu-title">TRAVEL PRODUCTS</div>

        <a href="admin-destinations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-destinations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-earth-americas"></i><span>Destinations</span>
        </a>

        <a href="admin-packages.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-packages.php','admin-package-images.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-suitcase-rolling"></i><span>Packages</span>
        </a>


        <div class="menu-title">SUPPLIERS</div>

        <a href="admin-suppliers.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-suppliers.php','admin-supplier-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-handshake"></i><span>Suppliers</span>
        </a>

        <div class="menu-title">OPERATIONS</div>

        <a href="admin-bookings.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-bookings.php','admin-booking-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-calendar-check"></i><span>Bookings</span>
        </a>

        <a href="admin-cancellations.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-cancellations.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ban"></i><span>Cancellations</span>
        </a>

        <div class="menu-title">FINANCE</div>

        <a href="admin-payments.php"
           class="menu-link <?= in_array(basename($_SERVER['PHP_SELF']), ['admin-payments.php','admin-payment-details.php'], true) ? 'active' : ''; ?>">
            <i class="fa-solid fa-credit-card"></i><span>Payments</span>
        </a>

        <div class="menu-title">MARKETING</div>

        <a href="admin-coupons.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-coupons.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-ticket"></i><span>Coupons</span>
        </a>

        <a href="admin-reviews.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-reviews.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-star"></i><span>Reviews</span>
        </a>

        <div class="menu-title">CONTENT</div>

        <a href="admin-blogs.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-blogs.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-nib"></i><span>Travel Stories</span>
        </a>

        <a href="admin-web-gallery.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-web-gallery.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-images"></i><span>Media Library</span>
        </a>

        <div class="menu-title">WEBSITE</div>

        <a href="admin-pages.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-pages.php' ? 'active' : ''; ?>">
            <i class="fa-regular fa-file-lines"></i><span>Website Content</span>
        </a>

        <a href="<?= defined('BASE_URL') ? e(BASE_URL) : '/'; ?>" target="_blank" class="menu-link">
            <i class="fa-solid fa-globe"></i><span>View Website</span>
        </a>

        <div class="menu-title">ADMINISTRATION</div>

        <a href="admin-settings.php"
           class="menu-link <?= basename($_SERVER['PHP_SELF']) === 'admin-settings.php' ? 'active' : ''; ?>">
            <i class="fa-solid fa-gear"></i><span>Settings</span>
        </a>

        <a href="logout.php" class="menu-link">
            <i class="fa-solid fa-arrow-right-from-bracket"></i><span>Logout</span>
        </a>
    </nav>
</aside>



<!-- UNIVERSAL MOBILE SIDEBAR CONTROLS -->






<!-- HEADER -->

<header class="header">

<a
    href="<?= e(BASE_URL . 'admin-dashboard.php'); ?>"
    class="logo"
>

<div class="logo-icon">
    <i class="fa-solid fa-plane"></i>
</div>

TRAV<span>SCOPE</span> ADMIN

</a>


<div class="admin">

<div class="avatar">

<?= e(
    strtoupper(
        mb_substr(
            $admin['name'],
            0,
            1
        )
    )
); ?>

</div>


<div>

<strong>
    <?= e($admin['name']); ?>
</strong>

<small>

<?= e(
    ucfirst(
        str_replace(
            '_',
            ' ',
            $admin['role']
        )
    )
); ?>

</small>

</div>

</div>

</header>


<div class="layout">

<!-- SIDEBAR -->

<!-- =========================================================
     CONSTANT TRAVSCOPE ADMIN SIDEBAR
========================================================= -->




<!-- MAIN -->

<main class="main">


<div class="page-head booking-page-head">
<div class="booking-heading-copy">
<div class="booking-eyebrow">OPERATIONS / BOOKING CONTROL</div>
<h1>Booking Management</h1>
<p>Track customers, travel dates, accommodation, payments and booking progress from one operational directory.</p>
<div class="booking-kpis" aria-label="Booking summary">
    <span class="bkpi bkpi-blue"><i class="fa-solid fa-receipt"></i><b><?= number_format($stats['total']); ?></b><small>Total</small></span>
    <span class="bkpi bkpi-amber"><i class="fa-regular fa-clock"></i><b><?= number_format($stats['pending']); ?></b><small>Pending</small></span>
    <span class="bkpi bkpi-green"><i class="fa-solid fa-circle-check"></i><b><?= number_format($stats['confirmed']); ?></b><small>Confirmed</small></span>
    <span class="bkpi bkpi-violet"><i class="fa-solid fa-flag-checkered"></i><b><?= number_format($stats['completed']); ?></b><small>Completed</small></span>
    <span class="bkpi bkpi-cyan"><i class="fa-solid fa-indian-rupee-sign"></i><b>₹<?= number_format($stats['revenue'], 0); ?></b><small>Received</small></span>
</div>
</div>
<div class="booking-head-actions">
<a href="<?= e(BASE_URL . 'admin-bookings.php'); ?>" class="refresh-btn"><i class="fa-solid fa-rotate"></i> Refresh</a>
</div>
</div>


<?php if ($success !== ''): ?>

<div class="alert alert-success">

<i class="fa-solid fa-circle-check"></i>

<?= e($success); ?>

</div>

<?php endif; ?>


<?php if ($error !== ''): ?>

<div class="alert alert-error">

<i class="fa-solid fa-circle-exclamation"></i>

<?= e($error); ?>

</div>

<?php endif; ?>


<!-- FILTER -->

<section class="card booking-filter-card">

<div class="card-head">

<div>

<h2><i class="fa-solid fa-magnifying-glass"></i> Booking Directory</h2>

<p>
    Search by booking number, customer, mobile, email or package.
</p>

</div>

</div>


<div class="card-body">

<form
    method="get"
    class="filters"
>


<input
    type="text"
    name="q"
    class="control"
    placeholder="Booking no., customer, mobile..."
    value="<?= e($search); ?>"
>


<select
    name="booking_status"
    class="control"
>

<option value="">
    All Booking Status
</option>

<?php foreach ($allowedBookingStatuses as $status): ?>

<option
    value="<?= e($status); ?>"
    <?= $bookingStatus === $status
        ? 'selected'
        : ''; ?>
>
    <?= e(ucfirst($status)); ?>
</option>

<?php endforeach; ?>

</select>


<select
    name="payment_status"
    class="control"
>

<option value="">
    All Payment Status
</option>

<?php foreach ($allowedPaymentStatuses as $status): ?>

<option
    value="<?= e($status); ?>"
    <?= $paymentStatus === $status
        ? 'selected'
        : ''; ?>
>
    <?= e(ucfirst($status)); ?>
</option>

<?php endforeach; ?>

</select>


<select
    name="hotel_category"
    class="control"
>

<option value="">
    All Hotel Categories
</option>

<option
    value="3_star"
    <?= $hotelCategory === '3_star'
        ? 'selected'
        : ''; ?>
>
    3 Star Hotel
</option>

<option
    value="4_star"
    <?= $hotelCategory === '4_star'
        ? 'selected'
        : ''; ?>
>
    4 Star Hotel
</option>

<option
    value="5_star"
    <?= $hotelCategory === '5_star'
        ? 'selected'
        : ''; ?>
>
    5 Star Hotel
</option>

</select>


<input
    type="date"
    name="date_from"
    class="control"
    value="<?= e($dateFrom); ?>"
    title="Travel date from"
>


<input
    type="date"
    name="date_to"
    class="control"
    value="<?= e($dateTo); ?>"
    title="Travel date to"
>


<button
    type="submit"
    class="filter-btn"
>
    <i class="fa-solid fa-magnifying-glass"></i>
    Filter
</button>


</form>


<?php if (
    $search !== '' ||
    $bookingStatus !== '' ||
    $paymentStatus !== '' ||
    $hotelCategory !== '' ||
    $dateFrom !== '' ||
    $dateTo !== ''
): ?>

<a
    href="<?= e(BASE_URL . 'admin-bookings.php'); ?>"
    class="clear-filter"
>
    <i class="fa-solid fa-xmark"></i>
    Clear all filters
</a>

<?php endif; ?>


</div>

</section>


<!-- BOOKINGS -->

<section class="card booking-results-card">

<div class="card-head">

<div>

<h2><i class="fa-solid fa-list-check"></i> Booking Records</h2>

<p>

<?= number_format($totalRows); ?>

booking<?= $totalRows === 1 ? '' : 's'; ?>

found.

</p>

</div>

</div>


<div class="card-body">


<?php if ($bookings): ?>

<div class="table-wrap">

<table class="booking-table">

<thead>
<tr>
    <th>Booking</th>
    <th>Customer</th>
    <th>Package</th>
    <th>Hotel</th>
    <th>Travel</th>
    <th>Travellers</th>
    <th>Amount</th>
    <th>Booking Status</th>
    <th>Payment</th>
    <th>Booked On</th>
    <th>Action</th>
</tr>
</thead>

<tbody>

<?php foreach ($bookings as $booking): ?>

<?php
$balance = max(
    0,
    (float)$booking['total_amount'] -
    (float)$booking['paid_amount']
);

$hotelCategoryLabel =
    adminBookingHotelCategoryLabel(
        $booking['hotel_category']
        ?? ''
    );

$hotelPricePerAdult =
    max(
        0,
        (float)(
            $booking['hotel_price']
            ?? 0
        )
    );

$adultCount =
    max(
        1,
        (int)(
            $booking['adults']
            ?? 1
        )
    );

$adultPackageSubtotal =
    round(
        $hotelPricePerAdult
        * $adultCount,
        2
    );
?>

<tr>

<td>
    <div class="booking-no">
        #<?= e($booking['booking_number']); ?>
    </div>
    <div class="subtext">
        ID <?= (int)$booking['id']; ?>
    </div>
</td>

<td class="customer-cell">
    <strong><?= e($booking['customer_name']); ?></strong>
    <div class="subtext"><?= e($booking['customer_mobile']); ?></div>
    <div class="subtext" title="<?= e($booking['customer_email']); ?>">
        <?= e($booking['customer_email']); ?>
    </div>
</td>

<td class="package-cell">
    <strong>
        <?= e($booking['package_title'] ?: 'Package unavailable'); ?>
    </strong>
    <div class="subtext">
        <?php if (!empty($booking['duration_days'])): ?>
            <?= (int)$booking['duration_days']; ?>D
            <?php if ((int)($booking['duration_nights'] ?? 0) > 0): ?>
                / <?= (int)$booking['duration_nights']; ?>N
            <?php endif; ?>
        <?php else: ?>
            Duration not set
        <?php endif; ?>
    </div>
</td>

<td>
    <div class="booking-no" style="font-family:'DM Sans',sans-serif;">
        <?= e($hotelCategoryLabel); ?>
    </div>

    <div class="subtext">
        <?php if ($hotelPricePerAdult > 0): ?>
            <?= e(bookingMoney(
                $hotelPricePerAdult,
                $booking['currency']
            )); ?>
            / adult
        <?php else: ?>
            Price not stored
        <?php endif; ?>
    </div>
</td>

<td>
    <div class="booking-no" style="font-family:'DM Sans',sans-serif;">
        <?= e(safeDate($booking['travel_date'])); ?>
    </div>
</td>

<td>
    <?= (int)$booking['adults']; ?> Adult<?= (int)$booking['adults'] === 1 ? '' : 's'; ?>
    <?php if ((int)$booking['children'] > 0): ?>
        <div class="subtext">
            <?= (int)$booking['children']; ?> Child<?= (int)$booking['children'] === 1 ? '' : 'ren'; ?>
        </div>
    <?php endif; ?>
</td>

<td>
    <div class="money-main">
        <?= e(bookingMoney(
            $booking['total_amount'],
            $booking['currency']
        )); ?>
    </div>

    <div class="subtext">
        <?= $adultCount; ?>
        Adult<?= $adultCount === 1 ? '' : 's'; ?>
        ×
        <?= e(bookingMoney(
            $hotelPricePerAdult,
            $booking['currency']
        )); ?>
    </div>

    <div class="subtext">
        Adult package:
        <?= e(bookingMoney(
            $adultPackageSubtotal,
            $booking['currency']
        )); ?>
    </div>

    <div class="subtext">
        Paid
        <?= e(bookingMoney(
            $booking['paid_amount'],
            $booking['currency']
        )); ?>
    </div>

    <?php if ($balance > 0): ?>
        <div class="money-balance">
            Due
            <?= e(bookingMoney(
                $balance,
                $booking['currency']
            )); ?>
        </div>
    <?php endif; ?>
</td>

<td>
    <span class="badge badge-<?= e(bookingStatusClass($booking['booking_status'])); ?>">
        <?= e(ucfirst($booking['booking_status'])); ?>
    </span>
</td>

<td>
    <span class="badge badge-<?= e(paymentStatusClass($booking['payment_status'])); ?>">
        <i class="fa-solid fa-wallet"></i>
        <?= e(ucfirst($booking['payment_status'])); ?>
    </span>
    <?php if (!empty($booking['latest_transaction_id'])): ?>
        <div class="subtext" title="<?= e($booking['latest_transaction_id']); ?>">
            TXN: <?= e($booking['latest_transaction_id']); ?>
        </div>
    <?php endif; ?>
</td>

<td>
    <?= e(safeDate($booking['created_at'], 'd M Y')); ?>
    <div class="subtext">
        <?= e(safeDate($booking['created_at'], 'h:i A')); ?>
    </div>
</td>

<td>
<div class="table-actions">

<a
    href="<?= e(BASE_URL . 'admin-booking-details.php?id=' . (int)$booking['id']); ?>"
    class="btn btn-details"
>
    <i class="fa-regular fa-eye"></i> Details
</a>

<?php if ($booking['booking_status'] === 'pending'): ?>

<form method="post" onsubmit="return confirm('Confirm this booking?');">
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
    <input type="hidden" name="action" value="change_booking_status">
    <input type="hidden" name="booking_id" value="<?= (int)$booking['id']; ?>">
    <input type="hidden" name="new_status" value="confirmed">
    <button type="submit" class="btn btn-confirm">
        <i class="fa-solid fa-check"></i> Confirm
    </button>
</form>

<form method="post" onsubmit="return confirm('Cancel this booking?');">
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
    <input type="hidden" name="action" value="change_booking_status">
    <input type="hidden" name="booking_id" value="<?= (int)$booking['id']; ?>">
    <input type="hidden" name="new_status" value="cancelled">
    <button type="submit" class="btn btn-cancel">
        <i class="fa-solid fa-xmark"></i> Cancel
    </button>
</form>

<?php elseif ($booking['booking_status'] === 'confirmed'): ?>

<form method="post" onsubmit="return confirm('Mark this trip as completed?');">
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
    <input type="hidden" name="action" value="change_booking_status">
    <input type="hidden" name="booking_id" value="<?= (int)$booking['id']; ?>">
    <input type="hidden" name="new_status" value="completed">
    <button type="submit" class="btn btn-complete">
        <i class="fa-solid fa-flag-checkered"></i> Complete
    </button>
</form>

<form method="post" onsubmit="return confirm('Cancel this confirmed booking?');">
    <input type="hidden" name="csrf_token" value="<?= e($csrfToken); ?>">
    <input type="hidden" name="action" value="change_booking_status">
    <input type="hidden" name="booking_id" value="<?= (int)$booking['id']; ?>">
    <input type="hidden" name="new_status" value="cancelled">
    <button type="submit" class="btn btn-cancel">
        <i class="fa-solid fa-ban"></i> Cancel
    </button>
</form>

<?php endif; ?>

<?php if ($booking['booking_status'] === 'cancelled'): ?>
    <a href="<?= e(BASE_URL . 'admin-cancellations.php?search=' . urlencode((string)$booking['booking_number'])); ?>" class="btn btn-details" title="Complete cancellation / refund assessment"><i class="fa-solid fa-scale-balanced"></i> Refund Review</a>
<?php endif; ?>

<a
    href="<?= e(BASE_URL . 'admin-payments.php?booking_id=' . (int)$booking['id']); ?>"
    class="btn payment-link"
>
    <i class="fa-solid fa-credit-card"></i>
    Payments<?= (int)$booking['payment_count'] > 0 ? ' (' . (int)$booking['payment_count'] . ')' : ''; ?>
</a>

</div>
</td>

</tr>

<?php endforeach; ?>

</tbody>
</table>
</div>

<!-- PAGINATION -->

<?php if ($totalPages > 1): ?>

<div class="pagination">


<?php if ($page > 1): ?>

<a
    href="<?= e(
        bookingPageUrl(
            $page - 1
        )
    ); ?>"
    class="page-btn"
>
    <i class="fa-solid fa-chevron-left"></i>
</a>

<?php endif; ?>


<?php

$startPage =
    max(
        1,
        $page - 2
    );

$endPage =
    min(
        $totalPages,
        $page + 2
    );

?>


<?php for (
    $i = $startPage;
    $i <= $endPage;
    $i++
): ?>

<a
    href="<?= e(
        bookingPageUrl($i)
    ); ?>"
    class="
        page-btn
        <?= $i === $page
            ? 'active'
            : ''; ?>
    "
>
    <?= $i; ?>
</a>

<?php endfor; ?>


<?php if ($page < $totalPages): ?>

<a
    href="<?= e(
        bookingPageUrl(
            $page + 1
        )
    ); ?>"
    class="page-btn"
>
    <i class="fa-solid fa-chevron-right"></i>
</a>

<?php endif; ?>


</div>

<?php endif; ?>


<?php else: ?>


<div class="empty">

<div class="empty-icon">
    <i class="fa-regular fa-calendar-xmark"></i>
</div>

<h3>
    No bookings found
</h3>

<p>
    New customer bookings will appear here automatically.
</p>

</div>


<?php endif; ?>


</div>

</section>


</main>

</div>


<script>

/*
|--------------------------------------------------------------------------
| PREVENT DOUBLE FORM SUBMISSION
|--------------------------------------------------------------------------
*/

document.querySelectorAll(
    'form[method="post"]'
).forEach(function(form){

    form.addEventListener(
        'submit',
        function(){

            const button =
                this.querySelector(
                    'button[type="submit"]'
                );

            if (!button) {
                return;
            }

            setTimeout(
                function(){

                    button.disabled = true;

                    button.style.opacity = '.65';

                    button.style.cursor =
                        'not-allowed';

                },
                20
            );

        }
    );

});

</script>







<script>
(function(){
    const sidebar=document.getElementById('sidebar');
    const toggle=document.getElementById('tsMobileSidebarToggle');
    const overlay=document.getElementById('tsSidebarOverlay');
    if(!sidebar || !toggle || !overlay) return;

    function setOpen(open){
        sidebar.classList.toggle('ts-sidebar-open',open);
        toggle.setAttribute('aria-expanded',open?'true':'false');
        overlay.classList.toggle('ts-sidebar-open',open);
        overlay.setAttribute('aria-hidden',open?'false':'true');
        document.body.classList.toggle('ts-sidebar-lock',open);
    }

    toggle.addEventListener('click',()=>setOpen(!sidebar.classList.contains('ts-sidebar-open')));
    overlay.addEventListener('click',()=>setOpen(false));

    document.addEventListener('keydown',e=>{
        if(e.key==='Escape') setOpen(false);
    });

    sidebar.querySelectorAll('a').forEach(a=>{
        a.addEventListener('click',()=>{
            if(window.innerWidth<=850) setOpen(false);
        });
    });

    window.addEventListener('resize',()=>{
        if(window.innerWidth>850) setOpen(false);
    });
})();
</script>


<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
