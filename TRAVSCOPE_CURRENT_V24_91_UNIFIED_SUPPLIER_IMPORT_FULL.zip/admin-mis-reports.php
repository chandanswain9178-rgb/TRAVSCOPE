<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/mis-functions.php';

requireAdmin();

$admin = currentAdmin($pdo);

if (
    !$admin
    || strtolower((string)($admin['status'] ?? '')) !== 'active'
) {
    unset(
        $_SESSION['admin_id'],
        $_SESSION['admin_name'],
        $_SESSION['admin_email'],
        $_SESSION['admin_role']
    );

    redirect(BASE_URL . 'admin-login.php');
}

$adminId = (int)$admin['id'];

$canViewMargin =
    function_exists('tsAclCan')
        ? tsAclCan($pdo, $adminId, 'view_margin')
        : true;

$canViewSupplierCost =
    function_exists('tsAclCan')
        ? tsAclCan($pdo, $adminId, 'view_supplier_cost')
        : true;

$profile =
    function_exists('tsAclProfile')
        ? tsAclProfile(
            $pdo,
            $adminId,
            (string)($admin['role'] ?? 'admin')
        )
        : (
            strtolower((string)($admin['role'] ?? 'admin')) === 'super_admin'
                ? 'super_admin'
                : 'admin'
        );

$catalog = tsMisCatalog();

$report =
    (string)(
        $_GET['report']
        ?? 'sales'
    );

if (!isset($catalog[$report])) {
    $report = 'sales';
}

if (
    $report === 'profitability'
    && !$canViewMargin
) {
    http_response_code(403);
    exit('Permission denied: View Margin / Profitability.');
}

if (
    $report === 'supplier_payables'
    && !$canViewSupplierCost
) {
    http_response_code(403);
    exit('Permission denied: View Supplier Cost.');
}

[$from, $to] = tsMisRange($_GET);

$data =
    tsMisReport(
        $pdo,
        $report,
        $from,
        $to
    );

$export =
    strtolower(
        trim(
            (string)(
                $_GET['export']
                ?? ''
            )
        )
    );

if (in_array($export, ['csv','xls'], true)) {
    if (
        function_exists('tsAclAudit')
        && function_exists('tsAclReady')
        && tsAclReady($pdo)
    ) {
        tsAclAudit(
            $pdo,
            $adminId,
            $report === 'profitability'
                ? 'view_margin'
                : (
                    $report === 'supplier_payables'
                        ? 'view_supplier_cost'
                        : 'management_mis'
                ),
            'export_management_mis_report',
            'authorized',
            'mis_report',
            null,
            [
                'report' => $report,
                'format' => $export,
                'from' => $from,
                'to' => $to,
            ]
        );
    }

    tsMisExport(
        $export,
        (string)$catalog[$report]['label'],
        $from,
        $to,
        (array)$data['columns'],
        (array)$data['rows']
    );
}

function mrE(?string $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function mrPretty($value, string $key = ''): string
{
    if ($value === null || $value === '') {
        return '-';
    }

    if (
        is_numeric($value)
        && preg_match(
            '/amount|margin|cost|selling|revenue|value|paid|outstanding|balance/i',
            $key
        )
    ) {
        return number_format((float)$value, 2);
    }

    if (
        preg_match(
            '/date|_at$/i',
            $key
        )
    ) {
        $ts = strtotime((string)$value);

        if ($ts) {
            return date(
                strpos($key, '_at') !== false
                    ? 'd M Y h:i A'
                    : 'd M Y',
                $ts
            );
        }
    }

    return (string)$value;
}

function mrQuery(
    string $report,
    string $from,
    string $to,
    array $extra = []
): string {
    return
        http_build_query(
            array_merge(
                [
                    'report' => $report,
                    'from' => $from,
                    'to' => $to,
                ],
                $extra
            )
        );
}

$availableReports = $catalog;

if (!$canViewMargin) {
    unset($availableReports['profitability']);
}

if (!$canViewSupplierCost) {
    unset($availableReports['supplier_payables']);
}

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Management MIS & Reports | TRAVSCOPE Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fb;color:#172033;font-family:Arial,Helvetica,sans-serif}.top{min-height:68px;padding:10px 4%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;border-bottom:1px solid #dfe7f0;position:sticky;top:0;z-index:20}.brand{font-weight:900}.brand span{color:#2563eb}.actions{display:flex;gap:7px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 10px;border:1px solid #cbd5e1;border-radius:9px;background:#fff;color:#334155;text-decoration:none;font-size:9px;font-weight:900;cursor:pointer}.btn.primary{background:#2563eb;border-color:#2563eb;color:#fff}.btn.good{background:#059669;border-color:#059669;color:#fff}.wrap{max-width:1480px;margin:20px auto;padding:0 13px}.hero{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;padding:17px;border:1px solid #dbe5ef;border-radius:15px;background:linear-gradient(135deg,#fff,#eff6ff)}.hero h1{margin:0;font-size:20px}.hero p{margin:5px 0 0;color:#64748b;font-size:10px;line-height:1.5}.filters{display:flex;gap:7px;flex-wrap:wrap;align-items:end;margin-top:11px;padding:11px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.field label{display:block;margin-bottom:4px;color:#64748b;font-size:7.5px;font-weight:900;text-transform:uppercase}.field select,.field input{min-height:34px;padding:6px 8px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;font-size:9px}.tabs{display:flex;gap:6px;flex-wrap:wrap;margin-top:11px}.tabs a{padding:7px 9px;border:1px solid #cbd5e1;border-radius:999px;background:#fff;color:#475569;text-decoration:none;font-size:8px;font-weight:900}.tabs a.active{background:#0f172a;border-color:#0f172a;color:#fff}.summary{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin-top:11px}.sum{padding:10px;border:1px solid #e2e8f0;border-radius:11px;background:#fff}.sum span{display:block;color:#64748b;font-size:7px;font-weight:900;text-transform:uppercase}.sum strong{display:block;margin-top:4px;font-size:12px}.card{margin-top:11px;border:1px solid #dfe7f0;border-radius:13px;background:#fff;overflow:hidden}.head{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;padding:11px 12px;border-bottom:1px solid #e8eef5;background:#fbfdff}.head h2{margin:0;font-size:12px}.head p{margin:4px 0 0;color:#64748b;font-size:8.5px;line-height:1.4}.table-wrap{overflow:auto;max-height:70vh}table{width:100%;border-collapse:collapse}th,td{padding:7px 8px;border-bottom:1px solid #eef2f7;text-align:left;font-size:8px;white-space:nowrap}th{position:sticky;top:0;background:#f8fafc;color:#64748b;font-size:7px;text-transform:uppercase;z-index:2}.empty{padding:28px;text-align:center;color:#94a3b8;font-size:10px}.note{padding:9px 11px;border-top:1px solid #e8eef5;background:#f8fafc;color:#64748b;font-size:8.5px}.tag{display:inline-flex;padding:4px 7px;border-radius:999px;background:#eff6ff;color:#1d4ed8;font-size:7.5px;font-weight:900}
@media(max-width:950px){.summary{grid-template-columns:repeat(2,1fr)}.top,.hero{flex-direction:column;align-items:flex-start}}
@media(max-width:550px){.summary{grid-template-columns:1fr}.filters{display:grid;grid-template-columns:1fr}.field select,.field input{width:100%}}
</style>

<!-- TRAVSCOPE PRO UNIFORM UI -->
<script>document.documentElement.classList.add('ts-pro-preload');</script>
<link rel="stylesheet" href="assets/travscope-pro-admin.css?v=20260916-v2">
</head>
<body>

<header class="top">
    <div class="brand">
        TRAV<span>SCOPE</span> · MANAGEMENT MIS
    </div>

    <div class="actions">
        <a class="btn" href="<?= mrE(BASE_URL . 'admin-dashboard.php'); ?>">
            <i class="fa-solid fa-gauge-high"></i>
            Dashboard
        </a>

        <a class="btn" href="<?= mrE(BASE_URL . 'admin-business-analytics.php'); ?>">
            <i class="fa-solid fa-chart-line"></i>
            Analytics
        </a>

        <a
            class="btn good"
            href="<?= mrE(
                BASE_URL
                . 'admin-mis-reports.php?'
                . mrQuery(
                    $report,
                    $from,
                    $to,
                    ['export' => 'csv']
                )
            ); ?>"
        >
            <i class="fa-solid fa-file-csv"></i>
            CSV
        </a>

        <a
            class="btn primary"
            href="<?= mrE(
                BASE_URL
                . 'admin-mis-reports.php?'
                . mrQuery(
                    $report,
                    $from,
                    $to,
                    ['export' => 'xls']
                )
            ); ?>"
        >
            <i class="fa-solid fa-file-excel"></i>
            Excel
        </a>
    </div>
</header>

<main class="wrap">

<section class="hero">
    <div>
        <h1>Management MIS + Reporting / Export Center</h1>
        <p>
            Date-range operational and commercial reports generated directly from current TRAVSCOPE
            Booking, CRM, billing, supplier finance, profitability, Repeat Sales and Operations data.
            Exported rows are exactly the same data shown in the selected report.
        </p>
    </div>

    <span class="tag">
        <?= mrE(strtoupper($profile)); ?>
    </span>
</section>

<form method="get" class="filters">
    <div class="field">
        <label>Report</label>
        <select name="report">
            <?php foreach ($availableReports as $key => $meta): ?>
                <option
                    value="<?= mrE($key); ?>"
                    <?= $report === $key ? 'selected' : ''; ?>
                >
                    <?= mrE((string)$meta['label']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="field">
        <label>From</label>
        <input type="date" name="from" value="<?= mrE($from); ?>">
    </div>

    <div class="field">
        <label>To</label>
        <input type="date" name="to" value="<?= mrE($to); ?>">
    </div>

    <button class="btn primary" type="submit">
        <i class="fa-solid fa-filter"></i>
        Run Report
    </button>
</form>

<div class="tabs">
    <?php foreach ($availableReports as $key => $meta): ?>
        <a
            class="<?= $report === $key ? 'active' : ''; ?>"
            href="<?= mrE(
                BASE_URL
                . 'admin-mis-reports.php?'
                . mrQuery(
                    $key,
                    $from,
                    $to
                )
            ); ?>"
        >
            <?= mrE((string)$meta['label']); ?>
        </a>
    <?php endforeach; ?>
</div>

<?php if (!empty($data['totals'])): ?>
    <div class="summary">
        <?php foreach ((array)$data['totals'] as $label => $value): ?>
            <div class="sum">
                <span><?= mrE((string)$label); ?></span>
                <strong>
                    <?= mrE(
                        is_float($value)
                        || (
                            is_numeric($value)
                            && preg_match(
                                '/sales|margin|value|paid|outstanding|balance|scheduled|invoice/i',
                                (string)$label
                            )
                        )
                            ? number_format((float)$value, 2)
                            : (string)$value
                    ); ?>
                </strong>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<section class="card">
    <div class="head">
        <div>
            <h2><?= mrE((string)$catalog[$report]['label']); ?></h2>
            <p>
                <?= mrE((string)$catalog[$report]['description']); ?>
                · <?= mrE($from); ?> to <?= mrE($to); ?>
            </p>
        </div>

        <span class="tag">
            <?= count((array)$data['rows']); ?> ROWS
        </span>
    </div>

    <div class="table-wrap">
        <?php if (empty($data['columns'])): ?>
            <div class="empty">
                <?= mrE((string)($data['note'] ?? 'Report module is unavailable.')); ?>
            </div>

        <?php elseif (empty($data['rows'])): ?>
            <div class="empty">
                No records found for this date range.
            </div>

        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <?php foreach ((array)$data['columns'] as $key => $label): ?>
                            <th><?= mrE((string)$label); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ((array)$data['rows'] as $row): ?>
                        <tr>
                            <?php foreach ((array)$data['columns'] as $key => $label): ?>
                                <td>
                                    <?= mrE(
                                        mrPretty(
                                            $row[$key] ?? '',
                                            (string)$key
                                        )
                                    ); ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <?php if (!empty($data['note'])): ?>
        <div class="note">
            <strong>Report basis:</strong>
            <?= mrE((string)$data['note']); ?>
        </div>
    <?php endif; ?>
</section>

</main>

<script src="assets/travscope-pro-admin.js?v=20260916-v2" defer></script><script src="site-brand-sync.js?v=20261005-v2473" defer></script>
</body>
</html>
